// Patient Care Compliance Types

export type PatientCareDomain =
  | 'Clinical Care Delivery'
  | 'Care Plans & Documentation'
  | 'Medication Administration'
  | 'Infection Prevention & Control'
  | 'Patient Rights & Grievances'
  | 'Incident / Adverse Event Management'
  | 'Falls / Pressure Injury Prevention'
  | 'Staffing & Competency'
  | 'Quality Measures / Outcomes'
  | 'Discharge / Transitions of Care'
  | 'Patient Tracker / Observations'
  | 'Checklists';

export type OversightBody =
  | 'CMS'
  | 'State Survey/DOH'
  | 'Accreditation'
  | 'OCR'
  | 'CDC'
  | 'Other';

export type Priority = 'Critical' | 'High' | 'Medium' | 'Low';

export type Status = 'Open' | 'In Progress' | 'Pending Review' | 'Completed' | 'Overdue' | 'Closed';

export type RiskLevel = 'Critical' | 'High' | 'Medium' | 'Low';

export type UserRole =
  | 'Staff (Patient Care)'
  | 'Department Head (Patient Care)'
  | 'Compliance Head'
  | 'Org Admin';

export interface BaseItem {
  id: string;
  title: string;
  description: string;
  status: Status;
  priority: Priority;
  owner: string;
  createdDate: string;
  dueDate: string;
  updatedDate: string;
  domains: PatientCareDomain[];
  oversightBodies: OversightBody[];
  evidencePackRequired: boolean;
  phiInvolved: boolean;
  facility?: string;
}

export interface RiskItem extends BaseItem {
  type: 'risk';
  riskLevel: RiskLevel;
  preventiveControls: string[];
  detectiveControls: string[];
  mitigationPlan: string;
}

export interface AuditItem extends BaseItem {
  type: 'audit';
  auditType: 'Internal' | 'External' | 'Mock Survey' | 'Self-Assessment';
  deadline: string;
  findings: number;
}

export interface ComplianceItem extends BaseItem {
  type: 'compliance';
  category: string;
  capaRequired: boolean;
  capaId?: string;
  isPatientTracker?: boolean;
}

export interface CAPAItem extends BaseItem {
  type: 'capa';
  rootCause: string;
  correctiveAction: string;
  preventiveAction: string;
  linkedComplianceId: string;
  verificationDate?: string;
}

export interface CitationItem extends BaseItem {
  type: 'citation';
  surveyDate: string;
  citationType: 'Survey Finding' | 'Deficiency' | 'Immediate Jeopardy' | 'Condition-Level';
  pocStatus: 'Draft' | 'Submitted' | 'Accepted' | 'Rejected';
  pocDueDate: string;
}

export interface FeedbackItem extends BaseItem {
  type: 'feedback';
  feedbackType: 'Complaint' | 'Grievance' | 'Suggestion' | 'Compliment' | 'Safety Concern';
  source: 'Patient' | 'Family' | 'Staff' | 'Anonymous';
  slaDue: string;
  resolution?: string;
}

export interface EnforcementItem extends BaseItem {
  type: 'enforcement';
  enforcementType: 'Survey Action' | 'Sanction' | 'Civil Money Penalty' | 'Termination Notice' | 'State Action';
  agency: string;
  responseDeadline: string;
  financialImpact?: number;
}

export interface PolicyItem {
  id: string;
  name: string;
  category: string;
  lastUpdate: string;
  status: 'Active' | 'Under Review' | 'Pending Approval' | 'Retired';
  nextReviewDate: string;
  owner: string;
  version: string;
}

export interface OrgMember {
  id: string;
  name: string;
  title: string;
  department: string;
  email: string;
  phone: string;
  reportsTo?: string;
  role: UserRole;
  status: 'Active' | 'Inactive';
}

export interface QuickStat {
  label: string;
  value: number;
  change?: number;
  changeType?: 'increase' | 'decrease';
}

export interface KPI {
  id: string;
  name: string;
  value: number;
  target: number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  formula: string;
}

export interface ActionItem {
  id: string;
  title: string;
  type: 'audit' | 'compliance' | 'enforcement' | 'risk' | 'feedback' | 'capa';
  priority: Priority;
  dueDate: string;
  owner: string;
  status: Status;
  sourceApp: string;
}

export interface ReviewItem {
  id: string;
  type: string;
  title: string;
  owner: string;
  updatedDate: string;
  status: Status;
  sourceApp: string;
}

export interface Alert {
  id: string;
  type: 'warning' | 'error' | 'info';
  title: string;
  description: string;
  date: string;
}

// Navigation types
export interface NavItem {
  label: string;
  path: string;
  icon: string;
  children?: NavItem[];
}

export interface Breadcrumb {
  label: string;
  path?: string;
}

// Filter types
export interface DashboardFilters {
  facility: string;
  dateRange: '7' | '30' | '90' | 'ytd' | 'custom';
  customDateStart?: string;
  customDateEnd?: string;
  viewMode: 'me' | 'all';
  searchQuery: string;
}
