import {
  RiskItem,
  AuditItem,
  ComplianceItem,
  CAPAItem,
  CitationItem,
  FeedbackItem,
  EnforcementItem,
  PolicyItem,
  OrgMember,
  QuickStat,
  KPI,
  ActionItem,
  ReviewItem,
  Alert
} from '@/types/patientCare';

// Risk Items
export const mockRisks: RiskItem[] = [
  {
    id: 'RSK-PC-001',
    type: 'risk',
    title: 'Medication Administration Error Risk',
    description: 'Elevated risk of medication errors during shift transitions',
    status: 'Open',
    priority: 'High',
    owner: 'Dr. Sarah Chen',
    createdDate: '2024-12-01',
    dueDate: '2025-01-15',
    updatedDate: '2024-12-20',
    domains: ['Medication Administration', 'Clinical Care Delivery'],
    oversightBodies: ['CMS', 'Accreditation'],
    evidencePackRequired: true,
    phiInvolved: true,
    riskLevel: 'High',
    preventiveControls: ['Double-check verification', 'Bar code scanning'],
    detectiveControls: ['Near-miss reporting', 'Monthly audit'],
    mitigationPlan: 'Implement standardized handoff protocol'
  },
  {
    id: 'RSK-PC-002',
    type: 'risk',
    title: 'Falls Prevention Program Gap',
    description: 'Inconsistent falls risk assessment completion across units',
    status: 'In Progress',
    priority: 'Medium',
    owner: 'Nancy Williams, RN',
    createdDate: '2024-11-15',
    dueDate: '2025-01-30',
    updatedDate: '2024-12-18',
    domains: ['Falls / Pressure Injury Prevention', 'Quality Measures / Outcomes'],
    oversightBodies: ['CMS', 'State Survey/DOH'],
    evidencePackRequired: true,
    phiInvolved: false,
    riskLevel: 'Medium',
    preventiveControls: ['Unit-based education', 'EHR alerts'],
    detectiveControls: ['Weekly compliance reports'],
    mitigationPlan: 'Standardize assessment tool across all units'
  },
  {
    id: 'RSK-PC-003',
    type: 'risk',
    title: 'Infection Control Compliance Risk',
    description: 'Hand hygiene compliance below benchmark in ICU',
    status: 'Pending Review',
    priority: 'Critical',
    owner: 'Infection Prevention Team',
    createdDate: '2024-12-10',
    dueDate: '2025-01-05',
    updatedDate: '2024-12-22',
    domains: ['Infection Prevention & Control', 'Clinical Care Delivery'],
    oversightBodies: ['CDC', 'Accreditation', 'State Survey/DOH'],
    evidencePackRequired: true,
    phiInvolved: false,
    riskLevel: 'Critical',
    preventiveControls: ['Secret shopper audits', 'Hand sanitizer stations'],
    detectiveControls: ['Electronic monitoring badges'],
    mitigationPlan: 'Intensive ICU re-education campaign'
  }
];

// Audit Items
export const mockAudits: AuditItem[] = [
  {
    id: 'AUD-PC-001',
    type: 'audit',
    title: 'Q4 Care Documentation Audit',
    description: 'Quarterly review of patient care documentation completeness',
    status: 'In Progress',
    priority: 'High',
    owner: 'Quality Team',
    createdDate: '2024-12-01',
    dueDate: '2024-12-31',
    updatedDate: '2024-12-20',
    domains: ['Care Plans & Documentation'],
    oversightBodies: ['CMS', 'Accreditation'],
    evidencePackRequired: true,
    phiInvolved: true,
    auditType: 'Internal',
    deadline: '2024-12-31',
    findings: 5
  },
  {
    id: 'AUD-PC-002',
    type: 'audit',
    title: 'Medication Administration Checklist',
    description: 'Monthly medication administration process verification',
    status: 'Pending Review',
    priority: 'Medium',
    owner: 'Pharmacy Director',
    createdDate: '2024-12-05',
    dueDate: '2025-01-10',
    updatedDate: '2024-12-19',
    domains: ['Medication Administration', 'Checklists'],
    oversightBodies: ['CMS'],
    evidencePackRequired: false,
    phiInvolved: true,
    auditType: 'Self-Assessment',
    deadline: '2025-01-10',
    findings: 2
  },
  {
    id: 'AUD-PC-003',
    type: 'audit',
    title: 'Mock Survey Readiness Assessment',
    description: 'Annual mock survey preparation audit',
    status: 'Open',
    priority: 'Critical',
    owner: 'Compliance Director',
    createdDate: '2024-12-15',
    dueDate: '2025-02-01',
    updatedDate: '2024-12-15',
    domains: ['Clinical Care Delivery', 'Patient Rights & Grievances', 'Care Plans & Documentation'],
    oversightBodies: ['CMS', 'State Survey/DOH', 'Accreditation'],
    evidencePackRequired: true,
    phiInvolved: false,
    auditType: 'Mock Survey',
    deadline: '2025-02-01',
    findings: 0
  }
];

// Compliance Items
export const mockCompliance: ComplianceItem[] = [
  {
    id: 'CMP-PC-001',
    type: 'compliance',
    title: 'Patient Rights Notice Update Required',
    description: 'State mandate to update patient rights notifications by end of quarter',
    status: 'In Progress',
    priority: 'High',
    owner: 'Patient Relations',
    createdDate: '2024-11-01',
    dueDate: '2024-12-31',
    updatedDate: '2024-12-18',
    domains: ['Patient Rights & Grievances'],
    oversightBodies: ['State Survey/DOH', 'CMS'],
    evidencePackRequired: true,
    phiInvolved: false,
    category: 'Patient Care Compliance',
    capaRequired: false
  },
  {
    id: 'CMP-PC-002',
    type: 'compliance',
    title: 'Discharge Planning Process Gap',
    description: 'Incomplete discharge instructions documentation identified',
    status: 'Open',
    priority: 'Medium',
    owner: 'Case Management',
    createdDate: '2024-12-10',
    dueDate: '2025-01-20',
    updatedDate: '2024-12-15',
    domains: ['Discharge / Transitions of Care', 'Care Plans & Documentation'],
    oversightBodies: ['CMS', 'Accreditation'],
    evidencePackRequired: true,
    phiInvolved: true,
    category: 'Clinical Care Delivery',
    capaRequired: true,
    capaId: 'CAPA-PC-001'
  },
  {
    id: 'CMP-PC-003',
    type: 'compliance',
    title: 'Adverse Event Reporting Enhancement',
    description: 'System improvements needed for real-time adverse event tracking',
    status: 'Pending Review',
    priority: 'High',
    owner: 'Risk Management',
    createdDate: '2024-12-05',
    dueDate: '2025-01-25',
    updatedDate: '2024-12-20',
    domains: ['Incident / Adverse Event Management', 'Quality Measures / Outcomes'],
    oversightBodies: ['CMS', 'State Survey/DOH'],
    evidencePackRequired: true,
    phiInvolved: true,
    category: 'Incident / Adverse Event Management',
    capaRequired: true,
    capaId: 'CAPA-PC-002'
  }
];

// CAPA Items
export const mockCAPAs: CAPAItem[] = [
  {
    id: 'CAPA-PC-001',
    type: 'capa',
    title: 'Discharge Documentation CAPA',
    description: 'Corrective action for discharge documentation gaps',
    status: 'In Progress',
    priority: 'High',
    owner: 'Case Management Director',
    createdDate: '2024-12-12',
    dueDate: '2025-02-01',
    updatedDate: '2024-12-20',
    domains: ['Discharge / Transitions of Care'],
    oversightBodies: ['CMS'],
    evidencePackRequired: true,
    phiInvolved: false,
    rootCause: 'Lack of standardized discharge checklist',
    correctiveAction: 'Implement mandatory EHR discharge checklist',
    preventiveAction: 'Quarterly compliance audits',
    linkedComplianceId: 'CMP-PC-002'
  },
  {
    id: 'CAPA-PC-002',
    type: 'capa',
    title: 'Adverse Event Reporting CAPA',
    description: 'System and process improvements for event reporting',
    status: 'Open',
    priority: 'High',
    owner: 'Quality Director',
    createdDate: '2024-12-15',
    dueDate: '2025-02-15',
    updatedDate: '2024-12-18',
    domains: ['Incident / Adverse Event Management'],
    oversightBodies: ['State Survey/DOH'],
    evidencePackRequired: true,
    phiInvolved: true,
    rootCause: 'Delayed reporting due to complex workflow',
    correctiveAction: 'Streamline reporting interface',
    preventiveAction: 'Staff education and monthly monitoring',
    linkedComplianceId: 'CMP-PC-003'
  }
];

// Citation Items
export const mockCitations: CitationItem[] = [
  {
    id: 'CIT-PC-001',
    type: 'citation',
    title: 'Care Planning Deficiency F656',
    description: 'Deficiency cited for incomplete care plan updates',
    status: 'In Progress',
    priority: 'Critical',
    owner: 'DON',
    createdDate: '2024-11-20',
    dueDate: '2025-01-15',
    updatedDate: '2024-12-22',
    domains: ['Care Plans & Documentation'],
    oversightBodies: ['CMS', 'State Survey/DOH'],
    evidencePackRequired: true,
    phiInvolved: true,
    surveyDate: '2024-11-15',
    citationType: 'Deficiency',
    pocStatus: 'Submitted',
    pocDueDate: '2025-01-15'
  },
  {
    id: 'CIT-PC-002',
    type: 'citation',
    title: 'Patient Rights Survey Finding',
    description: 'Finding related to grievance response timeliness',
    status: 'Open',
    priority: 'High',
    owner: 'Patient Relations Manager',
    createdDate: '2024-12-01',
    dueDate: '2025-01-30',
    updatedDate: '2024-12-15',
    domains: ['Patient Rights & Grievances'],
    oversightBodies: ['State Survey/DOH'],
    evidencePackRequired: true,
    phiInvolved: false,
    surveyDate: '2024-11-28',
    citationType: 'Survey Finding',
    pocStatus: 'Draft',
    pocDueDate: '2025-01-30'
  }
];

// Feedback Items
export const mockFeedback: FeedbackItem[] = [
  {
    id: 'FBK-PC-001',
    type: 'feedback',
    title: 'Patient Grievance - Wait Time',
    description: 'Complaint regarding extended wait time for pain medication',
    status: 'In Progress',
    priority: 'High',
    owner: 'Patient Relations',
    createdDate: '2024-12-18',
    dueDate: '2024-12-25',
    updatedDate: '2024-12-20',
    domains: ['Patient Rights & Grievances', 'Medication Administration'],
    oversightBodies: ['CMS'],
    evidencePackRequired: false,
    phiInvolved: true,
    feedbackType: 'Grievance',
    source: 'Patient',
    slaDue: '2024-12-25'
  },
  {
    id: 'FBK-PC-002',
    type: 'feedback',
    title: 'Safety Concern - Equipment',
    description: 'Staff reported unsafe patient lift equipment',
    status: 'Open',
    priority: 'Critical',
    owner: 'Safety Officer',
    createdDate: '2024-12-19',
    dueDate: '2024-12-22',
    updatedDate: '2024-12-19',
    domains: ['Clinical Care Delivery', 'Incident / Adverse Event Management'],
    oversightBodies: ['Accreditation'],
    evidencePackRequired: true,
    phiInvolved: false,
    feedbackType: 'Safety Concern',
    source: 'Staff',
    slaDue: '2024-12-22'
  },
  {
    id: 'FBK-PC-003',
    type: 'feedback',
    title: 'Care Experience - Communication',
    description: 'Family feedback about care team communication',
    status: 'Pending Review',
    priority: 'Medium',
    owner: 'Nurse Manager',
    createdDate: '2024-12-15',
    dueDate: '2024-12-30',
    updatedDate: '2024-12-18',
    domains: ['Clinical Care Delivery', 'Patient Rights & Grievances'],
    oversightBodies: ['CMS'],
    evidencePackRequired: false,
    phiInvolved: true,
    feedbackType: 'Complaint',
    source: 'Family',
    slaDue: '2024-12-30'
  }
];

// Enforcement Items
export const mockEnforcements: EnforcementItem[] = [
  {
    id: 'ENF-PC-001',
    type: 'enforcement',
    title: 'State Survey Follow-up Required',
    description: 'Required follow-up to November 2024 state survey findings',
    status: 'In Progress',
    priority: 'Critical',
    owner: 'Compliance Director',
    createdDate: '2024-12-01',
    dueDate: '2025-01-31',
    updatedDate: '2024-12-20',
    domains: ['Clinical Care Delivery', 'Care Plans & Documentation'],
    oversightBodies: ['State Survey/DOH'],
    evidencePackRequired: true,
    phiInvolved: false,
    enforcementType: 'Survey Action',
    agency: 'State Department of Health',
    responseDeadline: '2025-01-31'
  },
  {
    id: 'ENF-PC-002',
    type: 'enforcement',
    title: 'CMS Condition of Participation Review',
    description: 'Review related to care transitions documentation',
    status: 'Open',
    priority: 'High',
    owner: 'CNO',
    createdDate: '2024-12-15',
    dueDate: '2025-02-28',
    updatedDate: '2024-12-18',
    domains: ['Discharge / Transitions of Care'],
    oversightBodies: ['CMS'],
    evidencePackRequired: true,
    phiInvolved: true,
    enforcementType: 'Sanction',
    agency: 'CMS Regional Office',
    responseDeadline: '2025-02-28',
    financialImpact: 25000
  }
];

// Policy Items
export const mockPolicies: PolicyItem[] = [
  {
    id: 'POL-PC-001',
    name: 'Patient Rights and Responsibilities',
    category: 'Patient Rights & Grievances',
    lastUpdate: '2024-10-01',
    status: 'Active',
    nextReviewDate: '2025-10-01',
    owner: 'Patient Relations Director',
    version: '3.2'
  },
  {
    id: 'POL-PC-002',
    name: 'Care Planning and Documentation Standards',
    category: 'Care Plans & Documentation',
    lastUpdate: '2024-08-15',
    status: 'Under Review',
    nextReviewDate: '2025-02-15',
    owner: 'Chief Nursing Officer',
    version: '4.0'
  },
  {
    id: 'POL-PC-003',
    name: 'Medication Administration Policy',
    category: 'Medication Administration',
    lastUpdate: '2024-11-01',
    status: 'Active',
    nextReviewDate: '2025-11-01',
    owner: 'Pharmacy Director',
    version: '5.1'
  },
  {
    id: 'POL-PC-004',
    name: 'Falls Prevention Protocol',
    category: 'Falls / Pressure Injury Prevention',
    lastUpdate: '2024-06-01',
    status: 'Active',
    nextReviewDate: '2025-06-01',
    owner: 'Risk Manager',
    version: '2.3'
  },
  {
    id: 'POL-PC-005',
    name: 'Infection Prevention and Control Program',
    category: 'Infection Prevention & Control',
    lastUpdate: '2024-12-01',
    status: 'Active',
    nextReviewDate: '2025-12-01',
    owner: 'Infection Preventionist',
    version: '6.0'
  }
];

// Org Members
export const mockOrgMembers: OrgMember[] = [
  {
    id: 'ORG-001',
    name: 'Dr. Michael Roberts',
    title: 'Chief Medical Officer',
    department: 'Executive Leadership',
    email: 'mroberts@healthcare.org',
    phone: '(555) 123-4567',
    role: 'Org Admin',
    status: 'Active'
  },
  {
    id: 'ORG-002',
    name: 'Janet Thompson, RN, MSN',
    title: 'Chief Nursing Officer',
    department: 'Nursing Administration',
    email: 'jthompson@healthcare.org',
    phone: '(555) 123-4568',
    reportsTo: 'ORG-001',
    role: 'Department Head (Patient Care)',
    status: 'Active'
  },
  {
    id: 'ORG-003',
    name: 'David Martinez',
    title: 'Compliance Director',
    department: 'Compliance',
    email: 'dmartinez@healthcare.org',
    phone: '(555) 123-4569',
    reportsTo: 'ORG-001',
    role: 'Compliance Head',
    status: 'Active'
  },
  {
    id: 'ORG-004',
    name: 'Sarah Chen, MD',
    title: 'Director of Quality',
    department: 'Quality Management',
    email: 'schen@healthcare.org',
    phone: '(555) 123-4570',
    reportsTo: 'ORG-002',
    role: 'Department Head (Patient Care)',
    status: 'Active'
  },
  {
    id: 'ORG-005',
    name: 'Nancy Williams, RN',
    title: 'Patient Safety Officer',
    department: 'Risk Management',
    email: 'nwilliams@healthcare.org',
    phone: '(555) 123-4571',
    reportsTo: 'ORG-003',
    role: 'Staff (Patient Care)',
    status: 'Active'
  },
  {
    id: 'ORG-006',
    name: 'Robert Kim',
    title: 'Patient Relations Manager',
    department: 'Patient Experience',
    email: 'rkim@healthcare.org',
    phone: '(555) 123-4572',
    reportsTo: 'ORG-002',
    role: 'Staff (Patient Care)',
    status: 'Active'
  }
];

// Quick Stats
export const mockQuickStats: QuickStat[] = [
  { label: 'Total Open Items', value: 24, change: -3, changeType: 'decrease' },
  { label: 'Completed', value: 156, change: 12, changeType: 'increase' },
  { label: 'Pending Review', value: 8, change: 2, changeType: 'increase' },
  { label: 'Overdue', value: 3, change: -1, changeType: 'decrease' }
];

// KPIs
export const mockKPIs: KPI[] = [
  {
    id: 'KPI-001',
    name: 'Patient Care Compliance Rate',
    value: 94.5,
    target: 95,
    unit: '%',
    trend: 'up',
    formula: '(Compliant Items / Total Items) × 100'
  },
  {
    id: 'KPI-002',
    name: 'Time to Close Critical Issues',
    value: 5.2,
    target: 5,
    unit: 'days',
    trend: 'down',
    formula: 'Avg days from open to close for critical items'
  },
  {
    id: 'KPI-003',
    name: 'Incident Checklist Completion',
    value: 98.1,
    target: 100,
    unit: '%',
    trend: 'up',
    formula: '(Completed Checklists / Required Checklists) × 100'
  },
  {
    id: 'KPI-004',
    name: 'Grievance Response Timeliness',
    value: 91.3,
    target: 95,
    unit: '%',
    trend: 'stable',
    formula: '(On-time Responses / Total Grievances) × 100'
  },
  {
    id: 'KPI-005',
    name: 'Repeat Issue Rate (30 days)',
    value: 4.2,
    target: 5,
    unit: '%',
    trend: 'down',
    formula: '(Repeat Issues / Total Issues) × 100'
  }
];

// Action Items for Action Center
export const mockActionItems: ActionItem[] = [
  {
    id: 'ACT-001',
    title: 'Complete Q4 Documentation Audit',
    type: 'audit',
    priority: 'High',
    dueDate: '2024-12-31',
    owner: 'Quality Team',
    status: 'In Progress',
    sourceApp: 'AuditPro'
  },
  {
    id: 'ACT-002',
    title: 'Respond to Grievance - Wait Time',
    type: 'feedback',
    priority: 'High',
    dueDate: '2024-12-25',
    owner: 'Patient Relations',
    status: 'In Progress',
    sourceApp: 'FeedbackHub'
  },
  {
    id: 'ACT-003',
    title: 'Submit POC for Care Planning Deficiency',
    type: 'compliance',
    priority: 'Critical',
    dueDate: '2025-01-15',
    owner: 'DON',
    status: 'In Progress',
    sourceApp: 'CitaPro'
  },
  {
    id: 'ACT-004',
    title: 'Review ICU Infection Control Mitigation',
    type: 'risk',
    priority: 'Critical',
    dueDate: '2025-01-05',
    owner: 'Infection Prevention',
    status: 'Pending Review',
    sourceApp: 'RiskGuard'
  },
  {
    id: 'ACT-005',
    title: 'State Survey Follow-up Documentation',
    type: 'enforcement',
    priority: 'Critical',
    dueDate: '2025-01-31',
    owner: 'Compliance Director',
    status: 'In Progress',
    sourceApp: 'EnforcePoint'
  }
];

// Review Items
export const mockReviewItems: ReviewItem[] = [
  {
    id: 'REV-001',
    type: 'Audit Review',
    title: 'Medication Administration Checklist Review',
    owner: 'Pharmacy Director',
    updatedDate: '2024-12-19',
    status: 'Pending Review',
    sourceApp: 'AuditPro'
  },
  {
    id: 'REV-002',
    type: 'Risk Approval',
    title: 'ICU Infection Control Risk Mitigation',
    owner: 'Infection Prevention Team',
    updatedDate: '2024-12-22',
    status: 'Pending Review',
    sourceApp: 'RiskGuard'
  },
  {
    id: 'REV-003',
    type: 'Compliance Closure',
    title: 'Adverse Event Reporting Enhancement',
    owner: 'Risk Management',
    updatedDate: '2024-12-20',
    status: 'Pending Review',
    sourceApp: 'ComplianceConnect'
  },
  {
    id: 'REV-004',
    type: 'CAPA Approval',
    title: 'Discharge Documentation CAPA',
    owner: 'Case Management Director',
    updatedDate: '2024-12-20',
    status: 'Pending Review',
    sourceApp: 'ActionGuard'
  }
];

// Alerts
export const mockAlerts: Alert[] = [
  {
    id: 'ALT-001',
    type: 'error',
    title: 'Upcoming State Survey',
    description: 'State survey window opens in 45 days',
    date: '2025-02-01'
  },
  {
    id: 'ALT-002',
    type: 'warning',
    title: 'Incident Cluster Detected',
    description: '3 similar fall incidents in Unit 4A this week',
    date: '2024-12-22'
  },
  {
    id: 'ALT-003',
    type: 'warning',
    title: 'High-Priority Items Overdue',
    description: '2 critical compliance items past due date',
    date: '2024-12-20'
  }
];

// Facilities
export const mockFacilities = [
  { id: 'FAC-001', name: 'Main Hospital Campus' },
  { id: 'FAC-002', name: 'North Medical Center' },
  { id: 'FAC-003', name: 'South Ambulatory Care' },
  { id: 'FAC-004', name: 'East Rehabilitation Center' }
];
