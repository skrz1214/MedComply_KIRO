import { cn } from '@/lib/utils';
import { AlertCircle, AlertTriangle, Info, X } from 'lucide-react';
import { Alert } from '@/types/patientCare';
import { useState } from 'react';

interface AlertsPanelProps {
  alerts: Alert[];
  onDismiss?: (id: string) => void;
}

export function AlertsPanel({ alerts, onDismiss }: AlertsPanelProps) {
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set());

  const visibleAlerts = alerts.filter(a => !dismissedIds.has(a.id));

  const handleDismiss = (id: string) => {
    setDismissedIds(prev => new Set([...prev, id]));
    onDismiss?.(id);
  };

  const alertStyles = {
    error: {
      bg: 'bg-destructive/10 border-destructive/30',
      icon: AlertCircle,
      iconColor: 'text-destructive'
    },
    warning: {
      bg: 'bg-warning/10 border-warning/30',
      icon: AlertTriangle,
      iconColor: 'text-warning'
    },
    info: {
      bg: 'bg-info/10 border-info/30',
      icon: Info,
      iconColor: 'text-info'
    }
  };

  if (visibleAlerts.length === 0) return null;

  return (
    <div className="dashboard-card p-5">
      <div className="widget-header">
        <h2 className="widget-title">Alerts</h2>
        <span className="text-sm text-muted-foreground">
          {visibleAlerts.length} active
        </span>
      </div>

      <div className="mt-4 space-y-3">
        {visibleAlerts.map((alert) => {
          const style = alertStyles[alert.type];
          const Icon = style.icon;

          return (
            <div
              key={alert.id}
              className={cn(
                "flex items-start gap-3 p-3 rounded-lg border animate-fade-in",
                style.bg
              )}
            >
              <Icon className={cn("h-5 w-5 flex-shrink-0 mt-0.5", style.iconColor)} />
              
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-medium text-foreground">
                  {alert.title}
                </h4>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {alert.description}
                </p>
                <span className="text-xs text-muted-foreground/60 mt-1 block">
                  {new Date(alert.date).toLocaleDateString()}
                </span>
              </div>

              <button 
                onClick={() => handleDismiss(alert.id)}
                className="p-1 rounded hover:bg-foreground/10 transition-colors"
              >
                <X className="h-4 w-4 text-muted-foreground" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
