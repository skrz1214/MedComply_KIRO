import { cn } from '@/lib/utils';
import { 
  ChevronUp, 
  ChevronDown, 
  MoreHorizontal, 
  Download,
  Eye,
  Edit,
  Trash2,
  ExternalLink
} from 'lucide-react';
import { useState, ReactNode } from 'react';
import { Status, Priority } from '@/types/patientCare';

export interface Column<T> {
  key: string;
  label: string;
  sortable?: boolean;
  render?: (item: T) => ReactNode;
  className?: string;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  onRowClick?: (item: T) => void;
  onExport?: () => void;
  keyField: keyof T;
  emptyMessage?: string;
  actions?: {
    view?: (item: T) => void;
    edit?: (item: T) => void;
    delete?: (item: T) => void;
    openInApp?: (item: T) => void;
  };
}

export function DataTable<T>({
  columns,
  data,
  onRowClick,
  onExport,
  keyField,
  emptyMessage = 'No data available',
  actions
}: DataTableProps<T>) {
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [openActionMenu, setOpenActionMenu] = useState<string | null>(null);

  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDirection('asc');
    }
  };

  const sortedData = [...data].sort((a, b) => {
    if (!sortKey) return 0;
    const aValue = (a as Record<string, unknown>)[sortKey];
    const bValue = (b as Record<string, unknown>)[sortKey];
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return sortDirection === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
    }
    if (typeof aValue === 'number' && typeof bValue === 'number') {
      return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
    }
    return 0;
  });

  return (
    <div className="dashboard-card overflow-hidden">
      {onExport && (
        <div className="flex items-center justify-end p-4 border-b border-border">
          <button onClick={onExport} className="action-button action-button-secondary">
            <Download className="h-4 w-4" />
            Export CSV
          </button>
        </div>
      )}
      <div className="overflow-x-auto">
        <table className="data-table">
          <thead className="bg-muted/50">
            <tr>
              {columns.map((column) => (
                <th 
                  key={column.key}
                  className={cn(column.sortable && "cursor-pointer hover:bg-muted select-none", column.className)}
                  onClick={() => column.sortable && handleSort(column.key)}
                >
                  <div className="flex items-center gap-2">
                    {column.label}
                    {column.sortable && sortKey === column.key && (
                      sortDirection === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                    )}
                  </div>
                </th>
              ))}
              {actions && <th className="w-12"></th>}
            </tr>
          </thead>
          <tbody>
            {sortedData.length === 0 ? (
              <tr>
                <td colSpan={columns.length + (actions ? 1 : 0)} className="text-center py-12 text-muted-foreground">
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              sortedData.map((item) => (
                <tr 
                  key={String(item[keyField])}
                  className={cn("transition-colors", onRowClick && "cursor-pointer")}
                  onClick={() => onRowClick?.(item)}
                >
                  {columns.map((column) => (
                    <td key={column.key} className={column.className}>
                      {column.render ? column.render(item) : String((item as Record<string, unknown>)[column.key] ?? '')}
                    </td>
                  ))}
                  {actions && (
                    <td className="relative">
                      <button 
                        onClick={(e) => { e.stopPropagation(); setOpenActionMenu(openActionMenu === String(item[keyField]) ? null : String(item[keyField])); }}
                        className="p-1 rounded hover:bg-muted transition-colors"
                      >
                        <MoreHorizontal className="h-4 w-4 text-muted-foreground" />
                      </button>
                      {openActionMenu === String(item[keyField]) && (
                        <>
                          <div className="fixed inset-0 z-40" onClick={() => setOpenActionMenu(null)} />
                          <div className="absolute right-0 top-full mt-1 w-40 bg-card border border-border rounded-lg shadow-lg z-50 py-1 animate-fade-in">
                            {actions.view && <button onClick={(e) => { e.stopPropagation(); actions.view!(item); setOpenActionMenu(null); }} className="flex items-center gap-2 w-full px-3 py-2 text-sm text-foreground hover:bg-muted transition-colors"><Eye className="h-4 w-4" />View</button>}
                            {actions.edit && <button onClick={(e) => { e.stopPropagation(); actions.edit!(item); setOpenActionMenu(null); }} className="flex items-center gap-2 w-full px-3 py-2 text-sm text-foreground hover:bg-muted transition-colors"><Edit className="h-4 w-4" />Edit</button>}
                            {actions.openInApp && <button onClick={(e) => { e.stopPropagation(); actions.openInApp!(item); setOpenActionMenu(null); }} className="flex items-center gap-2 w-full px-3 py-2 text-sm text-foreground hover:bg-muted transition-colors"><ExternalLink className="h-4 w-4" />Open in App</button>}
                            {actions.delete && <button onClick={(e) => { e.stopPropagation(); actions.delete!(item); setOpenActionMenu(null); }} className="flex items-center gap-2 w-full px-3 py-2 text-sm text-destructive hover:bg-destructive/10 transition-colors"><Trash2 className="h-4 w-4" />Delete</button>}
                          </div>
                        </>
                      )}
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function StatusBadge({ status }: { status: Status }) {
  const statusStyles: Record<Status, string> = {
    'Open': 'status-chip-info', 'In Progress': 'status-chip-warning', 'Pending Review': 'status-chip-warning',
    'Completed': 'status-chip-success', 'Overdue': 'status-chip-error', 'Closed': 'status-chip-neutral'
  };
  return <span className={cn("status-chip", statusStyles[status])}>{status}</span>;
}

export function PriorityBadge({ priority }: { priority: Priority }) {
  const priorityStyles: Record<Priority, string> = {
    'Critical': 'status-chip-error', 'High': 'status-chip-warning', 'Medium': 'status-chip-info', 'Low': 'status-chip-neutral'
  };
  return <span className={cn("status-chip", priorityStyles[priority])}>{priority}</span>;
}

export function DomainTags({ domains }: { domains: string[] }) {
  const displayDomains = domains.slice(0, 2);
  const remaining = domains.length - 2;
  return (
    <div className="flex flex-wrap gap-1">
      {displayDomains.map((domain, index) => (<span key={index} className="text-xs px-2 py-0.5 rounded bg-muted text-muted-foreground">{domain}</span>))}
      {remaining > 0 && <span className="text-xs px-2 py-0.5 rounded bg-muted text-muted-foreground">+{remaining}</span>}
    </div>
  );
}
