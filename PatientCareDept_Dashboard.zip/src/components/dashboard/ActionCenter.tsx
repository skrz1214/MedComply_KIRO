import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { 
  Clock, 
  CheckCircle2, 
  ArrowRight,
  Plus,
  ChevronRight,
  Search,
  RefreshCw
} from 'lucide-react';
import { ActionItem, ReviewItem } from '@/types/patientCare';
import { useState } from 'react';
import { Input } from '@/components/ui/input';

interface ActionCenterProps {
  items: ActionItem[];
  onAddAction?: () => void;
}

export function ActionCenter({ items, onAddAction }: ActionCenterProps) {
  const [activeTab, setActiveTab] = useState<'today' | 'week' | 'overdue'>('today');
  const [viewMode, setViewMode] = useState<'me' | 'all'>('me');
  const [searchQuery, setSearchQuery] = useState('');

  const today = new Date();
  const weekFromNow = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);

  const todayCount = items.filter(i => new Date(i.dueDate).toDateString() === today.toDateString()).length;
  const weekCount = items.filter(i => {
    const d = new Date(i.dueDate);
    return d >= today && d <= weekFromNow;
  }).length;
  const overdueCount = items.filter(i => new Date(i.dueDate) < today && i.status !== 'Completed').length;

  const filteredItems = items.filter(item => {
    const dueDate = new Date(item.dueDate);
    
    let tabMatch = false;
    if (activeTab === 'today') {
      tabMatch = dueDate.toDateString() === today.toDateString();
    } else if (activeTab === 'week') {
      tabMatch = dueDate >= today && dueDate <= weekFromNow;
    } else {
      tabMatch = dueDate < today && item.status !== 'Completed';
    }
    
    const searchMatch = searchQuery === '' || 
      item.title.toLowerCase().includes(searchQuery.toLowerCase());
    
    return tabMatch && searchMatch;
  });

  const completedToday = filteredItems.filter(i => i.status === 'Completed').length;
  const totalToday = filteredItems.length;

  const priorityColors = {
    Critical: 'bg-destructive text-destructive-foreground',
    High: 'bg-warning text-warning-foreground',
    Medium: 'bg-info text-info-foreground',
    Low: 'bg-muted text-muted-foreground'
  };

  const statusText: Record<string, string> = {
    'Open': 'Not started',
    'In Progress': 'In progress',
    'Pending Review': 'Pending review',
    'Completed': 'Completed',
    'Overdue': 'Overdue',
    'Closed': 'Closed'
  };

  return (
    <div className="dashboard-card">
      {/* Header */}
      <div className="flex items-center justify-between p-5 pb-4">
        <div className="flex items-center gap-3">
          <h2 className="widget-title">Action Center</h2>
          <span className="w-6 h-6 rounded-full bg-accent text-accent-foreground text-xs font-semibold flex items-center justify-center">
            {items.length}
          </span>
        </div>
        <button 
          onClick={onAddAction}
          className="action-button action-button-primary"
        >
          <Plus className="h-4 w-4" />
          Add Action Item
        </button>
      </div>

      <div className="px-5 pb-4">
        <p className="text-sm text-muted-foreground">Executive compliance tasks</p>
      </div>

      {/* Today's Progress */}
      <div className="mx-5 p-4 bg-muted/30 rounded-lg mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-foreground">Today's Progress</span>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>{completedToday} of {totalToday} completed</span>
            <RefreshCw className="h-4 w-4" />
          </div>
        </div>
        <div className="h-2 bg-warning/30 rounded-full overflow-hidden">
          <div 
            className="h-full bg-warning rounded-full transition-all"
            style={{ width: totalToday > 0 ? `${(completedToday / totalToday) * 100}%` : '0%' }}
          />
        </div>
      </div>

      {/* Tabs Row */}
      <div className="px-5 flex items-center gap-4 text-sm">
        <button 
          onClick={() => setActiveTab('today')}
          className={cn(
            "font-medium transition-colors",
            activeTab === 'today' ? "text-foreground" : "text-muted-foreground hover:text-foreground"
          )}
        >
          Today <span className="text-muted-foreground">{todayCount}</span>
        </button>
        <button 
          onClick={() => setActiveTab('week')}
          className={cn(
            "font-medium transition-colors",
            activeTab === 'week' ? "text-foreground" : "text-muted-foreground hover:text-foreground"
          )}
        >
          This Week <span className="text-muted-foreground">{weekCount}</span>
        </button>
        <button 
          onClick={() => setActiveTab('overdue')}
          className={cn(
            "font-medium transition-colors",
            activeTab === 'overdue' ? "text-destructive" : "text-muted-foreground hover:text-destructive"
          )}
        >
          Overdue <span className="text-destructive">{overdueCount}</span>
        </button>
      </div>

      {/* Filters Row */}
      <div className="px-5 py-3 flex items-center gap-3">
        <div className="flex rounded-md border border-border overflow-hidden">
          <button 
            onClick={() => setViewMode('me')}
            className={cn(
              "px-3 py-1.5 text-sm font-medium transition-colors",
              viewMode === 'me' 
                ? "bg-accent text-accent-foreground" 
                : "bg-background text-muted-foreground hover:bg-muted"
            )}
          >
            Me
          </button>
          <button 
            onClick={() => setViewMode('all')}
            className={cn(
              "px-3 py-1.5 text-sm font-medium transition-colors",
              viewMode === 'all' 
                ? "bg-accent text-accent-foreground" 
                : "bg-background text-muted-foreground hover:bg-muted"
            )}
          >
            All
          </button>
        </div>

        <select className="px-3 py-1.5 text-sm border border-border rounded-md bg-background text-foreground">
          <option>All Types</option>
          <option>Audit</option>
          <option>Risk</option>
          <option>Compliance</option>
          <option>Feedback</option>
        </select>

        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search tasks"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 h-9 bg-background"
          />
        </div>
      </div>

      {/* Items List */}
      <div className="border-t border-border">
        {filteredItems.length === 0 ? (
          <div className="py-12 text-center text-muted-foreground">
            <CheckCircle2 className="h-8 w-8 mx-auto mb-2 text-success" />
            <p className="text-sm">No items for this period</p>
          </div>
        ) : (
          filteredItems.slice(0, 5).map((item) => (
            <div 
              key={item.id}
              className="flex items-center justify-between px-5 py-4 border-b border-border/50 hover:bg-muted/30 transition-colors cursor-pointer group"
            >
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-medium text-foreground mb-1">
                  {item.title}
                </h4>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    Due {new Date(item.dueDate).toLocaleDateString() === today.toLocaleDateString() 
                      ? 'Today' 
                      : new Date(item.dueDate).toLocaleDateString()}
                  </span>
                  <span>•</span>
                  <span>👤 {item.owner}</span>
                  <span>•</span>
                  <span className={cn(
                    "px-1.5 py-0.5 rounded text-xs font-medium",
                    priorityColors[item.priority]
                  )}>
                    {item.priority}
                  </span>
                  <span className="text-muted-foreground">{statusText[item.status] || item.status}</span>
                </div>
              </div>

              <ChevronRight className="h-5 w-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          ))
        )}
      </div>

      {/* View All Link */}
      {filteredItems.length > 5 && (
        <div className="p-4 border-t border-border text-center">
          <Link 
            to="/dashboards/department/patient-care/compliance?from=action-center"
            className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
          >
            View All Actions
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      )}
    </div>
  );
}

interface ReviewQueueProps {
  items: ReviewItem[];
}

export function ReviewQueue({ items }: ReviewQueueProps) {
  const typeStyles: Record<string, { bg: string; text: string }> = {
    'Policy': { bg: 'bg-blue-100', text: 'text-blue-700' },
    'Audit Review': { bg: 'bg-amber-100', text: 'text-amber-700' },
    'Audit': { bg: 'bg-amber-100', text: 'text-amber-700' },
    'Training': { bg: 'bg-purple-100', text: 'text-purple-700' },
    'Risk Approval': { bg: 'bg-orange-100', text: 'text-orange-700' },
    'Compliance Closure': { bg: 'bg-green-100', text: 'text-green-700' },
    'CAPA Approval': { bg: 'bg-teal-100', text: 'text-teal-700' },
    'Enforcement Response': { bg: 'bg-red-100', text: 'text-red-700' },
    'Citation POC': { bg: 'bg-rose-100', text: 'text-rose-700' }
  };

  const statusStyles: Record<string, string> = {
    'Pending Review': 'status-chip-warning',
    'In Progress': 'status-chip-info',
    'Open': 'status-chip-info',
    'Completed': 'status-chip-success',
    'Overdue': 'status-chip-error'
  };

  return (
    <div className="dashboard-card">
      {/* Header */}
      <div className="flex items-center gap-3 p-5 pb-2">
        <h2 className="widget-title">Review Queue</h2>
        <span className="w-6 h-6 rounded-full bg-warning text-warning-foreground text-xs font-semibold flex items-center justify-center">
          {items.length}
        </span>
      </div>

      <div className="px-5 pb-4">
        <p className="text-sm text-muted-foreground">Pending reviews & sign-offs</p>
      </div>

      <div className="border-t border-border">
        {items.length === 0 ? (
          <div className="py-12 text-center text-muted-foreground">
            <CheckCircle2 className="h-8 w-8 mx-auto mb-2 text-success" />
            <p className="text-sm">No pending reviews</p>
          </div>
        ) : (
          items.map((item) => {
            const typeStyle = typeStyles[item.type] || { bg: 'bg-muted', text: 'text-muted-foreground' };
            
            return (
              <div 
                key={item.id}
                className="flex items-center gap-4 px-5 py-4 border-b border-border/50 hover:bg-muted/30 transition-colors cursor-pointer group"
              >
                {/* Icon */}
                <div className="w-10 h-10 rounded-lg bg-muted/50 flex items-center justify-center flex-shrink-0">
                  <span className="text-lg">📄</span>
                </div>
                
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium text-foreground mb-1">
                    {item.title}
                  </h4>
                  <div className="flex items-center gap-2 text-xs">
                    <span className={cn(
                      "px-2 py-0.5 rounded text-xs font-medium",
                      typeStyle.bg, typeStyle.text
                    )}>
                      {item.type}
                    </span>
                    <span className="text-muted-foreground">👤 {item.owner}</span>
                    <span className="text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {new Date(item.updatedDate).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric', 
                        year: 'numeric' 
                      })}
                    </span>
                    <span className={cn("status-chip", statusStyles[item.status] || 'status-chip-neutral')}>
                      {item.status}
                    </span>
                  </div>
                </div>

                <ChevronRight className="h-5 w-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
