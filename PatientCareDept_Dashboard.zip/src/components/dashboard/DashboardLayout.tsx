import { ReactNode, createContext, useContext, useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { 
  LayoutDashboard, 
  ShieldAlert, 
  ClipboardCheck, 
  FileCheck2, 
  MessageSquare, 
  Gavel,
  Users,
  Search,
  Bell,
  Settings,
  ChevronDown,
  Home,
  Shield,
  UserCog,
  User,
  Check,
  FileText
} from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

// Role types and context
export type UserRole = 'admin' | 'department_head' | 'staff';

interface RoleInfo {
  id: UserRole;
  label: string;
  shortLabel: string;
  icon: typeof Shield;
  color: string;
}

export const roles: RoleInfo[] = [
  { id: 'admin', label: 'Admin / Compliance Head', shortLabel: 'Admin', icon: Shield, color: 'text-primary' },
  { id: 'department_head', label: 'Department Head (Patient Care)', shortLabel: 'Dept Head', icon: UserCog, color: 'text-info' },
  { id: 'staff', label: 'Staff (Patient Care)', shortLabel: 'Staff', icon: User, color: 'text-muted-foreground' },
];

interface RoleContextType {
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  getRoleInfo: () => RoleInfo;
  hasPermission: (requiredRole: UserRole) => boolean;
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export function useRole() {
  const context = useContext(RoleContext);
  if (!context) {
    throw new Error('useRole must be used within a DashboardLayout');
  }
  return context;
}

interface DashboardLayoutProps {
  children: ReactNode;
}

const navItems = [
  { label: 'Dashboard', path: '/dashboards/department/patient-care', icon: LayoutDashboard },
  { label: 'Org Chart', path: '/dashboards/department/patient-care/org-chart', icon: Users },
  { label: 'Risk Management', path: '/dashboards/department/patient-care/risks', icon: ShieldAlert },
  { label: 'Audit Management', path: '/dashboards/department/patient-care/audits', icon: ClipboardCheck },
  { label: 'Enforcement Management', path: '/dashboards/department/patient-care/enforcements', icon: Gavel },
  { label: 'Compliance Tracking', path: '/dashboards/department/patient-care/compliance', icon: FileCheck2 },
  { label: 'Feedback Management', path: '/dashboards/department/patient-care/feedback', icon: MessageSquare },
  { label: 'Documentation', path: '/dashboards/department/patient-care/documentation', icon: FileText },
];

function Sidebar({ collapsed, onToggle }: { collapsed: boolean; onToggle: () => void }) {
  const location = useLocation();

  return (
    <aside 
      className={cn(
        "fixed left-0 top-0 h-screen bg-card border-r border-border flex flex-col transition-all duration-300 z-50",
        collapsed ? "w-16" : "w-56"
      )}
    >
      {/* Logo */}
      <div className="h-16 flex items-center px-4 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center flex-shrink-0">
            <FileCheck2 className="h-5 w-5 text-accent-foreground" />
          </div>
          {!collapsed && (
            <div className="min-w-0">
              <span className="font-display font-bold text-foreground text-sm">ComplianceHub</span>
              <p className="text-xs text-muted-foreground truncate">Patient Care Division</p>
            </div>
          )}
        </div>
      </div>

      {/* Section Label */}
      {!collapsed && (
        <div className="px-4 py-3">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            Management Hub
          </span>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto scrollbar-thin">
        <ul className="space-y-0.5 px-2">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            
            return (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors",
                    isActive 
                      ? "bg-accent/10 text-accent font-medium" 
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  )}
                >
                  <Icon className="h-4 w-4 flex-shrink-0" />
                  {!collapsed && <span className="truncate">{item.label}</span>}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </aside>
  );
}

function Header({ currentRole, onRoleChange }: { currentRole: UserRole; onRoleChange: (role: UserRole) => void }) {
  const currentRoleInfo = roles.find(r => r.id === currentRole) || roles[0];
  const RoleIcon = currentRoleInfo.icon;

  const handleRoleChange = (role: UserRole) => {
    onRoleChange(role);
    const roleInfo = roles.find(r => r.id === role);
    toast.success(`Switched to ${roleInfo?.label}`, {
      description: 'You are now viewing the dashboard as this role.'
    });
  };

  return (
    <header className="h-14 bg-card border-b border-border flex items-center justify-between px-6">
      {/* Home Icon */}
      <div className="flex items-center gap-4">
        <Link to="/" className="p-1.5 rounded-md hover:bg-muted transition-colors">
          <Home className="h-4 w-4 text-muted-foreground" />
        </Link>
      </div>
      
      <div className="flex items-center gap-3">
        {/* Key Icon */}
        <button className="p-1.5 rounded-md hover:bg-muted transition-colors">
          <Settings className="h-4 w-4 text-muted-foreground" />
        </button>

        {/* Role Impersonation Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-2 px-3 py-1.5 rounded-md border border-border hover:bg-muted transition-colors">
              <RoleIcon className={cn("h-4 w-4", currentRoleInfo.color)} />
              <span className="text-sm text-foreground">{currentRoleInfo.shortLabel}</span>
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-64">
            <DropdownMenuLabel className="text-xs text-muted-foreground">
              Impersonate Role
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            {roles.map((role) => {
              const Icon = role.icon;
              const isActive = currentRole === role.id;
              return (
                <DropdownMenuItem
                  key={role.id}
                  onClick={() => handleRoleChange(role.id)}
                  className="flex items-center justify-between cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <Icon className={cn("h-4 w-4", role.color)} />
                    <span>{role.label}</span>
                  </div>
                  {isActive && <Check className="h-4 w-4 text-primary" />}
                </DropdownMenuItem>
              );
            })}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search..."
            className="h-8 w-40 pl-9 pr-3 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        {/* Notifications */}
        <button className="relative p-1.5 rounded-md hover:bg-muted transition-colors">
          <Bell className="h-4 w-4 text-muted-foreground" />
        </button>

        {/* Settings */}
        <button className="p-1.5 rounded-md hover:bg-muted transition-colors">
          <Settings className="h-4 w-4 text-muted-foreground" />
        </button>
      </div>
    </header>
  );
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [currentRole, setCurrentRole] = useState<UserRole>('admin');

  const getRoleInfo = () => roles.find(r => r.id === currentRole) || roles[0];
  
  const hasPermission = (requiredRole: UserRole) => {
    const roleHierarchy: UserRole[] = ['staff', 'department_head', 'admin'];
    const currentIndex = roleHierarchy.indexOf(currentRole);
    const requiredIndex = roleHierarchy.indexOf(requiredRole);
    return currentIndex >= requiredIndex;
  };

  const roleContextValue: RoleContextType = {
    currentRole,
    setCurrentRole,
    getRoleInfo,
    hasPermission,
  };

  return (
    <RoleContext.Provider value={roleContextValue}>
      <div className="min-h-screen bg-background">
        <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />
        
        <div 
          className={cn(
            "transition-all duration-300",
            sidebarCollapsed ? "ml-16" : "ml-56"
          )}
        >
          <Header currentRole={currentRole} onRoleChange={setCurrentRole} />
          <main className="p-6 animate-fade-in">
            {children}
          </main>
        </div>
      </div>
    </RoleContext.Provider>
  );
}
