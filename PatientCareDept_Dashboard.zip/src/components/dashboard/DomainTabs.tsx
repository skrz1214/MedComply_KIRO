import { cn } from '@/lib/utils';
import { ReactNode, useState } from 'react';

interface Tab {
  id: string;
  label: string;
  count?: number;
}

interface DomainTabsProps {
  tabs: Tab[];
  activeTab: string;
  onTabChange: (tabId: string) => void;
  children: ReactNode;
  filterSummary?: string[];
}

export function DomainTabs({ 
  tabs, 
  activeTab, 
  onTabChange, 
  children,
  filterSummary 
}: DomainTabsProps) {
  return (
    <div>
      {/* Tab Navigation */}
      <div className="flex gap-1 border-b border-border overflow-x-auto scrollbar-thin pb-px">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              "tab-button whitespace-nowrap flex items-center gap-2",
              activeTab === tab.id && "active"
            )}
          >
            {tab.label}
            {tab.count !== undefined && (
              <span className={cn(
                "text-xs px-1.5 py-0.5 rounded-full",
                activeTab === tab.id 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-muted text-muted-foreground"
              )}>
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Filter Summary Chips */}
      {filterSummary && filterSummary.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-4">
          {filterSummary.map((filter, index) => (
            <span key={index} className="filter-chip">
              {filter}
            </span>
          ))}
        </div>
      )}

      {/* Tab Content */}
      <div className="mt-6 animate-fade-in">
        {children}
      </div>
    </div>
  );
}

interface MetricTilesProps {
  metrics: {
    label: string;
    value: number;
    onClick?: () => void;
    variant?: 'default' | 'success' | 'warning' | 'error';
  }[];
}

export function MetricTiles({ metrics }: MetricTilesProps) {
  const variantStyles = {
    default: 'border-border hover:border-primary/30',
    success: 'border-success/30 bg-success/5 hover:border-success/50',
    warning: 'border-warning/30 bg-warning/5 hover:border-warning/50',
    error: 'border-destructive/30 bg-destructive/5 hover:border-destructive/50'
  };

  const valueStyles = {
    default: 'text-foreground',
    success: 'text-success',
    warning: 'text-warning',
    error: 'text-destructive'
  };

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
      {metrics.map((metric, index) => (
        <button
          key={index}
          onClick={metric.onClick}
          className={cn(
            "p-4 rounded-lg border transition-all text-left",
            variantStyles[metric.variant || 'default'],
            metric.onClick && "cursor-pointer hover:shadow-sm"
          )}
        >
          <span className="text-sm text-muted-foreground block">{metric.label}</span>
          <span className={cn(
            "text-2xl font-bold font-display block mt-1",
            valueStyles[metric.variant || 'default']
          )}>
            {metric.value}
          </span>
        </button>
      ))}
    </div>
  );
}
