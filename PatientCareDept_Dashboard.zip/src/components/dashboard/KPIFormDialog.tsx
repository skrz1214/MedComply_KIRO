import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { z } from 'zod';
import { toast } from '@/hooks/use-toast';

export interface KPIData {
  id: string;
  name: string;
  value: number;
  target: number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  formula: string;
  numerator: string;
  denominator: string;
  description?: string;
}

const kpiSchema = z.object({
  name: z.string().trim().min(1, 'Name is required').max(100, 'Name must be less than 100 characters'),
  value: z.number().min(0, 'Value must be positive'),
  target: z.number().min(0, 'Target must be positive'),
  unit: z.string().min(1, 'Unit is required'),
  trend: z.enum(['up', 'down', 'stable']),
  formula: z.string().max(200, 'Formula must be less than 200 characters'),
  numerator: z.string().trim().min(1, 'Numerator is required').max(100, 'Numerator must be less than 100 characters'),
  denominator: z.string().trim().min(1, 'Denominator is required').max(100, 'Denominator must be less than 100 characters'),
  description: z.string().max(500, 'Description must be less than 500 characters').optional()
});

interface KPIFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (kpi: KPIData) => void;
  editingKPI?: KPIData | null;
  mode: 'create' | 'edit';
}

export function KPIFormDialog({ open, onOpenChange, onSave, editingKPI, mode }: KPIFormDialogProps) {
  const [formData, setFormData] = useState<Partial<KPIData>>({
    name: '',
    value: 0,
    target: 0,
    unit: '%',
    trend: 'stable',
    formula: '',
    numerator: '',
    denominator: '',
    description: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editingKPI && mode === 'edit') {
      setFormData(editingKPI);
    } else if (mode === 'create') {
      setFormData({
        name: '',
        value: 0,
        target: 0,
        unit: '%',
        trend: 'stable',
        formula: '',
        numerator: '',
        denominator: '',
        description: ''
      });
    }
    setErrors({});
  }, [editingKPI, mode, open]);

  // Auto-generate formula from numerator and denominator
  useEffect(() => {
    if (formData.numerator && formData.denominator) {
      const formula = `(${formData.numerator} / ${formData.denominator}) × 100`;
      setFormData(prev => ({ ...prev, formula }));
    }
  }, [formData.numerator, formData.denominator]);

  const handleChange = (field: keyof KPIData, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user types
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleSubmit = () => {
    try {
      const validatedData = kpiSchema.parse({
        ...formData,
        value: Number(formData.value),
        target: Number(formData.target)
      });

      const kpiData: KPIData = {
        id: editingKPI?.id || `KPI-${Date.now()}`,
        name: validatedData.name,
        value: validatedData.value,
        target: validatedData.target,
        unit: validatedData.unit,
        trend: validatedData.trend,
        formula: validatedData.formula,
        numerator: validatedData.numerator,
        denominator: validatedData.denominator,
        description: validatedData.description
      };

      onSave(kpiData);
      onOpenChange(false);
      
      toast({
        title: mode === 'create' ? 'KPI Created' : 'KPI Updated',
        description: `"${kpiData.name}" has been ${mode === 'create' ? 'created' : 'updated'} successfully.`
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string> = {};
        error.errors.forEach(err => {
          if (err.path[0]) {
            newErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(newErrors);
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="font-display">
            {mode === 'create' ? 'Add New KPI' : 'Edit KPI'}
          </DialogTitle>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          {/* Name */}
          <div className="grid gap-2">
            <Label htmlFor="name">KPI Name *</Label>
            <Input
              id="name"
              value={formData.name || ''}
              onChange={(e) => handleChange('name', e.target.value)}
              placeholder="e.g., Patient Care Compliance Rate"
              className={errors.name ? 'border-destructive' : ''}
            />
            {errors.name && <span className="text-xs text-destructive">{errors.name}</span>}
          </div>

          {/* Description */}
          <div className="grid gap-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description || ''}
              onChange={(e) => handleChange('description', e.target.value)}
              placeholder="Brief description of what this KPI measures..."
              rows={2}
            />
          </div>

          {/* Value and Target Row */}
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="value">Current Value *</Label>
              <Input
                id="value"
                type="number"
                step="0.1"
                value={formData.value || 0}
                onChange={(e) => handleChange('value', parseFloat(e.target.value) || 0)}
                className={errors.value ? 'border-destructive' : ''}
              />
              {errors.value && <span className="text-xs text-destructive">{errors.value}</span>}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="target">Target *</Label>
              <Input
                id="target"
                type="number"
                step="0.1"
                value={formData.target || 0}
                onChange={(e) => handleChange('target', parseFloat(e.target.value) || 0)}
                className={errors.target ? 'border-destructive' : ''}
              />
              {errors.target && <span className="text-xs text-destructive">{errors.target}</span>}
            </div>
          </div>

          {/* Unit and Trend Row */}
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="unit">Unit *</Label>
              <Select
                value={formData.unit || '%'}
                onValueChange={(value) => handleChange('unit', value)}
              >
                <SelectTrigger id="unit">
                  <SelectValue placeholder="Select unit" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="%">Percentage (%)</SelectItem>
                  <SelectItem value="days">Days</SelectItem>
                  <SelectItem value="hours">Hours</SelectItem>
                  <SelectItem value="count">Count</SelectItem>
                  <SelectItem value="ratio">Ratio</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="trend">Trend</Label>
              <Select
                value={formData.trend || 'stable'}
                onValueChange={(value) => handleChange('trend', value as 'up' | 'down' | 'stable')}
              >
                <SelectTrigger id="trend">
                  <SelectValue placeholder="Select trend" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="up">↑ Improving</SelectItem>
                  <SelectItem value="down">↓ Declining</SelectItem>
                  <SelectItem value="stable">→ Stable</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Formula Section */}
          <div className="border-t border-border pt-4 mt-2">
            <h4 className="text-sm font-medium text-foreground mb-3">Formula Definition</h4>
            
            {/* Numerator */}
            <div className="grid gap-2 mb-3">
              <Label htmlFor="numerator">Numerator *</Label>
              <Input
                id="numerator"
                value={formData.numerator || ''}
                onChange={(e) => handleChange('numerator', e.target.value)}
                placeholder="e.g., Compliant Items"
                className={errors.numerator ? 'border-destructive' : ''}
              />
              {errors.numerator && <span className="text-xs text-destructive">{errors.numerator}</span>}
            </div>

            {/* Denominator */}
            <div className="grid gap-2 mb-3">
              <Label htmlFor="denominator">Denominator *</Label>
              <Input
                id="denominator"
                value={formData.denominator || ''}
                onChange={(e) => handleChange('denominator', e.target.value)}
                placeholder="e.g., Total Items"
                className={errors.denominator ? 'border-destructive' : ''}
              />
              {errors.denominator && <span className="text-xs text-destructive">{errors.denominator}</span>}
            </div>

            {/* Generated Formula Preview */}
            <div className="grid gap-2">
              <Label htmlFor="formula">Formula Preview</Label>
              <div className="p-3 bg-muted rounded-md text-sm text-muted-foreground font-mono">
                {formData.formula || '(Numerator / Denominator) × 100'}
              </div>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit}>
            {mode === 'create' ? 'Create KPI' : 'Save Changes'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
