import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { 
  FileCheck2, 
  MessageSquare, 
  ShieldAlert, 
  ClipboardCheck, 
  Gavel,
  FileWarning
} from 'lucide-react';

interface MicroAppTile {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  path: string;
  color: string;
}

const microApps: MicroAppTile[] = [
  {
    id: 'complianceconnect',
    name: 'ComplianceConnect',
    description: 'Compliance management hub',
    icon: FileCheck2,
    path: '/complianceconnect?from=patient-care-dashboard&dept=patient-care',
    color: 'bg-accent'
  },
  {
    id: 'feedbackhub',
    name: 'FeedbackHub',
    description: 'Stakeholder feedback system',
    icon: MessageSquare,
    path: '/feedbackhub?from=patient-care-dashboard&dept=patient-care',
    color: 'bg-accent'
  },
  {
    id: 'riskguard',
    name: 'RiskGuard',
    description: 'Risk assessment platform',
    icon: ShieldAlert,
    path: '/riskguard?from=patient-care-dashboard&dept=patient-care',
    color: 'bg-warning'
  },
  {
    id: 'auditpro',
    name: 'AuditPro',
    description: 'Audit management system',
    icon: ClipboardCheck,
    path: '/auditpro?from=patient-care-dashboard&dept=patient-care',
    color: 'bg-accent'
  },
  {
    id: 'enforcepoint',
    name: 'EnforcePoint',
    description: 'Enforcement tracking',
    icon: Gavel,
    path: '/enforcepoint?from=patient-care-dashboard&dept=patient-care',
    color: 'bg-destructive'
  },
  {
    id: 'citapro',
    name: 'CitaPro',
    description: 'Citation management',
    icon: FileWarning,
    path: '/citapro?from=patient-care-dashboard&dept=patient-care',
    color: 'bg-warning'
  }
];

interface MicroAppTilesProps {
  className?: string;
}

export function MicroAppTiles({ className }: MicroAppTilesProps) {
  return (
    <div className={cn("space-y-4", className)}>
      <h2 className="text-lg font-semibold font-display text-foreground">Quick Access</h2>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {microApps.map((app) => {
          const Icon = app.icon;
          
          return (
            <Link
              key={app.id}
              to={app.path}
              className="dashboard-card p-4 hover:border-accent/50 transition-all group"
            >
              <div className={cn(
                "w-10 h-10 rounded-lg flex items-center justify-center mb-3",
                app.color
              )}>
                <Icon className="h-5 w-5 text-white" />
              </div>
              
              <h3 className="font-medium text-sm text-foreground">{app.name}</h3>
              <p className="text-xs text-muted-foreground mt-1">{app.description}</p>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
