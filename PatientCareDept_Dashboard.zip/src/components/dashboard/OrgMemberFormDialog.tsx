import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { OrgMember, UserRole } from '@/types/patientCare';
import { toast } from 'sonner';

interface OrgMemberFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  member?: OrgMember | null;
  allMembers: OrgMember[];
  onSave: (member: OrgMember) => void;
}

const roles: UserRole[] = [
  'Org Admin',
  'Compliance Head',
  'Department Head (Patient Care)',
  'Staff (Patient Care)',
];

const departments = [
  'Executive Leadership',
  'Nursing Administration',
  'Compliance',
  'Quality Management',
  'Risk Management',
  'Patient Care',
  'Clinical Operations',
  'Infection Prevention',
];

export function OrgMemberFormDialog({
  open,
  onOpenChange,
  member,
  allMembers,
  onSave,
}: OrgMemberFormDialogProps) {
  const [formData, setFormData] = useState<Partial<OrgMember>>({
    name: '',
    title: '',
    department: '',
    email: '',
    phone: '',
    role: 'Staff (Patient Care)',
    status: 'Active',
    reportsTo: undefined,
  });

  useEffect(() => {
    if (member) {
      setFormData(member);
    } else {
      setFormData({
        name: '',
        title: '',
        department: '',
        email: '',
        phone: '',
        role: 'Staff (Patient Care)',
        status: 'Active',
        reportsTo: undefined,
      });
    }
  }, [member, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.title || !formData.department || !formData.email) {
      toast.error('Please fill in all required fields');
      return;
    }

    const newMember: OrgMember = {
      id: member?.id || `ORG-${Date.now()}`,
      name: formData.name!,
      title: formData.title!,
      department: formData.department!,
      email: formData.email!,
      phone: formData.phone || '',
      role: formData.role as UserRole,
      status: formData.status as 'Active' | 'Inactive',
      reportsTo: formData.reportsTo || undefined,
    };

    onSave(newMember);
    onOpenChange(false);
    toast.success(member ? 'Member updated successfully' : 'Member added successfully');
  };

  const potentialManagers = allMembers.filter(
    (m) => m.id !== member?.id
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display">
            {member ? 'Edit Member' : 'Add New Member'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                value={formData.name || ''}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Dr. John Smith"
              />
            </div>

            <div className="col-span-2">
              <Label htmlFor="title">Job Title *</Label>
              <Input
                id="title"
                value={formData.title || ''}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="e.g., Chief Nursing Officer"
              />
            </div>

            <div>
              <Label htmlFor="department">Department *</Label>
              <Select
                value={formData.department || ''}
                onValueChange={(value) => setFormData({ ...formData, department: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="role">Role *</Label>
              <Select
                value={formData.role || 'Staff (Patient Care)'}
                onValueChange={(value) => setFormData({ ...formData, role: value as UserRole })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  {roles.map((role) => (
                    <SelectItem key={role} value={role}>
                      {role}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email || ''}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="email@healthcare.org"
              />
            </div>

            <div>
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                value={formData.phone || ''}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="(555) 123-4567"
              />
            </div>

            <div>
              <Label htmlFor="reportsTo">Reports To</Label>
              <Select
                value={formData.reportsTo || 'none'}
                onValueChange={(value) =>
                  setFormData({ ...formData, reportsTo: value === 'none' ? undefined : value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select manager" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None (Top Level)</SelectItem>
                  {potentialManagers.map((m) => (
                    <SelectItem key={m.id} value={m.id}>
                      {m.name} - {m.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status || 'Active'}
                onValueChange={(value) =>
                  setFormData({ ...formData, status: value as 'Active' | 'Inactive' })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="Inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-border">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">{member ? 'Update Member' : 'Add Member'}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
