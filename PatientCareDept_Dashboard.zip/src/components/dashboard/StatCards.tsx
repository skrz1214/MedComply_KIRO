import { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown, Minus, Plus, FileText, CheckCircle2, Clock, AlertTriangle } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: number | string;
  change?: number;
  changeType?: 'increase' | 'decrease';
  icon?: ReactNode;
  onClick?: () => void;
  variant?: 'default' | 'accent' | 'success' | 'warning' | 'error';
}

export function StatCard({
  label,
  value,
  change,
  changeType,
  icon,
  onClick,
  variant = 'default'
}: StatCardProps) {
  const variantStyles = {
    default: 'border-border',
    accent: 'border-accent/30 bg-accent/5',
    success: 'border-success/30 bg-success/5',
    warning: 'border-warning/30 bg-warning/5',
    error: 'border-destructive/30 bg-destructive/5'
  };

  const valueStyles = {
    default: 'text-foreground',
    accent: 'text-accent',
    success: 'text-success',
    warning: 'text-warning',
    error: 'text-destructive'
  };

  return (
    <div 
      className={cn(
        "stat-card",
        variantStyles[variant],
        onClick && "cursor-pointer hover:shadow-md"
      )}
      onClick={onClick}
    >
      <div className="flex items-start justify-between">
        <span className="stat-label">{label}</span>
        {icon && (
          <div className={cn("p-1.5 rounded-md", variant === 'default' ? 'bg-muted' : 'bg-current/10')}>
            {icon}
          </div>
        )}
      </div>
      
      <div className="flex items-end justify-between">
        <span className={cn("stat-value", valueStyles[variant])}>{value}</span>
        
        {change !== undefined && (
          <div className={cn(
            "flex items-center gap-1 text-xs font-medium",
            changeType === 'increase' ? 'text-success' : changeType === 'decrease' ? 'text-destructive' : 'text-muted-foreground'
          )}>
            {changeType === 'increase' ? (
              <TrendingUp className="h-3 w-3" />
            ) : changeType === 'decrease' ? (
              <TrendingDown className="h-3 w-3" />
            ) : (
              <Minus className="h-3 w-3" />
            )}
            <span>{Math.abs(change)}</span>
          </div>
        )}
      </div>
    </div>
  );
}

// Quick Stats Panel - Compact vertical list style matching reference
interface QuickStatsListProps {
  stats: {
    label: string;
    value: number;
    change?: number;
    changeType?: 'increase' | 'decrease';
  }[];
}

export function QuickStatsList({ stats }: QuickStatsListProps) {
  const getIcon = (label: string) => {
    if (label.toLowerCase().includes('total')) return <FileText className="h-4 w-4 text-muted-foreground" />;
    if (label.toLowerCase().includes('completed')) return <CheckCircle2 className="h-4 w-4 text-success" />;
    if (label.toLowerCase().includes('pending')) return <Clock className="h-4 w-4 text-warning" />;
    if (label.toLowerCase().includes('overdue')) return <AlertTriangle className="h-4 w-4 text-destructive" />;
    return <FileText className="h-4 w-4 text-muted-foreground" />;
  };

  const getValueColor = (label: string) => {
    if (label.toLowerCase().includes('completed')) return 'text-success';
    if (label.toLowerCase().includes('pending')) return 'text-warning';
    if (label.toLowerCase().includes('overdue')) return 'text-destructive';
    return 'text-foreground';
  };

  return (
    <div className="dashboard-card p-5">
      <h2 className="widget-title mb-4">Quick Stats</h2>
      
      <div className="space-y-4">
        {stats.map((stat, index) => (
          <div key={index} className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {getIcon(stat.label)}
              <span className="text-sm text-muted-foreground">{stat.label}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={cn("text-xl font-bold font-display", getValueColor(stat.label))}>
                {stat.value}
              </span>
              {stat.change !== undefined && (
                <span className={cn(
                  "text-xs font-medium",
                  stat.changeType === 'increase' ? 'text-success' : 'text-destructive'
                )}>
                  {stat.changeType === 'increase' ? '+' : ''}{stat.change}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

interface KPICardProps {
  name: string;
  value: number;
  target: number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  formula?: string;
}

export function KPICard({ name, value, target, unit, trend, formula }: KPICardProps) {
  const isOnTarget = unit === '%' 
    ? (value >= target) 
    : (value <= target);
  
  const percentOfTarget = unit === '%' 
    ? (value / 100) * 100
    : Math.min((target / value) * 100, 100);

  const progressColor = isOnTarget ? 'bg-success' : value >= target * 0.8 ? 'bg-warning' : 'bg-destructive';

  return (
    <div className="py-4 border-b border-border/50 last:border-0">
      <div className="flex items-start justify-between mb-2">
        <span className="text-sm font-medium text-foreground">{name}</span>
        <div className={cn(
          "flex items-center gap-1",
          trend === 'up' ? 'text-success' : trend === 'down' ? 'text-destructive' : 'text-muted-foreground'
        )}>
          {trend === 'up' ? (
            <TrendingUp className="h-4 w-4" />
          ) : trend === 'down' ? (
            <TrendingDown className="h-4 w-4" />
          ) : (
            <Minus className="h-4 w-4" />
          )}
        </div>
      </div>

      <div className="flex items-baseline gap-2 mb-1">
        <span className={cn("text-2xl font-bold font-display", isOnTarget ? 'text-foreground' : 'text-warning')}>
          {value}
          <span className="text-base font-normal text-muted-foreground ml-0.5">{unit}</span>
        </span>
        <span className="text-xs text-muted-foreground">
          Target: {target}{unit}
        </span>
      </div>

      {/* Progress bar */}
      <div className="h-1.5 bg-muted rounded-full overflow-hidden mb-2">
        <div 
          className={cn("h-full rounded-full transition-all", progressColor)}
          style={{ width: `${Math.min(percentOfTarget, 100)}%` }}
        />
      </div>

      {/* Formula */}
      {formula && (
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <FileText className="h-3 w-3" />
          <span className="truncate">{formula}</span>
        </div>
      )}
    </div>
  );
}

interface KPIPanelProps {
  kpis: KPICardProps[];
  onAdd?: () => void;
}

export function KPIPanel({ kpis, onAdd }: KPIPanelProps) {
  return (
    <div className="dashboard-card p-5">
      <div className="flex items-center justify-between mb-2">
        <h2 className="widget-title">Quality KPIs</h2>
        {onAdd && (
          <button 
            onClick={onAdd}
            className="w-6 h-6 rounded flex items-center justify-center hover:bg-muted transition-colors"
          >
            <Plus className="h-4 w-4 text-muted-foreground" />
          </button>
        )}
      </div>
      
      <div>
        {kpis.map((kpi, index) => (
          <KPICard key={index} {...kpi} />
        ))}
      </div>
    </div>
  );
}
