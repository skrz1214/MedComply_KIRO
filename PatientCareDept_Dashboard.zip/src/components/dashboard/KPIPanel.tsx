import { useState } from 'react';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown, Minus, Plus, FileText, MoreHorizontal, Edit, Trash2, Eye } from 'lucide-react';
import { KPIFormDialog, KPIData } from './KPIFormDialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { toast } from '@/hooks/use-toast';

interface KPIPanelProps {
  kpis: KPIData[];
  onKPIsChange: (kpis: KPIData[]) => void;
}

function KPICard({ 
  kpi, 
  onEdit, 
  onDelete,
  onView
}: { 
  kpi: KPIData; 
  onEdit: () => void; 
  onDelete: () => void;
  onView: () => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);

  const isOnTarget = kpi.unit === '%' 
    ? (kpi.value >= kpi.target) 
    : (kpi.value <= kpi.target);
  
  const percentOfTarget = kpi.unit === '%' 
    ? (kpi.value / 100) * 100
    : Math.min((kpi.target / kpi.value) * 100, 100);

  const progressColor = isOnTarget ? 'bg-success' : kpi.value >= kpi.target * 0.8 ? 'bg-warning' : 'bg-destructive';

  return (
    <div className="py-4 border-b border-border/50 last:border-0 group">
      <div className="flex items-start justify-between mb-2">
        <span className="text-sm font-medium text-foreground">{kpi.name}</span>
        <div className="flex items-center gap-2">
          <div className={cn(
            "flex items-center gap-1",
            kpi.trend === 'up' ? 'text-success' : kpi.trend === 'down' ? 'text-destructive' : 'text-muted-foreground'
          )}>
            {kpi.trend === 'up' ? (
              <TrendingUp className="h-4 w-4" />
            ) : kpi.trend === 'down' ? (
              <TrendingDown className="h-4 w-4" />
            ) : (
              <Minus className="h-4 w-4" />
            )}
          </div>
          
          {/* Actions Menu */}
          <div className="relative">
            <button 
              onClick={() => setMenuOpen(!menuOpen)}
              className="p-1 rounded hover:bg-muted transition-colors opacity-0 group-hover:opacity-100"
            >
              <MoreHorizontal className="h-4 w-4 text-muted-foreground" />
            </button>
            
            {menuOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setMenuOpen(false)} />
                <div className="absolute right-0 top-full mt-1 w-32 bg-card border border-border rounded-lg shadow-lg z-50 py-1 animate-fade-in">
                  <button 
                    onClick={() => { onView(); setMenuOpen(false); }}
                    className="flex items-center gap-2 w-full px-3 py-2 text-sm text-foreground hover:bg-muted transition-colors"
                  >
                    <Eye className="h-4 w-4" />
                    View
                  </button>
                  <button 
                    onClick={() => { onEdit(); setMenuOpen(false); }}
                    className="flex items-center gap-2 w-full px-3 py-2 text-sm text-foreground hover:bg-muted transition-colors"
                  >
                    <Edit className="h-4 w-4" />
                    Edit
                  </button>
                  <button 
                    onClick={() => { onDelete(); setMenuOpen(false); }}
                    className="flex items-center gap-2 w-full px-3 py-2 text-sm text-destructive hover:bg-destructive/10 transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                    Delete
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="flex items-baseline gap-2 mb-1">
        <span className={cn("text-2xl font-bold font-display", isOnTarget ? 'text-foreground' : 'text-warning')}>
          {kpi.value}
          <span className="text-base font-normal text-muted-foreground ml-0.5">{kpi.unit}</span>
        </span>
        <span className="text-xs text-muted-foreground">
          Target: {kpi.target}{kpi.unit}
        </span>
      </div>

      {/* Progress bar */}
      <div className="h-1.5 bg-muted rounded-full overflow-hidden mb-2">
        <div 
          className={cn("h-full rounded-full transition-all", progressColor)}
          style={{ width: `${Math.min(percentOfTarget, 100)}%` }}
        />
      </div>

      {/* Formula */}
      {kpi.formula && (
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <FileText className="h-3 w-3" />
          <span className="truncate">{kpi.formula}</span>
        </div>
      )}
    </div>
  );
}

function KPIDetailDialog({ 
  kpi, 
  open, 
  onOpenChange 
}: { 
  kpi: KPIData | null; 
  open: boolean; 
  onOpenChange: (open: boolean) => void;
}) {
  if (!kpi) return null;

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="font-display">{kpi.name}</AlertDialogTitle>
          <AlertDialogDescription asChild>
            <div className="space-y-4 pt-4">
              {kpi.description && (
                <p className="text-sm text-foreground">{kpi.description}</p>
              )}
              
              <div className="grid grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
                <div>
                  <span className="text-xs text-muted-foreground">Current Value</span>
                  <p className="text-xl font-bold font-display">{kpi.value}{kpi.unit}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Target</span>
                  <p className="text-xl font-bold font-display">{kpi.target}{kpi.unit}</p>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-medium text-foreground">Formula</h4>
                <div className="p-3 bg-muted rounded-md">
                  <p className="text-sm font-mono text-muted-foreground">{kpi.formula}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-muted/50 rounded-lg">
                  <span className="text-xs text-muted-foreground">Numerator</span>
                  <p className="text-sm font-medium">{kpi.numerator}</p>
                </div>
                <div className="p-3 bg-muted/50 rounded-lg">
                  <span className="text-xs text-muted-foreground">Denominator</span>
                  <p className="text-sm font-medium">{kpi.denominator}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-sm">
                <span className="text-muted-foreground">Trend:</span>
                <span className={cn(
                  "flex items-center gap-1 font-medium",
                  kpi.trend === 'up' ? 'text-success' : kpi.trend === 'down' ? 'text-destructive' : 'text-muted-foreground'
                )}>
                  {kpi.trend === 'up' && <TrendingUp className="h-4 w-4" />}
                  {kpi.trend === 'down' && <TrendingDown className="h-4 w-4" />}
                  {kpi.trend === 'stable' && <Minus className="h-4 w-4" />}
                  {kpi.trend === 'up' ? 'Improving' : kpi.trend === 'down' ? 'Declining' : 'Stable'}
                </span>
              </div>
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogAction>Close</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

export function KPIPanel({ kpis, onKPIsChange }: KPIPanelProps) {
  const [formOpen, setFormOpen] = useState(false);
  const [formMode, setFormMode] = useState<'create' | 'edit'>('create');
  const [editingKPI, setEditingKPI] = useState<KPIData | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deletingKPI, setDeletingKPI] = useState<KPIData | null>(null);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [viewingKPI, setViewingKPI] = useState<KPIData | null>(null);

  const handleAddClick = () => {
    setFormMode('create');
    setEditingKPI(null);
    setFormOpen(true);
  };

  const handleEditClick = (kpi: KPIData) => {
    setFormMode('edit');
    setEditingKPI(kpi);
    setFormOpen(true);
  };

  const handleDeleteClick = (kpi: KPIData) => {
    setDeletingKPI(kpi);
    setDeleteDialogOpen(true);
  };

  const handleViewClick = (kpi: KPIData) => {
    setViewingKPI(kpi);
    setViewDialogOpen(true);
  };

  const handleSave = (kpi: KPIData) => {
    if (formMode === 'create') {
      onKPIsChange([...kpis, kpi]);
    } else {
      onKPIsChange(kpis.map(k => k.id === kpi.id ? kpi : k));
    }
  };

  const handleDelete = () => {
    if (deletingKPI) {
      onKPIsChange(kpis.filter(k => k.id !== deletingKPI.id));
      toast({
        title: 'KPI Deleted',
        description: `"${deletingKPI.name}" has been deleted.`
      });
      setDeleteDialogOpen(false);
      setDeletingKPI(null);
    }
  };

  return (
    <>
      <div className="dashboard-card p-5">
        <div className="flex items-center justify-between mb-2">
          <h2 className="widget-title">Quality KPIs</h2>
          <button 
            onClick={handleAddClick}
            className="w-6 h-6 rounded flex items-center justify-center hover:bg-muted transition-colors"
          >
            <Plus className="h-4 w-4 text-muted-foreground" />
          </button>
        </div>
        
        <div>
          {kpis.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">
              <p className="text-sm">No KPIs configured</p>
              <button 
                onClick={handleAddClick}
                className="mt-2 text-sm text-primary hover:text-primary/80 transition-colors"
              >
                Add your first KPI
              </button>
            </div>
          ) : (
            kpis.map((kpi) => (
              <KPICard 
                key={kpi.id} 
                kpi={kpi}
                onEdit={() => handleEditClick(kpi)}
                onDelete={() => handleDeleteClick(kpi)}
                onView={() => handleViewClick(kpi)}
              />
            ))
          )}
        </div>
      </div>

      {/* Create/Edit Dialog */}
      <KPIFormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        onSave={handleSave}
        editingKPI={editingKPI}
        mode={formMode}
      />

      {/* View Details Dialog */}
      <KPIDetailDialog
        kpi={viewingKPI}
        open={viewDialogOpen}
        onOpenChange={setViewDialogOpen}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete KPI</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deletingKPI?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
