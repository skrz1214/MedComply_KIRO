import { useState } from 'react';
import { DashboardLayout } from '@/components/dashboard/DashboardLayout';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { DomainTabs, MetricTiles } from '@/components/dashboard/DomainTabs';
import { DataTable, StatusBadge, PriorityBadge, DomainTags } from '@/components/dashboard/DataTable';
import { mockRisks, mockPolicies } from '@/data/mockPatientCareData';
import { RiskItem, PolicyItem } from '@/types/patientCare';
import { Button } from '@/components/ui/button';
import { Plus, Download, Search } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const riskTabs = [
  { id: 'all', label: 'All Patient Care' },
  { id: 'clinical', label: 'Clinical Care Delivery' },
  { id: 'incident', label: 'Incident / Adverse Event' },
  { id: 'rights', label: 'Patient Rights & Grievances' },
  { id: 'quality', label: 'Quality Measures / Outcomes' },
  { id: 'staffing', label: 'Staffing & Competency' },
  { id: 'infection', label: 'Infection Prevention' }
];

export default function RiskManagement() {
  const [activeTab, setActiveTab] = useState('all');
  const [mainTab, setMainTab] = useState('risks');
  const navigate = useNavigate();

  // Risk Management State
  const filteredRisks = activeTab === 'all' 
    ? mockRisks 
    : mockRisks.filter(risk => 
        risk.domains.some(d => d.toLowerCase().includes(activeTab))
      );

  const metrics = [
    { label: 'Total Risks', value: filteredRisks.length },
    { label: 'Pending Review', value: filteredRisks.filter(r => r.status === 'Pending Review').length, variant: 'warning' as const },
    { label: 'Completed', value: filteredRisks.filter(r => r.status === 'Completed').length, variant: 'success' as const },
    { label: 'Overdue', value: filteredRisks.filter(r => r.status === 'Overdue').length, variant: 'error' as const }
  ];

  const tabCounts = riskTabs.map(tab => ({
    ...tab,
    count: tab.id === 'all' 
      ? mockRisks.length
      : mockRisks.filter(r => r.domains.some(d => d.toLowerCase().includes(tab.id))).length
  }));

  const riskColumns = [
    { key: 'id', label: 'Risk ID', sortable: true },
    { key: 'title', label: 'Description', sortable: true, className: 'max-w-xs' },
    { 
      key: 'riskLevel', 
      label: 'Risk Level', 
      sortable: true,
      render: (item: RiskItem) => <PriorityBadge priority={item.riskLevel} />
    },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
      render: (item: RiskItem) => <StatusBadge status={item.status} />
    },
    { key: 'owner', label: 'Owner', sortable: true },
    { 
      key: 'dueDate', 
      label: 'Due Date', 
      sortable: true,
      render: (item: RiskItem) => new Date(item.dueDate).toLocaleDateString()
    },
    {
      key: 'domains',
      label: 'Domains',
      render: (item: RiskItem) => <DomainTags domains={item.domains} />
    }
  ];

  // Policies & Procedures State
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const categories = [...new Set(mockPolicies.map(p => p.category))];

  const filteredPolicies = mockPolicies.filter(policy => {
    const matchesSearch = policy.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          policy.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || policy.status === statusFilter;
    const matchesCategory = categoryFilter === 'all' || policy.category === categoryFilter;
    return matchesSearch && matchesStatus && matchesCategory;
  });

  const statusStyles: Record<string, string> = {
    'Active': 'status-chip-success',
    'Under Review': 'status-chip-warning',
    'Pending Approval': 'status-chip-info',
    'Retired': 'status-chip-neutral'
  };

  const policyColumns = [
    { key: 'name', label: 'Policy Name', sortable: true, className: 'max-w-md' },
    { 
      key: 'category', 
      label: 'Category', 
      sortable: true,
      render: (item: PolicyItem) => (
        <span className="text-sm px-2 py-0.5 rounded bg-muted text-muted-foreground">
          {item.category}
        </span>
      )
    },
    { 
      key: 'lastUpdate', 
      label: 'Last Update', 
      sortable: true, 
      render: (item: PolicyItem) => new Date(item.lastUpdate).toLocaleDateString() 
    },
    { 
      key: 'status', 
      label: 'Status',
      sortable: true,
      render: (item: PolicyItem) => (
        <span className={cn("status-chip", statusStyles[item.status])}>
          {item.status}
        </span>
      )
    },
    { 
      key: 'nextReviewDate', 
      label: 'Next Review', 
      sortable: true, 
      render: (item: PolicyItem) => {
        const reviewDate = new Date(item.nextReviewDate);
        const daysUntilReview = Math.ceil((reviewDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
        const isUpcoming = daysUntilReview <= 30;
        
        return (
          <span className={cn(isUpcoming && "text-warning font-medium")}>
            {reviewDate.toLocaleDateString()}
          </span>
        );
      }
    },
    { key: 'owner', label: 'Owner', sortable: true },
    { 
      key: 'version', 
      label: 'Version',
      render: (item: PolicyItem) => (
        <span className="text-xs font-mono bg-muted px-1.5 py-0.5 rounded">
          v{item.version}
        </span>
      )
    }
  ];

  // Policy stats
  const policyStats = {
    total: mockPolicies.length,
    active: mockPolicies.filter(p => p.status === 'Active').length,
    underReview: mockPolicies.filter(p => p.status === 'Under Review').length,
    pendingApproval: mockPolicies.filter(p => p.status === 'Pending Approval').length,
    upcomingReviews: mockPolicies.filter(p => {
      const days = Math.ceil((new Date(p.nextReviewDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
      return days <= 30 && days > 0;
    }).length
  };

  const handleExport = () => {
    toast.success('Export started', { description: 'Your CSV file will download shortly.' });
  };

  const handleAddRisk = () => {
    navigate('/riskguard/risks/new?dept=patient-care');
  };

  const handleAddPolicy = () => {
    navigate('/documents/policies/new?dept=patient-care');
  };

  return (
    <DashboardLayout>
      <DashboardHeader
        title="Risk Management"
        subtitle="Patient Care risk identification, assessment, and mitigation"
        actions={
          mainTab === 'risks' ? (
            <>
              <Button variant="outline" onClick={handleExport} className="gap-2">
                <Download className="h-4 w-4" />
                Export
              </Button>
              <Button variant="default" onClick={handleAddRisk} className="gap-2">
                <Plus className="h-4 w-4" />
                Add Risk
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" onClick={handleExport} className="gap-2">
                <Download className="h-4 w-4" />
                Export
              </Button>
              <Button variant="default" onClick={handleAddPolicy} className="gap-2">
                <Plus className="h-4 w-4" />
                Add Policy
              </Button>
            </>
          )
        }
      />

      <Tabs value={mainTab} onValueChange={setMainTab} className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="risks">Risk Register</TabsTrigger>
          <TabsTrigger value="policies">Policies and Procedures</TabsTrigger>
        </TabsList>

        <TabsContent value="risks" className="mt-0">
          <DomainTabs
            tabs={tabCounts}
            activeTab={activeTab}
            onTabChange={setActiveTab}
            filterSummary={activeTab !== 'all' ? [`Domain: ${riskTabs.find(t => t.id === activeTab)?.label}`] : undefined}
          >
            <MetricTiles metrics={metrics} />

            <DataTable
              columns={riskColumns}
              data={filteredRisks}
              keyField="id"
              onExport={handleExport}
              actions={{
                view: (item) => toast.info(`Viewing ${item.id}`),
                edit: (item) => navigate(`/riskguard/risks/${item.id}`),
                openInApp: (item) => navigate(`/riskguard/risks/${item.id}?from=patient-care-dashboard`)
              }}
            />
          </DomainTabs>
        </TabsContent>

        <TabsContent value="policies" className="mt-0">
          {/* Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
            <div className="dashboard-card p-4">
              <span className="text-sm text-muted-foreground">Total Policies</span>
              <span className="text-2xl font-bold font-display block mt-1">{policyStats.total}</span>
            </div>
            <div className="dashboard-card p-4 border-success/30 bg-success/5">
              <span className="text-sm text-muted-foreground">Active</span>
              <span className="text-2xl font-bold font-display text-success block mt-1">{policyStats.active}</span>
            </div>
            <div className="dashboard-card p-4 border-warning/30 bg-warning/5">
              <span className="text-sm text-muted-foreground">Under Review</span>
              <span className="text-2xl font-bold font-display text-warning block mt-1">{policyStats.underReview}</span>
            </div>
            <div className="dashboard-card p-4 border-info/30 bg-info/5">
              <span className="text-sm text-muted-foreground">Pending Approval</span>
              <span className="text-2xl font-bold font-display text-info block mt-1">{policyStats.pendingApproval}</span>
            </div>
            <div className="dashboard-card p-4">
              <span className="text-sm text-muted-foreground">Reviews Due (30d)</span>
              <span className="text-2xl font-bold font-display block mt-1">{policyStats.upcomingReviews}</span>
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-3 mb-6">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search policies..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-9 w-full pl-10 pr-4 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="h-9 px-3 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="all">All Status</option>
              <option value="Active">Active</option>
              <option value="Under Review">Under Review</option>
              <option value="Pending Approval">Pending Approval</option>
              <option value="Retired">Retired</option>
            </select>

            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="h-9 px-3 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="all">All Categories</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <DataTable
            columns={policyColumns}
            data={filteredPolicies}
            keyField="id"
            onExport={handleExport}
            emptyMessage="No policies match your filters"
            actions={{
              view: (item) => toast.info(`Viewing ${item.name}`),
              edit: (item) => navigate(`/documents/policies/${item.id}`),
              delete: (item) => toast.info(`Archive policy: ${item.name}`)
            }}
          />
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  );
}
