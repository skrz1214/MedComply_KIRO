import { useState } from 'react';
import { DashboardLayout } from '@/components/dashboard/DashboardLayout';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { DomainTabs, MetricTiles } from '@/components/dashboard/DomainTabs';
import { DataTable, StatusBadge, PriorityBadge, DomainTags } from '@/components/dashboard/DataTable';
import { mockAudits } from '@/data/mockPatientCareData';
import { AuditItem } from '@/types/patientCare';
import { Button } from '@/components/ui/button';
import { Plus, Download, Calendar } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

const auditTabs = [
  { id: 'all', label: 'All Patient Care' },
  { id: 'careplans', label: 'Care Plans & Documentation' },
  { id: 'checklist', label: 'Patient Care Checklist' },
  { id: 'incident', label: 'Incident Phase Checklist' },
  { id: 'medication', label: 'Medication Administration' },
  { id: 'infection', label: 'Infection Prevention' },
  { id: 'discharge', label: 'Discharge / Transitions' }
];

export default function AuditManagement() {
  const [activeTab, setActiveTab] = useState('all');
  const navigate = useNavigate();

  const filteredAudits = activeTab === 'all' 
    ? mockAudits 
    : mockAudits.filter(audit => 
        audit.domains.some(d => d.toLowerCase().includes(activeTab.replace('careplans', 'care plan')))
      );

  const metrics = [
    { label: 'Total Audits', value: filteredAudits.length },
    { label: 'Pending Review', value: filteredAudits.filter(a => a.status === 'Pending Review').length, variant: 'warning' as const },
    { label: 'Completed', value: filteredAudits.filter(a => a.status === 'Completed').length, variant: 'success' as const },
    { label: 'Overdue', value: filteredAudits.filter(a => a.status === 'Overdue').length, variant: 'error' as const }
  ];

  const tabCounts = auditTabs.map(tab => ({
    ...tab,
    count: tab.id === 'all' 
      ? mockAudits.length
      : mockAudits.filter(a => a.domains.some(d => d.toLowerCase().includes(tab.id.replace('careplans', 'care plan')))).length
  }));

  const columns = [
    { key: 'id', label: 'Audit ID', sortable: true },
    { key: 'title', label: 'Title', sortable: true, className: 'max-w-xs' },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
      render: (item: AuditItem) => <StatusBadge status={item.status} />
    },
    { 
      key: 'deadline', 
      label: 'Deadline', 
      sortable: true,
      render: (item: AuditItem) => (
        <span className="flex items-center gap-1.5">
          <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
          {new Date(item.deadline).toLocaleDateString()}
        </span>
      )
    },
    { key: 'owner', label: 'Owner', sortable: true },
    { 
      key: 'priority', 
      label: 'Priority', 
      sortable: true,
      render: (item: AuditItem) => <PriorityBadge priority={item.priority} />
    },
    {
      key: 'domains',
      label: 'Domains',
      render: (item: AuditItem) => <DomainTags domains={item.domains} />
    },
    {
      key: 'findings',
      label: 'Findings',
      render: (item: AuditItem) => (
        <span className={item.findings > 0 ? 'text-warning font-medium' : 'text-muted-foreground'}>
          {item.findings}
        </span>
      )
    }
  ];

  const handleExport = () => {
    toast.success('Export started', { description: 'Your CSV file will download shortly.' });
  };

  const handleAddAudit = () => {
    navigate('/auditpro/audits/new?dept=patient-care');
  };

  // Upcoming deadlines
  const upcomingDeadlines = mockAudits
    .filter(a => new Date(a.deadline) >= new Date())
    .sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime())
    .slice(0, 3);

  return (
    <DashboardLayout>
      <DashboardHeader
        title="Audit Management"
        subtitle="Patient Care audits, assessments, and compliance checks"
        actions={
          <>
            <Button variant="outline" onClick={handleExport} className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
            <Button variant="default" onClick={handleAddAudit} className="gap-2">
              <Plus className="h-4 w-4" />
              Add Audit
            </Button>
          </>
        }
      />

      {/* Upcoming Deadlines Widget */}
      {upcomingDeadlines.length > 0 && (
        <div className="dashboard-card p-4 mb-6">
          <h3 className="text-sm font-medium text-foreground mb-3">Upcoming Deadlines</h3>
          <div className="flex flex-wrap gap-4">
            {upcomingDeadlines.map((audit) => (
              <div 
                key={audit.id}
                className="flex items-center gap-3 px-3 py-2 rounded-lg bg-muted/50"
              >
                <Calendar className="h-4 w-4 text-warning" />
                <div>
                  <span className="text-sm font-medium">{audit.title}</span>
                  <span className="text-xs text-muted-foreground ml-2">
                    Due: {new Date(audit.deadline).toLocaleDateString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <DomainTabs
        tabs={tabCounts}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        filterSummary={activeTab !== 'all' ? [`Domain: ${auditTabs.find(t => t.id === activeTab)?.label}`] : undefined}
      >
        <MetricTiles metrics={metrics} />

        <DataTable
          columns={columns}
          data={filteredAudits}
          keyField="id"
          onExport={handleExport}
          actions={{
            view: (item) => toast.info(`Viewing ${item.id}`),
            edit: (item) => navigate(`/auditpro/audits/${item.id}`),
            openInApp: (item) => navigate(`/auditpro/audits/${item.id}?from=patient-care-dashboard`)
          }}
        />
      </DomainTabs>
    </DashboardLayout>
  );
}
