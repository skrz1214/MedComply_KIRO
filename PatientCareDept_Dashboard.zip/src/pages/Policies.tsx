import { DashboardLayout } from '@/components/dashboard/DashboardLayout';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { DataTable, StatusBadge } from '@/components/dashboard/DataTable';
import { mockPolicies } from '@/data/mockPatientCareData';
import { PolicyItem } from '@/types/patientCare';
import { Button } from '@/components/ui/button';
import { Plus, Download, Filter, Search } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { useState } from 'react';

export default function Policies() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const categories = [...new Set(mockPolicies.map(p => p.category))];

  const filteredPolicies = mockPolicies.filter(policy => {
    const matchesSearch = policy.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          policy.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || policy.status === statusFilter;
    const matchesCategory = categoryFilter === 'all' || policy.category === categoryFilter;
    return matchesSearch && matchesStatus && matchesCategory;
  });

  const statusStyles: Record<string, string> = {
    'Active': 'status-chip-success',
    'Under Review': 'status-chip-warning',
    'Pending Approval': 'status-chip-info',
    'Retired': 'status-chip-neutral'
  };

  const columns = [
    { key: 'name', label: 'Policy Name', sortable: true, className: 'max-w-md' },
    { 
      key: 'category', 
      label: 'Category', 
      sortable: true,
      render: (item: PolicyItem) => (
        <span className="text-sm px-2 py-0.5 rounded bg-muted text-muted-foreground">
          {item.category}
        </span>
      )
    },
    { 
      key: 'lastUpdate', 
      label: 'Last Update', 
      sortable: true, 
      render: (item: PolicyItem) => new Date(item.lastUpdate).toLocaleDateString() 
    },
    { 
      key: 'status', 
      label: 'Status',
      sortable: true,
      render: (item: PolicyItem) => (
        <span className={cn("status-chip", statusStyles[item.status])}>
          {item.status}
        </span>
      )
    },
    { 
      key: 'nextReviewDate', 
      label: 'Next Review', 
      sortable: true, 
      render: (item: PolicyItem) => {
        const reviewDate = new Date(item.nextReviewDate);
        const daysUntilReview = Math.ceil((reviewDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
        const isUpcoming = daysUntilReview <= 30;
        
        return (
          <span className={cn(isUpcoming && "text-warning font-medium")}>
            {reviewDate.toLocaleDateString()}
          </span>
        );
      }
    },
    { key: 'owner', label: 'Owner', sortable: true },
    { 
      key: 'version', 
      label: 'Version',
      render: (item: PolicyItem) => (
        <span className="text-xs font-mono bg-muted px-1.5 py-0.5 rounded">
          v{item.version}
        </span>
      )
    }
  ];

  const handleExport = () => {
    toast.success('Export started', { description: 'Your CSV file will download shortly.' });
  };

  const handleAddPolicy = () => {
    navigate('/documents/policies/new?dept=patient-care');
  };

  // Policy stats
  const stats = {
    total: mockPolicies.length,
    active: mockPolicies.filter(p => p.status === 'Active').length,
    underReview: mockPolicies.filter(p => p.status === 'Under Review').length,
    pendingApproval: mockPolicies.filter(p => p.status === 'Pending Approval').length,
    upcomingReviews: mockPolicies.filter(p => {
      const days = Math.ceil((new Date(p.nextReviewDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
      return days <= 30 && days > 0;
    }).length
  };

  return (
    <DashboardLayout>
      <DashboardHeader
        title="Policies & Procedures"
        subtitle="Patient Care policy documents and controlled procedures"
        showFilters={false}
        actions={
          <>
            <Button variant="outline" onClick={handleExport} className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
            <Button variant="default" onClick={handleAddPolicy} className="gap-2">
              <Plus className="h-4 w-4" />
              Add Policy
            </Button>
          </>
        }
      />

      {/* Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
        <div className="dashboard-card p-4">
          <span className="text-sm text-muted-foreground">Total Policies</span>
          <span className="text-2xl font-bold font-display block mt-1">{stats.total}</span>
        </div>
        <div className="dashboard-card p-4 border-success/30 bg-success/5">
          <span className="text-sm text-muted-foreground">Active</span>
          <span className="text-2xl font-bold font-display text-success block mt-1">{stats.active}</span>
        </div>
        <div className="dashboard-card p-4 border-warning/30 bg-warning/5">
          <span className="text-sm text-muted-foreground">Under Review</span>
          <span className="text-2xl font-bold font-display text-warning block mt-1">{stats.underReview}</span>
        </div>
        <div className="dashboard-card p-4 border-info/30 bg-info/5">
          <span className="text-sm text-muted-foreground">Pending Approval</span>
          <span className="text-2xl font-bold font-display text-info block mt-1">{stats.pendingApproval}</span>
        </div>
        <div className="dashboard-card p-4">
          <span className="text-sm text-muted-foreground">Reviews Due (30d)</span>
          <span className="text-2xl font-bold font-display block mt-1">{stats.upcomingReviews}</span>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-6">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search policies..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-9 w-full pl-10 pr-4 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="h-9 px-3 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
        >
          <option value="all">All Status</option>
          <option value="Active">Active</option>
          <option value="Under Review">Under Review</option>
          <option value="Pending Approval">Pending Approval</option>
          <option value="Retired">Retired</option>
        </select>

        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="h-9 px-3 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
        >
          <option value="all">All Categories</option>
          {categories.map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
      </div>

      <DataTable
        columns={columns}
        data={filteredPolicies}
        keyField="id"
        onExport={handleExport}
        emptyMessage="No policies match your filters"
        actions={{
          view: (item) => toast.info(`Viewing ${item.name}`),
          edit: (item) => navigate(`/documents/policies/${item.id}`),
          delete: (item) => toast.info(`Archive policy: ${item.name}`)
        }}
      />
    </DashboardLayout>
  );
}
