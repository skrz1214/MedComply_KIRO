import { useState } from 'react';
import { DashboardLayout } from '@/components/dashboard/DashboardLayout';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { DomainTabs, MetricTiles } from '@/components/dashboard/DomainTabs';
import { DataTable, StatusBadge, PriorityBadge, DomainTags } from '@/components/dashboard/DataTable';
import { mockEnforcements } from '@/data/mockPatientCareData';
import { EnforcementItem } from '@/types/patientCare';
import { Button } from '@/components/ui/button';
import { Plus, Download, Calendar, DollarSign, AlertTriangle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const enforcementTabs = [
  { id: 'all', label: 'All Patient Care' },
  { id: 'survey', label: 'Survey/Inspection Enforcement' },
  { id: 'rights', label: 'Patient Rights Enforcement' },
  { id: 'quality', label: 'Care Quality Enforcement' }
];

export default function EnforcementManagement() {
  const [activeTab, setActiveTab] = useState('all');
  const navigate = useNavigate();

  const filteredEnforcements = activeTab === 'all' 
    ? mockEnforcements 
    : mockEnforcements.filter(enf => 
        enf.domains.some(d => d.toLowerCase().includes(activeTab === 'survey' ? 'clinical' : activeTab))
      );

  const metrics = [
    { label: 'Total Cases', value: filteredEnforcements.length },
    { label: 'Active', value: filteredEnforcements.filter(e => e.status === 'In Progress' || e.status === 'Open').length, variant: 'warning' as const },
    { label: 'Resolved', value: filteredEnforcements.filter(e => e.status === 'Completed' || e.status === 'Closed').length, variant: 'success' as const },
    { label: 'Critical', value: filteredEnforcements.filter(e => e.priority === 'Critical').length, variant: 'error' as const }
  ];

  const tabCounts = enforcementTabs.map(tab => ({
    ...tab,
    count: tab.id === 'all' 
      ? mockEnforcements.length
      : mockEnforcements.filter(e => 
          e.domains.some(d => d.toLowerCase().includes(tab.id === 'survey' ? 'clinical' : tab.id))
        ).length
  }));

  const enforcementTypeStyles: Record<string, string> = {
    'Survey Action': 'bg-warning/10 text-warning',
    'Sanction': 'bg-destructive/10 text-destructive',
    'Civil Money Penalty': 'bg-destructive/10 text-destructive',
    'Termination Notice': 'bg-destructive/10 text-destructive',
    'State Action': 'bg-warning/10 text-warning'
  };

  const columns = [
    { key: 'id', label: 'Enforcement ID', sortable: true },
    { key: 'title', label: 'Title', sortable: true, className: 'max-w-xs' },
    { 
      key: 'enforcementType', 
      label: 'Type', 
      sortable: true,
      render: (item: EnforcementItem) => (
        <span className={cn("status-chip", enforcementTypeStyles[item.enforcementType])}>
          {item.enforcementType}
        </span>
      )
    },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
      render: (item: EnforcementItem) => <StatusBadge status={item.status} />
    },
    { 
      key: 'responseDeadline', 
      label: 'Response Due', 
      sortable: true,
      render: (item: EnforcementItem) => {
        const dueDate = new Date(item.responseDeadline);
        const daysUntilDue = Math.ceil((dueDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
        const isUrgent = daysUntilDue <= 14;
        
        return (
          <span className={cn(
            "flex items-center gap-1.5",
            isUrgent && "text-warning font-medium"
          )}>
            <Calendar className="h-3.5 w-3.5" />
            {dueDate.toLocaleDateString()}
            {isUrgent && daysUntilDue > 0 && (
              <span className="text-xs">({daysUntilDue}d)</span>
            )}
          </span>
        );
      }
    },
    { key: 'owner', label: 'Owner', sortable: true },
    { 
      key: 'priority', 
      label: 'Priority', 
      sortable: true,
      render: (item: EnforcementItem) => <PriorityBadge priority={item.priority} />
    },
    {
      key: 'domains',
      label: 'Domains',
      render: (item: EnforcementItem) => <DomainTags domains={item.domains} />
    },
    {
      key: 'financialImpact',
      label: 'Financial Impact',
      render: (item: EnforcementItem) => item.financialImpact ? (
        <span className="flex items-center gap-1 text-destructive font-medium">
          <DollarSign className="h-3.5 w-3.5" />
          {item.financialImpact.toLocaleString()}
        </span>
      ) : <span className="text-muted-foreground text-xs">-</span>
    }
  ];

  const handleExport = () => {
    toast.success('Export started', { description: 'Your CSV file will download shortly.' });
  };

  const handleAddEnforcement = () => {
    navigate('/enforcepoint/cases/new?dept=patient-care');
  };

  // Upcoming deadlines
  const upcomingDeadlines = mockEnforcements
    .filter(e => new Date(e.responseDeadline) >= new Date() && (e.status === 'Open' || e.status === 'In Progress'))
    .sort((a, b) => new Date(a.responseDeadline).getTime() - new Date(b.responseDeadline).getTime())
    .slice(0, 3);

  return (
    <DashboardLayout>
      <DashboardHeader
        title="Enforcement Management"
        subtitle="Survey actions, sanctions, and regulatory enforcement cases"
        actions={
          <>
            <Button variant="outline" onClick={handleExport} className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
            <Button variant="default" onClick={handleAddEnforcement} className="gap-2">
              <Plus className="h-4 w-4" />
              Add Case
            </Button>
          </>
        }
      />

      {/* Upcoming Deadlines Alert */}
      {upcomingDeadlines.length > 0 && (
        <div className="dashboard-card p-4 mb-6 border-warning/30 bg-warning/5">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="h-5 w-5 text-warning" />
            <h3 className="font-medium text-foreground">Upcoming Response Deadlines</h3>
          </div>
          <div className="space-y-2">
            {upcomingDeadlines.map((enf) => {
              const daysUntilDue = Math.ceil((new Date(enf.responseDeadline).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
              
              return (
                <div 
                  key={enf.id}
                  className="flex items-center justify-between px-3 py-2 rounded-lg bg-card border border-border"
                >
                  <div className="flex items-center gap-3">
                    <PriorityBadge priority={enf.priority} />
                    <span className="text-sm font-medium">{enf.title}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-sm text-muted-foreground">
                      {enf.agency}
                    </span>
                    <span className={cn(
                      "text-sm font-medium",
                      daysUntilDue <= 7 ? "text-destructive" : daysUntilDue <= 14 ? "text-warning" : "text-muted-foreground"
                    )}>
                      {daysUntilDue} days left
                    </span>
                    <Button variant="outline" size="sm" onClick={() => navigate(`/enforcepoint/cases/${enf.id}`)}>
                      View
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <DomainTabs
        tabs={tabCounts}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        filterSummary={activeTab !== 'all' ? [`Category: ${enforcementTabs.find(t => t.id === activeTab)?.label}`] : undefined}
      >
        <MetricTiles metrics={metrics} />

        <DataTable
          columns={columns}
          data={filteredEnforcements}
          keyField="id"
          onExport={handleExport}
          actions={{
            view: (item) => toast.info(`Viewing ${item.id}`),
            edit: (item) => navigate(`/enforcepoint/cases/${item.id}`),
            openInApp: (item) => navigate(`/enforcepoint/cases/${item.id}?from=patient-care-dashboard`)
          }}
        />
      </DomainTabs>
    </DashboardLayout>
  );
}
