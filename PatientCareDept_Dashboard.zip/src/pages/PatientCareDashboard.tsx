import { useState } from 'react';
import { DashboardLayout } from '@/components/dashboard/DashboardLayout';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { QuickStatsList } from '@/components/dashboard/StatCards';
import { ActionCenter, ReviewQueue } from '@/components/dashboard/ActionCenter';
import { MicroAppTiles } from '@/components/dashboard/MicroAppTiles';
import { KPIPanel } from '@/components/dashboard/KPIPanel';
import { KPIData } from '@/components/dashboard/KPIFormDialog';
import { 
  mockQuickStats, 
  mockKPIs, 
  mockActionItems, 
  mockReviewItems
} from '@/data/mockPatientCareData';

// Transform initial KPIs to include formula fields
const initialKPIs: KPIData[] = mockKPIs.slice(0, 4).map(kpi => ({
  id: kpi.id,
  name: kpi.name,
  value: kpi.value,
  target: kpi.target,
  unit: kpi.unit,
  trend: kpi.trend,
  formula: kpi.formula,
  numerator: kpi.name.includes('Compliance') ? 'Compliant Items' : 
             kpi.name.includes('Time') ? 'Days from open to close' :
             kpi.name.includes('Checklist') ? 'Completed Checklists' :
             kpi.name.includes('Response') ? 'On-time Responses' : 'Metric Value',
  denominator: kpi.name.includes('Compliance') ? 'Total Items' :
               kpi.name.includes('Time') ? 'Critical items count' :
               kpi.name.includes('Checklist') ? 'Required Checklists' :
               kpi.name.includes('Response') ? 'Total Grievances' : 'Total Count',
  description: `Measures the ${kpi.name.toLowerCase()} performance metric.`
}));

export default function PatientCareDashboard() {
  const [kpis, setKPIs] = useState<KPIData[]>(initialKPIs);

  const handleAddAction = () => {
    console.log('Add action clicked');
  };

  // Transform quick stats for the list format
  const quickStatsData = [
    { label: 'Total', value: mockQuickStats[0].value, change: mockQuickStats[0].change, changeType: mockQuickStats[0].changeType },
    { label: 'Completed', value: mockQuickStats[1].value, change: mockQuickStats[1].change, changeType: mockQuickStats[1].changeType },
    { label: 'Pending', value: mockQuickStats[2].value, change: mockQuickStats[2].change, changeType: mockQuickStats[2].changeType },
    { label: 'Overdue', value: mockQuickStats[3].value, change: mockQuickStats[3].change, changeType: mockQuickStats[3].changeType }
  ];

  return (
    <DashboardLayout>
      <DashboardHeader
        title="Patient Care Compliance Master Dashboard"
        subtitle="Patient Care Compliance Dashboard"
      />

      {/* Main Grid Layout - Match reference: left 2/3, right 1/3 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column - Main content */}
        <div className="lg:col-span-8 space-y-6">
          {/* Action Center */}
          <ActionCenter items={mockActionItems} onAddAction={handleAddAction} />

          {/* Review Queue */}
          <ReviewQueue items={mockReviewItems} />
        </div>

        {/* Right Column - Stats and KPIs */}
        <div className="lg:col-span-4 space-y-6">
          {/* Quick Stats */}
          <QuickStatsList stats={quickStatsData} />

          {/* Quality KPIs with CRUD */}
          <KPIPanel kpis={kpis} onKPIsChange={setKPIs} />
        </div>
      </div>

      {/* Micro Apps Section */}
      <div className="mt-8">
        <MicroAppTiles />
      </div>
    </DashboardLayout>
  );
}
