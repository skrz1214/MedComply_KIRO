import { useState } from 'react';
import { DashboardLayout } from '@/components/dashboard/DashboardLayout';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { DomainTabs, MetricTiles } from '@/components/dashboard/DomainTabs';
import { DataTable, StatusBadge, PriorityBadge, DomainTags } from '@/components/dashboard/DataTable';
import { mockCompliance, mockCAPAs, mockCitations, mockPolicies } from '@/data/mockPatientCareData';
import { ComplianceItem, CAPAItem, CitationItem, PolicyItem } from '@/types/patientCare';
import { Button } from '@/components/ui/button';
import { Plus, Download, FileText, AlertTriangle, FileCheck, FileWarning, Eye } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

// Sub-tab definitions
const subTabs = [
  { id: 'compliance', label: 'Compliance Items', icon: FileCheck },
  { id: 'capa', label: 'CAPA', icon: AlertTriangle },
  { id: 'citations', label: 'Citations', icon: FileWarning },
  { id: 'policies', label: 'Policies/Docs', icon: FileText },
  { id: 'tracker', label: 'Patient Tracker', icon: Eye }
];

const complianceDomainTabs = [
  { id: 'all', label: 'All Patient Care' },
  { id: 'general', label: 'Patient Care Compliance' },
  { id: 'rights', label: 'Patient Rights & Grievances' },
  { id: 'clinical', label: 'Clinical Care Delivery' },
  { id: 'careplans', label: 'Care Plans & Documentation' },
  { id: 'incident', label: 'Incident / Adverse Event' },
  { id: 'quality', label: 'Quality Measures / Outcomes' },
  { id: 'infection', label: 'Infection Prevention' }
];

const capaDomainTabs = [
  { id: 'all', label: 'All Patient Care' },
  { id: 'clinical', label: 'Clinical Care Delivery' },
  { id: 'incident', label: 'Incident / Adverse Event' },
  { id: 'careplans', label: 'Care Plans & Documentation' }
];

const citationDomainTabs = [
  { id: 'all', label: 'All Patient Care' },
  { id: 'survey', label: 'Survey Findings' },
  { id: 'rights', label: 'Patient Rights & Grievances' },
  { id: 'documentation', label: 'Care Documentation Deficiencies' }
];

export default function ComplianceTracking() {
  const [activeSubTab, setActiveSubTab] = useState('compliance');
  const [activeDomainTab, setActiveDomainTab] = useState('all');
  const navigate = useNavigate();

  const handleExport = () => {
    toast.success('Export started', { description: 'Your CSV file will download shortly.' });
  };

  const renderComplianceItems = () => {
    const filtered = activeDomainTab === 'all'
      ? mockCompliance
      : mockCompliance.filter(c => 
          c.domains.some(d => d.toLowerCase().includes(activeDomainTab))
        );

    const metrics = [
      { label: 'Total Items', value: filtered.length },
      { label: 'Pending Review', value: filtered.filter(c => c.status === 'Pending Review').length, variant: 'warning' as const },
      { label: 'Completed', value: filtered.filter(c => c.status === 'Completed').length, variant: 'success' as const },
      { label: 'Overdue', value: filtered.filter(c => c.status === 'Overdue').length, variant: 'error' as const }
    ];

    const columns = [
      { key: 'id', label: 'Compliance ID', sortable: true },
      { key: 'title', label: 'Description', sortable: true, className: 'max-w-xs' },
      { key: 'status', label: 'Status', sortable: true, render: (item: ComplianceItem) => <StatusBadge status={item.status} /> },
      { key: 'owner', label: 'Owner', sortable: true },
      { key: 'dueDate', label: 'Due Date', sortable: true, render: (item: ComplianceItem) => new Date(item.dueDate).toLocaleDateString() },
      { key: 'domains', label: 'Domains', render: (item: ComplianceItem) => <DomainTags domains={item.domains} /> },
      { 
        key: 'capaRequired', 
        label: 'CAPA', 
        render: (item: ComplianceItem) => item.capaRequired 
          ? <span className="status-chip status-chip-warning">Required</span>
          : <span className="text-muted-foreground text-xs">-</span>
      }
    ];

    const tabCounts = complianceDomainTabs.map(tab => ({
      ...tab,
      count: tab.id === 'all' ? mockCompliance.length : mockCompliance.filter(c => 
        c.domains.some(d => d.toLowerCase().includes(tab.id))
      ).length
    }));

    return (
      <DomainTabs
        tabs={tabCounts}
        activeTab={activeDomainTab}
        onTabChange={setActiveDomainTab}
        filterSummary={activeDomainTab !== 'all' ? [`Domain: ${complianceDomainTabs.find(t => t.id === activeDomainTab)?.label}`] : undefined}
      >
        <MetricTiles metrics={metrics} />
        <DataTable
          columns={columns}
          data={filtered}
          keyField="id"
          onExport={handleExport}
          actions={{
            view: (item) => toast.info(`Viewing ${item.id}`),
            edit: (item) => navigate(`/complianceconnect/issues/${item.id}`),
            openInApp: (item) => navigate(`/complianceconnect/issues/${item.id}?from=patient-care-dashboard`)
          }}
        />
      </DomainTabs>
    );
  };

  const renderCAPAItems = () => {
    const filtered = activeDomainTab === 'all'
      ? mockCAPAs
      : mockCAPAs.filter(c => c.domains.some(d => d.toLowerCase().includes(activeDomainTab)));

    const columns = [
      { key: 'id', label: 'CAPA ID', sortable: true },
      { key: 'title', label: 'Title', sortable: true, className: 'max-w-xs' },
      { key: 'status', label: 'Status', sortable: true, render: (item: CAPAItem) => <StatusBadge status={item.status} /> },
      { key: 'priority', label: 'Priority', sortable: true, render: (item: CAPAItem) => <PriorityBadge priority={item.priority} /> },
      { key: 'owner', label: 'Owner', sortable: true },
      { key: 'dueDate', label: 'Due Date', sortable: true, render: (item: CAPAItem) => new Date(item.dueDate).toLocaleDateString() },
      { key: 'linkedComplianceId', label: 'Linked Issue', sortable: true }
    ];

    const tabCounts = capaDomainTabs.map(tab => ({
      ...tab,
      count: tab.id === 'all' ? mockCAPAs.length : mockCAPAs.filter(c => 
        c.domains.some(d => d.toLowerCase().includes(tab.id))
      ).length
    }));

    return (
      <DomainTabs
        tabs={tabCounts}
        activeTab={activeDomainTab}
        onTabChange={setActiveDomainTab}
      >
        <DataTable
          columns={columns}
          data={filtered}
          keyField="id"
          onExport={handleExport}
          actions={{
            view: (item) => toast.info(`Viewing ${item.id}`),
            edit: (item) => navigate(`/actionguard/capas/${item.id}`),
            openInApp: (item) => navigate(`/actionguard/capas/${item.id}?from=patient-care-dashboard`)
          }}
        />
      </DomainTabs>
    );
  };

  const renderCitations = () => {
    const columns = [
      { key: 'id', label: 'Citation ID', sortable: true },
      { key: 'title', label: 'Title', sortable: true, className: 'max-w-xs' },
      { key: 'citationType', label: 'Type', sortable: true },
      { key: 'status', label: 'Status', sortable: true, render: (item: CitationItem) => <StatusBadge status={item.status} /> },
      { key: 'pocStatus', label: 'POC Status', render: (item: CitationItem) => (
        <span className={cn(
          "status-chip",
          item.pocStatus === 'Accepted' ? 'status-chip-success' :
          item.pocStatus === 'Submitted' ? 'status-chip-info' :
          item.pocStatus === 'Rejected' ? 'status-chip-error' : 'status-chip-neutral'
        )}>{item.pocStatus}</span>
      )},
      { key: 'owner', label: 'Owner', sortable: true },
      { key: 'pocDueDate', label: 'POC Due', sortable: true, render: (item: CitationItem) => new Date(item.pocDueDate).toLocaleDateString() }
    ];

    return (
      <DomainTabs
        tabs={citationDomainTabs.map(tab => ({ ...tab, count: mockCitations.length }))}
        activeTab={activeDomainTab}
        onTabChange={setActiveDomainTab}
      >
        <DataTable
          columns={columns}
          data={mockCitations}
          keyField="id"
          onExport={handleExport}
          actions={{
            view: (item) => toast.info(`Viewing ${item.id}`),
            edit: (item) => navigate(`/citapro/citations/${item.id}`)
          }}
        />
      </DomainTabs>
    );
  };

  const renderPolicies = () => {
    const columns = [
      { key: 'name', label: 'Policy Name', sortable: true },
      { key: 'category', label: 'Category', sortable: true },
      { key: 'lastUpdate', label: 'Last Update', sortable: true, render: (item: PolicyItem) => new Date(item.lastUpdate).toLocaleDateString() },
      { key: 'status', label: 'Status', render: (item: PolicyItem) => (
        <span className={cn(
          "status-chip",
          item.status === 'Active' ? 'status-chip-success' :
          item.status === 'Under Review' ? 'status-chip-warning' :
          item.status === 'Pending Approval' ? 'status-chip-info' : 'status-chip-neutral'
        )}>{item.status}</span>
      )},
      { key: 'nextReviewDate', label: 'Next Review', sortable: true, render: (item: PolicyItem) => new Date(item.nextReviewDate).toLocaleDateString() },
      { key: 'owner', label: 'Owner', sortable: true },
      { key: 'version', label: 'Version' }
    ];

    return (
      <DataTable
        columns={columns}
        data={mockPolicies}
        keyField="id"
        onExport={handleExport}
        actions={{
          view: (item) => toast.info(`Viewing ${item.name}`),
          edit: (item) => navigate(`/documents/policies/${item.id}`)
        }}
      />
    );
  };

  const renderPatientTracker = () => {
    // Patient Tracker is a filtered view of compliance items
    const trackerItems = mockCompliance.filter(c => c.isPatientTracker);
    
    const columns = [
      { key: 'title', label: 'Observation/Concern', sortable: true },
      { key: 'id', label: 'Patient ID (Masked)', render: () => '***-***-' + Math.random().toString().slice(2, 6) },
      { key: 'facility', label: 'Location/Unit', render: () => 'Unit 4A' },
      { key: 'createdDate', label: 'Date', sortable: true, render: (item: ComplianceItem) => new Date(item.createdDate).toLocaleDateString() },
      { key: 'priority', label: 'Severity', render: (item: ComplianceItem) => <PriorityBadge priority={item.priority} /> },
      { key: 'status', label: 'Status', render: (item: ComplianceItem) => <StatusBadge status={item.status} /> },
      { key: 'owner', label: 'Owner', sortable: true }
    ];

    return (
      <div>
        <div className="mb-4 p-4 bg-muted/50 rounded-lg border border-border">
          <p className="text-sm text-muted-foreground">
            <strong>Patient Tracker</strong> is a filtered view of ComplianceConnect items tagged as patient observations. 
            PHI is masked by default.
          </p>
        </div>
        <DataTable
          columns={columns}
          data={mockCompliance.slice(0, 3)} // Using sample data
          keyField="id"
          emptyMessage="No patient tracker items found"
          actions={{
            view: (item) => toast.info(`Viewing ${item.id}`),
            edit: (item) => navigate(`/complianceconnect/issues/${item.id}?tracker=true`)
          }}
        />
      </div>
    );
  };

  const getAddButtonConfig = () => {
    switch (activeSubTab) {
      case 'compliance':
        return { label: 'Add Compliance Item', path: '/complianceconnect/issues/new?category=patient-care' };
      case 'capa':
        return { label: 'Add CAPA', path: '/actionguard/capas/new?dept=patient-care' };
      case 'citations':
        return { label: 'Add Citation', path: '/citapro/citations/new?dept=patient-care' };
      case 'policies':
        return { label: 'Add Policy', path: '/documents/policies/new?dept=patient-care' };
      default:
        return null;
    }
  };

  const addButton = getAddButtonConfig();

  return (
    <DashboardLayout>
      <DashboardHeader
        title="Compliance Tracking"
        subtitle="Patient Care compliance items, CAPA, citations, policies, and patient tracking"
        actions={
          <>
            <Button variant="outline" onClick={handleExport} className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
            {addButton && (
              <Button variant="default" onClick={() => navigate(addButton.path)} className="gap-2">
                <Plus className="h-4 w-4" />
                {addButton.label}
              </Button>
            )}
          </>
        }
      />

      {/* Sub-tabs */}
      <div className="flex gap-2 mb-6 border-b border-border pb-px overflow-x-auto">
        {subTabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveSubTab(tab.id);
                setActiveDomainTab('all');
              }}
              className={cn(
                "flex items-center gap-2 px-4 py-2 text-sm font-medium border-b-2 transition-colors whitespace-nowrap",
                activeSubTab === tab.id 
                  ? "border-primary text-primary" 
                  : "border-transparent text-muted-foreground hover:text-foreground"
              )}
            >
              <Icon className="h-4 w-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Content based on active sub-tab */}
      {activeSubTab === 'compliance' && renderComplianceItems()}
      {activeSubTab === 'capa' && renderCAPAItems()}
      {activeSubTab === 'citations' && renderCitations()}
      {activeSubTab === 'policies' && renderPolicies()}
      {activeSubTab === 'tracker' && renderPatientTracker()}
    </DashboardLayout>
  );
}
