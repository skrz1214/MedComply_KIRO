import { useState } from 'react';
import { DashboardLayout } from '@/components/dashboard/DashboardLayout';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { DomainTabs, MetricTiles } from '@/components/dashboard/DomainTabs';
import { DataTable, StatusBadge, PriorityBadge, DomainTags } from '@/components/dashboard/DataTable';
import { mockFeedback } from '@/data/mockPatientCareData';
import { FeedbackItem } from '@/types/patientCare';
import { Button } from '@/components/ui/button';
import { Plus, Download, Clock, MessageSquare } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const feedbackTabs = [
  { id: 'all', label: 'All Patient Care' },
  { id: 'complaints', label: 'Patient Complaints / Grievances' },
  { id: 'experience', label: 'Care Experience Feedback' },
  { id: 'safety', label: 'Safety Concerns' }
];

export default function FeedbackManagement() {
  const [activeTab, setActiveTab] = useState('all');
  const navigate = useNavigate();

  const filteredFeedback = activeTab === 'all' 
    ? mockFeedback 
    : mockFeedback.filter(fb => {
        if (activeTab === 'complaints') return fb.feedbackType === 'Complaint' || fb.feedbackType === 'Grievance';
        if (activeTab === 'experience') return fb.feedbackType === 'Suggestion' || fb.feedbackType === 'Compliment';
        if (activeTab === 'safety') return fb.feedbackType === 'Safety Concern';
        return true;
      });

  const metrics = [
    { label: 'Total Feedback', value: filteredFeedback.length },
    { label: 'Open', value: filteredFeedback.filter(f => f.status === 'Open').length, variant: 'warning' as const },
    { label: 'Resolved', value: filteredFeedback.filter(f => f.status === 'Completed' || f.status === 'Closed').length, variant: 'success' as const },
    { label: 'SLA At Risk', value: filteredFeedback.filter(f => new Date(f.slaDue) <= new Date()).length, variant: 'error' as const }
  ];

  const tabCounts = feedbackTabs.map(tab => ({
    ...tab,
    count: tab.id === 'all' 
      ? mockFeedback.length
      : mockFeedback.filter(fb => {
          if (tab.id === 'complaints') return fb.feedbackType === 'Complaint' || fb.feedbackType === 'Grievance';
          if (tab.id === 'experience') return fb.feedbackType === 'Suggestion' || fb.feedbackType === 'Compliment';
          if (tab.id === 'safety') return fb.feedbackType === 'Safety Concern';
          return true;
        }).length
  }));

  const feedbackTypeStyles: Record<string, string> = {
    'Complaint': 'bg-warning/10 text-warning',
    'Grievance': 'bg-destructive/10 text-destructive',
    'Suggestion': 'bg-info/10 text-info',
    'Compliment': 'bg-success/10 text-success',
    'Safety Concern': 'bg-destructive/10 text-destructive'
  };

  const columns = [
    { key: 'id', label: 'Feedback ID', sortable: true },
    { 
      key: 'feedbackType', 
      label: 'Type', 
      sortable: true,
      render: (item: FeedbackItem) => (
        <span className={cn("status-chip", feedbackTypeStyles[item.feedbackType])}>
          {item.feedbackType}
        </span>
      )
    },
    { key: 'title', label: 'Description', sortable: true, className: 'max-w-xs' },
    {
      key: 'source',
      label: 'Source',
      render: (item: FeedbackItem) => (
        <span className="text-sm text-muted-foreground flex items-center gap-1.5">
          <MessageSquare className="h-3.5 w-3.5" />
          {item.source}
        </span>
      )
    },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
      render: (item: FeedbackItem) => <StatusBadge status={item.status} />
    },
    { key: 'owner', label: 'Owner', sortable: true },
    { 
      key: 'slaDue', 
      label: 'SLA Due', 
      sortable: true,
      render: (item: FeedbackItem) => {
        const dueDate = new Date(item.slaDue);
        const isOverdue = dueDate < new Date() && item.status !== 'Completed' && item.status !== 'Closed';
        return (
          <span className={cn(
            "flex items-center gap-1.5",
            isOverdue && "text-destructive font-medium"
          )}>
            <Clock className="h-3.5 w-3.5" />
            {dueDate.toLocaleDateString()}
          </span>
        );
      }
    },
    {
      key: 'domains',
      label: 'Domains',
      render: (item: FeedbackItem) => <DomainTags domains={item.domains} />
    }
  ];

  const handleExport = () => {
    toast.success('Export started', { description: 'Your CSV file will download shortly.' });
  };

  const handleAddFeedback = () => {
    navigate('/feedbackhub/items/new?dept=patient-care');
  };

  return (
    <DashboardLayout>
      <DashboardHeader
        title="Feedback Management"
        subtitle="Patient complaints, grievances, experience feedback, and safety concerns"
        actions={
          <>
            <Button variant="outline" onClick={handleExport} className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
            <Button variant="default" onClick={handleAddFeedback} className="gap-2">
              <Plus className="h-4 w-4" />
              Add Feedback
            </Button>
          </>
        }
      />

      {/* High-Severity Alert */}
      {mockFeedback.some(f => f.priority === 'Critical' && f.status === 'Open') && (
        <div className="mb-6 p-4 bg-destructive/10 border border-destructive/30 rounded-lg flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-destructive/20 flex items-center justify-center">
            <MessageSquare className="h-5 w-5 text-destructive" />
          </div>
          <div>
            <h4 className="font-medium text-foreground">Critical Feedback Requires Attention</h4>
            <p className="text-sm text-muted-foreground">
              {mockFeedback.filter(f => f.priority === 'Critical' && f.status === 'Open').length} critical item(s) need immediate response
            </p>
          </div>
          <Button variant="destructive" size="sm" className="ml-auto">
            Review Now
          </Button>
        </div>
      )}

      <DomainTabs
        tabs={tabCounts}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        filterSummary={activeTab !== 'all' ? [`Category: ${feedbackTabs.find(t => t.id === activeTab)?.label}`] : undefined}
      >
        <MetricTiles metrics={metrics} />

        <DataTable
          columns={columns}
          data={filteredFeedback}
          keyField="id"
          onExport={handleExport}
          actions={{
            view: (item) => toast.info(`Viewing ${item.id}`),
            edit: (item) => navigate(`/feedbackhub/items/${item.id}`),
            openInApp: (item) => navigate(`/feedbackhub/items/${item.id}?from=patient-care-dashboard`)
          }}
        />
      </DomainTabs>
    </DashboardLayout>
  );
}
