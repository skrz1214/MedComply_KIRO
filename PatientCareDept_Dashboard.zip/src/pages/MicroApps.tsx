import { DashboardLayout } from '@/components/dashboard/DashboardLayout';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { 
  FileCheck2, 
  MessageSquare, 
  ShieldAlert, 
  ClipboardCheck, 
  Gavel,
  FileWarning,
  ArrowRight,
  ExternalLink,
  Zap
} from 'lucide-react';

interface MicroApp {
  id: string;
  name: string;
  description: string;
  longDescription: string;
  icon: React.ElementType;
  path: string;
  color: string;
  features: string[];
  itemCount: number;
}

const microApps: MicroApp[] = [
  {
    id: 'complianceconnect',
    name: 'ComplianceConnect',
    description: 'Compliance tracking & issues',
    longDescription: 'Central hub for tracking compliance items, patient care issues, and regulatory requirements across all domains.',
    icon: FileCheck2,
    path: '/complianceconnect?from=patient-care-dashboard&dept=patient-care',
    color: 'bg-green-500',
    features: ['Issue tracking', 'Evidence management', 'Due date monitoring', 'Domain tagging'],
    itemCount: 12
  },
  {
    id: 'feedbackhub',
    name: 'FeedbackHub',
    description: 'Patient feedback & grievances',
    longDescription: 'Manage patient complaints, grievances, suggestions, and feedback with SLA tracking and resolution workflows.',
    icon: MessageSquare,
    path: '/feedbackhub?from=patient-care-dashboard&dept=patient-care',
    color: 'bg-purple-500',
    features: ['Grievance management', 'SLA tracking', 'Auto-escalation', 'Resolution workflows'],
    itemCount: 8
  },
  {
    id: 'riskguard',
    name: 'RiskGuard',
    description: 'Risk management & mitigation',
    longDescription: 'Identify, assess, and mitigate patient care risks with preventive and detective controls tracking.',
    icon: ShieldAlert,
    path: '/riskguard?from=patient-care-dashboard&dept=patient-care',
    color: 'bg-orange-500',
    features: ['Risk assessment', 'Control tracking', 'Mitigation plans', 'Risk scoring'],
    itemCount: 5
  },
  {
    id: 'auditpro',
    name: 'AuditPro',
    description: 'Audits & assessments',
    longDescription: 'Plan and execute internal audits, mock surveys, and compliance assessments with findings management.',
    icon: ClipboardCheck,
    path: '/auditpro?from=patient-care-dashboard&dept=patient-care',
    color: 'bg-blue-500',
    features: ['Audit planning', 'Finding tracking', 'Checklist management', 'Mock surveys'],
    itemCount: 3
  },
  {
    id: 'enforcepoint',
    name: 'EnforcePoint',
    description: 'Enforcement & actions',
    longDescription: 'Track regulatory enforcement actions, sanctions, and required responses with deadline management.',
    icon: Gavel,
    path: '/enforcepoint?from=patient-care-dashboard&dept=patient-care',
    color: 'bg-red-500',
    features: ['Enforcement tracking', 'Response management', 'Deadline alerts', 'Financial impact'],
    itemCount: 2
  },
  {
    id: 'citapro',
    name: 'CitaPro',
    description: 'Citations & POC management',
    longDescription: 'Manage survey citations, deficiencies, and Plans of Correction with regulatory agency submissions.',
    icon: FileWarning,
    path: '/citapro?from=patient-care-dashboard&dept=patient-care',
    color: 'bg-amber-500',
    features: ['Citation tracking', 'POC drafting', 'Submission tracking', 'Compliance verification'],
    itemCount: 4
  }
];

export default function MicroApps() {
  return (
    <DashboardLayout>
      <DashboardHeader
        title="Micro Apps Quick Access"
        subtitle="Direct access to compliance management applications with Patient Care context"
        showFilters={false}
      />

      {/* Context Banner */}
      <div className="dashboard-card p-4 mb-6 flex items-center gap-3 bg-accent/5 border-accent/30">
        <Zap className="h-5 w-5 text-accent" />
        <p className="text-sm text-foreground">
          All links preserve your Patient Care context: <code className="text-xs bg-muted px-1.5 py-0.5 rounded">from=patient-care-dashboard&dept=patient-care</code>
        </p>
      </div>

      {/* Apps Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {microApps.map((app) => {
          const Icon = app.icon;
          
          return (
            <Link
              key={app.id}
              to={app.path}
              className="dashboard-card p-6 group hover:shadow-lg transition-all"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className={cn(
                  "w-12 h-12 rounded-lg flex items-center justify-center",
                  app.color
                )}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                
                {app.itemCount > 0 && (
                  <span className="px-2 py-1 rounded-full bg-primary text-primary-foreground text-xs font-medium">
                    {app.itemCount} items
                  </span>
                )}
              </div>

              {/* Content */}
              <h3 className="text-lg font-semibold font-display text-foreground mb-2">
                {app.name}
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                {app.longDescription}
              </p>

              {/* Features */}
              <div className="flex flex-wrap gap-2 mb-4">
                {app.features.map((feature, index) => (
                  <span 
                    key={index}
                    className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground"
                  >
                    {feature}
                  </span>
                ))}
              </div>

              {/* Footer */}
              <div className="flex items-center gap-2 text-sm font-medium text-primary group-hover:text-primary/80 transition-colors">
                Open {app.name}
                <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          );
        })}
      </div>

      {/* External Links */}
      <div className="mt-8">
        <h2 className="text-lg font-semibold font-display text-foreground mb-4">Additional Resources</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <a 
            href="#" 
            className="dashboard-card p-4 flex items-center justify-between group hover:border-primary/30"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                <FileCheck2 className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <h4 className="font-medium text-foreground">ActionGuard (CAPA)</h4>
                <p className="text-xs text-muted-foreground">Corrective and preventive actions</p>
              </div>
            </div>
            <ExternalLink className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
          </a>

          <a 
            href="#" 
            className="dashboard-card p-4 flex items-center justify-between group hover:border-primary/30"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                <FileCheck2 className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <h4 className="font-medium text-foreground">Documents Module</h4>
                <p className="text-xs text-muted-foreground">Controlled policies and procedures</p>
              </div>
            </div>
            <ExternalLink className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
          </a>
        </div>
      </div>
    </DashboardLayout>
  );
}
