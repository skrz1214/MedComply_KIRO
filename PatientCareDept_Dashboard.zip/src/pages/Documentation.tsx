import { useState } from 'react';
import { DashboardLayout } from '@/components/dashboard/DashboardLayout';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { Button } from '@/components/ui/button';
import { Download, FileText, Code, TestTube, ClipboardCheck, ChevronDown, ChevronUp, Terminal } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import jsPDF from 'jspdf';

interface DocumentSection {
  id: string;
  title: string;
  icon: typeof FileText;
  color: string;
  content: DocumentContent;
}

interface DocumentContent {
  title: string;
  version: string;
  lastUpdated: string;
  sections: { heading: string; content: string[] }[];
}

const prdContent: DocumentContent = {
  title: 'Product Requirements Document (PRD)',
  version: '1.0',
  lastUpdated: '2025-12-25',
  sections: [
    {
      heading: '1. Executive Summary',
      content: [
        'The Patient Care Compliance Dashboard is a comprehensive management system designed to streamline compliance operations, risk management, audit tracking, and regulatory adherence for healthcare organizations.',
        'This system enables real-time monitoring of key performance indicators, automated workflow management, and centralized documentation control.',
      ],
    },
    {
      heading: '2. Product Vision',
      content: [
        'To provide healthcare compliance teams with an intuitive, integrated platform that reduces manual effort, improves regulatory adherence, and enhances patient care quality through data-driven insights.',
      ],
    },
    {
      heading: '3. Target Users',
      content: [
        '• Admin/Compliance Head: Full system access, configuration, and oversight',
        '• Department Head (Patient Care): Department-level management and reporting',
        '• Staff (Patient Care): Day-to-day task execution and data entry',
      ],
    },
    {
      heading: '4. Core Features',
      content: [
        '4.1 Dashboard Overview - Real-time KPIs, action items, and compliance status',
        '4.2 Risk Management - Risk register, assessment workflows, and mitigation tracking',
        '4.3 Audit Management - Audit scheduling, findings tracking, and corrective actions',
        '4.4 Compliance Tracking - Regulatory requirements monitoring and evidence collection',
        '4.5 Feedback Management - Stakeholder feedback collection and analysis',
        '4.6 Enforcement Management - Policy enforcement and violation tracking',
        '4.7 Organization Chart - Team structure and role management',
        '4.8 Policies & Procedures - Document control and version management',
      ],
    },
    {
      heading: '5. Success Metrics',
      content: [
        '• 95% compliance rate across all regulatory requirements',
        '• 50% reduction in manual compliance reporting time',
        '• 100% audit trail coverage for all compliance activities',
        '• <24 hour response time for critical compliance issues',
      ],
    },
    {
      heading: '6. Technical Requirements',
      content: [
        '• Web-based responsive application (React/TypeScript)',
        '• Role-based access control (RBAC)',
        '• Real-time data synchronization',
        '• Secure data encryption (AES-256)',
        '• HIPAA-compliant infrastructure',
      ],
    },
  ],
};

const tddContent: DocumentContent = {
  title: 'Technical Design Document (TDD)',
  version: '1.0',
  lastUpdated: '2025-12-25',
  sections: [
    {
      heading: '1. System Architecture',
      content: [
        'The system follows a modern single-page application (SPA) architecture with the following components:',
        '• Frontend: React 18 with TypeScript, Vite build system',
        '• Styling: Tailwind CSS with custom design system tokens',
        '• State Management: React Query for server state, React Context for UI state',
        '• Routing: React Router v6 for client-side navigation',
      ],
    },
    {
      heading: '2. Component Architecture',
      content: [
        '2.1 Layout Components',
        '  - DashboardLayout: Main application shell with sidebar and header',
        '  - DashboardHeader: Page-level header with actions and filters',
        '',
        '2.2 Feature Components',
        '  - KPIPanel: Key performance indicator display with CRUD operations',
        '  - DataTable: Reusable table with sorting, filtering, and actions',
        '  - OrgChart: Hierarchical organization visualization',
        '  - DomainTabs: Tab-based domain filtering system',
      ],
    },
    {
      heading: '3. Data Models',
      content: [
        'interface RiskItem {',
        '  id: string;',
        '  title: string;',
        '  riskLevel: "Critical" | "High" | "Medium" | "Low";',
        '  status: string;',
        '  owner: string;',
        '  dueDate: string;',
        '  domains: string[];',
        '}',
        '',
        'interface KPI {',
        '  id: string;',
        '  name: string;',
        '  value: number;',
        '  target: number;',
        '  numerator: string;',
        '  denominator: string;',
        '  formula: string;',
        '}',
      ],
    },
    {
      heading: '4. Security Design',
      content: [
        '4.1 Authentication: Session-based with secure token storage',
        '4.2 Authorization: Role-based access control with three tiers:',
        '  - Admin: Full system access',
        '  - Department Head: Department-scoped access',
        '  - Staff: Task-level access',
        '4.3 Data Protection: All sensitive data encrypted at rest and in transit',
      ],
    },
    {
      heading: '5. API Design',
      content: [
        'RESTful API endpoints following standard conventions:',
        '• GET /api/risks - Retrieve risk register',
        '• POST /api/risks - Create new risk entry',
        '• PUT /api/risks/:id - Update risk entry',
        '• DELETE /api/risks/:id - Remove risk entry',
        '• GET /api/kpis - Retrieve KPI dashboard data',
        '• GET /api/audits - Retrieve audit records',
      ],
    },
    {
      heading: '6. Performance Considerations',
      content: [
        '• Lazy loading for route-based code splitting',
        '• Optimistic updates for improved UX',
        '• Debounced search inputs to reduce API calls',
        '• Memoized components to prevent unnecessary re-renders',
      ],
    },
  ],
};

const qaTestCasesContent: DocumentContent = {
  title: 'QA Test Cases Document',
  version: '1.0',
  lastUpdated: '2025-12-25',
  sections: [
    {
      heading: '1. Dashboard Module Test Cases',
      content: [
        'TC-DASH-001: Verify dashboard loads within 3 seconds',
        '  Steps: Navigate to dashboard URL',
        '  Expected: All KPIs and widgets render correctly',
        '',
        'TC-DASH-002: Verify KPI calculations are accurate',
        '  Steps: Compare displayed values with source data',
        '  Expected: Values match within 0.1% tolerance',
        '',
        'TC-DASH-003: Verify action center displays pending items',
        '  Steps: Check action items against database',
        '  Expected: All pending items shown with correct counts',
      ],
    },
    {
      heading: '2. Risk Management Test Cases',
      content: [
        'TC-RISK-001: Create new risk entry',
        '  Steps: Click Add Risk > Fill form > Submit',
        '  Expected: Risk appears in register with correct data',
        '',
        'TC-RISK-002: Edit existing risk',
        '  Steps: Select risk > Click Edit > Modify fields > Save',
        '  Expected: Changes persist and display correctly',
        '',
        'TC-RISK-003: Filter risks by domain',
        '  Steps: Click domain tab > Verify filtered results',
        '  Expected: Only risks matching domain are displayed',
        '',
        'TC-RISK-004: Validate risk level color coding',
        '  Steps: View risks with different levels',
        '  Expected: Critical=Red, High=Orange, Medium=Yellow, Low=Green',
      ],
    },
    {
      heading: '3. Organization Chart Test Cases',
      content: [
        'TC-ORG-001: Add new organization member',
        '  Steps: Click Add Member > Fill details > Save',
        '  Expected: Member appears in chart and list views',
        '',
        'TC-ORG-002: Edit member details',
        '  Steps: Click member > Edit > Modify > Save',
        '  Expected: Updated info reflects in both views',
        '',
        'TC-ORG-003: Delete member with reassignment',
        '  Steps: Delete member with direct reports',
        '  Expected: Reports reassigned to deleted members manager',
        '',
        'TC-ORG-004: Expand/collapse chart nodes',
        '  Steps: Click expand/collapse arrows',
        '  Expected: Child nodes show/hide correctly',
      ],
    },
    {
      heading: '4. Role Impersonation Test Cases',
      content: [
        'TC-ROLE-001: Switch to Department Head role',
        '  Steps: Click role dropdown > Select Department Head',
        '  Expected: Toast confirms switch, UI updates accordingly',
        '',
        'TC-ROLE-002: Switch to Staff role',
        '  Steps: Click role dropdown > Select Staff',
        '  Expected: Limited options visible per role permissions',
        '',
        'TC-ROLE-003: Verify role persistence during navigation',
        '  Steps: Switch role > Navigate between pages',
        '  Expected: Selected role maintained across pages',
      ],
    },
    {
      heading: '5. Data Export Test Cases',
      content: [
        'TC-EXP-001: Export risk register to CSV',
        '  Steps: Click Export button on risks page',
        '  Expected: CSV file downloads with all visible data',
        '',
        'TC-EXP-002: Export audit findings',
        '  Steps: Navigate to audits > Click Export',
        '  Expected: Complete audit data exported correctly',
      ],
    },
  ],
};

const uatTestCasesContent: DocumentContent = {
  title: 'UAT Test Cases Document',
  version: '1.0',
  lastUpdated: '2025-12-25',
  sections: [
    {
      heading: '1. User Journey: Compliance Head Daily Review',
      content: [
        'UAT-001: Morning Dashboard Review',
        '  Scenario: Compliance Head starts their day reviewing overall status',
        '  Steps:',
        '    1. Login to system as Admin/Compliance Head',
        '    2. View dashboard KPIs for compliance rate',
        '    3. Review action center for urgent items',
        '    4. Check overdue tasks count',
        '  Acceptance Criteria:',
        '    - Dashboard loads in under 3 seconds',
        '    - All critical metrics visible without scrolling',
        '    - Urgent items highlighted appropriately',
      ],
    },
    {
      heading: '2. User Journey: Risk Assessment Workflow',
      content: [
        'UAT-002: Complete Risk Assessment Cycle',
        '  Scenario: Department Head identifies and documents a new risk',
        '  Steps:',
        '    1. Navigate to Risk Management',
        '    2. Create new risk with all required fields',
        '    3. Assign risk level and owner',
        '    4. Set due date for mitigation',
        '    5. Verify risk appears in dashboard counts',
        '  Acceptance Criteria:',
        '    - Form validates required fields',
        '    - Risk immediately visible in register',
        '    - Dashboard KPIs update to reflect new risk',
      ],
    },
    {
      heading: '3. User Journey: Audit Finding Resolution',
      content: [
        'UAT-003: Resolve Audit Finding',
        '  Scenario: Staff member addresses an open audit finding',
        '  Steps:',
        '    1. Login as Staff role',
        '    2. Navigate to Audit Management',
        '    3. Select open finding assigned to user',
        '    4. Upload evidence of resolution',
        '    5. Mark finding as resolved',
        '  Acceptance Criteria:',
        '    - Staff can only see their assigned items',
        '    - Evidence upload completes successfully',
        '    - Status change reflects immediately',
      ],
    },
    {
      heading: '4. User Journey: Policy Document Review',
      content: [
        'UAT-004: Annual Policy Review Process',
        '  Scenario: Department Head reviews policies due for annual update',
        '  Steps:',
        '    1. Navigate to Risk Management > Policies tab',
        '    2. Filter policies by Review Due (30 days)',
        '    3. Open policy requiring review',
        '    4. Verify current version and last update',
        '    5. Initiate review workflow',
        '  Acceptance Criteria:',
        '    - Upcoming reviews clearly highlighted',
        '    - Policy history accessible',
        '    - Review workflow initiates correctly',
      ],
    },
    {
      heading: '5. User Journey: Organization Updates',
      content: [
        'UAT-005: Onboard New Team Member',
        '  Scenario: Admin adds new staff member to organization',
        '  Steps:',
        '    1. Navigate to Org Chart',
        '    2. Click Add Member',
        '    3. Fill in employee details and reporting structure',
        '    4. Assign appropriate role',
        '    5. Verify member appears in chart and directory',
        '  Acceptance Criteria:',
        '    - All required fields validated',
        '    - Reporting line correctly shown in chart',
        '    - Team Directory list updates immediately',
      ],
    },
    {
      heading: '6. Cross-Functional Scenarios',
      content: [
        'UAT-006: End-to-End Compliance Workflow',
        '  Scenario: Complete compliance cycle from risk to resolution',
        '  Steps:',
        '    1. Identify risk in Risk Management',
        '    2. Create related audit finding',
        '    3. Track through enforcement if needed',
        '    4. Document in feedback management',
        '    5. Update relevant policies',
        '  Acceptance Criteria:',
        '    - All modules interconnected',
        '    - Audit trail maintained throughout',
        '    - Reports reflect complete workflow',
      ],
    },
  ],
};

const systemPromptContent: DocumentContent = {
  title: 'System Prompt - Patient Care Compliance Dashboard',
  version: '1.0',
  lastUpdated: '2025-12-25',
  sections: [
    {
      heading: '1. System Overview',
      content: [
        'You are the Patient Care Compliance Department Dashboard - a comprehensive management system for healthcare organizations to manage compliance operations, risk assessment, audit tracking, and regulatory adherence.',
        '',
        'This system is part of a broader compliance suite following the same UX patterns as Finance and HSLS dashboards, featuring left navigation, persistent breadcrumbs, Action Center, Review Queue, Quick Stats, Quality KPIs, and Quick Access microapp tiles.',
      ],
    },
    {
      heading: '2. Core Architecture - Five Suite Buckets',
      content: [
        'ALL Patient Care work items MUST route into one of these five core modules:',
        '',
        '2.1 Risk Management (RiskGuard)',
        '  - Risk register with assessment workflows',
        '  - Mitigation tracking and monitoring',
        '  - Risk level classification: Critical, High, Medium, Low',
        '  - Policy and procedure document management',
        '  - CAPA (Corrective and Preventive Actions) tracking',
        '',
        '2.2 Audit Management (AuditPro)',
        '  - Audit scheduling and calendar',
        '  - Finding tracking with severity levels',
        '  - Corrective action workflows',
        '  - Evidence collection and documentation',
        '',
        '2.3 Compliance Tracking (ComplianceConnect)',
        '  - Regulatory requirements monitoring',
        '  - CAPA/ActionGuard integration',
        '  - Citations/CitaPro management',
        '  - Document control links',
        '  - Evidence collection for compliance',
        '',
        '2.4 Feedback Management (FeedbackHub)',
        '  - Stakeholder feedback collection',
        '  - Patient satisfaction tracking',
        '  - Complaint management',
        '  - Quality improvement input',
        '',
        '2.5 Enforcement Management (EnforcePoint)',
        '  - Policy enforcement tracking',
        '  - Violation documentation',
        '  - Corrective measures',
        '  - Escalation workflows',
      ],
    },
    {
      heading: '3. Role-Based Access Control',
      content: [
        'The system supports three user role levels with impersonation capability:',
        '',
        '3.1 Admin/Compliance Head',
        '  - Full system access and configuration',
        '  - All CRUD operations across all modules',
        '  - Organization chart management',
        '  - System-wide reporting and analytics',
        '  - User role management',
        '',
        '3.2 Department Head (Patient Care)',
        '  - Department-scoped access',
        '  - Team management within department',
        '  - Risk and audit oversight for department',
        '  - Approval workflows for department items',
        '  - Department-level reporting',
        '',
        '3.3 Staff (Patient Care)',
        '  - Task-level access only',
        '  - View and update assigned items',
        '  - Evidence upload and documentation',
        '  - Limited reporting (own tasks only)',
        '  - Read-only access to policies',
      ],
    },
    {
      heading: '4. Regulatory Alignment (Configurable Tags)',
      content: [
        'The system is regulatory-ready via configurable multi-select tags:',
        '',
        '• CMS (Conditions of Participation) - Medicare/Medicaid care delivery requirements',
        '• State Health Dept / State Survey Agency - State-level regulatory oversight',
        '• Accreditor (Generic) - Joint Commission, CARF, or other accreditation bodies',
        '• HHS OCR - Privacy/Security (HIPAA) impact on patient care workflows',
        '• CDC Guidance / Infection Control - Optional for infection control scope',
        '• Local/State Patient Rights - Generic patient rights requirements tag',
        '',
        'IMPORTANT: Do NOT hardcode specific accreditor standards. The system uses flexible tagging to support unknown future clients and varying regulatory requirements.',
      ],
    },
    {
      heading: '5. Dashboard Components',
      content: [
        '5.1 Quick Stats Cards',
        '  - Total Risks (with critical count badge)',
        '  - Active Audits (with findings count)',
        '  - Compliance Rate (percentage with trend)',
        '  - Overdue Items (urgent attention indicator)',
        '',
        '5.2 Action Center',
        '  - Prioritized task list',
        '  - Due date highlighting',
        '  - Quick action buttons',
        '  - Role-filtered view',
        '',
        '5.3 Quality KPI Panel',
        '  - Configurable KPI cards with targets',
        '  - Formula display (numerator/denominator)',
        '  - Progress bars with color coding',
        '  - CRUD operations for KPIs',
        '',
        '5.4 Alerts Panel',
        '  - System notifications',
        '  - Compliance alerts',
        '  - Due date reminders',
        '  - Priority-based sorting',
        '',
        '5.5 Quick Access Microapp Tiles',
        '  - Shortcut tiles to major modules',
        '  - Icon-based visual navigation',
        '  - Module status indicators',
      ],
    },
    {
      heading: '6. Data Table Features',
      content: [
        'Standard data table functionality across all modules:',
        '',
        '• Column sorting (ascending/descending)',
        '• Domain-based tab filtering',
        '• Search/filter by text',
        '• Status badges with color coding',
        '• Risk level indicators',
        '• Row actions (View, Edit, Delete)',
        '• Bulk selection capability',
        '• Export to CSV/PDF',
        '• Pagination controls',
      ],
    },
    {
      heading: '7. Organization Chart Module',
      content: [
        '7.1 Hierarchical Tree View',
        '  - Visual org structure display',
        '  - Expandable/collapsible nodes',
        '  - Role and department indicators',
        '  - Reporting line visualization',
        '',
        '7.2 Team Directory List',
        '  - Searchable member list',
        '  - Quick contact information',
        '  - Role and department filters',
        '',
        '7.3 Member Management',
        '  - Add new team members',
        '  - Edit member details',
        '  - Assign reporting structure',
        '  - Delete with reassignment workflow',
      ],
    },
    {
      heading: '8. Document Management',
      content: [
        'Policies and procedures are managed within Risk Management:',
        '',
        '• Document version control',
        '• Review date tracking',
        '• Approval workflows',
        '• Access logging',
        '• Category and tag organization',
        '• Full-text search',
        '• Download and export',
      ],
    },
    {
      heading: '9. Technical Stack',
      content: [
        '• Frontend: React 18 with TypeScript',
        '• Build: Vite for fast development and builds',
        '• Styling: Tailwind CSS with custom design tokens',
        '• UI Components: Shadcn/ui component library',
        '• State: React Query for server state management',
        '• Routing: React Router v6 for SPA navigation',
        '• Charts: Recharts for data visualization',
        '• PDF: jsPDF for document generation',
        '• Icons: Lucide React icon library',
        '• Forms: React Hook Form with Zod validation',
      ],
    },
    {
      heading: '10. Design System Tokens',
      content: [
        'Semantic color tokens (HSL-based):',
        '',
        '--background, --foreground: Base surface and text',
        '--primary, --primary-foreground: Brand/action colors',
        '--secondary, --secondary-foreground: Secondary surfaces',
        '--muted, --muted-foreground: Subdued elements',
        '--accent, --accent-foreground: Highlight elements',
        '--destructive: Error/danger states',
        '--success: Success states',
        '--warning: Warning states',
        '--info: Informational states',
        '',
        'All components use design system tokens. Direct color values (text-white, bg-black) are NOT used.',
      ],
    },
    {
      heading: '11. Patient Care Admin Functions',
      content: [
        'Patient care administrative functions are implemented as:',
        '',
        '• Filtered views over existing modules',
        '• Configurable templates',
        '• Checklists integrated into workflows',
        '• KPI dashboards with patient care metrics',
        '',
        'These are NOT separate microapps or new data stores. They leverage the five core buckets with appropriate filtering and views.',
        '',
        'Examples:',
        '- Patient Tracker → Filtered view in Compliance Tracking',
        '- Incident Checklist → Template in Risk Management',
        '- Patient Care Checklist → Audit template in Audit Management',
        '- Quality Management → KPI dashboard in main dashboard',
      ],
    },
    {
      heading: '12. Workflow Patterns',
      content: [
        '12.1 Item Creation',
        '  - Form dialog with validation',
        '  - Required field enforcement',
        '  - Domain/tag selection',
        '  - Owner assignment',
        '  - Due date setting',
        '',
        '12.2 Item Review',
        '  - Status progression workflow',
        '  - Approval/rejection options',
        '  - Comment/note attachment',
        '  - Evidence upload',
        '',
        '12.3 Escalation',
        '  - Automatic escalation on overdue',
        '  - Manual escalation option',
        '  - Notification to stakeholders',
        '  - Audit trail logging',
      ],
    },
    {
      heading: '13. Reporting & Analytics',
      content: [
        '• Real-time dashboard metrics',
        '• Trend analysis charts',
        '• Compliance score tracking',
        '• Risk heat maps',
        '• Audit finding summaries',
        '• Export to PDF/CSV',
        '• Scheduled report generation',
        '• Role-based report access',
      ],
    },
    {
      heading: '14. Security & Compliance',
      content: [
        '• HIPAA-compliant data handling',
        '• Role-based access control (RBAC)',
        '• Session-based authentication',
        '• Audit trail for all actions',
        '• Data encryption at rest and in transit',
        '• Secure document storage',
        '• Access logging and monitoring',
      ],
    },
    {
      heading: '15. Integration Points',
      content: [
        'The system is designed for integration with:',
        '',
        '• Electronic Health Records (EHR) systems',
        '• Learning Management Systems (LMS)',
        '• HR/Payroll systems',
        '• Document Management Systems',
        '• Notification services (email, SMS)',
        '• Analytics platforms',
        '',
        'Integration is via RESTful APIs with standard authentication.',
      ],
    },
    {
      heading: '16. Navigation Structure',
      content: [
        'Left sidebar navigation:',
        '',
        '1. Patient Care Dashboard (Home)',
        '2. Risk Management',
        '3. Audit Management',
        '4. Compliance Tracking',
        '5. Feedback Management',
        '6. Enforcement Management',
        '7. Org Chart',
        '8. Documentation',
        '',
        'Each page follows consistent layout with header, filters, and main content area.',
      ],
    },
    {
      heading: '17. Response Patterns',
      content: [
        'User actions should trigger appropriate feedback:',
        '',
        '• Success: Toast notification with confirmation',
        '• Error: Toast notification with error details',
        '• Loading: Visual loading indicators',
        '• Confirmation: Dialog for destructive actions',
        '• Validation: Inline field-level feedback',
      ],
    },
    {
      heading: '18. Lean Implementation Principle',
      content: [
        'CRITICAL: Keep implementation LEAN for unknown future clients:',
        '',
        '• Use flexible tagging over hardcoded rules',
        '• Configurable templates over fixed workflows',
        '• Generic regulatory alignment over specific standards',
        '• Extensible data models over rigid schemas',
        '• Role-based visibility over fixed permissions',
        '',
        'The system should adapt to various healthcare organization types and regulatory environments without code changes.',
      ],
    },
  ],
};

const documents: DocumentSection[] = [
  { id: 'system-prompt', title: 'System Prompt', icon: Terminal, color: 'text-purple-500', content: systemPromptContent },
  { id: 'prd', title: 'Product Requirements Document (PRD)', icon: FileText, color: 'text-primary', content: prdContent },
  { id: 'tdd', title: 'Technical Design Document (TDD)', icon: Code, color: 'text-info', content: tddContent },
  { id: 'qa', title: 'QA Test Cases', icon: TestTube, color: 'text-warning', content: qaTestCasesContent },
  { id: 'uat', title: 'UAT Test Cases', icon: ClipboardCheck, color: 'text-success', content: uatTestCasesContent },
];

export default function Documentation() {
  const [expandedDoc, setExpandedDoc] = useState<string | null>(null);

  const generatePDF = (doc: DocumentSection) => {
    const pdf = new jsPDF();
    const content = doc.content;
    let yPosition = 20;
    const pageHeight = pdf.internal.pageSize.height;
    const marginLeft = 20;
    const marginRight = 20;
    const maxWidth = pdf.internal.pageSize.width - marginLeft - marginRight;

    // Title
    pdf.setFontSize(20);
    pdf.setFont('helvetica', 'bold');
    pdf.text(content.title, marginLeft, yPosition);
    yPosition += 10;

    // Metadata
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    pdf.setTextColor(100);
    pdf.text(`Version: ${content.version} | Last Updated: ${content.lastUpdated}`, marginLeft, yPosition);
    yPosition += 15;
    pdf.setTextColor(0);

    // Sections
    content.sections.forEach((section) => {
      // Check if we need a new page
      if (yPosition > pageHeight - 40) {
        pdf.addPage();
        yPosition = 20;
      }

      // Section heading
      pdf.setFontSize(14);
      pdf.setFont('helvetica', 'bold');
      pdf.text(section.heading, marginLeft, yPosition);
      yPosition += 8;

      // Section content
      pdf.setFontSize(10);
      pdf.setFont('helvetica', 'normal');

      section.content.forEach((line) => {
        if (yPosition > pageHeight - 20) {
          pdf.addPage();
          yPosition = 20;
        }

        const splitLines = pdf.splitTextToSize(line, maxWidth);
        splitLines.forEach((splitLine: string) => {
          if (yPosition > pageHeight - 20) {
            pdf.addPage();
            yPosition = 20;
          }
          pdf.text(splitLine, marginLeft, yPosition);
          yPosition += 5;
        });
      });

      yPosition += 8;
    });

    // Footer on each page
    const totalPages = pdf.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      pdf.setPage(i);
      pdf.setFontSize(8);
      pdf.setTextColor(150);
      pdf.text(
        `Patient Care Compliance Dashboard - ${content.title} - Page ${i} of ${totalPages}`,
        marginLeft,
        pageHeight - 10
      );
    }

    // Download
    const fileName = `${doc.id.toUpperCase()}_PatientCare_v${content.version}.pdf`;
    pdf.save(fileName);
    toast.success('PDF Downloaded', { description: fileName });
  };

  const toggleExpand = (docId: string) => {
    setExpandedDoc(expandedDoc === docId ? null : docId);
  };

  return (
    <DashboardLayout>
      <DashboardHeader
        title="Documentation"
        subtitle="Project documentation, requirements, and test cases"
        showFilters={false}
        actions={
          <Button
            variant="default"
            onClick={() => documents.forEach((doc) => generatePDF(doc))}
            className="gap-2"
          >
            <Download className="h-4 w-4" />
            Download All
          </Button>
        }
      />

      <div className="grid gap-4">
        {documents.map((doc) => {
          const Icon = doc.icon;
          const isExpanded = expandedDoc === doc.id;

          return (
            <div key={doc.id} className="dashboard-card overflow-hidden">
              {/* Header */}
              <div
                className="flex items-center justify-between p-4 cursor-pointer hover:bg-muted/50 transition-colors"
                onClick={() => toggleExpand(doc.id)}
              >
                <div className="flex items-center gap-3">
                  <div className={cn('p-2 rounded-lg bg-muted', doc.color)}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">{doc.title}</h3>
                    <p className="text-sm text-muted-foreground">
                      Version {doc.content.version} • Updated {doc.content.lastUpdated}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      generatePDF(doc);
                    }}
                    className="gap-2"
                  >
                    <Download className="h-4 w-4" />
                    Download PDF
                  </Button>
                  {isExpanded ? (
                    <ChevronUp className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>
              </div>

              {/* Expanded Content */}
              {isExpanded && (
                <div className="border-t border-border p-6 bg-muted/20">
                  <div className="prose prose-sm max-w-none">
                    {doc.content.sections.map((section, idx) => (
                      <div key={idx} className="mb-6">
                        <h4 className="text-base font-semibold text-foreground mb-2">
                          {section.heading}
                        </h4>
                        <div className="space-y-1">
                          {section.content.map((line, lineIdx) => (
                            <p
                              key={lineIdx}
                              className={cn(
                                'text-sm text-muted-foreground',
                                line.startsWith('  ') && 'ml-4',
                                line.startsWith('•') && 'ml-2'
                              )}
                            >
                              {line || '\u00A0'}
                            </p>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </DashboardLayout>
  );
}
