import { DashboardLayout } from '@/components/dashboard/DashboardLayout';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { mockOrgMembers } from '@/data/mockPatientCareData';
import { OrgMember } from '@/types/patientCare';
import { Button } from '@/components/ui/button';
import { 
  Plus, Edit, ChevronDown, Trash2, MoreVertical 
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { useState } from 'react';
import { OrgMemberFormDialog } from '@/components/dashboard/OrgMemberFormDialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

// Avatar color palette
const avatarColors = [
  'bg-cyan-500',
  'bg-blue-500', 
  'bg-green-500',
  'bg-orange-500',
  'bg-purple-500',
  'bg-pink-500',
  'bg-teal-500',
  'bg-indigo-500',
];

const getAvatarColor = (name: string) => {
  const index = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) % avatarColors.length;
  return avatarColors[index];
};

export default function OrgChart() {
  const [members, setMembers] = useState<OrgMember[]>(mockOrgMembers);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<OrgMember | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [memberToDelete, setMemberToDelete] = useState<OrgMember | null>(null);
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set(members.map(m => m.id)));

  // Build org tree
  const topLevel = members.filter((m) => !m.reportsTo);
  const getReports = (id: string) => members.filter((m) => m.reportsTo === id);

  const handleAddMember = () => {
    setEditingMember(null);
    setDialogOpen(true);
  };

  const handleEditMember = (member: OrgMember) => {
    setEditingMember(member);
    setDialogOpen(true);
  };

  const handleDeleteClick = (member: OrgMember) => {
    setMemberToDelete(member);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = () => {
    if (memberToDelete) {
      const updatedMembers = members
        .filter((m) => m.id !== memberToDelete.id)
        .map((m) => ({
          ...m,
          reportsTo: m.reportsTo === memberToDelete.id ? memberToDelete.reportsTo : m.reportsTo,
        }));
      setMembers(updatedMembers);
      toast.success(`${memberToDelete.name} removed from org chart`);
    }
    setDeleteDialogOpen(false);
    setMemberToDelete(null);
  };

  const handleSaveMember = (member: OrgMember) => {
    if (editingMember) {
      setMembers(members.map((m) => (m.id === member.id ? member : m)));
    } else {
      setMembers([...members, member]);
      setExpandedNodes(prev => new Set([...prev, member.id]));
    }
  };

  const toggleExpand = (id: string) => {
    setExpandedNodes(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  // Card component for org chart
  const OrgCard = ({ member }: { member: OrgMember }) => {
    const reports = getReports(member.id);
    const hasReports = reports.length > 0;
    const isExpanded = expandedNodes.has(member.id);

    return (
      <div className="flex flex-col items-center">
        <div className="bg-card border border-border rounded-lg shadow-sm p-4 min-w-[200px] relative group">
          <div className="flex items-start gap-3">
            <div className={cn(
              'w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 text-white font-semibold text-sm',
              getAvatarColor(member.name)
            )}>
              {member.name.split(' ').map((n) => n[0]).join('')}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-1">
                <div>
                  <h3 className="font-medium text-foreground text-sm">{member.name}</h3>
                  <p className="text-xs text-muted-foreground">{member.title}</p>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleEditMember(member)}>
                      <Edit className="h-4 w-4 mr-2" />
                      Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleDeleteClick(member)} className="text-destructive">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>
          <a
            href={`mailto:${member.email}`}
            className="text-xs text-primary hover:underline mt-2 block truncate"
          >
            {member.email}
          </a>
          
          {/* Expand/Collapse button */}
          {hasReports && (
            <button
              onClick={() => toggleExpand(member.id)}
              className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-6 h-6 bg-card border border-border rounded-full flex items-center justify-center shadow-sm hover:bg-muted transition-colors z-10"
            >
              <ChevronDown className={cn(
                'h-4 w-4 text-muted-foreground transition-transform',
                !isExpanded && '-rotate-90'
              )} />
            </button>
          )}
        </div>

        {/* Children */}
        {hasReports && isExpanded && (
          <div className="relative mt-6">
            {/* Vertical line from parent */}
            <div className="absolute left-1/2 -top-6 w-px h-6 bg-border" />
            
            {/* Horizontal connector */}
            {reports.length > 1 && (
              <div className="absolute top-0 left-0 right-0 h-px bg-border" style={{
                left: `calc(${100 / (reports.length * 2)}% - 1px)`,
                right: `calc(${100 / (reports.length * 2)}% - 1px)`,
              }} />
            )}

            <div className="flex gap-6 justify-center">
              {reports.map((report, index) => (
                <div key={report.id} className="relative">
                  {/* Vertical line to child */}
                  <div className="absolute left-1/2 -top-0 w-px h-4 bg-border -translate-x-1/2" />
                  <div className="pt-4">
                    <OrgCard member={report} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  // Team Directory List
  const TeamDirectory = () => (
    <div className="dashboard-card">
      <div className="flex items-center justify-between p-4 border-b border-border">
        <h3 className="font-semibold text-foreground">Team Directory</h3>
        <span className="text-sm text-muted-foreground">{members.length} members</span>
      </div>
      <div className="divide-y divide-border">
        {members.map((member) => (
          <div
            key={member.id}
            className="flex items-center gap-3 p-4 hover:bg-muted/50 transition-colors group"
          >
            <div className={cn(
              'w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-white font-semibold text-xs',
              getAvatarColor(member.name)
            )}>
              {member.name.split(' ').map((n) => n[0]).join('')}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-foreground text-sm">{member.name}</p>
              <p className="text-xs text-muted-foreground">{member.title}</p>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => handleEditMember(member)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleDeleteClick(member)} className="text-destructive">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <DashboardLayout>
      <DashboardHeader
        title="Governing Body Org Chart"
        subtitle="Patient Care leadership structure and contacts"
        showFilters={false}
        actions={
          <Button variant="default" onClick={handleAddMember} className="gap-2">
            <Plus className="h-4 w-4" />
            Add Member
          </Button>
        }
      />

      {/* Organization Chart - Horizontal Tree */}
      <div className="dashboard-card p-6 mb-6 overflow-x-auto">
        <div className="flex justify-center min-w-max py-4">
          <div className="flex gap-8">
            {topLevel.map((member) => (
              <OrgCard key={member.id} member={member} />
            ))}
          </div>
        </div>
      </div>

      {/* Team Directory */}
      <TeamDirectory />

      {/* Form Dialog */}
      <OrgMemberFormDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        member={editingMember}
        allMembers={members}
        onSave={handleSaveMember}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Member</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove <strong>{memberToDelete?.name}</strong> from the org
              chart? Direct reports will be reassigned to their manager.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
}
