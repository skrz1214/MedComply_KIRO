import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import PatientCareDashboard from "./pages/PatientCareDashboard";
import RiskManagement from "./pages/RiskManagement";
import AuditManagement from "./pages/AuditManagement";
import ComplianceTracking from "./pages/ComplianceTracking";
import FeedbackManagement from "./pages/FeedbackManagement";
import EnforcementManagement from "./pages/EnforcementManagement";
import OrgChart from "./pages/OrgChart";
import Policies from "./pages/Policies";
import MicroApps from "./pages/MicroApps";
import Documentation from "./pages/Documentation";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Navigate to="/dashboards/department/patient-care" replace />} />
          <Route path="/dashboards/department/patient-care" element={<PatientCareDashboard />} />
          <Route path="/dashboards/department/patient-care/risks" element={<RiskManagement />} />
          <Route path="/dashboards/department/patient-care/audits" element={<AuditManagement />} />
          <Route path="/dashboards/department/patient-care/compliance" element={<ComplianceTracking />} />
          <Route path="/dashboards/department/patient-care/feedback" element={<FeedbackManagement />} />
          <Route path="/dashboards/department/patient-care/enforcements" element={<EnforcementManagement />} />
          <Route path="/dashboards/department/patient-care/org-chart" element={<OrgChart />} />
          <Route path="/dashboards/department/patient-care/policies" element={<Policies />} />
          <Route path="/dashboards/department/patient-care/microapps" element={<MicroApps />} />
          <Route path="/dashboards/department/patient-care/documentation" element={<Documentation />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
