import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AdminLayout } from "@/components/layout/AdminLayout";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import AdminHome from "./pages/admin/AdminHome";
import DashboardsConfig from "./pages/admin/DashboardsConfig";
import OrganizationConfig from "./pages/admin/OrganizationConfig";
import RolesConfig from "./pages/admin/RolesConfig";
import ChangeHistory from "./pages/admin/ChangeHistory";
import AppsConfig from "./pages/admin/AppsConfig";
import LOVManager from "./pages/admin/LOVManager";
import WorkflowsConfig from "./pages/admin/WorkflowsConfig";
import LibrariesConfig from "./pages/admin/LibrariesConfig";
import DocumentsConfig from "./pages/admin/DocumentsConfig";
import SecurityConfig from "./pages/admin/SecurityConfig";
import NotificationsConfig from "./pages/admin/NotificationsConfig";
import DataRetentionConfig from "./pages/admin/DataRetentionConfig";
import DevelopmentDocs from "./pages/admin/DevelopmentDocs";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminHome />} />
            <Route path="dashboards" element={<DashboardsConfig />} />
            <Route path="organization" element={<OrganizationConfig />} />
            <Route path="access" element={<RolesConfig />} />
            <Route path="apps" element={<AppsConfig />} />
            <Route path="lov" element={<LOVManager />} />
            <Route path="workflows" element={<WorkflowsConfig />} />
            <Route path="libraries" element={<LibrariesConfig />} />
            <Route path="documents" element={<DocumentsConfig />} />
            <Route path="security" element={<SecurityConfig />} />
            <Route path="notifications" element={<NotificationsConfig />} />
            <Route path="data" element={<DataRetentionConfig />} />
            <Route path="history" element={<ChangeHistory />} />
            <Route path="dev-docs" element={<DevelopmentDocs />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
