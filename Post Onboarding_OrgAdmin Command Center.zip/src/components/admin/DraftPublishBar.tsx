import { Button } from "@/components/ui/button";
import { Save, Send, Trash2, Eye, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

interface DraftPublishBarProps {
  hasChanges: boolean;
  lastSaved?: string;
  onSaveDraft: () => void;
  onPublish: () => void;
  onDiscard: () => void;
  onPreview: () => void;
  isPublishing?: boolean;
  isSaving?: boolean;
}

export function DraftPublishBar({
  hasChanges,
  lastSaved,
  onSaveDraft,
  onPublish,
  onDiscard,
  onPreview,
  isPublishing,
  isSaving,
}: DraftPublishBarProps) {
  if (!hasChanges) return null;

  return (
    <div className="draft-bar animate-slide-up">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-draft animate-pulse" />
          <span className="text-sm font-medium text-foreground">
            Unsaved Changes
          </span>
        </div>
        
        {lastSaved && (
          <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
            <Clock className="w-3.5 h-3.5" />
            <span>Last saved {lastSaved}</span>
          </div>
        )}
      </div>

      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="sm"
          onClick={onDiscard}
          className="text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="w-4 h-4 mr-2" />
          Discard
        </Button>
        
        <Button
          variant="outline"
          size="sm"
          onClick={onPreview}
        >
          <Eye className="w-4 h-4 mr-2" />
          Preview
        </Button>
        
        <Button
          variant="secondary"
          size="sm"
          onClick={onSaveDraft}
          disabled={isSaving}
        >
          <Save className="w-4 h-4 mr-2" />
          {isSaving ? "Saving..." : "Save Draft"}
        </Button>
        
        <Button
          size="sm"
          onClick={onPublish}
          disabled={isPublishing}
          className="bg-accent text-accent-foreground hover:bg-accent/90"
        >
          <Send className="w-4 h-4 mr-2" />
          {isPublishing ? "Publishing..." : "Publish"}
        </Button>
      </div>
    </div>
  );
}
