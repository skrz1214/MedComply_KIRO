import { cn } from "@/lib/utils";
import { CheckCircle2, XCircle, AlertCircle } from "lucide-react";

interface StatusCardProps {
  title: string;
  status: "configured" | "not-configured" | "partial";
  value?: string;
  description?: string;
  icon?: React.ComponentType<{ className?: string }>;
  onClick?: () => void;
}

export function StatusCard({
  title,
  status,
  value,
  description,
  icon: Icon,
  onClick,
}: StatusCardProps) {
  const statusConfig = {
    configured: {
      icon: CheckCircle2,
      color: "text-success",
      bgColor: "bg-success/10",
      label: "Configured",
    },
    "not-configured": {
      icon: XCircle,
      color: "text-muted-foreground",
      bgColor: "bg-muted",
      label: "Not Configured",
    },
    partial: {
      icon: AlertCircle,
      color: "text-warning",
      bgColor: "bg-warning/10",
      label: "Partial",
    },
  };

  const config = statusConfig[status];
  const StatusIcon = config.icon;

  return (
    <button
      onClick={onClick}
      className={cn(
        "card-metric text-left w-full group focus-ring",
        onClick && "cursor-pointer hover:border-accent"
      )}
    >
      <div className="flex items-start justify-between mb-4">
        <div
          className={cn(
            "w-10 h-10 rounded-lg flex items-center justify-center",
            config.bgColor
          )}
        >
          {Icon ? (
            <Icon className={cn("w-5 h-5", config.color)} />
          ) : (
            <StatusIcon className={cn("w-5 h-5", config.color)} />
          )}
        </div>
        <span
          className={cn(
            "text-xs font-medium px-2 py-1 rounded-full",
            config.bgColor,
            config.color
          )}
        >
          {config.label}
        </span>
      </div>

      <h3 className="font-semibold text-foreground mb-1 group-hover:text-accent transition-colors">
        {title}
      </h3>
      
      {value && (
        <p className="text-2xl font-bold text-foreground mb-1">{value}</p>
      )}
      
      {description && (
        <p className="text-sm text-muted-foreground">{description}</p>
      )}
    </button>
  );
}
