import { NavLink, useLocation } from "react-router-dom";
import {
  Home,
  Building2,
  Puzzle,
  Shield,
  List,
  GitBranch,
  BookOpen,
  LayoutDashboard,
  FileText,
  Lock,
  Bell,
  Database,
  History,
  ChevronDown,
  Settings,
  Users,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";

interface NavSection {
  title: string;
  items: NavItem[];
}

interface NavItem {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  children?: { label: string; href: string }[];
}

const navigationSections: NavSection[] = [
  {
    title: "Overview",
    items: [
      { label: "Admin Home", href: "/admin", icon: Home },
    ],
  },
  {
    title: "Organization",
    items: [
      { label: "Organization & Structure", href: "/admin/organization", icon: Building2 },
      { label: "Apps & Integrations", href: "/admin/apps", icon: Puzzle },
    ],
  },
  {
    title: "Access Control",
    items: [
      { label: "Access Management", href: "/admin/access", icon: Shield },
      { label: "LOV Manager", href: "/admin/lov", icon: List },
    ],
  },
  {
    title: "Configuration",
    items: [
      { 
        label: "Dashboards", 
        href: "/admin/dashboards", 
        icon: LayoutDashboard,
        badge: "3 Layers",
      },
    ],
  },
  {
    title: "System",
    items: [
      { label: "Data & Retention", href: "/admin/data", icon: Database },
      { label: "Change History", href: "/admin/history", icon: History },
    ],
  },
  {
    title: "Documents for Development",
    items: [
      { label: "Dev Documents", href: "/admin/dev-docs", icon: FileText },
    ],
  },
];

export function AdminSidebar() {
  const location = useLocation();
  const [expandedSections, setExpandedSections] = useState<string[]>(
    navigationSections.map((s) => s.title)
  );

  const toggleSection = (title: string) => {
    setExpandedSections((prev) =>
      prev.includes(title)
        ? prev.filter((t) => t !== title)
        : [...prev, title]
    );
  };

  const isActive = (href: string) => {
    if (href === "/admin") {
      return location.pathname === "/admin";
    }
    return location.pathname.startsWith(href);
  };

  return (
    <aside className="w-64 min-h-screen bg-sidebar flex flex-col border-r border-sidebar-border">
      {/* Logo */}
      <div className="h-16 flex items-center px-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-sidebar-primary flex items-center justify-center">
            <Shield className="w-5 h-5 text-sidebar-primary-foreground" />
          </div>
          <div>
            <span className="font-semibold text-sidebar-foreground">MedComply</span>
            <span className="text-xs text-sidebar-muted block">Admin Center</span>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-3">
        {navigationSections.map((section) => (
          <div key={section.title} className="mb-4">
            <button
              onClick={() => toggleSection(section.title)}
              className="nav-section-title w-full flex items-center justify-between hover:text-sidebar-foreground transition-colors"
              aria-expanded={expandedSections.includes(section.title)}
            >
              {section.title}
              <ChevronDown
                className={cn(
                  "w-3 h-3 transition-transform",
                  expandedSections.includes(section.title) ? "" : "-rotate-90"
                )}
              />
            </button>

            {expandedSections.includes(section.title) && (
              <ul className="mt-1 space-y-1 animate-fade-in">
                {section.items.map((item) => (
                  <li key={item.href}>
                    <NavLink
                      to={item.href}
                      end={item.href === "/admin"}
                      className={({ isActive: active }) =>
                        cn(
                          "nav-item focus-ring",
                          active || isActive(item.href)
                            ? "nav-item-active"
                            : "nav-item-inactive"
                        )
                      }
                    >
                      <item.icon className="w-4 h-4 flex-shrink-0" />
                      <span className="flex-1 truncate">{item.label}</span>
                      {item.badge && (
                        <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-sidebar-primary/20 text-sidebar-primary">
                          {item.badge}
                        </span>
                      )}
                    </NavLink>
                  </li>
                ))}
              </ul>
            )}
          </div>
        ))}
      </nav>

      {/* User Section */}
      <div className="p-3 border-t border-sidebar-border">
        <div className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-sidebar-accent transition-colors cursor-pointer">
          <div className="w-8 h-8 rounded-full bg-sidebar-accent flex items-center justify-center">
            <Users className="w-4 h-4 text-sidebar-foreground" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-sidebar-foreground truncate">
              Org Admin
            </p>
            <p className="text-xs text-sidebar-muted truncate">
              Full Access
            </p>
          </div>
          <Settings className="w-4 h-4 text-sidebar-muted" />
        </div>
      </div>
    </aside>
  );
}
