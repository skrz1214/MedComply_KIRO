import { useState } from "react";
import { TabNavigation } from "@/components/admin/TabNavigation";
import { Button } from "@/components/ui/button";
import { BookOpen, Plus, ChevronRight, FileText, AlertTriangle, ClipboardCheck } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const tabs = [
  { id: "citations", label: "Citations", count: 24 },
  { id: "enforcement", label: "Enforcement", count: 18 },
  { id: "audit", label: "Audit Templates", count: 12 },
  { id: "capa", label: "CAPA", count: 8 },
];

export default function LibrariesConfig() {
  const [activeTab, setActiveTab] = useState("citations");

  const items = {
    citations: [
      { name: "CMS F-Tag Library", count: 156, lastUpdated: "Jan 15, 2024" },
      { name: "State Survey Citations", count: 89, lastUpdated: "Jan 10, 2024" },
      { name: "OSHA Violations", count: 45, lastUpdated: "Dec 28, 2023" },
    ],
    enforcement: [
      { name: "CMS Enforcement Actions", count: 34, lastUpdated: "Jan 12, 2024" },
      { name: "State Penalties", count: 22, lastUpdated: "Jan 8, 2024" },
    ],
    audit: [
      { name: "Annual Compliance Audit", count: 1, lastUpdated: "Jan 5, 2024" },
      { name: "Quarterly QA Review", count: 1, lastUpdated: "Dec 20, 2023" },
      { name: "Mock Survey Template", count: 1, lastUpdated: "Dec 15, 2023" },
    ],
    capa: [
      { name: "Standard CAPA Template", count: 1, lastUpdated: "Jan 10, 2024" },
      { name: "High-Priority CAPA", count: 1, lastUpdated: "Jan 5, 2024" },
    ],
  };

  const icons = {
    citations: AlertTriangle,
    enforcement: FileText,
    audit: ClipboardCheck,
    capa: BookOpen,
  };

  const Icon = icons[activeTab as keyof typeof icons];

  return (
    <div className="animate-fade-in">
      <div className="border-b border-border bg-card">
        <div className="p-6 max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
                <BookOpen className="w-7 h-7 text-accent" />
                Libraries
              </h1>
              <p className="text-muted-foreground mt-1">
                Manage citations, enforcement templates, and CAPA libraries
              </p>
            </div>
          </div>

          <TabNavigation
            tabs={tabs}
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />
        </div>
      </div>

      <div className="p-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-foreground capitalize">{activeTab} Library</h2>
          <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90">
            <Plus className="w-4 h-4 mr-2" />
            Add Entry
          </Button>
        </div>

        <div className="card-section">
          <div className="divide-y divide-border">
            {items[activeTab as keyof typeof items].map((item, index) => (
              <div
                key={index}
                className="p-4 flex items-center gap-4 hover:bg-muted/50 transition-colors cursor-pointer"
              >
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Icon className="w-5 h-5 text-accent" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground">{item.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {item.count} items • Updated {item.lastUpdated}
                  </p>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
