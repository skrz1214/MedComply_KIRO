import { useState } from "react";
import { TabNavigation } from "@/components/admin/TabNavigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Building2,
  MapPin,
  Plus,
  CheckCircle2,
  Users,
  Phone,
  Mail,
  Globe,
  Pencil,
  Trash2,
  Eye,
  Clock,
  Hash,
  FileText,
} from "lucide-react";
import { toast } from "sonner";

const tabs = [
  { id: "profile", label: "Organization Profile" },
  { id: "facilities", label: "Facilities", count: 4 },
  { id: "departments", label: "Departments", count: 8 },
];

// LOV Options based on PRD
const ORG_TYPES = [
  "Hospital",
  "Health System",
  "Clinic",
  "Ambulatory Surgery Center",
  "Long-term Care",
  "Home Health",
  "Hospice",
  "Other",
];

const INDUSTRIES = [
  "Healthcare",
  "Behavioral Health",
  "Senior Living",
  "Rehabilitation",
];

const ACCREDITOR_OPTIONS = [
  "The Joint Commission (TJC)",
  "DNV GL Healthcare",
  "CARF",
  "ACHC",
  "CHAP",
  "None",
  "Other",
];

const US_STATES = [
  "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA",
  "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD",
  "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ",
  "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC",
  "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY",
];

const TIMEZONES = [
  "America/New_York",
  "America/Chicago",
  "America/Denver",
  "America/Los_Angeles",
  "America/Anchorage",
  "Pacific/Honolulu",
];

const FACILITY_TYPES = [
  "Hospital",
  "Clinic",
  "Ambulatory Surgery Center",
  "Long-term Care",
  "Specialty Center",
  "Annex",
  "Administrative",
  "Other",
];

const FACILITY_COUNT_OPTIONS = ["1", "2-5", "6-25", "26+"];
const DEPARTMENT_COUNT_OPTIONS = ["1-5", "6-15", "16+"];
const USER_COUNT_OPTIONS = ["1-25", "26-100", "101-500", "500+"];

export default function OrganizationConfig() {
  const [activeTab, setActiveTab] = useState("profile");

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="p-6 max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
                <Building2 className="w-7 h-7 text-accent" />
                Organization & Structure
              </h1>
              <p className="text-muted-foreground mt-1">
                Manage your organization profile, facilities, and departments
              </p>
            </div>
          </div>

          <TabNavigation
            tabs={tabs}
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />
        </div>
      </div>

      {/* Content */}
      <div className="p-6 max-w-7xl mx-auto">
        {activeTab === "profile" && <OrganizationProfile />}
        {activeTab === "facilities" && <FacilitiesConfig />}
        {activeTab === "departments" && <DepartmentsConfig />}
      </div>
    </div>
  );
}

interface OrganizationData {
  // Basic Info
  name: string;
  legalEntityName: string;
  orgType: string;
  industry: string;
  orgCode: string;
  
  // Healthcare Identifiers
  npi: string;
  taxId: string;
  ccn: string;
  accreditor: string;
  accreditorOther: string;
  
  // Primary Contact
  primaryContactName: string;
  primaryContactEmail: string;
  primaryContactPhone: string;
  implementationOwner: string;
  secondaryComplianceContact: string;
  
  // Address
  addressLine1: string;
  addressLine2: string;
  city: string;
  stateProvince: string;
  country: string;
  zipPostal: string;
  timeZone: string;
  
  // Structure
  singleFacilityMode: boolean;
  numberOfFacilities: string;
  numberOfDepartments: string;
  estimatedUsers: string;
  
  // Parent Org
  hasParentOrg: boolean;
  parentOrgName: string;
  parentOrgCode: string;
}

function OrganizationProfile() {
  const [orgData, setOrgData] = useState<OrganizationData>({
    name: "MedComply Health System",
    legalEntityName: "MedComply Healthcare Inc.",
    orgType: "Health System",
    industry: "Healthcare",
    orgCode: "MEDCOMPLY",
    
    npi: "",
    taxId: "",
    ccn: "",
    accreditor: "The Joint Commission (TJC)",
    accreditorOther: "",
    
    primaryContactName: "John Smith",
    primaryContactEmail: "admin@medcomply.org",
    primaryContactPhone: "+1 (555) 123-4567",
    implementationOwner: "",
    secondaryComplianceContact: "",
    
    addressLine1: "123 Healthcare Drive",
    addressLine2: "",
    city: "Medical City",
    stateProvince: "CA",
    country: "US",
    zipPostal: "12345",
    timeZone: "America/Los_Angeles",
    
    singleFacilityMode: false,
    numberOfFacilities: "2-5",
    numberOfDepartments: "6-15",
    estimatedUsers: "101-500",
    
    hasParentOrg: false,
    parentOrgName: "",
    parentOrgCode: "",
  });

  const handleSave = () => {
    toast.success("Organization profile saved successfully");
  };

  const updateField = (field: keyof OrganizationData, value: string | boolean) => {
    setOrgData({ ...orgData, [field]: value });
  };

  return (
    <div className="space-y-6">
      {/* Basic Information */}
      <div className="card-section">
        <div className="p-4 border-b border-border">
          <h3 className="font-medium text-foreground flex items-center gap-2">
            <Building2 className="w-4 h-4 text-muted-foreground" />
            Basic Information
          </h3>
        </div>
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Organization Name <span className="text-destructive">*</span>
              </label>
              <Input 
                value={orgData.name}
                onChange={(e) => updateField("name", e.target.value)}
                placeholder="Enter organization name"
                maxLength={100}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Legal Entity Name
              </label>
              <Input 
                value={orgData.legalEntityName}
                onChange={(e) => updateField("legalEntityName", e.target.value)}
                placeholder="Legal name for contracts"
                maxLength={150}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Organization Code <span className="text-destructive">*</span>
              </label>
              <Input 
                value={orgData.orgCode}
                onChange={(e) => updateField("orgCode", e.target.value.toUpperCase())}
                placeholder="e.g., MEDORG"
                maxLength={20}
              />
              <p className="text-xs text-muted-foreground mt-1">3-20 alphanumeric characters</p>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Organization Type <span className="text-destructive">*</span>
              </label>
              <select 
                className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                value={orgData.orgType}
                onChange={(e) => updateField("orgType", e.target.value)}
              >
                {ORG_TYPES.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Industry <span className="text-destructive">*</span>
              </label>
              <select 
                className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                value={orgData.industry}
                onChange={(e) => updateField("industry", e.target.value)}
              >
                {INDUSTRIES.map(ind => (
                  <option key={ind} value={ind}>{ind}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Time Zone <span className="text-destructive">*</span>
              </label>
              <select 
                className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                value={orgData.timeZone}
                onChange={(e) => updateField("timeZone", e.target.value)}
              >
                {TIMEZONES.map(tz => (
                  <option key={tz} value={tz}>{tz.replace("_", " ")}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Healthcare Identifiers */}
      <div className="card-section">
        <div className="p-4 border-b border-border">
          <h3 className="font-medium text-foreground flex items-center gap-2">
            <Hash className="w-4 h-4 text-muted-foreground" />
            Healthcare Identifiers
          </h3>
        </div>
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                NPI (National Provider Identifier)
              </label>
              <Input 
                value={orgData.npi}
                onChange={(e) => updateField("npi", e.target.value.replace(/\D/g, "").slice(0, 10))}
                placeholder="10 digits"
                maxLength={10}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Tax ID (EIN)
              </label>
              <Input 
                value={orgData.taxId}
                onChange={(e) => updateField("taxId", e.target.value)}
                placeholder="XX-XXXXXXX"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                CCN (CMS Certification Number)
              </label>
              <Input 
                value={orgData.ccn}
                onChange={(e) => updateField("ccn", e.target.value.slice(0, 6))}
                placeholder="6 characters"
                maxLength={6}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Accreditor
              </label>
              <select 
                className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                value={orgData.accreditor}
                onChange={(e) => updateField("accreditor", e.target.value)}
              >
                {ACCREDITOR_OPTIONS.map(acc => (
                  <option key={acc} value={acc}>{acc}</option>
                ))}
              </select>
            </div>
          </div>
          {orgData.accreditor === "Other" && (
            <div className="max-w-md">
              <label className="text-sm font-medium text-foreground block mb-2">
                Other Accreditor Name
              </label>
              <Input 
                value={orgData.accreditorOther}
                onChange={(e) => updateField("accreditorOther", e.target.value)}
                placeholder="Enter accreditor name"
                maxLength={100}
              />
            </div>
          )}
        </div>
      </div>

      {/* Primary Contact Information */}
      <div className="card-section">
        <div className="p-4 border-b border-border">
          <h3 className="font-medium text-foreground flex items-center gap-2">
            <Users className="w-4 h-4 text-muted-foreground" />
            Primary Contact Information
          </h3>
        </div>
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Primary Contact Name <span className="text-destructive">*</span>
              </label>
              <Input 
                value={orgData.primaryContactName}
                onChange={(e) => updateField("primaryContactName", e.target.value)}
                placeholder="Full name"
                maxLength={100}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Primary Contact Email <span className="text-destructive">*</span>
              </label>
              <Input 
                type="email"
                value={orgData.primaryContactEmail}
                onChange={(e) => updateField("primaryContactEmail", e.target.value)}
                placeholder="email@organization.com"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Primary Contact Phone
              </label>
              <Input 
                type="tel"
                value={orgData.primaryContactPhone}
                onChange={(e) => updateField("primaryContactPhone", e.target.value)}
                placeholder="+1 (555) 123-4567"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Implementation Owner
              </label>
              <Input 
                value={orgData.implementationOwner}
                onChange={(e) => updateField("implementationOwner", e.target.value)}
                placeholder="Project owner name"
                maxLength={100}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Secondary Compliance Contact
              </label>
              <Input 
                type="email"
                value={orgData.secondaryComplianceContact}
                onChange={(e) => updateField("secondaryComplianceContact", e.target.value)}
                placeholder="compliance@organization.com"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Address */}
      <div className="card-section">
        <div className="p-4 border-b border-border">
          <h3 className="font-medium text-foreground flex items-center gap-2">
            <MapPin className="w-4 h-4 text-muted-foreground" />
            Organization Address
          </h3>
        </div>
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Address Line 1 <span className="text-destructive">*</span>
              </label>
              <Input 
                value={orgData.addressLine1}
                onChange={(e) => updateField("addressLine1", e.target.value)}
                placeholder="Street address"
                maxLength={200}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Address Line 2
              </label>
              <Input 
                value={orgData.addressLine2}
                onChange={(e) => updateField("addressLine2", e.target.value)}
                placeholder="Suite, floor, etc."
                maxLength={200}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                City <span className="text-destructive">*</span>
              </label>
              <Input 
                value={orgData.city}
                onChange={(e) => updateField("city", e.target.value)}
                placeholder="City"
                maxLength={100}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                State <span className="text-destructive">*</span>
              </label>
              <select 
                className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                value={orgData.stateProvince}
                onChange={(e) => updateField("stateProvince", e.target.value)}
              >
                {US_STATES.map(state => (
                  <option key={state} value={state}>{state}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                ZIP Code <span className="text-destructive">*</span>
              </label>
              <Input 
                value={orgData.zipPostal}
                onChange={(e) => updateField("zipPostal", e.target.value)}
                placeholder="12345"
                maxLength={10}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Country <span className="text-destructive">*</span>
              </label>
              <Input 
                value={orgData.country}
                onChange={(e) => updateField("country", e.target.value)}
                placeholder="US"
                maxLength={2}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Organization Structure */}
      <div className="card-section">
        <div className="p-4 border-b border-border">
          <h3 className="font-medium text-foreground flex items-center gap-2">
            <Building2 className="w-4 h-4 text-muted-foreground" />
            Organization Structure
          </h3>
        </div>
        <div className="p-6 space-y-6">
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="singleFacility"
              checked={orgData.singleFacilityMode}
              onCheckedChange={(checked) => updateField("singleFacilityMode", !!checked)}
            />
            <label htmlFor="singleFacility" className="text-sm font-medium text-foreground cursor-pointer">
              Single Facility Mode
            </label>
          </div>
          
          {!orgData.singleFacilityMode && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Number of Facilities <span className="text-destructive">*</span>
                </label>
                <select 
                  className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                  value={orgData.numberOfFacilities}
                  onChange={(e) => updateField("numberOfFacilities", e.target.value)}
                >
                  {FACILITY_COUNT_OPTIONS.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Number of Departments <span className="text-destructive">*</span>
                </label>
                <select 
                  className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                  value={orgData.numberOfDepartments}
                  onChange={(e) => updateField("numberOfDepartments", e.target.value)}
                >
                  {DEPARTMENT_COUNT_OPTIONS.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Estimated Users <span className="text-destructive">*</span>
                </label>
                <select 
                  className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                  value={orgData.estimatedUsers}
                  onChange={(e) => updateField("estimatedUsers", e.target.value)}
                >
                  {USER_COUNT_OPTIONS.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Parent Organization */}
      <div className="card-section">
        <div className="p-4 border-b border-border">
          <h3 className="font-medium text-foreground flex items-center gap-2">
            <Building2 className="w-4 h-4 text-muted-foreground" />
            Parent Organization
          </h3>
        </div>
        <div className="p-6 space-y-6">
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="hasParent"
              checked={orgData.hasParentOrg}
              onCheckedChange={(checked) => updateField("hasParentOrg", !!checked)}
            />
            <label htmlFor="hasParent" className="text-sm font-medium text-foreground cursor-pointer">
              This organization has a parent organization
            </label>
          </div>
          
          {orgData.hasParentOrg && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Parent Organization Name
                </label>
                <Input 
                  value={orgData.parentOrgName}
                  onChange={(e) => updateField("parentOrgName", e.target.value)}
                  placeholder="Parent organization name"
                  maxLength={100}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Parent Organization Code
                </label>
                <Input 
                  value={orgData.parentOrgCode}
                  onChange={(e) => updateField("parentOrgCode", e.target.value.toUpperCase())}
                  placeholder="PARENTORG"
                  maxLength={20}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button 
          className="bg-accent text-accent-foreground hover:bg-accent/90"
          onClick={handleSave}
        >
          Save Changes
        </Button>
      </div>
    </div>
  );
}

interface Facility {
  id: number;
  name: string;
  code: string;
  type: string;
  sameAsOrgAddress: boolean;
  address: string;
  city: string;
  stateProvince: string;
  country: string;
  zipPostal: string;
  timeZone: string;
  isParent: boolean;
  parentFacilityId: number | null;
  departments: number;
  status: "active" | "inactive";
}

interface FacilityFormData {
  name: string;
  code: string;
  type: string;
  sameAsOrgAddress: boolean;
  address: string;
  city: string;
  stateProvince: string;
  country: string;
  zipPostal: string;
  timeZone: string;
  isParent: boolean;
  parentFacilityId: number | null;
}

function FacilitiesConfig() {
  const [facilities, setFacilities] = useState<Facility[]>([
    { 
      id: 1, 
      name: "Main Hospital", 
      code: "MAIN",
      type: "Hospital", 
      sameAsOrgAddress: true,
      address: "123 Healthcare Drive", 
      city: "Medical City",
      stateProvince: "CA",
      country: "US",
      zipPostal: "12345",
      timeZone: "America/Los_Angeles",
      isParent: true,
      parentFacilityId: null,
      departments: 4, 
      status: "active" 
    },
    { 
      id: 2, 
      name: "East Wing", 
      code: "EAST",
      type: "Annex", 
      sameAsOrgAddress: false,
      address: "125 Healthcare Drive", 
      city: "Medical City",
      stateProvince: "CA",
      country: "US",
      zipPostal: "12345",
      timeZone: "America/Los_Angeles",
      isParent: false,
      parentFacilityId: 1,
      departments: 2, 
      status: "active" 
    },
    { 
      id: 3, 
      name: "Cancer Center", 
      code: "ONCO",
      type: "Specialty Center", 
      sameAsOrgAddress: false,
      address: "200 Oncology Lane", 
      city: "Medical City",
      stateProvince: "CA",
      country: "US",
      zipPostal: "12346",
      timeZone: "America/Los_Angeles",
      isParent: false,
      parentFacilityId: 1,
      departments: 1, 
      status: "active" 
    },
    { 
      id: 4, 
      name: "Children's Wing", 
      code: "PEDS",
      type: "Specialty Center", 
      sameAsOrgAddress: false,
      address: "300 Pediatric Way", 
      city: "Medical City",
      stateProvince: "CA",
      country: "US",
      zipPostal: "12347",
      timeZone: "America/Los_Angeles",
      isParent: false,
      parentFacilityId: 1,
      departments: 1, 
      status: "active" 
    },
  ]);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedFacility, setSelectedFacility] = useState<Facility | null>(null);
  const [formData, setFormData] = useState<FacilityFormData>({ 
    name: "", 
    code: "",
    type: "Hospital", 
    sameAsOrgAddress: false,
    address: "",
    city: "",
    stateProvince: "CA",
    country: "US",
    zipPostal: "",
    timeZone: "America/Los_Angeles",
    isParent: false,
    parentFacilityId: null,
  });
  const [isEditing, setIsEditing] = useState(false);

  const parentFacilities = facilities.filter(f => f.isParent);

  const handleCreate = () => {
    setFormData({ 
      name: "", 
      code: "",
      type: "Hospital", 
      sameAsOrgAddress: false,
      address: "",
      city: "",
      stateProvince: "CA",
      country: "US",
      zipPostal: "",
      timeZone: "America/Los_Angeles",
      isParent: false,
      parentFacilityId: null,
    });
    setIsEditing(false);
    setDialogOpen(true);
  };

  const handleEdit = (facility: Facility) => {
    setFormData({ 
      name: facility.name, 
      code: facility.code,
      type: facility.type, 
      sameAsOrgAddress: facility.sameAsOrgAddress,
      address: facility.address,
      city: facility.city,
      stateProvince: facility.stateProvince,
      country: facility.country,
      zipPostal: facility.zipPostal,
      timeZone: facility.timeZone,
      isParent: facility.isParent,
      parentFacilityId: facility.parentFacilityId,
    });
    setSelectedFacility(facility);
    setIsEditing(true);
    setDialogOpen(true);
  };

  const handleView = (facility: Facility) => {
    setSelectedFacility(facility);
    setViewDialogOpen(true);
  };

  const handleDeleteClick = (facility: Facility) => {
    setSelectedFacility(facility);
    setDeleteDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.name || !formData.code) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (!formData.sameAsOrgAddress && (!formData.address || !formData.city || !formData.zipPostal)) {
      toast.error("Please fill in address details or select 'Same as organization address'");
      return;
    }

    if (isEditing && selectedFacility) {
      setFacilities(facilities.map(f => 
        f.id === selectedFacility.id 
          ? { 
              ...f, 
              name: formData.name, 
              code: formData.code,
              type: formData.type, 
              sameAsOrgAddress: formData.sameAsOrgAddress,
              address: formData.address,
              city: formData.city,
              stateProvince: formData.stateProvince,
              country: formData.country,
              zipPostal: formData.zipPostal,
              timeZone: formData.timeZone,
              isParent: formData.isParent,
              parentFacilityId: formData.parentFacilityId,
            }
          : f
      ));
      toast.success("Facility updated successfully");
    } else {
      const newFacility: Facility = {
        id: Math.max(...facilities.map(f => f.id)) + 1,
        name: formData.name,
        code: formData.code,
        type: formData.type,
        sameAsOrgAddress: formData.sameAsOrgAddress,
        address: formData.address,
        city: formData.city,
        stateProvince: formData.stateProvince,
        country: formData.country,
        zipPostal: formData.zipPostal,
        timeZone: formData.timeZone,
        isParent: formData.isParent,
        parentFacilityId: formData.parentFacilityId,
        departments: 0,
        status: "active",
      };
      setFacilities([...facilities, newFacility]);
      toast.success("Facility created successfully");
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (selectedFacility) {
      setFacilities(facilities.filter(f => f.id !== selectedFacility.id));
      toast.success("Facility deactivated successfully");
    }
    setDeleteDialogOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Facilities</h2>
          <p className="text-sm text-muted-foreground">
            Manage physical locations and their configurations
          </p>
        </div>
        <Button 
          size="sm" 
          className="bg-accent text-accent-foreground hover:bg-accent/90"
          onClick={handleCreate}
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Facility
        </Button>
      </div>

      <div className="card-section">
        <div className="divide-y divide-border">
          {facilities.map((facility) => (
            <div
              key={facility.id}
              className="p-4 flex items-center gap-4 hover:bg-muted/50 transition-colors group"
            >
              <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                <Building2 className="w-5 h-5 text-accent" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-foreground">{facility.name}</p>
                  <Badge variant="outline" className="text-xs">{facility.code}</Badge>
                  <Badge variant="outline" className="text-xs">{facility.type}</Badge>
                  {facility.isParent && (
                    <Badge variant="secondary" className="text-xs">Parent</Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  {facility.city}, {facility.stateProvince} • {facility.departments} departments
                </p>
              </div>
              <Badge variant="outline" className="text-success border-success/30 bg-success/5">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Active
              </Badge>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button variant="ghost" size="icon" onClick={() => handleView(facility)}>
                  <Eye className="w-4 h-4 text-muted-foreground" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleEdit(facility)}>
                  <Pencil className="w-4 h-4 text-muted-foreground" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleDeleteClick(facility)}>
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{isEditing ? "Edit Facility" : "Add New Facility"}</DialogTitle>
            <DialogDescription>
              {isEditing ? "Update the facility information below." : "Enter the details for the new facility."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            {/* Basic Info */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Facility Name <span className="text-destructive">*</span>
                </label>
                <Input 
                  value={formData.name} 
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter facility name"
                  maxLength={100}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Facility Code <span className="text-destructive">*</span>
                </label>
                <Input 
                  value={formData.code} 
                  onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                  placeholder="e.g., MAIN"
                  maxLength={20}
                />
                <p className="text-xs text-muted-foreground mt-1">2-20 alphanumeric characters</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">Facility Type <span className="text-destructive">*</span></label>
                <select 
                  className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                >
                  {FACILITY_TYPES.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">Time Zone <span className="text-destructive">*</span></label>
                <select 
                  className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                  value={formData.timeZone}
                  onChange={(e) => setFormData({ ...formData, timeZone: e.target.value })}
                >
                  {TIMEZONES.map(tz => (
                    <option key={tz} value={tz}>{tz.replace("_", " ")}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Parent Facility */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="isParent"
                  checked={formData.isParent}
                  onCheckedChange={(checked) => setFormData({ ...formData, isParent: !!checked, parentFacilityId: null })}
                />
                <label htmlFor="isParent" className="text-sm font-medium text-foreground cursor-pointer">
                  This is a parent facility
                </label>
              </div>
              
              {!formData.isParent && parentFacilities.length > 0 && (
                <div>
                  <label className="text-sm font-medium text-foreground block mb-2">Parent Facility</label>
                  <select 
                    className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                    value={formData.parentFacilityId || ""}
                    onChange={(e) => setFormData({ ...formData, parentFacilityId: e.target.value ? Number(e.target.value) : null })}
                  >
                    <option value="">None</option>
                    {parentFacilities.map(f => (
                      <option key={f.id} value={f.id}>{f.name}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {/* Address */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="sameAddress"
                  checked={formData.sameAsOrgAddress}
                  onCheckedChange={(checked) => setFormData({ ...formData, sameAsOrgAddress: !!checked })}
                />
                <label htmlFor="sameAddress" className="text-sm font-medium text-foreground cursor-pointer">
                  Same as organization address
                </label>
              </div>
              
              <div className={formData.sameAsOrgAddress ? "opacity-50 pointer-events-none" : ""}>
                <div className="mb-4">
                  <label className="text-sm font-medium text-foreground block mb-2">
                    Address {!formData.sameAsOrgAddress && <span className="text-destructive">*</span>}
                  </label>
                  <Input 
                    value={formData.address} 
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    placeholder="Enter street address"
                    maxLength={200}
                    disabled={formData.sameAsOrgAddress}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="text-sm font-medium text-foreground block mb-2">
                      City {!formData.sameAsOrgAddress && <span className="text-destructive">*</span>}
                    </label>
                    <Input 
                      value={formData.city} 
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      placeholder="City"
                      maxLength={100}
                      disabled={formData.sameAsOrgAddress}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground block mb-2">
                      State {!formData.sameAsOrgAddress && <span className="text-destructive">*</span>}
                    </label>
                    <select 
                      className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md disabled:opacity-50"
                      value={formData.stateProvince}
                      onChange={(e) => setFormData({ ...formData, stateProvince: e.target.value })}
                      disabled={formData.sameAsOrgAddress}
                    >
                      {US_STATES.map(state => (
                        <option key={state} value={state}>{state}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-foreground block mb-2">
                      ZIP Code {!formData.sameAsOrgAddress && <span className="text-destructive">*</span>}
                    </label>
                    <Input 
                      value={formData.zipPostal} 
                      onChange={(e) => setFormData({ ...formData, zipPostal: e.target.value })}
                      placeholder="12345"
                      maxLength={10}
                      disabled={formData.sameAsOrgAddress}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground block mb-2">Country</label>
                    <Input 
                      value={formData.country} 
                      onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                      placeholder="US"
                      maxLength={2}
                      disabled={formData.sameAsOrgAddress}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={handleSave}>
              {isEditing ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Facility Details</DialogTitle>
          </DialogHeader>
          {selectedFacility && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{selectedFacility.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline">{selectedFacility.code}</Badge>
                    <Badge variant="outline">{selectedFacility.type}</Badge>
                    {selectedFacility.isParent && <Badge variant="secondary">Parent</Badge>}
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Address</p>
                  <p className="font-medium text-foreground">
                    {selectedFacility.sameAsOrgAddress ? "(Same as organization)" : selectedFacility.address}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Location</p>
                  <p className="font-medium text-foreground">
                    {selectedFacility.city}, {selectedFacility.stateProvince} {selectedFacility.zipPostal}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Time Zone</p>
                  <p className="font-medium text-foreground">{selectedFacility.timeZone.replace("_", " ")}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Departments</p>
                  <p className="font-medium text-foreground">{selectedFacility.departments}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Status</p>
                  <Badge variant="outline" className="text-success border-success/30 bg-success/5 mt-1">
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    {selectedFacility.status}
                  </Badge>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewDialogOpen(false)}>Close</Button>
            <Button 
              className="bg-accent text-accent-foreground hover:bg-accent/90"
              onClick={() => {
                setViewDialogOpen(false);
                if (selectedFacility) handleEdit(selectedFacility);
              }}
            >
              <Pencil className="w-4 h-4 mr-2" />
              Edit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Deactivate Facility?</AlertDialogTitle>
            <AlertDialogDescription>
              This will deactivate "{selectedFacility?.name}". The facility and its data will be preserved but marked as inactive. This action can be reversed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleDelete}
            >
              Deactivate
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

interface Department {
  id: number;
  name: string;
  code: string;
  description: string;
  facilityIds: number[];
  status: "active" | "inactive";
}

interface DepartmentFormData {
  name: string;
  code: string;
  description: string;
  facilityIds: number[];
}

function DepartmentsConfig() {
  const facilities = [
    { id: 1, name: "Main Hospital" },
    { id: 2, name: "East Wing" },
    { id: 3, name: "Cancer Center" },
    { id: 4, name: "Children's Wing" },
  ];

  const [departments, setDepartments] = useState<Department[]>([
    { id: 1, name: "Cardiology", code: "CARD", description: "Cardiovascular services and care", facilityIds: [1], status: "active" },
    { id: 2, name: "Emergency", code: "EMER", description: "Emergency and trauma services", facilityIds: [1], status: "active" },
    { id: 3, name: "Radiology", code: "RAD", description: "Imaging and diagnostic services", facilityIds: [1, 2], status: "active" },
    { id: 4, name: "Pharmacy", code: "PHAR", description: "Medication dispensing and management", facilityIds: [1, 2, 3, 4], status: "active" },
    { id: 5, name: "Nursing", code: "NURS", description: "General nursing services", facilityIds: [2], status: "active" },
    { id: 6, name: "Laboratory", code: "LAB", description: "Clinical laboratory services", facilityIds: [2], status: "active" },
    { id: 7, name: "Oncology", code: "ONCO", description: "Cancer treatment and care", facilityIds: [3], status: "active" },
    { id: 8, name: "Pediatrics", code: "PEDS", description: "Children's health services", facilityIds: [4], status: "active" },
  ]);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState<Department | null>(null);
  const [formData, setFormData] = useState<DepartmentFormData>({ 
    name: "", 
    code: "",
    description: "",
    facilityIds: [] 
  });
  const [isEditing, setIsEditing] = useState(false);

  const getFacilityNames = (ids: number[]) => {
    return facilities.filter(f => ids.includes(f.id)).map(f => f.name).join(", ");
  };

  const handleCreate = () => {
    setFormData({ name: "", code: "", description: "", facilityIds: [] });
    setIsEditing(false);
    setDialogOpen(true);
  };

  const handleEdit = (dept: Department) => {
    setFormData({ 
      name: dept.name, 
      code: dept.code,
      description: dept.description,
      facilityIds: dept.facilityIds 
    });
    setSelectedDepartment(dept);
    setIsEditing(true);
    setDialogOpen(true);
  };

  const handleView = (dept: Department) => {
    setSelectedDepartment(dept);
    setViewDialogOpen(true);
  };

  const handleDeleteClick = (dept: Department) => {
    setSelectedDepartment(dept);
    setDeleteDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.name || !formData.code) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (formData.facilityIds.length === 0) {
      toast.error("Please select at least one facility");
      return;
    }

    if (isEditing && selectedDepartment) {
      setDepartments(departments.map(d => 
        d.id === selectedDepartment.id 
          ? { 
              ...d, 
              name: formData.name, 
              code: formData.code,
              description: formData.description,
              facilityIds: formData.facilityIds 
            }
          : d
      ));
      toast.success("Department updated successfully");
    } else {
      const newDept: Department = {
        id: Math.max(...departments.map(d => d.id)) + 1,
        name: formData.name,
        code: formData.code,
        description: formData.description,
        facilityIds: formData.facilityIds,
        status: "active",
      };
      setDepartments([...departments, newDept]);
      toast.success("Department created successfully");
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (selectedDepartment) {
      setDepartments(departments.filter(d => d.id !== selectedDepartment.id));
      toast.success("Department deactivated successfully");
    }
    setDeleteDialogOpen(false);
  };

  const toggleFacility = (facilityId: number) => {
    if (formData.facilityIds.includes(facilityId)) {
      setFormData({ ...formData, facilityIds: formData.facilityIds.filter(id => id !== facilityId) });
    } else {
      setFormData({ ...formData, facilityIds: [...formData.facilityIds, facilityId] });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Departments</h2>
          <p className="text-sm text-muted-foreground">
            Manage departments and their facility assignments
          </p>
        </div>
        <Button 
          size="sm" 
          className="bg-accent text-accent-foreground hover:bg-accent/90"
          onClick={handleCreate}
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Department
        </Button>
      </div>

      <div className="card-section">
        <div className="divide-y divide-border">
          {departments.map((dept) => (
            <div
              key={dept.id}
              className="p-4 flex items-center gap-4 hover:bg-muted/50 transition-colors group"
            >
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <MapPin className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-foreground">{dept.name}</p>
                  <Badge variant="outline" className="text-xs">{dept.code}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {getFacilityNames(dept.facilityIds)}
                </p>
              </div>
              <Badge variant="outline" className="text-success border-success/30 bg-success/5">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Active
              </Badge>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button variant="ghost" size="icon" onClick={() => handleView(dept)}>
                  <Eye className="w-4 h-4 text-muted-foreground" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleEdit(dept)}>
                  <Pencil className="w-4 h-4 text-muted-foreground" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleDeleteClick(dept)}>
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{isEditing ? "Edit Department" : "Add New Department"}</DialogTitle>
            <DialogDescription>
              {isEditing ? "Update the department information below." : "Enter the details for the new department."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Department Name <span className="text-destructive">*</span>
                </label>
                <Input 
                  value={formData.name} 
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter department name"
                  maxLength={100}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Department Code <span className="text-destructive">*</span>
                </label>
                <Input 
                  value={formData.code} 
                  onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                  placeholder="e.g., CARD"
                  maxLength={20}
                />
                <p className="text-xs text-muted-foreground mt-1">2-20 alphanumeric characters</p>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">Description</label>
              <Textarea 
                value={formData.description} 
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Brief description of the department"
                maxLength={500}
                rows={3}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Assigned Facilities <span className="text-destructive">*</span>
              </label>
              <div className="space-y-2 border border-input rounded-md p-3">
                {facilities.map(facility => (
                  <div key={facility.id} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`facility-${facility.id}`}
                      checked={formData.facilityIds.includes(facility.id)}
                      onCheckedChange={() => toggleFacility(facility.id)}
                    />
                    <label 
                      htmlFor={`facility-${facility.id}`} 
                      className="text-sm text-foreground cursor-pointer"
                    >
                      {facility.name}
                    </label>
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Select at least one facility</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={handleSave}>
              {isEditing ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Department Details</DialogTitle>
          </DialogHeader>
          {selectedDepartment && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{selectedDepartment.name}</h3>
                  <Badge variant="outline">{selectedDepartment.code}</Badge>
                </div>
              </div>
              <div className="space-y-3 text-sm">
                <div>
                  <p className="text-muted-foreground">Description</p>
                  <p className="font-medium text-foreground">{selectedDepartment.description || "—"}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Assigned Facilities</p>
                  <p className="font-medium text-foreground">{getFacilityNames(selectedDepartment.facilityIds)}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Status</p>
                  <Badge variant="outline" className="text-success border-success/30 bg-success/5 mt-1">
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    {selectedDepartment.status}
                  </Badge>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewDialogOpen(false)}>Close</Button>
            <Button 
              className="bg-accent text-accent-foreground hover:bg-accent/90"
              onClick={() => {
                setViewDialogOpen(false);
                if (selectedDepartment) handleEdit(selectedDepartment);
              }}
            >
              <Pencil className="w-4 h-4 mr-2" />
              Edit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Deactivate Department?</AlertDialogTitle>
            <AlertDialogDescription>
              This will deactivate "{selectedDepartment?.name}". The department and its data will be preserved but marked as inactive. This action can be reversed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleDelete}
            >
              Deactivate
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
