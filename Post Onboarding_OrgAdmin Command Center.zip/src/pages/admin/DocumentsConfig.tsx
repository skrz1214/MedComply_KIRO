import { Button } from "@/components/ui/button";
import { FileText, Plus, ChevronRight, CheckCircle2, Clock, Lock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export default function DocumentsConfig() {
  const documents = [
    { id: 1, name: "Infection Control Policy", type: "Policy", status: "published", version: "v3.2", controlled: true },
    { id: 2, name: "Hand Hygiene Procedure", type: "SOP", status: "published", version: "v2.1", controlled: true },
    { id: 3, name: "Emergency Response Plan", type: "Plan", status: "review", version: "v1.5", controlled: true },
    { id: 4, name: "Staff Training Guide", type: "Guide", status: "draft", version: "v1.0", controlled: false },
    { id: 5, name: "HIPAA Compliance Checklist", type: "Checklist", status: "published", version: "v4.0", controlled: true },
  ];

  const statusConfig = {
    published: { label: "Published", icon: CheckCircle2, color: "text-success bg-success/10" },
    review: { label: "In Review", icon: Clock, color: "text-warning bg-warning/10" },
    draft: { label: "Draft", icon: Clock, color: "text-muted-foreground bg-muted" },
  };

  return (
    <div className="animate-fade-in">
      <div className="border-b border-border bg-card">
        <div className="p-6 max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <FileText className="w-7 h-7 text-accent" />
            Documents Governance
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage controlled documents, policies, and procedures
          </p>
        </div>
      </div>

      <div className="p-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-foreground">Controlled Documents</h2>
          <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90">
            <Plus className="w-4 h-4 mr-2" />
            New Document
          </Button>
        </div>

        <div className="card-section">
          <div className="divide-y divide-border">
            {documents.map((doc) => {
              const status = statusConfig[doc.status as keyof typeof statusConfig];
              const StatusIcon = status.icon;
              return (
                <div
                  key={doc.id}
                  className="p-4 flex items-center gap-4 hover:bg-muted/50 transition-colors cursor-pointer"
                >
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <FileText className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-foreground">{doc.name}</p>
                      {doc.controlled && (
                        <Lock className="w-3 h-3 text-muted-foreground" />
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {doc.type} • {doc.version}
                    </p>
                  </div>
                  <Badge className={cn("gap-1", status.color)}>
                    <StatusIcon className="w-3 h-3" />
                    {status.label}
                  </Badge>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
