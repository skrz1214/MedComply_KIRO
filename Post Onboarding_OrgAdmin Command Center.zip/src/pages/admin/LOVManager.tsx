import { useState } from "react";
import { Button } from "@/components/ui/button";
import { List, Plus, ChevronRight, Settings, Edit2, Trash2, X, Check, Building2, Users, Shield, FileText } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";

interface LOVItem {
  id: string;
  value: string;
  label: string;
  isActive: boolean;
  sortOrder: number;
}

interface LOVSet {
  id: string;
  name: string;
  code: string;
  category: "onboarding" | "compliance" | "general";
  scope: string;
  lastModified: string;
  items: LOVItem[];
}

const initialLOVSets: LOVSet[] = [
  // Onboarding LOVs
  {
    id: "1",
    name: "Organization Types",
    code: "ORG_TYPES",
    category: "onboarding",
    scope: "Organization",
    lastModified: "Jan 15, 2024",
    items: [
      { id: "1-1", value: "hospital", label: "Hospital", isActive: true, sortOrder: 1 },
      { id: "1-2", value: "clinic", label: "Clinic", isActive: true, sortOrder: 2 },
      { id: "1-3", value: "laboratory", label: "Laboratory", isActive: true, sortOrder: 3 },
      { id: "1-4", value: "pharmacy", label: "Pharmacy", isActive: true, sortOrder: 4 },
      { id: "1-5", value: "nursing_home", label: "Nursing Home", isActive: true, sortOrder: 5 },
    ],
  },
  {
    id: "2",
    name: "Industry Types",
    code: "INDUSTRY_TYPES",
    category: "onboarding",
    scope: "Organization",
    lastModified: "Jan 14, 2024",
    items: [
      { id: "2-1", value: "healthcare", label: "Healthcare", isActive: true, sortOrder: 1 },
      { id: "2-2", value: "pharmaceuticals", label: "Pharmaceuticals", isActive: true, sortOrder: 2 },
      { id: "2-3", value: "medical_devices", label: "Medical Devices", isActive: true, sortOrder: 3 },
      { id: "2-4", value: "biotech", label: "Biotechnology", isActive: true, sortOrder: 4 },
      { id: "2-5", value: "research", label: "Research Institution", isActive: true, sortOrder: 5 },
    ],
  },
  {
    id: "3",
    name: "Regulatory Bodies",
    code: "REGULATORY_BODIES",
    category: "onboarding",
    scope: "Organization",
    lastModified: "Jan 12, 2024",
    items: [
      { id: "3-1", value: "nabh", label: "NABH", isActive: true, sortOrder: 1 },
      { id: "3-2", value: "jci", label: "JCI", isActive: true, sortOrder: 2 },
      { id: "3-3", value: "nabl", label: "NABL", isActive: true, sortOrder: 3 },
      { id: "3-4", value: "cdsco", label: "CDSCO", isActive: true, sortOrder: 4 },
      { id: "3-5", value: "iso", label: "ISO", isActive: true, sortOrder: 5 },
    ],
  },
  {
    id: "4",
    name: "Department Types",
    code: "DEPT_TYPES",
    category: "onboarding",
    scope: "Organization",
    lastModified: "Jan 10, 2024",
    items: [
      { id: "4-1", value: "quality", label: "Quality Assurance", isActive: true, sortOrder: 1 },
      { id: "4-2", value: "operations", label: "Operations", isActive: true, sortOrder: 2 },
      { id: "4-3", value: "nursing", label: "Nursing", isActive: true, sortOrder: 3 },
      { id: "4-4", value: "admin", label: "Administration", isActive: true, sortOrder: 4 },
      { id: "4-5", value: "hr", label: "Human Resources", isActive: true, sortOrder: 5 },
      { id: "4-6", value: "it", label: "IT", isActive: true, sortOrder: 6 },
    ],
  },
  {
    id: "5",
    name: "User Roles",
    code: "USER_ROLES",
    category: "onboarding",
    scope: "Organization",
    lastModified: "Jan 8, 2024",
    items: [
      { id: "5-1", value: "org_admin", label: "Organization Admin", isActive: true, sortOrder: 1 },
      { id: "5-2", value: "compliance_head", label: "Compliance Head", isActive: true, sortOrder: 2 },
      { id: "5-3", value: "dept_head", label: "Department Head", isActive: true, sortOrder: 3 },
      { id: "5-4", value: "staff", label: "Staff", isActive: true, sortOrder: 4 },
    ],
  },
];

const getCategoryIcon = (category: LOVSet["category"]) => {
  switch (category) {
    case "onboarding":
      return Building2;
    case "compliance":
      return Shield;
    default:
      return FileText;
  }
};

const getCategoryColor = (category: LOVSet["category"]) => {
  switch (category) {
    case "onboarding":
      return "bg-blue-500/10 text-blue-600";
    case "compliance":
      return "bg-amber-500/10 text-amber-600";
    default:
      return "bg-muted text-muted-foreground";
  }
};

export default function LOVManager() {
  const { toast } = useToast();
  const [lovSets, setLovSets] = useState<LOVSet[]>(initialLOVSets);
  const [selectedLOV, setSelectedLOV] = useState<LOVSet | null>(null);
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [isCreateSetDialogOpen, setIsCreateSetDialogOpen] = useState(false);
  const [isCreateItemDialogOpen, setIsCreateItemDialogOpen] = useState(false);
  const [isEditItemDialogOpen, setIsEditItemDialogOpen] = useState(false);
  const [isDeleteItemDialogOpen, setIsDeleteItemDialogOpen] = useState(false);
  const [isDeleteSetDialogOpen, setIsDeleteSetDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<LOVItem | null>(null);
  const [deletingItem, setDeletingItem] = useState<LOVItem | null>(null);
  const [filterCategory, setFilterCategory] = useState<"all" | "onboarding" | "compliance" | "general">("all");

  const [newSetForm, setNewSetForm] = useState({ name: "", code: "", category: "onboarding" as LOVSet["category"] });
  const [newItemForm, setNewItemForm] = useState({ value: "", label: "", isActive: true });
  const [editItemForm, setEditItemForm] = useState({ value: "", label: "", isActive: true });

  const filteredLOVSets = lovSets;

  const handleOpenLOV = (lov: LOVSet) => {
    setSelectedLOV(lov);
    setIsSheetOpen(true);
  };

  const handleCreateSet = () => {
    if (!newSetForm.name || !newSetForm.code) {
      toast({ title: "Error", description: "Name and code are required", variant: "destructive" });
      return;
    }
    const newSet: LOVSet = {
      id: Date.now().toString(),
      name: newSetForm.name,
      code: newSetForm.code.toUpperCase().replace(/\s+/g, "_"),
      category: newSetForm.category,
      scope: "Organization",
      lastModified: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      items: [],
    };
    setLovSets([...lovSets, newSet]);
    setNewSetForm({ name: "", code: "", category: "onboarding" });
    setIsCreateSetDialogOpen(false);
    toast({ title: "Success", description: `Value set "${newSet.name}" created` });
  };

  const handleDeleteSet = () => {
    if (!selectedLOV) return;
    setLovSets(lovSets.filter(lov => lov.id !== selectedLOV.id));
    setIsDeleteSetDialogOpen(false);
    setIsSheetOpen(false);
    setSelectedLOV(null);
    toast({ title: "Success", description: "Value set deleted" });
  };

  const handleCreateItem = () => {
    if (!selectedLOV || !newItemForm.value || !newItemForm.label) {
      toast({ title: "Error", description: "Value and label are required", variant: "destructive" });
      return;
    }
    const newItem: LOVItem = {
      id: `${selectedLOV.id}-${Date.now()}`,
      value: newItemForm.value.toLowerCase().replace(/\s+/g, "_"),
      label: newItemForm.label,
      isActive: newItemForm.isActive,
      sortOrder: selectedLOV.items.length + 1,
    };
    const updatedLOV = { ...selectedLOV, items: [...selectedLOV.items, newItem] };
    setLovSets(lovSets.map(lov => lov.id === selectedLOV.id ? updatedLOV : lov));
    setSelectedLOV(updatedLOV);
    setNewItemForm({ value: "", label: "", isActive: true });
    setIsCreateItemDialogOpen(false);
    toast({ title: "Success", description: `Item "${newItem.label}" added` });
  };

  const handleEditItem = () => {
    if (!selectedLOV || !editingItem || !editItemForm.value || !editItemForm.label) {
      toast({ title: "Error", description: "Value and label are required", variant: "destructive" });
      return;
    }
    const updatedItems = selectedLOV.items.map(item =>
      item.id === editingItem.id
        ? { ...item, value: editItemForm.value.toLowerCase().replace(/\s+/g, "_"), label: editItemForm.label, isActive: editItemForm.isActive }
        : item
    );
    const updatedLOV = { ...selectedLOV, items: updatedItems };
    setLovSets(lovSets.map(lov => lov.id === selectedLOV.id ? updatedLOV : lov));
    setSelectedLOV(updatedLOV);
    setEditingItem(null);
    setIsEditItemDialogOpen(false);
    toast({ title: "Success", description: "Item updated" });
  };

  const handleDeleteItem = () => {
    if (!selectedLOV || !deletingItem) return;
    const updatedItems = selectedLOV.items.filter(item => item.id !== deletingItem.id);
    const updatedLOV = { ...selectedLOV, items: updatedItems };
    setLovSets(lovSets.map(lov => lov.id === selectedLOV.id ? updatedLOV : lov));
    setSelectedLOV(updatedLOV);
    setDeletingItem(null);
    setIsDeleteItemDialogOpen(false);
    toast({ title: "Success", description: "Item deleted" });
  };

  const openEditItemDialog = (item: LOVItem) => {
    setEditingItem(item);
    setEditItemForm({ value: item.value, label: item.label, isActive: item.isActive });
    setIsEditItemDialogOpen(true);
  };

  const openDeleteItemDialog = (item: LOVItem) => {
    setDeletingItem(item);
    setIsDeleteItemDialogOpen(true);
  };

  return (
    <div className="animate-fade-in">
      <div className="border-b border-border bg-card">
        <div className="p-6 max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <List className="w-7 h-7 text-accent" />
            LOV Manager
          </h1>
          <p className="text-muted-foreground mt-1">
            Configure dropdown options and standardized value sets
          </p>
        </div>
      </div>

      <div className="p-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-foreground">
            Value Sets
          </h2>
          <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={() => setIsCreateSetDialogOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Create Value Set
          </Button>
        </div>

        <div className="card-section">
          <div className="divide-y divide-border">
            {filteredLOVSets.map((lov) => {
              const CategoryIcon = getCategoryIcon(lov.category);
              return (
                <div
                  key={lov.id}
                  onClick={() => handleOpenLOV(lov)}
                  className="p-4 flex items-center gap-4 hover:bg-muted/50 transition-colors cursor-pointer group"
                >
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getCategoryColor(lov.category)}`}>
                    <CategoryIcon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground">{lov.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {lov.items.length} items • Code: {lov.code} • Last modified {lov.lastModified}
                    </p>
                  </div>
                  <Badge variant="outline" className="capitalize">{lov.category}</Badge>
                  <Badge variant="outline">{lov.scope}</Badge>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* LOV Items Sheet */}
      <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
        <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <List className="w-5 h-5" />
              {selectedLOV?.name}
            </SheetTitle>
            <SheetDescription>
              Code: {selectedLOV?.code} • {selectedLOV?.items.length} items
            </SheetDescription>
          </SheetHeader>

          <div className="mt-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium text-foreground">Items</h3>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => setIsDeleteSetDialogOpen(true)}>
                  <Trash2 className="w-4 h-4 mr-1" />
                  Delete Set
                </Button>
                <Button size="sm" onClick={() => setIsCreateItemDialogOpen(true)}>
                  <Plus className="w-4 h-4 mr-1" />
                  Add Item
                </Button>
              </div>
            </div>

            <div className="border rounded-lg divide-y divide-border">
              {selectedLOV?.items.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground">
                  No items yet. Click "Add Item" to create one.
                </div>
              ) : (
                selectedLOV?.items.map((item) => (
                  <div key={item.id} className="p-3 flex items-center gap-3 group hover:bg-muted/50">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground">{item.label}</p>
                      <p className="text-sm text-muted-foreground">Value: {item.value}</p>
                    </div>
                    <Badge variant={item.isActive ? "default" : "secondary"}>
                      {item.isActive ? "Active" : "Inactive"}
                    </Badge>
                    <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100" onClick={() => openEditItemDialog(item)}>
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 text-destructive" onClick={() => openDeleteItemDialog(item)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))
              )}
            </div>
          </div>
        </SheetContent>
      </Sheet>

      {/* Create Value Set Dialog */}
      <Dialog open={isCreateSetDialogOpen} onOpenChange={setIsCreateSetDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Value Set</DialogTitle>
            <DialogDescription>Add a new list of values for dropdowns and selections.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input id="name" placeholder="e.g., Priority Levels" value={newSetForm.name} onChange={(e) => setNewSetForm({ ...newSetForm, name: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="code">Code</Label>
              <Input id="code" placeholder="e.g., PRIORITY_LEVELS" value={newSetForm.code} onChange={(e) => setNewSetForm({ ...newSetForm, code: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Category</Label>
              <div className="flex gap-2">
                {["onboarding", "compliance", "general"].map((cat) => (
                  <Button
                    key={cat}
                    type="button"
                    variant={newSetForm.category === cat ? "default" : "outline"}
                    size="sm"
                    onClick={() => setNewSetForm({ ...newSetForm, category: cat as LOVSet["category"] })}
                    className="capitalize"
                  >
                    {cat}
                  </Button>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateSetDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreateSet}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Item Dialog */}
      <Dialog open={isCreateItemDialogOpen} onOpenChange={setIsCreateItemDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Item</DialogTitle>
            <DialogDescription>Add a new item to "{selectedLOV?.name}"</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="label">Label</Label>
              <Input id="label" placeholder="Display name" value={newItemForm.label} onChange={(e) => setNewItemForm({ ...newItemForm, label: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="value">Value</Label>
              <Input id="value" placeholder="Internal value" value={newItemForm.value} onChange={(e) => setNewItemForm({ ...newItemForm, value: e.target.value })} />
            </div>
            <div className="flex items-center gap-2">
              <Switch id="active" checked={newItemForm.isActive} onCheckedChange={(checked) => setNewItemForm({ ...newItemForm, isActive: checked })} />
              <Label htmlFor="active">Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateItemDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreateItem}>Add Item</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Item Dialog */}
      <Dialog open={isEditItemDialogOpen} onOpenChange={setIsEditItemDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Item</DialogTitle>
            <DialogDescription>Update the item details</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-label">Label</Label>
              <Input id="edit-label" value={editItemForm.label} onChange={(e) => setEditItemForm({ ...editItemForm, label: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-value">Value</Label>
              <Input id="edit-value" value={editItemForm.value} onChange={(e) => setEditItemForm({ ...editItemForm, value: e.target.value })} />
            </div>
            <div className="flex items-center gap-2">
              <Switch id="edit-active" checked={editItemForm.isActive} onCheckedChange={(checked) => setEditItemForm({ ...editItemForm, isActive: checked })} />
              <Label htmlFor="edit-active">Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditItemDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleEditItem}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Item Confirmation */}
      <AlertDialog open={isDeleteItemDialogOpen} onOpenChange={setIsDeleteItemDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Item</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deletingItem?.label}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteItem} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Set Confirmation */}
      <AlertDialog open={isDeleteSetDialogOpen} onOpenChange={setIsDeleteSetDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Value Set</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{selectedLOV?.name}" and all its items? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteSet} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
