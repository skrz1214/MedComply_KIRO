import { StatusCard } from "@/components/admin/StatusCard";
import { useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  Building2,
  Users,
  Shield,
  Activity,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  Puzzle,
  MessageSquare,
  FileCheck,
  ShieldAlert,
  Gavel,
  ClipboardCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AdminHome() {
  const navigate = useNavigate();

  const dashboardMetrics = [
    {
      title: "Master Dashboard (Org)",
      status: "configured" as const,
      description: "Organization-wide compliance view",
      icon: LayoutDashboard,
      href: "/admin/dashboards?tab=master",
    },
    {
      title: "Department Dashboards",
      status: "partial" as const,
      value: "3 / 8",
      description: "Departments configured",
      icon: Building2,
      href: "/admin/dashboards?tab=departments",
    },
    {
      title: "Personal Dashboard Template",
      status: "configured" as const,
      description: "User workspace template active",
      icon: Users,
      href: "/admin/dashboards?tab=individuals",
    },
    {
      title: "User Personalization",
      status: "configured" as const,
      value: "68%",
      description: "Users with custom layouts",
      icon: Activity,
      href: "/admin/dashboards?tab=individuals",
    },
  ];

  const microappMetrics = [
    {
      title: "FeedbackHub",
      status: "configured" as const,
      description: "Feedback collection active",
      icon: MessageSquare,
      href: "/admin/apps",
    },
    {
      title: "ComplianceConnect",
      status: "configured" as const,
      description: "Issue tracking & CAPA enabled",
      icon: FileCheck,
      href: "/admin/apps",
    },
    {
      title: "RiskGuard",
      status: "partial" as const,
      value: "3 / 5",
      description: "Risk modules configured",
      icon: ShieldAlert,
      href: "/admin/apps",
    },
    {
      title: "EnforcePoint",
      status: "configured" as const,
      description: "Enforcement tracking active",
      icon: Gavel,
      href: "/admin/apps",
    },
    {
      title: "AuditPro",
      status: "not-configured" as const,
      description: "Pending initial setup",
      icon: ClipboardCheck,
      href: "/admin/apps",
    },
  ];

  const quickStats = [
    { label: "Active Facilities", value: "4", icon: Building2 },
    { label: "Active Users", value: "156", icon: Users },
    { label: "Roles Configured", value: "12", icon: Shield },
    { label: "Apps Enabled", value: "5", icon: Puzzle },
  ];

  const recentChanges = [
    {
      action: "Published",
      item: "Master Dashboard",
      user: "Sarah Chen",
      time: "2 hours ago",
      type: "success",
    },
    {
      action: "Draft saved",
      item: "Cardiology Dept Dashboard",
      user: "Mike Johnson",
      time: "5 hours ago",
      type: "warning",
    },
    {
      action: "Updated",
      item: "CAPA Workflow Policy",
      user: "Sarah Chen",
      time: "1 day ago",
      type: "success",
    },
    {
      action: "Created",
      item: "New Enforcement Template",
      user: "Dr. Patel",
      time: "2 days ago",
      type: "success",
    },
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto animate-fade-in">
      {/* Header */}
      <div className="admin-header">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Admin Home</h1>
          <p className="text-muted-foreground mt-1">
            Configure and manage your MedComply organization
          </p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {quickStats.map((stat) => (
          <div
            key={stat.label}
            className="bg-card border border-border rounded-lg p-4 flex items-center gap-4"
          >
            <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
              <stat.icon className="w-5 h-5 text-accent" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Dashboard Coverage */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <LayoutDashboard className="w-5 h-5 text-accent" />
            Dashboard Coverage
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/admin/dashboards")}
            className="text-accent hover:text-accent/80"
          >
            View All
            <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {dashboardMetrics.map((metric) => (
            <StatusCard
              key={metric.title}
              title={metric.title}
              status={metric.status}
              value={metric.value}
              description={metric.description}
              icon={metric.icon}
              onClick={() => navigate(metric.href)}
            />
          ))}
        </div>
      </section>

      {/* Microapp Coverage */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Puzzle className="w-5 h-5 text-accent" />
            Microapp Coverage
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/admin/apps")}
            className="text-accent hover:text-accent/80"
          >
            View All
            <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {microappMetrics.map((metric) => (
            <StatusCard
              key={metric.title}
              title={metric.title}
              status={metric.status}
              value={metric.value}
              description={metric.description}
              icon={metric.icon}
              onClick={() => navigate(metric.href)}
            />
          ))}
        </div>
      </section>

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Configuration Health */}
        <section className="card-section">
          <div className="p-4 border-b border-border flex items-center justify-between">
            <h2 className="font-semibold text-foreground flex items-center gap-2">
              <Activity className="w-5 h-5 text-accent" />
              Configuration Health
            </h2>
          </div>
          <div className="p-4 space-y-4">
            <HealthItem
              label="Organization Profile"
              status="complete"
              description="All required fields configured"
              detail="4 facilities, 8 departments active"
            />
            <HealthItem
              label="User Provisioning"
              status="complete"
              description="156 users across 4 roles"
              detail="Last sync: 2 hours ago"
            />
            <HealthItem
              label="Access Management"
              status="complete"
              description="4 roles with 48 entitlements"
              detail="No orphaned permissions"
            />
            <HealthItem
              label="Security Policies"
              status="warning"
              description="MFA enabled for 89% of users"
              detail="17 users pending MFA setup"
            />
            <HealthItem
              label="Data Retention"
              status="complete"
              description="4 policies active"
              detail="Audit logs: 365 days retention"
            />
            <HealthItem
              label="App Integrations"
              status="warning"
              description="4 of 5 microapps configured"
              detail="AuditPro pending initial setup"
            />
            <HealthItem
              label="Department Coverage"
              status="warning"
              description="3 of 8 departments configured"
              detail="5 departments need dashboard setup"
            />
            <HealthItem
              label="Compliance Readiness"
              status="complete"
              description="Core compliance modules active"
              detail="Issue tracking, CAPA, Enforcement"
            />
          </div>
        </section>

        {/* Recent Changes */}
        <section className="card-section">
          <div className="p-4 border-b border-border flex items-center justify-between">
            <h2 className="font-semibold text-foreground flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-accent" />
              Recent Changes
            </h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/admin/history")}
              className="text-accent hover:text-accent/80"
            >
              View History
            </Button>
          </div>
          <div className="divide-y divide-border">
            {recentChanges.map((change, index) => (
              <div key={index} className="p-4 flex items-start gap-3">
                <div
                  className={`w-2 h-2 rounded-full mt-2 ${
                    change.type === "success" ? "bg-success" : "bg-warning"
                  }`}
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground">
                    <span className="font-medium">{change.action}</span>{" "}
                    <span className="text-accent">{change.item}</span>
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {change.user} • {change.time}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

function HealthItem({
  label,
  status,
  description,
  detail,
}: {
  label: string;
  status: "complete" | "warning" | "error";
  description: string;
  detail?: string;
}) {
  const icons = {
    complete: <CheckCircle2 className="w-5 h-5 text-success" />,
    warning: <AlertTriangle className="w-5 h-5 text-warning" />,
    error: <AlertTriangle className="w-5 h-5 text-destructive" />,
  };

  return (
    <div className="flex items-center gap-3">
      {icons[status]}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-foreground">{label}</p>
        <p className="text-xs text-muted-foreground">{description}</p>
        {detail && (
          <p className="text-xs text-muted-foreground/70 mt-0.5">{detail}</p>
        )}
      </div>
    </div>
  );
}
