import { Button } from "@/components/ui/button";
import { Puzzle, Plus, CheckCircle2, ExternalLink } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function AppsConfig() {
  const apps = [
    { id: "riskguard", name: "RiskGuard", description: "Risk assessment and mitigation", enabled: true, risk: "high" },
    { id: "enforcepoint", name: "EnforcePoint", description: "Enforcement tracking and compliance calendar", enabled: true, risk: "high" },
    { id: "complianceconnect", name: "ComplianceConnect", description: "Issue tracking, CAPA, and citations", enabled: true, risk: "high" },
    { id: "feedbackhub", name: "FeedbackHub", description: "Staff and patient feedback collection", enabled: true, risk: "low" },
    { id: "auditpro", name: "AuditPro", description: "Audit planning and findings management", enabled: true, risk: "medium" },
  ];

  const riskColors = {
    high: "text-destructive bg-destructive/10",
    medium: "text-warning bg-warning/10",
    low: "text-success bg-success/10",
  };

  return (
    <div className="animate-fade-in">
      <div className="border-b border-border bg-card">
        <div className="p-6 max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <Puzzle className="w-7 h-7 text-accent" />
            Apps & Integrations
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage microapp configurations and third-party integrations
          </p>
        </div>
      </div>

      <div className="p-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-foreground">Microapps</h2>
          <Button size="sm" variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            Add Integration
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {apps.map((app) => (
            <div key={app.id} className="card-section p-4 hover:shadow-md transition-shadow cursor-pointer">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Puzzle className="w-5 h-5 text-accent" />
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={riskColors[app.risk as keyof typeof riskColors]}>
                    {app.risk} risk
                  </Badge>
                  {app.enabled && (
                    <CheckCircle2 className="w-5 h-5 text-success" />
                  )}
                </div>
              </div>
              <h3 className="font-semibold text-foreground mb-1">{app.name}</h3>
              <p className="text-sm text-muted-foreground">{app.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
