import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Lock, Shield, Activity } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function SecurityConfig() {
  const securitySettings = [
    { id: "mfa", name: "Multi-Factor Authentication", description: "Require MFA for all users", enabled: true },
    { id: "session", name: "Session Timeout", description: "Auto-logout after 30 minutes of inactivity", enabled: true },
    { id: "password", name: "Password Policy", description: "Enforce strong password requirements", enabled: true },
    { id: "ip", name: "IP Allowlisting", description: "Restrict access to specific IP ranges", enabled: false },
    { id: "audit", name: "Audit Logging", description: "Log all user actions for 365 days", enabled: true },
  ];

  const recentActivity = [
    { action: "Login attempt", user: "sarah.chen@medcomply.org", status: "success", time: "2 min ago" },
    { action: "Password changed", user: "mike.johnson@medcomply.org", status: "success", time: "1 hour ago" },
    { action: "Role modified", user: "admin@medcomply.org", status: "success", time: "3 hours ago" },
    { action: "Failed login", user: "unknown@email.com", status: "blocked", time: "5 hours ago" },
  ];

  return (
    <div className="animate-fade-in">
      <div className="border-b border-border bg-card">
        <div className="p-6 max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <Lock className="w-7 h-7 text-accent" />
            Security & Audit
          </h1>
          <p className="text-muted-foreground mt-1">
            Configure security policies and view audit logs
          </p>
        </div>
      </div>

      <div className="p-6 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Security Settings */}
          <div className="card-section">
            <div className="p-4 border-b border-border flex items-center gap-2">
              <Shield className="w-5 h-5 text-accent" />
              <h2 className="font-semibold text-foreground">Security Settings</h2>
            </div>
            <div className="divide-y divide-border">
              {securitySettings.map((setting) => (
                <div key={setting.id} className="p-4 flex items-center gap-4">
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{setting.name}</p>
                    <p className="text-sm text-muted-foreground">{setting.description}</p>
                  </div>
                  <Switch checked={setting.enabled} aria-label={setting.name} />
                </div>
              ))}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="card-section">
            <div className="p-4 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-accent" />
                <h2 className="font-semibold text-foreground">Recent Activity</h2>
              </div>
              <Button variant="ghost" size="sm" className="text-accent">View All</Button>
            </div>
            <div className="divide-y divide-border">
              {recentActivity.map((activity, index) => (
                <div key={index} className="p-4 flex items-center gap-4">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">{activity.action}</p>
                    <p className="text-xs text-muted-foreground">{activity.user}</p>
                  </div>
                  <Badge 
                    variant="outline" 
                    className={activity.status === "success" ? "text-success" : "text-destructive"}
                  >
                    {activity.status}
                  </Badge>
                  <span className="text-xs text-muted-foreground">{activity.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
