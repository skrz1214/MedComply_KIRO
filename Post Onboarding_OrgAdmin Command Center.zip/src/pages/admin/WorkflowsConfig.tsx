import { useState } from "react";
import { Button } from "@/components/ui/button";
import { GitBranch, Plus, ChevronRight, CheckCircle2, Clock, Edit2, Trash2, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface WorkflowStep {
  id: string;
  name: string;
  type: "approval" | "notification" | "condition" | "action";
  order: number;
}

interface Workflow {
  id: string;
  name: string;
  type: string;
  status: "active" | "draft";
  description: string;
  steps: WorkflowStep[];
}

const WORKFLOW_TYPES = ["Onboarding", "Approval", "Assignment", "Change Control", "Notification"];

const initialWorkflows: Workflow[] = [
  { 
    id: "1", 
    name: "User Onboarding Workflow", 
    type: "Onboarding", 
    status: "active", 
    description: "Standard workflow for onboarding new users to the organization",
    steps: [
      { id: "1-1", name: "Submit User Details", type: "action", order: 1 },
      { id: "1-2", name: "Manager Approval", type: "approval", order: 2 },
      { id: "1-3", name: "IT Setup Notification", type: "notification", order: 3 },
      { id: "1-4", name: "Access Provisioning", type: "action", order: 4 },
    ]
  },
  { 
    id: "2", 
    name: "Department Approval Chain", 
    type: "Approval", 
    status: "active",
    description: "Multi-level approval chain for department-level decisions",
    steps: [
      { id: "2-1", name: "Initiator Submission", type: "action", order: 1 },
      { id: "2-2", name: "Department Head Approval", type: "approval", order: 2 },
      { id: "2-3", name: "Final Notification", type: "notification", order: 3 },
    ]
  },
  { 
    id: "3", 
    name: "Role Assignment Workflow", 
    type: "Assignment", 
    status: "active",
    description: "Workflow for assigning or changing user roles",
    steps: [
      { id: "3-1", name: "Role Request", type: "action", order: 1 },
      { id: "3-2", name: "Admin Approval", type: "approval", order: 2 },
    ]
  },
  { 
    id: "4", 
    name: "Access Request Approval", 
    type: "Approval", 
    status: "active",
    description: "Approval workflow for system access requests",
    steps: [
      { id: "4-1", name: "Access Request Form", type: "action", order: 1 },
      { id: "4-2", name: "Check Eligibility", type: "condition", order: 2 },
      { id: "4-3", name: "Security Approval", type: "approval", order: 3 },
    ]
  },
  { 
    id: "5", 
    name: "Organization Settings Change", 
    type: "Change Control", 
    status: "draft",
    description: "Controlled workflow for modifying organization-level settings",
    steps: [
      { id: "5-1", name: "Change Request", type: "action", order: 1 },
      { id: "5-2", name: "Impact Assessment", type: "condition", order: 2 },
      { id: "5-3", name: "Admin Approval", type: "approval", order: 3 },
      { id: "5-4", name: "Change Notification", type: "notification", order: 4 },
    ]
  },
];

const getStepTypeColor = (type: WorkflowStep["type"]) => {
  switch (type) {
    case "approval": return "bg-blue-500/10 text-blue-600";
    case "notification": return "bg-green-500/10 text-green-600";
    case "condition": return "bg-amber-500/10 text-amber-600";
    case "action": return "bg-purple-500/10 text-purple-600";
    default: return "bg-muted text-muted-foreground";
  }
};

export default function WorkflowsConfig() {
  const { toast } = useToast();
  const [workflows, setWorkflows] = useState<Workflow[]>(initialWorkflows);
  const [selectedWorkflow, setSelectedWorkflow] = useState<Workflow | null>(null);
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isAddStepDialogOpen, setIsAddStepDialogOpen] = useState(false);

  const [newWorkflowForm, setNewWorkflowForm] = useState({ 
    name: "", 
    type: "Approval", 
    description: "",
    status: "draft" as "active" | "draft"
  });
  const [editWorkflowForm, setEditWorkflowForm] = useState({ 
    name: "", 
    type: "Approval", 
    description: "",
    status: "draft" as "active" | "draft"
  });
  const [newStepForm, setNewStepForm] = useState({
    name: "",
    type: "action" as WorkflowStep["type"]
  });

  const handleOpenWorkflow = (workflow: Workflow) => {
    setSelectedWorkflow(workflow);
    setIsSheetOpen(true);
  };

  const handleCreateWorkflow = () => {
    if (!newWorkflowForm.name) {
      toast({ title: "Error", description: "Workflow name is required", variant: "destructive" });
      return;
    }
    const newWorkflow: Workflow = {
      id: Date.now().toString(),
      name: newWorkflowForm.name,
      type: newWorkflowForm.type,
      status: newWorkflowForm.status,
      description: newWorkflowForm.description,
      steps: [],
    };
    setWorkflows([...workflows, newWorkflow]);
    setNewWorkflowForm({ name: "", type: "Approval", description: "", status: "draft" });
    setIsCreateDialogOpen(false);
    toast({ title: "Success", description: `Workflow "${newWorkflow.name}" created` });
  };

  const handleEditWorkflow = () => {
    if (!selectedWorkflow || !editWorkflowForm.name) {
      toast({ title: "Error", description: "Workflow name is required", variant: "destructive" });
      return;
    }
    const updatedWorkflow = {
      ...selectedWorkflow,
      name: editWorkflowForm.name,
      type: editWorkflowForm.type,
      description: editWorkflowForm.description,
      status: editWorkflowForm.status,
    };
    setWorkflows(workflows.map(w => w.id === selectedWorkflow.id ? updatedWorkflow : w));
    setSelectedWorkflow(updatedWorkflow);
    setIsEditDialogOpen(false);
    toast({ title: "Success", description: "Workflow updated" });
  };

  const handleDeleteWorkflow = () => {
    if (!selectedWorkflow) return;
    setWorkflows(workflows.filter(w => w.id !== selectedWorkflow.id));
    setIsDeleteDialogOpen(false);
    setIsSheetOpen(false);
    setSelectedWorkflow(null);
    toast({ title: "Success", description: "Workflow deleted" });
  };

  const handleAddStep = () => {
    if (!selectedWorkflow || !newStepForm.name) {
      toast({ title: "Error", description: "Step name is required", variant: "destructive" });
      return;
    }
    const newStep: WorkflowStep = {
      id: `${selectedWorkflow.id}-${Date.now()}`,
      name: newStepForm.name,
      type: newStepForm.type,
      order: selectedWorkflow.steps.length + 1,
    };
    const updatedWorkflow = { ...selectedWorkflow, steps: [...selectedWorkflow.steps, newStep] };
    setWorkflows(workflows.map(w => w.id === selectedWorkflow.id ? updatedWorkflow : w));
    setSelectedWorkflow(updatedWorkflow);
    setNewStepForm({ name: "", type: "action" });
    setIsAddStepDialogOpen(false);
    toast({ title: "Success", description: `Step "${newStep.name}" added` });
  };

  const handleDeleteStep = (stepId: string) => {
    if (!selectedWorkflow) return;
    const updatedSteps = selectedWorkflow.steps.filter(s => s.id !== stepId);
    const updatedWorkflow = { ...selectedWorkflow, steps: updatedSteps };
    setWorkflows(workflows.map(w => w.id === selectedWorkflow.id ? updatedWorkflow : w));
    setSelectedWorkflow(updatedWorkflow);
    toast({ title: "Success", description: "Step deleted" });
  };

  const openEditDialog = () => {
    if (!selectedWorkflow) return;
    setEditWorkflowForm({
      name: selectedWorkflow.name,
      type: selectedWorkflow.type,
      description: selectedWorkflow.description,
      status: selectedWorkflow.status,
    });
    setIsEditDialogOpen(true);
  };

  return (
    <div className="animate-fade-in">
      <div className="border-b border-border bg-card">
        <div className="p-6 max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <GitBranch className="w-7 h-7 text-accent" />
            Workflows & Policies
          </h1>
          <p className="text-muted-foreground mt-1">
            Configure approval workflows and policy automation
          </p>
        </div>
      </div>

      <div className="p-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-foreground">Workflows</h2>
          <Button 
            size="sm" 
            className="bg-accent text-accent-foreground hover:bg-accent/90"
            onClick={() => setIsCreateDialogOpen(true)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Workflow
          </Button>
        </div>

        <div className="card-section">
          <div className="divide-y divide-border">
            {workflows.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">
                No workflows yet. Click "Create Workflow" to add one.
              </div>
            ) : (
              workflows.map((workflow) => (
                <div
                  key={workflow.id}
                  onClick={() => handleOpenWorkflow(workflow)}
                  className="p-4 flex items-center gap-4 hover:bg-muted/50 transition-colors cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                    <GitBranch className="w-5 h-5 text-accent" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-foreground">{workflow.name}</p>
                      <Badge variant="outline">{workflow.type}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{workflow.steps.length} steps</p>
                  </div>
                  <Badge 
                    className={cn(
                      workflow.status === "active" 
                        ? "bg-success/10 text-success" 
                        : "bg-warning/10 text-warning"
                    )}
                  >
                    {workflow.status === "active" ? (
                      <><CheckCircle2 className="w-3 h-3 mr-1" /> Active</>
                    ) : (
                      <><Clock className="w-3 h-3 mr-1" /> Draft</>
                    )}
                  </Badge>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Workflow Details Sheet */}
      <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
        <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <GitBranch className="w-5 h-5" />
              {selectedWorkflow?.name}
            </SheetTitle>
            <SheetDescription>
              {selectedWorkflow?.description || "No description"}
            </SheetDescription>
          </SheetHeader>

          <div className="mt-6 space-y-6">
            <div className="flex items-center gap-2">
              <Badge variant="outline">{selectedWorkflow?.type}</Badge>
              <Badge 
                className={cn(
                  selectedWorkflow?.status === "active" 
                    ? "bg-success/10 text-success" 
                    : "bg-warning/10 text-warning"
                )}
              >
                {selectedWorkflow?.status === "active" ? "Active" : "Draft"}
              </Badge>
            </div>

            <div className="flex items-center justify-between">
              <h3 className="font-medium text-foreground">Workflow Steps</h3>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={openEditDialog}>
                  <Edit2 className="w-4 h-4 mr-1" />
                  Edit
                </Button>
                <Button size="sm" variant="outline" onClick={() => setIsDeleteDialogOpen(true)}>
                  <Trash2 className="w-4 h-4 mr-1" />
                  Delete
                </Button>
                <Button size="sm" onClick={() => setIsAddStepDialogOpen(true)}>
                  <Plus className="w-4 h-4 mr-1" />
                  Add Step
                </Button>
              </div>
            </div>

            <div className="border rounded-lg divide-y divide-border">
              {selectedWorkflow?.steps.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground">
                  No steps yet. Click "Add Step" to create one.
                </div>
              ) : (
                selectedWorkflow?.steps.map((step, index) => (
                  <div key={step.id} className="p-3 flex items-center gap-3 group hover:bg-muted/50">
                    <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-sm font-medium">
                      {index + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground">{step.name}</p>
                      <Badge className={cn("text-xs mt-1", getStepTypeColor(step.type))}>
                        {step.type}
                      </Badge>
                    </div>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="opacity-0 group-hover:opacity-100 h-8 w-8"
                      onClick={() => handleDeleteStep(step.id)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))
              )}
            </div>
          </div>
        </SheetContent>
      </Sheet>

      {/* Create Workflow Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Workflow</DialogTitle>
            <DialogDescription>Add a new workflow to the system</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="workflow-name">Name</Label>
              <Input
                id="workflow-name"
                value={newWorkflowForm.name}
                onChange={(e) => setNewWorkflowForm({ ...newWorkflowForm, name: e.target.value })}
                placeholder="Enter workflow name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="workflow-type">Type</Label>
              <Select
                value={newWorkflowForm.type}
                onValueChange={(value) => setNewWorkflowForm({ ...newWorkflowForm, type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {WORKFLOW_TYPES.map((type) => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="workflow-description">Description</Label>
              <Input
                id="workflow-description"
                value={newWorkflowForm.description}
                onChange={(e) => setNewWorkflowForm({ ...newWorkflowForm, description: e.target.value })}
                placeholder="Enter description"
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="workflow-active">Set as Active</Label>
              <Switch
                id="workflow-active"
                checked={newWorkflowForm.status === "active"}
                onCheckedChange={(checked) => setNewWorkflowForm({ ...newWorkflowForm, status: checked ? "active" : "draft" })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreateWorkflow}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Workflow Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Workflow</DialogTitle>
            <DialogDescription>Update workflow details</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-workflow-name">Name</Label>
              <Input
                id="edit-workflow-name"
                value={editWorkflowForm.name}
                onChange={(e) => setEditWorkflowForm({ ...editWorkflowForm, name: e.target.value })}
                placeholder="Enter workflow name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-workflow-type">Type</Label>
              <Select
                value={editWorkflowForm.type}
                onValueChange={(value) => setEditWorkflowForm({ ...editWorkflowForm, type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {WORKFLOW_TYPES.map((type) => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-workflow-description">Description</Label>
              <Input
                id="edit-workflow-description"
                value={editWorkflowForm.description}
                onChange={(e) => setEditWorkflowForm({ ...editWorkflowForm, description: e.target.value })}
                placeholder="Enter description"
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="edit-workflow-active">Active</Label>
              <Switch
                id="edit-workflow-active"
                checked={editWorkflowForm.status === "active"}
                onCheckedChange={(checked) => setEditWorkflowForm({ ...editWorkflowForm, status: checked ? "active" : "draft" })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleEditWorkflow}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Step Dialog */}
      <Dialog open={isAddStepDialogOpen} onOpenChange={setIsAddStepDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Step</DialogTitle>
            <DialogDescription>Add a new step to the workflow</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="step-name">Step Name</Label>
              <Input
                id="step-name"
                value={newStepForm.name}
                onChange={(e) => setNewStepForm({ ...newStepForm, name: e.target.value })}
                placeholder="Enter step name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="step-type">Step Type</Label>
              <Select
                value={newStepForm.type}
                onValueChange={(value) => setNewStepForm({ ...newStepForm, type: value as WorkflowStep["type"] })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="action">Action</SelectItem>
                  <SelectItem value="approval">Approval</SelectItem>
                  <SelectItem value="notification">Notification</SelectItem>
                  <SelectItem value="condition">Condition</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddStepDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAddStep}>Add</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Workflow Confirmation */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Workflow</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{selectedWorkflow?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteWorkflow} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
