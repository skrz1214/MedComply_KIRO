import { useState } from "react";
import { TabNavigation } from "@/components/admin/TabNavigation";
import { DraftPublishBar } from "@/components/admin/DraftPublishBar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  LayoutDashboard,
  Building2,
  Plus,
  GripVertical,
  Eye,
  Settings,
  ChevronRight,
  Users,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Pencil,
  Trash2,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useSearchParams } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

const tabs = [
  { id: "master", label: "Master (Org)" },
  { id: "departments", label: "Departments", count: 8 },
  { id: "individuals", label: "Individuals" },
];

export default function DashboardsConfig() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialTab = searchParams.get("tab") || "master";
  const [activeTab, setActiveTab] = useState(initialTab);
  const [hasChanges, setHasChanges] = useState(false);
  const { toast } = useToast();

  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    setSearchParams({ tab: tabId });
  };

  const handleSaveDraft = () => {
    toast({ title: "Draft saved", description: "Your changes have been saved as a draft." });
    setHasChanges(false);
  };

  const handlePublish = () => {
    toast({ title: "Published", description: "Dashboard configuration has been published." });
    setHasChanges(false);
  };

  const handleDiscard = () => {
    setHasChanges(false);
  };

  const handlePreview = () => {
    toast({ title: "Preview mode", description: "Opening preview in new tab..." });
  };

  return (
    <div className="animate-fade-in pb-24">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="p-6 max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
                <LayoutDashboard className="w-7 h-7 text-accent" />
                Dashboards
              </h1>
              <p className="text-muted-foreground mt-1">
                Configure dashboard layouts and widgets for all user levels
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-success border-success/30 bg-success/5">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Published
              </Badge>
              <span className="text-sm text-muted-foreground">v2.4</span>
            </div>
          </div>

          <TabNavigation
            tabs={tabs}
            activeTab={activeTab}
            onTabChange={handleTabChange}
          />
        </div>
      </div>

      {/* Content */}
      <div className="p-6 max-w-7xl mx-auto">
        {activeTab === "master" && (
          <MasterDashboardConfig onChange={() => setHasChanges(true)} />
        )}
        {activeTab === "departments" && (
          <DepartmentDashboardsConfig onChange={() => setHasChanges(true)} />
        )}
        {activeTab === "individuals" && (
          <IndividualDashboardConfig onChange={() => setHasChanges(true)} />
        )}
      </div>

      {/* Draft/Publish Bar */}
      <DraftPublishBar
        hasChanges={hasChanges}
        lastSaved="5 minutes ago"
        onSaveDraft={handleSaveDraft}
        onPublish={handlePublish}
        onDiscard={handleDiscard}
        onPreview={handlePreview}
      />
    </div>
  );
}

// Widget Types
const WIDGET_TYPES = [
  { value: "kpi", label: "KPI Tile" },
  { value: "chart", label: "Trend Chart" },
  { value: "list", label: "List Widget" },
  { value: "queue", label: "Work Queue" },
  { value: "calendar", label: "Calendar" },
  { value: "content", label: "Content Block" },
];

interface Widget {
  id: string;
  name: string;
  type: string;
  enabled: boolean;
}

function MasterDashboardConfig({ onChange }: { onChange: () => void }) {
  const { toast } = useToast();
  const [widgets, setWidgets] = useState<Widget[]>([
    { id: "kpi-compliance", name: "Compliance Score", type: "KPI Tile", enabled: true },
    { id: "kpi-risk", name: "Risk Index", type: "KPI Tile", enabled: true },
    { id: "chart-trends", name: "Compliance Trends", type: "Trend Chart", enabled: true },
    { id: "queue-work", name: "Cross-App Work Queue", type: "Work Queue", enabled: true },
    { id: "list-risk", name: "At-Risk Items", type: "List Widget", enabled: true },
    { id: "calendar", name: "Compliance Calendar", type: "Calendar", enabled: false },
    { id: "announcements", name: "Announcements", type: "Content Block", enabled: true },
  ]);

  const [isAddWidgetOpen, setIsAddWidgetOpen] = useState(false);
  const [isEditWidgetOpen, setIsEditWidgetOpen] = useState(false);
  const [isDeleteWidgetOpen, setIsDeleteWidgetOpen] = useState(false);
  const [selectedWidget, setSelectedWidget] = useState<Widget | null>(null);
  const [widgetForm, setWidgetForm] = useState({ name: "", type: "kpi" });

  const handleAddWidget = () => {
    if (!widgetForm.name) {
      toast({ title: "Error", description: "Widget name is required", variant: "destructive" });
      return;
    }
    const typeLabel = WIDGET_TYPES.find(t => t.value === widgetForm.type)?.label || widgetForm.type;
    const newWidget: Widget = {
      id: Date.now().toString(),
      name: widgetForm.name,
      type: typeLabel,
      enabled: true,
    };
    setWidgets([...widgets, newWidget]);
    setWidgetForm({ name: "", type: "kpi" });
    setIsAddWidgetOpen(false);
    onChange();
    toast({ title: "Success", description: `Widget "${newWidget.name}" added` });
  };

  const handleEditWidget = () => {
    if (!selectedWidget || !widgetForm.name) {
      toast({ title: "Error", description: "Widget name is required", variant: "destructive" });
      return;
    }
    const typeLabel = WIDGET_TYPES.find(t => t.value === widgetForm.type)?.label || widgetForm.type;
    setWidgets(widgets.map(w => 
      w.id === selectedWidget.id ? { ...w, name: widgetForm.name, type: typeLabel } : w
    ));
    setIsEditWidgetOpen(false);
    onChange();
    toast({ title: "Success", description: "Widget updated" });
  };

  const handleDeleteWidget = () => {
    if (!selectedWidget) return;
    setWidgets(widgets.filter(w => w.id !== selectedWidget.id));
    setIsDeleteWidgetOpen(false);
    onChange();
    toast({ title: "Success", description: "Widget deleted" });
  };

  const openEditWidget = (widget: Widget) => {
    setSelectedWidget(widget);
    const typeValue = WIDGET_TYPES.find(t => t.label === widget.type)?.value || "kpi";
    setWidgetForm({ name: widget.name, type: typeValue });
    setIsEditWidgetOpen(true);
  };

  const openDeleteWidget = (widget: Widget) => {
    setSelectedWidget(widget);
    setIsDeleteWidgetOpen(true);
  };

  const toggleWidget = (widgetId: string) => {
    setWidgets(widgets.map(w => w.id === widgetId ? { ...w, enabled: !w.enabled } : w));
    onChange();
  };

  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Master Compliance Dashboard</h2>
          <p className="text-sm text-muted-foreground">
            Organization-wide view for leadership and compliance teams
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Eye className="w-4 h-4 mr-2" />
            Preview as Role
          </Button>
          <Button variant="outline" size="sm">
            <Settings className="w-4 h-4 mr-2" />
            Layout Settings
          </Button>
        </div>
      </div>

      {/* Layout Builder */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Widget List */}
        <div className="lg:col-span-2 card-section">
          <div className="p-4 border-b border-border flex items-center justify-between">
            <h3 className="font-medium text-foreground">Dashboard Widgets</h3>
            <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={() => {
              setWidgetForm({ name: "", type: "kpi" });
              setIsAddWidgetOpen(true);
            }}>
              <Plus className="w-4 h-4 mr-2" />
              Add Widget
            </Button>
          </div>
          <div className="divide-y divide-border">
            {widgets.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">
                No widgets yet. Click "Add Widget" to create one.
              </div>
            ) : (
              widgets.map((widget) => (
                <div
                  key={widget.id}
                  className="p-4 flex items-center gap-4 hover:bg-muted/50 transition-colors group"
                >
                  <GripVertical className="w-4 h-4 text-muted-foreground cursor-move" />
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{widget.name}</p>
                    <p className="text-xs text-muted-foreground">{widget.type}</p>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEditWidget(widget)}>
                      <Pencil className="w-4 h-4 text-muted-foreground" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openDeleteWidget(widget)}>
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                  <Switch
                    checked={widget.enabled}
                    onCheckedChange={() => toggleWidget(widget.id)}
                    aria-label={`Enable ${widget.name}`}
                  />
                </div>
              ))
            )}
          </div>
        </div>

        {/* Settings Panel */}
        <div className="space-y-4">
          <div className="card-section p-4">
            <h3 className="font-medium text-foreground mb-4">Visibility Rules</h3>
            <div className="space-y-3">
              <VisibilityRule role="Org Admin" access="view-manage" />
              <VisibilityRule role="Compliance Head" access="view-manage" />
              <VisibilityRule role="Department Head" access="view-only" />
              <VisibilityRule role="Staff" access="no-access" />
            </div>
          </div>

          <div className="card-section p-4">
            <h3 className="font-medium text-foreground mb-4">Export Settings</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground">Enable CSV Export</span>
                <Switch defaultChecked onCheckedChange={onChange} />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground">Enable PDF Export</span>
                <Switch defaultChecked onCheckedChange={onChange} />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground">Require Export Reason</span>
                <Switch onCheckedChange={onChange} />
              </div>
            </div>
          </div>

          <div className="card-section p-4">
            <h3 className="font-medium text-foreground mb-4">Default Filters</h3>
            <div className="space-y-3">
              <div>
                <label className="text-sm text-muted-foreground block mb-1">Date Range</label>
                <select className="w-full px-3 py-2 text-sm bg-muted border-0 rounded-md">
                  <option>Last 30 days</option>
                  <option>Last 90 days</option>
                  <option>Year to date</option>
                </select>
              </div>
              <div>
                <label className="text-sm text-muted-foreground block mb-1">Severity Filter</label>
                <select className="w-full px-3 py-2 text-sm bg-muted border-0 rounded-md">
                  <option>All Severities</option>
                  <option>High & Critical Only</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add Widget Dialog */}
      <Dialog open={isAddWidgetOpen} onOpenChange={setIsAddWidgetOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Widget</DialogTitle>
            <DialogDescription>Add a new widget to the master dashboard</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Widget Name</Label>
              <Input
                value={widgetForm.name}
                onChange={(e) => setWidgetForm({ ...widgetForm, name: e.target.value })}
                placeholder="Enter widget name"
              />
            </div>
            <div className="space-y-2">
              <Label>Widget Type</Label>
              <select
                className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                value={widgetForm.type}
                onChange={(e) => setWidgetForm({ ...widgetForm, type: e.target.value })}
              >
                {WIDGET_TYPES.map((type) => (
                  <option key={type.value} value={type.value}>{type.label}</option>
                ))}
              </select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddWidgetOpen(false)}>Cancel</Button>
            <Button onClick={handleAddWidget}>Add Widget</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Widget Dialog */}
      <Dialog open={isEditWidgetOpen} onOpenChange={setIsEditWidgetOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Widget</DialogTitle>
            <DialogDescription>Update widget configuration</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Widget Name</Label>
              <Input
                value={widgetForm.name}
                onChange={(e) => setWidgetForm({ ...widgetForm, name: e.target.value })}
                placeholder="Enter widget name"
              />
            </div>
            <div className="space-y-2">
              <Label>Widget Type</Label>
              <select
                className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                value={widgetForm.type}
                onChange={(e) => setWidgetForm({ ...widgetForm, type: e.target.value })}
              >
                {WIDGET_TYPES.map((type) => (
                  <option key={type.value} value={type.value}>{type.label}</option>
                ))}
              </select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditWidgetOpen(false)}>Cancel</Button>
            <Button onClick={handleEditWidget}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Widget Confirmation */}
      <AlertDialog open={isDeleteWidgetOpen} onOpenChange={setIsDeleteWidgetOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Widget</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{selectedWidget?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteWidget} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

interface DeptDashboard {
  id: string;
  name: string;
  facility: string;
  status: "configured" | "customized" | "pending";
  template: boolean;
  widgets: string[];
}

function DepartmentDashboardsConfig({ onChange }: { onChange: () => void }) {
  const { toast } = useToast();
  const [departments, setDepartments] = useState<DeptDashboard[]>([
    { id: "1", name: "Cardiology", facility: "Main Hospital", status: "configured", template: true, widgets: ["My Dept Work Queue", "Top KPIs", "Overdue Items"] },
    { id: "2", name: "Emergency", facility: "Main Hospital", status: "configured", template: true, widgets: ["My Dept Work Queue", "Top KPIs"] },
    { id: "3", name: "Radiology", facility: "Main Hospital", status: "customized", template: false, widgets: ["Custom Widget 1", "Custom Widget 2"] },
    { id: "4", name: "Pharmacy", facility: "Main Hospital", status: "pending", template: true, widgets: [] },
    { id: "5", name: "Nursing", facility: "East Wing", status: "pending", template: true, widgets: [] },
    { id: "6", name: "Laboratory", facility: "East Wing", status: "pending", template: true, widgets: [] },
    { id: "7", name: "Oncology", facility: "Cancer Center", status: "configured", template: true, widgets: ["My Dept Work Queue", "Top KPIs", "Overdue Items"] },
    { id: "8", name: "Pediatrics", facility: "Children's Wing", status: "pending", template: true, widgets: [] },
  ]);

  const [searchQuery, setSearchQuery] = useState("");
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isConfigureOpen, setIsConfigureOpen] = useState(false);
  const [selectedDept, setSelectedDept] = useState<DeptDashboard | null>(null);
  const [deptForm, setDeptForm] = useState({ name: "", facility: "", useTemplate: true });

  const statusConfig = {
    configured: { label: "Using Template", color: "text-success", bg: "bg-success/10", icon: CheckCircle2 },
    customized: { label: "Customized", color: "text-info", bg: "bg-info/10", icon: Settings },
    pending: { label: "Not Configured", color: "text-muted-foreground", bg: "bg-muted", icon: Clock },
  };

  const filteredDepts = departments.filter(d => 
    d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.facility.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCreate = () => {
    if (!deptForm.name || !deptForm.facility) {
      toast({ title: "Error", description: "Name and facility are required", variant: "destructive" });
      return;
    }
    const newDept: DeptDashboard = {
      id: Date.now().toString(),
      name: deptForm.name,
      facility: deptForm.facility,
      status: deptForm.useTemplate ? "configured" : "pending",
      template: deptForm.useTemplate,
      widgets: deptForm.useTemplate ? ["My Dept Work Queue", "Top KPIs", "Overdue Items", "Upcoming Deadlines"] : [],
    };
    setDepartments([...departments, newDept]);
    setDeptForm({ name: "", facility: "", useTemplate: true });
    setIsCreateOpen(false);
    onChange();
    toast({ title: "Success", description: `Department dashboard "${newDept.name}" created` });
  };

  const handleEdit = () => {
    if (!selectedDept || !deptForm.name || !deptForm.facility) {
      toast({ title: "Error", description: "Name and facility are required", variant: "destructive" });
      return;
    }
    setDepartments(departments.map(d => 
      d.id === selectedDept.id 
        ? { ...d, name: deptForm.name, facility: deptForm.facility, template: deptForm.useTemplate }
        : d
    ));
    setIsEditOpen(false);
    onChange();
    toast({ title: "Success", description: "Department dashboard updated" });
  };

  const handleDelete = () => {
    if (!selectedDept) return;
    setDepartments(departments.filter(d => d.id !== selectedDept.id));
    setIsDeleteOpen(false);
    onChange();
    toast({ title: "Success", description: "Department dashboard deleted" });
  };

  const openEdit = (dept: DeptDashboard) => {
    setSelectedDept(dept);
    setDeptForm({ name: dept.name, facility: dept.facility, useTemplate: dept.template });
    setIsEditOpen(true);
  };

  const openDelete = (dept: DeptDashboard) => {
    setSelectedDept(dept);
    setIsDeleteOpen(true);
  };

  const openConfigure = (dept: DeptDashboard) => {
    setSelectedDept(dept);
    setIsConfigureOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Department Dashboards</h2>
          <p className="text-sm text-muted-foreground">
            Configure dashboard templates for each department
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Settings className="w-4 h-4 mr-2" />
            Template Settings
          </Button>
          <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={() => {
            setDeptForm({ name: "", facility: "", useTemplate: true });
            setIsCreateOpen(true);
          }}>
            <Plus className="w-4 h-4 mr-2" />
            Add Department
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search departments..."
            className="pl-10 bg-card"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline" size="sm">
          <Filter className="w-4 h-4 mr-2" />
          Filter
        </Button>
      </div>

      {/* Department List */}
      <div className="card-section">
        <div className="divide-y divide-border">
          {filteredDepts.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              No departments found.
            </div>
          ) : (
            filteredDepts.map((dept) => {
              const status = statusConfig[dept.status];
              const StatusIcon = status.icon;
              
              return (
                <div
                  key={dept.id}
                  className="p-4 flex items-center gap-4 hover:bg-muted/50 transition-colors group"
                >
                  <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", status.bg)}>
                    <Building2 className={cn("w-5 h-5", status.color)} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-foreground">{dept.name}</p>
                      <Badge variant="outline" className={cn("text-xs", status.color, status.bg, "border-0")}>
                        <StatusIcon className="w-3 h-3 mr-1" />
                        {status.label}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{dept.facility}</p>
                  </div>
                  <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="sm" onClick={() => openConfigure(dept)}>
                      <Eye className="w-4 h-4 mr-2" />
                      Configure
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(dept)}>
                      <Pencil className="w-4 h-4 text-muted-foreground" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openDelete(dept)}>
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Template Preview Card */}
      <div className="card-section p-6">
        <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
          <LayoutDashboard className="w-5 h-5 text-accent" />
          Department Dashboard Template
        </h3>
        <p className="text-sm text-muted-foreground mb-4">
          Default widgets applied to all departments using the template
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {["My Dept Work Queue", "Top KPIs", "Overdue Items", "Upcoming Deadlines"].map((widget) => (
            <div key={widget} className="p-3 bg-muted rounded-lg text-center">
              <p className="text-sm font-medium text-foreground">{widget}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Create Department Dialog */}
      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Department Dashboard</DialogTitle>
            <DialogDescription>Create a new department dashboard configuration</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Department Name</Label>
              <Input
                value={deptForm.name}
                onChange={(e) => setDeptForm({ ...deptForm, name: e.target.value })}
                placeholder="Enter department name"
              />
            </div>
            <div className="space-y-2">
              <Label>Facility</Label>
              <Input
                value={deptForm.facility}
                onChange={(e) => setDeptForm({ ...deptForm, facility: e.target.value })}
                placeholder="Enter facility name"
              />
            </div>
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">Use Default Template</p>
                <p className="text-xs text-muted-foreground">Apply standard department widgets</p>
              </div>
              <Switch
                checked={deptForm.useTemplate}
                onCheckedChange={(checked) => setDeptForm({ ...deptForm, useTemplate: checked })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Department Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Department Dashboard</DialogTitle>
            <DialogDescription>Update department dashboard settings</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Department Name</Label>
              <Input
                value={deptForm.name}
                onChange={(e) => setDeptForm({ ...deptForm, name: e.target.value })}
                placeholder="Enter department name"
              />
            </div>
            <div className="space-y-2">
              <Label>Facility</Label>
              <Input
                value={deptForm.facility}
                onChange={(e) => setDeptForm({ ...deptForm, facility: e.target.value })}
                placeholder="Enter facility name"
              />
            </div>
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">Use Default Template</p>
                <p className="text-xs text-muted-foreground">Apply standard department widgets</p>
              </div>
              <Switch
                checked={deptForm.useTemplate}
                onCheckedChange={(checked) => setDeptForm({ ...deptForm, useTemplate: checked })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditOpen(false)}>Cancel</Button>
            <Button onClick={handleEdit}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Configure Sheet */}
      <Sheet open={isConfigureOpen} onOpenChange={setIsConfigureOpen}>
        <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <Building2 className="w-5 h-5" />
              {selectedDept?.name} Dashboard
            </SheetTitle>
            <SheetDescription>
              Configure widgets and settings for this department
            </SheetDescription>
          </SheetHeader>
          <div className="mt-6 space-y-6">
            <div>
              <h3 className="font-medium text-foreground mb-3">Current Widgets</h3>
              <div className="border rounded-lg divide-y divide-border">
                {selectedDept?.widgets.length === 0 ? (
                  <div className="p-4 text-center text-muted-foreground">
                    No widgets configured. Using template defaults.
                  </div>
                ) : (
                  selectedDept?.widgets.map((widget, index) => (
                    <div key={index} className="p-3 flex items-center gap-3">
                      <GripVertical className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm text-foreground flex-1">{widget}</span>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <X className="w-4 h-4 text-muted-foreground" />
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </div>
            <Button className="w-full" variant="outline">
              <Plus className="w-4 h-4 mr-2" />
              Add Widget
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      {/* Delete Confirmation */}
      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Department Dashboard</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the dashboard for "{selectedDept?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

interface IndividualWidget {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  required: boolean;
}

function IndividualDashboardConfig({ onChange }: { onChange: () => void }) {
  const { toast } = useToast();
  const [widgets, setWidgets] = useState<IndividualWidget[]>([
    { id: "work-queue", name: "My Work Queue", description: "Assigned items across all apps", enabled: true, required: true },
    { id: "deadlines", name: "My Deadlines", description: "Due soon and overdue items", enabled: true, required: true },
    { id: "notifications", name: "My Notifications", description: "Recent notifications", enabled: true, required: false },
    { id: "quick-actions", name: "Quick Actions", description: "Create issue, upload evidence", enabled: true, required: false },
    { id: "training", name: "My Training", description: "Read & Acknowledge items", enabled: false, required: false },
  ]);

  const [isAddWidgetOpen, setIsAddWidgetOpen] = useState(false);
  const [isEditWidgetOpen, setIsEditWidgetOpen] = useState(false);
  const [isDeleteWidgetOpen, setIsDeleteWidgetOpen] = useState(false);
  const [selectedWidget, setSelectedWidget] = useState<IndividualWidget | null>(null);
  const [widgetForm, setWidgetForm] = useState({ name: "", description: "", required: false });

  const personalizationRoles = [
    { role: "Staff", canPersonalize: true, canReorder: true, canHide: true },
    { role: "Department Head", canPersonalize: true, canReorder: true, canHide: true },
    { role: "Compliance Head", canPersonalize: true, canReorder: true, canHide: true },
    { role: "Org Admin", canPersonalize: true, canReorder: true, canHide: true },
  ];

  const handleAddWidget = () => {
    if (!widgetForm.name) {
      toast({ title: "Error", description: "Widget name is required", variant: "destructive" });
      return;
    }
    const newWidget: IndividualWidget = {
      id: Date.now().toString(),
      name: widgetForm.name,
      description: widgetForm.description,
      enabled: true,
      required: widgetForm.required,
    };
    setWidgets([...widgets, newWidget]);
    setWidgetForm({ name: "", description: "", required: false });
    setIsAddWidgetOpen(false);
    onChange();
    toast({ title: "Success", description: `Widget "${newWidget.name}" added` });
  };

  const handleEditWidget = () => {
    if (!selectedWidget || !widgetForm.name) {
      toast({ title: "Error", description: "Widget name is required", variant: "destructive" });
      return;
    }
    setWidgets(widgets.map(w => 
      w.id === selectedWidget.id 
        ? { ...w, name: widgetForm.name, description: widgetForm.description, required: widgetForm.required }
        : w
    ));
    setIsEditWidgetOpen(false);
    onChange();
    toast({ title: "Success", description: "Widget updated" });
  };

  const handleDeleteWidget = () => {
    if (!selectedWidget) return;
    if (selectedWidget.required) {
      toast({ title: "Error", description: "Required widgets cannot be deleted", variant: "destructive" });
      return;
    }
    setWidgets(widgets.filter(w => w.id !== selectedWidget.id));
    setIsDeleteWidgetOpen(false);
    onChange();
    toast({ title: "Success", description: "Widget deleted" });
  };

  const openEditWidget = (widget: IndividualWidget) => {
    setSelectedWidget(widget);
    setWidgetForm({ name: widget.name, description: widget.description, required: widget.required });
    setIsEditWidgetOpen(true);
  };

  const openDeleteWidget = (widget: IndividualWidget) => {
    setSelectedWidget(widget);
    setIsDeleteWidgetOpen(true);
  };

  const toggleWidget = (widgetId: string) => {
    const widget = widgets.find(w => w.id === widgetId);
    if (widget?.required) return;
    setWidgets(widgets.map(w => w.id === widgetId ? { ...w, enabled: !w.enabled } : w));
    onChange();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Personal Dashboard Template</h2>
          <p className="text-sm text-muted-foreground">
            Configure the default "My Dashboard" experience for all users
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Eye className="w-4 h-4 mr-2" />
            Preview as User
          </Button>
          <Button variant="outline" size="sm">
            Reset All Users
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Default Widgets */}
        <div className="lg:col-span-2 card-section">
          <div className="p-4 border-b border-border flex items-center justify-between">
            <div>
              <h3 className="font-medium text-foreground">Default Widgets</h3>
              <p className="text-sm text-muted-foreground">
                Widgets shown on personal dashboards by default
              </p>
            </div>
            <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={() => {
              setWidgetForm({ name: "", description: "", required: false });
              setIsAddWidgetOpen(true);
            }}>
              <Plus className="w-4 h-4 mr-2" />
              Add Widget
            </Button>
          </div>
          <div className="divide-y divide-border">
            {widgets.map((widget) => (
              <div
                key={widget.id}
                className="p-4 flex items-center gap-4 group"
              >
                <GripVertical className="w-4 h-4 text-muted-foreground cursor-move" />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-foreground">{widget.name}</p>
                    {widget.required && (
                      <Badge variant="outline" className="text-xs">Required</Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{widget.description}</p>
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEditWidget(widget)}>
                    <Pencil className="w-4 h-4 text-muted-foreground" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8" 
                    onClick={() => openDeleteWidget(widget)}
                    disabled={widget.required}
                  >
                    <Trash2 className={cn("w-4 h-4", widget.required ? "text-muted-foreground/50" : "text-destructive")} />
                  </Button>
                </div>
                <Switch
                  checked={widget.enabled}
                  disabled={widget.required}
                  onCheckedChange={() => toggleWidget(widget.id)}
                  aria-label={`Enable ${widget.name}`}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Personalization Controls */}
        <div className="space-y-4">
          <div className="card-section p-4">
            <h3 className="font-medium text-foreground mb-4 flex items-center gap-2">
              <Users className="w-4 h-4 text-accent" />
              Personalization by Role
            </h3>
            <div className="space-y-4">
              {personalizationRoles.map((item) => (
                <div key={item.role} className="space-y-2">
                  <p className="text-sm font-medium text-foreground">{item.role}</p>
                  <div className="space-y-1.5 pl-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Can reorder widgets</span>
                      <Switch 
                        defaultChecked={item.canReorder} 
                        onCheckedChange={onChange}
                        className="scale-90" 
                      />
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Can hide optional widgets</span>
                      <Switch 
                        defaultChecked={item.canHide} 
                        onCheckedChange={onChange}
                        className="scale-90" 
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="card-section p-4">
            <h3 className="font-medium text-foreground mb-4">Usage Statistics</h3>
            <div className="space-y-3">
              <StatItem label="Users with default layout" value="50" />
              <StatItem label="Users with custom layout" value="106" />
              <StatItem label="Personalization rate" value="68%" highlight />
            </div>
          </div>
        </div>
      </div>

      {/* Add Widget Dialog */}
      <Dialog open={isAddWidgetOpen} onOpenChange={setIsAddWidgetOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Widget</DialogTitle>
            <DialogDescription>Add a new widget to personal dashboards</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Widget Name</Label>
              <Input
                value={widgetForm.name}
                onChange={(e) => setWidgetForm({ ...widgetForm, name: e.target.value })}
                placeholder="Enter widget name"
              />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Input
                value={widgetForm.description}
                onChange={(e) => setWidgetForm({ ...widgetForm, description: e.target.value })}
                placeholder="Enter widget description"
              />
            </div>
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">Required Widget</p>
                <p className="text-xs text-muted-foreground">Users cannot disable this widget</p>
              </div>
              <Switch
                checked={widgetForm.required}
                onCheckedChange={(checked) => setWidgetForm({ ...widgetForm, required: checked })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddWidgetOpen(false)}>Cancel</Button>
            <Button onClick={handleAddWidget}>Add Widget</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Widget Dialog */}
      <Dialog open={isEditWidgetOpen} onOpenChange={setIsEditWidgetOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Widget</DialogTitle>
            <DialogDescription>Update widget configuration</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Widget Name</Label>
              <Input
                value={widgetForm.name}
                onChange={(e) => setWidgetForm({ ...widgetForm, name: e.target.value })}
                placeholder="Enter widget name"
              />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Input
                value={widgetForm.description}
                onChange={(e) => setWidgetForm({ ...widgetForm, description: e.target.value })}
                placeholder="Enter widget description"
              />
            </div>
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">Required Widget</p>
                <p className="text-xs text-muted-foreground">Users cannot disable this widget</p>
              </div>
              <Switch
                checked={widgetForm.required}
                onCheckedChange={(checked) => setWidgetForm({ ...widgetForm, required: checked })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditWidgetOpen(false)}>Cancel</Button>
            <Button onClick={handleEditWidget}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Widget Confirmation */}
      <AlertDialog open={isDeleteWidgetOpen} onOpenChange={setIsDeleteWidgetOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Widget</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{selectedWidget?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteWidget} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function VisibilityRule({ role, access }: { role: string; access: string }) {
  const accessLabels: Record<string, { label: string; color: string }> = {
    "view-manage": { label: "View & Manage", color: "text-success" },
    "view-only": { label: "View Only", color: "text-info" },
    "no-access": { label: "No Access", color: "text-muted-foreground" },
  };

  const config = accessLabels[access];

  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-foreground">{role}</span>
      <span className={cn("text-xs font-medium", config.color)}>{config.label}</span>
    </div>
  );
}

function StatItem({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className={cn("text-sm font-semibold", highlight ? "text-accent" : "text-foreground")}>
        {value}
      </span>
    </div>
  );
}
