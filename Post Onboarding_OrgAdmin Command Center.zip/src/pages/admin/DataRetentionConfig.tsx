import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Database, Pencil, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";

interface RetentionPolicy {
  id: string;
  category: string;
  retention: string;
  description: string;
  isRequired: boolean;
}

export default function DataRetentionConfig() {
  const { toast } = useToast();
  const [policies, setPolicies] = useState<RetentionPolicy[]>([
    { id: "1", category: "Audit Logs", retention: "365 days", description: "Organization-wide audit trail for all user actions", isRequired: true },
    { id: "2", category: "User Session Data", retention: "90 days", description: "Login sessions and activity timestamps", isRequired: false },
    { id: "3", category: "System Backups", retention: "30 days", description: "Daily system backup snapshots", isRequired: true },
    { id: "4", category: "Archived Records", retention: "7 years", description: "Permanently archived compliance records", isRequired: true },
  ]);

  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [selectedPolicy, setSelectedPolicy] = useState<RetentionPolicy | null>(null);
  const [policyForm, setPolicyForm] = useState({ retention: "", description: "" });

  const handleEdit = () => {
    if (!selectedPolicy || !policyForm.retention) {
      toast({ title: "Error", description: "Retention period is required", variant: "destructive" });
      return;
    }
    setPolicies(policies.map(p => 
      p.id === selectedPolicy.id 
        ? { ...p, retention: policyForm.retention, description: policyForm.description }
        : p
    ));
    setIsEditOpen(false);
    toast({ title: "Success", description: "Retention policy updated" });
  };

  const handleDelete = () => {
    if (!selectedPolicy) return;
    if (selectedPolicy.isRequired) {
      toast({ title: "Error", description: "Required policies cannot be deleted", variant: "destructive" });
      return;
    }
    setPolicies(policies.filter(p => p.id !== selectedPolicy.id));
    setIsDeleteOpen(false);
    toast({ title: "Success", description: "Retention policy deleted" });
  };

  const openEdit = (policy: RetentionPolicy) => {
    setSelectedPolicy(policy);
    setPolicyForm({ 
      retention: policy.retention, 
      description: policy.description
    });
    setIsEditOpen(true);
  };

  const openDelete = (policy: RetentionPolicy) => {
    setSelectedPolicy(policy);
    setIsDeleteOpen(true);
  };

  return (
    <div className="animate-fade-in">
      <div className="border-b border-border bg-card">
        <div className="p-6 max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <Database className="w-7 h-7 text-accent" />
            Data & Retention
          </h1>
          <p className="text-muted-foreground mt-1">
            View and manage organization-level data retention policies for compliance
          </p>
        </div>
      </div>

      <div className="p-6 max-w-7xl mx-auto">
        {/* Retention Policies */}
        <div className="card-section">
          <div className="p-4 border-b border-border">
            <h2 className="font-semibold text-foreground">Organization Retention Policies</h2>
            <p className="text-sm text-muted-foreground">Org-level data retention. App-specific policies are managed within each microapp.</p>
          </div>
          <div className="divide-y divide-border">
            {policies.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">
                No retention policies configured.
              </div>
            ) : (
              policies.map((policy) => (
                <div key={policy.id} className="p-4 flex items-center gap-4 group">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Database className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-foreground">{policy.category}</p>
                      {policy.isRequired && (
                        <Badge variant="secondary" className="text-xs">Required</Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{policy.description}</p>
                  </div>
                  <Badge variant="outline">{policy.retention}</Badge>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(policy)}>
                      <Pencil className="w-4 h-4 text-muted-foreground" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8" 
                      onClick={() => openDelete(policy)}
                      disabled={policy.isRequired}
                    >
                      <Trash2 className={`w-4 h-4 ${policy.isRequired ? "text-muted-foreground/50" : "text-destructive"}`} />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Edit Policy Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Retention Policy</DialogTitle>
            <DialogDescription>Update the retention period for "{selectedPolicy?.category}"</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Category</Label>
              <Input
                value={selectedPolicy?.category || ""}
                disabled
                className="bg-muted"
              />
            </div>
            <div className="space-y-2">
              <Label>Retention Period</Label>
              <Input
                value={policyForm.retention}
                onChange={(e) => setPolicyForm({ ...policyForm, retention: e.target.value })}
                placeholder="e.g., 90 days, 7 years"
              />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Input
                value={policyForm.description}
                onChange={(e) => setPolicyForm({ ...policyForm, description: e.target.value })}
                placeholder="Brief description of this policy"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditOpen(false)}>Cancel</Button>
            <Button onClick={handleEdit}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Retention Policy</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the "{selectedPolicy?.category}" retention policy? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
