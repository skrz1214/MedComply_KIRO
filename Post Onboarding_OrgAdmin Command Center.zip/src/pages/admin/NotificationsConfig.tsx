import { useState } from "react";
import { TabNavigation } from "@/components/admin/TabNavigation";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Bell, Plus, Mail, MessageSquare, Smartphone } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const tabs = [
  { id: "templates", label: "Templates", count: 12 },
  { id: "channels", label: "Channels" },
  { id: "preferences", label: "Preferences" },
];

export default function NotificationsConfig() {
  const [activeTab, setActiveTab] = useState("templates");

  const templates = [
    { id: 1, name: "Issue Created", event: "New compliance issue", channels: ["email", "app"], enabled: true },
    { id: 2, name: "CAPA Due Soon", event: "CAPA action due in 3 days", channels: ["email", "app"], enabled: true },
    { id: 3, name: "Audit Scheduled", event: "New audit scheduled", channels: ["email"], enabled: true },
    { id: 4, name: "Document Approved", event: "Document review complete", channels: ["app"], enabled: true },
    { id: 5, name: "Escalation Alert", event: "Item escalated", channels: ["email", "app", "sms"], enabled: true },
  ];

  return (
    <div className="animate-fade-in">
      <div className="border-b border-border bg-card">
        <div className="p-6 max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
                <Bell className="w-7 h-7 text-accent" />
                Notifications
              </h1>
              <p className="text-muted-foreground mt-1">
                Configure notification templates and delivery preferences
              </p>
            </div>
          </div>

          <TabNavigation
            tabs={tabs}
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />
        </div>
      </div>

      <div className="p-6 max-w-7xl mx-auto">
        {activeTab === "templates" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-foreground">Notification Templates</h2>
              <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90">
                <Plus className="w-4 h-4 mr-2" />
                Create Template
              </Button>
            </div>

            <div className="card-section">
              <div className="divide-y divide-border">
                {templates.map((template) => (
                  <div key={template.id} className="p-4 flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                      <Bell className="w-5 h-5 text-accent" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{template.name}</p>
                      <p className="text-sm text-muted-foreground">{template.event}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {template.channels.includes("email") && (
                        <Badge variant="outline" className="gap-1">
                          <Mail className="w-3 h-3" /> Email
                        </Badge>
                      )}
                      {template.channels.includes("app") && (
                        <Badge variant="outline" className="gap-1">
                          <MessageSquare className="w-3 h-3" /> App
                        </Badge>
                      )}
                      {template.channels.includes("sms") && (
                        <Badge variant="outline" className="gap-1">
                          <Smartphone className="w-3 h-3" /> SMS
                        </Badge>
                      )}
                    </div>
                    <Switch checked={template.enabled} aria-label={`Enable ${template.name}`} />
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === "channels" && (
          <div className="card-section p-6 text-center text-muted-foreground">
            <Bell className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Configure email, SMS, and in-app notification channels</p>
          </div>
        )}

        {activeTab === "preferences" && (
          <div className="card-section p-6 text-center text-muted-foreground">
            <Bell className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Set default notification preferences for roles</p>
          </div>
        )}
      </div>
    </div>
  );
}
