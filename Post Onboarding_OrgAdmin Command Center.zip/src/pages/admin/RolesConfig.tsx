import { useState } from "react";
import { TabNavigation } from "@/components/admin/TabNavigation";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Shield,
  Plus,
  Users,
  ChevronRight,
  Eye,
  Settings,
  LayoutDashboard,
  FileText,
  Download,
  Lock,
  Pencil,
  Trash2,
  Building2,
  Grid3X3,
  AlertTriangle,
  CheckCircle2,
  Mail,
  Briefcase,
  ShieldCheck,
  UserCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const tabs = [
  { id: "users", label: "Users", count: 156 },
  { id: "roles", label: "Roles", count: 4 },
  { id: "entitlements", label: "Entitlements" },
  { id: "app-access", label: "App Access" },
];

// LOV Options from PRD
const ROLE_TYPES = [
  { value: "staff", label: "Staff" },
  { value: "department_head", label: "Department Head" },
  { value: "compliance_head", label: "Compliance Head" },
  { value: "org_admin", label: "Org Admin" },
];

const OBJECT_AREAS = [
  "Issues",
  "CAPA",
  "Audits",
  "Documents",
  "Training",
  "Risk Assessment",
  "Enforcement",
  "Feedback",
  "Reports",
  "Master Compliance Dashboard",
  "Department Dashboard",
  "User Dashboard",
];

const CAPABILITIES = [
  { value: "view", label: "View" },
  { value: "create", label: "Create" },
  { value: "edit", label: "Edit" },
  { value: "submit", label: "Submit" },
  { value: "approve", label: "Approve" },
  { value: "close", label: "Close" },
];

const DATA_SCOPES = [
  { value: "self", label: "Self Only" },
  { value: "department", label: "Department" },
  { value: "org", label: "Organization-wide" },
];

const ACCESS_PRESETS = [
  { value: "recommended", label: "Recommended", description: "Balanced access based on role type" },
  { value: "strict", label: "Strict", description: "Minimal access, maximum security" },
  { value: "operational", label: "Operational", description: "Maximum productivity, broader access" },
];

// Mock microapps from PRD
const MICROAPPS = [
  { id: "1", name: "ComplianceConnect", code: "COMPLIANCE", riskLevel: "high" },
  { id: "2", name: "RiskGuard", code: "RISKGUARD", riskLevel: "high" },
  { id: "3", name: "EnforcePoint", code: "ENFORCE", riskLevel: "high" },
  { id: "4", name: "AuditReady", code: "AUDIT", riskLevel: "high" },
  { id: "5", name: "FeedbackHub", code: "FEEDBACK", riskLevel: "low" },
  { id: "6", name: "Master Compliance Dashboard", code: "MASTER_DASHBOARD", riskLevel: "medium" },
  { id: "7", name: "Department Dashboard", code: "DEPT_DASHBOARD", riskLevel: "low" },
  { id: "8", name: "User Dashboard", code: "USER_DASHBOARD", riskLevel: "low" },
];

// Mock departments
const DEPARTMENTS = [
  { id: "1", name: "Nursing" },
  { id: "2", name: "Administration" },
  { id: "3", name: "Pharmacy" },
  { id: "4", name: "Radiology" },
  { id: "5", name: "Emergency" },
];

export default function RolesConfig() {
  const [activeTab, setActiveTab] = useState("users");

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="p-6 max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
                <Shield className="w-7 h-7 text-accent" />
                Access Management
              </h1>
              <p className="text-muted-foreground mt-1">
                Manage users, roles, permissions, and app access
              </p>
            </div>
          </div>

          <TabNavigation
            tabs={tabs}
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />
        </div>
      </div>

      {/* Content */}
      <div className="p-6 max-w-7xl mx-auto">
        {activeTab === "users" && <UsersTab />}
        {activeTab === "roles" && <RolesTab />}
        {activeTab === "entitlements" && <EntitlementsTab />}
        {activeTab === "app-access" && <AppAccessTab />}
      </div>
    </div>
  );
}

// Types based on PRD 6.5
interface RoleEntitlement {
  objectArea: string;
  scope: "self" | "department" | "org";
  capabilities: string[];
}

interface Role {
  id: string;
  name: string;
  type: "staff" | "department_head" | "compliance_head" | "org_admin";
  isSystemRole: boolean;
  description: string;
  departmentIds: string[];
  microappIds: string[];
  entitlements: RoleEntitlement[];
  userCount: number;
}

interface RoleFormData {
  name: string;
  type: "staff" | "department_head" | "compliance_head" | "org_admin";
  isSystemRole: boolean;
  description: string;
  departmentIds: string[];
  microappIds: string[];
}

function RolesTab() {
  const [roles, setRoles] = useState<Role[]>([
    { 
      id: "1", 
      name: "Org Admin", 
      type: "org_admin",
      isSystemRole: true,
      description: "Full administrative access including system configuration",
      departmentIds: [],
      microappIds: ["1", "2", "3", "4", "5", "6"],
      entitlements: [
        { objectArea: "All", scope: "org", capabilities: ["view", "create", "edit", "submit", "approve", "close"] }
      ],
      userCount: 3,
    },
    { 
      id: "2", 
      name: "Compliance Head", 
      type: "compliance_head",
      isSystemRole: true,
      description: "Organization-wide compliance oversight with approval authority",
      departmentIds: [],
      microappIds: ["1", "2", "3", "4"],
      entitlements: [
        { objectArea: "Issues", scope: "org", capabilities: ["view", "create", "edit", "approve", "close"] },
        { objectArea: "CAPA", scope: "org", capabilities: ["view", "create", "edit", "approve", "close"] },
        { objectArea: "Audits", scope: "org", capabilities: ["view", "create", "edit", "approve"] },
      ],
      userCount: 8,
    },
    { 
      id: "3", 
      name: "Department Head", 
      type: "department_head",
      isSystemRole: true,
      description: "Department manager with full department access and document management",
      departmentIds: ["1", "2"],
      microappIds: ["1", "2", "5"],
      entitlements: [
        { objectArea: "Issues", scope: "department", capabilities: ["view", "create", "edit", "submit"] },
        { objectArea: "Documents", scope: "department", capabilities: ["view", "create", "edit", "approve"] },
        { objectArea: "Training", scope: "department", capabilities: ["view", "create", "edit"] },
      ],
      userCount: 12,
    },
    { 
      id: "4", 
      name: "Staff", 
      type: "staff",
      isSystemRole: true,
      description: "Standard staff member with self-management and department view access",
      departmentIds: [],
      microappIds: ["5", "6"],
      entitlements: [
        { objectArea: "Issues", scope: "self", capabilities: ["view", "create"] },
        { objectArea: "Training", scope: "self", capabilities: ["view"] },
        { objectArea: "Feedback", scope: "self", capabilities: ["view", "create"] },
      ],
      userCount: 133,
    },
  ]);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<RoleFormData>({
    name: "",
    type: "staff",
    isSystemRole: false,
    description: "",
    departmentIds: [],
    microappIds: [],
  });

  const getRoleColor = (type: string) => {
    switch (type) {
      case "org_admin": return "bg-destructive/10 text-destructive";
      case "compliance_head": return "bg-warning/10 text-warning";
      case "department_head": return "bg-info/10 text-info";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const handleCreate = () => {
    setFormData({
      name: "",
      type: "staff",
      isSystemRole: false,
      description: "",
      departmentIds: [],
      microappIds: [],
    });
    setIsEditing(false);
    setDialogOpen(true);
  };

  const handleEdit = (role: Role) => {
    setFormData({
      name: role.name,
      type: role.type,
      isSystemRole: role.isSystemRole,
      description: role.description,
      departmentIds: role.departmentIds,
      microappIds: role.microappIds,
    });
    setSelectedRole(role);
    setIsEditing(true);
    setDialogOpen(true);
  };

  const handleView = (role: Role) => {
    setSelectedRole(role);
    setViewDialogOpen(true);
  };

  const handleDeleteClick = (role: Role) => {
    if (role.isSystemRole) {
      toast.error("System roles cannot be deleted");
      return;
    }
    setSelectedRole(role);
    setDeleteDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.name || !formData.description) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (isEditing && selectedRole) {
      setRoles(roles.map(r => 
        r.id === selectedRole.id 
          ? { ...r, ...formData }
          : r
      ));
      toast.success("Role updated successfully");
    } else {
      const newRole: Role = {
        id: String(Date.now()),
        ...formData,
        entitlements: [],
        userCount: 0,
      };
      setRoles([...roles, newRole]);
      toast.success("Role created successfully");
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (selectedRole) {
      setRoles(roles.filter(r => r.id !== selectedRole.id));
      toast.success("Role deleted successfully");
    }
    setDeleteDialogOpen(false);
  };

  const toggleDepartment = (deptId: string) => {
    setFormData(prev => ({
      ...prev,
      departmentIds: prev.departmentIds.includes(deptId)
        ? prev.departmentIds.filter(id => id !== deptId)
        : [...prev.departmentIds, deptId]
    }));
  };

  const toggleMicroapp = (appId: string) => {
    setFormData(prev => ({
      ...prev,
      microappIds: prev.microappIds.includes(appId)
        ? prev.microappIds.filter(id => id !== appId)
        : [...prev.microappIds, appId]
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Roles</h2>
          <p className="text-sm text-muted-foreground">
            Define roles with type, departments, and microapp assignments
          </p>
        </div>
        <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={handleCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Create Role
        </Button>
      </div>

      <div className="card-section">
        <div className="divide-y divide-border">
          {roles.map((role) => (
            <div
              key={role.id}
              className="p-4 flex items-center gap-4 hover:bg-muted/50 transition-colors group"
            >
              <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", getRoleColor(role.type))}>
                <Shield className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-foreground">{role.name}</p>
                  <Badge variant="outline" className="text-xs capitalize">
                    {role.type.replace("_", " ")}
                  </Badge>
                  {role.isSystemRole && (
                    <Badge variant="secondary" className="text-xs">
                      <Lock className="w-3 h-3 mr-1" />
                      System
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">{role.description}</p>
                <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Grid3X3 className="w-3 h-3" />
                    {role.microappIds.length} apps
                  </span>
                  {role.departmentIds.length > 0 && (
                    <span className="flex items-center gap-1">
                      <Building2 className="w-3 h-3" />
                      {role.departmentIds.length} depts
                    </span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Users className="w-4 h-4" />
                {role.userCount} users
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button variant="ghost" size="icon" onClick={() => handleView(role)}>
                  <Eye className="w-4 h-4 text-muted-foreground" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleEdit(role)}>
                  <Pencil className="w-4 h-4 text-muted-foreground" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => handleDeleteClick(role)}
                  disabled={role.isSystemRole}
                >
                  <Trash2 className={cn("w-4 h-4", role.isSystemRole ? "text-muted-foreground/50" : "text-destructive")} />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{isEditing ? "Edit Role" : "Create New Role"}</DialogTitle>
            <DialogDescription>
              {isEditing ? "Update role configuration." : "Define a new role with type, description, and assignments."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            {/* Basic Info */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Role Name <span className="text-destructive">*</span>
                </label>
                <Input 
                  value={formData.name} 
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter role name"
                  maxLength={100}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Role Type <span className="text-destructive">*</span>
                </label>
                <select 
                  className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as RoleFormData["type"] })}
                >
                  {ROLE_TYPES.map(type => (
                    <option key={type.value} value={type.value}>{type.label}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Description <span className="text-destructive">*</span>
              </label>
              <Input 
                value={formData.description} 
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Brief description of this role's purpose"
                maxLength={500}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox 
                id="isSystemRole"
                checked={formData.isSystemRole}
                onCheckedChange={(checked) => setFormData({ ...formData, isSystemRole: !!checked })}
              />
              <label htmlFor="isSystemRole" className="text-sm font-medium text-foreground cursor-pointer">
                Mark as system role (cannot be deleted)
              </label>
            </div>

            {/* Department Assignments */}
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Department Assignments
              </label>
              <p className="text-xs text-muted-foreground mb-3">
                Leave empty for organization-wide roles
              </p>
              <div className="grid grid-cols-2 gap-2">
                {DEPARTMENTS.map(dept => (
                  <div key={dept.id} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`dept-${dept.id}`}
                      checked={formData.departmentIds.includes(dept.id)}
                      onCheckedChange={() => toggleDepartment(dept.id)}
                    />
                    <label htmlFor={`dept-${dept.id}`} className="text-sm text-foreground cursor-pointer">
                      {dept.name}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Microapp Assignments */}
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Microapp Access <span className="text-destructive">*</span>
              </label>
              <p className="text-xs text-muted-foreground mb-3">
                Select which apps this role can access
              </p>
              <div className="grid grid-cols-2 gap-2">
                {MICROAPPS.map(app => (
                  <div key={app.id} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`app-${app.id}`}
                      checked={formData.microappIds.includes(app.id)}
                      onCheckedChange={() => toggleMicroapp(app.id)}
                    />
                    <label htmlFor={`app-${app.id}`} className="text-sm text-foreground cursor-pointer flex items-center gap-2">
                      {app.name}
                      <Badge 
                        variant="outline" 
                        className={cn(
                          "text-xs",
                          app.riskLevel === "high" && "border-destructive/30 text-destructive",
                          app.riskLevel === "medium" && "border-warning/30 text-warning",
                          app.riskLevel === "low" && "border-success/30 text-success"
                        )}
                      >
                        {app.riskLevel}
                      </Badge>
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={handleSave}>
              {isEditing ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Role Details</DialogTitle>
          </DialogHeader>
          {selectedRole && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-4">
                <div className={cn("w-12 h-12 rounded-lg flex items-center justify-center", getRoleColor(selectedRole.type))}>
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{selectedRole.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="capitalize">{selectedRole.type.replace("_", " ")}</Badge>
                    {selectedRole.isSystemRole && <Badge variant="secondary"><Lock className="w-3 h-3 mr-1" />System</Badge>}
                  </div>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">{selectedRole.description}</p>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Users Assigned</p>
                  <p className="font-medium text-foreground">{selectedRole.userCount}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Microapps</p>
                  <p className="font-medium text-foreground">{selectedRole.microappIds.length} assigned</p>
                </div>
              </div>

              {selectedRole.entitlements.length > 0 && (
                <div>
                  <p className="text-sm font-medium text-foreground mb-2">Entitlements</p>
                  <div className="space-y-2">
                    {selectedRole.entitlements.map((ent, idx) => (
                      <div key={idx} className="p-2 bg-muted/50 rounded-md text-sm">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{ent.objectArea}</span>
                          <Badge variant="outline" className="text-xs capitalize">{ent.scope}</Badge>
                        </div>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {ent.capabilities.map(cap => (
                            <Badge key={cap} variant="secondary" className="text-xs capitalize">{cap}</Badge>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Role</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{selectedRole?.name}"? This action cannot be undone.
              Users with this role will lose their permissions.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

interface EntitlementItem {
  id: string;
  objectArea: string;
  roles: {
    roleName: string;
    scope: string;
    capabilities: string[];
  }[];
}

interface EntitlementFormData {
  objectArea: string;
  roles: {
    roleName: string;
    scope: string;
    capabilities: string[];
  }[];
}

function EntitlementsTab() {
  const [entitlements, setEntitlements] = useState<EntitlementItem[]>([
    {
      id: "1",
      objectArea: "Issues",
      roles: [
        { roleName: "Org Admin", scope: "org", capabilities: ["view", "create", "edit", "submit", "approve", "close"] },
        { roleName: "Compliance Head", scope: "org", capabilities: ["view", "create", "edit", "approve", "close"] },
        { roleName: "Department Head", scope: "department", capabilities: ["view", "create", "edit", "submit"] },
        { roleName: "Staff", scope: "self", capabilities: ["view", "create"] },
      ],
    },
    {
      id: "2",
      objectArea: "CAPA",
      roles: [
        { roleName: "Org Admin", scope: "org", capabilities: ["view", "create", "edit", "submit", "approve", "close"] },
        { roleName: "Compliance Head", scope: "org", capabilities: ["view", "create", "edit", "approve", "close"] },
        { roleName: "Department Head", scope: "department", capabilities: ["view", "create", "edit"] },
        { roleName: "Staff", scope: "self", capabilities: ["view"] },
      ],
    },
    {
      id: "3",
      objectArea: "Audits",
      roles: [
        { roleName: "Org Admin", scope: "org", capabilities: ["view", "create", "edit", "submit", "approve", "close"] },
        { roleName: "Compliance Head", scope: "org", capabilities: ["view", "create", "edit", "approve"] },
        { roleName: "Department Head", scope: "department", capabilities: ["view", "edit"] },
        { roleName: "Staff", scope: "self", capabilities: ["view"] },
      ],
    },
    {
      id: "4",
      objectArea: "Documents",
      roles: [
        { roleName: "Org Admin", scope: "org", capabilities: ["view", "create", "edit", "approve"] },
        { roleName: "Compliance Head", scope: "org", capabilities: ["view", "create", "edit", "approve"] },
        { roleName: "Department Head", scope: "department", capabilities: ["view", "create", "edit", "approve"] },
        { roleName: "Staff", scope: "self", capabilities: ["view"] },
      ],
    },
    {
      id: "5",
      objectArea: "Training",
      roles: [
        { roleName: "Org Admin", scope: "org", capabilities: ["view", "create", "edit", "approve"] },
        { roleName: "Compliance Head", scope: "org", capabilities: ["view", "create", "edit"] },
        { roleName: "Department Head", scope: "department", capabilities: ["view", "create", "edit"] },
        { roleName: "Staff", scope: "self", capabilities: ["view"] },
      ],
    },
    {
      id: "6",
      objectArea: "Risk Assessment",
      roles: [
        { roleName: "Org Admin", scope: "org", capabilities: ["view", "create", "edit", "approve", "close"] },
        { roleName: "Compliance Head", scope: "org", capabilities: ["view", "create", "edit", "approve"] },
        { roleName: "Department Head", scope: "department", capabilities: ["view", "create"] },
        { roleName: "Staff", scope: "self", capabilities: [] },
      ],
    },
  ]);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedEntitlement, setSelectedEntitlement] = useState<EntitlementItem | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  const defaultRoles = [
    { roleName: "Org Admin", scope: "org", capabilities: [] as string[] },
    { roleName: "Compliance Head", scope: "org", capabilities: [] as string[] },
    { roleName: "Department Head", scope: "department", capabilities: [] as string[] },
    { roleName: "Staff", scope: "self", capabilities: [] as string[] },
  ];

  const [formData, setFormData] = useState<EntitlementFormData>({
    objectArea: "",
    roles: defaultRoles,
  });

  const getScopeColor = (scope: string) => {
    switch (scope) {
      case "org": return "bg-destructive/10 text-destructive border-destructive/20";
      case "department": return "bg-info/10 text-info border-info/20";
      case "self": return "bg-muted text-muted-foreground";
      default: return "";
    }
  };

  const handleCreate = () => {
    setFormData({
      objectArea: "",
      roles: defaultRoles.map(r => ({ ...r, capabilities: [] })),
    });
    setIsEditing(false);
    setDialogOpen(true);
  };

  const handleEdit = (item: EntitlementItem) => {
    setFormData({
      objectArea: item.objectArea,
      roles: item.roles.map(r => ({ ...r })),
    });
    setSelectedEntitlement(item);
    setIsEditing(true);
    setDialogOpen(true);
  };

  const handleView = (item: EntitlementItem) => {
    setSelectedEntitlement(item);
    setViewDialogOpen(true);
  };

  const handleDeleteClick = (item: EntitlementItem) => {
    setSelectedEntitlement(item);
    setDeleteDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.objectArea) {
      toast.error("Please select an object area");
      return;
    }

    if (isEditing && selectedEntitlement) {
      setEntitlements(entitlements.map(e =>
        e.id === selectedEntitlement.id
          ? { ...e, ...formData }
          : e
      ));
      toast.success("Entitlement updated successfully");
    } else {
      const newEntitlement: EntitlementItem = {
        id: String(Date.now()),
        ...formData,
      };
      setEntitlements([...entitlements, newEntitlement]);
      toast.success("Entitlement created successfully");
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (selectedEntitlement) {
      setEntitlements(entitlements.filter(e => e.id !== selectedEntitlement.id));
      toast.success("Entitlement deleted successfully");
    }
    setDeleteDialogOpen(false);
  };

  const toggleCapability = (roleIndex: number, capability: string) => {
    setFormData(prev => ({
      ...prev,
      roles: prev.roles.map((role, idx) => {
        if (idx !== roleIndex) return role;
        const caps = role.capabilities.includes(capability)
          ? role.capabilities.filter(c => c !== capability)
          : [...role.capabilities, capability];
        return { ...role, capabilities: caps };
      }),
    }));
  };

  const updateRoleScope = (roleIndex: number, scope: string) => {
    setFormData(prev => ({
      ...prev,
      roles: prev.roles.map((role, idx) =>
        idx === roleIndex ? { ...role, scope } : role
      ),
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Entitlements Matrix</h2>
          <p className="text-sm text-muted-foreground">
            View and manage entitlements by object area with scope and capabilities
          </p>
        </div>
        <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={handleCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Add Entitlement
        </Button>
      </div>

      <div className="text-xs text-muted-foreground flex items-center gap-4 mb-4">
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-destructive/20"></span> Org-wide
        </span>
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-info/20"></span> Department
        </span>
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-muted"></span> Self only
        </span>
      </div>

      {entitlements.map((item) => (
        <div key={item.id} className="card-section group">
          <div className="p-4 border-b border-border flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-accent" />
              <h3 className="font-medium text-foreground">{item.objectArea}</h3>
            </div>
            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <Button variant="ghost" size="icon" onClick={() => handleView(item)}>
                <Eye className="w-4 h-4 text-muted-foreground" />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => handleEdit(item)}>
                <Pencil className="w-4 h-4 text-muted-foreground" />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => handleDeleteClick(item)}>
                <Trash2 className="w-4 h-4 text-destructive" />
              </Button>
            </div>
          </div>
          <div className="divide-y divide-border">
            {item.roles.map((role) => (
              <div key={role.roleName} className="p-4 flex items-center gap-4">
                <div className="w-32 flex-shrink-0">
                  <p className="text-sm font-medium text-foreground">{role.roleName}</p>
                </div>
                <Badge variant="outline" className={cn("text-xs capitalize", getScopeColor(role.scope))}>
                  {role.scope}
                </Badge>
                <div className="flex-1 flex flex-wrap gap-1">
                  {role.capabilities.length > 0 ? (
                    role.capabilities.map((cap) => (
                      <Badge key={cap} variant="secondary" className="text-xs capitalize">
                        {cap}
                      </Badge>
                    ))
                  ) : (
                    <span className="text-xs text-muted-foreground italic">No access</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{isEditing ? "Edit Entitlement" : "Add New Entitlement"}</DialogTitle>
            <DialogDescription>
              {isEditing ? "Update entitlement configuration." : "Define entitlements for an object area."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Object Area <span className="text-destructive">*</span>
              </label>
              <select
                className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                value={formData.objectArea}
                onChange={(e) => setFormData({ ...formData, objectArea: e.target.value })}
              >
                <option value="">Select object area</option>
                {OBJECT_AREAS.filter(area => !entitlements.some(e => e.objectArea === area) || (isEditing && selectedEntitlement?.objectArea === area)).map(area => (
                  <option key={area} value={area}>{area}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground block mb-3">Role Permissions</label>
              <div className="space-y-4">
                {formData.roles.map((role, roleIndex) => (
                  <div key={role.roleName} className="p-4 border border-border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <span className="font-medium text-foreground">{role.roleName}</span>
                      <select
                        className="px-2 py-1 text-sm bg-background border border-input rounded-md"
                        value={role.scope}
                        onChange={(e) => updateRoleScope(roleIndex, e.target.value)}
                      >
                        {DATA_SCOPES.map(scope => (
                          <option key={scope.value} value={scope.value}>{scope.label}</option>
                        ))}
                      </select>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {CAPABILITIES.map(cap => (
                        <label key={cap.value} className="flex items-center gap-2 cursor-pointer">
                          <Checkbox
                            checked={role.capabilities.includes(cap.value)}
                            onCheckedChange={() => toggleCapability(roleIndex, cap.value)}
                          />
                          <span className="text-sm text-foreground">{cap.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={handleSave}>
              {isEditing ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Entitlement Details</DialogTitle>
          </DialogHeader>
          {selectedEntitlement && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-3">
                <FileText className="w-6 h-6 text-accent" />
                <h3 className="font-semibold text-foreground text-lg">{selectedEntitlement.objectArea}</h3>
              </div>
              <div className="space-y-3">
                {selectedEntitlement.roles.map((role) => (
                  <div key={role.roleName} className="p-3 bg-muted/50 rounded-md">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-foreground">{role.roleName}</span>
                      <Badge variant="outline" className={cn("text-xs capitalize", getScopeColor(role.scope))}>
                        {role.scope}
                      </Badge>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {role.capabilities.length > 0 ? (
                        role.capabilities.map((cap) => (
                          <Badge key={cap} variant="secondary" className="text-xs capitalize">{cap}</Badge>
                        ))
                      ) : (
                        <span className="text-xs text-muted-foreground italic">No access</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Entitlement</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the entitlement for "{selectedEntitlement?.objectArea}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

interface AppAccessItem {
  id: string;
  app: string;
  code: string;
  riskLevel: string;
  roles: {
    role: string;
    accessLevel: string;
    scope: string;
  }[];
}

interface AppAccessFormData {
  app: string;
  code: string;
  riskLevel: string;
  roles: {
    role: string;
    accessLevel: string;
    scope: string;
  }[];
}

function AppAccessTab() {
  const [selectedPreset, setSelectedPreset] = useState<string>("recommended");

  const [appAccessList, setAppAccessList] = useState<AppAccessItem[]>([
    {
      id: "1",
      app: "ComplianceConnect",
      code: "COMPLIANCE",
      riskLevel: "high",
      roles: [
        { role: "Org Admin", accessLevel: "manage", scope: "org" },
        { role: "Compliance Head", accessLevel: "manage", scope: "org" },
        { role: "Department Head", accessLevel: "view", scope: "department" },
        { role: "Staff", accessLevel: "none", scope: "self" },
      ],
    },
    {
      id: "2",
      app: "RiskGuard",
      code: "RISKGUARD",
      riskLevel: "high",
      roles: [
        { role: "Org Admin", accessLevel: "manage", scope: "org" },
        { role: "Compliance Head", accessLevel: "manage", scope: "org" },
        { role: "Department Head", accessLevel: "view", scope: "department" },
        { role: "Staff", accessLevel: "none", scope: "self" },
      ],
    },
    {
      id: "3",
      app: "AuditReady",
      code: "AUDIT",
      riskLevel: "high",
      roles: [
        { role: "Org Admin", accessLevel: "manage", scope: "org" },
        { role: "Compliance Head", accessLevel: "manage", scope: "org" },
        { role: "Department Head", accessLevel: "view", scope: "department" },
        { role: "Staff", accessLevel: "view", scope: "self" },
      ],
    },
    {
      id: "4",
      app: "FeedbackHub",
      code: "FEEDBACK",
      riskLevel: "low",
      roles: [
        { role: "Org Admin", accessLevel: "manage", scope: "org" },
        { role: "Compliance Head", accessLevel: "view", scope: "org" },
        { role: "Department Head", accessLevel: "manage", scope: "department" },
        { role: "Staff", accessLevel: "manage", scope: "self" },
      ],
    },
    {
      id: "5",
      app: "Master Compliance Dashboard",
      code: "MASTER_DASHBOARD",
      riskLevel: "medium",
      roles: [
        { role: "Org Admin", accessLevel: "manage", scope: "org" },
        { role: "Compliance Head", accessLevel: "manage", scope: "org" },
        { role: "Department Head", accessLevel: "none", scope: "self" },
        { role: "Staff", accessLevel: "none", scope: "self" },
      ],
    },
    {
      id: "6",
      app: "Department Dashboard",
      code: "DEPT_DASHBOARD",
      riskLevel: "low",
      roles: [
        { role: "Org Admin", accessLevel: "manage", scope: "org" },
        { role: "Compliance Head", accessLevel: "view", scope: "org" },
        { role: "Department Head", accessLevel: "manage", scope: "department" },
        { role: "Staff", accessLevel: "view", scope: "self" },
      ],
    },
    {
      id: "7",
      app: "User Dashboard",
      code: "USER_DASHBOARD",
      riskLevel: "low",
      roles: [
        { role: "Org Admin", accessLevel: "view", scope: "org" },
        { role: "Compliance Head", accessLevel: "view", scope: "org" },
        { role: "Department Head", accessLevel: "view", scope: "department" },
        { role: "Staff", accessLevel: "manage", scope: "self" },
      ],
    },
  ]);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedAppAccess, setSelectedAppAccess] = useState<AppAccessItem | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  const defaultRoles = [
    { role: "Org Admin", accessLevel: "none", scope: "org" },
    { role: "Compliance Head", accessLevel: "none", scope: "org" },
    { role: "Department Head", accessLevel: "none", scope: "department" },
    { role: "Staff", accessLevel: "none", scope: "self" },
  ];

  const [formData, setFormData] = useState<AppAccessFormData>({
    app: "",
    code: "",
    riskLevel: "medium",
    roles: defaultRoles,
  });

  const ACCESS_LEVELS = [
    { value: "none", label: "No Access" },
    { value: "view", label: "View Only" },
    { value: "manage", label: "Full Access" },
  ];

  const RISK_LEVELS = [
    { value: "low", label: "Low" },
    { value: "medium", label: "Medium" },
    { value: "high", label: "High" },
  ];

  const getAccessLevelColor = (level: string) => {
    switch (level) {
      case "manage": return "bg-success/10 text-success border-success/20";
      case "view": return "bg-info/10 text-info border-info/20";
      case "none": return "bg-muted text-muted-foreground";
      default: return "";
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case "high": return "border-destructive/30 text-destructive";
      case "medium": return "border-warning/30 text-warning";
      case "low": return "border-success/30 text-success";
      default: return "";
    }
  };

  const handleCreate = () => {
    setFormData({
      app: "",
      code: "",
      riskLevel: "medium",
      roles: defaultRoles.map(r => ({ ...r })),
    });
    setIsEditing(false);
    setDialogOpen(true);
  };

  const handleEdit = (item: AppAccessItem) => {
    setFormData({
      app: item.app,
      code: item.code,
      riskLevel: item.riskLevel,
      roles: item.roles.map(r => ({ ...r })),
    });
    setSelectedAppAccess(item);
    setIsEditing(true);
    setDialogOpen(true);
  };

  const handleView = (item: AppAccessItem) => {
    setSelectedAppAccess(item);
    setViewDialogOpen(true);
  };

  const handleDeleteClick = (item: AppAccessItem) => {
    setSelectedAppAccess(item);
    setDeleteDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.app || !formData.code) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (isEditing && selectedAppAccess) {
      setAppAccessList(appAccessList.map(a =>
        a.id === selectedAppAccess.id
          ? { ...a, ...formData }
          : a
      ));
      toast.success("App access updated successfully");
    } else {
      const newAppAccess: AppAccessItem = {
        id: String(Date.now()),
        ...formData,
      };
      setAppAccessList([...appAccessList, newAppAccess]);
      toast.success("App access created successfully");
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (selectedAppAccess) {
      setAppAccessList(appAccessList.filter(a => a.id !== selectedAppAccess.id));
      toast.success("App access deleted successfully");
    }
    setDeleteDialogOpen(false);
  };

  const updateRoleAccess = (roleIndex: number, field: "accessLevel" | "scope", value: string) => {
    setFormData(prev => ({
      ...prev,
      roles: prev.roles.map((role, idx) =>
        idx === roleIndex ? { ...role, [field]: value } : role
      ),
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">App Access Configuration</h2>
          <p className="text-sm text-muted-foreground">
            Configure app access levels and data scope by role
          </p>
        </div>
        <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={handleCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Add App Access
        </Button>
      </div>

      {/* Preset Selection */}
      <div className="card-section p-4">
        <h3 className="font-medium text-foreground mb-3">Access Preset</h3>
        <div className="grid grid-cols-3 gap-4">
          {ACCESS_PRESETS.map((preset) => (
            <button
              key={preset.value}
              onClick={() => setSelectedPreset(preset.value)}
              className={cn(
                "p-4 rounded-lg border-2 text-left transition-all",
                selectedPreset === preset.value
                  ? "border-accent bg-accent/5"
                  : "border-border hover:border-accent/50"
              )}
            >
              <div className="flex items-center gap-2 mb-1">
                {selectedPreset === preset.value && <CheckCircle2 className="w-4 h-4 text-accent" />}
                <span className="font-medium text-foreground">{preset.label}</span>
              </div>
              <p className="text-xs text-muted-foreground">{preset.description}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Access Legend */}
      <div className="text-xs text-muted-foreground flex items-center gap-6">
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-success/20"></span> Manage (full access)
        </span>
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-info/20"></span> View only
        </span>
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-muted"></span> No access
        </span>
      </div>

      {/* App Access Matrix */}
      {appAccessList.map((app) => (
        <div key={app.id} className="card-section group">
          <div className="p-4 border-b border-border flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Grid3X3 className="w-5 h-5 text-accent" />
              <h3 className="font-medium text-foreground">{app.app}</h3>
              <Badge variant="outline" className="text-xs">{app.code}</Badge>
              <Badge variant="outline" className={cn("text-xs", getRiskColor(app.riskLevel))}>
                <AlertTriangle className="w-3 h-3 mr-1" />
                {app.riskLevel} risk
              </Badge>
            </div>
            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <Button variant="ghost" size="icon" onClick={() => handleView(app)}>
                <Eye className="w-4 h-4 text-muted-foreground" />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => handleEdit(app)}>
                <Pencil className="w-4 h-4 text-muted-foreground" />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => handleDeleteClick(app)}>
                <Trash2 className="w-4 h-4 text-destructive" />
              </Button>
            </div>
          </div>
          <div className="p-4">
            <div className="grid grid-cols-3 gap-4 mb-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">
              <div>Role</div>
              <div className="text-center">Access Level</div>
              <div className="text-center">Data Scope</div>
            </div>
            <div className="space-y-2">
              {app.roles.map((role) => (
                <div key={role.role} className="grid grid-cols-3 gap-4 items-center py-2 border-b border-border last:border-0">
                  <div className="text-sm font-medium text-foreground">{role.role}</div>
                  <div className="flex justify-center">
                    <Badge variant="outline" className={cn("text-xs capitalize", getAccessLevelColor(role.accessLevel))}>
                      {role.accessLevel}
                    </Badge>
                  </div>
                  <div className="flex justify-center">
                    <Badge variant="outline" className="text-xs capitalize">
                      {role.scope}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}

      {/* Export Controls */}
      <div className="card-section p-4">
        <h3 className="font-medium text-foreground mb-3 flex items-center gap-2">
          <Download className="w-4 h-4" />
          Export Controls
        </h3>
        <div className="grid grid-cols-4 gap-4">
          {["Org Admin", "Compliance Head", "Department Head", "Staff"].map((role) => (
            <div key={role} className="p-3 bg-muted/50 rounded-lg">
              <p className="text-sm font-medium text-foreground mb-2">{role}</p>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">CSV Export</span>
                  <Switch defaultChecked={role !== "Staff"} />
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">PDF Export</span>
                  <Switch defaultChecked={role !== "Staff"} />
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Cross-App KPIs</span>
                  <Switch defaultChecked={role === "Org Admin" || role === "Compliance Head"} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{isEditing ? "Edit App Access" : "Add New App Access"}</DialogTitle>
            <DialogDescription>
              {isEditing ? "Update app access configuration." : "Define access levels for an application."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  App Name <span className="text-destructive">*</span>
                </label>
                <Input
                  value={formData.app}
                  onChange={(e) => setFormData({ ...formData, app: e.target.value })}
                  placeholder="Enter app name"
                  maxLength={100}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  App Code <span className="text-destructive">*</span>
                </label>
                <Input
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                  placeholder="e.g., COMPLIANCE"
                  maxLength={20}
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Risk Level <span className="text-destructive">*</span>
              </label>
              <select
                className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                value={formData.riskLevel}
                onChange={(e) => setFormData({ ...formData, riskLevel: e.target.value })}
              >
                {RISK_LEVELS.map(level => (
                  <option key={level.value} value={level.value}>{level.label}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground block mb-3">Role Access Levels</label>
              <div className="space-y-4">
                {formData.roles.map((role, roleIndex) => (
                  <div key={role.role} className="p-4 border border-border rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-foreground">{role.role}</span>
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground">Access:</span>
                          <select
                            className="px-2 py-1 text-sm bg-background border border-input rounded-md"
                            value={role.accessLevel}
                            onChange={(e) => updateRoleAccess(roleIndex, "accessLevel", e.target.value)}
                          >
                            {ACCESS_LEVELS.map(level => (
                              <option key={level.value} value={level.value}>{level.label}</option>
                            ))}
                          </select>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground">Scope:</span>
                          <select
                            className="px-2 py-1 text-sm bg-background border border-input rounded-md"
                            value={role.scope}
                            onChange={(e) => updateRoleAccess(roleIndex, "scope", e.target.value)}
                          >
                            {DATA_SCOPES.map(scope => (
                              <option key={scope.value} value={scope.value}>{scope.label}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={handleSave}>
              {isEditing ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>App Access Details</DialogTitle>
          </DialogHeader>
          {selectedAppAccess && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-3">
                <Grid3X3 className="w-6 h-6 text-accent" />
                <div>
                  <h3 className="font-semibold text-foreground text-lg">{selectedAppAccess.app}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="text-xs">{selectedAppAccess.code}</Badge>
                    <Badge variant="outline" className={cn("text-xs", getRiskColor(selectedAppAccess.riskLevel))}>
                      {selectedAppAccess.riskLevel} risk
                    </Badge>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                {selectedAppAccess.roles.map((role) => (
                  <div key={role.role} className="p-3 bg-muted/50 rounded-md flex items-center justify-between">
                    <span className="font-medium text-foreground">{role.role}</span>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={cn("text-xs capitalize", getAccessLevelColor(role.accessLevel))}>
                        {role.accessLevel}
                      </Badge>
                      <Badge variant="outline" className="text-xs capitalize">{role.scope}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete App Access</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete access configuration for "{selectedAppAccess?.app}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// User Status options
const USER_STATUSES = [
  { value: "active", label: "Active" },
  { value: "inactive", label: "Inactive" },
  { value: "pending", label: "Pending" },
  { value: "suspended", label: "Suspended" },
];

interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  jobTitle: string;
  departmentIds: string[];
  roleIds: string[];
  mfaEnabled: boolean;
  status: "active" | "inactive" | "pending" | "suspended";
  createdAt: string;
}

interface UserFormData {
  firstName: string;
  lastName: string;
  email: string;
  jobTitle: string;
  departmentIds: string[];
  roleIds: string[];
  mfaEnabled: boolean;
  status: "active" | "inactive" | "pending" | "suspended";
}

const ROLE_OPTIONS = [
  { id: "1", name: "Org Admin" },
  { id: "2", name: "Compliance Head" },
  { id: "3", name: "Department Head" },
  { id: "4", name: "Staff" },
];

function UsersTab() {
  const [users, setUsers] = useState<User[]>([
    {
      id: "1",
      firstName: "John",
      lastName: "Smith",
      email: "john.smith@hospital.org",
      jobTitle: "Chief Compliance Officer",
      departmentIds: [],
      roleIds: ["1"],
      mfaEnabled: true,
      status: "active",
      createdAt: "2024-01-15",
    },
    {
      id: "2",
      firstName: "Sarah",
      lastName: "Johnson",
      email: "sarah.johnson@hospital.org",
      jobTitle: "Compliance Manager",
      departmentIds: ["1", "2"],
      roleIds: ["2"],
      mfaEnabled: true,
      status: "active",
      createdAt: "2024-02-10",
    },
    {
      id: "3",
      firstName: "Michael",
      lastName: "Chen",
      email: "michael.chen@hospital.org",
      jobTitle: "Department Head - Nursing",
      departmentIds: ["1"],
      roleIds: ["3"],
      mfaEnabled: false,
      status: "active",
      createdAt: "2024-03-05",
    },
    {
      id: "4",
      firstName: "Emily",
      lastName: "Davis",
      email: "emily.davis@hospital.org",
      jobTitle: "Staff Nurse",
      departmentIds: ["1"],
      roleIds: ["4"],
      mfaEnabled: false,
      status: "active",
      createdAt: "2024-04-20",
    },
    {
      id: "5",
      firstName: "Robert",
      lastName: "Wilson",
      email: "robert.wilson@hospital.org",
      jobTitle: "IT Administrator",
      departmentIds: ["6"],
      roleIds: ["1"],
      mfaEnabled: true,
      status: "pending",
      createdAt: "2024-05-12",
    },
  ]);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<UserFormData>({
    firstName: "",
    lastName: "",
    email: "",
    jobTitle: "",
    departmentIds: [],
    roleIds: [],
    mfaEnabled: false,
    status: "pending",
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-success/10 text-success";
      case "inactive": return "bg-muted text-muted-foreground";
      case "pending": return "bg-warning/10 text-warning";
      case "suspended": return "bg-destructive/10 text-destructive";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const handleCreate = () => {
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      jobTitle: "",
      departmentIds: [],
      roleIds: [],
      mfaEnabled: false,
      status: "pending",
    });
    setIsEditing(false);
    setDialogOpen(true);
  };

  const handleEdit = (user: User) => {
    setFormData({
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      jobTitle: user.jobTitle,
      departmentIds: user.departmentIds,
      roleIds: user.roleIds,
      mfaEnabled: user.mfaEnabled,
      status: user.status,
    });
    setSelectedUser(user);
    setIsEditing(true);
    setDialogOpen(true);
  };

  const handleView = (user: User) => {
    setSelectedUser(user);
    setViewDialogOpen(true);
  };

  const handleDeleteClick = (user: User) => {
    setSelectedUser(user);
    setDeleteDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.firstName || !formData.lastName || !formData.email) {
      toast.error("Please fill in all required fields");
      return;
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      toast.error("Please enter a valid email address");
      return;
    }

    if (isEditing && selectedUser) {
      setUsers(users.map(u => 
        u.id === selectedUser.id 
          ? { ...u, ...formData }
          : u
      ));
      toast.success("User updated successfully");
    } else {
      const newUser: User = {
        id: String(Date.now()),
        ...formData,
        createdAt: new Date().toISOString().split("T")[0],
      };
      setUsers([...users, newUser]);
      toast.success("User created successfully");
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (selectedUser) {
      setUsers(users.filter(u => u.id !== selectedUser.id));
      toast.success("User deleted successfully");
    }
    setDeleteDialogOpen(false);
  };

  const toggleDepartment = (deptId: string) => {
    setFormData(prev => ({
      ...prev,
      departmentIds: prev.departmentIds.includes(deptId)
        ? prev.departmentIds.filter(id => id !== deptId)
        : [...prev.departmentIds, deptId]
    }));
  };

  const toggleRole = (roleId: string) => {
    setFormData(prev => ({
      ...prev,
      roleIds: prev.roleIds.includes(roleId)
        ? prev.roleIds.filter(id => id !== roleId)
        : [...prev.roleIds, roleId]
    }));
  };

  const getRoleNames = (roleIds: string[]) => {
    return roleIds.map(id => ROLE_OPTIONS.find(r => r.id === id)?.name || "Unknown").join(", ");
  };

  const getDeptNames = (deptIds: string[]) => {
    return deptIds.map(id => DEPARTMENTS.find(d => d.id === id)?.name || "Unknown").join(", ");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Users</h2>
          <p className="text-sm text-muted-foreground">
            Manage user accounts, roles, and department assignments
          </p>
        </div>
        <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={handleCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Add User
        </Button>
      </div>

      <div className="card-section">
        <div className="divide-y divide-border">
          {users.map((user) => (
            <div
              key={user.id}
              className="p-4 flex items-center gap-4 hover:bg-muted/50 transition-colors group"
            >
              <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
                <UserCircle className="w-6 h-6 text-accent" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-foreground">{user.firstName} {user.lastName}</p>
                  <Badge className={cn("text-xs capitalize", getStatusColor(user.status))}>
                    {user.status}
                  </Badge>
                  {user.mfaEnabled && (
                    <Badge variant="outline" className="text-xs">
                      <ShieldCheck className="w-3 h-3 mr-1" />
                      MFA
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground mt-0.5">
                  <span className="flex items-center gap-1">
                    <Mail className="w-3 h-3" />
                    {user.email}
                  </span>
                  <span className="flex items-center gap-1">
                    <Briefcase className="w-3 h-3" />
                    {user.jobTitle}
                  </span>
                </div>
                <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Shield className="w-3 h-3" />
                    {getRoleNames(user.roleIds) || "No roles"}
                  </span>
                  {user.departmentIds.length > 0 && (
                    <span className="flex items-center gap-1">
                      <Building2 className="w-3 h-3" />
                      {getDeptNames(user.departmentIds)}
                    </span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button variant="ghost" size="icon" onClick={() => handleView(user)}>
                  <Eye className="w-4 h-4 text-muted-foreground" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleEdit(user)}>
                  <Pencil className="w-4 h-4 text-muted-foreground" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleDeleteClick(user)}>
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Create/Edit User Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{isEditing ? "Edit User" : "Add New User"}</DialogTitle>
            <DialogDescription>
              {isEditing ? "Update user information and assignments." : "Create a new user account with role and department assignments."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            {/* Basic Info */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  First Name <span className="text-destructive">*</span>
                </label>
                <Input 
                  value={formData.firstName} 
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  placeholder="Enter first name"
                  maxLength={50}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Last Name <span className="text-destructive">*</span>
                </label>
                <Input 
                  value={formData.lastName} 
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  placeholder="Enter last name"
                  maxLength={50}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Email <span className="text-destructive">*</span>
                </label>
                <Input 
                  type="email"
                  value={formData.email} 
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="Enter email address"
                  maxLength={100}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Job Title
                </label>
                <Input 
                  value={formData.jobTitle} 
                  onChange={(e) => setFormData({ ...formData, jobTitle: e.target.value })}
                  placeholder="Enter job title"
                  maxLength={100}
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Status
              </label>
              <select 
                className="w-full px-3 py-2 text-sm bg-background border border-input rounded-md"
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as UserFormData["status"] })}
              >
                {USER_STATUSES.map(status => (
                  <option key={status.value} value={status.value}>{status.label}</option>
                ))}
              </select>
            </div>

            {/* Roles */}
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Roles
              </label>
              <div className="grid grid-cols-2 gap-2">
                {ROLE_OPTIONS.map(role => (
                  <div key={role.id} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`role-${role.id}`}
                      checked={formData.roleIds.includes(role.id)}
                      onCheckedChange={() => toggleRole(role.id)}
                    />
                    <label htmlFor={`role-${role.id}`} className="text-sm text-foreground cursor-pointer">
                      {role.name}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Departments */}
            <div>
              <label className="text-sm font-medium text-foreground block mb-2">
                Departments
              </label>
              <div className="grid grid-cols-2 gap-2">
                {DEPARTMENTS.map(dept => (
                  <div key={dept.id} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`dept-${dept.id}`}
                      checked={formData.departmentIds.includes(dept.id)}
                      onCheckedChange={() => toggleDepartment(dept.id)}
                    />
                    <label htmlFor={`dept-${dept.id}`} className="text-sm text-foreground cursor-pointer">
                      {dept.name}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* MFA Toggle */}
            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">Multi-Factor Authentication</p>
                <p className="text-xs text-muted-foreground">Require MFA for this user's account</p>
              </div>
              <Switch
                checked={formData.mfaEnabled}
                onCheckedChange={(checked) => setFormData({ ...formData, mfaEnabled: checked })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{isEditing ? "Save Changes" : "Add User"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View User Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserCircle className="w-5 h-5" />
              User Details
            </DialogTitle>
          </DialogHeader>
          {selectedUser && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center">
                  <UserCircle className="w-10 h-10 text-accent" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground">
                    {selectedUser.firstName} {selectedUser.lastName}
                  </h3>
                  <p className="text-sm text-muted-foreground">{selectedUser.jobTitle}</p>
                  <Badge className={cn("text-xs capitalize mt-1", getStatusColor(selectedUser.status))}>
                    {selectedUser.status}
                  </Badge>
                </div>
              </div>

              <div className="space-y-3 pt-4 border-t border-border">
                <div className="flex items-start gap-3">
                  <Mail className="w-4 h-4 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-xs text-muted-foreground">Email</p>
                    <p className="text-sm text-foreground">{selectedUser.email}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Shield className="w-4 h-4 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-xs text-muted-foreground">Roles</p>
                    <p className="text-sm text-foreground">{getRoleNames(selectedUser.roleIds) || "No roles assigned"}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Building2 className="w-4 h-4 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-xs text-muted-foreground">Departments</p>
                    <p className="text-sm text-foreground">{getDeptNames(selectedUser.departmentIds) || "No departments assigned"}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <ShieldCheck className="w-4 h-4 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-xs text-muted-foreground">MFA Status</p>
                    <p className="text-sm text-foreground">{selectedUser.mfaEnabled ? "Enabled" : "Disabled"}</p>
                  </div>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewDialogOpen(false)}>Close</Button>
            <Button onClick={() => { setViewDialogOpen(false); if (selectedUser) handleEdit(selectedUser); }}>
              Edit User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete User</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {selectedUser?.firstName} {selectedUser?.lastName}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}