import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  FileText,
  Download,
  Eye,
  BookOpen,
  TestTube,
  Users,
  Code,
  ChevronDown,
  ChevronRight,
  CheckCircle2,
  Calendar,
  User,
  Bot,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import jsPDF from "jspdf";

interface DocumentSection {
  id: string;
  title: string;
  content: string[];
}

interface DevDocument {
  id: string;
  title: string;
  shortTitle: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  version: string;
  lastUpdated: string;
  author: string;
  status: "approved" | "draft" | "review";
  sections: DocumentSection[];
}

const documents: DevDocument[] = [
  {
    id: "prd",
    title: "Product Requirements Document (PRD)",
    shortTitle: "PRD",
    description: "Complete product requirements for MedComply Admin Center",
    icon: BookOpen,
    version: "2.1",
    lastUpdated: "2024-01-15",
    author: "Product Team",
    status: "approved",
    sections: [
      {
        id: "overview",
        title: "1. Executive Overview",
        content: [
          "1.1 Product Vision: MedComply Admin Center is a centralized configuration and management platform for healthcare compliance operations.",
          "1.2 Target Users: Organization Administrators, Compliance Officers, IT Administrators",
          "1.3 Business Objectives:",
          "  - Reduce configuration time by 60%",
          "  - Centralize all admin functions in one interface",
          "  - Enable self-service organization management",
          "  - Provide audit trail for all configuration changes",
        ],
      },
      {
        id: "org-structure",
        title: "2. Organization & Structure",
        content: [
          "2.1 Organization Profile Management:",
          "  - Organization name, type, and contact information",
          "  - Logo and branding configuration",
          "  - Timezone and locale settings",
          "  - Regulatory framework selection (CMS, Joint Commission, State)",
          "",
          "2.2 Facility Management:",
          "  - Add/Edit/Delete facilities",
          "  - Facility type classification (Hospital, Clinic, SNF, etc.)",
          "  - Address and contact details",
          "  - Facility-specific compliance requirements",
          "",
          "2.3 Department Management:",
          "  - Hierarchical department structure",
          "  - Department heads assignment",
          "  - Cost center mapping",
          "  - Department-level compliance ownership",
        ],
      },
      {
        id: "access-management",
        title: "3. Access Management",
        content: [
          "3.1 User Management:",
          "  - User provisioning and deprovisioning",
          "  - Bulk user import via CSV",
          "  - User status management (Active, Inactive, Locked)",
          "  - Department and facility assignment",
          "",
          "3.2 Role Configuration:",
          "  - Role types: Org Admin, Compliance Head, Department Head, Staff",
          "  - System roles (non-deletable) vs Custom roles",
          "  - Role-to-department mapping",
          "  - Role-to-microapp assignment",
          "",
          "3.3 Entitlements:",
          "  - Object Areas: Issues, CAPA, Audits, Documents, Training, Risk Assessment, Enforcement, Feedback, Reports, Dashboards",
          "  - Capabilities: View, Create, Edit, Submit, Approve, Close",
          "  - Data Scopes: Self Only, Department, Organization-wide",
          "",
          "3.4 App Access Control:",
          "  - Per-role microapp visibility",
          "  - Feature-level permissions within apps",
          "  - Access inheritance rules",
        ],
      },
      {
        id: "microapps",
        title: "4. Microapp Configuration",
        content: [
          "4.1 Available Microapps:",
          "  - ComplianceConnect: Issue tracking and CAPA management",
          "  - RiskGuard: Risk assessment and mitigation",
          "  - EnforcePoint: Enforcement action tracking",
          "  - AuditReady: Audit scheduling and management",
          "  - FeedbackHub: Feedback collection and analysis",
          "",
          "4.2 App-Level Settings:",
          "  - Enable/Disable per organization",
          "  - Default workflow configurations",
          "  - Notification preferences",
          "  - Data retention policies (app-specific)",
          "",
          "4.3 Integration Points:",
          "  - Cross-app data sharing rules",
          "  - Unified search configuration",
          "  - Dashboard widget availability",
        ],
      },
      {
        id: "dashboards",
        title: "5. Dashboard Configuration",
        content: [
          "5.1 Three-Layer Dashboard Architecture:",
          "  - Master Dashboard (Organization-wide)",
          "  - Department Dashboards (Per department)",
          "  - Personal Dashboards (Individual users)",
          "",
          "5.2 Master Dashboard:",
          "  - Org-wide KPIs and metrics",
          "  - Compliance score visualization",
          "  - Cross-department comparisons",
          "  - Executive summary widgets",
          "",
          "5.3 Department Dashboards:",
          "  - Department-specific metrics",
          "  - Team performance indicators",
          "  - Pending actions and escalations",
          "  - Template-based configuration",
          "",
          "5.4 Personal Dashboards:",
          "  - User-specific task lists",
          "  - Personal compliance metrics",
          "  - Customizable widget layout",
          "  - Saved filters and views",
        ],
      },
      {
        id: "data-retention",
        title: "6. Data & Retention",
        content: [
          "6.1 Retention Policies:",
          "  - Audit Logs: Configurable (default 365 days)",
          "  - User Session Data: Configurable (default 90 days)",
          "  - System Backups: Configurable (default 30 days)",
          "  - Archived Records: Configurable (default 7 years)",
          "",
          "6.2 Policy Enforcement:",
          "  - Required policies (non-deletable)",
          "  - Compliance-driven retention periods",
          "  - Automatic archival workflows",
        ],
      },
      {
        id: "audit-trail",
        title: "7. Audit Trail & History",
        content: [
          "7.1 Change History:",
          "  - All configuration changes logged",
          "  - User attribution for every action",
          "  - Timestamp and IP address recording",
          "  - Before/after value comparison",
          "",
          "7.2 Audit Log Categories:",
          "  - Authentication events",
          "  - User management actions",
          "  - Security policy changes",
          "  - Configuration updates",
          "",
          "7.3 Export Capabilities:",
          "  - CSV and JSON export formats",
          "  - Filtered export based on criteria",
          "  - Scheduled report generation",
        ],
      },
      {
        id: "lov-manager",
        title: "8. LOV Manager",
        content: [
          "8.1 List of Values Management:",
          "  - System LOVs (non-editable)",
          "  - Organization LOVs (customizable)",
          "  - App-specific LOVs",
          "",
          "8.2 LOV Configuration:",
          "  - Add/Edit/Delete values",
          "  - Display order management",
          "  - Active/Inactive status",
          "  - Default value selection",
          "",
          "8.3 Usage Tracking:",
          "  - LOV usage count per app",
          "  - Impact analysis before deletion",
          "  - Bulk update capabilities",
        ],
      },
    ],
  },
  {
    id: "tdd",
    title: "Technical Design Document (TDD)",
    shortTitle: "TDD",
    description: "Technical architecture and implementation specifications",
    icon: Code,
    version: "2.0",
    lastUpdated: "2024-01-14",
    author: "Engineering Team",
    status: "approved",
    sections: [
      {
        id: "architecture",
        title: "1. System Architecture",
        content: [
          "1.1 Technology Stack:",
          "  - Frontend: React 18.x with TypeScript",
          "  - UI Framework: Tailwind CSS + shadcn/ui",
          "  - State Management: React Query + Context API",
          "  - Routing: React Router v6",
          "  - Build Tool: Vite",
          "",
          "1.2 Backend Integration:",
          "  - Database: PostgreSQL via Supabase",
          "  - Authentication: Supabase Auth",
          "  - API Layer: Supabase Edge Functions",
          "  - File Storage: Supabase Storage",
          "",
          "1.3 Architecture Patterns:",
          "  - Component-based UI architecture",
          "  - Feature-based folder structure",
          "  - Custom hooks for business logic",
          "  - Centralized state management for global state",
        ],
      },
      {
        id: "data-model",
        title: "2. Data Model",
        content: [
          "2.1 Core Entities:",
          "  - organizations (id, name, type, settings, created_at)",
          "  - facilities (id, org_id, name, type, address, status)",
          "  - departments (id, facility_id, name, head_user_id, parent_id)",
          "  - users (id, email, name, status, department_id)",
          "  - roles (id, name, type, is_system, org_id)",
          "  - user_roles (user_id, role_id)",
          "  - entitlements (id, role_id, object_area, scope, capabilities[])",
          "",
          "2.2 Configuration Entities:",
          "  - dashboard_configs (id, type, owner_id, layout, widgets[])",
          "  - retention_policies (id, org_id, category, period, is_required)",
          "  - lov_definitions (id, org_id, category, values[], is_system)",
          "  - app_configs (id, org_id, app_code, settings, enabled)",
          "",
          "2.3 Audit Entities:",
          "  - audit_logs (id, user_id, action, category, details, ip, timestamp)",
          "  - change_history (id, entity_type, entity_id, changes, user_id, timestamp)",
        ],
      },
      {
        id: "components",
        title: "3. Component Architecture",
        content: [
          "3.1 Layout Components:",
          "  - AdminLayout: Main layout wrapper with sidebar",
          "  - AdminSidebar: Navigation sidebar with sections",
          "  - TabNavigation: Reusable tab component",
          "",
          "3.2 Feature Components:",
          "  - StatusCard: Configuration status display",
          "  - DataTable: Sortable, filterable tables",
          "  - FormDialog: CRUD operation dialogs",
          "  - ConfirmDialog: Delete/action confirmations",
          "",
          "3.3 UI Components (shadcn/ui):",
          "  - Button, Input, Select, Switch, Checkbox",
          "  - Dialog, AlertDialog, Sheet",
          "  - Badge, Card, Tabs",
          "  - Toast notifications (sonner)",
        ],
      },
      {
        id: "api-design",
        title: "4. API Design",
        content: [
          "4.1 RESTful Endpoints:",
          "  - GET /api/organizations/:id",
          "  - GET/POST /api/facilities",
          "  - GET/POST/PUT/DELETE /api/departments",
          "  - GET/POST/PUT/DELETE /api/users",
          "  - GET/POST/PUT/DELETE /api/roles",
          "  - GET/POST/PUT/DELETE /api/entitlements",
          "",
          "4.2 Query Parameters:",
          "  - Pagination: page, limit",
          "  - Filtering: filter[field]=value",
          "  - Sorting: sort=field:asc|desc",
          "  - Search: q=searchterm",
          "",
          "4.3 Response Format:",
          "  - Success: { data: T, meta: { total, page, limit } }",
          "  - Error: { error: { code, message, details } }",
        ],
      },
      {
        id: "security",
        title: "5. Security Implementation",
        content: [
          "5.1 Authentication:",
          "  - JWT-based authentication via Supabase",
          "  - Session management with refresh tokens",
          "  - MFA support (TOTP)",
          "",
          "5.2 Authorization:",
          "  - Row Level Security (RLS) on all tables",
          "  - Role-based access control (RBAC)",
          "  - has_role() security definer function",
          "  - Client-side route protection",
          "",
          "5.3 Data Protection:",
          "  - HTTPS/TLS encryption in transit",
          "  - Encrypted storage at rest",
          "  - PII field-level encryption",
          "  - Audit logging for sensitive operations",
        ],
      },
      {
        id: "performance",
        title: "6. Performance Considerations",
        content: [
          "6.1 Frontend Optimization:",
          "  - Code splitting with React.lazy()",
          "  - Memoization for expensive computations",
          "  - Virtual scrolling for large lists",
          "  - Optimistic UI updates",
          "",
          "6.2 Data Fetching:",
          "  - React Query for caching and invalidation",
          "  - Stale-while-revalidate pattern",
          "  - Prefetching for navigation",
          "  - Pagination for large datasets",
          "",
          "6.3 Database Optimization:",
          "  - Indexed columns for frequent queries",
          "  - Materialized views for dashboards",
          "  - Connection pooling",
          "  - Query optimization",
        ],
      },
    ],
  },
  {
    id: "qa",
    title: "QA Test Cases",
    shortTitle: "QA Tests",
    description: "Quality assurance test cases for all features",
    icon: TestTube,
    version: "1.8",
    lastUpdated: "2024-01-13",
    author: "QA Team",
    status: "approved",
    sections: [
      {
        id: "auth-tests",
        title: "1. Authentication Tests",
        content: [
          "TC-AUTH-001: Verify successful login with valid credentials",
          "  - Precondition: User account exists and is active",
          "  - Steps: Enter email, enter password, click Login",
          "  - Expected: User redirected to Admin Home",
          "",
          "TC-AUTH-002: Verify login failure with invalid password",
          "  - Precondition: User account exists",
          "  - Steps: Enter email, enter wrong password, click Login",
          "  - Expected: Error message displayed, login attempt logged",
          "",
          "TC-AUTH-003: Verify account lockout after 5 failed attempts",
          "  - Precondition: User account exists and is active",
          "  - Steps: Enter wrong password 5 times",
          "  - Expected: Account locked, lockout message displayed",
          "",
          "TC-AUTH-004: Verify session timeout after inactivity",
          "  - Precondition: User is logged in",
          "  - Steps: Wait for session timeout period",
          "  - Expected: User redirected to login page",
          "",
          "TC-AUTH-005: Verify logout functionality",
          "  - Precondition: User is logged in",
          "  - Steps: Click logout button",
          "  - Expected: Session cleared, redirected to login",
        ],
      },
      {
        id: "user-mgmt-tests",
        title: "2. User Management Tests",
        content: [
          "TC-USER-001: Verify user creation with all required fields",
          "  - Steps: Navigate to Users, click Add User, fill form, submit",
          "  - Expected: User created, success toast displayed",
          "",
          "TC-USER-002: Verify user creation fails without required fields",
          "  - Steps: Navigate to Users, click Add User, submit empty form",
          "  - Expected: Validation errors displayed for required fields",
          "",
          "TC-USER-003: Verify user role assignment",
          "  - Steps: Edit user, select role, save",
          "  - Expected: Role assigned, user permissions updated",
          "",
          "TC-USER-004: Verify user deactivation",
          "  - Steps: Select user, click Deactivate, confirm",
          "  - Expected: User status changed to Inactive",
          "",
          "TC-USER-005: Verify bulk user import via CSV",
          "  - Steps: Click Import, upload valid CSV, submit",
          "  - Expected: Users created, import summary displayed",
          "",
          "TC-USER-006: Verify user search functionality",
          "  - Steps: Enter search term in search box",
          "  - Expected: User list filtered by name/email",
          "",
          "TC-USER-007: Verify user filter by status",
          "  - Steps: Select status filter (Active/Inactive)",
          "  - Expected: User list filtered by selected status",
        ],
      },
      {
        id: "role-tests",
        title: "3. Role Management Tests",
        content: [
          "TC-ROLE-001: Verify custom role creation",
          "  - Steps: Navigate to Roles, click Create Role, fill form, submit",
          "  - Expected: Role created, appears in role list",
          "",
          "TC-ROLE-002: Verify system role cannot be deleted",
          "  - Steps: Navigate to Roles, try to delete system role",
          "  - Expected: Delete button disabled or error message",
          "",
          "TC-ROLE-003: Verify role entitlement configuration",
          "  - Steps: Edit role, modify entitlements, save",
          "  - Expected: Entitlements updated, affecting assigned users",
          "",
          "TC-ROLE-004: Verify role-to-app access mapping",
          "  - Steps: Edit role, assign/remove app access, save",
          "  - Expected: App access updated for role",
          "",
          "TC-ROLE-005: Verify role assignment to user",
          "  - Steps: Edit user, assign role, save",
          "  - Expected: User inherits role permissions",
        ],
      },
      {
        id: "dashboard-tests",
        title: "4. Dashboard Configuration Tests",
        content: [
          "TC-DASH-001: Verify Master Dashboard widget configuration",
          "  - Steps: Navigate to Dashboards, edit Master, add/remove widgets",
          "  - Expected: Widget layout saved and reflected",
          "",
          "TC-DASH-002: Verify Department Dashboard creation",
          "  - Steps: Navigate to Department tab, click Create, configure",
          "  - Expected: Dashboard created for department",
          "",
          "TC-DASH-003: Verify draft save functionality",
          "  - Steps: Make changes, click Save Draft",
          "  - Expected: Draft saved, publish button enabled",
          "",
          "TC-DASH-004: Verify publish functionality",
          "  - Steps: Make changes, click Publish",
          "  - Expected: Changes published, version incremented",
          "",
          "TC-DASH-005: Verify dashboard preview",
          "  - Steps: Click Preview button",
          "  - Expected: Dashboard rendered in preview mode",
        ],
      },
      {
        id: "data-retention-tests",
        title: "5. Data Retention Tests",
        content: [
          "TC-RET-001: Verify retention policy list display",
          "  - Steps: Navigate to Data & Retention",
          "  - Expected: All policies displayed with correct details",
          "",
          "TC-RET-002: Verify retention period edit",
          "  - Steps: Click Edit on policy, change period, save",
          "  - Expected: Period updated, toast confirmation",
          "",
          "TC-RET-003: Verify required policy cannot be deleted",
          "  - Steps: Try to delete required policy",
          "  - Expected: Delete button disabled",
          "",
          "TC-RET-004: Verify retention policy description edit",
          "  - Steps: Edit policy, change description, save",
          "  - Expected: Description updated",
        ],
      },
      {
        id: "audit-tests",
        title: "6. Audit & History Tests",
        content: [
          "TC-AUD-001: Verify audit log display",
          "  - Steps: Navigate to Change History",
          "  - Expected: Audit logs displayed with correct details",
          "",
          "TC-AUD-002: Verify audit log search",
          "  - Steps: Enter search term",
          "  - Expected: Logs filtered by search term",
          "",
          "TC-AUD-003: Verify audit log category filter",
          "  - Steps: Select category filter",
          "  - Expected: Logs filtered by category",
          "",
          "TC-AUD-004: Verify audit log severity filter",
          "  - Steps: Select severity filter",
          "  - Expected: Logs filtered by severity",
          "",
          "TC-AUD-005: Verify audit log export",
          "  - Steps: Click Export, select format",
          "  - Expected: Download initiated for selected format",
          "",
          "TC-AUD-006: Verify audit log detail view",
          "  - Steps: Click on audit log entry",
          "  - Expected: Detail panel shows full information",
        ],
      },
    ],
  },
  {
    id: "uat",
    title: "UAT Test Cases",
    shortTitle: "UAT Tests",
    description: "User acceptance testing scenarios for business validation",
    icon: Users,
    version: "1.5",
    lastUpdated: "2024-01-12",
    author: "Business Analysts",
    status: "review",
    sections: [
      {
        id: "org-setup",
        title: "1. Organization Setup Scenarios",
        content: [
          "UAT-ORG-001: Complete Organization Profile Setup",
          "  - Persona: Org Admin (First-time setup)",
          "  - Scenario: Admin configures organization profile from scratch",
          "  - Acceptance Criteria:",
          "    ✓ Organization name and details saved correctly",
          "    ✓ Logo uploaded and displayed in header",
          "    ✓ Timezone reflects in all timestamps",
          "    ✓ Regulatory frameworks selected are applied to compliance modules",
          "",
          "UAT-ORG-002: Multi-Facility Organization Setup",
          "  - Persona: Org Admin (Healthcare system)",
          "  - Scenario: Admin adds multiple facilities with different types",
          "  - Acceptance Criteria:",
          "    ✓ Multiple facilities can be added",
          "    ✓ Each facility has unique configuration",
          "    ✓ Facility-specific reports generate correctly",
          "",
          "UAT-ORG-003: Department Hierarchy Configuration",
          "  - Persona: Org Admin",
          "  - Scenario: Admin creates nested department structure",
          "  - Acceptance Criteria:",
          "    ✓ Parent-child relationships work correctly",
          "    ✓ Department heads can be assigned",
          "    ✓ Users can be moved between departments",
        ],
      },
      {
        id: "user-onboarding",
        title: "2. User Onboarding Scenarios",
        content: [
          "UAT-USER-001: Single User Onboarding",
          "  - Persona: Org Admin onboarding new employee",
          "  - Scenario: Admin creates user account and assigns role",
          "  - Acceptance Criteria:",
          "    ✓ User receives welcome email",
          "    ✓ User can login with provided credentials",
          "    ✓ User sees only permitted features",
          "",
          "UAT-USER-002: Bulk User Import",
          "  - Persona: Org Admin (Large organization)",
          "  - Scenario: Admin imports 100+ users via CSV",
          "  - Acceptance Criteria:",
          "    ✓ CSV template downloads correctly",
          "    ✓ Import processes without errors",
          "    ✓ Import summary shows success/failure count",
          "    ✓ Failed rows can be reviewed and corrected",
          "",
          "UAT-USER-003: User Role Change",
          "  - Persona: Org Admin promoting employee",
          "  - Scenario: Admin changes user from Staff to Department Head",
          "  - Acceptance Criteria:",
          "    ✓ New permissions take effect immediately",
          "    ✓ User sees new features on next login",
          "    ✓ Change is logged in audit trail",
        ],
      },
      {
        id: "dashboard-config",
        title: "3. Dashboard Configuration Scenarios",
        content: [
          "UAT-DASH-001: Master Dashboard Setup",
          "  - Persona: Compliance Head",
          "  - Scenario: Configure organization-wide compliance dashboard",
          "  - Acceptance Criteria:",
          "    ✓ All KPI widgets available for selection",
          "    ✓ Layout saves correctly after customization",
          "    ✓ Published dashboard visible to all permitted users",
          "",
          "UAT-DASH-002: Department Dashboard Template",
          "  - Persona: Org Admin",
          "  - Scenario: Create template for department dashboards",
          "  - Acceptance Criteria:",
          "    ✓ Template can be applied to multiple departments",
          "    ✓ Department-specific data populates correctly",
          "    ✓ Department heads can customize within limits",
          "",
          "UAT-DASH-003: Personal Dashboard Customization",
          "  - Persona: Staff Member",
          "  - Scenario: User customizes their personal dashboard",
          "  - Acceptance Criteria:",
          "    ✓ User can rearrange widgets",
          "    ✓ User can add/remove permitted widgets",
          "    ✓ Customizations persist across sessions",
        ],
      },
      {
        id: "compliance-workflows",
        title: "4. Compliance Workflow Scenarios",
        content: [
          "UAT-COMP-001: Issue Tracking End-to-End",
          "  - Persona: Staff → Department Head → Compliance Head",
          "  - Scenario: Issue reported, escalated, resolved",
          "  - Acceptance Criteria:",
          "    ✓ Staff can create issue",
          "    ✓ Department Head notified and can assign",
          "    ✓ Compliance Head can review and close",
          "    ✓ All actions logged in audit trail",
          "",
          "UAT-COMP-002: CAPA Workflow",
          "  - Persona: Multiple roles in approval chain",
          "  - Scenario: CAPA created, actions assigned, verified, closed",
          "  - Acceptance Criteria:",
          "    ✓ Workflow stages progress correctly",
          "    ✓ Notifications sent at each stage",
          "    ✓ Escalation triggers on SLA breach",
          "",
          "UAT-COMP-003: Audit Preparation",
          "  - Persona: Compliance Head preparing for survey",
          "  - Scenario: Generate compliance reports for auditors",
          "  - Acceptance Criteria:",
          "    ✓ Reports include all required data",
          "    ✓ Export formats work correctly",
          "    ✓ Historical data accessible",
        ],
      },
      {
        id: "security-scenarios",
        title: "5. Security & Access Scenarios",
        content: [
          "UAT-SEC-001: Role-Based Access Verification",
          "  - Persona: Users with different roles",
          "  - Scenario: Verify each role sees only permitted features",
          "  - Acceptance Criteria:",
          "    ✓ Staff cannot access admin functions",
          "    ✓ Department Head limited to their department",
          "    ✓ Org Admin has full access",
          "",
          "UAT-SEC-002: Data Scope Enforcement",
          "  - Persona: Department Head",
          "  - Scenario: Verify data visibility is limited to department",
          "  - Acceptance Criteria:",
          "    ✓ Only department data visible in lists",
          "    ✓ Cannot access other department records",
          "    ✓ Reports limited to department scope",
          "",
          "UAT-SEC-003: Audit Trail Integrity",
          "  - Persona: Org Admin reviewing changes",
          "  - Scenario: Verify all actions are logged",
          "  - Acceptance Criteria:",
          "    ✓ User actions recorded with timestamp",
          "    ✓ Before/after values captured",
          "    ✓ Export includes complete audit trail",
        ],
      },
      {
        id: "reporting",
        title: "6. Reporting & Export Scenarios",
        content: [
          "UAT-REP-001: Compliance Dashboard Export",
          "  - Persona: Compliance Head",
          "  - Scenario: Export dashboard data for leadership presentation",
          "  - Acceptance Criteria:",
          "    ✓ PDF export renders correctly",
          "    ✓ All charts and metrics included",
          "    ✓ Branding applied to export",
          "",
          "UAT-REP-002: Audit Log Export",
          "  - Persona: Org Admin during audit",
          "  - Scenario: Export audit logs for external auditors",
          "  - Acceptance Criteria:",
          "    ✓ CSV/JSON formats work correctly",
          "    ✓ Filters applied to export",
          "    ✓ All required fields included",
          "",
          "UAT-REP-003: User Activity Report",
          "  - Persona: Org Admin",
          "  - Scenario: Generate user activity report for compliance",
          "  - Acceptance Criteria:",
          "    ✓ Login history accurate",
          "    ✓ Action counts correct",
          "    ✓ Inactive users identified",
        ],
      },
    ],
  },
  {
    id: "system-prompt",
    title: "Systems Prompt Document",
    shortTitle: "Systems Prompt",
    description: "AI assistant system prompt and behavioral guidelines for MedComply",
    icon: Bot,
    version: "1.0",
    lastUpdated: "2024-01-16",
    author: "AI Engineering Team",
    status: "approved",
    sections: [
      {
        id: "core-identity",
        title: "1. Core Identity & Purpose",
        content: [
          "1.1 System Identity:",
          "  - Name: MedComply AI Assistant",
          "  - Role: Healthcare compliance guidance and administrative support",
          "  - Domain: Healthcare regulatory compliance, HIPAA, CMS, Joint Commission",
          "",
          "1.2 Primary Objectives:",
          "  - Provide accurate compliance guidance based on current regulations",
          "  - Assist administrators with configuration and setup tasks",
          "  - Answer questions about system functionality and best practices",
          "  - Support users in navigating complex compliance requirements",
          "",
          "1.3 Core Values:",
          "  - Accuracy: Never provide inaccurate or outdated compliance information",
          "  - Clarity: Communicate complex regulations in understandable terms",
          "  - Helpfulness: Proactively suggest relevant information and actions",
          "  - Compliance: Always prioritize regulatory compliance over convenience",
        ],
      },
      {
        id: "behavioral-guidelines",
        title: "2. Behavioral Guidelines",
        content: [
          "2.1 Response Style:",
          "  - Use clear, professional language appropriate for healthcare settings",
          "  - Provide structured responses with bullet points for complex topics",
          "  - Include regulatory references when citing compliance requirements",
          "  - Offer actionable next steps when appropriate",
          "",
          "2.2 Interaction Patterns:",
          "  - Greet users professionally without excessive formality",
          "  - Ask clarifying questions when requests are ambiguous",
          "  - Summarize complex responses with key takeaways",
          "  - Acknowledge limitations and suggest escalation when appropriate",
          "",
          "2.3 Error Handling:",
          "  - Clearly state when information is outside knowledge domain",
          "  - Never fabricate compliance regulations or deadlines",
          "  - Recommend consulting official sources for critical decisions",
          "  - Log uncertain responses for human review",
        ],
      },
      {
        id: "domain-knowledge",
        title: "3. Domain Knowledge Areas",
        content: [
          "3.1 Regulatory Frameworks:",
          "  - HIPAA Privacy and Security Rules",
          "  - CMS Conditions of Participation",
          "  - Joint Commission Standards",
          "  - State-specific healthcare regulations",
          "  - OSHA workplace safety requirements",
          "",
          "3.2 Compliance Areas:",
          "  - Patient privacy and data protection",
          "  - Clinical documentation requirements",
          "  - Staff credentialing and training",
          "  - Incident reporting and investigation",
          "  - Audit preparation and response",
          "",
          "3.3 System Functionality:",
          "  - Organization and facility configuration",
          "  - User and role management",
          "  - Workflow and notification setup",
          "  - Dashboard and reporting configuration",
          "  - Integration with external systems",
        ],
      },
      {
        id: "context-handling",
        title: "4. Context Handling",
        content: [
          "4.1 User Context:",
          "  - Identify user role from session (Org Admin, Compliance Head, etc.)",
          "  - Tailor responses to user's permission level",
          "  - Reference user's organization and facility when relevant",
          "  - Maintain conversation history for coherent multi-turn dialogues",
          "",
          "4.2 Organizational Context:",
          "  - Apply organization-specific configurations and policies",
          "  - Reference facility-specific compliance requirements",
          "  - Consider department-level permissions and scopes",
          "  - Align with configured regulatory frameworks",
          "",
          "4.3 Temporal Context:",
          "  - Consider upcoming compliance deadlines",
          "  - Reference recent regulatory changes",
          "  - Account for audit schedules and preparation needs",
          "  - Track seasonal compliance activities",
        ],
      },
      {
        id: "safety-boundaries",
        title: "5. Safety & Boundaries",
        content: [
          "5.1 Prohibited Actions:",
          "  - Never provide specific medical advice or diagnoses",
          "  - Never disclose PHI or sensitive patient information",
          "  - Never bypass security controls or access restrictions",
          "  - Never provide legal advice (recommend legal counsel instead)",
          "",
          "5.2 Escalation Triggers:",
          "  - Requests involving potential patient safety issues",
          "  - Questions about active legal proceedings",
          "  - Suspected data breaches or security incidents",
          "  - Requests for information beyond knowledge cutoff",
          "",
          "5.3 Data Handling:",
          "  - Do not store conversation data beyond session",
          "  - Anonymize any referenced patient scenarios",
          "  - Flag conversations containing potential PHI",
          "  - Comply with data retention policies",
        ],
      },
      {
        id: "integration-protocols",
        title: "6. Integration Protocols",
        content: [
          "6.1 System Integration:",
          "  - Query organization database for current configurations",
          "  - Access user permissions for response filtering",
          "  - Retrieve relevant compliance documents and policies",
          "  - Log interactions for audit trail",
          "",
          "6.2 External References:",
          "  - Link to official regulatory sources when appropriate",
          "  - Reference internal knowledge base articles",
          "  - Provide document download links for forms/templates",
          "  - Connect to training module recommendations",
          "",
          "6.3 Action Capabilities:",
          "  - Initiate workflow triggers (with confirmation)",
          "  - Generate compliance reports (read-only)",
          "  - Schedule reminders and notifications",
          "  - Create draft configurations for review",
        ],
      },
      {
        id: "response-templates",
        title: "7. Response Templates",
        content: [
          "7.1 Compliance Query Response:",
          "  [Requirement Summary]",
          "  - Regulation: [Name and citation]",
          "  - Requirement: [Brief description]",
          "  - Applicability: [Who/what this applies to]",
          "  - Key Actions: [Numbered list]",
          "  - Reference: [Link to official source]",
          "",
          "7.2 Configuration Guidance Response:",
          "  [Feature Overview]",
          "  - Purpose: [What this configuration does]",
          "  - Location: [Where to find in Admin Center]",
          "  - Steps: [Numbered configuration steps]",
          "  - Best Practices: [Recommendations]",
          "  - Related: [Links to related configurations]",
          "",
          "7.3 Error/Issue Response:",
          "  [Issue Acknowledgment]",
          "  - Status: [What we understand about the issue]",
          "  - Cause: [Possible explanation if known]",
          "  - Resolution: [Steps to resolve or workaround]",
          "  - Escalation: [When/how to escalate if unresolved]",
        ],
      },
      {
        id: "training-guidelines",
        title: "8. Continuous Improvement",
        content: [
          "8.1 Feedback Integration:",
          "  - Collect user ratings on response helpfulness",
          "  - Track common question patterns for knowledge gaps",
          "  - Identify frequently needed clarifications",
          "  - Monitor escalation patterns for training needs",
          "",
          "8.2 Knowledge Updates:",
          "  - Integrate new regulatory guidance within 48 hours",
          "  - Update system functionality documentation with releases",
          "  - Refresh compliance deadline calendars monthly",
          "  - Review and update response templates quarterly",
          "",
          "8.3 Performance Metrics:",
          "  - Response accuracy rate target: >98%",
          "  - User satisfaction score target: >4.5/5",
          "  - Escalation rate target: <5%",
          "  - Average response time target: <3 seconds",
        ],
      },
    ],
  },
];

export default function DevelopmentDocs() {
  const { toast } = useToast();
  const [expandedDoc, setExpandedDoc] = useState<string | null>(null);
  const [previewDoc, setPreviewDoc] = useState<DevDocument | null>(null);

  const statusColors: Record<string, string> = {
    approved: "bg-success/10 text-success",
    draft: "bg-warning/10 text-warning",
    review: "bg-info/10 text-info",
  };

  const handleDownload = (doc: DevDocument) => {
    const pdf = new jsPDF();
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 20;
    const maxWidth = pageWidth - margin * 2;
    let yPosition = margin;

    const addNewPageIfNeeded = (requiredSpace: number) => {
      if (yPosition + requiredSpace > pageHeight - margin) {
        pdf.addPage();
        yPosition = margin;
        return true;
      }
      return false;
    };

    // Title
    pdf.setFontSize(20);
    pdf.setFont("helvetica", "bold");
    const titleLines = pdf.splitTextToSize(doc.title, maxWidth);
    pdf.text(titleLines, margin, yPosition);
    yPosition += titleLines.length * 8 + 5;

    // Metadata
    pdf.setFontSize(10);
    pdf.setFont("helvetica", "normal");
    pdf.setTextColor(100, 100, 100);
    pdf.text(`Version: ${doc.version}  |  Last Updated: ${doc.lastUpdated}  |  Author: ${doc.author}  |  Status: ${doc.status.toUpperCase()}`, margin, yPosition);
    yPosition += 10;

    // Divider line
    pdf.setDrawColor(200, 200, 200);
    pdf.line(margin, yPosition, pageWidth - margin, yPosition);
    yPosition += 10;

    // Sections
    pdf.setTextColor(0, 0, 0);
    doc.sections.forEach((section) => {
      addNewPageIfNeeded(25);

      // Section title
      pdf.setFontSize(14);
      pdf.setFont("helvetica", "bold");
      const sectionTitleLines = pdf.splitTextToSize(section.title, maxWidth);
      pdf.text(sectionTitleLines, margin, yPosition);
      yPosition += sectionTitleLines.length * 6 + 5;

      // Section content
      pdf.setFontSize(10);
      pdf.setFont("helvetica", "normal");
      section.content.forEach((line) => {
        if (line === "") {
          yPosition += 3;
          return;
        }

        addNewPageIfNeeded(8);

        const indent = line.startsWith("  ") ? 10 : 0;
        const textLine = line.trimStart();
        const lineWidth = maxWidth - indent;
        const wrappedLines = pdf.splitTextToSize(textLine, lineWidth);

        wrappedLines.forEach((wrappedLine: string) => {
          addNewPageIfNeeded(6);
          pdf.text(wrappedLine, margin + indent, yPosition);
          yPosition += 5;
        });
      });

      yPosition += 8;
    });

    // Footer on each page
    const totalPages = pdf.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      pdf.setPage(i);
      pdf.setFontSize(8);
      pdf.setTextColor(150, 150, 150);
      pdf.text(`MedComply Admin Center - ${doc.shortTitle} v${doc.version}`, margin, pageHeight - 10);
      pdf.text(`Page ${i} of ${totalPages}`, pageWidth - margin - 20, pageHeight - 10);
    }

    pdf.save(`${doc.shortTitle.replace(/\s+/g, "_")}_v${doc.version}.pdf`);

    toast({
      title: "PDF Downloaded",
      description: `${doc.shortTitle} document has been downloaded as PDF`,
    });
  };

  const toggleDoc = (docId: string) => {
    setExpandedDoc(expandedDoc === docId ? null : docId);
  };

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="p-6 max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <FileText className="w-7 h-7 text-accent" />
            Development Documents
          </h1>
          <p className="text-muted-foreground mt-1">
            PRD, TDD, QA Test Cases, and UAT Test Cases for the development team
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 max-w-7xl mx-auto">
        {/* Document Cards */}
        <div className="space-y-4">
          {documents.map((doc) => (
            <div key={doc.id} className="card-section overflow-hidden">
              {/* Document Header */}
              <div
                className="p-4 flex items-center gap-4 cursor-pointer hover:bg-muted/50 transition-colors"
                onClick={() => toggleDoc(doc.id)}
              >
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
                  <doc.icon className="w-6 h-6 text-accent" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-foreground">{doc.title}</h3>
                    <Badge className={cn("text-xs", statusColors[doc.status])}>
                      {doc.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{doc.description}</p>
                  <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {doc.lastUpdated}
                    </span>
                    <span className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {doc.author}
                    </span>
                    <span>v{doc.version}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      setPreviewDoc(doc);
                    }}
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Preview
                  </Button>
                  <Button
                    size="sm"
                    className="bg-accent text-accent-foreground hover:bg-accent/90"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDownload(doc);
                    }}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                  {expandedDoc === doc.id ? (
                    <ChevronDown className="w-5 h-5 text-muted-foreground" />
                  ) : (
                    <ChevronRight className="w-5 h-5 text-muted-foreground" />
                  )}
                </div>
              </div>

              {/* Expanded Sections */}
              {expandedDoc === doc.id && (
                <div className="border-t border-border bg-muted/30 p-4 animate-fade-in">
                  <p className="text-sm font-medium text-foreground mb-3">
                    Document Sections ({doc.sections.length})
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                    {doc.sections.map((section) => (
                      <div
                        key={section.id}
                        className="p-3 bg-card rounded-lg border border-border flex items-center gap-2"
                      >
                        <CheckCircle2 className="w-4 h-4 text-success flex-shrink-0" />
                        <span className="text-sm text-foreground truncate">
                          {section.title}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Summary Stats */}
        <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="card-section p-4 text-center">
            <p className="text-3xl font-bold text-foreground">{documents.length}</p>
            <p className="text-sm text-muted-foreground">Total Documents</p>
          </div>
          <div className="card-section p-4 text-center">
            <p className="text-3xl font-bold text-success">
              {documents.filter((d) => d.status === "approved").length}
            </p>
            <p className="text-sm text-muted-foreground">Approved</p>
          </div>
          <div className="card-section p-4 text-center">
            <p className="text-3xl font-bold text-info">
              {documents.filter((d) => d.status === "review").length}
            </p>
            <p className="text-sm text-muted-foreground">In Review</p>
          </div>
          <div className="card-section p-4 text-center">
            <p className="text-3xl font-bold text-foreground">
              {documents.reduce((acc, d) => acc + d.sections.length, 0)}
            </p>
            <p className="text-sm text-muted-foreground">Total Sections</p>
          </div>
        </div>
      </div>

      {/* Preview Dialog */}
      <Dialog open={!!previewDoc} onOpenChange={() => setPreviewDoc(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {previewDoc?.icon && <previewDoc.icon className="w-5 h-5 text-accent" />}
              {previewDoc?.title}
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[70vh] pr-4">
            <div className="space-y-6">
              {/* Document Meta */}
              <div className="flex items-center gap-4 text-sm text-muted-foreground pb-4 border-b border-border">
                <span>Version {previewDoc?.version}</span>
                <span>•</span>
                <span>{previewDoc?.lastUpdated}</span>
                <span>•</span>
                <span>{previewDoc?.author}</span>
                <Badge className={cn("text-xs ml-auto", previewDoc?.status && statusColors[previewDoc.status])}>
                  {previewDoc?.status}
                </Badge>
              </div>

              {/* Sections */}
              {previewDoc?.sections.map((section) => (
                <div key={section.id} className="space-y-2">
                  <h3 className="font-semibold text-foreground text-lg">
                    {section.title}
                  </h3>
                  <div className="bg-muted/50 rounded-lg p-4">
                    {section.content.map((line, idx) => (
                      <p
                        key={idx}
                        className={cn(
                          "text-sm",
                          line.startsWith("  ") ? "text-muted-foreground ml-4" : "text-foreground",
                          line === "" ? "h-2" : ""
                        )}
                      >
                        {line || "\u00A0"}
                      </p>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
          <div className="flex justify-end gap-2 pt-4 border-t border-border">
            <Button variant="outline" onClick={() => setPreviewDoc(null)}>
              Close
            </Button>
            <Button
              className="bg-accent text-accent-foreground hover:bg-accent/90"
              onClick={() => previewDoc && handleDownload(previewDoc)}
            >
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
