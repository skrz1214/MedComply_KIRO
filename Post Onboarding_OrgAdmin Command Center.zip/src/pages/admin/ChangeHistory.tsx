import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  History,
  Search,
  Filter,
  ChevronRight,
  User,
  Calendar,
  Shield,
  Settings,
  ArrowRight,
  Download,
  Users,
  Key,
  LogIn,
  LogOut,
  UserPlus,
  Trash2,
  Eye,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

interface AuditLogEntry {
  id: string;
  action: string;
  category: "authentication" | "user_management" | "security" | "configuration";
  user: string;
  userEmail: string;
  ipAddress: string;
  timestamp: string;
  details: string;
  severity: "info" | "warning" | "critical";
}

export default function ChangeHistory() {
  const { toast } = useToast();
  const [selectedEntry, setSelectedEntry] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [severityFilter, setSeverityFilter] = useState<string>("all");
  const [isExportOpen, setIsExportOpen] = useState(false);

  const auditLogs: AuditLogEntry[] = [
    {
      id: "1",
      action: "User Login",
      category: "authentication",
      user: "Sarah Chen",
      userEmail: "sarah.chen@org.com",
      ipAddress: "192.168.1.45",
      timestamp: "2024-01-15 14:32:00",
      details: "Successful login via SSO",
      severity: "info",
    },
    {
      id: "2",
      action: "Failed Login Attempt",
      category: "authentication",
      user: "Unknown",
      userEmail: "admin@org.com",
      ipAddress: "203.45.67.89",
      timestamp: "2024-01-15 14:28:00",
      details: "Invalid password - 3rd attempt",
      severity: "warning",
    },
    {
      id: "3",
      action: "Role Assignment Changed",
      category: "user_management",
      user: "Sarah Chen",
      userEmail: "sarah.chen@org.com",
      ipAddress: "192.168.1.45",
      timestamp: "2024-01-15 13:15:00",
      details: "Assigned 'Department Head' role to Mike Johnson",
      severity: "info",
    },
    {
      id: "4",
      action: "User Deactivated",
      category: "user_management",
      user: "Sarah Chen",
      userEmail: "sarah.chen@org.com",
      ipAddress: "192.168.1.45",
      timestamp: "2024-01-15 11:45:00",
      details: "Deactivated user account: john.doe@org.com",
      severity: "warning",
    },
    {
      id: "5",
      action: "Security Policy Updated",
      category: "security",
      user: "Sarah Chen",
      userEmail: "sarah.chen@org.com",
      ipAddress: "192.168.1.45",
      timestamp: "2024-01-14 16:30:00",
      details: "Password policy updated: minimum 12 characters required",
      severity: "info",
    },
    {
      id: "6",
      action: "Bulk User Import",
      category: "user_management",
      user: "Sarah Chen",
      userEmail: "sarah.chen@org.com",
      ipAddress: "192.168.1.45",
      timestamp: "2024-01-14 10:00:00",
      details: "Imported 25 users from CSV",
      severity: "info",
    },
    {
      id: "7",
      action: "MFA Disabled",
      category: "security",
      user: "Mike Johnson",
      userEmail: "mike.johnson@org.com",
      ipAddress: "192.168.1.102",
      timestamp: "2024-01-13 15:20:00",
      details: "Multi-factor authentication disabled for user account",
      severity: "critical",
    },
    {
      id: "8",
      action: "Session Timeout Updated",
      category: "configuration",
      user: "Sarah Chen",
      userEmail: "sarah.chen@org.com",
      ipAddress: "192.168.1.45",
      timestamp: "2024-01-13 09:00:00",
      details: "Session timeout changed from 30 min to 60 min",
      severity: "info",
    },
  ];

  const categoryIcons: Record<string, React.ComponentType<{ className?: string }>> = {
    authentication: LogIn,
    user_management: Users,
    security: Shield,
    configuration: Settings,
  };

  const categoryLabels: Record<string, string> = {
    authentication: "Authentication",
    user_management: "User Management",
    security: "Security",
    configuration: "Configuration",
  };

  const severityColors: Record<string, string> = {
    info: "text-info bg-info/10",
    warning: "text-warning bg-warning/10",
    critical: "text-destructive bg-destructive/10",
  };

  const actionIcons: Record<string, React.ComponentType<{ className?: string }>> = {
    "User Login": LogIn,
    "Failed Login Attempt": LogOut,
    "Role Assignment Changed": Key,
    "User Deactivated": Trash2,
    "Security Policy Updated": Shield,
    "Bulk User Import": UserPlus,
    "MFA Disabled": Shield,
    "Session Timeout Updated": Settings,
  };

  const filteredLogs = auditLogs.filter((log) => {
    const matchesSearch =
      log.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.details.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === "all" || log.category === categoryFilter;
    const matchesSeverity = severityFilter === "all" || log.severity === severityFilter;
    return matchesSearch && matchesCategory && matchesSeverity;
  });

  const handleExport = (format: "csv" | "json") => {
    toast({
      title: "Export Started",
      description: `Exporting ${filteredLogs.length} log entries as ${format.toUpperCase()}`,
    });
    setIsExportOpen(false);
  };

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="p-6 max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <History className="w-7 h-7 text-accent" />
            Change History
          </h1>
          <p className="text-muted-foreground mt-1">
            Organization-level audit log of all administrative actions
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 max-w-7xl mx-auto">
        {/* Filters */}
        <div className="flex flex-wrap items-center gap-4 mb-6">
          <div className="relative flex-1 min-w-[200px] max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search logs..."
              className="pl-10 bg-card"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[180px] bg-card">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="authentication">Authentication</SelectItem>
              <SelectItem value="user_management">User Management</SelectItem>
              <SelectItem value="security">Security</SelectItem>
              <SelectItem value="configuration">Configuration</SelectItem>
            </SelectContent>
          </Select>
          <Select value={severityFilter} onValueChange={setSeverityFilter}>
            <SelectTrigger className="w-[150px] bg-card">
              <SelectValue placeholder="Severity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Severity</SelectItem>
              <SelectItem value="info">Info</SelectItem>
              <SelectItem value="warning">Warning</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={() => setIsExportOpen(true)}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="card-section p-4">
            <p className="text-2xl font-bold text-foreground">{auditLogs.length}</p>
            <p className="text-sm text-muted-foreground">Total Entries</p>
          </div>
          <div className="card-section p-4">
            <p className="text-2xl font-bold text-info">{auditLogs.filter(l => l.severity === "info").length}</p>
            <p className="text-sm text-muted-foreground">Info</p>
          </div>
          <div className="card-section p-4">
            <p className="text-2xl font-bold text-warning">{auditLogs.filter(l => l.severity === "warning").length}</p>
            <p className="text-sm text-muted-foreground">Warnings</p>
          </div>
          <div className="card-section p-4">
            <p className="text-2xl font-bold text-destructive">{auditLogs.filter(l => l.severity === "critical").length}</p>
            <p className="text-sm text-muted-foreground">Critical</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* History List */}
          <div className="lg:col-span-2 card-section">
            <div className="p-4 border-b border-border flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                Showing {filteredLogs.length} of {auditLogs.length} entries
              </p>
            </div>
            <div className="divide-y divide-border max-h-[600px] overflow-y-auto">
              {filteredLogs.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground">
                  No log entries match your filters.
                </div>
              ) : (
                filteredLogs.map((entry) => {
                  const CategoryIcon = categoryIcons[entry.category] || Settings;
                  const ActionIcon = actionIcons[entry.action] || Eye;
                  return (
                    <button
                      key={entry.id}
                      onClick={() => setSelectedEntry(entry.id)}
                      className={cn(
                        "w-full p-4 flex items-start gap-4 hover:bg-muted/50 transition-colors text-left",
                        selectedEntry === entry.id && "bg-muted/50"
                      )}
                    >
                      <div className={cn(
                        "w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0",
                        severityColors[entry.severity]
                      )}>
                        <ActionIcon className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-medium text-foreground">{entry.action}</p>
                          <Badge className={cn("text-xs", severityColors[entry.severity])}>
                            {entry.severity}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-1">{entry.details}</p>
                        <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                          <User className="w-3 h-3" />
                          <span>{entry.user}</span>
                          <span>•</span>
                          <span>{entry.timestamp}</span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-1" />
                    </button>
                  );
                })
              )}
            </div>
          </div>

          {/* Detail Panel */}
          <div className="card-section">
            {selectedEntry ? (
              <LogDetail entry={auditLogs.find((e) => e.id === selectedEntry)!} categoryLabels={categoryLabels} />
            ) : (
              <div className="p-6 text-center text-muted-foreground">
                <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Select an entry to view details</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Export Dialog */}
      <Dialog open={isExportOpen} onOpenChange={setIsExportOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Export Audit Logs</DialogTitle>
            <DialogDescription>
              Export {filteredLogs.length} log entries based on your current filters
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-3">
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => handleExport("csv")}
            >
              <Download className="w-4 h-4 mr-2" />
              Export as CSV
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => handleExport("json")}
            >
              <Download className="w-4 h-4 mr-2" />
              Export as JSON
            </Button>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsExportOpen(false)}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function LogDetail({ 
  entry, 
  categoryLabels 
}: { 
  entry: AuditLogEntry; 
  categoryLabels: Record<string, string>;
}) {
  const severityColors: Record<string, string> = {
    info: "text-info bg-info/10",
    warning: "text-warning bg-warning/10",
    critical: "text-destructive bg-destructive/10",
  };

  return (
    <div className="p-4">
      <div className="flex items-center gap-2 mb-4">
        <Badge className={cn("text-xs", severityColors[entry.severity])}>
          {entry.severity}
        </Badge>
        <Badge variant="outline" className="text-xs">
          {categoryLabels[entry.category]}
        </Badge>
      </div>

      <h3 className="font-semibold text-foreground mb-2">{entry.action}</h3>
      <p className="text-sm text-muted-foreground mb-4">{entry.details}</p>

      <div className="space-y-3 border-t border-border pt-4">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">User</span>
          <span className="text-foreground font-medium">{entry.user}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Email</span>
          <span className="text-foreground">{entry.userEmail}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">IP Address</span>
          <span className="text-foreground font-mono text-xs">{entry.ipAddress}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Timestamp</span>
          <span className="text-foreground">{entry.timestamp}</span>
        </div>
      </div>
    </div>
  );
}
