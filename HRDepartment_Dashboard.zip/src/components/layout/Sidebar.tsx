import { useState } from "react";
import { NavLink } from "@/components/NavLink";
import {
  LayoutDashboard,
  Users,
  FileText,
  ClipboardCheck,
  Shield,
  AlertTriangle,
  CheckCircle,
  ChevronDown,
  ChevronUp,
  MessageSquare,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface NavItem {
  title: string;
  href: string;
  icon: React.ElementType;
}

const managementHubItems: NavItem[] = [
  { title: "Dashboard", href: "/", icon: LayoutDashboard },
  { title: "Governing Body Org Chart", href: "/org-chart", icon: Users },
  { title: "Audit Items", href: "/audits", icon: ClipboardCheck },
  { title: "Enforcements", href: "/enforcements", icon: Shield },
  { title: "Risk Management", href: "/risks", icon: AlertTriangle },
  { title: "Compliance Tracking", href: "/compliance", icon: CheckCircle },
  { title: "Feedback Management", href: "/feedback", icon: MessageSquare },
  { title: "Documentation", href: "/documentation", icon: FileText },
];

export function Sidebar() {
  const [isExpanded, setIsExpanded] = useState(true);

  return (
    <aside className="bg-[hsl(215,45%,20%)] h-screen flex flex-col w-64 shrink-0">
      {/* Header */}
      <div className="flex items-center gap-3 p-5 border-b border-white/10">
        <div className="h-9 w-9 rounded-full bg-white/10 flex items-center justify-center">
          <div className="h-5 w-5 rounded-full border-2 border-white/70" />
        </div>
        <div>
          <h1 className="font-display font-bold text-white text-lg leading-tight">
            MedComply
          </h1>
          <p className="text-[11px] text-white/50">
            Leadership Dashboard
          </p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-3">
        {/* Management Hub Section */}
        <div className="mb-2">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center justify-between w-full px-3 py-2 text-xs font-semibold text-white/50 uppercase tracking-wider hover:text-white/70 transition-colors"
          >
            <span>Management Hub</span>
            {isExpanded ? (
              <ChevronUp className="h-4 w-4" />
            ) : (
              <ChevronDown className="h-4 w-4" />
            )}
          </button>

          {isExpanded && (
            <ul className="space-y-0.5 mt-1">
              {managementHubItems.map((item) => (
                <li key={item.href}>
                  <NavLink
                    to={item.href}
                    className={cn(
                      "flex items-center gap-3 px-3 py-2.5 rounded-md text-white/70 hover:bg-white/5 hover:text-white transition-colors text-sm"
                    )}
                    activeClassName="bg-white/10 text-[hsl(195,80%,60%)] font-medium"
                    end={item.href === "/"}
                  >
                    <item.icon className="h-[18px] w-[18px] shrink-0" />
                    <span>{item.title}</span>
                  </NavLink>
                </li>
              ))}
            </ul>
          )}
        </div>
      </nav>

      {/* Footer - User Profile */}
      <div className="p-4 border-t border-white/10">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-full bg-[hsl(195,80%,50%)]/20 flex items-center justify-center text-[hsl(195,80%,60%)] text-sm font-medium">
            JD
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">
              Jane Doe
            </p>
            <p className="text-xs text-white/50 truncate">HR Director</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
