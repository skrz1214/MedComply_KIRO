import { ChevronRight, Home } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const routeNames: Record<string, string> = {
  "": "Dashboard",
  "org-chart": "Org Chart",
  "policies": "Policies & Procedures",
  "audits": "Audit Items",
  "enforcements": "Enforcements",
  "risks": "Risks & Thresholds",
  "compliance": "Compliance Items",
  "training": "Training Statistics",
  "kpis": "Quality KPIs",
  "employee-files": "Employee Files",
  "corrections": "Plan of Correction",
  "apps": "Micro Applications",
  "compliance-connect": "ComplianceConnect",
  "feedback-hub": "FeedbackHub",
  "risk-guard": "RiskGuard",
  "audit-pro": "AuditPro",
  "enforce-point": "EnforcePoint",
  "cita-pro": "CitaPro",
};

export function Breadcrumb() {
  const location = useLocation();
  const pathSegments = location.pathname.split("/").filter(Boolean);

  const breadcrumbs = pathSegments.map((segment, index) => {
    const path = "/" + pathSegments.slice(0, index + 1).join("/");
    const name = routeNames[segment] || segment;
    const isLast = index === pathSegments.length - 1;

    return { path, name, isLast };
  });

  return (
    <nav className="flex items-center gap-1.5 text-sm">
      <Link
        to="/"
        className="flex items-center gap-1 text-muted-foreground hover:text-foreground transition-colors"
      >
        <Home className="h-4 w-4" />
        {pathSegments.length === 0 && <span>Dashboard</span>}
      </Link>

      {breadcrumbs.map((crumb) => (
        <span key={crumb.path} className="flex items-center gap-1.5">
          <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/50" />
          {crumb.isLast ? (
            <span className="font-medium text-foreground">{crumb.name}</span>
          ) : (
            <Link
              to={crumb.path}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              {crumb.name}
            </Link>
          )}
        </span>
      ))}
    </nav>
  );
}
