import { Sidebar } from "./Sidebar";
import { Breadcrumb } from "./Breadcrumb";
import { RoleSwitcher } from "./RoleSwitcher";
import { Bell, Search, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useRole } from "@/contexts/RoleContext";
import { Badge } from "@/components/ui/badge";

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const { isImpersonating } = useRole();

  return (
    <div className="flex min-h-screen w-full bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col min-w-0">
        {/* Impersonation Banner */}
        {isImpersonating && (
          <div className="bg-warning/20 border-b border-warning/30 px-4 py-2 text-center">
            <Badge variant="outline" className="text-warning border-warning">
              Impersonation Mode Active
            </Badge>
          </div>
        )}

        {/* Top Bar */}
        <header className="sticky top-0 z-10 bg-card border-b border-border px-6 py-3">
          <div className="flex items-center justify-between gap-4">
            <Breadcrumb />
            
            <div className="flex items-center gap-3">
              <div className="relative hidden md:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search..."
                  className="pl-9 w-64 bg-muted/50 border-0 focus-visible:ring-1"
                />
              </div>

              <RoleSwitcher />
              
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5 text-muted-foreground" />
                <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-destructive" />
              </Button>
              
              <Button variant="ghost" size="icon">
                <Settings className="h-5 w-5 text-muted-foreground" />
              </Button>
            </div>
          </div>
        </header>
        
        {/* Main Content */}
        <main className="flex-1 p-6 overflow-auto">
          <div className="animate-fade-in">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
