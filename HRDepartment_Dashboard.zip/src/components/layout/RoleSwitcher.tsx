import { useRole, UserRole } from "@/contexts/RoleContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, Users, Eye, ChevronDown, UserCog } from "lucide-react";
import { cn } from "@/lib/utils";

const roleConfig: Record<
  UserRole,
  { label: string; description: string; icon: React.ElementType; color: string }
> = {
  admin: {
    label: "Admin",
    description: "Master Compliance Dashboard",
    icon: Shield,
    color: "text-destructive",
  },
  department_head: {
    label: "Department",
    description: "Department-level management",
    icon: Users,
    color: "text-warning",
  },
  viewer: {
    label: "View Only",
    description: "Read-only access",
    icon: Eye,
    color: "text-muted-foreground",
  },
};

export function RoleSwitcher() {
  const { currentRole, setRole, isImpersonating, currentUser } = useRole();
  const config = roleConfig[currentRole];
  const Icon = config.icon;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          className={cn(
            "gap-2 h-9",
            isImpersonating && "border-warning bg-warning/10"
          )}
        >
          <UserCog className="h-4 w-4" />
          <span className="hidden sm:inline">{currentUser.name}</span>
          <Badge
            variant="secondary"
            className={cn("text-xs", config.color)}
          >
            <Icon className="h-3 w-3 mr-1" />
            {config.label}
          </Badge>
          <ChevronDown className="h-4 w-4 opacity-50" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        <DropdownMenuLabel className="flex items-center gap-2">
          <UserCog className="h-4 w-4" />
          Impersonate Role
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {(Object.keys(roleConfig) as UserRole[]).map((role) => {
          const { label, description, icon: RoleIcon, color } = roleConfig[role];
          const isActive = currentRole === role;
          return (
            <DropdownMenuItem
              key={role}
              onClick={() => setRole(role)}
              className={cn(
                "flex items-start gap-3 p-3 cursor-pointer",
                isActive && "bg-muted"
              )}
            >
              <div className={cn("mt-0.5", color)}>
                <RoleIcon className="h-4 w-4" />
              </div>
              <div className="flex-1">
                <div className="font-medium">{label}</div>
                <div className="text-xs text-muted-foreground">
                  {description}
                </div>
              </div>
              {isActive && (
                <Badge variant="secondary" className="text-xs">
                  Active
                </Badge>
              )}
            </DropdownMenuItem>
          );
        })}
        {isImpersonating && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={() => setRole("admin")}
              className="text-warning"
            >
              Exit Impersonation
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
