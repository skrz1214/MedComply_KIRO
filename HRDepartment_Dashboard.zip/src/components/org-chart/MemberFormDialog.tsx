import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

interface OrgMember {
  id: string;
  name: string;
  initials: string;
  title: string;
  department: string;
  role: string;
  email: string;
  isHead?: boolean;
  reportsTo?: string;
}

interface MemberFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  member: OrgMember | null;
  members: OrgMember[];
  onSave: (member: OrgMember) => void;
  mode: "add" | "edit";
}

const generateInitials = (name: string): string => {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 3);
};

const roles = ["Executive", "Director", "Manager", "Officer", "Staff"];
const departments = [
  "Human Resources",
  "HR Operations",
  "Training",
  "Employee Relations",
  "HR Compliance",
  "Benefits",
  "Recruitment",
  "Payroll",
];

export function MemberFormDialog({
  open,
  onOpenChange,
  member,
  members,
  onSave,
  mode,
}: MemberFormDialogProps) {
  const [formData, setFormData] = useState<Partial<OrgMember>>({
    name: "",
    title: "",
    department: "",
    role: "",
    email: "",
    isHead: false,
    reportsTo: "",
  });

  useEffect(() => {
    if (member && mode === "edit") {
      setFormData(member);
    } else {
      setFormData({
        name: "",
        title: "",
        department: "",
        role: "",
        email: "",
        isHead: false,
        reportsTo: "",
      });
    }
  }, [member, mode, open]);

  const handleSave = () => {
    if (!formData.name || !formData.title || !formData.department || !formData.role || !formData.email) {
      toast.error("Please fill in all required fields");
      return;
    }

    const newMember: OrgMember = {
      id: member?.id || crypto.randomUUID(),
      name: formData.name,
      initials: generateInitials(formData.name),
      title: formData.title,
      department: formData.department,
      role: formData.role,
      email: formData.email,
      isHead: formData.isHead || false,
      reportsTo: formData.reportsTo,
    };

    onSave(newMember);
    toast.success(mode === "add" ? "Member added successfully" : "Member updated successfully");
    onOpenChange(false);
  };

  const availableManagers = members.filter((m) => m.id !== member?.id);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{mode === "add" ? "Add New Member" : "Edit Member"}</DialogTitle>
          <DialogDescription>
            {mode === "add"
              ? "Add a new member to the organization"
              : "Update member information"}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name *</Label>
            <Input
              id="name"
              placeholder="Enter full name..."
              value={formData.name || ""}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">Job Title *</Label>
            <Input
              id="title"
              placeholder="Enter job title..."
              value={formData.title || ""}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="department">Department *</Label>
              <Select
                value={formData.department || ""}
                onValueChange={(value) => setFormData({ ...formData, department: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">Role *</Label>
              <Select
                value={formData.role || ""}
                onValueChange={(value) => setFormData({ ...formData, role: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  {roles.map((role) => (
                    <SelectItem key={role} value={role}>
                      {role}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email *</Label>
            <Input
              id="email"
              type="email"
              placeholder="Enter email address..."
              value={formData.email || ""}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="reportsTo">Reports To</Label>
            <Select
              value={formData.reportsTo || "none"}
              onValueChange={(value) =>
                setFormData({ ...formData, reportsTo: value === "none" ? "" : value })
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Select manager" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None (Head of Organization)</SelectItem>
                {availableManagers.map((m) => (
                  <SelectItem key={m.id} value={m.id}>
                    {m.name} - {m.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            {mode === "add" ? "Add Member" : "Save Changes"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
