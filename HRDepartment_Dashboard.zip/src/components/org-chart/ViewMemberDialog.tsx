import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Mail, Building2, Briefcase, User } from "lucide-react";

interface OrgMember {
  id: string;
  name: string;
  initials: string;
  title: string;
  department: string;
  role: string;
  email: string;
  isHead?: boolean;
  reportsTo?: string;
}

interface ViewMemberDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  member: OrgMember | null;
}

export function ViewMemberDialog({
  open,
  onOpenChange,
  member,
}: ViewMemberDialogProps) {
  if (!member) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[450px]">
        <DialogHeader>
          <DialogTitle>Member Profile</DialogTitle>
        </DialogHeader>

        <div className="flex flex-col items-center py-6">
          <div className="h-20 w-20 rounded-full bg-primary/10 text-primary text-2xl font-bold flex items-center justify-center mb-4">
            {member.initials}
          </div>
          <h3 className="text-xl font-semibold">{member.name}</h3>
          <p className="text-muted-foreground">{member.title}</p>
          {member.isHead && (
            <Badge className="mt-2" variant="default">Head of Organization</Badge>
          )}
        </div>

        <div className="space-y-4 border-t pt-4">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-muted flex items-center justify-center">
              <Building2 className="h-4 w-4 text-muted-foreground" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Department</p>
              <p className="font-medium">{member.department}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-muted flex items-center justify-center">
              <Briefcase className="h-4 w-4 text-muted-foreground" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Role</p>
              <p className="font-medium">{member.role}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-muted flex items-center justify-center">
              <Mail className="h-4 w-4 text-muted-foreground" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Email</p>
              <p className="font-medium">{member.email}</p>
            </div>
          </div>

          {member.reportsTo && (
            <div className="flex items-center gap-3">
              <div className="h-9 w-9 rounded-lg bg-muted flex items-center justify-center">
                <User className="h-4 w-4 text-muted-foreground" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Reports To</p>
                <p className="font-medium">{member.reportsTo}</p>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
