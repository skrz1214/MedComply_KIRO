import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Clock,
  User,
  Search,
  FileText,
  ClipboardCheck,
  GraduationCap,
  ChevronRight,
  Calendar,
  CheckCircle,
  AlertTriangle,
  Eye,
} from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useRole } from "@/contexts/RoleContext";

interface ActionItem {
  id: string;
  title: string;
  dueDate: string;
  dueLabel: string;
  assignee: string;
  priority: "high" | "medium" | "low";
  status: "not-started" | "in-progress" | "completed";
  department: string;
  type: string;
}

interface ReviewItem {
  id: string;
  title: string;
  type: string;
  author: string;
  date: string;
  status: "pending" | "in-review";
  icon: React.ElementType;
}

// User's assigned tasks only
const userActionItems: ActionItem[] = [
  {
    id: "1",
    title: "Review compliance documentation for Q2 2025",
    dueDate: "2024-12-13",
    dueLabel: "Due Today",
    assignee: "Me",
    priority: "high",
    status: "not-started",
    department: "Compliance",
    type: "Policy",
  },
  {
    id: "3",
    title: "Complete HIPAA training certification",
    dueDate: "2024-12-15",
    dueLabel: "Due in 2 days",
    assignee: "Me",
    priority: "high",
    status: "not-started",
    department: "Compliance",
    type: "Training",
  },
];

const userReviewItems: ReviewItem[] = [
  {
    id: "1",
    title: "New policy draft – Patient Data Protection",
    type: "Policy",
    author: "Sarah Johnson",
    date: "Dec 10, 2024",
    status: "pending",
    icon: FileText,
  },
];

const priorityStyles = {
  high: "bg-destructive/10 text-destructive border-destructive/20",
  medium: "bg-warning/10 text-warning border-warning/20",
  low: "bg-success/10 text-success border-success/20",
};

const priorityLabels = {
  high: "High",
  medium: "Med",
  low: "Low",
};

const statusStyles = {
  "not-started": "text-muted-foreground",
  "in-progress": "text-info",
  "completed": "text-success",
};

const statusLabels = {
  "not-started": "Not started",
  "in-progress": "In progress",
  "completed": "Completed",
};

export function ViewerDashboard() {
  const navigate = useNavigate();
  const { currentUser } = useRole();
  const [activeTab, setActiveTab] = useState("today");
  const [searchTerm, setSearchTerm] = useState("");

  const getItemRoute = (item: ActionItem) => {
    switch (item.type) {
      case "Policy": return "/policies";
      case "Audit": return "/audits";
      case "Training": return "/training";
      case "Enforcement": return "/enforcements";
      case "Risk": return "/risks";
      default: return "/";
    }
  };

  const getReviewRoute = (item: ReviewItem) => {
    switch (item.type) {
      case "Policy": return "/policies";
      case "Audit": return "/audits";
      case "Training": return "/training";
      default: return "/";
    }
  };

  const completedToday = userActionItems.filter((item) => item.status === "completed" && item.dueLabel === "Due Today").length;
  const totalToday = userActionItems.filter((item) => item.dueLabel === "Due Today" || item.dueLabel === "Due Tomorrow").length;
  const progressPercent = totalToday > 0 ? (completedToday / totalToday) * 100 : 0;

  const todayCount = userActionItems.filter((item) => item.dueLabel === "Due Today" || item.dueLabel === "Due Tomorrow").length;
  const weekCount = userActionItems.filter((item) => item.dueLabel.includes("days")).length;
  const overdueCount = userActionItems.filter((item) => item.dueLabel === "Overdue").length;

  const filteredItems = userActionItems.filter((item) => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase());
    
    let matchesTab = true;
    if (activeTab === "today") matchesTab = item.dueLabel === "Due Today" || item.dueLabel === "Due Tomorrow";
    if (activeTab === "week") matchesTab = item.dueLabel.includes("days");
    if (activeTab === "overdue") matchesTab = item.dueLabel === "Overdue";
    
    return matchesSearch && matchesTab;
  });

  return (
    <>
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Eye className="h-6 w-6 text-muted-foreground" />
          <span className="text-sm font-medium text-muted-foreground uppercase tracking-wide">View Only</span>
        </div>
        <h1 className="font-display text-3xl font-bold text-foreground">
          My Compliance Dashboard
        </h1>
        <p className="text-muted-foreground mt-1">
          Read-only access • {currentUser.name} • {currentUser.department}
        </p>
      </div>

      {/* Quick Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <FileText className="h-5 w-5 text-primary" />
            </div>
            <div>
              <div className="text-2xl font-bold">{userActionItems.length}</div>
              <div className="text-sm text-muted-foreground">My Tasks</div>
            </div>
          </div>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-success/10 flex items-center justify-center">
              <CheckCircle className="h-5 w-5 text-success" />
            </div>
            <div>
              <div className="text-2xl font-bold">0</div>
              <div className="text-sm text-muted-foreground">Completed</div>
            </div>
          </div>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-warning/10 flex items-center justify-center">
              <Clock className="h-5 w-5 text-warning" />
            </div>
            <div>
              <div className="text-2xl font-bold">{userActionItems.length}</div>
              <div className="text-sm text-muted-foreground">Pending</div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-3 space-y-6">
          {/* My Tasks */}
          <div className="bg-card rounded-xl border border-border p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <h2 className="font-display text-xl font-semibold">My Tasks</h2>
                <span className="h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs font-medium flex items-center justify-center">
                  {userActionItems.length}
                </span>
              </div>
              <div className="text-sm text-muted-foreground italic">
                View only mode
              </div>
            </div>

            {/* Progress Bar */}
            <div className="bg-muted/50 rounded-lg p-4 mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">My Progress</span>
                <span className="text-sm text-muted-foreground">
                  {completedToday} of {totalToday} completed
                </span>
              </div>
              <Progress value={progressPercent} className="h-2" />
            </div>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-4">
              <TabsList className="bg-muted/50 p-1">
                <TabsTrigger value="today" className="data-[state=active]:bg-card">
                  Today <span className="ml-1.5 text-muted-foreground">{todayCount}</span>
                </TabsTrigger>
                <TabsTrigger value="week" className="data-[state=active]:bg-card">
                  This Week <span className="ml-1.5 text-muted-foreground">{weekCount}</span>
                </TabsTrigger>
                <TabsTrigger value="overdue" className="data-[state=active]:bg-card text-destructive">
                  Overdue <span className="ml-1.5">{overdueCount}</span>
                </TabsTrigger>
              </TabsList>
            </Tabs>

            {/* Search */}
            <div className="mb-4">
              <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search my tasks"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>

            {/* Task List */}
            <div className="space-y-3">
              {filteredItems.map((item) => (
                <div
                  key={item.id}
                  onClick={() => navigate(getItemRoute(item))}
                  className="p-4 rounded-lg border border-border bg-card hover:border-primary/30 hover:bg-muted/50 transition-colors cursor-pointer"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <h3 className="font-medium mb-2">{item.title}</h3>
                      <div className="flex flex-wrap items-center gap-2 text-sm">
                        <span className={cn(
                          "flex items-center gap-1",
                          item.dueLabel === "Overdue" ? "text-destructive" : "text-warning"
                        )}>
                          <Clock className="h-3.5 w-3.5" />
                          {item.dueLabel}
                        </span>
                        <span className="text-muted-foreground">•</span>
                        <span className={cn(
                          "px-2 py-0.5 rounded-full text-xs font-medium border",
                          priorityStyles[item.priority]
                        )}>
                          {priorityLabels[item.priority]}
                        </span>
                        <span className={cn("text-sm", statusStyles[item.status])}>
                          {statusLabels[item.status]}
                        </span>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </div>
                </div>
              ))}

              {filteredItems.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  No tasks found
                </div>
              )}
            </div>
          </div>

          {/* Items to Review */}
          <div className="bg-card rounded-xl border border-border p-6">
            <div className="flex items-center gap-3 mb-2">
              <h2 className="font-display text-xl font-semibold">Items to Review</h2>
              <span className="h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs font-medium flex items-center justify-center">
                {userReviewItems.length}
              </span>
            </div>
            <p className="text-sm text-muted-foreground mb-6">Documents assigned for your review</p>

            <div className="space-y-4">
              {userReviewItems.map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.id}
                    onClick={() => navigate(getReviewRoute(item))}
                    className="flex items-center gap-4 p-4 rounded-lg border border-border hover:border-primary/30 hover:bg-muted/50 transition-colors cursor-pointer"
                  >
                    <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                      <Icon className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium">{item.title}</h3>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                        <span className="px-2 py-0.5 rounded bg-muted text-xs font-medium">
                          {item.type}
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="h-3.5 w-3.5" />
                          {item.author}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3.5 w-3.5" />
                          {item.date}
                        </span>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          <div className="bg-card rounded-xl border border-border p-5">
            <h3 className="font-display font-semibold mb-4">My Stats</h3>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-lg bg-success/10 flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-success" />
                  </div>
                  <span className="text-sm">Completed</span>
                </div>
                <span className="text-xl font-bold">0</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-lg bg-warning/10 flex items-center justify-center">
                    <Clock className="h-4 w-4 text-warning" />
                  </div>
                  <span className="text-sm">Pending</span>
                </div>
                <span className="text-xl font-bold">{userActionItems.length}</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-lg bg-destructive/10 flex items-center justify-center">
                    <AlertTriangle className="h-4 w-4 text-destructive" />
                  </div>
                  <span className="text-sm">Overdue</span>
                </div>
                <span className="text-xl font-bold">0</span>
              </div>
            </div>
          </div>

          <div className="bg-card rounded-xl border border-border p-5">
            <h3 className="font-display font-semibold mb-4">Upcoming Training</h3>
            <div className="space-y-3">
              <div className="p-3 rounded-lg border border-border">
                <div className="flex items-center gap-2 mb-1">
                  <GraduationCap className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">HIPAA Training</span>
                </div>
                <div className="text-xs text-muted-foreground">Due in 2 days</div>
              </div>
              <div className="p-3 rounded-lg border border-border">
                <div className="flex items-center gap-2 mb-1">
                  <ClipboardCheck className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">Compliance Basics</span>
                </div>
                <div className="text-xs text-muted-foreground">Due Jan 5, 2025</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
