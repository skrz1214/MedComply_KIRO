import { cn } from "@/lib/utils";

type StatusType = "pending" | "completed" | "overdue" | "active" | "inactive" | "high" | "medium" | "low";

interface StatusBadgeProps {
  status: StatusType;
  label?: string;
}

const statusStyles: Record<StatusType, string> = {
  pending: "status-pending",
  completed: "status-completed",
  overdue: "status-overdue",
  active: "status-active",
  inactive: "bg-muted text-muted-foreground",
  high: "bg-destructive/15 text-destructive",
  medium: "bg-warning/15 text-warning",
  low: "bg-success/15 text-success",
};

const defaultLabels: Record<StatusType, string> = {
  pending: "Pending",
  completed: "Completed",
  overdue: "Overdue",
  active: "Active",
  inactive: "Inactive",
  high: "High",
  medium: "Medium",
  low: "Low",
};

export function StatusBadge({ status, label }: StatusBadgeProps) {
  return (
    <span className={cn("status-badge", statusStyles[status])}>
      {label || defaultLabels[status]}
    </span>
  );
}
