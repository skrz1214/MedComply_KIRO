import { Calendar, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

interface Deadline {
  id: string;
  title: string;
  dueDate: string;
  type: string;
  priority: "high" | "medium" | "low";
}

interface UpcomingDeadlinesProps {
  deadlines: Deadline[];
  onItemClick?: (deadline: Deadline) => void;
}

const priorityColors = {
  high: "border-l-destructive",
  medium: "border-l-warning",
  low: "border-l-success",
};

export function UpcomingDeadlines({ deadlines, onItemClick }: UpcomingDeadlinesProps) {
  return (
    <div className="bg-card rounded-lg border border-border p-5">
      <div className="flex items-center gap-2 mb-4">
        <Calendar className="h-5 w-5 text-primary" />
        <h3 className="font-display font-semibold text-foreground">Upcoming Deadlines</h3>
      </div>
      
      <div className="space-y-3">
        {deadlines.map((deadline) => (
          <button
            key={deadline.id}
            onClick={() => onItemClick?.(deadline)}
            className={cn(
              "w-full text-left p-3 rounded-md bg-muted/50 border-l-4 hover:bg-muted transition-colors",
              priorityColors[deadline.priority]
            )}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">{deadline.title}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{deadline.type}</p>
              </div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground shrink-0">
                <Clock className="h-3 w-3" />
                {deadline.dueDate}
              </div>
            </div>
          </button>
        ))}
        
        {deadlines.length === 0 && (
          <p className="text-sm text-muted-foreground text-center py-4">
            No upcoming deadlines
          </p>
        )}
      </div>
    </div>
  );
}
