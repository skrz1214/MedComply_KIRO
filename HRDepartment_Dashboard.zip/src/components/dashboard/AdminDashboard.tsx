import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AddActionItemDialog } from "@/components/dashboard/AddActionItemDialog";
import { QualityKPIs } from "@/components/dashboard/QualityKPIs";
import { QuickAccessApps } from "@/components/dashboard/QuickAccessApps";
import {
  Plus,
  Clock,
  User,
  Search,
  FileText,
  ClipboardCheck,
  GraduationCap,
  ChevronRight,
  Calendar,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
} from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useRole } from "@/contexts/RoleContext";

interface ActionItem {
  id: string;
  title: string;
  dueDate: string;
  dueLabel: string;
  assignee: string;
  priority: "high" | "medium" | "low";
  status: "not-started" | "in-progress" | "completed";
  department: string;
  type: string;
}

interface ReviewItem {
  id: string;
  title: string;
  type: string;
  author: string;
  date: string;
  status: "pending" | "in-review";
  icon: React.ElementType;
}

const initialActionItems: ActionItem[] = [
  {
    id: "1",
    title: "Review compliance documentation for Q2 2025",
    dueDate: "2024-12-13",
    dueLabel: "Due Today",
    assignee: "Me",
    priority: "high",
    status: "not-started",
    department: "Compliance",
    type: "Policy",
  },
  {
    id: "2",
    title: "Update risk assessment report",
    dueDate: "2024-12-14",
    dueLabel: "Due Tomorrow",
    assignee: "Me",
    priority: "medium",
    status: "in-progress",
    department: "Risk Management",
    type: "Risk",
  },
  {
    id: "3",
    title: "Complete HIPAA training certification",
    dueDate: "2024-12-15",
    dueLabel: "Due in 2 days",
    assignee: "Me",
    priority: "high",
    status: "not-started",
    department: "Compliance",
    type: "Training",
  },
  {
    id: "4",
    title: "Submit quarterly audit findings",
    dueDate: "2024-12-10",
    dueLabel: "Overdue",
    assignee: "Sarah Johnson",
    priority: "high",
    status: "not-started",
    department: "Audit",
    type: "Audit",
  },
  {
    id: "5",
    title: "Review enforcement action response",
    dueDate: "2024-12-11",
    dueLabel: "Overdue",
    assignee: "Me",
    priority: "medium",
    status: "in-progress",
    department: "Compliance",
    type: "Enforcement",
  },
];

const reviewItems: ReviewItem[] = [
  {
    id: "1",
    title: "New policy draft – Patient Data Protection",
    type: "Policy",
    author: "Sarah Johnson",
    date: "Dec 10, 2024",
    status: "pending",
    icon: FileText,
  },
  {
    id: "2",
    title: "Quarterly Audit Results",
    type: "Audit",
    author: "Michael Chen",
    date: "Dec 9, 2024",
    status: "in-review",
    icon: ClipboardCheck,
  },
  {
    id: "3",
    title: "Staff Training Compliance Report",
    type: "Training",
    author: "Emily Davis",
    date: "Dec 8, 2024",
    status: "pending",
    icon: GraduationCap,
  },
];

const priorityStyles = {
  high: "bg-destructive/10 text-destructive border-destructive/20",
  medium: "bg-warning/10 text-warning border-warning/20",
  low: "bg-success/10 text-success border-success/20",
};

const priorityLabels = {
  high: "High",
  medium: "Med",
  low: "Low",
};

const statusStyles = {
  "not-started": "text-muted-foreground",
  "in-progress": "text-info",
  "completed": "text-success",
};

const statusLabels = {
  "not-started": "Not started",
  "in-progress": "In progress",
  "completed": "Completed",
};

export function AdminDashboard() {
  const navigate = useNavigate();
  const { currentUser } = useRole();
  const [actionItems, setActionItems] = useState<ActionItem[]>(initialActionItems);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("today");
  const [assigneeFilter, setAssigneeFilter] = useState("all");
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  const getItemRoute = (item: ActionItem) => {
    switch (item.type) {
      case "Policy": return "/policies";
      case "Audit": return "/audits";
      case "Training": return "/training";
      case "Enforcement": return "/enforcements";
      case "Risk": return "/risks";
      default: return "/";
    }
  };

  const getReviewRoute = (item: ReviewItem) => {
    switch (item.type) {
      case "Policy": return "/policies";
      case "Audit": return "/audits";
      case "Training": return "/training";
      default: return "/";
    }
  };

  const completedToday = actionItems.filter((item) => item.status === "completed" && item.dueLabel === "Due Today").length;
  const totalToday = actionItems.filter((item) => item.dueLabel === "Due Today" || item.dueLabel === "Due Tomorrow").length;
  const progressPercent = totalToday > 0 ? (completedToday / totalToday) * 100 : 0;

  const todayCount = actionItems.filter((item) => item.dueLabel === "Due Today" || item.dueLabel === "Due Tomorrow").length;
  const weekCount = actionItems.filter((item) => item.dueLabel.includes("days")).length;
  const overdueCount = actionItems.filter((item) => item.dueLabel === "Overdue").length;

  const handleAddActionItem = (newItem: ActionItem) => {
    setActionItems([newItem, ...actionItems]);
  };

  const filteredItems = actionItems.filter((item) => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesAssignee = assigneeFilter === "all" || (assigneeFilter === "me" && item.assignee === "Me");
    const matchesDepartment = departmentFilter === "all" || item.department === departmentFilter;
    const matchesType = typeFilter === "all" || item.type === typeFilter;
    
    let matchesTab = true;
    if (activeTab === "today") matchesTab = item.dueLabel === "Due Today" || item.dueLabel === "Due Tomorrow";
    if (activeTab === "week") matchesTab = item.dueLabel.includes("days");
    if (activeTab === "overdue") matchesTab = item.dueLabel === "Overdue";
    
    return matchesSearch && matchesAssignee && matchesDepartment && matchesType && matchesTab;
  });

  return (
    <>
      {/* Header */}
      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold text-foreground">
          HR Compliance Master Dashboard
        </h1>
        <p className="text-muted-foreground mt-1">
          HR Compliance Dashboard
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-3 space-y-6">
          {/* Action Center */}
          <div className="bg-card rounded-xl border border-border p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <h2 className="font-display text-xl font-semibold">Action Center</h2>
                <span className="h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs font-medium flex items-center justify-center">
                  {actionItems.length}
                </span>
              </div>
              <Button onClick={() => setAddDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Action Item
              </Button>
            </div>

            <p className="text-sm text-muted-foreground mb-4">All organization compliance tasks</p>

            {/* Progress Bar */}
            <div className="bg-muted/50 rounded-lg p-4 mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Organization Progress</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">
                    {completedToday} of {totalToday} completed
                  </span>
                  <button className="p-1 rounded hover:bg-muted">
                    <RefreshCw className="h-4 w-4 text-muted-foreground" />
                  </button>
                </div>
              </div>
              <Progress value={progressPercent} className="h-2" />
            </div>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-4">
              <TabsList className="bg-muted/50 p-1">
                <TabsTrigger value="today" className="data-[state=active]:bg-card">
                  Today <span className="ml-1.5 text-muted-foreground">{todayCount}</span>
                </TabsTrigger>
                <TabsTrigger value="week" className="data-[state=active]:bg-card">
                  This Week <span className="ml-1.5 text-muted-foreground">{weekCount}</span>
                </TabsTrigger>
                <TabsTrigger value="overdue" className="data-[state=active]:bg-card text-destructive">
                  Overdue <span className="ml-1.5">{overdueCount}</span>
                </TabsTrigger>
              </TabsList>
            </Tabs>

            {/* Filters */}
            <div className="flex flex-wrap items-center gap-3 mb-4">
              <div className="flex rounded-lg border border-border overflow-hidden">
                <button
                  onClick={() => setAssigneeFilter("me")}
                  className={cn(
                    "px-4 py-2 text-sm font-medium transition-colors",
                    assigneeFilter === "me" ? "bg-primary text-primary-foreground" : "bg-card hover:bg-muted"
                  )}
                >
                  Me
                </button>
                <button
                  onClick={() => setAssigneeFilter("all")}
                  className={cn(
                    "px-4 py-2 text-sm font-medium transition-colors border-l border-border",
                    assigneeFilter === "all" ? "bg-primary text-primary-foreground" : "bg-card hover:bg-muted"
                  )}
                >
                  All
                </button>
              </div>

              <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="All Departments" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  <SelectItem value="Compliance">Compliance</SelectItem>
                  <SelectItem value="Risk Management">Risk Management</SelectItem>
                  <SelectItem value="Audit">Audit</SelectItem>
                  <SelectItem value="HR">HR</SelectItem>
                </SelectContent>
              </Select>

              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Policy">Policy</SelectItem>
                  <SelectItem value="Audit">Audit</SelectItem>
                  <SelectItem value="Training">Training</SelectItem>
                  <SelectItem value="Enforcement">Enforcement</SelectItem>
                  <SelectItem value="Risk">Risk</SelectItem>
                </SelectContent>
              </Select>

              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search tasks"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>

            {/* Action Items List */}
            <div className="space-y-3">
              {filteredItems.map((item) => (
                <div
                  key={item.id}
                  onClick={() => navigate(getItemRoute(item))}
                  className="p-4 rounded-lg border border-border bg-card hover:border-primary/30 hover:bg-muted/50 transition-colors cursor-pointer"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <h3 className="font-medium mb-2">{item.title}</h3>
                      <div className="flex flex-wrap items-center gap-2 text-sm">
                        <span className={cn(
                          "flex items-center gap-1",
                          item.dueLabel === "Overdue" ? "text-destructive" : "text-warning"
                        )}>
                          <Clock className="h-3.5 w-3.5" />
                          {item.dueLabel}
                        </span>
                        <span className="text-muted-foreground">•</span>
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <User className="h-3.5 w-3.5" />
                          {item.assignee}
                        </span>
                        <span className="text-muted-foreground">•</span>
                        <span className="text-muted-foreground text-xs">{item.department}</span>
                        <span className="text-muted-foreground">•</span>
                        <span className={cn(
                          "px-2 py-0.5 rounded-full text-xs font-medium border",
                          priorityStyles[item.priority]
                        )}>
                          {priorityLabels[item.priority]}
                        </span>
                        <span className={cn("text-sm", statusStyles[item.status])}>
                          {statusLabels[item.status]}
                        </span>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </div>
                </div>
              ))}

              {filteredItems.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  No tasks found matching your filters
                </div>
              )}
            </div>
          </div>

          {/* Review Queue */}
          <div className="bg-card rounded-xl border border-border p-6">
            <div className="flex items-center gap-3 mb-2">
              <h2 className="font-display text-xl font-semibold">Review Queue</h2>
              <span className="h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs font-medium flex items-center justify-center">
                {reviewItems.length}
              </span>
            </div>
            <p className="text-sm text-muted-foreground mb-6">Pending reviews & sign-offs</p>

            <div className="space-y-4">
              {reviewItems.map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.id}
                    onClick={() => navigate(getReviewRoute(item))}
                    className="flex items-center gap-4 p-4 rounded-lg border border-border hover:border-primary/30 hover:bg-muted/50 transition-colors cursor-pointer"
                  >
                    <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                      <Icon className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium">{item.title}</h3>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                        <span className="px-2 py-0.5 rounded bg-muted text-xs font-medium">
                          {item.type}
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="h-3.5 w-3.5" />
                          {item.author}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3.5 w-3.5" />
                          {item.date}
                        </span>
                        <span className={cn(
                          "text-xs font-medium",
                          item.status === "pending" ? "text-warning" : "text-info"
                        )}>
                          {item.status === "pending" ? "Pending Review" : "In Review"}
                        </span>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Sidebar - Stats Summary */}
        <div className="space-y-4">
          <div className="bg-card rounded-xl border border-border p-5">
            <h3 className="font-display font-semibold mb-4">Quick Stats</h3>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-lg bg-muted flex items-center justify-center">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <span className="text-sm">Total</span>
                </div>
                <div className="text-right">
                  <span className="text-xl font-bold">42</span>
                  <span className="text-xs text-success ml-1">+3</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-lg bg-success/10 flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-success" />
                  </div>
                  <span className="text-sm">Completed</span>
                </div>
                <div className="text-right">
                  <span className="text-xl font-bold text-success">25</span>
                  <span className="text-xs text-success ml-1">+5</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-lg bg-warning/10 flex items-center justify-center">
                    <Clock className="h-4 w-4 text-warning" />
                  </div>
                  <span className="text-sm">Pending</span>
                </div>
                <div className="text-right">
                  <span className="text-xl font-bold text-warning">13</span>
                  <span className="text-xs text-destructive ml-1">+2</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-lg bg-destructive/10 flex items-center justify-center">
                    <AlertTriangle className="h-4 w-4 text-destructive" />
                  </div>
                  <span className="text-sm">Overdue</span>
                </div>
                <div className="text-right">
                  <span className="text-xl font-bold text-destructive">4</span>
                  <span className="text-xs text-destructive ml-1">+1</span>
                </div>
              </div>
            </div>
          </div>

          {/* Quality KPIs */}
          <QualityKPIs />
        </div>
      </div>

      {/* Quick Access Apps */}
      <div className="mt-6">
        <QuickAccessApps />
      </div>

      <AddActionItemDialog
        open={addDialogOpen}
        onOpenChange={setAddDialogOpen}
        onAdd={handleAddActionItem}
      />
    </>
  );
}
