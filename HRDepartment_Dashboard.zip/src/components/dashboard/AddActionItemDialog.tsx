import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import {
  CalendarIcon,
  ShieldCheck,
  AlertTriangle,
  MessageSquare,
  ClipboardCheck,
  Scale,
  FileText,
  Target,
} from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface ActionItem {
  id: string;
  title: string;
  dueDate: string;
  dueLabel: string;
  assignee: string;
  priority: "high" | "medium" | "low";
  status: "not-started" | "in-progress" | "completed";
  department: string;
  type: string;
  description?: string;
}

interface AddActionItemDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAdd: (item: ActionItem) => void;
}

const taskTypes = [
  { id: "compliance", label: "Compliance", icon: ShieldCheck, color: "text-primary" },
  { id: "risk", label: "Risk", icon: AlertTriangle, color: "text-warning" },
  { id: "feedback", label: "Feedback", icon: MessageSquare, color: "text-info" },
  { id: "audit", label: "Audit", icon: ClipboardCheck, color: "text-success" },
  { id: "enforcement", label: "Enforcement", icon: Scale, color: "text-destructive" },
  { id: "citation", label: "Citation", icon: FileText, color: "text-muted-foreground" },
  { id: "kpi", label: "KPI", icon: Target, color: "text-primary" },
];

const departments = [
  "Compliance",
  "Audit",
  "Risk Management",
  "Human Resources",
  "Training",
  "Legal",
];

const priorities = [
  { value: "high", label: "High" },
  { value: "medium", label: "Medium" },
  { value: "low", label: "Low" },
];

const assignees = [
  "Me",
  "Sarah Johnson",
  "Michael Chen",
  "Emily Davis",
  "Robert Martinez",
  "Jennifer Lee",
];

const getDueLabel = (date: Date): string => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const dueDate = new Date(date);
  dueDate.setHours(0, 0, 0, 0);

  const diffTime = dueDate.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 0) return "Overdue";
  if (diffDays === 0) return "Due Today";
  if (diffDays === 1) return "Due Tomorrow";
  return `Due in ${diffDays} days`;
};

export function AddActionItemDialog({
  open,
  onOpenChange,
  onAdd,
}: AddActionItemDialogProps) {
  const [step, setStep] = useState<"type" | "details">("type");
  const [selectedType, setSelectedType] = useState<string>("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [dueDate, setDueDate] = useState<Date>();
  const [assignee, setAssignee] = useState("Me");
  const [priority, setPriority] = useState<"high" | "medium" | "low">("medium");
  const [department, setDepartment] = useState("");

  const resetForm = () => {
    setStep("type");
    setSelectedType("");
    setTitle("");
    setDescription("");
    setDueDate(undefined);
    setAssignee("Me");
    setPriority("medium");
    setDepartment("");
  };

  const handleContinue = () => {
    if (!selectedType) {
      toast.error("Please select a task type");
      return;
    }
    setStep("details");
  };

  const handleBack = () => {
    setStep("type");
  };

  const handleSubmit = () => {
    if (!title.trim()) {
      toast.error("Please enter a title");
      return;
    }
    if (!dueDate) {
      toast.error("Please select a due date");
      return;
    }
    if (!department) {
      toast.error("Please select a department");
      return;
    }

    const typeLabel = taskTypes.find((t) => t.id === selectedType)?.label || selectedType;

    const newItem: ActionItem = {
      id: crypto.randomUUID(),
      title: title.trim(),
      dueDate: dueDate.toISOString().split("T")[0],
      dueLabel: getDueLabel(dueDate),
      assignee,
      priority,
      status: "not-started",
      department,
      type: typeLabel,
      description: description.trim() || undefined,
    };

    onAdd(newItem);
    toast.success("Action item created successfully");
    resetForm();
    onOpenChange(false);
  };

  const handleCancel = () => {
    resetForm();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => {
      if (!isOpen) resetForm();
      onOpenChange(isOpen);
    }}>
      <DialogContent className="sm:max-w-[550px]">
        {step === "type" ? (
          <>
            <DialogHeader>
              <DialogTitle>Add New Action Item</DialogTitle>
              <DialogDescription>
                Select the type of task to create
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-4 gap-3 py-6">
              {taskTypes.map((type) => {
                const Icon = type.icon;
                return (
                  <button
                    key={type.id}
                    onClick={() => setSelectedType(type.id)}
                    className={cn(
                      "flex flex-col items-center justify-center gap-2 p-4 rounded-lg border-2 transition-all hover:border-primary/50",
                      selectedType === type.id
                        ? "border-primary bg-primary/5"
                        : "border-border bg-card"
                    )}
                  >
                    <Icon className={cn("h-6 w-6", type.color)} />
                    <span className="text-sm font-medium">{type.label}</span>
                  </button>
                );
              })}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={handleCancel}>
                Cancel
              </Button>
              <Button onClick={handleContinue} disabled={!selectedType}>
                Continue
              </Button>
            </DialogFooter>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>
                New {taskTypes.find((t) => t.id === selectedType)?.label} Task
              </DialogTitle>
              <DialogDescription>
                Fill in the details for your action item
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  placeholder="Enter action item title..."
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Enter description (optional)..."
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Due Date *</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !dueDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dueDate ? format(dueDate, "PPP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={dueDate}
                        onSelect={setDueDate}
                        initialFocus
                        className="p-3 pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label>Priority *</Label>
                  <Select value={priority} onValueChange={(v) => setPriority(v as "high" | "medium" | "low")}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      {priorities.map((p) => (
                        <SelectItem key={p.value} value={p.value}>
                          {p.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Department *</Label>
                  <Select value={department} onValueChange={setDepartment}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      {departments.map((d) => (
                        <SelectItem key={d} value={d}>
                          {d}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Assign To</Label>
                  <Select value={assignee} onValueChange={setAssignee}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select assignee" />
                    </SelectTrigger>
                    <SelectContent>
                      {assignees.map((a) => (
                        <SelectItem key={a} value={a}>
                          {a}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={handleBack}>
                Back
              </Button>
              <Button onClick={handleSubmit}>Create Action Item</Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
