import { LucideIcon } from "lucide-react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

interface MicroAppTileProps {
  title: string;
  description: string;
  href: string;
  icon: LucideIcon;
  color: "teal" | "blue" | "orange" | "red" | "green" | "purple";
}

const colorStyles = {
  teal: "bg-gradient-to-br from-primary/15 to-primary/5 border-primary/20 hover:border-primary/40",
  blue: "bg-gradient-to-br from-info/15 to-info/5 border-info/20 hover:border-info/40",
  orange: "bg-gradient-to-br from-warning/15 to-warning/5 border-warning/20 hover:border-warning/40",
  red: "bg-gradient-to-br from-destructive/15 to-destructive/5 border-destructive/20 hover:border-destructive/40",
  green: "bg-gradient-to-br from-success/15 to-success/5 border-success/20 hover:border-success/40",
  purple: "bg-gradient-to-br from-accent/15 to-accent/5 border-accent/20 hover:border-accent/40",
};

const iconColorStyles = {
  teal: "text-primary bg-primary/15",
  blue: "text-info bg-info/15",
  orange: "text-warning bg-warning/15",
  red: "text-destructive bg-destructive/15",
  green: "text-success bg-success/15",
  purple: "text-accent-foreground bg-accent",
};

export function MicroAppTile({ title, description, href, icon: Icon, color }: MicroAppTileProps) {
  return (
    <Link
      to={href}
      className={cn(
        "block p-5 rounded-lg border transition-all duration-200 hover:shadow-md group",
        colorStyles[color]
      )}
    >
      <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center mb-3", iconColorStyles[color])}>
        <Icon className="h-5 w-5" />
      </div>
      <h3 className="font-display font-semibold text-foreground group-hover:text-primary transition-colors">
        {title}
      </h3>
      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
        {description}
      </p>
    </Link>
  );
}
