import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, TrendingUp, TrendingDown, Minus, Pencil, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface KPI {
  id: string;
  name: string;
  numerator: number;
  numeratorLabel: string;
  denominator: number;
  denominatorLabel: string;
  target: number;
  unit: string;
  trend: "up" | "down" | "neutral";
}

const calculateValue = (numerator: number, denominator: number): number => {
  if (denominator === 0) return 0;
  return Math.round((numerator / denominator) * 100);
};

const initialKPIs: KPI[] = [
  {
    id: "1",
    name: "Content Compliance Rate",
    numerator: 188,
    numeratorLabel: "Compliant Content",
    denominator: 200,
    denominatorLabel: "Total Content Reviewed",
    target: 95,
    unit: "%",
    trend: "up",
  },
  {
    id: "2",
    name: "Campaign Approval Rate",
    numerator: 44,
    numeratorLabel: "First-Time Approvals",
    denominator: 50,
    denominatorLabel: "Total Submissions",
    target: 90,
    unit: "%",
    trend: "up",
  },
  {
    id: "3",
    name: "Disclosure Compliance Rate",
    numerator: 97,
    numeratorLabel: "Content with Proper Disclosures",
    denominator: 100,
    denominatorLabel: "Content Requiring Disclosure",
    target: 100,
    unit: "%",
    trend: "neutral",
  },
  {
    id: "4",
    name: "Regulatory Violation Rate",
    numerator: 2,
    numeratorLabel: "Violations Found",
    denominator: 100,
    denominatorLabel: "Total Content Audited",
    target: 0,
    unit: "%",
    trend: "down",
  },
];

export function QualityKPIs() {
  const [kpis, setKpis] = useState<KPI[]>(initialKPIs);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingKPI, setEditingKPI] = useState<KPI | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    numerator: "",
    numeratorLabel: "",
    denominator: "",
    denominatorLabel: "",
    target: "",
    unit: "%",
  });

  const resetForm = () => {
    setFormData({ name: "", numerator: "", numeratorLabel: "", denominator: "", denominatorLabel: "", target: "", unit: "%" });
    setEditingKPI(null);
  };

  const openAddDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (kpi: KPI) => {
    setEditingKPI(kpi);
    setFormData({
      name: kpi.name,
      numerator: kpi.numerator.toString(),
      numeratorLabel: kpi.numeratorLabel,
      denominator: kpi.denominator.toString(),
      denominatorLabel: kpi.denominatorLabel,
      target: kpi.target.toString(),
      unit: kpi.unit,
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.name || !formData.numerator || !formData.denominator || !formData.target) {
      toast.error("Please fill in all required fields");
      return;
    }

    const numerator = parseFloat(formData.numerator);
    const denominator = parseFloat(formData.denominator);
    const target = parseFloat(formData.target);
    const value = calculateValue(numerator, denominator);
    
    let trend: "up" | "down" | "neutral" = "neutral";
    if (value >= target) trend = "up";
    else if (value < target * 0.9) trend = "down";

    if (editingKPI) {
      setKpis(
        kpis.map((k) =>
          k.id === editingKPI.id
            ? { ...k, name: formData.name, numerator, numeratorLabel: formData.numeratorLabel, denominator, denominatorLabel: formData.denominatorLabel, target, unit: formData.unit, trend }
            : k
        )
      );
      toast.success("KPI updated successfully");
    } else {
      const newKPI: KPI = {
        id: Date.now().toString(),
        name: formData.name,
        numerator,
        numeratorLabel: formData.numeratorLabel,
        denominator,
        denominatorLabel: formData.denominatorLabel,
        target,
        unit: formData.unit,
        trend,
      };
      setKpis([...kpis, newKPI]);
      toast.success("KPI added successfully");
    }

    setDialogOpen(false);
    resetForm();
  };

  const handleDelete = (id: string) => {
    setKpis(kpis.filter((k) => k.id !== id));
    toast.success("KPI deleted");
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up":
        return <TrendingUp className="h-4 w-4 text-success" />;
      case "down":
        return <TrendingDown className="h-4 w-4 text-destructive" />;
      default:
        return <Minus className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getProgressColor = (value: number, target: number) => {
    const ratio = value / target;
    if (ratio >= 1) return "bg-success";
    if (ratio >= 0.9) return "bg-warning";
    return "bg-destructive";
  };

  return (
    <div className="bg-card rounded-xl border border-border p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-semibold">Quality KPIs</h3>
        <Button variant="ghost" size="icon" onClick={openAddDialog}>
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      <div className="space-y-4">
        {kpis.map((kpi) => {
          const value = calculateValue(kpi.numerator, kpi.denominator);
          return (
            <div key={kpi.id} className="group">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-primary">{kpi.name}</span>
                  {getTrendIcon(kpi.trend)}
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => openEditDialog(kpi)}>
                    <Pencil className="h-3 w-3" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-6 w-6 text-destructive" onClick={() => handleDelete(kpi.id)}>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-bold">{value}</span>
                <span className="text-sm text-muted-foreground">{kpi.unit}</span>
                <span className="text-xs text-muted-foreground ml-auto">Target: {kpi.target}{kpi.unit}</span>
              </div>
              <div className="h-1.5 bg-muted rounded-full mt-2 overflow-hidden">
                <div
                  className={cn("h-full rounded-full transition-all", getProgressColor(value, kpi.target))}
                  style={{ width: `${Math.min((value / kpi.target) * 100, 100)}%` }}
                />
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                📊 ({kpi.numeratorLabel}: {kpi.numerator} ÷ {kpi.denominatorLabel}: {kpi.denominator}) × 100
              </p>
            </div>
          );
        })}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingKPI ? "Edit KPI" : "Add New KPI"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">KPI Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Compliance Rate"
              />
            </div>
            
            <div className="p-3 bg-muted/50 rounded-lg space-y-3">
              <Label className="text-xs text-muted-foreground uppercase tracking-wide">Formula Fields</Label>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="numeratorLabel" className="text-xs">Numerator Label</Label>
                  <Input
                    id="numeratorLabel"
                    value={formData.numeratorLabel}
                    onChange={(e) => setFormData({ ...formData, numeratorLabel: e.target.value })}
                    placeholder="e.g., Compliant Content"
                    className="text-sm"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="numerator" className="text-xs">Numerator Value *</Label>
                  <Input
                    id="numerator"
                    type="number"
                    value={formData.numerator}
                    onChange={(e) => setFormData({ ...formData, numerator: e.target.value })}
                    placeholder="188"
                    className="text-sm"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="denominatorLabel" className="text-xs">Denominator Label</Label>
                  <Input
                    id="denominatorLabel"
                    value={formData.denominatorLabel}
                    onChange={(e) => setFormData({ ...formData, denominatorLabel: e.target.value })}
                    placeholder="e.g., Total Content Reviewed"
                    className="text-sm"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="denominator" className="text-xs">Denominator Value *</Label>
                  <Input
                    id="denominator"
                    type="number"
                    value={formData.denominator}
                    onChange={(e) => setFormData({ ...formData, denominator: e.target.value })}
                    placeholder="200"
                    className="text-sm"
                  />
                </div>
              </div>
              <div className="text-xs text-muted-foreground pt-2 border-t border-border">
                Calculated: ({formData.numerator || 0} ÷ {formData.denominator || 1}) × 100 = <strong>{formData.denominator ? Math.round((parseFloat(formData.numerator || "0") / parseFloat(formData.denominator || "1")) * 100) : 0}%</strong>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="target">Target Value *</Label>
                <Input
                  id="target"
                  type="number"
                  value={formData.target}
                  onChange={(e) => setFormData({ ...formData, target: e.target.value })}
                  placeholder="95"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="unit">Unit</Label>
                <Select value={formData.unit} onValueChange={(v) => setFormData({ ...formData, unit: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="%">Percentage (%)</SelectItem>
                    <SelectItem value="count">Count</SelectItem>
                    <SelectItem value="days">Days</SelectItem>
                    <SelectItem value="hours">Hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave}>{editingKPI ? "Update" : "Add"} KPI</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
