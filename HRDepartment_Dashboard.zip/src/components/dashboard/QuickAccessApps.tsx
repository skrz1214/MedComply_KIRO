import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import {
  CheckCircle,
  MessageSquare,
  AlertTriangle,
  ClipboardCheck,
  Gavel,
} from "lucide-react";

interface QuickApp {
  id: string;
  title: string;
  description: string;
  href: string;
  icon: React.ElementType;
  color: "teal" | "yellow" | "orange" | "blue" | "red";
}

const quickApps: QuickApp[] = [
  {
    id: "1",
    title: "ComplianceConnect",
    description: "Compliance management hub",
    href: "/apps/compliance-connect",
    icon: CheckCircle,
    color: "teal",
  },
  {
    id: "2",
    title: "FeedbackHub",
    description: "Stakeholder feedback system",
    href: "/apps/feedback-hub",
    icon: MessageSquare,
    color: "yellow",
  },
  {
    id: "3",
    title: "RiskGuard",
    description: "Risk assessment platform",
    href: "/apps/risk-guard",
    icon: AlertTriangle,
    color: "orange",
  },
  {
    id: "4",
    title: "AuditPro",
    description: "Audit management system",
    href: "/apps/audit-pro",
    icon: ClipboardCheck,
    color: "blue",
  },
  {
    id: "5",
    title: "EnforcePoint",
    description: "Enforcement tracking",
    href: "/apps/enforce-point",
    icon: Gavel,
    color: "red",
  },
];

const colorStyles = {
  teal: "bg-primary/10 text-primary",
  yellow: "bg-warning/10 text-warning",
  orange: "bg-warning/15 text-warning",
  blue: "bg-info/10 text-info",
  red: "bg-destructive/10 text-destructive",
};

export function QuickAccessApps() {
  return (
    <div>
      <h3 className="font-display font-semibold mb-4">Quick Access</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        {quickApps.map((app) => {
          const Icon = app.icon;
          return (
            <Link
              key={app.id}
              to={app.href}
              className="bg-card rounded-xl border border-border p-4 hover:border-primary/30 hover:bg-muted/50 transition-all group"
            >
              <div
                className={cn(
                  "h-10 w-10 rounded-lg flex items-center justify-center mb-3",
                  colorStyles[app.color]
                )}
              >
                <Icon className="h-5 w-5" />
              </div>
              <h4 className="font-medium text-sm group-hover:text-primary transition-colors">
                {app.title}
              </h4>
              <p className="text-xs text-muted-foreground mt-1 line-clamp-1">
                {app.description}
              </p>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
