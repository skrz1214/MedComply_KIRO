import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export interface TrainingRecord {
  id: string;
  employeeName: string;
  trainingType: string;
  status: "completed" | "pending" | "overdue";
  completionDate: string;
}

interface TrainingFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: "add" | "edit";
  training?: TrainingRecord | null;
  onSave: (training: TrainingRecord) => void;
}

const trainingTypes = [
  "HIPAA Privacy",
  "Workplace Safety",
  "Harassment Prevention",
  "Infection Control",
  "Emergency Procedures",
  "OSHA Compliance",
  "Fire Safety",
  "CPR/First Aid",
  "Patient Rights",
  "Data Security",
];

export const TrainingFormDialog = ({
  open,
  onOpenChange,
  mode,
  training,
  onSave,
}: TrainingFormDialogProps) => {
  const [formData, setFormData] = useState<Omit<TrainingRecord, "id">>({
    employeeName: "",
    trainingType: "",
    status: "pending",
    completionDate: "",
  });
  const [date, setDate] = useState<Date | undefined>();

  useEffect(() => {
    if (training && mode === "edit") {
      setFormData({
        employeeName: training.employeeName,
        trainingType: training.trainingType,
        status: training.status,
        completionDate: training.completionDate,
      });
      // Parse existing date
      const parsedDate = new Date(training.completionDate);
      if (!isNaN(parsedDate.getTime())) {
        setDate(parsedDate);
      }
    } else {
      setFormData({
        employeeName: "",
        trainingType: "",
        status: "pending",
        completionDate: "",
      });
      setDate(undefined);
    }
  }, [training, mode, open]);

  const handleDateSelect = (selectedDate: Date | undefined) => {
    setDate(selectedDate);
    if (selectedDate) {
      const formattedDate = format(selectedDate, "MMM d, yyyy");
      setFormData({ ...formData, completionDate: formattedDate });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.employeeName || !formData.trainingType || !formData.completionDate) {
      toast.error("Please fill in all required fields");
      return;
    }

    const newTraining: TrainingRecord = {
      id: training?.id || `TR-${Date.now()}`,
      ...formData,
    };

    onSave(newTraining);
    onOpenChange(false);
    toast.success(`Training record ${mode === "add" ? "created" : "updated"} successfully`);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>
            {mode === "add" ? "Add Training Record" : "Edit Training Record"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="employeeName">Employee Name *</Label>
            <Input
              id="employeeName"
              value={formData.employeeName}
              onChange={(e) => setFormData({ ...formData, employeeName: e.target.value })}
              placeholder="Enter employee name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="trainingType">Training Type *</Label>
            <Select
              value={formData.trainingType}
              onValueChange={(value) => setFormData({ ...formData, trainingType: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select training type" />
              </SelectTrigger>
              <SelectContent>
                {trainingTypes.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Status *</Label>
            <Select
              value={formData.status}
              onValueChange={(value: "completed" | "pending" | "overdue") =>
                setFormData({ ...formData, status: value })
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="overdue">Overdue</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Completion/Due Date *</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !date && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={handleDateSelect}
                  initialFocus
                  className="p-3 pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">
              {mode === "add" ? "Add Training" : "Save Changes"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
