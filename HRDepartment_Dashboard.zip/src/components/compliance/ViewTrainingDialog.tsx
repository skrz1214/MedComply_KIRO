import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { GraduationCap, User, Calendar, BookOpen } from "lucide-react";
import type { TrainingRecord } from "./TrainingFormDialog";

interface ViewTrainingDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  training: TrainingRecord | null;
}

export const ViewTrainingDialog = ({
  open,
  onOpenChange,
  training,
}: ViewTrainingDialogProps) => {
  if (!training) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Training Record Details</DialogTitle>
        </DialogHeader>
        <div className="space-y-6 mt-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-lg bg-info/10 flex items-center justify-center">
              <GraduationCap className="h-6 w-6 text-info" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">{training.trainingType}</h3>
              <p className="text-sm text-muted-foreground">ID: {training.id}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-muted/50">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <User className="h-4 w-4" />
                <span className="text-xs font-medium uppercase">Employee</span>
              </div>
              <p className="font-medium">{training.employeeName}</p>
            </div>

            <div className="p-4 rounded-lg bg-muted/50">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <BookOpen className="h-4 w-4" />
                <span className="text-xs font-medium uppercase">Training Type</span>
              </div>
              <p className="font-medium">{training.trainingType}</p>
            </div>

            <div className="p-4 rounded-lg bg-muted/50">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Calendar className="h-4 w-4" />
                <span className="text-xs font-medium uppercase">
                  {training.status === "completed" ? "Completion Date" : "Due Date"}
                </span>
              </div>
              <p className="font-medium">{training.completionDate}</p>
            </div>

            <div className="p-4 rounded-lg bg-muted/50">
              <div className="text-xs font-medium uppercase text-muted-foreground mb-1">Status</div>
              <StatusBadge status={training.status} />
            </div>
          </div>

          <div className="flex justify-end">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
