import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

export interface EmployeeFile {
  id: string;
  employeeName: string;
  department: string;
  fileType: string;
  lastUpdated: string;
  status: "active" | "pending" | "inactive";
}

interface EmployeeFileFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: "add" | "edit";
  employeeFile?: EmployeeFile | null;
  onSave: (employeeFile: EmployeeFile) => void;
}

const departments = ["Nursing", "IT", "Administration", "Pharmacy", "Lab", "Maintenance", "Finance", "HR"];
const fileTypes = ["Personnel", "Training", "Credentials", "Licenses", "Certifications", "Safety", "Benefits"];

export const EmployeeFileFormDialog = ({
  open,
  onOpenChange,
  mode,
  employeeFile,
  onSave,
}: EmployeeFileFormDialogProps) => {
  const [formData, setFormData] = useState<Omit<EmployeeFile, "id" | "lastUpdated">>({
    employeeName: "",
    department: "",
    fileType: "",
    status: "active",
  });

  useEffect(() => {
    if (employeeFile && mode === "edit") {
      setFormData({
        employeeName: employeeFile.employeeName,
        department: employeeFile.department,
        fileType: employeeFile.fileType,
        status: employeeFile.status,
      });
    } else {
      setFormData({
        employeeName: "",
        department: "",
        fileType: "",
        status: "active",
      });
    }
  }, [employeeFile, mode, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.employeeName || !formData.department || !formData.fileType) {
      toast.error("Please fill in all required fields");
      return;
    }

    const now = new Date();
    const formattedDate = now.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });

    const newEmployeeFile: EmployeeFile = {
      id: employeeFile?.id || `EF-${Date.now()}`,
      ...formData,
      lastUpdated: formattedDate,
    };

    onSave(newEmployeeFile);
    onOpenChange(false);
    toast.success(`Employee file ${mode === "add" ? "created" : "updated"} successfully`);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>
            {mode === "add" ? "Add Employee File Record" : "Edit Employee File Record"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="employeeName">Employee Name *</Label>
            <Input
              id="employeeName"
              value={formData.employeeName}
              onChange={(e) => setFormData({ ...formData, employeeName: e.target.value })}
              placeholder="Enter employee name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="department">Department *</Label>
            <Select
              value={formData.department}
              onValueChange={(value) => setFormData({ ...formData, department: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select department" />
              </SelectTrigger>
              <SelectContent>
                {departments.map((dept) => (
                  <SelectItem key={dept} value={dept}>
                    {dept}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="fileType">File Type *</Label>
            <Select
              value={formData.fileType}
              onValueChange={(value) => setFormData({ ...formData, fileType: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select file type" />
              </SelectTrigger>
              <SelectContent>
                {fileTypes.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Status *</Label>
            <Select
              value={formData.status}
              onValueChange={(value: "active" | "pending" | "inactive") =>
                setFormData({ ...formData, status: value })
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">
              {mode === "add" ? "Add Record" : "Save Changes"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
