import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { FileText, Building, FolderOpen, Calendar } from "lucide-react";
import type { EmployeeFile } from "./EmployeeFileFormDialog";

interface ViewEmployeeFileDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  employeeFile: EmployeeFile | null;
}

export const ViewEmployeeFileDialog = ({
  open,
  onOpenChange,
  employeeFile,
}: ViewEmployeeFileDialogProps) => {
  if (!employeeFile) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Employee File Details</DialogTitle>
        </DialogHeader>
        <div className="space-y-6 mt-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
              <FileText className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">{employeeFile.employeeName}</h3>
              <p className="text-sm text-muted-foreground">ID: {employeeFile.id}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-muted/50">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Building className="h-4 w-4" />
                <span className="text-xs font-medium uppercase">Department</span>
              </div>
              <p className="font-medium">{employeeFile.department}</p>
            </div>

            <div className="p-4 rounded-lg bg-muted/50">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <FolderOpen className="h-4 w-4" />
                <span className="text-xs font-medium uppercase">File Type</span>
              </div>
              <p className="font-medium">{employeeFile.fileType}</p>
            </div>

            <div className="p-4 rounded-lg bg-muted/50">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Calendar className="h-4 w-4" />
                <span className="text-xs font-medium uppercase">Last Updated</span>
              </div>
              <p className="font-medium">{employeeFile.lastUpdated}</p>
            </div>

            <div className="p-4 rounded-lg bg-muted/50">
              <div className="text-xs font-medium uppercase text-muted-foreground mb-1">Status</div>
              <StatusBadge status={employeeFile.status} />
            </div>
          </div>

          <div className="flex justify-end">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
