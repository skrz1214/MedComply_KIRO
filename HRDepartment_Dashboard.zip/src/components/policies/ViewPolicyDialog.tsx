import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { Badge } from "@/components/ui/badge";
import { FileText, Calendar, User, FolderOpen, Paperclip } from "lucide-react";

interface Policy {
  id: string;
  name: string;
  category: string;
  lastUpdate: string;
  status: "active" | "pending" | "inactive";
  nextUpdate: string;
  owner: string;
  description?: string;
  attachments?: string[];
}

interface ViewPolicyDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  policy: Policy | null;
}

export function ViewPolicyDialog({ open, onOpenChange, policy }: ViewPolicyDialogProps) {
  if (!policy) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            {policy.name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Status</span>
            <StatusBadge status={policy.status} />
          </div>

          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground flex items-center gap-2">
              <FolderOpen className="h-4 w-4" />
              Category
            </span>
            <Badge variant="outline">{policy.category}</Badge>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground flex items-center gap-2">
              <User className="h-4 w-4" />
              Owner
            </span>
            <span className="text-sm font-medium">{policy.owner}</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Last Update
            </span>
            <span className="text-sm">{policy.lastUpdate}</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Next Update
            </span>
            <span className="text-sm">{policy.nextUpdate}</span>
          </div>

          {policy.description && (
            <div className="pt-2 border-t">
              <span className="text-sm text-muted-foreground block mb-2">Description</span>
              <p className="text-sm">{policy.description}</p>
            </div>
          )}

          {policy.attachments && policy.attachments.length > 0 && (
            <div className="pt-2 border-t">
              <span className="text-sm text-muted-foreground flex items-center gap-2 mb-2">
                <Paperclip className="h-4 w-4" />
                Attachments
              </span>
              <div className="flex flex-wrap gap-2">
                {policy.attachments.map((file, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {file}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
