import { createContext, useContext, useState, ReactNode } from "react";

export type UserRole = "admin" | "department_head" | "viewer";

export interface RoleUser {
  name: string;
  role: UserRole;
  department?: string;
  title: string;
}

const roleUsers: Record<UserRole, RoleUser> = {
  admin: {
    name: "Jane Doe",
    role: "admin",
    title: "Compliance Head",
  },
  department_head: {
    name: "Michael Chen",
    role: "department_head",
    department: "Compliance",
    title: "Department Manager",
  },
  viewer: {
    name: "Sarah Johnson",
    role: "viewer",
    department: "Compliance",
    title: "View Only User",
  },
};

interface RoleContextType {
  currentRole: UserRole;
  currentUser: RoleUser;
  setRole: (role: UserRole) => void;
  canEdit: boolean;
  canManage: boolean;
  canConfigure: boolean;
  isImpersonating: boolean;
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export function RoleProvider({ children }: { children: ReactNode }) {
  const [currentRole, setCurrentRole] = useState<UserRole>("admin");
  const [originalRole] = useState<UserRole>("admin"); // The "real" role

  const currentUser = roleUsers[currentRole];

  const canEdit = currentRole === "admin" || currentRole === "department_head";
  const canManage = currentRole === "admin" || currentRole === "department_head";
  const canConfigure = currentRole === "admin";
  const isImpersonating = currentRole !== originalRole;

  const setRole = (role: UserRole) => {
    setCurrentRole(role);
  };

  return (
    <RoleContext.Provider
      value={{
        currentRole,
        currentUser,
        setRole,
        canEdit,
        canManage,
        canConfigure,
        isImpersonating,
      }}
    >
      {children}
    </RoleContext.Provider>
  );
}

export function useRole() {
  const context = useContext(RoleContext);
  if (context === undefined) {
    throw new Error("useRole must be used within a RoleProvider");
  }
  return context;
}
