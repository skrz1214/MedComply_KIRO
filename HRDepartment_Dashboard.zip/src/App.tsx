import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { RoleProvider } from "@/contexts/RoleContext";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import OrgChartPage from "./pages/OrgChartPage";
import PoliciesPage from "./pages/PoliciesPage";
import PolicyViewPage from "./pages/PolicyViewPage";
import PolicyEditPage from "./pages/PolicyEditPage";
import AuditsPage from "./pages/AuditsPage";
import AuditViewPage from "./pages/AuditViewPage";
import AuditEditPage from "./pages/AuditEditPage";
import EnforcementsPage from "./pages/EnforcementsPage";
import RisksPage from "./pages/RisksPage";
import CompliancePage from "./pages/CompliancePage";
import TrainingPage from "./pages/TrainingPage";
import KPIsPage from "./pages/KPIsPage";
import EmployeeFilesPage from "./pages/EmployeeFilesPage";
import CorrectionsPage from "./pages/CorrectionsPage";
import MicroAppPage from "./pages/MicroAppPage";
import DocumentationPage from "./pages/DocumentationPage";
import FeedbackManagementPage from "./pages/FeedbackManagementPage";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <RoleProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/org-chart" element={<OrgChartPage />} />
            <Route path="/policies" element={<PoliciesPage />} />
            <Route path="/policies/:policyId" element={<PolicyViewPage />} />
            <Route path="/policies/:policyId/edit" element={<PolicyEditPage />} />
            <Route path="/audits" element={<AuditsPage />} />
            <Route path="/audits/:auditId" element={<AuditViewPage />} />
            <Route path="/audits/:auditId/edit" element={<AuditEditPage />} />
            <Route path="/enforcements" element={<EnforcementsPage />} />
            <Route path="/risks" element={<RisksPage />} />
            <Route path="/compliance" element={<CompliancePage />} />
            <Route path="/training" element={<TrainingPage />} />
            <Route path="/kpis" element={<KPIsPage />} />
            <Route path="/employee-files" element={<EmployeeFilesPage />} />
            <Route path="/corrections" element={<CorrectionsPage />} />
            <Route path="/apps/:appId" element={<MicroAppPage />} />
            <Route path="/feedback" element={<FeedbackManagementPage />} />
            <Route path="/documentation" element={<DocumentationPage />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </RoleProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
