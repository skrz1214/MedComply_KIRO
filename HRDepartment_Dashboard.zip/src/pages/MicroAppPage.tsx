import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useParams } from "react-router-dom";
import { 
  CheckCircle, 
  MessageSquare, 
  AlertTriangle, 
  ClipboardCheck, 
  Gavel, 
  Calendar,
  ArrowRight,
  BarChart3,
  Users,
  FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const microApps: Record<string, {
  title: string;
  description: string;
  icon: React.ElementType;
  color: string;
  features: string[];
  stats: { label: string; value: string }[];
}> = {
  "compliance-connect": {
    title: "ComplianceConnect",
    description: "Centralized compliance management platform for tracking, reporting, and ensuring organizational adherence to regulatory requirements.",
    icon: CheckCircle,
    color: "text-primary",
    features: [
      "Regulatory requirement tracking",
      "Compliance status dashboard",
      "Automated compliance reporting",
      "Document management",
      "Audit trail logging",
    ],
    stats: [
      { label: "Active Requirements", value: "156" },
      { label: "Compliance Rate", value: "96%" },
      { label: "Pending Reviews", value: "12" },
    ],
  },
  "feedback-hub": {
    title: "FeedbackHub",
    description: "Employee feedback collection and analysis platform for improving workplace satisfaction and addressing concerns.",
    icon: MessageSquare,
    color: "text-info",
    features: [
      "Anonymous feedback submission",
      "Survey management",
      "Sentiment analysis",
      "Response tracking",
      "Trend reporting",
    ],
    stats: [
      { label: "Total Feedback", value: "2,847" },
      { label: "Response Rate", value: "78%" },
      { label: "Avg. Satisfaction", value: "4.2/5" },
    ],
  },
  "risk-guard": {
    title: "RiskGuard",
    description: "Comprehensive risk assessment and mitigation platform for identifying, evaluating, and managing organizational risks.",
    icon: AlertTriangle,
    color: "text-warning",
    features: [
      "Risk identification & assessment",
      "Mitigation strategy planning",
      "Risk scoring & prioritization",
      "Control monitoring",
      "Risk trend analysis",
    ],
    stats: [
      { label: "Active Risks", value: "34" },
      { label: "Mitigated This Month", value: "8" },
      { label: "High Priority", value: "5" },
    ],
  },
  "audit-pro": {
    title: "AuditPro",
    description: "End-to-end audit management solution for scheduling, conducting, and tracking internal and external audits.",
    icon: ClipboardCheck,
    color: "text-success",
    features: [
      "Audit scheduling & planning",
      "Checklist management",
      "Finding documentation",
      "Corrective action tracking",
      "Audit report generation",
    ],
    stats: [
      { label: "Total Audits", value: "45" },
      { label: "Completed", value: "32" },
      { label: "Pending", value: "8" },
    ],
  },
  "enforce-point": {
    title: "EnforcePoint",
    description: "Policy enforcement and tracking system for managing compliance violations and corrective actions.",
    icon: Gavel,
    color: "text-destructive",
    features: [
      "Violation tracking",
      "Enforcement action management",
      "Escalation workflows",
      "Resolution documentation",
      "Enforcement analytics",
    ],
    stats: [
      { label: "Total Enforcements", value: "28" },
      { label: "Resolved", value: "20" },
      { label: "Pending", value: "5" },
    ],
  },
  "cita-pro": {
    title: "CitaPro",
    description: "Citation and violation management system for tracking regulatory citations and managing remediation efforts.",
    icon: Calendar,
    color: "text-accent-foreground",
    features: [
      "Citation logging & tracking",
      "Violation categorization",
      "Remediation planning",
      "Due date management",
      "Regulatory communication",
    ],
    stats: [
      { label: "Total Citations", value: "12" },
      { label: "Remediated", value: "9" },
      { label: "In Progress", value: "3" },
    ],
  },
};

const MicroAppPage = () => {
  const { appId } = useParams<{ appId: string }>();
  const app = appId ? microApps[appId] : null;

  if (!app) {
    return (
      <DashboardLayout>
        <div className="text-center py-12">
          <h1 className="text-2xl font-bold mb-4">Application Not Found</h1>
          <p className="text-muted-foreground mb-6">The requested micro application could not be found.</p>
          <Button asChild>
            <Link to="/">Return to Dashboard</Link>
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  const Icon = app.icon;

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="flex items-start gap-4 mb-8">
        <div className={`p-4 rounded-xl bg-card border border-border ${app.color}`}>
          <Icon className="h-8 w-8" />
        </div>
        <div className="flex-1">
          <h1 className="font-display text-3xl font-bold">{app.title}</h1>
          <p className="text-muted-foreground mt-1 max-w-2xl">{app.description}</p>
        </div>
        <Button>
          Open Application
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        {app.stats.map((stat) => (
          <div key={stat.label} className="p-5 rounded-lg bg-card border border-border">
            <p className="text-sm text-muted-foreground">{stat.label}</p>
            <p className="text-3xl font-bold mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Features */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card rounded-lg border border-border p-6">
          <h2 className="font-display font-semibold text-lg mb-4">Key Features</h2>
          <ul className="space-y-3">
            {app.features.map((feature, i) => (
              <li key={i} className="flex items-center gap-3">
                <CheckCircle className="h-4 w-4 text-success shrink-0" />
                <span className="text-muted-foreground">{feature}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-card rounded-lg border border-border p-6">
          <h2 className="font-display font-semibold text-lg mb-4">Quick Actions</h2>
          <div className="space-y-3">
            <Button variant="outline" className="w-full justify-start">
              <BarChart3 className="h-4 w-4 mr-2" />
              View Analytics Dashboard
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <FileText className="h-4 w-4 mr-2" />
              Generate Report
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Users className="h-4 w-4 mr-2" />
              Manage Access
            </Button>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default MicroAppPage;
