import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { SectionHeader } from "@/components/dashboard/SectionHeader";
import { DataTable, Column } from "@/components/dashboard/DataTable";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { Input } from "@/components/ui/input";
import { FolderOpen, Search, FileText, Shield, GraduationCap, Heart } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";

interface EmployeeFile {
  id: string;
  employeeName: string;
  department: string;
  fileType: string;
  lastUpdated: string;
  status: "active" | "pending" | "inactive";
}

const employeeFiles: EmployeeFile[] = [
  { id: "1", employeeName: "Sarah Johnson", department: "Nursing", fileType: "Personnel", lastUpdated: "Dec 10, 2024", status: "active" },
  { id: "2", employeeName: "Mike Chen", department: "IT", fileType: "Training", lastUpdated: "Dec 8, 2024", status: "active" },
  { id: "3", employeeName: "Emily Davis", department: "Administration", fileType: "Credentials", lastUpdated: "Dec 5, 2024", status: "pending" },
  { id: "4", employeeName: "John Smith", department: "Pharmacy", fileType: "Licenses", lastUpdated: "Dec 3, 2024", status: "active" },
  { id: "5", employeeName: "Lisa Wang", department: "Lab", fileType: "Certifications", lastUpdated: "Nov 28, 2024", status: "active" },
  { id: "6", employeeName: "Robert Brown", department: "Maintenance", fileType: "Safety", lastUpdated: "Nov 25, 2024", status: "inactive" },
];

const columns: Column<EmployeeFile>[] = [
  { key: "employeeName", header: "Employee Name" },
  { key: "department", header: "Department" },
  { key: "fileType", header: "File Type" },
  { key: "lastUpdated", header: "Last Updated" },
  { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
  { key: "actions", header: "Actions" },
];

const fileCategories = [
  { label: "Personnel Records", count: 1248, icon: FileText, color: "text-primary bg-primary/10" },
  { label: "Training Records", count: 856, icon: GraduationCap, color: "text-info bg-info/10" },
  { label: "Credentials & Licenses", count: 432, icon: Shield, color: "text-warning bg-warning/10" },
  { label: "Benefits & Insurance", count: 1248, icon: Heart, color: "text-success bg-success/10" },
];

const EmployeeFilesPage = () => {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredData = employeeFiles.filter(
    (file) =>
      file.employeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      file.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <DashboardLayout>
      <SectionHeader
        title="Employee Files"
        description="Manage employee records and documents with role-based access control"
        actionLabel="Add Record"
        onAction={() => toast.info("Opening employee record form...")}
      />

      {/* File Categories */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {fileCategories.map((cat) => (
          <button
            key={cat.label}
            onClick={() => toast.info(`Viewing ${cat.label}...`)}
            className="p-5 rounded-lg bg-card border border-border hover:border-primary/30 hover:shadow-md transition-all text-left group"
          >
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${cat.color}`}>
              <cat.icon className="h-5 w-5" />
            </div>
            <p className="font-semibold group-hover:text-primary transition-colors">{cat.label}</p>
            <p className="text-2xl font-bold mt-1">{cat.count.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground">records</p>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative max-w-sm mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search employees..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-9"
        />
      </div>

      <DataTable
        columns={columns}
        data={filteredData}
        onView={(item) => toast.info(`Viewing files for: ${item.employeeName}`)}
        onEdit={(item) => toast.info(`Editing files for: ${item.employeeName}`)}
        onDelete={(item) => toast.error(`Deleted files for: ${item.employeeName}`)}
      />
    </DashboardLayout>
  );
};

export default EmployeeFilesPage;
