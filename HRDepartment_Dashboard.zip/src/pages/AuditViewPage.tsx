import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { Badge } from "@/components/ui/badge";
import { useNavigate, useParams } from "react-router-dom";
import { useState } from "react";
import { toast } from "sonner";
import { 
  ArrowLeft, 
  ClipboardCheck, 
  Calendar, 
  User, 
  Flag,
  Edit,
  Trash2,
  FileText
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface AuditItem {
  id: string;
  title: string;
  status: "pending" | "completed" | "overdue";
  deadline: string;
  owner: string;
  priority: "high" | "medium" | "low";
  description?: string;
  notes?: string;
}

const auditsData: AuditItem[] = [
  { id: "AUD-001", title: "Annual HIPAA Compliance Review", status: "pending", deadline: "Dec 20, 2024", owner: "Sarah Johnson", priority: "high", description: "Comprehensive annual review of HIPAA compliance across all departments, including privacy practices, security measures, and employee training verification." },
  { id: "AUD-002", title: "Workplace Safety Inspection", status: "completed", deadline: "Dec 15, 2024", owner: "Mike Chen", priority: "medium", description: "Routine inspection of workplace safety protocols, emergency exits, fire extinguishers, and first aid stations." },
  { id: "AUD-003", title: "Employee Records Audit", status: "overdue", deadline: "Dec 10, 2024", owner: "Emily Davis", priority: "high", description: "Audit of all employee records for completeness, accuracy, and compliance with retention policies." },
  { id: "AUD-004", title: "Training Compliance Check", status: "pending", deadline: "Dec 28, 2024", owner: "John Smith", priority: "medium", description: "Verification that all required training has been completed by staff within mandated timeframes." },
  { id: "AUD-005", title: "IT Security Assessment", status: "completed", deadline: "Dec 12, 2024", owner: "Lisa Wang", priority: "high", description: "Assessment of IT infrastructure security, including access controls, data encryption, and vulnerability scanning." },
  { id: "AUD-006", title: "Background Check Verification", status: "pending", deadline: "Jan 5, 2025", owner: "Robert Brown", priority: "low", description: "Verification that all new hires have completed required background checks." },
];

const AuditViewPage = () => {
  const { auditId } = useParams();
  const navigate = useNavigate();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  
  const audit = auditsData.find(a => a.id === auditId);

  if (!audit) {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center py-12">
          <ClipboardCheck className="h-12 w-12 text-muted-foreground mb-4" />
          <h2 className="text-xl font-semibold mb-2">Audit Not Found</h2>
          <p className="text-muted-foreground mb-4">The audit you're looking for doesn't exist.</p>
          <Button onClick={() => navigate("/audits")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Audits
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  const handleDelete = () => {
    toast.success(`Audit "${audit.id}" deleted successfully`);
    navigate("/audits");
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "text-destructive";
      case "medium": return "text-warning";
      case "low": return "text-muted-foreground";
      default: return "";
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/audits")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold">{audit.title}</h1>
                <Badge variant="outline" className="font-mono">{audit.id}</Badge>
              </div>
              <p className="text-muted-foreground">Audit Details</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => navigate(`/audits/${audit.id}/edit`)}>
              <Edit className="h-4 w-4 mr-2" />
              Edit
            </Button>
            <Button variant="destructive" onClick={() => setDeleteDialogOpen(true)}>
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="grid gap-6 md:grid-cols-2">
          {/* Main Info Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ClipboardCheck className="h-5 w-5 text-primary" />
                Audit Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2 border-b">
                <span className="text-muted-foreground">Status</span>
                <StatusBadge status={audit.status} />
              </div>
              <div className="flex items-center justify-between py-2 border-b">
                <span className="text-muted-foreground flex items-center gap-2">
                  <Flag className="h-4 w-4" />
                  Priority
                </span>
                <span className={`font-medium capitalize ${getPriorityColor(audit.priority)}`}>
                  {audit.priority}
                </span>
              </div>
              <div className="flex items-center justify-between py-2 border-b">
                <span className="text-muted-foreground flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Owner
                </span>
                <span className="font-medium">{audit.owner}</span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-muted-foreground flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Deadline
                </span>
                <span>{audit.deadline}</span>
              </div>
            </CardContent>
          </Card>

          {/* Description Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Description
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                {audit.description || "No description provided."}
              </p>

              {audit.notes && (
                <div className="pt-4 mt-4 border-t">
                  <h4 className="text-sm font-medium mb-2">Notes</h4>
                  <p className="text-sm text-muted-foreground">{audit.notes}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Audit</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{audit.title}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
};

export default AuditViewPage;
