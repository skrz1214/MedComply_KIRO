import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { SectionHeader } from "@/components/dashboard/SectionHeader";
import { DataTable, Column } from "@/components/dashboard/DataTable";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { GraduationCap, CheckCircle, Clock, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { Progress } from "@/components/ui/progress";

interface TrainingRecord {
  id: string;
  employeeName: string;
  trainingType: string;
  status: "completed" | "pending" | "overdue";
  completionDate: string;
}

const trainingData: TrainingRecord[] = [
  { id: "1", employeeName: "Sarah Johnson", trainingType: "HIPAA Privacy", status: "completed", completionDate: "Nov 28, 2024" },
  { id: "2", employeeName: "Mike Chen", trainingType: "Workplace Safety", status: "completed", completionDate: "Nov 25, 2024" },
  { id: "3", employeeName: "Emily Davis", trainingType: "Harassment Prevention", status: "pending", completionDate: "Dec 20, 2024" },
  { id: "4", employeeName: "John Smith", trainingType: "Infection Control", status: "overdue", completionDate: "Dec 1, 2024" },
  { id: "5", employeeName: "Lisa Wang", trainingType: "Emergency Procedures", status: "completed", completionDate: "Nov 20, 2024" },
  { id: "6", employeeName: "Robert Brown", trainingType: "OSHA Compliance", status: "pending", completionDate: "Dec 28, 2024" },
  { id: "7", employeeName: "Jennifer Lee", trainingType: "Patient Rights", status: "completed", completionDate: "Nov 15, 2024" },
  { id: "8", employeeName: "David Wilson", trainingType: "Fire Safety", status: "pending", completionDate: "Jan 5, 2025" },
];

const columns: Column<TrainingRecord>[] = [
  { key: "employeeName", header: "Employee Name" },
  { key: "trainingType", header: "Training Type" },
  { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
  { key: "completionDate", header: "Completion Date" },
  { key: "actions", header: "Actions" },
];

const TrainingPage = () => {
  const completionRate = 94;

  return (
    <DashboardLayout>
      <SectionHeader
        title="Training Statistics"
        description="Monitor and manage employee training compliance"
        actionLabel="Add Training"
        onAction={() => toast.info("Opening training record form...")}
      />

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <MetricCard title="Total Training Records" value={1248} icon={GraduationCap} variant="primary" />
        <MetricCard title="Completed" value={1173} icon={CheckCircle} variant="success" />
        <MetricCard title="Pending" value={52} icon={Clock} variant="warning" />
        <MetricCard title="Overdue" value={23} icon={AlertTriangle} variant="danger" />
      </div>

      {/* Completion Rate */}
      <div className="bg-card rounded-lg border border-border p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display font-semibold">Overall Training Completion Rate</h3>
          <span className="text-2xl font-bold text-primary">{completionRate}%</span>
        </div>
        <Progress value={completionRate} className="h-3" />
        <div className="flex justify-between mt-3 text-sm text-muted-foreground">
          <span>Target: 95%</span>
          <span>1,173 of 1,248 employees</span>
        </div>
      </div>

      {/* Training Type Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
        {[
          { type: "HIPAA", completed: 98 },
          { type: "Safety", completed: 95 },
          { type: "Harassment", completed: 92 },
          { type: "Infection Control", completed: 88 },
          { type: "Emergency", completed: 96 },
          { type: "OSHA", completed: 91 },
        ].map((item) => (
          <div key={item.type} className="p-4 rounded-lg bg-card border border-border text-center">
            <p className="text-sm text-muted-foreground">{item.type}</p>
            <p className="text-2xl font-bold mt-1" style={{ color: item.completed >= 95 ? "hsl(var(--success))" : item.completed >= 90 ? "hsl(var(--warning))" : "hsl(var(--destructive))" }}>
              {item.completed}%
            </p>
          </div>
        ))}
      </div>

      <DataTable
        columns={columns}
        data={trainingData}
        onView={(item) => toast.info(`Viewing training record: ${item.employeeName}`)}
        onEdit={(item) => toast.info(`Editing training: ${item.trainingType}`)}
        onDelete={(item) => toast.error(`Deleted training record: ${item.id}`)}
      />
    </DashboardLayout>
  );
};

export default TrainingPage;
