import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { SectionHeader } from "@/components/dashboard/SectionHeader";
import { DataTable, Column } from "@/components/dashboard/DataTable";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { BarChart3 } from "lucide-react";
import { toast } from "sonner";

interface KPI {
  id: string;
  name: string;
  owner: string;
  metricType: string;
  status: "active" | "pending" | "inactive";
  frequency: string;
}

const kpiData: KPI[] = [
  { id: "1", name: "Employee Turnover Rate", owner: "HR Director", metricType: "Percentage", status: "active", frequency: "Monthly" },
  { id: "2", name: "Training Completion Rate", owner: "Training Manager", metricType: "Percentage", status: "active", frequency: "Weekly" },
  { id: "3", name: "Time to Fill Positions", owner: "Recruiting Lead", metricType: "Days", status: "active", frequency: "Monthly" },
  { id: "4", name: "Employee Satisfaction Score", owner: "HR Director", metricType: "Score (1-10)", status: "active", frequency: "Quarterly" },
  { id: "5", name: "Compliance Audit Score", owner: "Compliance Officer", metricType: "Percentage", status: "active", frequency: "Quarterly" },
  { id: "6", name: "Safety Incident Rate", owner: "Safety Officer", metricType: "Count", status: "active", frequency: "Monthly" },
  { id: "7", name: "Absenteeism Rate", owner: "HR Operations", metricType: "Percentage", status: "pending", frequency: "Weekly" },
  { id: "8", name: "Credentialing Turnaround", owner: "Credentialing Dept", metricType: "Days", status: "active", frequency: "Monthly" },
];

const columns: Column<KPI>[] = [
  { key: "name", header: "KPI Name" },
  { key: "owner", header: "Owner" },
  { key: "metricType", header: "Metric Type" },
  { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
  { key: "frequency", header: "Frequency" },
  { key: "actions", header: "Actions" },
];

const KPIsPage = () => {
  return (
    <DashboardLayout>
      <SectionHeader
        title="Quality Management KPIs"
        description="Define and track key performance indicators for HR quality management"
        actionLabel="Add KPI"
        onAction={() => toast.info("Opening KPI definition form...")}
      />

      {/* Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { label: "Active KPIs", value: "14", color: "text-primary" },
          { label: "Meeting Target", value: "11", color: "text-success" },
          { label: "Below Target", value: "2", color: "text-warning" },
          { label: "Critical", value: "1", color: "text-destructive" },
        ].map((stat) => (
          <div key={stat.label} className="p-5 rounded-lg bg-card border border-border">
            <div className="flex items-center gap-3">
              <BarChart3 className={`h-8 w-8 ${stat.color}`} />
              <div>
                <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <DataTable
        columns={columns}
        data={kpiData}
        onView={(item) => toast.info(`Viewing KPI: ${item.name}`)}
        onEdit={(item) => toast.info(`Editing KPI: ${item.name}`)}
        onDelete={(item) => toast.error(`Deleted KPI: ${item.name}`)}
      />
    </DashboardLayout>
  );
};

export default KPIsPage;
