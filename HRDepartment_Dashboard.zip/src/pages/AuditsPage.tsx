import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { SectionHeader } from "@/components/dashboard/SectionHeader";
import { DataTable, Column } from "@/components/dashboard/DataTable";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { UpcomingDeadlines } from "@/components/dashboard/UpcomingDeadlines";
import { ClipboardCheck, Clock, CheckCircle, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface AuditItem {
  id: string;
  title: string;
  status: "pending" | "completed" | "overdue";
  deadline: string;
  owner: string;
  priority: "high" | "medium" | "low";
}

const initialAuditData: AuditItem[] = [
  { id: "AUD-001", title: "Annual HIPAA Compliance Review", status: "pending", deadline: "Dec 20, 2024", owner: "Sarah Johnson", priority: "high" },
  { id: "AUD-002", title: "Workplace Safety Inspection", status: "completed", deadline: "Dec 15, 2024", owner: "Mike Chen", priority: "medium" },
  { id: "AUD-003", title: "Employee Records Audit", status: "overdue", deadline: "Dec 10, 2024", owner: "Emily Davis", priority: "high" },
  { id: "AUD-004", title: "Training Compliance Check", status: "pending", deadline: "Dec 28, 2024", owner: "John Smith", priority: "medium" },
  { id: "AUD-005", title: "IT Security Assessment", status: "completed", deadline: "Dec 12, 2024", owner: "Lisa Wang", priority: "high" },
  { id: "AUD-006", title: "Background Check Verification", status: "pending", deadline: "Jan 5, 2025", owner: "Robert Brown", priority: "low" },
];

const deadlines = [
  { id: "1", title: "Annual HIPAA Compliance Review", dueDate: "Dec 20, 2024", type: "Audit", priority: "high" as const },
  { id: "2", title: "Training Compliance Check", dueDate: "Dec 28, 2024", type: "Audit", priority: "medium" as const },
  { id: "3", title: "Background Check Verification", dueDate: "Jan 5, 2025", type: "Audit", priority: "low" as const },
];

const columns: Column<AuditItem>[] = [
  { key: "id", header: "Audit ID", className: "font-mono text-sm" },
  { key: "title", header: "Title" },
  { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
  { key: "deadline", header: "Deadline" },
  { key: "owner", header: "Owner" },
  { key: "priority", header: "Priority", render: (item) => <StatusBadge status={item.priority} /> },
  { key: "actions", header: "Actions" },
];

const AuditsPage = () => {
  const navigate = useNavigate();
  const [audits, setAudits] = useState<AuditItem[]>(initialAuditData);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedAudit, setSelectedAudit] = useState<AuditItem | null>(null);

  const handleAdd = () => {
    navigate("/apps/auditpro");
  };

  const handleView = (item: AuditItem) => {
    navigate(`/audits/${item.id}`);
  };

  const handleEdit = (item: AuditItem) => {
    navigate(`/audits/${item.id}/edit`);
  };

  const handleDelete = (item: AuditItem) => {
    setSelectedAudit(item);
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = () => {
    if (selectedAudit) {
      setAudits(audits.filter(a => a.id !== selectedAudit.id));
      toast.success(`Audit "${selectedAudit.id}" deleted successfully`);
      setDeleteDialogOpen(false);
      setSelectedAudit(null);
    }
  };

  return (
    <DashboardLayout>
      <SectionHeader
        title="Audit Items"
        description="Manage and track all audit activities integrated with AuditPro"
        actionLabel="Add Audit"
        onAction={handleAdd}
      />

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <MetricCard title="Total Audits" value={45} icon={ClipboardCheck} variant="primary" />
        <MetricCard title="Pending Review" value={15} icon={Clock} variant="warning" />
        <MetricCard title="Completed" value={25} icon={CheckCircle} variant="success" />
        <MetricCard title="Overdue" value={5} icon={AlertTriangle} variant="danger" />
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <DataTable
            columns={columns}
            data={audits}
            onView={handleView}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        </div>
        <div>
          <UpcomingDeadlines deadlines={deadlines} />
        </div>
      </div>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Audit</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{selectedAudit?.title}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
};

export default AuditsPage;
