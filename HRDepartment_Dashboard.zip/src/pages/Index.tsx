import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useRole } from "@/contexts/RoleContext";
import { AdminDashboard } from "@/components/dashboard/AdminDashboard";
import { DepartmentHeadDashboard } from "@/components/dashboard/DepartmentHeadDashboard";
import { ViewerDashboard } from "@/components/dashboard/ViewerDashboard";

const Index = () => {
  const { currentRole } = useRole();

  const renderDashboard = () => {
    switch (currentRole) {
      case "admin":
        return <AdminDashboard />;
      case "department_head":
        return <DepartmentHeadDashboard />;
      case "viewer":
        return <ViewerDashboard />;
      default:
        return <AdminDashboard />;
    }
  };

  return (
    <DashboardLayout>
      {renderDashboard()}
    </DashboardLayout>
  );
};

export default Index;
