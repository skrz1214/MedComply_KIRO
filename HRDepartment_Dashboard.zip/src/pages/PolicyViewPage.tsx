import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { Badge } from "@/components/ui/badge";
import { DeletePolicyDialog } from "@/components/policies/DeletePolicyDialog";
import { useNavigate, useParams } from "react-router-dom";
import { useState } from "react";
import { toast } from "sonner";
import { 
  ArrowLeft, 
  FileText, 
  Calendar, 
  User, 
  FolderOpen, 
  Paperclip,
  Edit,
  Trash2
} from "lucide-react";

interface Policy {
  id: string;
  name: string;
  category: string;
  lastUpdate: string;
  status: "active" | "pending" | "inactive";
  nextUpdate: string;
  owner: string;
  description?: string;
  attachments?: string[];
}

// Mock data - in real app this would come from API/database
const policiesData: Policy[] = [
  { id: "1", name: "Employee Handbook", category: "General", lastUpdate: "Nov 15, 2024", status: "active", nextUpdate: "Nov 15, 2025", owner: "HR Director", description: "Comprehensive guide covering company policies, procedures, and employee expectations.", attachments: ["handbook_v3.pdf", "appendix_a.docx"] },
  { id: "2", name: "HIPAA Privacy Policy", category: "Compliance", lastUpdate: "Oct 20, 2024", status: "active", nextUpdate: "Oct 20, 2025", owner: "Compliance Officer", description: "Outlines the organization's commitment to protecting patient health information in accordance with HIPAA regulations." },
  { id: "3", name: "Remote Work Policy", category: "Operations", lastUpdate: "Sep 10, 2024", status: "pending", nextUpdate: "Dec 31, 2024", owner: "Operations Manager", description: "Guidelines for employees working remotely, including equipment, communication, and security requirements." },
  { id: "4", name: "Code of Conduct", category: "Ethics", lastUpdate: "Aug 5, 2024", status: "active", nextUpdate: "Aug 5, 2025", owner: "Legal Counsel", description: "Standards of professional behavior and ethical guidelines for all employees." },
  { id: "5", name: "Anti-Harassment Policy", category: "HR", lastUpdate: "Jul 22, 2024", status: "active", nextUpdate: "Jul 22, 2025", owner: "HR Director", description: "Zero-tolerance policy on workplace harassment with reporting procedures and consequences." },
  { id: "6", name: "Data Security Policy", category: "IT", lastUpdate: "Jun 18, 2024", status: "pending", nextUpdate: "Jan 15, 2025", owner: "IT Director", description: "Protocols for data protection, access controls, and incident response procedures.", attachments: ["security_checklist.pdf"] },
  { id: "7", name: "Expense Reimbursement", category: "Finance", lastUpdate: "May 12, 2024", status: "inactive", nextUpdate: "TBD", owner: "Finance Manager", description: "Procedures for submitting and processing expense reimbursement requests." },
];

const PolicyViewPage = () => {
  const { policyId } = useParams();
  const navigate = useNavigate();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  
  const policy = policiesData.find(p => p.id === policyId);

  if (!policy) {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center py-12">
          <FileText className="h-12 w-12 text-muted-foreground mb-4" />
          <h2 className="text-xl font-semibold mb-2">Policy Not Found</h2>
          <p className="text-muted-foreground mb-4">The policy you're looking for doesn't exist.</p>
          <Button onClick={() => navigate("/policies")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Policies
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  const handleDelete = () => {
    toast.success(`Policy "${policy.name}" deleted successfully`);
    navigate("/policies");
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/policies")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">{policy.name}</h1>
              <p className="text-muted-foreground">Policy Details</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => navigate(`/policies/${policy.id}/edit`)}>
              <Edit className="h-4 w-4 mr-2" />
              Edit
            </Button>
            <Button variant="destructive" onClick={() => setDeleteDialogOpen(true)}>
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="grid gap-6 md:grid-cols-2">
          {/* Main Info Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Policy Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2 border-b">
                <span className="text-muted-foreground">Status</span>
                <StatusBadge status={policy.status} />
              </div>
              <div className="flex items-center justify-between py-2 border-b">
                <span className="text-muted-foreground flex items-center gap-2">
                  <FolderOpen className="h-4 w-4" />
                  Category
                </span>
                <Badge variant="outline">{policy.category}</Badge>
              </div>
              <div className="flex items-center justify-between py-2 border-b">
                <span className="text-muted-foreground flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Owner
                </span>
                <span className="font-medium">{policy.owner}</span>
              </div>
              <div className="flex items-center justify-between py-2 border-b">
                <span className="text-muted-foreground flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Last Update
                </span>
                <span>{policy.lastUpdate}</span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-muted-foreground flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Next Update
                </span>
                <span>{policy.nextUpdate}</span>
              </div>
            </CardContent>
          </Card>

          {/* Description & Attachments Card */}
          <Card>
            <CardHeader>
              <CardTitle>Description</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-muted-foreground">
                {policy.description || "No description provided."}
              </p>

              {policy.attachments && policy.attachments.length > 0 && (
                <div className="pt-4 border-t">
                  <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
                    <Paperclip className="h-4 w-4" />
                    Attachments ({policy.attachments.length})
                  </h4>
                  <div className="space-y-2">
                    {policy.attachments.map((file, index) => (
                      <div 
                        key={index} 
                        className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors cursor-pointer"
                      >
                        <FileText className="h-4 w-4 text-primary" />
                        <span className="text-sm">{file}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <DeletePolicyDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        policy={policy}
        onConfirm={handleDelete}
      />
    </DashboardLayout>
  );
};

export default PolicyViewPage;
