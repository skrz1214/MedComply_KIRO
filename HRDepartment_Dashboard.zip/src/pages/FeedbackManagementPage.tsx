import { useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { DataTable, Column } from "@/components/dashboard/DataTable";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { UpcomingDeadlines } from "@/components/dashboard/UpcomingDeadlines";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  MessageSquare, Clock, CheckCircle, AlertTriangle, 
  Search, Plus, ThumbsUp, ThumbsDown, TrendingUp, Users,
  Info
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { toast } from "sonner";

// Feedback Types
interface Feedback {
  id: string;
  subject: string;
  category: string;
  status: "pending" | "completed" | "active";
  submittedDate: string;
  priority: "high" | "medium" | "low";
}

interface Survey {
  id: string;
  title: string;
  status: "active" | "pending" | "completed";
  responses: number;
  targetResponses: number;
  dueDate: string;
}

interface SentimentRecord {
  id: string;
  department: string;
  score: number;
  trend: "up" | "down" | "neutral";
  responses: number;
  period: string;
}

// Initial Feedback Data
const initialFeedbackData: Feedback[] = [
  { id: "FB-001", subject: "Workplace Environment Concern", category: "Environment", status: "pending", submittedDate: "Dec 20, 2024", priority: "high" },
  { id: "FB-002", subject: "Training Program Suggestion", category: "Training", status: "completed", submittedDate: "Dec 18, 2024", priority: "medium" },
  { id: "FB-003", subject: "Benefits Package Inquiry", category: "Benefits", status: "active", submittedDate: "Dec 15, 2024", priority: "low" },
  { id: "FB-004", subject: "Safety Protocol Feedback", category: "Safety", status: "pending", submittedDate: "Dec 12, 2024", priority: "high" },
  { id: "FB-005", subject: "Remote Work Policy", category: "Policy", status: "completed", submittedDate: "Dec 10, 2024", priority: "medium" },
  { id: "FB-006", subject: "Team Communication Issues", category: "Communication", status: "active", submittedDate: "Dec 8, 2024", priority: "high" },
];

const feedbackColumns: Column<Feedback>[] = [
  { key: "id", header: "Feedback ID", className: "font-mono text-sm" },
  { key: "subject", header: "Subject" },
  { key: "category", header: "Category" },
  { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
  { key: "submittedDate", header: "Submitted" },
  { key: "priority", header: "Priority", render: (item) => <StatusBadge status={item.priority} /> },
  { key: "actions", header: "Actions" },
];

// Initial Survey Data
const initialSurveyData: Survey[] = [
  { id: "SV-001", title: "Annual Employee Satisfaction Survey", status: "active", responses: 856, targetResponses: 1200, dueDate: "Jan 15, 2025" },
  { id: "SV-002", title: "Q4 Pulse Check", status: "completed", responses: 1150, targetResponses: 1150, dueDate: "Dec 15, 2024" },
  { id: "SV-003", title: "Training Effectiveness Survey", status: "active", responses: 234, targetResponses: 500, dueDate: "Dec 30, 2024" },
  { id: "SV-004", title: "Workplace Safety Assessment", status: "pending", responses: 0, targetResponses: 800, dueDate: "Jan 20, 2025" },
  { id: "SV-005", title: "Benefits Satisfaction Survey", status: "completed", responses: 920, targetResponses: 900, dueDate: "Nov 30, 2024" },
];

const surveyColumns: Column<Survey>[] = [
  { key: "id", header: "Survey ID", className: "font-mono text-sm" },
  { key: "title", header: "Title" },
  { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
  { key: "responses", header: "Responses", render: (item) => `${item.responses}/${item.targetResponses}` },
  { key: "dueDate", header: "Due Date" },
  { key: "actions", header: "Actions" },
];

// Sentiment Data
const sentimentData: SentimentRecord[] = [
  { id: "1", department: "Nursing", score: 4.2, trend: "up", responses: 245, period: "Q4 2024" },
  { id: "2", department: "IT", score: 4.5, trend: "up", responses: 48, period: "Q4 2024" },
  { id: "3", department: "Administration", score: 3.8, trend: "down", responses: 62, period: "Q4 2024" },
  { id: "4", department: "Pharmacy", score: 4.1, trend: "neutral", responses: 35, period: "Q4 2024" },
  { id: "5", department: "Lab", score: 4.3, trend: "up", responses: 28, period: "Q4 2024" },
  { id: "6", department: "Maintenance", score: 3.9, trend: "neutral", responses: 22, period: "Q4 2024" },
];

const sentimentColumns: Column<SentimentRecord>[] = [
  { key: "department", header: "Department" },
  { key: "score", header: "Score", render: (item) => (
    <span className={item.score >= 4 ? "text-success font-semibold" : item.score >= 3.5 ? "text-warning font-semibold" : "text-destructive font-semibold"}>
      {item.score}/5
    </span>
  )},
  { key: "trend", header: "Trend", render: (item) => (
    <div className="flex items-center gap-1">
      {item.trend === "up" && <TrendingUp className="h-4 w-4 text-success" />}
      {item.trend === "down" && <TrendingUp className="h-4 w-4 text-destructive rotate-180" />}
      {item.trend === "neutral" && <span className="text-muted-foreground">—</span>}
      <span className="capitalize text-sm">{item.trend}</span>
    </div>
  )},
  { key: "responses", header: "Responses" },
  { key: "period", header: "Period" },
];

const deadlines = [
  { id: "1", title: "Annual Employee Satisfaction Survey", dueDate: "Jan 15, 2025", type: "Survey", priority: "high" as const },
  { id: "2", title: "Training Effectiveness Survey", dueDate: "Dec 30, 2024", type: "Survey", priority: "medium" as const },
  { id: "3", title: "Workplace Safety Assessment", dueDate: "Jan 20, 2025", type: "Survey", priority: "high" as const },
];

const feedbackCategories = [
  { label: "Environment", count: 342, icon: MessageSquare, color: "text-primary bg-primary/10" },
  { label: "Training", count: 256, icon: Users, color: "text-info bg-info/10" },
  { label: "Safety", count: 189, icon: AlertTriangle, color: "text-warning bg-warning/10" },
  { label: "Benefits", count: 412, icon: ThumbsUp, color: "text-success bg-success/10" },
];

const FeedbackManagementPage = () => {
  const [activeTab, setActiveTab] = useState("feedback");
  const [searchTerm, setSearchTerm] = useState("");
  const [feedbackData, setFeedbackData] = useState<Feedback[]>(initialFeedbackData);
  const [surveyData, setSurveyData] = useState<Survey[]>(initialSurveyData);

  const overallSatisfaction = 4.2;
  const responseRate = 78;

  const filteredFeedback = feedbackData.filter(
    (item) =>
      item.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold text-foreground">Feedback Management</h1>
        <p className="text-muted-foreground mt-1">
          Collect, analyze, and respond to employee feedback and surveys
        </p>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="feedback" className="gap-1.5">
            Feedback
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-3.5 w-3.5 text-muted-foreground hover:text-foreground transition-colors" />
                </TooltipTrigger>
                <TooltipContent side="bottom" className="max-w-xs">
                  <p className="font-medium mb-1">Feedback</p>
                  <p className="text-xs text-muted-foreground">
                    Track and manage employee feedback submissions. All feedback is processed 
                    through FeedbackHub for anonymous collection and sentiment analysis.
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </TabsTrigger>
          <TabsTrigger value="surveys" className="gap-1.5">
            Surveys
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-3.5 w-3.5 text-muted-foreground hover:text-foreground transition-colors" />
                </TooltipTrigger>
                <TooltipContent side="bottom" className="max-w-xs">
                  <p className="font-medium mb-1">Surveys</p>
                  <p className="text-xs text-muted-foreground">
                    Manage organizational surveys for employee satisfaction, training effectiveness, 
                    and workplace assessments. Track response rates and completion status.
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </TabsTrigger>
          <TabsTrigger value="sentiment" className="gap-1.5">
            Sentiment Analysis
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-3.5 w-3.5 text-muted-foreground hover:text-foreground transition-colors" />
                </TooltipTrigger>
                <TooltipContent side="bottom" className="max-w-xs">
                  <p className="font-medium mb-1">Sentiment Analysis</p>
                  <p className="text-xs text-muted-foreground">
                    View aggregated sentiment scores by department. Data is compiled from 
                    surveys and feedback to identify trends and areas for improvement.
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </TabsTrigger>
        </TabsList>

        {/* Feedback Tab */}
        <TabsContent value="feedback" className="space-y-6">
          {/* Categories */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {feedbackCategories.map((cat) => (
              <button
                key={cat.label}
                onClick={() => toast.info(`Viewing ${cat.label} feedback...`)}
                className="p-5 rounded-lg bg-card border border-border hover:border-primary/30 hover:shadow-md transition-all text-left group"
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${cat.color}`}>
                  <cat.icon className="h-5 w-5" />
                </div>
                <p className="font-semibold group-hover:text-primary transition-colors">{cat.label}</p>
                <p className="text-2xl font-bold mt-1">{cat.count.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">submissions</p>
              </button>
            ))}
          </div>

          {/* Search and Table */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center justify-between gap-4">
                <div className="relative max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search feedback..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Button onClick={() => toast.info("Opening feedback form...")}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Feedback
                </Button>
              </div>

              <DataTable
                columns={feedbackColumns}
                data={filteredFeedback}
                onView={(item) => toast.info(`Viewing: ${item.subject}`)}
                onEdit={(item) => toast.info(`Editing: ${item.id}`)}
                onDelete={(item) => {
                  setFeedbackData(feedbackData.filter(f => f.id !== item.id));
                  toast.success(`Deleted: ${item.id}`);
                }}
              />
            </div>
            <div>
              <UpcomingDeadlines deadlines={deadlines} />
            </div>
          </div>
        </TabsContent>

        {/* Surveys Tab */}
        <TabsContent value="surveys" className="space-y-6">
          {/* Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricCard title="Total Surveys" value={surveyData.length} icon={MessageSquare} variant="primary" />
            <MetricCard title="Active" value={surveyData.filter(s => s.status === "active").length} icon={Clock} variant="warning" />
            <MetricCard title="Completed" value={surveyData.filter(s => s.status === "completed").length} icon={CheckCircle} variant="success" />
            <MetricCard title="Pending" value={surveyData.filter(s => s.status === "pending").length} icon={AlertTriangle} variant="danger" />
          </div>

          {/* Response Rate */}
          <div className="bg-card rounded-lg border border-border p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold">Overall Response Rate</h3>
              <span className="text-2xl font-bold text-primary">{responseRate}%</span>
            </div>
            <Progress value={responseRate} className="h-3" />
            <div className="flex justify-between mt-3 text-sm text-muted-foreground">
              <span>Target: 85%</span>
              <span>3,160 of 4,050 employees</span>
            </div>
          </div>

          {/* Survey Table */}
          <div className="flex justify-end">
            <Button onClick={() => toast.info("Opening survey creation form...")}>
              <Plus className="h-4 w-4 mr-2" />
              Create Survey
            </Button>
          </div>

          <DataTable
            columns={surveyColumns}
            data={surveyData}
            onView={(item) => toast.info(`Viewing survey: ${item.title}`)}
            onEdit={(item) => toast.info(`Editing survey: ${item.id}`)}
            onDelete={(item) => {
              setSurveyData(surveyData.filter(s => s.id !== item.id));
              toast.success(`Deleted survey: ${item.id}`);
            }}
          />
        </TabsContent>

        {/* Sentiment Analysis Tab */}
        <TabsContent value="sentiment" className="space-y-6">
          {/* Overall Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricCard title="Avg. Satisfaction" value={overallSatisfaction} icon={ThumbsUp} variant="success" />
            <MetricCard title="Total Responses" value={2847} icon={Users} variant="primary" />
            <MetricCard title="Positive Feedback" value="68%" icon={ThumbsUp} variant="success" />
            <MetricCard title="Needs Attention" value={3} icon={ThumbsDown} variant="danger" />
          </div>

          {/* Satisfaction Score */}
          <div className="bg-card rounded-lg border border-border p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold">Overall Employee Satisfaction</h3>
              <span className="text-2xl font-bold text-success">{overallSatisfaction}/5</span>
            </div>
            <Progress value={(overallSatisfaction / 5) * 100} className="h-3" />
            <div className="flex justify-between mt-3 text-sm text-muted-foreground">
              <span>Target: 4.5/5</span>
              <span>Based on 2,847 responses</span>
            </div>
          </div>

          {/* Department Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {sentimentData.map((item) => (
              <div key={item.id} className="p-4 rounded-lg bg-card border border-border text-center">
                <p className="text-sm text-muted-foreground truncate">{item.department}</p>
                <p className="text-2xl font-bold mt-1" style={{ 
                  color: item.score >= 4 ? "hsl(var(--success))" : 
                         item.score >= 3.5 ? "hsl(var(--warning))" : 
                         "hsl(var(--destructive))" 
                }}>
                  {item.score}
                </p>
                <div className="flex items-center justify-center gap-1 mt-1">
                  {item.trend === "up" && <TrendingUp className="h-3 w-3 text-success" />}
                  {item.trend === "down" && <TrendingUp className="h-3 w-3 text-destructive rotate-180" />}
                  <span className="text-xs text-muted-foreground">{item.responses} responses</span>
                </div>
              </div>
            ))}
          </div>

          {/* Sentiment Table */}
          <div className="bg-card rounded-lg border border-border">
            <div className="p-4 border-b border-border">
              <h3 className="font-display font-semibold">Department Sentiment Details</h3>
            </div>
            <div className="p-4">
              <DataTable
                columns={sentimentColumns}
                data={sentimentData}
                onView={(item) => toast.info(`Viewing sentiment for: ${item.department}`)}
              />
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  );
};

export default FeedbackManagementPage;
