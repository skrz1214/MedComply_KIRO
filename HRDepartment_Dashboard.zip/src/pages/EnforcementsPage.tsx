import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { SectionHeader } from "@/components/dashboard/SectionHeader";
import { DataTable, Column } from "@/components/dashboard/DataTable";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { UpcomingDeadlines } from "@/components/dashboard/UpcomingDeadlines";
import { Shield, Clock, CheckCircle, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

interface Enforcement {
  id: string;
  title: string;
  status: "pending" | "completed" | "overdue";
  dueDate: string;
  owner: string;
  priority: "high" | "medium" | "low";
}

const enforcementData: Enforcement[] = [
  { id: "ENF-001", title: "Mandatory Overtime Compliance", status: "pending", dueDate: "Dec 18, 2024", owner: "HR Operations", priority: "high" },
  { id: "ENF-002", title: "Workplace Safety Violation", status: "completed", dueDate: "Dec 10, 2024", owner: "Safety Officer", priority: "high" },
  { id: "ENF-003", title: "HIPAA Training Deadline", status: "overdue", dueDate: "Dec 5, 2024", owner: "Training Dept", priority: "high" },
  { id: "ENF-004", title: "Badge Access Update", status: "pending", dueDate: "Dec 25, 2024", owner: "IT Security", priority: "medium" },
  { id: "ENF-005", title: "Credential Verification", status: "completed", dueDate: "Dec 12, 2024", owner: "Credentialing", priority: "medium" },
  { id: "ENF-006", title: "Break Room Compliance", status: "pending", dueDate: "Jan 2, 2025", owner: "Facilities", priority: "low" },
];

const deadlines = [
  { id: "1", title: "Mandatory Overtime Compliance", dueDate: "Dec 18, 2024", type: "Enforcement", priority: "high" as const },
  { id: "2", title: "Badge Access Update", dueDate: "Dec 25, 2024", type: "Enforcement", priority: "medium" as const },
  { id: "3", title: "Break Room Compliance", dueDate: "Jan 2, 2025", type: "Enforcement", priority: "low" as const },
];

const columns: Column<Enforcement>[] = [
  { key: "id", header: "Enforcement ID", className: "font-mono text-sm" },
  { key: "title", header: "Title" },
  { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
  { key: "dueDate", header: "Due Date" },
  { key: "owner", header: "Owner" },
  { key: "priority", header: "Priority", render: (item) => <StatusBadge status={item.priority} /> },
  { key: "actions", header: "Actions" },
];

const EnforcementsPage = () => {
  const handleAdd = () => {
    toast.info("Redirecting to EnforcePoint to create new enforcement...");
  };

  return (
    <DashboardLayout>
      <SectionHeader
        title="Enforcements"
        description="Track and manage policy enforcements via EnforcePoint"
        actionLabel="Add Enforcement"
        onAction={handleAdd}
      />

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <MetricCard title="Total" value={28} icon={Shield} variant="primary" />
        <MetricCard title="Pending" value={10} icon={Clock} variant="warning" />
        <MetricCard title="Completed" value={15} icon={CheckCircle} variant="success" />
        <MetricCard title="Overdue" value={3} icon={AlertTriangle} variant="danger" />
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <DataTable
            columns={columns}
            data={enforcementData}
            onView={(item) => toast.info(`Viewing: ${item.title}`)}
            onEdit={(item) => toast.info(`Redirecting to EnforcePoint to edit: ${item.id}`)}
            onDelete={(item) => toast.error(`Deleted: ${item.id}`)}
          />
        </div>
        <div>
          <UpcomingDeadlines deadlines={deadlines} />
        </div>
      </div>
    </DashboardLayout>
  );
};

export default EnforcementsPage;
