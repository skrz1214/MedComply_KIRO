import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useNavigate, useParams } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
import { toast } from "sonner";
import { ArrowLeft, FileText, Paperclip, X } from "lucide-react";

interface Policy {
  id: string;
  name: string;
  category: string;
  lastUpdate: string;
  status: "active" | "pending" | "inactive";
  nextUpdate: string;
  owner: string;
  description?: string;
  attachments?: string[];
}

// Mock data - in real app this would come from API/database
const policiesData: Policy[] = [
  { id: "1", name: "Employee Handbook", category: "General", lastUpdate: "Nov 15, 2024", status: "active", nextUpdate: "Nov 15, 2025", owner: "HR Director", description: "Comprehensive guide covering company policies, procedures, and employee expectations.", attachments: ["handbook_v3.pdf", "appendix_a.docx"] },
  { id: "2", name: "HIPAA Privacy Policy", category: "Compliance", lastUpdate: "Oct 20, 2024", status: "active", nextUpdate: "Oct 20, 2025", owner: "Compliance Officer", description: "Outlines the organization's commitment to protecting patient health information in accordance with HIPAA regulations." },
  { id: "3", name: "Remote Work Policy", category: "Operations", lastUpdate: "Sep 10, 2024", status: "pending", nextUpdate: "Dec 31, 2024", owner: "Operations Manager", description: "Guidelines for employees working remotely, including equipment, communication, and security requirements." },
  { id: "4", name: "Code of Conduct", category: "Ethics", lastUpdate: "Aug 5, 2024", status: "active", nextUpdate: "Aug 5, 2025", owner: "Legal Counsel", description: "Standards of professional behavior and ethical guidelines for all employees." },
  { id: "5", name: "Anti-Harassment Policy", category: "HR", lastUpdate: "Jul 22, 2024", status: "active", nextUpdate: "Jul 22, 2025", owner: "HR Director", description: "Zero-tolerance policy on workplace harassment with reporting procedures and consequences." },
  { id: "6", name: "Data Security Policy", category: "IT", lastUpdate: "Jun 18, 2024", status: "pending", nextUpdate: "Jan 15, 2025", owner: "IT Director", description: "Protocols for data protection, access controls, and incident response procedures.", attachments: ["security_checklist.pdf"] },
  { id: "7", name: "Expense Reimbursement", category: "Finance", lastUpdate: "May 12, 2024", status: "inactive", nextUpdate: "TBD", owner: "Finance Manager", description: "Procedures for submitting and processing expense reimbursement requests." },
];

const categories = ["General", "Compliance", "Operations", "Ethics", "HR", "IT", "Finance"];
const statuses = ["active", "pending", "inactive"] as const;

const PolicyEditPage = () => {
  const { policyId } = useParams();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const isNewPolicy = policyId === "new";
  
  const existingPolicy = !isNewPolicy ? policiesData.find(p => p.id === policyId) : null;

  const [formData, setFormData] = useState({
    name: "",
    category: "",
    status: "active" as "active" | "pending" | "inactive",
    nextUpdate: "",
    owner: "",
    description: "",
  });
  const [attachments, setAttachments] = useState<string[]>([]);

  useEffect(() => {
    if (existingPolicy) {
      setFormData({
        name: existingPolicy.name,
        category: existingPolicy.category,
        status: existingPolicy.status,
        nextUpdate: existingPolicy.nextUpdate,
        owner: existingPolicy.owner,
        description: existingPolicy.description || "",
      });
      setAttachments(existingPolicy.attachments || []);
    }
  }, [existingPolicy]);

  if (!isNewPolicy && !existingPolicy) {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center py-12">
          <FileText className="h-12 w-12 text-muted-foreground mb-4" />
          <h2 className="text-xl font-semibold mb-2">Policy Not Found</h2>
          <p className="text-muted-foreground mb-4">The policy you're looking for doesn't exist.</p>
          <Button onClick={() => navigate("/policies")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Policies
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isNewPolicy) {
      toast.success(`Policy "${formData.name}" created successfully`);
    } else {
      toast.success(`Policy "${formData.name}" updated successfully`);
    }
    
    navigate("/policies");
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newAttachments = Array.from(files).map(file => file.name);
      setAttachments([...attachments, ...newAttachments]);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const removeAttachment = (index: number) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-3xl">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/policies")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">
              {isNewPolicy ? "Add New Policy" : `Edit: ${existingPolicy?.name}`}
            </h1>
            <p className="text-muted-foreground">
              {isNewPolicy ? "Create a new policy" : "Update policy information"}
            </p>
          </div>
        </div>

        {/* Form */}
        <Card>
          <CardHeader>
            <CardTitle>Policy Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Policy Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter policy name"
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Category *</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Status *</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value as typeof formData.status })}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      {statuses.map((status) => (
                        <SelectItem key={status} value={status} className="capitalize">{status}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="owner">Owner *</Label>
                  <Input
                    id="owner"
                    value={formData.owner}
                    onChange={(e) => setFormData({ ...formData, owner: e.target.value })}
                    placeholder="Policy owner"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="nextUpdate">Next Update *</Label>
                  <Input
                    id="nextUpdate"
                    value={formData.nextUpdate}
                    onChange={(e) => setFormData({ ...formData, nextUpdate: e.target.value })}
                    placeholder="e.g., Nov 15, 2025"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Enter policy description (optional)"
                  rows={4}
                />
              </div>

              {/* Attachments Section */}
              <div className="space-y-2">
                <Label>Attachments</Label>
                <div className="border border-dashed border-border rounded-lg p-6">
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    onChange={handleFileChange}
                    className="hidden"
                    accept=".pdf,.doc,.docx,.xls,.xlsx,.txt"
                  />
                  <div className="text-center">
                    <Paperclip className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      Add Attachments
                    </Button>
                    <p className="text-xs text-muted-foreground mt-2">
                      PDF, DOC, DOCX, XLS, XLSX, TXT files accepted
                    </p>
                  </div>
                  
                  {attachments.length > 0 && (
                    <div className="mt-4 space-y-2">
                      {attachments.map((file, index) => (
                        <div key={index} className="flex items-center justify-between bg-muted/50 rounded-lg px-4 py-3">
                          <div className="flex items-center gap-3">
                            <FileText className="h-4 w-4 text-primary" />
                            <span className="text-sm">{file}</span>
                          </div>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeAttachment(index)}
                            className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button type="button" variant="outline" onClick={() => navigate("/policies")}>
                  Cancel
                </Button>
                <Button type="submit">
                  {isNewPolicy ? "Create Policy" : "Save Changes"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default PolicyEditPage;
