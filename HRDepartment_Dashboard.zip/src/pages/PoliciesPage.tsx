import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { SectionHeader } from "@/components/dashboard/SectionHeader";
import { DataTable, Column } from "@/components/dashboard/DataTable";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { DeletePolicyDialog } from "@/components/policies/DeletePolicyDialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Search } from "lucide-react";

interface Policy {
  id: string;
  name: string;
  category: string;
  lastUpdate: string;
  status: "active" | "pending" | "inactive";
  nextUpdate: string;
  owner: string;
  description?: string;
  attachments?: string[];
}

const initialPoliciesData: Policy[] = [
  { id: "1", name: "Employee Handbook", category: "General", lastUpdate: "Nov 15, 2024", status: "active", nextUpdate: "Nov 15, 2025", owner: "HR Director" },
  { id: "2", name: "HIPAA Privacy Policy", category: "Compliance", lastUpdate: "Oct 20, 2024", status: "active", nextUpdate: "Oct 20, 2025", owner: "Compliance Officer" },
  { id: "3", name: "Remote Work Policy", category: "Operations", lastUpdate: "Sep 10, 2024", status: "pending", nextUpdate: "Dec 31, 2024", owner: "Operations Manager" },
  { id: "4", name: "Code of Conduct", category: "Ethics", lastUpdate: "Aug 5, 2024", status: "active", nextUpdate: "Aug 5, 2025", owner: "Legal Counsel" },
  { id: "5", name: "Anti-Harassment Policy", category: "HR", lastUpdate: "Jul 22, 2024", status: "active", nextUpdate: "Jul 22, 2025", owner: "HR Director" },
  { id: "6", name: "Data Security Policy", category: "IT", lastUpdate: "Jun 18, 2024", status: "pending", nextUpdate: "Jan 15, 2025", owner: "IT Director" },
  { id: "7", name: "Expense Reimbursement", category: "Finance", lastUpdate: "May 12, 2024", status: "inactive", nextUpdate: "TBD", owner: "Finance Manager" },
];

const categories = ["All", "General", "Compliance", "Operations", "Ethics", "HR", "IT", "Finance"];
const statuses = ["All", "Active", "Pending", "Inactive"];

const columns: Column<Policy>[] = [
  { key: "name", header: "Policy Name" },
  { key: "category", header: "Category" },
  { key: "lastUpdate", header: "Last Update" },
  { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
  { key: "nextUpdate", header: "Next Update" },
  { key: "owner", header: "Owner" },
  { key: "actions", header: "Actions" },
];

const PoliciesPage = () => {
  const navigate = useNavigate();
  const [policies, setPolicies] = useState<Policy[]>(initialPoliciesData);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  
  // Dialog states
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedPolicy, setSelectedPolicy] = useState<Policy | null>(null);

  const filteredData = policies.filter((policy) => {
    const matchesSearch = policy.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === "All" || policy.category === categoryFilter;
    const matchesStatus = statusFilter === "All" || policy.status.toLowerCase() === statusFilter.toLowerCase();
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const handleAdd = () => {
    navigate("/policies/new/edit");
  };

  const handleView = (policy: Policy) => {
    navigate(`/policies/${policy.id}`);
  };

  const handleEdit = (policy: Policy) => {
    navigate(`/policies/${policy.id}/edit`);
  };

  const handleDelete = (policy: Policy) => {
    setSelectedPolicy(policy);
    setDeleteDialogOpen(true);
  };


  const handleConfirmDelete = () => {
    if (selectedPolicy) {
      setPolicies(policies.filter(p => p.id !== selectedPolicy.id));
      toast.success(`Policy "${selectedPolicy.name}" deleted successfully`);
      setDeleteDialogOpen(false);
      setSelectedPolicy(null);
    }
  };

  return (
    <DashboardLayout>
      <SectionHeader
        title="Policies & Procedures"
        description="Manage Human Resource level policies and procedures"
        actionLabel="Add Policy"
        onAction={handleAdd}
      />

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search policies..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((cat) => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            {statuses.map((status) => (
              <SelectItem key={status} value={status}>{status}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <DataTable
        columns={columns}
        data={filteredData}
        onView={handleView}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />

      <DeletePolicyDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        policy={selectedPolicy}
        onConfirm={handleConfirmDelete}
      />
    </DashboardLayout>
  );
};

export default PoliciesPage;
