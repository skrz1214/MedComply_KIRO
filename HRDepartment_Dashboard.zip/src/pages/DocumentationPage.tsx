import { useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Download, FileText, Code, TestTube, UserCheck, MessageSquareText } from "lucide-react";
import { toast } from "sonner";
import jsPDF from "jspdf";

const DocumentationPage = () => {
  const [activeTab, setActiveTab] = useState("prd");

  const generatePDF = (docType: string) => {
    const doc = new jsPDF();
    let content = "";
    let title = "";

    switch (docType) {
      case "prd":
        title = "Product Requirements Document";
        content = getPRDContent();
        break;
      case "tdd":
        title = "Technical Design Document";
        content = getTDDContent();
        break;
      case "qa":
        title = "QA Test Cases";
        content = getQAContent();
        break;
      case "uat":
        title = "UAT Test Cases";
        content = getUATContent();
        break;
      case "prompt":
        title = "System Prompt";
        content = getPromptContent();
        break;
    }

    // Add title
    doc.setFontSize(20);
    doc.text(title, 20, 20);
    
    // Add content
    doc.setFontSize(11);
    const lines = doc.splitTextToSize(content, 170);
    let y = 35;
    
    lines.forEach((line: string) => {
      if (y > 280) {
        doc.addPage();
        y = 20;
      }
      doc.text(line, 20, y);
      y += 6;
    });

    doc.save(`${docType.toUpperCase()}_HR_Compliance_Dashboard.pdf`);
    toast.success(`${title} downloaded successfully`);
  };

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold text-foreground">Documentation</h1>
        <p className="text-muted-foreground mt-1">
          Project documentation including PRD, TDD, QA and UAT test cases
        </p>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="prd" className="gap-2">
            <FileText className="h-4 w-4" />
            PRD
          </TabsTrigger>
          <TabsTrigger value="tdd" className="gap-2">
            <Code className="h-4 w-4" />
            TDD
          </TabsTrigger>
          <TabsTrigger value="qa" className="gap-2">
            <TestTube className="h-4 w-4" />
            QA Test Cases
          </TabsTrigger>
          <TabsTrigger value="uat" className="gap-2">
            <UserCheck className="h-4 w-4" />
            UAT Test Cases
          </TabsTrigger>
          <TabsTrigger value="prompt" className="gap-2">
            <MessageSquareText className="h-4 w-4" />
            System Prompt
          </TabsTrigger>
        </TabsList>

        {/* PRD Tab */}
        <TabsContent value="prd">
          <DocumentCard
            title="Product Requirements Document (PRD)"
            icon={FileText}
            onDownload={() => generatePDF("prd")}
          >
            <PRDContent />
          </DocumentCard>
        </TabsContent>

        {/* TDD Tab */}
        <TabsContent value="tdd">
          <DocumentCard
            title="Technical Design Document (TDD)"
            icon={Code}
            onDownload={() => generatePDF("tdd")}
          >
            <TDDContent />
          </DocumentCard>
        </TabsContent>

        {/* QA Tab */}
        <TabsContent value="qa">
          <DocumentCard
            title="QA Test Cases"
            icon={TestTube}
            onDownload={() => generatePDF("qa")}
          >
            <QAContent />
          </DocumentCard>
        </TabsContent>

        {/* UAT Tab */}
        <TabsContent value="uat">
          <DocumentCard
            title="UAT Test Cases"
            icon={UserCheck}
            onDownload={() => generatePDF("uat")}
          >
            <UATContent />
          </DocumentCard>
        </TabsContent>

        {/* System Prompt Tab */}
        <TabsContent value="prompt">
          <DocumentCard
            title="System Prompt - Final Version"
            icon={MessageSquareText}
            onDownload={() => generatePDF("prompt")}
          >
            <PromptContent />
          </DocumentCard>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  );
};

interface DocumentCardProps {
  title: string;
  icon: React.ElementType;
  onDownload: () => void;
  children: React.ReactNode;
}

const DocumentCard = ({ title, icon: Icon, onDownload, children }: DocumentCardProps) => (
  <div className="bg-card rounded-lg border border-border">
    <div className="p-4 border-b border-border flex items-center justify-between">
      <div className="flex items-center gap-3">
        <Icon className="h-5 w-5 text-primary" />
        <h2 className="font-semibold">{title}</h2>
      </div>
      <Button onClick={onDownload}>
        <Download className="h-4 w-4 mr-2" />
        Download PDF
      </Button>
    </div>
    <div className="p-6 max-h-[600px] overflow-y-auto prose prose-sm dark:prose-invert max-w-none">
      {children}
    </div>
  </div>
);

// PRD Content Component
const PRDContent = () => (
  <div className="space-y-6">
    <section>
      <h3 className="text-lg font-semibold border-b pb-2">1. Executive Summary</h3>
      <p className="mt-3">The MedComply HR Compliance Master Dashboard is a comprehensive web-based application designed to centralize and streamline human resources compliance management for healthcare organizations. The system provides real-time visibility into compliance status, risk management, audit tracking, enforcement management, feedback collection, and training tracking across the organization.</p>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">2. Product Vision</h3>
      <p className="mt-3">To provide HR departments with a unified platform that simplifies compliance tracking, reduces regulatory risk, and ensures organizational adherence to federal, state, and industry-specific requirements including HIPAA, OSHA, and ADAA. The platform integrates with external systems (HR System, LMS, FeedbackHub) while providing centralized status tracking and reporting.</p>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">3. Target Users</h3>
      <ul className="list-disc pl-5 mt-3 space-y-1">
        <li><strong>Admin:</strong> Full system access, configuration, and approval authority</li>
        <li><strong>Department Manager:</strong> Department-level compliance oversight and task management</li>
        <li><strong>View Only User:</strong> Read-only access to assigned compliance items and training</li>
      </ul>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">4. Core Features</h3>
      <div className="mt-3 space-y-4">
        <div>
          <h4 className="font-medium">4.1 Dashboard (Management Hub)</h4>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>Action Center with task management and priority filtering</li>
            <li>Review Queue for pending approvals and sign-offs</li>
            <li>Quality KPIs with CRUD operations and formula-based calculations</li>
            <li>Quick Access to micro-applications</li>
            <li>Upcoming Deadlines section</li>
          </ul>
        </div>
        <div>
          <h4 className="font-medium">4.2 Governing Body Org Chart</h4>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>Hierarchical organization structure display</li>
            <li>Member management with full CRUD operations</li>
            <li>Role and department assignments</li>
          </ul>
        </div>
        <div>
          <h4 className="font-medium">4.3 Audit Management</h4>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>Audit item tracking and scheduling</li>
            <li>Audit findings documentation</li>
            <li>View and edit audit details</li>
          </ul>
        </div>
        <div>
          <h4 className="font-medium">4.4 Enforcements</h4>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>Enforcement action tracking via EnforcePoint integration</li>
            <li>Priority-based enforcement management</li>
            <li>Status tracking (pending, completed, overdue)</li>
          </ul>
        </div>
        <div>
          <h4 className="font-medium">4.5 Risk Management</h4>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>Risk Registry with severity levels (High, Medium, Low)</li>
            <li>Policies & Procedures management with CRUD operations</li>
            <li>HIPAA compliance tracking</li>
            <li>ADAA compliance tracking</li>
          </ul>
        </div>
        <div>
          <h4 className="font-medium">4.6 Compliance Tracking (Tabbed Interface)</h4>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>Compliance Items tab with status tracking</li>
            <li>Employee Files tab - status tracking for files maintained in HR system</li>
            <li>Training Statistics tab - completion tracking for LMS-managed courses</li>
            <li>Full CRUD operations for Employee Files and Training records</li>
            <li>Tooltips explaining data sources and integrations</li>
          </ul>
        </div>
        <div>
          <h4 className="font-medium">4.7 Feedback Management (Tabbed Interface)</h4>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>Feedback tab - track employee feedback by category</li>
            <li>Surveys tab - manage organizational surveys and response rates</li>
            <li>Sentiment Analysis tab - department-level satisfaction scores and trends</li>
            <li>Integration with FeedbackHub for anonymous collection</li>
          </ul>
        </div>
        <div>
          <h4 className="font-medium">4.8 Documentation</h4>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>PRD, TDD, QA Test Cases, UAT Test Cases documents</li>
            <li>System Prompt documentation</li>
            <li>PDF download functionality for all documents</li>
          </ul>
        </div>
      </div>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">5. External System Integrations</h3>
      <ul className="list-disc pl-5 mt-3 space-y-1">
        <li><strong>HR System:</strong> Employee files and personnel records storage</li>
        <li><strong>LMS (Learning Management System):</strong> Training course management</li>
        <li><strong>FeedbackHub:</strong> Anonymous feedback collection and sentiment analysis</li>
        <li><strong>EnforcePoint:</strong> Policy enforcement and violation tracking</li>
      </ul>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">6. Success Metrics</h3>
      <ul className="list-disc pl-5 mt-3 space-y-1">
        <li>95% compliance rate across all tracked items</li>
        <li>90% training completion rate organization-wide</li>
        <li>50% reduction in compliance-related incidents</li>
        <li>100% on-time regulatory submission rate</li>
        <li>4.5/5 average employee satisfaction score</li>
      </ul>
    </section>
  </div>
);

// TDD Content Component
const TDDContent = () => (
  <div className="space-y-6">
    <section>
      <h3 className="text-lg font-semibold border-b pb-2">1. System Architecture</h3>
      <p className="mt-3">The MedComply HR Compliance Master Dashboard is built as a single-page application (SPA) using modern web technologies with a component-based architecture.</p>
      <div className="mt-3 p-4 bg-muted rounded-lg">
        <h4 className="font-medium mb-2">Technology Stack:</h4>
        <ul className="list-disc pl-5 space-y-1">
          <li><strong>Frontend:</strong> React 18, TypeScript, Vite</li>
          <li><strong>Styling:</strong> Tailwind CSS, shadcn/ui components</li>
          <li><strong>State Management:</strong> React Context API, React Query, useState hooks</li>
          <li><strong>Routing:</strong> React Router DOM v6</li>
          <li><strong>Charts:</strong> Recharts</li>
          <li><strong>PDF Generation:</strong> jsPDF</li>
          <li><strong>Date Handling:</strong> date-fns</li>
          <li><strong>Notifications:</strong> Sonner toast library</li>
        </ul>
      </div>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">2. Component Structure</h3>
      <div className="mt-3 font-mono text-sm bg-muted p-4 rounded-lg">
        <pre>{`src/
├── components/
│   ├── compliance/
│   │   ├── EmployeeFileFormDialog.tsx
│   │   ├── TrainingFormDialog.tsx
│   │   ├── ViewEmployeeFileDialog.tsx
│   │   ├── ViewTrainingDialog.tsx
│   │   └── DeleteConfirmDialog.tsx
│   ├── dashboard/
│   │   ├── AdminDashboard.tsx
│   │   ├── DepartmentHeadDashboard.tsx
│   │   ├── ViewerDashboard.tsx
│   │   ├── QualityKPIs.tsx
│   │   ├── QuickAccessApps.tsx
│   │   ├── DataTable.tsx
│   │   ├── MetricCard.tsx
│   │   └── StatusBadge.tsx
│   ├── layout/
│   │   ├── DashboardLayout.tsx
│   │   ├── Sidebar.tsx
│   │   ├── Breadcrumb.tsx
│   │   └── RoleSwitcher.tsx
│   └── ui/ (shadcn components)
├── pages/
│   ├── Index.tsx
│   ├── OrgChartPage.tsx
│   ├── AuditsPage.tsx
│   ├── EnforcementsPage.tsx
│   ├── RisksPage.tsx
│   ├── CompliancePage.tsx
│   ├── FeedbackManagementPage.tsx
│   └── DocumentationPage.tsx
└── contexts/
    └── RoleContext.tsx`}</pre>
      </div>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">3. Data Models</h3>
      <div className="mt-3 space-y-4">
        <div className="p-4 bg-muted rounded-lg">
          <h4 className="font-medium mb-2">EmployeeFile Model:</h4>
          <pre className="text-sm">{`interface EmployeeFile {
  id: string;
  employeeName: string;
  department: string;
  fileType: string;
  lastUpdated: string;
  status: "active" | "pending" | "inactive";
}`}</pre>
        </div>
        <div className="p-4 bg-muted rounded-lg">
          <h4 className="font-medium mb-2">TrainingRecord Model:</h4>
          <pre className="text-sm">{`interface TrainingRecord {
  id: string;
  employeeName: string;
  trainingType: string;
  status: "completed" | "pending" | "overdue";
  completionDate: string;
}`}</pre>
        </div>
        <div className="p-4 bg-muted rounded-lg">
          <h4 className="font-medium mb-2">Feedback Model:</h4>
          <pre className="text-sm">{`interface Feedback {
  id: string;
  subject: string;
  category: string;
  status: "pending" | "completed" | "active";
  submittedDate: string;
  priority: "high" | "medium" | "low";
}`}</pre>
        </div>
        <div className="p-4 bg-muted rounded-lg">
          <h4 className="font-medium mb-2">Survey Model:</h4>
          <pre className="text-sm">{`interface Survey {
  id: string;
  title: string;
  status: "active" | "pending" | "completed";
  responses: number;
  targetResponses: number;
  dueDate: string;
}`}</pre>
        </div>
      </div>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">4. UI/UX Design Patterns</h3>
      <ul className="list-disc pl-5 mt-3 space-y-1">
        <li>Dark navy sidebar with collapsible "Management Hub" navigation</li>
        <li>Tabbed interfaces for multi-section pages (Compliance, Feedback)</li>
        <li>Tooltips with info icons explaining data sources and integrations</li>
        <li>Modal dialogs for CRUD operations</li>
        <li>Toast notifications for user feedback</li>
        <li>Status badges with color coding (green=success, yellow=warning, red=error)</li>
        <li>Progress bars for completion tracking</li>
        <li>Responsive grid layouts</li>
      </ul>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">5. Security Considerations</h3>
      <ul className="list-disc pl-5 mt-3 space-y-1">
        <li>Role-based access control (RBAC) via RoleContext</li>
        <li>Client-side route protection based on user roles</li>
        <li>Input validation using form validation</li>
        <li>XSS prevention through React's built-in escaping</li>
      </ul>
    </section>
  </div>
);

// QA Content Component
const QAContent = () => (
  <div className="space-y-6">
    <section>
      <h3 className="text-lg font-semibold border-b pb-2">Test Case Summary</h3>
      <div className="mt-3 grid grid-cols-4 gap-4 text-center">
        <div className="p-3 bg-primary/10 rounded-lg">
          <p className="text-2xl font-bold text-primary">58</p>
          <p className="text-sm text-muted-foreground">Total Cases</p>
        </div>
        <div className="p-3 bg-success/10 rounded-lg">
          <p className="text-2xl font-bold text-success">42</p>
          <p className="text-sm text-muted-foreground">Functional</p>
        </div>
        <div className="p-3 bg-info/10 rounded-lg">
          <p className="text-2xl font-bold text-info">10</p>
          <p className="text-sm text-muted-foreground">UI/UX</p>
        </div>
        <div className="p-3 bg-warning/10 rounded-lg">
          <p className="text-2xl font-bold text-warning">6</p>
          <p className="text-sm text-muted-foreground">Performance</p>
        </div>
      </div>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">TC-001: Dashboard Loading</h3>
      <table className="w-full mt-3 text-sm">
        <tbody>
          <tr className="border-b"><td className="py-2 font-medium w-32">Priority:</td><td>High</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Precondition:</td><td>User is authenticated</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Steps:</td><td>1. Navigate to dashboard URL<br/>2. Observe page load</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Expected:</td><td>Dashboard loads within 3 seconds with all components visible</td></tr>
        </tbody>
      </table>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">TC-002: Sidebar Navigation</h3>
      <table className="w-full mt-3 text-sm">
        <tbody>
          <tr className="border-b"><td className="py-2 font-medium w-32">Priority:</td><td>High</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Precondition:</td><td>User is on any page</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Steps:</td><td>1. Click Management Hub chevron to collapse/expand<br/>2. Click each navigation item<br/>3. Verify active state highlighting</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Expected:</td><td>Section collapses/expands, navigation works, active item highlighted in cyan</td></tr>
        </tbody>
      </table>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">TC-003: Employee File CRUD</h3>
      <table className="w-full mt-3 text-sm">
        <tbody>
          <tr className="border-b"><td className="py-2 font-medium w-32">Priority:</td><td>High</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Precondition:</td><td>User is on Compliance Tracking &gt; Employee Files tab</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Steps:</td><td>1. Click Add Record button<br/>2. Fill form fields<br/>3. Save record<br/>4. View record details<br/>5. Edit record<br/>6. Delete record</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Expected:</td><td>All CRUD operations complete with toast notifications</td></tr>
        </tbody>
      </table>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">TC-004: Training Record CRUD</h3>
      <table className="w-full mt-3 text-sm">
        <tbody>
          <tr className="border-b"><td className="py-2 font-medium w-32">Priority:</td><td>High</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Precondition:</td><td>User is on Compliance Tracking &gt; Training Statistics tab</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Steps:</td><td>1. Click Add Training button<br/>2. Fill form with date picker<br/>3. Save training record<br/>4. Verify metrics update<br/>5. Edit and delete records</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Expected:</td><td>CRUD operations work, metrics recalculate dynamically</td></tr>
        </tbody>
      </table>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">TC-005: Feedback Management Tabs</h3>
      <table className="w-full mt-3 text-sm">
        <tbody>
          <tr className="border-b"><td className="py-2 font-medium w-32">Priority:</td><td>Medium</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Precondition:</td><td>User navigates to Feedback Management</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Steps:</td><td>1. Click Feedback tab<br/>2. Click Surveys tab<br/>3. Click Sentiment Analysis tab<br/>4. Hover over info tooltips</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Expected:</td><td>Each tab displays correct content, tooltips show explanatory text</td></tr>
        </tbody>
      </table>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">TC-006: Tooltip Information Display</h3>
      <table className="w-full mt-3 text-sm">
        <tbody>
          <tr className="border-b"><td className="py-2 font-medium w-32">Priority:</td><td>Medium</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Precondition:</td><td>User is on Compliance Tracking page</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Steps:</td><td>1. Hover over Employee Files info icon<br/>2. Hover over Training Statistics info icon<br/>3. Read tooltip content</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Expected:</td><td>Tooltips display explaining HR System and LMS integrations</td></tr>
        </tbody>
      </table>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">TC-007: PDF Download</h3>
      <table className="w-full mt-3 text-sm">
        <tbody>
          <tr className="border-b"><td className="py-2 font-medium w-32">Priority:</td><td>Medium</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Precondition:</td><td>User is on Documentation page</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Steps:</td><td>1. Select each document tab (PRD, TDD, QA, UAT, System Prompt)<br/>2. Click Download PDF button</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Expected:</td><td>PDF file downloads with correct content for each document type</td></tr>
        </tbody>
      </table>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">TC-008: Search Functionality</h3>
      <table className="w-full mt-3 text-sm">
        <tbody>
          <tr className="border-b"><td className="py-2 font-medium w-32">Priority:</td><td>Medium</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Precondition:</td><td>User is on Employee Files or Feedback tab</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Steps:</td><td>1. Type search term in search box<br/>2. Observe filtered results</td></tr>
          <tr className="border-b"><td className="py-2 font-medium">Expected:</td><td>Table filters to show only matching records</td></tr>
        </tbody>
      </table>
    </section>
  </div>
);

// UAT Content Component
const UATContent = () => (
  <div className="space-y-6">
    <section>
      <h3 className="text-lg font-semibold border-b pb-2">UAT Overview</h3>
      <p className="mt-3">User Acceptance Testing scenarios designed to validate the MedComply HR Compliance Master Dashboard meets business requirements and user expectations.</p>
      <div className="mt-4 p-4 bg-muted rounded-lg">
        <p><strong>Test Environment:</strong> Production-like staging environment</p>
        <p><strong>Test Duration:</strong> 2 weeks</p>
        <p><strong>Participants:</strong> HR Directors, Compliance Officers, Department Managers</p>
      </div>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">UAT-001: End-to-End Compliance Workflow</h3>
      <div className="mt-3 p-4 border rounded-lg">
        <p className="font-medium">Scenario:</p>
        <p className="text-muted-foreground mt-1">As an HR Director, I need to track a new OSHA compliance requirement from creation to completion.</p>
        <div className="mt-3">
          <p className="font-medium">Acceptance Criteria:</p>
          <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
            <li>Can create new compliance item with all required fields</li>
            <li>Item appears in Action Center with correct priority</li>
            <li>Can assign to appropriate department manager</li>
            <li>Status updates reflect in real-time across dashboard</li>
            <li>Completion triggers removal from pending queue</li>
          </ul>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-4 text-sm">
          <div><strong>Pass/Fail:</strong> ___________</div>
          <div><strong>Tester:</strong> _______________</div>
          <div><strong>Date:</strong> ________________</div>
        </div>
      </div>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">UAT-002: Employee File Management</h3>
      <div className="mt-3 p-4 border rounded-lg">
        <p className="font-medium">Scenario:</p>
        <p className="text-muted-foreground mt-1">As an HR Manager, I need to track employee file status while understanding files are stored in the HR System.</p>
        <div className="mt-3">
          <p className="font-medium">Acceptance Criteria:</p>
          <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
            <li>Tooltip clearly explains files are maintained in HR System</li>
            <li>Can add new employee file tracking record</li>
            <li>Can view, edit, and delete file records</li>
            <li>Category counts display correctly</li>
            <li>Search filters employee records accurately</li>
          </ul>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-4 text-sm">
          <div><strong>Pass/Fail:</strong> ___________</div>
          <div><strong>Tester:</strong> _______________</div>
          <div><strong>Date:</strong> ________________</div>
        </div>
      </div>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">UAT-003: Training Compliance Monitoring</h3>
      <div className="mt-3 p-4 border rounded-lg">
        <p className="font-medium">Scenario:</p>
        <p className="text-muted-foreground mt-1">As a Department Manager, I need to monitor training completion while understanding courses are managed in LMS.</p>
        <div className="mt-3">
          <p className="font-medium">Acceptance Criteria:</p>
          <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
            <li>Tooltip explains LMS integration for course management</li>
            <li>Training Statistics tab shows accurate completion rates</li>
            <li>Can add training records with date picker</li>
            <li>Metrics update dynamically when records change</li>
            <li>Training type breakdown displays correctly</li>
          </ul>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-4 text-sm">
          <div><strong>Pass/Fail:</strong> ___________</div>
          <div><strong>Tester:</strong> _______________</div>
          <div><strong>Date:</strong> ________________</div>
        </div>
      </div>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">UAT-004: Feedback Management Workflow</h3>
      <div className="mt-3 p-4 border rounded-lg">
        <p className="font-medium">Scenario:</p>
        <p className="text-muted-foreground mt-1">As an HR Director, I need to review employee feedback and sentiment trends across departments.</p>
        <div className="mt-3">
          <p className="font-medium">Acceptance Criteria:</p>
          <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
            <li>Feedback tab shows categorized feedback with priority levels</li>
            <li>Surveys tab displays response rates and survey status</li>
            <li>Sentiment Analysis shows department scores and trends</li>
            <li>Tooltips explain FeedbackHub integration</li>
            <li>Can search and filter feedback records</li>
          </ul>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-4 text-sm">
          <div><strong>Pass/Fail:</strong> ___________</div>
          <div><strong>Tester:</strong> _______________</div>
          <div><strong>Date:</strong> ________________</div>
        </div>
      </div>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">UAT-005: Navigation and UI Consistency</h3>
      <div className="mt-3 p-4 border rounded-lg">
        <p className="font-medium">Scenario:</p>
        <p className="text-muted-foreground mt-1">As any user, I need consistent navigation and UI patterns across all pages.</p>
        <div className="mt-3">
          <p className="font-medium">Acceptance Criteria:</p>
          <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
            <li>Sidebar collapses/expands Management Hub section</li>
            <li>Active navigation item is clearly highlighted</li>
            <li>All pages follow consistent layout patterns</li>
            <li>Status badges use consistent color coding</li>
            <li>Toast notifications appear for all actions</li>
          </ul>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-4 text-sm">
          <div><strong>Pass/Fail:</strong> ___________</div>
          <div><strong>Tester:</strong> _______________</div>
          <div><strong>Date:</strong> ________________</div>
        </div>
      </div>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">Sign-Off</h3>
      <div className="mt-3 p-4 border rounded-lg">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Business Owner:</p>
            <p className="font-medium mt-1">_________________________</p>
            <p className="text-xs text-muted-foreground mt-1">Date: _______________</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">QA Lead:</p>
            <p className="font-medium mt-1">_________________________</p>
            <p className="text-xs text-muted-foreground mt-1">Date: _______________</p>
          </div>
        </div>
      </div>
    </section>
  </div>
);

// System Prompt Content Component
const PromptContent = () => (
  <div className="space-y-6">
    <section>
      <h3 className="text-lg font-semibold border-b pb-2">MedComply HR Compliance Dashboard - System Prompt</h3>
      <p className="mt-3 text-muted-foreground">This document contains the complete system prompt used to generate the MedComply HR Compliance Master Dashboard application.</p>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">1. Application Overview</h3>
      <p className="mt-3">Build a MedComply HR Compliance Master Dashboard - a comprehensive web-based application for healthcare HR compliance management. The system provides real-time visibility into compliance status, risk management, audit tracking, enforcement management, feedback collection, and training tracking. The dashboard serves as a central hub that integrates with external systems (HR System, LMS, FeedbackHub, EnforcePoint) while providing unified status tracking.</p>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">2. Technology Stack</h3>
      <ul className="list-disc pl-5 mt-3 space-y-1">
        <li><strong>Frontend Framework:</strong> React 18 with TypeScript</li>
        <li><strong>Build Tool:</strong> Vite</li>
        <li><strong>Styling:</strong> Tailwind CSS with shadcn/ui component library</li>
        <li><strong>State Management:</strong> React Context API for role management, useState for local state</li>
        <li><strong>Routing:</strong> React Router DOM v6</li>
        <li><strong>Charts:</strong> Recharts for data visualization</li>
        <li><strong>PDF Generation:</strong> jsPDF for document downloads</li>
        <li><strong>Date Handling:</strong> date-fns for date formatting</li>
        <li><strong>Notifications:</strong> Sonner for toast notifications</li>
      </ul>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">3. User Roles</h3>
      <ul className="list-disc pl-5 mt-3 space-y-2">
        <li><strong>Admin:</strong> Full system access including CRUD operations on all entities, configuration settings, and approval authority</li>
        <li><strong>Department Manager:</strong> Department-level compliance oversight, task management, and limited administrative functions</li>
        <li><strong>View Only:</strong> Read-only access to assigned compliance items, training requirements, and reports</li>
      </ul>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">4. Navigation Structure</h3>
      <div className="mt-3 p-4 bg-muted rounded-lg font-mono text-sm">
        <pre>{`MANAGEMENT HUB (collapsible section)
├── Dashboard (/)
├── Governing Body Org Chart (/org-chart)
├── Audit Items (/audits)
├── Enforcements (/enforcements)
├── Risk Management (/risks)
│   ├── Risks tab
│   ├── Policies & Procedures tab
│   ├── HIPAA tab
│   └── ADAA tab
├── Compliance Tracking (/compliance)
│   ├── Compliance Items tab
│   ├── Employee Files tab (with tooltip)
│   └── Training Statistics tab (with tooltip)
├── Feedback Management (/feedback)
│   ├── Feedback tab (with tooltip)
│   ├── Surveys tab (with tooltip)
│   └── Sentiment Analysis tab (with tooltip)
└── Documentation (/documentation)
    ├── PRD
    ├── TDD
    ├── QA Test Cases
    ├── UAT Test Cases
    └── System Prompt`}</pre>
      </div>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">5. Sidebar Design</h3>
      <ul className="list-disc pl-5 mt-3 space-y-1">
        <li>Dark navy blue background (hsl 215, 45%, 20%)</li>
        <li>MedComply logo with "Leadership Dashboard" subtitle</li>
        <li>Single collapsible "MANAGEMENT HUB" section with chevron toggle</li>
        <li>Navigation items with icons and text</li>
        <li>Active item highlighted in cyan (hsl 195, 80%, 60%)</li>
        <li>User profile footer with initials avatar</li>
      </ul>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">6. Key Features</h3>
      <div className="mt-3 space-y-4">
        <div>
          <h4 className="font-medium">6.1 Compliance Tracking</h4>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>Tabbed interface: Compliance Items, Employee Files, Training Statistics</li>
            <li>Full CRUD for Employee Files and Training records via modal dialogs</li>
            <li>Info tooltips explaining HR System and LMS integrations</li>
            <li>Dynamic metrics that update based on data changes</li>
            <li>Search functionality for filtering records</li>
          </ul>
        </div>
        <div>
          <h4 className="font-medium">6.2 Feedback Management</h4>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>Tabbed interface: Feedback, Surveys, Sentiment Analysis</li>
            <li>Category-based feedback organization</li>
            <li>Survey response rate tracking with progress bars</li>
            <li>Department-level sentiment scores with trend indicators</li>
            <li>Info tooltips explaining FeedbackHub integration</li>
          </ul>
        </div>
        <div>
          <h4 className="font-medium">6.3 Documentation</h4>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>Five document tabs: PRD, TDD, QA Test Cases, UAT Test Cases, System Prompt</li>
            <li>PDF download functionality for each document</li>
            <li>Comprehensive content reflecting current application state</li>
          </ul>
        </div>
      </div>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">7. External System Integrations</h3>
      <div className="mt-3">
        <table className="w-full text-sm border">
          <thead className="bg-muted">
            <tr>
              <th className="p-2 border text-left">System</th>
              <th className="p-2 border text-left">Purpose</th>
              <th className="p-2 border text-left">Dashboard Role</th>
            </tr>
          </thead>
          <tbody>
            <tr><td className="p-2 border">HR System</td><td className="p-2 border">Employee file storage</td><td className="p-2 border">Status tracking only</td></tr>
            <tr><td className="p-2 border">LMS</td><td className="p-2 border">Training course management</td><td className="p-2 border">Completion tracking</td></tr>
            <tr><td className="p-2 border">FeedbackHub</td><td className="p-2 border">Anonymous feedback collection</td><td className="p-2 border">Analytics & trends</td></tr>
            <tr><td className="p-2 border">EnforcePoint</td><td className="p-2 border">Policy enforcement</td><td className="p-2 border">Enforcement tracking</td></tr>
          </tbody>
        </table>
      </div>
    </section>

    <section>
      <h3 className="text-lg font-semibold border-b pb-2">8. UI/UX Requirements</h3>
      <ul className="list-disc pl-5 mt-3 space-y-1">
        <li>Modern, clean design with consistent spacing</li>
        <li>Status badges: green (success/completed), yellow (warning/pending), red (error/overdue)</li>
        <li>Interactive data tables with view/edit/delete actions</li>
        <li>Modal dialogs for create/edit/view operations</li>
        <li>Toast notifications for user feedback</li>
        <li>Progress bars for completion tracking</li>
        <li>Responsive design for various screen sizes</li>
        <li>Info icon tooltips for explaining integrations and data sources</li>
      </ul>
    </section>
  </div>
);

// Plain text content functions for PDF generation
const getPRDContent = () => `
PRODUCT REQUIREMENTS DOCUMENT (PRD)
MedComply HR Compliance Master Dashboard
Version 2.0

1. EXECUTIVE SUMMARY
The MedComply HR Compliance Master Dashboard is a comprehensive web-based application designed to centralize and streamline human resources compliance management for healthcare organizations. The system provides real-time visibility into compliance status, risk management, audit tracking, enforcement management, feedback collection, and training tracking across the organization.

2. PRODUCT VISION
To provide HR departments with a unified platform that simplifies compliance tracking, reduces regulatory risk, and ensures organizational adherence to federal, state, and industry-specific requirements including HIPAA, OSHA, and ADAA. The platform integrates with external systems (HR System, LMS, FeedbackHub) while providing centralized status tracking and reporting.

3. TARGET USERS
- Admin: Full system access, configuration, and approval authority
- Department Manager: Department-level compliance oversight and task management
- View Only User: Read-only access to assigned compliance items and training

4. CORE FEATURES

4.1 Dashboard (Management Hub)
- Action Center with task management and priority filtering
- Review Queue for pending approvals and sign-offs
- Quality KPIs with CRUD operations and formula-based calculations
- Quick Access to micro-applications
- Upcoming Deadlines section

4.2 Governing Body Org Chart
- Hierarchical organization structure display
- Member management with full CRUD operations
- Role and department assignments

4.3 Audit Management
- Audit item tracking and scheduling
- Audit findings documentation
- View and edit audit details

4.4 Enforcements
- Enforcement action tracking via EnforcePoint integration
- Priority-based enforcement management
- Status tracking (pending, completed, overdue)

4.5 Risk Management
- Risk Registry with severity levels (High, Medium, Low)
- Policies & Procedures management with CRUD operations
- HIPAA compliance tracking
- ADAA compliance tracking

4.6 Compliance Tracking (Tabbed Interface)
- Compliance Items tab with status tracking
- Employee Files tab - status tracking for files maintained in HR system
- Training Statistics tab - completion tracking for LMS-managed courses
- Full CRUD operations for Employee Files and Training records
- Tooltips explaining data sources and integrations

4.7 Feedback Management (Tabbed Interface)
- Feedback tab - track employee feedback by category
- Surveys tab - manage organizational surveys and response rates
- Sentiment Analysis tab - department-level satisfaction scores and trends
- Integration with FeedbackHub for anonymous collection

4.8 Documentation
- PRD, TDD, QA Test Cases, UAT Test Cases documents
- System Prompt documentation
- PDF download functionality for all documents

5. EXTERNAL SYSTEM INTEGRATIONS
- HR System: Employee files and personnel records storage
- LMS (Learning Management System): Training course management
- FeedbackHub: Anonymous feedback collection and sentiment analysis
- EnforcePoint: Policy enforcement and violation tracking

6. SUCCESS METRICS
- 95% compliance rate across all tracked items
- 90% training completion rate organization-wide
- 50% reduction in compliance-related incidents
- 100% on-time regulatory submission rate
- 4.5/5 average employee satisfaction score
`;

const getTDDContent = () => `
TECHNICAL DESIGN DOCUMENT (TDD)
MedComply HR Compliance Master Dashboard
Version 2.0

1. SYSTEM ARCHITECTURE
The MedComply HR Compliance Master Dashboard is built as a single-page application (SPA) using modern web technologies with a component-based architecture.

Technology Stack:
- Frontend: React 18, TypeScript, Vite
- Styling: Tailwind CSS, shadcn/ui components
- State Management: React Context API, React Query, useState hooks
- Routing: React Router DOM v6
- Charts: Recharts
- PDF Generation: jsPDF
- Date Handling: date-fns
- Notifications: Sonner toast library

2. COMPONENT STRUCTURE
src/
├── components/
│   ├── compliance/
│   │   ├── EmployeeFileFormDialog.tsx
│   │   ├── TrainingFormDialog.tsx
│   │   ├── ViewEmployeeFileDialog.tsx
│   │   ├── ViewTrainingDialog.tsx
│   │   └── DeleteConfirmDialog.tsx
│   ├── dashboard/
│   │   ├── AdminDashboard.tsx
│   │   ├── QualityKPIs.tsx
│   │   ├── DataTable.tsx
│   │   ├── MetricCard.tsx
│   │   └── StatusBadge.tsx
│   ├── layout/
│   │   ├── DashboardLayout.tsx
│   │   ├── Sidebar.tsx
│   │   └── Breadcrumb.tsx
│   └── ui/ (shadcn components)
├── pages/
│   ├── Index.tsx
│   ├── OrgChartPage.tsx
│   ├── AuditsPage.tsx
│   ├── EnforcementsPage.tsx
│   ├── RisksPage.tsx
│   ├── CompliancePage.tsx
│   ├── FeedbackManagementPage.tsx
│   └── DocumentationPage.tsx
└── contexts/
    └── RoleContext.tsx

3. DATA MODELS

EmployeeFile Model:
- id: string
- employeeName: string
- department: string
- fileType: string
- lastUpdated: string
- status: "active" | "pending" | "inactive"

TrainingRecord Model:
- id: string
- employeeName: string
- trainingType: string
- status: "completed" | "pending" | "overdue"
- completionDate: string

Feedback Model:
- id: string
- subject: string
- category: string
- status: "pending" | "completed" | "active"
- submittedDate: string
- priority: "high" | "medium" | "low"

Survey Model:
- id: string
- title: string
- status: "active" | "pending" | "completed"
- responses: number
- targetResponses: number
- dueDate: string

4. UI/UX DESIGN PATTERNS
- Dark navy sidebar with collapsible "Management Hub" navigation
- Tabbed interfaces for multi-section pages (Compliance, Feedback)
- Tooltips with info icons explaining data sources and integrations
- Modal dialogs for CRUD operations
- Toast notifications for user feedback
- Status badges with color coding
- Progress bars for completion tracking
- Responsive grid layouts

5. SECURITY CONSIDERATIONS
- Role-based access control (RBAC) via RoleContext
- Client-side route protection based on user roles
- Input validation using form validation
- XSS prevention through React's built-in escaping
`;

const getQAContent = () => `
QA TEST CASES DOCUMENT
MedComply HR Compliance Master Dashboard
Version 2.0

TEST SUMMARY
Total Test Cases: 58
Functional Tests: 42
UI/UX Tests: 10
Performance Tests: 6

---

TC-001: DASHBOARD LOADING
Priority: High
Precondition: User is authenticated
Steps:
1. Navigate to dashboard URL
2. Observe page load
Expected Result: Dashboard loads within 3 seconds with all components visible

---

TC-002: SIDEBAR NAVIGATION
Priority: High
Precondition: User is on any page
Steps:
1. Click Management Hub chevron to collapse/expand
2. Click each navigation item
3. Verify active state highlighting
Expected Result: Section collapses/expands, navigation works, active item highlighted in cyan

---

TC-003: EMPLOYEE FILE CRUD
Priority: High
Precondition: User is on Compliance Tracking > Employee Files tab
Steps:
1. Click Add Record button
2. Fill form fields (name, department, file type, status)
3. Save record
4. View record details via eye icon
5. Edit record via pencil icon
6. Delete record via trash icon with confirmation
Expected Result: All CRUD operations complete with toast notifications

---

TC-004: TRAINING RECORD CRUD
Priority: High
Precondition: User is on Compliance Tracking > Training Statistics tab
Steps:
1. Click Add Training button
2. Fill form with date picker
3. Save training record
4. Verify metrics update dynamically
5. Edit and delete records
Expected Result: CRUD operations work, metrics recalculate dynamically

---

TC-005: FEEDBACK MANAGEMENT TABS
Priority: Medium
Precondition: User navigates to Feedback Management
Steps:
1. Click Feedback tab
2. Click Surveys tab
3. Click Sentiment Analysis tab
4. Hover over info tooltips
Expected Result: Each tab displays correct content, tooltips show explanatory text

---

TC-006: TOOLTIP INFORMATION DISPLAY
Priority: Medium
Precondition: User is on Compliance Tracking page
Steps:
1. Hover over Employee Files info icon
2. Hover over Training Statistics info icon
3. Read tooltip content
Expected Result: Tooltips display explaining HR System and LMS integrations

---

TC-007: PDF DOWNLOAD
Priority: Medium
Precondition: User is on Documentation page
Steps:
1. Select each document tab (PRD, TDD, QA, UAT, System Prompt)
2. Click Download PDF button
Expected Result: PDF file downloads with correct content for each document type

---

TC-008: SEARCH FUNCTIONALITY
Priority: Medium
Precondition: User is on Employee Files or Feedback tab
Steps:
1. Type search term in search box
2. Observe filtered results
Expected Result: Table filters to show only matching records

---

TC-009: RESPONSIVE DESIGN
Priority: Medium
Steps:
1. Resize browser to mobile width (375px)
2. Resize to tablet width (768px)
3. Resize to desktop width (1440px)
Expected Result: Layout adapts correctly at each breakpoint

---

TC-010: ROLE SWITCHING
Priority: High
Precondition: User is on dashboard
Steps:
1. Click role switcher in header
2. Select different role (Admin/Department/View Only)
3. Observe dashboard changes
Expected Result: Dashboard content updates to reflect selected role permissions
`;

const getUATContent = () => `
UAT TEST CASES DOCUMENT
MedComply HR Compliance Master Dashboard
Version 2.0

UAT OVERVIEW
User Acceptance Testing scenarios designed to validate the MedComply HR Compliance Master Dashboard meets business requirements and user expectations.

Test Environment: Production-like staging environment
Test Duration: 2 weeks
Participants: HR Directors, Compliance Officers, Department Managers

---

UAT-001: END-TO-END COMPLIANCE WORKFLOW

Scenario:
As an HR Director, I need to track a new OSHA compliance requirement from creation to completion.

Acceptance Criteria:
- Can create new compliance item with all required fields
- Item appears in Action Center with correct priority
- Can assign to appropriate department manager
- Status updates reflect in real-time across dashboard
- Completion triggers removal from pending queue

Steps:
1. Login as Admin user
2. Navigate to Compliance Tracking
3. Click "Add Item" button
4. Enter compliance item details
5. Save and verify item appears
6. Update status to In Progress
7. Update status to Completed
8. Verify item moves to completed section

Pass/Fail: ___________
Tester: _______________
Date: ________________

---

UAT-002: EMPLOYEE FILE MANAGEMENT

Scenario:
As an HR Manager, I need to track employee file status while understanding files are stored in the HR System.

Acceptance Criteria:
- Tooltip clearly explains files are maintained in HR System
- Can add new employee file tracking record
- Can view, edit, and delete file records
- Category counts display correctly
- Search filters employee records accurately

Steps:
1. Navigate to Compliance Tracking > Employee Files
2. Hover over info icon to read tooltip
3. Click Add Record
4. Fill in employee details
5. Save and verify record appears
6. Use view, edit, delete actions
7. Test search functionality

Pass/Fail: ___________
Tester: _______________
Date: ________________

---

UAT-003: TRAINING COMPLIANCE MONITORING

Scenario:
As a Department Manager, I need to monitor training completion while understanding courses are managed in LMS.

Acceptance Criteria:
- Tooltip explains LMS integration for course management
- Training Statistics tab shows accurate completion rates
- Can add training records with date picker
- Metrics update dynamically when records change
- Training type breakdown displays correctly

Steps:
1. Navigate to Compliance Tracking > Training Statistics
2. Verify tooltip explains LMS integration
3. Add new training record with date
4. Verify metrics update
5. Check completion rate calculation
6. Review training type breakdown

Pass/Fail: ___________
Tester: _______________
Date: ________________

---

UAT-004: FEEDBACK MANAGEMENT WORKFLOW

Scenario:
As an HR Director, I need to review employee feedback and sentiment trends across departments.

Acceptance Criteria:
- Feedback tab shows categorized feedback with priority levels
- Surveys tab displays response rates and survey status
- Sentiment Analysis shows department scores and trends
- Tooltips explain FeedbackHub integration
- Can search and filter feedback records

Steps:
1. Navigate to Feedback Management
2. Review Feedback tab with categories
3. Check Surveys tab for response rates
4. View Sentiment Analysis department scores
5. Verify trend indicators (up/down/neutral)
6. Test search functionality

Pass/Fail: ___________
Tester: _______________
Date: ________________

---

UAT-005: NAVIGATION AND UI CONSISTENCY

Scenario:
As any user, I need consistent navigation and UI patterns across all pages.

Acceptance Criteria:
- Sidebar collapses/expands Management Hub section
- Active navigation item is clearly highlighted
- All pages follow consistent layout patterns
- Status badges use consistent color coding
- Toast notifications appear for all actions

Steps:
1. Click Management Hub chevron to toggle
2. Navigate through all menu items
3. Verify active state styling
4. Check page layouts are consistent
5. Perform actions and verify toasts

Pass/Fail: ___________
Tester: _______________
Date: ________________

---

SIGN-OFF

Business Owner: _________________________
Signature: ______________________________
Date: __________________________________

QA Lead: _______________________________
Signature: ______________________________
Date: __________________________________

Project Manager: ________________________
Signature: ______________________________
Date: __________________________________
`;

const getPromptContent = () => `
MEDCOMPLY HR COMPLIANCE MASTER DASHBOARD - SYSTEM PROMPT
Final Version 2.0

1. APPLICATION OVERVIEW
Build a MedComply HR Compliance Master Dashboard - a comprehensive web-based application for healthcare HR compliance management. The system provides real-time visibility into compliance status, risk management, audit tracking, enforcement management, feedback collection, and training tracking. The dashboard serves as a central hub that integrates with external systems (HR System, LMS, FeedbackHub, EnforcePoint) while providing unified status tracking.

2. TECHNOLOGY STACK
- Frontend Framework: React 18 with TypeScript
- Build Tool: Vite
- Styling: Tailwind CSS with shadcn/ui component library
- State Management: React Context API for role management, useState for local state
- Routing: React Router DOM v6
- Charts: Recharts for data visualization
- PDF Generation: jsPDF for document downloads
- Date Handling: date-fns for date formatting
- Notifications: Sonner for toast notifications

3. USER ROLES
- Admin: Full system access including CRUD operations on all entities, configuration settings, and approval authority
- Department Manager: Department-level compliance oversight, task management, and limited administrative functions
- View Only: Read-only access to assigned compliance items, training requirements, and reports

4. NAVIGATION STRUCTURE
MANAGEMENT HUB (collapsible section)
├── Dashboard (/)
├── Governing Body Org Chart (/org-chart)
├── Audit Items (/audits)
├── Enforcements (/enforcements)
├── Risk Management (/risks)
├── Compliance Tracking (/compliance)
│   ├── Compliance Items tab
│   ├── Employee Files tab (with tooltip)
│   └── Training Statistics tab (with tooltip)
├── Feedback Management (/feedback)
│   ├── Feedback tab (with tooltip)
│   ├── Surveys tab (with tooltip)
│   └── Sentiment Analysis tab (with tooltip)
└── Documentation (/documentation)

5. SIDEBAR DESIGN
- Dark navy blue background (hsl 215, 45%, 20%)
- MedComply logo with "Leadership Dashboard" subtitle
- Single collapsible "MANAGEMENT HUB" section with chevron toggle
- Navigation items with icons and text
- Active item highlighted in cyan (hsl 195, 80%, 60%)
- User profile footer with initials avatar

6. KEY FEATURES

6.1 Compliance Tracking
- Tabbed interface: Compliance Items, Employee Files, Training Statistics
- Full CRUD for Employee Files and Training records via modal dialogs
- Info tooltips explaining HR System and LMS integrations
- Dynamic metrics that update based on data changes
- Search functionality for filtering records

6.2 Feedback Management
- Tabbed interface: Feedback, Surveys, Sentiment Analysis
- Category-based feedback organization
- Survey response rate tracking with progress bars
- Department-level sentiment scores with trend indicators
- Info tooltips explaining FeedbackHub integration

6.3 Documentation
- Five document tabs: PRD, TDD, QA Test Cases, UAT Test Cases, System Prompt
- PDF download functionality for each document
- Comprehensive content reflecting current application state

7. EXTERNAL SYSTEM INTEGRATIONS
- HR System: Employee file storage (dashboard tracks status only)
- LMS: Training course management (dashboard tracks completion)
- FeedbackHub: Anonymous feedback collection (dashboard shows analytics)
- EnforcePoint: Policy enforcement (dashboard tracks status)

8. UI/UX REQUIREMENTS
- Modern, clean design with consistent spacing
- Status badges: green (success/completed), yellow (warning/pending), red (error/overdue)
- Interactive data tables with view/edit/delete actions
- Modal dialogs for create/edit/view operations
- Toast notifications for user feedback
- Progress bars for completion tracking
- Responsive design for various screen sizes
- Info icon tooltips for explaining integrations and data sources
`;

export default DocumentationPage;
