import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useNavigate, useParams } from "react-router-dom";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { ArrowLeft, ClipboardCheck } from "lucide-react";

interface AuditItem {
  id: string;
  title: string;
  status: "pending" | "completed" | "overdue";
  deadline: string;
  owner: string;
  priority: "high" | "medium" | "low";
  description?: string;
  notes?: string;
}

const auditsData: AuditItem[] = [
  { id: "AUD-001", title: "Annual HIPAA Compliance Review", status: "pending", deadline: "Dec 20, 2024", owner: "Sarah Johnson", priority: "high", description: "Comprehensive annual review of HIPAA compliance across all departments, including privacy practices, security measures, and employee training verification." },
  { id: "AUD-002", title: "Workplace Safety Inspection", status: "completed", deadline: "Dec 15, 2024", owner: "Mike Chen", priority: "medium", description: "Routine inspection of workplace safety protocols, emergency exits, fire extinguishers, and first aid stations." },
  { id: "AUD-003", title: "Employee Records Audit", status: "overdue", deadline: "Dec 10, 2024", owner: "Emily Davis", priority: "high", description: "Audit of all employee records for completeness, accuracy, and compliance with retention policies." },
  { id: "AUD-004", title: "Training Compliance Check", status: "pending", deadline: "Dec 28, 2024", owner: "John Smith", priority: "medium", description: "Verification that all required training has been completed by staff within mandated timeframes." },
  { id: "AUD-005", title: "IT Security Assessment", status: "completed", deadline: "Dec 12, 2024", owner: "Lisa Wang", priority: "high", description: "Assessment of IT infrastructure security, including access controls, data encryption, and vulnerability scanning." },
  { id: "AUD-006", title: "Background Check Verification", status: "pending", deadline: "Jan 5, 2025", owner: "Robert Brown", priority: "low", description: "Verification that all new hires have completed required background checks." },
];

const statuses = ["pending", "completed", "overdue"] as const;
const priorities = ["high", "medium", "low"] as const;

const AuditEditPage = () => {
  const { auditId } = useParams();
  const navigate = useNavigate();
  
  const existingAudit = auditsData.find(a => a.id === auditId);

  const [formData, setFormData] = useState({
    title: "",
    status: "pending" as "pending" | "completed" | "overdue",
    deadline: "",
    owner: "",
    priority: "medium" as "high" | "medium" | "low",
    description: "",
    notes: "",
  });

  useEffect(() => {
    if (existingAudit) {
      setFormData({
        title: existingAudit.title,
        status: existingAudit.status,
        deadline: existingAudit.deadline,
        owner: existingAudit.owner,
        priority: existingAudit.priority,
        description: existingAudit.description || "",
        notes: existingAudit.notes || "",
      });
    }
  }, [existingAudit]);

  if (!existingAudit) {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center py-12">
          <ClipboardCheck className="h-12 w-12 text-muted-foreground mb-4" />
          <h2 className="text-xl font-semibold mb-2">Audit Not Found</h2>
          <p className="text-muted-foreground mb-4">The audit you're looking for doesn't exist.</p>
          <Button onClick={() => navigate("/audits")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Audits
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success(`Audit "${formData.title}" updated successfully`);
    navigate("/audits");
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-3xl">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/audits")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Edit: {existingAudit.title}</h1>
            <p className="text-muted-foreground">Update audit information</p>
          </div>
        </div>

        {/* Form */}
        <Card>
          <CardHeader>
            <CardTitle>Audit Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Enter audit title"
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Status *</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value as typeof formData.status })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      {statuses.map((status) => (
                        <SelectItem key={status} value={status} className="capitalize">{status}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Priority *</Label>
                  <Select
                    value={formData.priority}
                    onValueChange={(value) => setFormData({ ...formData, priority: value as typeof formData.priority })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      {priorities.map((priority) => (
                        <SelectItem key={priority} value={priority} className="capitalize">{priority}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="owner">Owner *</Label>
                  <Input
                    id="owner"
                    value={formData.owner}
                    onChange={(e) => setFormData({ ...formData, owner: e.target.value })}
                    placeholder="Audit owner"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="deadline">Deadline *</Label>
                  <Input
                    id="deadline"
                    value={formData.deadline}
                    onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                    placeholder="e.g., Dec 20, 2024"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Enter audit description"
                  rows={4}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Additional notes (optional)"
                  rows={3}
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button type="button" variant="outline" onClick={() => navigate("/audits")}>
                  Cancel
                </Button>
                <Button type="submit">
                  Save Changes
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default AuditEditPage;
