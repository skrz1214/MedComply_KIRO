import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { SectionHeader } from "@/components/dashboard/SectionHeader";
import { DataTable, Column } from "@/components/dashboard/DataTable";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { FileWarning, Clock, CheckCircle, AlertTriangle, Link2 } from "lucide-react";
import { toast } from "sonner";

interface PlanOfCorrection {
  id: string;
  title: string;
  linkedTo: string;
  linkedType: string;
  status: "pending" | "completed" | "overdue" | "active";
  dueDate: string;
  owner: string;
  lastUpdate: string;
}

const pocData: PlanOfCorrection[] = [
  { id: "POC-001", title: "HIPAA Training Gap Remediation", linkedTo: "AUD-003", linkedType: "Audit", status: "active", dueDate: "Dec 28, 2024", owner: "Training Dept", lastUpdate: "Dec 12, 2024" },
  { id: "POC-002", title: "Workplace Safety Violation Correction", linkedTo: "ENF-002", linkedType: "Enforcement", status: "completed", dueDate: "Dec 10, 2024", owner: "Safety Officer", lastUpdate: "Dec 10, 2024" },
  { id: "POC-003", title: "Credential Verification Process Update", linkedTo: "RSK-004", linkedType: "Risk", status: "pending", dueDate: "Jan 5, 2025", owner: "HR Ops", lastUpdate: "Dec 8, 2024" },
  { id: "POC-004", title: "IT Security Vulnerability Patch", linkedTo: "RSK-001", linkedType: "Risk", status: "active", dueDate: "Dec 22, 2024", owner: "IT Security", lastUpdate: "Dec 11, 2024" },
  { id: "POC-005", title: "Patient Data Handling Protocol", linkedTo: "CMP-002", linkedType: "Compliance", status: "overdue", dueDate: "Dec 5, 2024", owner: "Privacy Officer", lastUpdate: "Dec 1, 2024" },
  { id: "POC-006", title: "Emergency Response Training Update", linkedTo: "AUD-004", linkedType: "Audit", status: "pending", dueDate: "Jan 15, 2025", owner: "Training Dept", lastUpdate: "Dec 10, 2024" },
];

const columns: Column<PlanOfCorrection>[] = [
  { key: "id", header: "POC ID", className: "font-mono text-sm" },
  { key: "title", header: "Title" },
  {
    key: "linkedTo",
    header: "Linked To",
    render: (item) => (
      <span className="inline-flex items-center gap-1 text-primary hover:underline cursor-pointer">
        <Link2 className="h-3 w-3" />
        {item.linkedTo} ({item.linkedType})
      </span>
    ),
  },
  { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
  { key: "dueDate", header: "Due Date" },
  { key: "owner", header: "Owner" },
  { key: "lastUpdate", header: "Last Update" },
  { key: "actions", header: "Actions" },
];

const CorrectionsPage = () => {
  return (
    <DashboardLayout>
      <SectionHeader
        title="Plan of Correction"
        description="View, manage, and update corrective action plans with full audit trail"
        actionLabel="Add POC"
        onAction={() => toast.info("Opening plan of correction form...")}
      />

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="metric-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="metric-label">Total POCs</p>
              <p className="metric-value">24</p>
            </div>
            <div className="p-2.5 rounded-lg bg-primary/10 text-primary">
              <FileWarning className="h-5 w-5" />
            </div>
          </div>
        </div>
        <div className="metric-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="metric-label">In Progress</p>
              <p className="metric-value">8</p>
            </div>
            <div className="p-2.5 rounded-lg bg-info/10 text-info">
              <Clock className="h-5 w-5" />
            </div>
          </div>
        </div>
        <div className="metric-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="metric-label">Completed</p>
              <p className="metric-value">14</p>
            </div>
            <div className="p-2.5 rounded-lg bg-success/10 text-success">
              <CheckCircle className="h-5 w-5" />
            </div>
          </div>
        </div>
        <div className="metric-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="metric-label">Overdue</p>
              <p className="metric-value">2</p>
            </div>
            <div className="p-2.5 rounded-lg bg-destructive/10 text-destructive">
              <AlertTriangle className="h-5 w-5" />
            </div>
          </div>
        </div>
      </div>

      {/* Update History Info */}
      <div className="bg-muted/50 rounded-lg p-4 mb-6 border border-border">
        <p className="text-sm text-muted-foreground">
          <strong>Audit Trail:</strong> All plan of correction updates are logged with timestamps and user information for compliance tracking. Click on any POC to view its complete update history.
        </p>
      </div>

      <DataTable
        columns={columns}
        data={pocData}
        onView={(item) => toast.info(`Viewing POC: ${item.title}`)}
        onEdit={(item) => toast.info(`Editing POC: ${item.id}`)}
        onDelete={(item) => toast.error(`Deleted POC: ${item.id}`)}
      />
    </DashboardLayout>
  );
};

export default CorrectionsPage;
