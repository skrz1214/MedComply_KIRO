import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { SectionHeader } from "@/components/dashboard/SectionHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Users, Search, MessageSquare, Eye, Edit, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { MessageDialog } from "@/components/org-chart/MessageDialog";
import { ViewMemberDialog } from "@/components/org-chart/ViewMemberDialog";
import { MemberFormDialog } from "@/components/org-chart/MemberFormDialog";
import { DeleteMemberDialog } from "@/components/org-chart/DeleteMemberDialog";

interface OrgMember {
  id: string;
  name: string;
  initials: string;
  title: string;
  department: string;
  role: string;
  email: string;
  isHead?: boolean;
  reportsTo?: string;
}

const initialMembers: OrgMember[] = [
  { id: "1", name: "Dr. Sarah Johnson", initials: "DSJ", title: "Chief HR Officer", department: "Human Resources", role: "Executive", email: "sarah.j@hospital.org", isHead: true },
  { id: "2", name: "Michael Chen", initials: "MC", title: "VP of HR Operations", department: "HR Operations", role: "Executive", email: "m.chen@hospital.org", reportsTo: "1" },
  { id: "3", name: "Patricia Williams", initials: "PW", title: "Director of Training", department: "Training", role: "Director", email: "p.williams@hospital.org", reportsTo: "1" },
  { id: "4", name: "Robert Martinez", initials: "RM", title: "Employee Relations Manager", department: "Employee Relations", role: "Manager", email: "r.martinez@hospital.org", reportsTo: "2" },
  { id: "5", name: "Jennifer Lee", initials: "JL", title: "Compliance Manager", department: "HR Compliance", role: "Manager", email: "j.lee@hospital.org", reportsTo: "2" },
  { id: "6", name: "David Thompson", initials: "DT", title: "Benefits Administrator", department: "Benefits", role: "Officer", email: "d.thompson@hospital.org", reportsTo: "3" },
];

const OrgChartPage = () => {
  const [members, setMembers] = useState<OrgMember[]>(initialMembers);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedMember, setSelectedMember] = useState<OrgMember | null>(null);

  // Dialog states
  const [messageDialogOpen, setMessageDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [formDialogOpen, setFormDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [formMode, setFormMode] = useState<"add" | "edit">("add");

  // Build hierarchy
  const headMember = members.find((m) => m.isHead);
  const getDirectReports = (managerId: string) => 
    members.filter((m) => m.reportsTo === managerId);

  const filteredMembers = members.filter(
    (member) =>
      member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleMessage = (member: OrgMember) => {
    setSelectedMember(member);
    setMessageDialogOpen(true);
  };

  const handleView = (member: OrgMember) => {
    setSelectedMember(member);
    setViewDialogOpen(true);
  };

  const handleEdit = (member: OrgMember) => {
    setSelectedMember(member);
    setFormMode("edit");
    setFormDialogOpen(true);
  };

  const handleDelete = (member: OrgMember) => {
    setSelectedMember(member);
    setDeleteDialogOpen(true);
  };

  const handleAddMember = () => {
    setSelectedMember(null);
    setFormMode("add");
    setFormDialogOpen(true);
  };

  const handleSaveMember = (member: OrgMember) => {
    if (formMode === "add") {
      setMembers([...members, member]);
    } else {
      setMembers(members.map((m) => (m.id === member.id ? member : m)));
    }
  };

  const handleConfirmDelete = () => {
    if (selectedMember) {
      setMembers(members.filter((m) => m.id !== selectedMember.id));
      toast.success(`${selectedMember.name} has been removed`);
      setDeleteDialogOpen(false);
      setSelectedMember(null);
    }
  };

  const getManagerName = (managerId?: string) => {
    if (!managerId) return undefined;
    const manager = members.find((m) => m.id === managerId);
    return manager?.name;
  };

  // Render org chart node
  const renderOrgNode = (member: OrgMember, isHead: boolean = false) => {
    const reports = getDirectReports(member.id);

    return (
      <div key={member.id} className="flex flex-col items-center">
        <div
          className={cn(
            "px-5 py-3 rounded-lg border bg-card text-center min-w-[180px] cursor-pointer transition-all hover:shadow-md",
            isHead ? "border-2 border-primary shadow-md" : "border-border hover:border-primary/30"
          )}
          onClick={() => handleView(member)}
        >
          <p className={cn("font-medium", isHead && "text-primary")}>{member.name}</p>
          <p className="text-sm text-muted-foreground">{member.title}</p>
        </div>

        {reports.length > 0 && (
          <>
            <div className="w-px h-4 bg-border" />
            <div className="relative">
              {reports.length > 1 && (
                <div 
                  className="absolute top-0 left-1/2 -translate-x-1/2 h-px bg-border"
                  style={{ width: `${(reports.length - 1) * 200}px` }}
                />
              )}
              <div className="flex gap-4">
                {reports.map((report) => (
                  <div key={report.id} className="flex flex-col items-center">
                    <div className="w-px h-4 bg-border" />
                    {renderOrgNode(report)}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    );
  };

  return (
    <DashboardLayout>
      <SectionHeader
        title="Org Chart"
        description="View and manage organizational leadership structure"
        actionLabel="Add Member"
        onAction={handleAddMember}
      />

      {/* Visual Org Chart */}
      <div className="bg-card rounded-xl border border-border p-6 mb-6 overflow-x-auto">
        <div className="flex items-center gap-2 mb-6">
          <Users className="h-5 w-5 text-primary" />
          <h2 className="font-display text-lg font-semibold">Organization Structure</h2>
        </div>

        <div className="flex justify-center min-w-max pb-4">
          {headMember && renderOrgNode(headMember, true)}
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name, title, or department..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* Members Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/50 border-b border-border">
              <tr>
                <th className="text-left font-medium text-muted-foreground py-3 px-4">Name</th>
                <th className="text-left font-medium text-muted-foreground py-3 px-4">Title</th>
                <th className="text-left font-medium text-muted-foreground py-3 px-4">Department</th>
                <th className="text-left font-medium text-muted-foreground py-3 px-4">Role</th>
                <th className="text-left font-medium text-muted-foreground py-3 px-4">Email</th>
                <th className="text-left font-medium text-muted-foreground py-3 px-4">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredMembers.map((member) => (
                <tr key={member.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-primary/10 text-primary text-xs font-semibold flex items-center justify-center">
                        {member.initials}
                      </div>
                      <span className="font-medium">{member.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-muted-foreground">{member.title}</td>
                  <td className="py-3 px-4 text-muted-foreground">{member.department}</td>
                  <td className="py-3 px-4">
                    <span className={cn(
                      "px-2 py-0.5 rounded text-xs font-medium",
                      member.role === "Executive" && "bg-primary/10 text-primary",
                      member.role === "Director" && "bg-info/10 text-info",
                      member.role === "Manager" && "bg-warning/10 text-warning",
                      member.role === "Officer" && "bg-muted text-muted-foreground",
                      member.role === "Staff" && "bg-muted text-muted-foreground"
                    )}>
                      {member.role}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-muted-foreground">{member.email}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleMessage(member)}
                      >
                        <MessageSquare className="h-4 w-4 text-muted-foreground" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleView(member)}
                      >
                        <Eye className="h-4 w-4 text-muted-foreground" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleEdit(member)}
                      >
                        <Edit className="h-4 w-4 text-muted-foreground" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleDelete(member)}
                      >
                        <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredMembers.length === 0 && (
          <div className="p-8 text-center text-muted-foreground">
            No members found matching your search
          </div>
        )}
      </div>

      {/* Dialogs */}
      <MessageDialog
        open={messageDialogOpen}
        onOpenChange={setMessageDialogOpen}
        recipientName={selectedMember?.name || ""}
        recipientEmail={selectedMember?.email || ""}
      />

      <ViewMemberDialog
        open={viewDialogOpen}
        onOpenChange={setViewDialogOpen}
        member={selectedMember ? { ...selectedMember, reportsTo: getManagerName(selectedMember.reportsTo) } : null}
      />

      <MemberFormDialog
        open={formDialogOpen}
        onOpenChange={setFormDialogOpen}
        member={selectedMember}
        members={members}
        onSave={handleSaveMember}
        mode={formMode}
      />

      <DeleteMemberDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        member={selectedMember}
        onConfirm={handleConfirmDelete}
      />
    </DashboardLayout>
  );
};

export default OrgChartPage;
