import { useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { DataTable, Column } from "@/components/dashboard/DataTable";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { UpcomingDeadlines } from "@/components/dashboard/UpcomingDeadlines";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  CheckCircle, Clock, AlertTriangle, FileCheck, 
  Search, FileText, Shield, GraduationCap, Heart, Plus, Info 
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { toast } from "sonner";

// Import dialogs
import { EmployeeFileFormDialog, EmployeeFile } from "@/components/compliance/EmployeeFileFormDialog";
import { ViewEmployeeFileDialog } from "@/components/compliance/ViewEmployeeFileDialog";
import { TrainingFormDialog, TrainingRecord } from "@/components/compliance/TrainingFormDialog";
import { ViewTrainingDialog } from "@/components/compliance/ViewTrainingDialog";
import { DeleteConfirmDialog } from "@/components/compliance/DeleteConfirmDialog";

// Compliance Item Types
interface ComplianceItem {
  id: string;
  description: string;
  status: "pending" | "completed" | "overdue";
  owner: string;
}

const complianceData: ComplianceItem[] = [
  { id: "CMP-001", description: "Annual OSHA Certification Renewal", status: "completed", owner: "Safety Officer" },
  { id: "CMP-002", description: "State Healthcare License Review", status: "pending", owner: "Compliance Director" },
  { id: "CMP-003", description: "Joint Commission Accreditation", status: "pending", owner: "Quality Assurance" },
  { id: "CMP-004", description: "Medicare/Medicaid Compliance Audit", status: "overdue", owner: "Billing Compliance" },
  { id: "CMP-005", description: "Fire Safety Inspection Certificate", status: "completed", owner: "Facilities Manager" },
  { id: "CMP-006", description: "DEA License Verification", status: "pending", owner: "Pharmacy Director" },
  { id: "CMP-007", description: "Employee I-9 Compliance Check", status: "completed", owner: "HR Operations" },
  { id: "CMP-008", description: "CLIA Laboratory Certification", status: "pending", owner: "Lab Director" },
];

const complianceColumns: Column<ComplianceItem>[] = [
  { key: "id", header: "Compliance ID", className: "font-mono text-sm" },
  { key: "description", header: "Description" },
  { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
  { key: "owner", header: "Owner" },
  { key: "actions", header: "Actions" },
];

const deadlines = [
  { id: "1", title: "State Healthcare License Review", dueDate: "Dec 28, 2024", type: "Compliance", priority: "high" as const },
  { id: "2", title: "Joint Commission Accreditation", dueDate: "Jan 15, 2025", type: "Compliance", priority: "high" as const },
  { id: "3", title: "DEA License Verification", dueDate: "Jan 20, 2025", type: "Compliance", priority: "medium" as const },
];

// Initial Employee Files Data
const initialEmployeeFiles: EmployeeFile[] = [
  { id: "EF-001", employeeName: "Sarah Johnson", department: "Nursing", fileType: "Personnel", lastUpdated: "Dec 10, 2024", status: "active" },
  { id: "EF-002", employeeName: "Mike Chen", department: "IT", fileType: "Training", lastUpdated: "Dec 8, 2024", status: "active" },
  { id: "EF-003", employeeName: "Emily Davis", department: "Administration", fileType: "Credentials", lastUpdated: "Dec 5, 2024", status: "pending" },
  { id: "EF-004", employeeName: "John Smith", department: "Pharmacy", fileType: "Licenses", lastUpdated: "Dec 3, 2024", status: "active" },
  { id: "EF-005", employeeName: "Lisa Wang", department: "Lab", fileType: "Certifications", lastUpdated: "Nov 28, 2024", status: "active" },
  { id: "EF-006", employeeName: "Robert Brown", department: "Maintenance", fileType: "Safety", lastUpdated: "Nov 25, 2024", status: "inactive" },
];

const employeeColumns: Column<EmployeeFile>[] = [
  { key: "employeeName", header: "Employee Name" },
  { key: "department", header: "Department" },
  { key: "fileType", header: "File Type" },
  { key: "lastUpdated", header: "Last Updated" },
  { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
  { key: "actions", header: "Actions" },
];

const fileCategories = [
  { label: "Personnel Records", count: 1248, icon: FileText, color: "text-primary bg-primary/10" },
  { label: "Training Records", count: 856, icon: GraduationCap, color: "text-info bg-info/10" },
  { label: "Credentials & Licenses", count: 432, icon: Shield, color: "text-warning bg-warning/10" },
  { label: "Benefits & Insurance", count: 1248, icon: Heart, color: "text-success bg-success/10" },
];

// Initial Training Data
const initialTrainingData: TrainingRecord[] = [
  { id: "TR-001", employeeName: "Sarah Johnson", trainingType: "HIPAA Privacy", status: "completed", completionDate: "Nov 28, 2024" },
  { id: "TR-002", employeeName: "Mike Chen", trainingType: "Workplace Safety", status: "completed", completionDate: "Nov 25, 2024" },
  { id: "TR-003", employeeName: "Emily Davis", trainingType: "Harassment Prevention", status: "pending", completionDate: "Dec 20, 2024" },
  { id: "TR-004", employeeName: "John Smith", trainingType: "Infection Control", status: "overdue", completionDate: "Dec 1, 2024" },
  { id: "TR-005", employeeName: "Lisa Wang", trainingType: "Emergency Procedures", status: "completed", completionDate: "Nov 20, 2024" },
  { id: "TR-006", employeeName: "Robert Brown", trainingType: "OSHA Compliance", status: "pending", completionDate: "Dec 28, 2024" },
];

const trainingColumns: Column<TrainingRecord>[] = [
  { key: "employeeName", header: "Employee Name" },
  { key: "trainingType", header: "Training Type" },
  { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
  { key: "completionDate", header: "Completion Date" },
  { key: "actions", header: "Actions" },
];

const CompliancePage = () => {
  const [activeTab, setActiveTab] = useState("compliance");
  const [employeeSearchTerm, setEmployeeSearchTerm] = useState("");
  
  // Employee Files State
  const [employeeFiles, setEmployeeFiles] = useState<EmployeeFile[]>(initialEmployeeFiles);
  const [employeeFileDialogOpen, setEmployeeFileDialogOpen] = useState(false);
  const [employeeFileMode, setEmployeeFileMode] = useState<"add" | "edit">("add");
  const [selectedEmployeeFile, setSelectedEmployeeFile] = useState<EmployeeFile | null>(null);
  const [viewEmployeeFileDialogOpen, setViewEmployeeFileDialogOpen] = useState(false);
  const [deleteEmployeeFileDialogOpen, setDeleteEmployeeFileDialogOpen] = useState(false);

  // Training State
  const [trainingData, setTrainingData] = useState<TrainingRecord[]>(initialTrainingData);
  const [trainingDialogOpen, setTrainingDialogOpen] = useState(false);
  const [trainingMode, setTrainingMode] = useState<"add" | "edit">("add");
  const [selectedTraining, setSelectedTraining] = useState<TrainingRecord | null>(null);
  const [viewTrainingDialogOpen, setViewTrainingDialogOpen] = useState(false);
  const [deleteTrainingDialogOpen, setDeleteTrainingDialogOpen] = useState(false);
  
  const completionRate = Math.round((trainingData.filter(t => t.status === "completed").length / trainingData.length) * 100);

  const filteredEmployeeFiles = employeeFiles.filter(
    (file) =>
      file.employeeName.toLowerCase().includes(employeeSearchTerm.toLowerCase()) ||
      file.department.toLowerCase().includes(employeeSearchTerm.toLowerCase())
  );

  // Employee File Handlers
  const handleAddEmployeeFile = () => {
    setEmployeeFileMode("add");
    setSelectedEmployeeFile(null);
    setEmployeeFileDialogOpen(true);
  };

  const handleEditEmployeeFile = (file: EmployeeFile) => {
    setEmployeeFileMode("edit");
    setSelectedEmployeeFile(file);
    setEmployeeFileDialogOpen(true);
  };

  const handleViewEmployeeFile = (file: EmployeeFile) => {
    setSelectedEmployeeFile(file);
    setViewEmployeeFileDialogOpen(true);
  };

  const handleDeleteEmployeeFile = (file: EmployeeFile) => {
    setSelectedEmployeeFile(file);
    setDeleteEmployeeFileDialogOpen(true);
  };

  const handleSaveEmployeeFile = (file: EmployeeFile) => {
    if (employeeFileMode === "add") {
      setEmployeeFiles([...employeeFiles, file]);
    } else {
      setEmployeeFiles(employeeFiles.map(f => f.id === file.id ? file : f));
    }
  };

  const confirmDeleteEmployeeFile = () => {
    if (selectedEmployeeFile) {
      setEmployeeFiles(employeeFiles.filter(f => f.id !== selectedEmployeeFile.id));
      toast.success(`Employee file for ${selectedEmployeeFile.employeeName} deleted`);
      setDeleteEmployeeFileDialogOpen(false);
      setSelectedEmployeeFile(null);
    }
  };

  // Training Handlers
  const handleAddTraining = () => {
    setTrainingMode("add");
    setSelectedTraining(null);
    setTrainingDialogOpen(true);
  };

  const handleEditTraining = (training: TrainingRecord) => {
    setTrainingMode("edit");
    setSelectedTraining(training);
    setTrainingDialogOpen(true);
  };

  const handleViewTraining = (training: TrainingRecord) => {
    setSelectedTraining(training);
    setViewTrainingDialogOpen(true);
  };

  const handleDeleteTraining = (training: TrainingRecord) => {
    setSelectedTraining(training);
    setDeleteTrainingDialogOpen(true);
  };

  const handleSaveTraining = (training: TrainingRecord) => {
    if (trainingMode === "add") {
      setTrainingData([...trainingData, training]);
    } else {
      setTrainingData(trainingData.map(t => t.id === training.id ? training : t));
    }
  };

  const confirmDeleteTraining = () => {
    if (selectedTraining) {
      setTrainingData(trainingData.filter(t => t.id !== selectedTraining.id));
      toast.success(`Training record for ${selectedTraining.employeeName} deleted`);
      setDeleteTrainingDialogOpen(false);
      setSelectedTraining(null);
    }
  };

  // Calculate metrics
  const completedTraining = trainingData.filter(t => t.status === "completed").length;
  const pendingTraining = trainingData.filter(t => t.status === "pending").length;
  const overdueTraining = trainingData.filter(t => t.status === "overdue").length;

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold text-foreground">Compliance Tracking</h1>
        <p className="text-muted-foreground mt-1">
          Track compliance items, employee files, and training statistics
        </p>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="compliance">Compliance Items</TabsTrigger>
          <TabsTrigger value="employee-files" className="gap-1.5">
            Employee Files
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-3.5 w-3.5 text-muted-foreground hover:text-foreground transition-colors" />
                </TooltipTrigger>
                <TooltipContent side="bottom" className="max-w-xs">
                  <p className="font-medium mb-1">Employee Files</p>
                  <p className="text-xs text-muted-foreground">
                    All employee documents are maintained in the HR system. This section provides 
                    tracking and status monitoring for personnel records, training certifications, 
                    licenses, and credentials to ensure compliance requirements are met.
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </TabsTrigger>
          <TabsTrigger value="training" className="gap-1.5">
            Training Statistics
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-3.5 w-3.5 text-muted-foreground hover:text-foreground transition-colors" />
                </TooltipTrigger>
                <TooltipContent side="bottom" className="max-w-xs">
                  <p className="font-medium mb-1">Training Statistics</p>
                  <p className="text-xs text-muted-foreground">
                    All training courses are managed through the Learning Management System (LMS). 
                    This section tracks completion rates, pending requirements, and overdue trainings 
                    to ensure organizational compliance with mandatory training programs.
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </TabsTrigger>
        </TabsList>

        {/* Compliance Items Tab */}
        <TabsContent value="compliance" className="space-y-6">
          {/* Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricCard title="Total Items" value={156} icon={FileCheck} variant="primary" />
            <MetricCard title="Pending Review" value={32} icon={Clock} variant="warning" />
            <MetricCard title="Completed" value={118} icon={CheckCircle} variant="success" />
            <MetricCard title="Overdue" value={6} icon={AlertTriangle} variant="danger" />
          </div>

          {/* Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <div className="flex justify-end mb-4">
                <Button onClick={() => toast.info("Opening compliance item form...")}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Item
                </Button>
              </div>
              <DataTable
                columns={complianceColumns}
                data={complianceData}
                onView={(item) => toast.info(`Viewing: ${item.description}`)}
                onEdit={(item) => toast.info(`Editing: ${item.id}`)}
                onDelete={(item) => toast.error(`Deleted: ${item.id}`)}
              />
            </div>
            <div>
              <UpcomingDeadlines deadlines={deadlines} />
            </div>
          </div>
        </TabsContent>

        {/* Employee Files Tab */}
        <TabsContent value="employee-files" className="space-y-6">
          {/* File Categories */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {fileCategories.map((cat) => (
              <button
                key={cat.label}
                onClick={() => toast.info(`Viewing ${cat.label}...`)}
                className="p-5 rounded-lg bg-card border border-border hover:border-primary/30 hover:shadow-md transition-all text-left group"
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${cat.color}`}>
                  <cat.icon className="h-5 w-5" />
                </div>
                <p className="font-semibold group-hover:text-primary transition-colors">{cat.label}</p>
                <p className="text-2xl font-bold mt-1">{cat.count.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">records</p>
              </button>
            ))}
          </div>

          {/* Search and Table */}
          <div className="flex items-center justify-between gap-4">
            <div className="relative max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search employees..."
                value={employeeSearchTerm}
                onChange={(e) => setEmployeeSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            <Button onClick={handleAddEmployeeFile}>
              <Plus className="h-4 w-4 mr-2" />
              Add Record
            </Button>
          </div>

          <DataTable
            columns={employeeColumns}
            data={filteredEmployeeFiles}
            onView={handleViewEmployeeFile}
            onEdit={handleEditEmployeeFile}
            onDelete={handleDeleteEmployeeFile}
          />
        </TabsContent>

        {/* Training Statistics Tab */}
        <TabsContent value="training" className="space-y-6">
          {/* Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricCard title="Total Training Records" value={trainingData.length} icon={GraduationCap} variant="primary" />
            <MetricCard title="Completed" value={completedTraining} icon={CheckCircle} variant="success" />
            <MetricCard title="Pending" value={pendingTraining} icon={Clock} variant="warning" />
            <MetricCard title="Overdue" value={overdueTraining} icon={AlertTriangle} variant="danger" />
          </div>

          {/* Completion Rate */}
          <div className="bg-card rounded-lg border border-border p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold">Overall Training Completion Rate</h3>
              <span className="text-2xl font-bold text-primary">{completionRate}%</span>
            </div>
            <Progress value={completionRate} className="h-3" />
            <div className="flex justify-between mt-3 text-sm text-muted-foreground">
              <span>Target: 95%</span>
              <span>{completedTraining} of {trainingData.length} records</span>
            </div>
          </div>

          {/* Training Type Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {[
              { type: "HIPAA", completed: 98 },
              { type: "Safety", completed: 95 },
              { type: "Harassment", completed: 92 },
              { type: "Infection Control", completed: 88 },
              { type: "Emergency", completed: 96 },
              { type: "OSHA", completed: 91 },
            ].map((item) => (
              <div key={item.type} className="p-4 rounded-lg bg-card border border-border text-center">
                <p className="text-sm text-muted-foreground">{item.type}</p>
                <p className="text-2xl font-bold mt-1" style={{ color: item.completed >= 95 ? "hsl(var(--success))" : item.completed >= 90 ? "hsl(var(--warning))" : "hsl(var(--destructive))" }}>
                  {item.completed}%
                </p>
              </div>
            ))}
          </div>

          {/* Training Table */}
          <div className="flex justify-end">
            <Button onClick={handleAddTraining}>
              <Plus className="h-4 w-4 mr-2" />
              Add Training
            </Button>
          </div>

          <DataTable
            columns={trainingColumns}
            data={trainingData}
            onView={handleViewTraining}
            onEdit={handleEditTraining}
            onDelete={handleDeleteTraining}
          />
        </TabsContent>
      </Tabs>

      {/* Employee File Dialogs */}
      <EmployeeFileFormDialog
        open={employeeFileDialogOpen}
        onOpenChange={setEmployeeFileDialogOpen}
        mode={employeeFileMode}
        employeeFile={selectedEmployeeFile}
        onSave={handleSaveEmployeeFile}
      />
      <ViewEmployeeFileDialog
        open={viewEmployeeFileDialogOpen}
        onOpenChange={setViewEmployeeFileDialogOpen}
        employeeFile={selectedEmployeeFile}
      />
      <DeleteConfirmDialog
        open={deleteEmployeeFileDialogOpen}
        onOpenChange={setDeleteEmployeeFileDialogOpen}
        title="Delete Employee File"
        description={`Are you sure you want to delete the file record for ${selectedEmployeeFile?.employeeName}? This action cannot be undone.`}
        onConfirm={confirmDeleteEmployeeFile}
      />

      {/* Training Dialogs */}
      <TrainingFormDialog
        open={trainingDialogOpen}
        onOpenChange={setTrainingDialogOpen}
        mode={trainingMode}
        training={selectedTraining}
        onSave={handleSaveTraining}
      />
      <ViewTrainingDialog
        open={viewTrainingDialogOpen}
        onOpenChange={setViewTrainingDialogOpen}
        training={selectedTraining}
      />
      <DeleteConfirmDialog
        open={deleteTrainingDialogOpen}
        onOpenChange={setDeleteTrainingDialogOpen}
        title="Delete Training Record"
        description={`Are you sure you want to delete the training record for ${selectedTraining?.employeeName}? This action cannot be undone.`}
        onConfirm={confirmDeleteTraining}
      />
    </DashboardLayout>
  );
};

export default CompliancePage;
