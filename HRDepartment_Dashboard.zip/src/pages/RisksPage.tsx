import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { DataTable, Column } from "@/components/dashboard/DataTable";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { DeletePolicyDialog } from "@/components/policies/DeletePolicyDialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertTriangle, Plus, Filter, Download, Search, MoreHorizontal } from "lucide-react";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Risk Types
interface RiskItem {
  id: string;
  description: string;
  level: "high" | "medium" | "low";
  status: "pending" | "completed" | "active";
  owner: string;
}

const riskData: RiskItem[] = [
  { id: "RSK-001", description: "PHI exposure in testimonial videos", level: "high", status: "pending", owner: "Emily Watson" },
  { id: "RSK-002", description: "Non-compliant third-party ad network", level: "high", status: "active", owner: "David Kim" },
  { id: "RSK-003", description: "Outdated consent forms in campaigns", level: "medium", status: "completed", owner: "Jessica Brown" },
  { id: "RSK-004", description: "Social media auto-response PHI risk", level: "medium", status: "pending", owner: "David Kim" },
  { id: "RSK-005", description: "Print distribution tracking gap", level: "low", status: "active", owner: "James Wilson" },
];

const riskColumns: Column<RiskItem>[] = [
  { key: "id", header: "Risk ID", className: "font-mono text-sm" },
  { key: "description", header: "Description" },
  { key: "level", header: "Level", render: (item) => <StatusBadge status={item.level} /> },
  { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
  { key: "owner", header: "Owner" },
  { key: "actions", header: "Actions" },
];

// Policy Types
interface Policy {
  id: string;
  name: string;
  category: string;
  lastUpdate: string;
  status: "active" | "pending" | "inactive";
  nextUpdate: string;
  owner: string;
}

const initialPoliciesData: Policy[] = [
  { id: "1", name: "Employee Handbook", category: "General", lastUpdate: "Nov 15, 2024", status: "active", nextUpdate: "Nov 15, 2025", owner: "HR Director" },
  { id: "2", name: "HIPAA Privacy Policy", category: "Compliance", lastUpdate: "Oct 20, 2024", status: "active", nextUpdate: "Oct 20, 2025", owner: "Compliance Officer" },
  { id: "3", name: "Remote Work Policy", category: "Operations", lastUpdate: "Sep 10, 2024", status: "pending", nextUpdate: "Dec 31, 2024", owner: "Operations Manager" },
  { id: "4", name: "Code of Conduct", category: "Ethics", lastUpdate: "Aug 5, 2024", status: "active", nextUpdate: "Aug 5, 2025", owner: "Legal Counsel" },
  { id: "5", name: "Anti-Harassment Policy", category: "HR", lastUpdate: "Jul 22, 2024", status: "active", nextUpdate: "Jul 22, 2025", owner: "HR Director" },
];

const policyColumns: Column<Policy>[] = [
  { key: "name", header: "Policy Name" },
  { key: "category", header: "Category" },
  { key: "lastUpdate", header: "Last Update" },
  { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
  { key: "nextUpdate", header: "Next Update" },
  { key: "owner", header: "Owner" },
  { key: "actions", header: "Actions" },
];

const categories = ["All", "General", "Compliance", "Operations", "Ethics", "HR", "IT", "Finance"];

const RisksPage = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("risks");
  const [policies, setPolicies] = useState<Policy[]>(initialPoliciesData);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  
  // Dialog states
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedPolicy, setSelectedPolicy] = useState<Policy | null>(null);

  // Calculate risk stats
  const totalRisks = riskData.length;
  const highRisks = riskData.filter(r => r.level === "high").length;
  const mediumRisks = riskData.filter(r => r.level === "medium").length;
  const lowRisks = riskData.filter(r => r.level === "low").length;

  // Filter policies
  const filteredPolicies = policies.filter((policy) => {
    const matchesSearch = policy.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === "All" || policy.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const handleAddRisk = () => {
    toast.info("Opening risk creation form...");
  };

  const handleAddPolicy = () => {
    navigate("/policies/new/edit");
  };

  const handleViewPolicy = (policy: Policy) => {
    navigate(`/policies/${policy.id}`);
  };

  const handleEditPolicy = (policy: Policy) => {
    navigate(`/policies/${policy.id}/edit`);
  };

  const handleDeletePolicy = (policy: Policy) => {
    setSelectedPolicy(policy);
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = () => {
    if (selectedPolicy) {
      setPolicies(policies.filter(p => p.id !== selectedPolicy.id));
      toast.success(`Policy "${selectedPolicy.name}" deleted successfully`);
      setDeleteDialogOpen(false);
      setSelectedPolicy(null);
    }
  };

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold text-foreground">Risk Management</h1>
        <p className="text-muted-foreground mt-1">
          Risk assessment, policies, and regulatory compliance management
        </p>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="risks">Risks</TabsTrigger>
          <TabsTrigger value="policies">Policies</TabsTrigger>
          <TabsTrigger value="hipaa">HIPAA & ADAA</TabsTrigger>
        </TabsList>

        {/* Risks Tab */}
        <TabsContent value="risks" className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-lg border-2 border-primary bg-card">
              <div className="flex items-center gap-3">
                <AlertTriangle className="h-5 w-5 text-primary" />
                <span className="text-sm text-muted-foreground">Total Risks</span>
              </div>
              <p className="text-3xl font-bold mt-2">{totalRisks}</p>
            </div>
            <div className="p-4 rounded-lg border border-border bg-card">
              <span className="text-sm text-muted-foreground">High Risk</span>
              <p className="text-3xl font-bold mt-2 text-destructive">{highRisks}</p>
            </div>
            <div className="p-4 rounded-lg border border-border bg-card">
              <span className="text-sm text-muted-foreground">Medium Risk</span>
              <p className="text-3xl font-bold mt-2 text-warning">{mediumRisks}</p>
            </div>
            <div className="p-4 rounded-lg border border-border bg-card">
              <span className="text-sm text-muted-foreground">Low Risk</span>
              <p className="text-3xl font-bold mt-2 text-success">{lowRisks}</p>
            </div>
          </div>

          {/* Risk Registry */}
          <div className="bg-card rounded-lg border border-border">
            <div className="p-4 border-b border-border flex items-center justify-between">
              <h3 className="font-semibold">Risk Registry</h3>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
                <Button size="sm" onClick={handleAddRisk}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add New
                </Button>
              </div>
            </div>
            <div className="p-0">
              <table className="w-full">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Risk ID</th>
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Description</th>
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Level</th>
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Status</th>
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Owner</th>
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {riskData.map((risk) => (
                    <tr key={risk.id} className="border-t border-border hover:bg-muted/30">
                      <td className="p-3 font-mono text-sm">{risk.id}</td>
                      <td className="p-3">{risk.description}</td>
                      <td className="p-3"><StatusBadge status={risk.level} /></td>
                      <td className="p-3"><StatusBadge status={risk.status} /></td>
                      <td className="p-3">{risk.owner}</td>
                      <td className="p-3">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => toast.info(`Viewing ${risk.id}`)}>View</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => toast.info(`Editing ${risk.id}`)}>Edit</DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive" onClick={() => toast.error(`Deleted ${risk.id}`)}>Delete</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>

        {/* Policies Tab */}
        <TabsContent value="policies" className="space-y-6">
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search policies..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={handleAddPolicy}>
              <Plus className="h-4 w-4 mr-2" />
              Add Policy
            </Button>
          </div>

          <DataTable
            columns={policyColumns}
            data={filteredPolicies}
            onView={handleViewPolicy}
            onEdit={handleEditPolicy}
            onDelete={handleDeletePolicy}
          />
        </TabsContent>

        {/* HIPAA & ADAA Tab */}
        <TabsContent value="hipaa" className="space-y-6">
          <div className="bg-card rounded-lg border border-border p-6">
            <h3 className="font-display font-semibold text-lg mb-4">HIPAA & ADAA Compliance</h3>
            <p className="text-muted-foreground mb-6">
              Regulatory compliance tracking for HIPAA (Health Insurance Portability and Accountability Act) 
              and ADAA (Americans with Disabilities Act Amendments).
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                <h4 className="font-medium mb-3">HIPAA Requirements</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-success" />
                    Privacy Rule Compliance
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-success" />
                    Security Rule Implementation
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-warning" />
                    Breach Notification Procedures
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-success" />
                    Business Associate Agreements
                  </li>
                </ul>
              </div>
              <div className="p-4 rounded-lg bg-info/5 border border-info/20">
                <h4 className="font-medium mb-3">ADAA Requirements</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-success" />
                    Reasonable Accommodations Policy
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-success" />
                    Non-Discrimination Procedures
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-success" />
                    Accessibility Standards
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-warning" />
                    Interactive Process Documentation
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <DeletePolicyDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        policy={selectedPolicy}
        onConfirm={handleConfirmDelete}
      />
    </DashboardLayout>
  );
};

export default RisksPage;
