import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, Download, Filter, Columns, Search, ChevronDown, ChevronUp,
  X, Calendar, Building2, Users, SlidersHorizontal, ExternalLink
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from '@/hooks/use-toast';
import { reportDefinitions, getReportData } from '@/data/reportsMockData';
import { ReportColumn, ReportRow, DEPARTMENTS, FACILITIES, SEVERITY_LEVELS, PRIORITY_LEVELS } from '@/types/reports';
import { generateCSV, downloadCSV, generateExportFilename, generateFilterSummary } from '@/lib/csvExport';

export default function ReportDetail() {
  const { reportId } = useParams<{ reportId: string }>();
  const navigate = useNavigate();
  
  const report = reportDefinitions.find(r => r.id === reportId);
  const reportData = reportId ? getReportData(reportId) : { metrics: [], rows: [] };

  // State
  const [searchQuery, setSearchQuery] = useState('');
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [visibleColumns, setVisibleColumns] = useState<string[]>(report?.columns.map(c => c.id) || []);
  const [filtersOpen, setFiltersOpen] = useState(true);
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [showColumnChooser, setShowColumnChooser] = useState(false);
  const [selectedRow, setSelectedRow] = useState<ReportRow | null>(null);
  const [showPreviewPanel, setShowPreviewPanel] = useState(false);

  // Filter state
  const [filters, setFilters] = useState<Record<string, any>>({
    dateRangeType: 'created',
    facility: 'all',
    department: [],
    severity: [],
    overdueOnly: false,
  });

  // Export options
  const [exportOptions, setExportOptions] = useState({
    includeHiddenColumns: false,
    includeLinkedIds: true,
  });

  if (!report) {
    return (
      <div className="p-6">
        <Button variant="ghost" onClick={() => navigate('/reports')} className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" /> Back to Reports
        </Button>
        <Card className="border-dashed">
          <CardContent className="p-8 text-center">
            <h3 className="text-lg font-semibold text-foreground">Report not found</h3>
            <p className="text-muted-foreground mt-2">The requested report does not exist.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Filter and sort data
  const filteredRows = useMemo(() => {
    let rows = [...reportData.rows];

    // Apply search
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      rows = rows.filter(row => 
        Object.values(row).some(val => 
          val?.toString().toLowerCase().includes(query)
        )
      );
    }

    // Apply filters
    if (filters.overdueOnly) {
      rows = rows.filter(row => 
        row.overdue === 'Yes' || row.daysOverdue > 0 || row.overdueActions > 0
      );
    }

    if (filters.department?.length > 0) {
      rows = rows.filter(row => filters.department.includes(row.department?.toLowerCase().replace(' ', '_')));
    }

    if (filters.severity?.length > 0) {
      rows = rows.filter(row => filters.severity.includes(row.severity?.toLowerCase()));
    }

    // Apply sort
    if (sortColumn) {
      rows.sort((a, b) => {
        const aVal = a[sortColumn];
        const bVal = b[sortColumn];
        
        if (aVal === bVal) return 0;
        if (aVal === null || aVal === undefined) return 1;
        if (bVal === null || bVal === undefined) return -1;

        const comparison = aVal < bVal ? -1 : 1;
        return sortDirection === 'asc' ? comparison : -comparison;
      });
    }

    return rows;
  }, [reportData.rows, searchQuery, sortColumn, sortDirection, filters]);

  const handleSort = (columnId: string) => {
    if (sortColumn === columnId) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(columnId);
      setSortDirection('asc');
    }
  };

  const handleExport = () => {
    const columnsToExport = report.columns.filter(col => 
      exportOptions.includeHiddenColumns || visibleColumns.includes(col.id)
    );

    const csv = generateCSV(
      filteredRows,
      columnsToExport,
      {
        reportName: report.title,
        exportedAt: new Date().toISOString(),
        userRole: 'admin',
        organization: 'MedComply Healthcare',
        facility: filters.facility === 'all' ? undefined : filters.facility,
        filterSummary: generateFilterSummary(filters),
      },
      exportOptions
    );

    const filename = generateExportFilename(report.title);
    downloadCSV(csv, filename);

    toast({
      title: 'Export Complete',
      description: `Downloaded ${filename} with ${filteredRows.length} rows.`,
    });

    setShowExportDialog(false);
  };

  const handleRowClick = (row: ReportRow) => {
    setSelectedRow(row);
    setShowPreviewPanel(true);
  };

  const handleDrillDown = () => {
    if (!selectedRow || !report.drillDownType) return;

    const id = selectedRow.issueId || selectedRow.capaId || selectedRow.citationCode || selectedRow.caseId || selectedRow.recordId;
    
    switch (report.drillDownType) {
      case 'issue':
        navigate(`/issues/${id}`);
        break;
      case 'capa':
        navigate(`/actionguard/${id}`);
        break;
      case 'citation':
        navigate(`/citations/${id}`);
        break;
      case 'citation_case':
        navigate(`/citations/cases/${id}`);
        break;
    }
  };

  const clearFilters = () => {
    setFilters({
      dateRangeType: 'created',
      facility: 'all',
      department: [],
      severity: [],
      overdueOnly: false,
    });
    setSearchQuery('');
  };

  const activeFilterCount = Object.entries(filters).filter(([key, val]) => {
    if (key === 'dateRangeType') return false;
    if (key === 'facility' && val === 'all') return false;
    if (Array.isArray(val) && val.length === 0) return false;
    if (val === false) return false;
    return true;
  }).length + (searchQuery ? 1 : 0);

  return (
    <div className="flex h-full">
      {/* Filters Panel */}
      <Collapsible open={filtersOpen} onOpenChange={setFiltersOpen} className="flex">
        <CollapsibleContent className="w-64 border-r bg-muted/30 p-4 space-y-4 overflow-auto">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-foreground">Filters</h3>
            {activeFilterCount > 0 && (
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                Clear all
              </Button>
            )}
          </div>

          {/* Date Range Type */}
          <div>
            <Label className="text-xs text-muted-foreground">Date Range Type</Label>
            <Select value={filters.dateRangeType} onValueChange={(v) => setFilters(f => ({ ...f, dateRangeType: v }))}>
              <SelectTrigger className="bg-background mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-background">
                <SelectItem value="created">Created</SelectItem>
                <SelectItem value="updated">Updated</SelectItem>
                <SelectItem value="closed">Closed</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Facility */}
          <div>
            <Label className="text-xs text-muted-foreground">Facility</Label>
            <Select value={filters.facility} onValueChange={(v) => setFilters(f => ({ ...f, facility: v }))}>
              <SelectTrigger className="bg-background mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-background">
                <SelectItem value="all">All Facilities</SelectItem>
                {FACILITIES.map(f => (
                  <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Department */}
          <div>
            <Label className="text-xs text-muted-foreground">Department</Label>
            <div className="mt-1 space-y-1 max-h-32 overflow-auto">
              {DEPARTMENTS.map(dept => (
                <label key={dept.value} className="flex items-center gap-2 text-sm cursor-pointer">
                  <Checkbox 
                    checked={filters.department.includes(dept.value)}
                    onCheckedChange={(checked) => {
                      setFilters(f => ({
                        ...f,
                        department: checked 
                          ? [...f.department, dept.value]
                          : f.department.filter((d: string) => d !== dept.value)
                      }));
                    }}
                  />
                  {dept.label}
                </label>
              ))}
            </div>
          </div>

          {/* Severity */}
          <div>
            <Label className="text-xs text-muted-foreground">Severity</Label>
            <div className="mt-1 space-y-1">
              {SEVERITY_LEVELS.map(sev => (
                <label key={sev.value} className="flex items-center gap-2 text-sm cursor-pointer">
                  <Checkbox 
                    checked={filters.severity.includes(sev.value)}
                    onCheckedChange={(checked) => {
                      setFilters(f => ({
                        ...f,
                        severity: checked 
                          ? [...f.severity, sev.value]
                          : f.severity.filter((s: string) => s !== sev.value)
                      }));
                    }}
                  />
                  {sev.label}
                </label>
              ))}
            </div>
          </div>

          {/* Overdue Toggle */}
          <div className="flex items-center justify-between">
            <Label className="text-sm">Overdue Only</Label>
            <Switch 
              checked={filters.overdueOnly}
              onCheckedChange={(checked) => setFilters(f => ({ ...f, overdueOnly: checked }))}
            />
          </div>
        </CollapsibleContent>
        
        <CollapsibleTrigger asChild>
          <Button variant="ghost" size="icon" className="h-8 w-8 mt-4 -mr-4 z-10">
            <SlidersHorizontal className="h-4 w-4" />
          </Button>
        </CollapsibleTrigger>
      </Collapsible>

      {/* Main Content */}
      <div className="flex-1 p-6 space-y-4 overflow-auto">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate('/reports')}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <h1 className="text-xl font-bold text-foreground">{report.title}</h1>
              <p className="text-sm text-muted-foreground">{report.description}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => setShowColumnChooser(true)}>
              <Columns className="h-4 w-4 mr-2" />
              Columns
            </Button>
            <Button onClick={() => setShowExportDialog(true)}>
              <Download className="h-4 w-4 mr-2" />
              Download CSV
            </Button>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {reportData.metrics.map((metric) => (
            <Card key={metric.id} className={`${
              metric.color === 'danger' ? 'border-red-500/30' : 
              metric.color === 'warning' ? 'border-amber-500/30' : 
              metric.color === 'success' ? 'border-green-500/30' : ''
            }`}>
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground">{metric.label}</p>
                <p className={`text-xl font-bold ${
                  metric.color === 'danger' ? 'text-red-600' : 
                  metric.color === 'warning' ? 'text-amber-600' : 
                  metric.color === 'success' ? 'text-green-600' : 'text-foreground'
                }`}>{metric.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Search and Active Filters */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search within results..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-background"
            />
          </div>
          {activeFilterCount > 0 && (
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="secondary">{activeFilterCount} filter{activeFilterCount > 1 ? 's' : ''} active</Badge>
              {filters.overdueOnly && (
                <Badge variant="outline" className="gap-1">
                  Overdue Only
                  <X className="h-3 w-3 cursor-pointer" onClick={() => setFilters(f => ({ ...f, overdueOnly: false }))} />
                </Badge>
              )}
            </div>
          )}
          <p className="text-sm text-muted-foreground">
            {filteredRows.length} of {reportData.rows.length} records
          </p>
        </div>

        {/* Data Table */}
        <Card>
          <ScrollArea className="h-[500px]">
            <Table>
              <TableHeader className="sticky top-0 bg-background z-10">
                <TableRow>
                  {report.columns.filter(col => visibleColumns.includes(col.id)).map((column) => (
                    <TableHead 
                      key={column.id}
                      className={column.sortable ? 'cursor-pointer hover:bg-muted/50' : ''}
                      onClick={() => column.sortable && handleSort(column.id)}
                    >
                      <div className="flex items-center gap-1">
                        {column.label}
                        {sortColumn === column.id && (
                          sortDirection === 'asc' ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />
                        )}
                      </div>
                    </TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRows.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={visibleColumns.length} className="text-center py-8 text-muted-foreground">
                      No records match your filters
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredRows.map((row) => (
                    <TableRow 
                      key={row.id} 
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => handleRowClick(row)}
                    >
                      {report.columns.filter(col => visibleColumns.includes(col.id)).map((column) => (
                        <TableCell key={column.id}>
                          {renderCellValue(row[column.id], column.id)}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </ScrollArea>
        </Card>
      </div>

      {/* Preview Panel */}
      <Sheet open={showPreviewPanel} onOpenChange={setShowPreviewPanel}>
        <SheetContent className="w-[400px] sm:w-[540px]">
          <SheetHeader>
            <SheetTitle>Record Preview</SheetTitle>
            <SheetDescription>
              Quick view of selected record details
            </SheetDescription>
          </SheetHeader>
          {selectedRow && (
            <div className="mt-6 space-y-4">
              {Object.entries(selectedRow).filter(([key]) => key !== 'id').map(([key, value]) => (
                <div key={key} className="flex justify-between py-2 border-b">
                  <span className="text-sm text-muted-foreground capitalize">
                    {key.replace(/([A-Z])/g, ' $1').trim()}
                  </span>
                  <span className="text-sm font-medium text-foreground">
                    {renderCellValue(value, key)}
                  </span>
                </div>
              ))}
              {report.drillDownType && (
                <Button className="w-full mt-4" onClick={handleDrillDown}>
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Open Full Record
                </Button>
              )}
            </div>
          )}
        </SheetContent>
      </Sheet>

      {/* Column Chooser Dialog */}
      <Dialog open={showColumnChooser} onOpenChange={setShowColumnChooser}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Choose Columns</DialogTitle>
            <DialogDescription>Select which columns to display in the report</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 max-h-64 overflow-auto py-4">
            {report.columns.map((column) => (
              <label key={column.id} className="flex items-center gap-2 cursor-pointer">
                <Checkbox 
                  checked={visibleColumns.includes(column.id)}
                  onCheckedChange={(checked) => {
                    setVisibleColumns(prev => 
                      checked 
                        ? [...prev, column.id]
                        : prev.filter(id => id !== column.id)
                    );
                  }}
                />
                <span className="text-sm">{column.label}</span>
              </label>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setVisibleColumns(report.columns.map(c => c.id))}>
              Show All
            </Button>
            <Button onClick={() => setShowColumnChooser(false)}>Done</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Export Dialog */}
      <Dialog open={showExportDialog} onOpenChange={setShowExportDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Export Options</DialogTitle>
            <DialogDescription>Configure your CSV export settings</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Include Hidden Columns</Label>
                <p className="text-xs text-muted-foreground">Export all columns, not just visible ones</p>
              </div>
              <Switch 
                checked={exportOptions.includeHiddenColumns}
                onCheckedChange={(checked) => setExportOptions(o => ({ ...o, includeHiddenColumns: checked }))}
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label>Include Record IDs</Label>
                <p className="text-xs text-muted-foreground">Include ID columns for cross-referencing</p>
              </div>
              <Switch 
                checked={exportOptions.includeLinkedIds}
                onCheckedChange={(checked) => setExportOptions(o => ({ ...o, includeLinkedIds: checked }))}
              />
            </div>
            <Card className="bg-muted/50">
              <CardContent className="p-4 text-sm">
                <p className="font-medium mb-2">Export Summary</p>
                <p className="text-muted-foreground">• {filteredRows.length} rows</p>
                <p className="text-muted-foreground">• {exportOptions.includeHiddenColumns ? report.columns.length : visibleColumns.length} columns</p>
                <p className="text-muted-foreground">• Filters: {generateFilterSummary(filters)}</p>
              </CardContent>
            </Card>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowExportDialog(false)}>Cancel</Button>
            <Button onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Export CSV
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function renderCellValue(value: any, columnId: string): React.ReactNode {
  if (value === null || value === undefined || value === '-') {
    return <span className="text-muted-foreground">-</span>;
  }

  // Handle severity/priority badges
  if (columnId === 'severity' || columnId === 'priority') {
    const colors: Record<string, string> = {
      critical: 'bg-red-500/10 text-red-600 border-red-500/20',
      high: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
      medium: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
      low: 'bg-green-500/10 text-green-600 border-green-500/20',
      urgent: 'bg-red-500/10 text-red-600 border-red-500/20',
    };
    return (
      <Badge variant="outline" className={colors[value.toLowerCase()] || ''}>
        {value}
      </Badge>
    );
  }

  // Handle status badges
  if (columnId === 'status' || columnId === 'stage' || columnId === 'currentStage') {
    return <Badge variant="outline">{value}</Badge>;
  }

  // Handle bucket badges
  if (columnId === 'bucket') {
    const colors: Record<string, string> = {
      NEW: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
      OPEN: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
      CLOSED: 'bg-green-500/10 text-green-600 border-green-500/20',
    };
    return (
      <Badge variant="outline" className={colors[value] || ''}>
        {value}
      </Badge>
    );
  }

  // Handle overdue
  if (columnId === 'overdue') {
    return value === 'Yes' ? (
      <Badge variant="outline" className="bg-red-500/10 text-red-600 border-red-500/20">Overdue</Badge>
    ) : (
      <span className="text-green-600">On Track</span>
    );
  }

  // Handle days overdue
  if (columnId === 'daysOverdue' && typeof value === 'number' && value > 0) {
    return <span className="text-red-600 font-medium">{value} days</span>;
  }

  // Handle verification/effectiveness
  if (columnId === 'effectivenessResult') {
    if (value === 'Pass') return <span className="text-green-600">Pass</span>;
    if (value === 'Fail') return <span className="text-red-600">Fail</span>;
    return value;
  }

  return value?.toString() || '';
}
