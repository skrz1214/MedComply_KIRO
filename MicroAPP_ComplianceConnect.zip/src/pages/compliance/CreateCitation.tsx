import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '@/components/compliance/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { 
  ArrowLeft, 
  ArrowRight, 
  Check, 
  BookOpen,
  FileText,
  ClipboardList,
  Link2,
  AlertTriangle,
  User,
  Building2
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { CitationSource, CitationStatus, RiskDomain, FacilityType, Jurisdiction } from '@/types/compliance';

interface CitationFormData {
  source: CitationSource | '';
  jurisdiction: Jurisdiction | '';
  facilityType: FacilityType | '';
  program: string;
  citationCode: string;
  title: string;
  fullText: string;
  interpretationNotes: string;
  riskDomain: RiskDomain | '';
  status: CitationStatus;
  tags: string[];
  references: string[];
  assignedReviewer: string;
  assignedDepartment: string;
}

// Mock current user
const currentUser = { id: 'current-user', name: 'You', role: 'Current User' };

// Mock reviewers list
const mockReviewers = [
  { id: 'myself', name: 'Myself', role: 'Self-assign' },
  { id: 'user-1', name: 'Dr. Sarah Chen', role: 'Compliance Manager' },
  { id: 'user-2', name: 'Michael Rodriguez', role: 'QA Reviewer' },
  { id: 'user-3', name: 'Jennifer Walsh', role: 'Department Head' },
  { id: 'user-4', name: 'David Thompson', role: 'Compliance Manager' },
];

// Mock departments list
const mockDepartments = [
  { id: 'dept-1', name: 'Nursing' },
  { id: 'dept-2', name: 'Pharmacy' },
  { id: 'dept-3', name: 'Laboratory' },
  { id: 'dept-4', name: 'Radiology' },
  { id: 'dept-5', name: 'Emergency' },
  { id: 'dept-6', name: 'Surgery' },
  { id: 'dept-7', name: 'Compliance' },
];

const steps = [
  { id: 1, name: 'Basic Info', icon: BookOpen },
  { id: 2, name: 'Citation Text', icon: FileText },
  { id: 3, name: 'Classification', icon: ClipboardList },
  { id: 4, name: 'Review & Create', icon: Check },
];

export default function CreateCitation() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<CitationFormData>({
    source: '',
    jurisdiction: '',
    facilityType: '',
    program: '',
    citationCode: '',
    title: '',
    fullText: '',
    interpretationNotes: '',
    riskDomain: '',
    status: 'draft',
    tags: [],
    references: [],
    assignedReviewer: '',
    assignedDepartment: '',
  });
  const [tagInput, setTagInput] = useState('');
  const [referenceInput, setReferenceInput] = useState('');

  const updateFormData = (field: keyof CitationFormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      updateFormData('tags', [...formData.tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    updateFormData('tags', formData.tags.filter(t => t !== tag));
  };

  const handleAddReference = () => {
    if (referenceInput.trim() && !formData.references.includes(referenceInput.trim())) {
      // Basic URL validation
      try {
        new URL(referenceInput.trim());
        updateFormData('references', [...formData.references, referenceInput.trim()]);
        setReferenceInput('');
      } catch {
        toast({ title: 'Invalid URL', description: 'Please enter a valid URL', variant: 'destructive' });
      }
    }
  };

  const handleRemoveReference = (ref: string) => {
    updateFormData('references', formData.references.filter(r => r !== ref));
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return formData.source && formData.jurisdiction && formData.citationCode && formData.title;
      case 2:
        return formData.fullText.trim().length > 0;
      case 3:
        return formData.riskDomain && formData.facilityType && formData.assignedReviewer && formData.assignedDepartment;
      case 4:
        return true;
      default:
        return false;
    }
  };

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    toast({
      title: 'Citation Created',
      description: `Citation ${formData.citationCode} has been created successfully.`,
    });
    navigate('/citations');
  };

  return (
    <div className="min-h-screen">
      <Header 
        title="Create New Citation" 
        subtitle="Add a new regulatory citation to the library" 
      />

      <div className="p-6 space-y-6">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate('/citations')}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Citations
        </Button>

        {/* Stepper */}
        <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isActive = currentStep === step.id;
              const isCompleted = currentStep > step.id;
              
              return (
                <div key={step.id} className="flex items-center flex-1">
                  <div className="flex flex-col items-center">
                    <div className={cn(
                      'w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all',
                      isActive && 'border-primary bg-primary text-white',
                      isCompleted && 'border-success bg-success text-white',
                      !isActive && !isCompleted && 'border-muted-foreground/30 text-muted-foreground'
                    )}>
                      {isCompleted ? (
                        <Check className="h-5 w-5" />
                      ) : (
                        <Icon className="h-5 w-5" />
                      )}
                    </div>
                    <span className={cn(
                      'text-xs mt-2 font-medium',
                      isActive && 'text-primary',
                      isCompleted && 'text-success',
                      !isActive && !isCompleted && 'text-muted-foreground'
                    )}>
                      {step.name}
                    </span>
                  </div>
                  {index < steps.length - 1 && (
                    <div className={cn(
                      'flex-1 h-0.5 mx-4 mt-[-1rem]',
                      isCompleted ? 'bg-success' : 'bg-muted'
                    )} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Form Content */}
        <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
          {/* Step 1: Basic Info */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Citation Basic Information</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Enter the source and identifying information for this citation.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Citation Source *</Label>
                  <Select 
                    value={formData.source} 
                    onValueChange={(value) => updateFormData('source', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select source" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cms">CMS</SelectItem>
                      <SelectItem value="joint_commission">Joint Commission</SelectItem>
                      <SelectItem value="state_doh">State DOH</SelectItem>
                      <SelectItem value="hipaa">HIPAA</SelectItem>
                      <SelectItem value="osha">OSHA</SelectItem>
                      <SelectItem value="internal_policy">Internal Policy</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Jurisdiction *</Label>
                  <Select 
                    value={formData.jurisdiction} 
                    onValueChange={(value) => updateFormData('jurisdiction', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select jurisdiction" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="federal">Federal</SelectItem>
                      <SelectItem value="state">State</SelectItem>
                      <SelectItem value="local">Local</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Citation Code *</Label>
                  <Input
                    placeholder="e.g., 42 CFR 482.21"
                    value={formData.citationCode}
                    onChange={(e) => updateFormData('citationCode', e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Program (Optional)</Label>
                  <Input
                    placeholder="e.g., CoP - Infection Control"
                    value={formData.program}
                    onChange={(e) => updateFormData('program', e.target.value)}
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label>Citation Title *</Label>
                  <Input
                    placeholder="Enter a descriptive title for this citation"
                    value={formData.title}
                    onChange={(e) => updateFormData('title', e.target.value)}
                  />
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Citation Text */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Citation Text</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Enter the full regulatory text and any interpretation notes.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-warning/10 border border-warning/20 flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-warning mt-0.5 shrink-0" />
                <p className="text-sm text-warning-foreground">
                  <strong>PHI/PII Warning:</strong> Do not include patient or employee personal information in citation text.
                </p>
              </div>

              <div className="space-y-2">
                <Label>Full Citation Text *</Label>
                <Textarea
                  placeholder="Enter the complete regulatory citation text..."
                  value={formData.fullText}
                  onChange={(e) => updateFormData('fullText', e.target.value)}
                  className="min-h-[200px]"
                />
              </div>

              <div className="space-y-2">
                <Label>Interpretation Notes (Optional)</Label>
                <Textarea
                  placeholder="Add any internal interpretation or guidance notes..."
                  value={formData.interpretationNotes}
                  onChange={(e) => updateFormData('interpretationNotes', e.target.value)}
                  className="min-h-[100px]"
                />
              </div>
            </div>
          )}

          {/* Step 3: Classification */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Classification & Tags</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Classify the citation for proper organization and searchability.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Risk Domain *</Label>
                  <Select 
                    value={formData.riskDomain} 
                    onValueChange={(value) => updateFormData('riskDomain', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select risk domain" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="patient_safety">Patient Safety</SelectItem>
                      <SelectItem value="data_privacy">Data Privacy</SelectItem>
                      <SelectItem value="regulatory">Regulatory</SelectItem>
                      <SelectItem value="documentation">Documentation</SelectItem>
                      <SelectItem value="operational">Operational</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Facility Type *</Label>
                  <Select 
                    value={formData.facilityType} 
                    onValueChange={(value) => updateFormData('facilityType', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select facility type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hospital">Hospital</SelectItem>
                      <SelectItem value="nursing_home">Nursing Home</SelectItem>
                      <SelectItem value="clinic">Clinic</SelectItem>
                      <SelectItem value="pharmacy">Pharmacy</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Initial Status</Label>
                  <Select 
                    value={formData.status} 
                    onValueChange={(value: CitationStatus) => updateFormData('status', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Assignment Section */}
              <div className="p-4 rounded-lg border border-border bg-muted/30 space-y-4">
                <div>
                  <h4 className="text-sm font-medium mb-1">Assignment *</h4>
                  <p className="text-xs text-muted-foreground">
                    Assign a reviewer and department for this citation.
                  </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Reviewer *</Label>
                    <Select 
                      value={formData.assignedReviewer}
                        onValueChange={(value) => updateFormData('assignedReviewer', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select reviewer" />
                        </SelectTrigger>
                        <SelectContent>
                          {mockReviewers.map((reviewer) => (
                            <SelectItem key={reviewer.id} value={reviewer.id}>
                              <div className="flex items-center gap-2">
                                <User className="h-4 w-4 text-muted-foreground" />
                                <span>{reviewer.name}</span>
                                <span className="text-muted-foreground text-xs">({reviewer.role})</span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  <div className="space-y-2">
                    <Label>Department *</Label>
                    <Select
                        value={formData.assignedDepartment} 
                        onValueChange={(value) => updateFormData('assignedDepartment', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                        <SelectContent>
                          {mockDepartments.map((dept) => (
                            <SelectItem key={dept.id} value={dept.id}>
                              <div className="flex items-center gap-2">
                                <Building2 className="h-4 w-4 text-muted-foreground" />
                                <span>{dept.name}</span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                  </div>
                </div>
              </div>


              <div className="space-y-2">
                <Label>Tags</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Add a tag..."
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                  />
                  <Button type="button" variant="outline" onClick={handleAddTag}>
                    Add
                  </Button>
                </div>
                {formData.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {formData.tags.map(tag => (
                      <Badge 
                        key={tag} 
                        variant="secondary"
                        className="cursor-pointer hover:bg-destructive/20"
                        onClick={() => handleRemoveTag(tag)}
                      >
                        {tag} ×
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label>Reference URLs</Label>
                <p className="text-sm text-muted-foreground mb-2">
                  Add links to official regulatory sources, guidance documents, or related resources.
                </p>
                <div className="flex gap-2">
                  <Input
                    placeholder="https://example.com/regulation"
                    value={referenceInput}
                    onChange={(e) => setReferenceInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddReference())}
                  />
                  <Button type="button" variant="outline" onClick={handleAddReference}>
                    Add
                  </Button>
                </div>
                {formData.references.length > 0 && (
                  <div className="space-y-2 mt-3">
                    {formData.references.map((ref, index) => (
                      <div 
                        key={index} 
                        className="flex items-center gap-2 p-2 rounded-lg bg-muted/50 group"
                      >
                        <Link2 className="h-4 w-4 text-muted-foreground shrink-0" />
                        <a 
                          href={ref} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="text-sm text-primary hover:underline truncate flex-1"
                        >
                          {ref}
                        </a>
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="sm" 
                          className="opacity-0 group-hover:opacity-100 h-6 w-6 p-0"
                          onClick={() => handleRemoveReference(ref)}
                        >
                          ×
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Step 4: Review */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Review & Create</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Review the citation details before creating.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Citation Code</p>
                    <p className="font-mono font-medium">{formData.citationCode}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Title</p>
                    <p className="font-medium">{formData.title}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Source</p>
                    <p className="capitalize">{formData.source?.replace('_', ' ')}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Jurisdiction</p>
                    <p className="capitalize">{formData.jurisdiction}</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Risk Domain</p>
                    <p className="capitalize">{formData.riskDomain?.replace('_', ' ')}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Facility Type</p>
                    <p className="capitalize">{formData.facilityType?.replace('_', ' ')}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Status</p>
                    <Badge variant={formData.status === 'active' ? 'default' : 'secondary'}>
                      {formData.status}
                    </Badge>
                  </div>
                  {formData.tags.length > 0 && (
                    <div>
                      <p className="text-sm text-muted-foreground">Tags</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {formData.tags.map(tag => (
                          <Badge key={tag} variant="outline">{tag}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  {formData.assignedReviewer && (
                    <div>
                      <p className="text-sm text-muted-foreground">Assigned Reviewer</p>
                      <p className="font-medium flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        {mockReviewers.find(r => r.id === formData.assignedReviewer)?.name}
                      </p>
                    </div>
                  )}
                  {formData.assignedDepartment && (
                    <div>
                      <p className="text-sm text-muted-foreground">Department</p>
                      <p className="font-medium flex items-center gap-2">
                        <Building2 className="h-4 w-4 text-muted-foreground" />
                        {mockDepartments.find(d => d.id === formData.assignedDepartment)?.name}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-4 p-4 rounded-lg bg-muted/50">
                <p className="text-sm text-muted-foreground mb-2">Citation Text Preview</p>
                <p className="text-sm line-clamp-4">{formData.fullText}</p>
              </div>

              <div className="p-4 rounded-lg bg-muted border border-border">
                <p className="text-sm text-foreground">
                  <strong>Note:</strong> After creating this citation, you can add evidence expectations, mappings, and remediation steps from the citation detail page.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <Button 
            variant="outline" 
            onClick={handleBack}
            disabled={currentStep === 1}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>

          {currentStep < 4 ? (
            <Button 
              onClick={handleNext}
              disabled={!canProceed()}
            >
              Next
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          ) : (
            <Button 
              variant="hero"
              onClick={handleSubmit}
            >
              <Check className="h-4 w-4 mr-2" />
              Create Citation
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}