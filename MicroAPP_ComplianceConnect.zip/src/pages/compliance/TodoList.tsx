import { useNavigate } from 'react-router-dom';
import { Header } from '@/components/compliance/Header';
import { IssueCard } from '@/components/compliance/IssueCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { mockIssues } from '@/data/mockData';
import { ClipboardList, Clock, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function TodoList() {
  const navigate = useNavigate();

  // Simulating current user's assigned tasks
  const myTasks = mockIssues.filter(i => 
    i.status !== 'completed' && 
    (i.assignedTo === 'Michael Chen' || i.assignedTo === 'Lisa Park' || i.assignedTo === 'Amanda Foster')
  );

  const pendingInitiation = mockIssues.filter(i => i.status === 'reported');
  const inProgress = myTasks.filter(i => i.status === 'in_progress');
  const awaitingQA = myTasks.filter(i => i.status === 'qa_review');

  const sections = [
    {
      title: 'Pending Initiation',
      description: 'Issues awaiting your review and action planning',
      icon: Clock,
      issues: pendingInitiation,
      variant: 'warning' as const,
    },
    {
      title: 'In Progress',
      description: 'Issues actively being worked on',
      icon: ClipboardList,
      issues: inProgress,
      variant: 'primary' as const,
    },
    {
      title: 'QA Review',
      description: 'Issues awaiting quality assurance review',
      icon: CheckCircle2,
      issues: awaitingQA,
      variant: 'info' as const,
    },
  ];

  const overdueIssues = myTasks.filter(i => 
    i.dueDate && new Date(i.dueDate) < new Date()
  );

  return (
    <div className="min-h-screen">
      <Header 
        title="My To-Do List" 
        subtitle="Your assigned compliance tasks" 
      />

      <div className="p-6 space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Tasks</p>
                <p className="text-2xl font-bold">{myTasks.length + pendingInitiation.length}</p>
              </div>
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <ClipboardList className="h-5 w-5 text-primary" />
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending Review</p>
                <p className="text-2xl font-bold">{pendingInitiation.length}</p>
              </div>
              <div className="w-10 h-10 rounded-lg bg-warning/10 flex items-center justify-center">
                <Clock className="h-5 w-5 text-warning" />
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-border bg-card p-4 shadow-soft">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">In Progress</p>
                <p className="text-2xl font-bold">{inProgress.length}</p>
              </div>
              <div className="w-10 h-10 rounded-lg bg-info/10 flex items-center justify-center">
                <ClipboardList className="h-5 w-5 text-info" />
              </div>
            </div>
          </div>

          <div className={cn(
            'rounded-xl border p-4 shadow-soft',
            overdueIssues.length > 0 
              ? 'border-destructive/30 bg-destructive/5' 
              : 'border-border bg-card'
          )}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Overdue</p>
                <p className={cn(
                  'text-2xl font-bold',
                  overdueIssues.length > 0 && 'text-destructive'
                )}>
                  {overdueIssues.length}
                </p>
              </div>
              <div className={cn(
                'w-10 h-10 rounded-lg flex items-center justify-center',
                overdueIssues.length > 0 ? 'bg-destructive/10' : 'bg-muted'
              )}>
                <AlertTriangle className={cn(
                  'h-5 w-5',
                  overdueIssues.length > 0 ? 'text-destructive' : 'text-muted-foreground'
                )} />
              </div>
            </div>
          </div>
        </div>

        {/* Overdue Alert */}
        {overdueIssues.length > 0 && (
          <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-5">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center shrink-0">
                <AlertTriangle className="h-5 w-5 text-destructive" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-destructive mb-1">
                  {overdueIssues.length} Overdue Item{overdueIssues.length > 1 ? 's' : ''}
                </h3>
                <p className="text-sm text-muted-foreground mb-3">
                  These compliance issues have passed their due date and require immediate attention.
                </p>
                <div className="space-y-2">
                  {overdueIssues.map(issue => (
                    <div 
                      key={issue.id}
                      className="flex items-center justify-between p-3 rounded-lg bg-background/50 cursor-pointer hover:bg-background transition-colors"
                      onClick={() => navigate(`/issues/${issue.id}`)}
                    >
                      <div>
                        <p className="font-medium text-sm">{issue.title}</p>
                        <p className="text-xs text-muted-foreground">{issue.id}</p>
                      </div>
                      <Badge variant="destructive">Overdue</Badge>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Task Sections */}
        {sections.map((section) => (
          <div key={section.title} className="space-y-4">
            <div className="flex items-center gap-3">
              <div className={cn(
                'w-8 h-8 rounded-lg flex items-center justify-center',
                section.variant === 'warning' && 'bg-warning/10',
                section.variant === 'primary' && 'bg-primary/10',
                section.variant === 'info' && 'bg-info/10',
              )}>
                <section.icon className={cn(
                  'h-4 w-4',
                  section.variant === 'warning' && 'text-warning',
                  section.variant === 'primary' && 'text-primary',
                  section.variant === 'info' && 'text-info',
                )} />
              </div>
              <div>
                <h2 className="font-semibold flex items-center gap-2">
                  {section.title}
                  <Badge variant="muted">{section.issues.length}</Badge>
                </h2>
                <p className="text-sm text-muted-foreground">{section.description}</p>
              </div>
            </div>

            {section.issues.length === 0 ? (
              <div className="rounded-xl border border-dashed border-border p-8 text-center">
                <p className="text-muted-foreground">No items in this category</p>
              </div>
            ) : (
              <div className="grid gap-4">
                {section.issues.map((issue) => (
                  <IssueCard 
                    key={issue.id} 
                    issue={issue}
                    onViewDetails={(id) => navigate(`/issues/${id}`)}
                  />
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
