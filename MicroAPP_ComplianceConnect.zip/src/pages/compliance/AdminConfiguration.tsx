import { useState } from 'react';
import { Settings, FileText, BookOpen, ClipboardCheck, Paperclip, Bell, BarChart3, Plug, Shield, Save, X, History, Upload } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';
import { AdminConfigCRUDTable } from '@/components/admin/AdminConfigCRUDTable';
import { AdminConfigSettingsCard } from '@/components/admin/AdminConfigSettingsCard';
import { AdminGuidancePanel } from '@/components/admin/AdminGuidancePanel';
import { RecommendedActionsManager } from '@/components/admin/RecommendedActionsManager';
import {
  mockIssueTypes, mockIssueCategories,
  mockPriorityLevels, mockRecommendedActions, mockMonitoringDestinations, mockIssueWorkflowSettings,
  mockCapaOriginTypes, mockCapaSeveritySLAs, mockCapaTemplates, mockCapaActionTypes,
  mockRCAMethods, mockContributingFactors, mockVerificationTypes, mockEffectivenessKPIs, mockClosureReasons,
  mockCitationSources, mockJurisdictions, mockFacilityTypes, mockEvidenceTypes, mockRiskDomains,
  mockAuthorityModeMappings, mockTimelinessRules, mockCaseClosureReasons,
  mockAllowedFileTypes, mockSensitivityTags, mockRetentionLabels,
  mockNotificationTemplates, mockNotificationRules, mockEscalationChains,
  mockReportingSettings, mockConfigAuditLog
} from '@/data/adminConfigMockData';

const adminSections = [
  { id: 'complianceconnect', icon: FileText, label: 'Compliance Issues', description: 'Issue types, categories, priorities' },
  { id: 'actionguard', icon: ClipboardCheck, label: 'CAPA (ActionGuard)', description: 'Templates, RCA methods, actions' },
  { id: 'citations', icon: BookOpen, label: 'Citations', description: 'Sources, evidence types, risk domains' },
  { id: 'citationcases', icon: Shield, label: 'Citation Cases', description: 'Authority modes, clocks, escalation' },
  { id: 'evidence', icon: Paperclip, label: 'Evidence & Attachments', description: 'File types, sensitivity tags' },
  { id: 'notifications', icon: Bell, label: 'Notifications', description: 'Templates, rules, escalation' },
  { id: 'reporting', icon: BarChart3, label: 'Reporting Settings', description: 'SLAs, export policies' },
  { id: 'integrations', icon: Plug, label: 'Integrations', description: 'External systems (coming soon)' },
];

export default function AdminConfiguration() {
  const [activeSection, setActiveSection] = useState('complianceconnect');
  const [hasChanges, setHasChanges] = useState(false);

  // Mock state for data management
  const [issueTypes, setIssueTypes] = useState(mockIssueTypes);
  const [issueCategories, setIssueCategories] = useState(mockIssueCategories);
  const [priorityLevels, setPriorityLevels] = useState(mockPriorityLevels);
  const [recommendedActions, setRecommendedActions] = useState(mockRecommendedActions);
  const [monitoringDestinations, setMonitoringDestinations] = useState(mockMonitoringDestinations);
  const [workflowSettings, setWorkflowSettings] = useState(mockIssueWorkflowSettings);
  const [capaOriginTypes, setCapaOriginTypes] = useState(mockCapaOriginTypes);
  const [capaSeveritySLAs, setCapaSeveritySLAs] = useState(mockCapaSeveritySLAs);
  const [capaTemplates, setCapaTemplates] = useState(mockCapaTemplates);
  const [capaActionTypes, setCapaActionTypes] = useState(mockCapaActionTypes);
  const [rcaMethods, setRcaMethods] = useState(mockRCAMethods);
  const [contributingFactors, setContributingFactors] = useState(mockContributingFactors);
  const [verificationTypes, setVerificationTypes] = useState(mockVerificationTypes);
  const [effectivenessKPIs, setEffectivenessKPIs] = useState(mockEffectivenessKPIs);
  const [closureReasons, setClosureReasons] = useState(mockClosureReasons);
  const [citationSources, setCitationSources] = useState(mockCitationSources);
  const [jurisdictions, setJurisdictions] = useState(mockJurisdictions);
  const [facilityTypes, setFacilityTypes] = useState(mockFacilityTypes);
  const [evidenceTypes, setEvidenceTypes] = useState(mockEvidenceTypes);
  const [riskDomains, setRiskDomains] = useState(mockRiskDomains);
  const [authorityModeMappings, setAuthorityModeMappings] = useState(mockAuthorityModeMappings);
  const [timelinessRules, setTimelinessRules] = useState(mockTimelinessRules);
  const [caseClosureReasons, setCaseClosureReasons] = useState(mockCaseClosureReasons);
  const [allowedFileTypes, setAllowedFileTypes] = useState(mockAllowedFileTypes);
  const [sensitivityTags, setSensitivityTags] = useState(mockSensitivityTags);
  const [notificationTemplates, setNotificationTemplates] = useState(mockNotificationTemplates);
  const [notificationRules, setNotificationRules] = useState(mockNotificationRules);
  const [reportingSettings, setReportingSettings] = useState(mockReportingSettings);

  const handleSave = () => {
    toast({ title: 'Changes Saved', description: 'Your configuration changes have been saved as a draft.' });
    setHasChanges(false);
  };

  const handlePublish = () => {
    toast({ title: 'Configuration Published', description: 'Your configuration changes are now live.' });
    setHasChanges(false);
  };

  const handleCancel = () => {
    setHasChanges(false);
    toast({ title: 'Changes Discarded', description: 'Your unsaved changes have been discarded.' });
  };

  const markChanged = () => setHasChanges(true);


  const renderComplianceIssuesSection = () => (
    <div className="space-y-6">
      <Tabs defaultValue="types" className="w-full">
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="types">Issue Types</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="priorities">Priorities</TabsTrigger>
          <TabsTrigger value="workflow">Workflow</TabsTrigger>
          <TabsTrigger value="actions">Recommended Actions</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
        </TabsList>
        <TabsContent value="types" className="mt-4">
          <AdminConfigCRUDTable
            title="Issue Types"
            description="Broad categories for classifying compliance issues"
            data={issueTypes}
            columns={[
              { key: 'name', label: 'Name' },
              { key: 'description', label: 'Description' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Type Name', type: 'text' },
              { key: 'description', label: 'Description', type: 'textarea' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', description: '', isActive: true, order: issueTypes.length + 1 }}
            onAdd={(item) => { setIssueTypes([...issueTypes, item as any]); markChanged(); }}
            onEdit={(item) => { setIssueTypes(issueTypes.map(t => t.id === item.id ? item : t)); markChanged(); }}
            onDelete={(id) => { setIssueTypes(issueTypes.filter(t => t.id !== id)); markChanged(); }}
            reorderable
          />
        </TabsContent>
        <TabsContent value="categories" className="mt-4">
          <AdminConfigCRUDTable
            title="Issue Categories"
            description="Subcategories within issue types"
            data={issueCategories}
            columns={[
              { key: 'name', label: 'Name' },
              { key: 'typeId', label: 'Parent Type', render: (c) => issueTypes.find(t => t.id === c.typeId)?.name || '-' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Category Name', type: 'text' },
              { key: 'description', label: 'Description', type: 'textarea' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', typeId: 'type-1', description: '', isActive: true, order: 1 }}
            onAdd={(item) => { setIssueCategories([...issueCategories, item as any]); markChanged(); }}
            onEdit={(item) => { setIssueCategories(issueCategories.map(c => c.id === item.id ? item : c)); markChanged(); }}
            onDelete={(id) => { setIssueCategories(issueCategories.filter(c => c.id !== id)); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="priorities" className="mt-4">
          <AdminConfigCRUDTable
            title="Priority Levels"
            description="Define priority levels with SLA targets"
            data={priorityLevels}
            columns={[
              { key: 'name', label: 'Name' },
              { key: 'description', label: 'Description' },
              { key: 'slaDays', label: 'SLA (Days)' },
            ]}
            formFields={[
              { key: 'name', label: 'Priority Name', type: 'text' },
              { key: 'description', label: 'Description', type: 'textarea' },
              { key: 'slaDays', label: 'SLA Days', type: 'number' },
            ]}
            defaultNewItem={{ name: '', description: '', slaDays: 7, color: 'yellow', order: priorityLevels.length + 1 }}
            onAdd={(item) => { setPriorityLevels([...priorityLevels, item as any]); markChanged(); }}
            onEdit={(item) => { setPriorityLevels(priorityLevels.map(p => p.id === item.id ? item : p)); markChanged(); }}
            onDelete={(id) => { setPriorityLevels(priorityLevels.filter(p => p.id !== id)); markChanged(); }}
            reorderable
          />
        </TabsContent>
        <TabsContent value="workflow" className="mt-4">
          <AdminConfigSettingsCard
            title="Issue Workflow Settings"
            description="Configure issue lifecycle behavior"
            settings={workflowSettings}
            fields={[
              { key: 'qaReviewRequired', label: 'QA Review Required', description: 'Issues must pass QA review before completion', type: 'switch' },
              { key: 'returnToInProgressAllowed', label: 'Return to In Progress', description: 'Allow returning issues from QA to In Progress', type: 'switch' },
              { key: 'completionRequiresEvidence', label: 'Evidence Required for Completion', description: 'Issues cannot be completed without evidence', type: 'switch' },
            ]}
            onChange={(key, value) => { setWorkflowSettings({ ...workflowSettings, [key]: value }); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="actions" className="mt-4">
          <RecommendedActionsManager
            actions={recommendedActions}
            issueTypes={issueTypes}
            issueCategories={issueCategories}
            priorityLevels={priorityLevels}
            onAdd={(item) => { setRecommendedActions([...recommendedActions, item]); markChanged(); }}
            onEdit={(item) => { setRecommendedActions(recommendedActions.map(a => a.id === item.id ? item : a)); markChanged(); }}
            onDelete={(id) => { setRecommendedActions(recommendedActions.filter(a => a.id !== id)); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="monitoring" className="mt-4">
          <AdminConfigCRUDTable
            title="Monitoring Destinations"
            description="Routing destinations for completed issues"
            data={monitoringDestinations}
            columns={[
              { key: 'name', label: 'Name' },
              { key: 'description', label: 'Description' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Destination Name', type: 'text' },
              { key: 'description', label: 'Description', type: 'textarea' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', description: '', isActive: true, order: monitoringDestinations.length + 1 }}
            onAdd={(item) => { setMonitoringDestinations([...monitoringDestinations, item as any]); markChanged(); }}
            onEdit={(item) => { setMonitoringDestinations(monitoringDestinations.map(m => m.id === item.id ? item : m)); markChanged(); }}
            onDelete={(id) => { setMonitoringDestinations(monitoringDestinations.filter(m => m.id !== id)); markChanged(); }}
            reorderable
          />
        </TabsContent>
      </Tabs>
    </div>
  );

  const renderCAPASection = () => (
    <div className="space-y-6">
      <Tabs defaultValue="origins" className="w-full">
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="origins">Origin Types</TabsTrigger>
          <TabsTrigger value="slas">Severity & SLAs</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="actions">Action Types</TabsTrigger>
          <TabsTrigger value="rca">RCA Methods</TabsTrigger>
          <TabsTrigger value="verification">Verification</TabsTrigger>
          <TabsTrigger value="effectiveness">Effectiveness</TabsTrigger>
          <TabsTrigger value="closure">Closure</TabsTrigger>
        </TabsList>
        <TabsContent value="origins" className="mt-4">
          <AdminConfigCRUDTable
            title="CAPA Origin Types"
            description="Sources that trigger CAPA creation"
            data={capaOriginTypes}
            columns={[
              { key: 'name', label: 'Name' },
              { key: 'description', label: 'Description' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Origin Type', type: 'text' },
              { key: 'description', label: 'Description', type: 'textarea' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', description: '', isActive: true, order: capaOriginTypes.length + 1 }}
            onAdd={(item) => { setCapaOriginTypes([...capaOriginTypes, item as any]); markChanged(); }}
            onEdit={(item) => { setCapaOriginTypes(capaOriginTypes.map(o => o.id === item.id ? item : o)); markChanged(); }}
            onDelete={(id) => { setCapaOriginTypes(capaOriginTypes.filter(o => o.id !== id)); markChanged(); }}
            reorderable
          />
        </TabsContent>
        <TabsContent value="slas" className="mt-4">
          <AdminConfigCRUDTable
            title="Severity & SLA Mapping"
            description="Configure due dates and warning thresholds by severity"
            data={capaSeveritySLAs}
            columns={[
              { key: 'severity', label: 'Severity' },
              { key: 'defaultDueDays', label: 'Due (Days)' },
              { key: 'reviewSlaDays', label: 'Review SLA (Days)' },
              { key: 'warningThresholdDays', label: 'Warning (Days)' },
            ]}
            formFields={[
              { key: 'severity', label: 'Severity Level', type: 'text' },
              { key: 'defaultDueDays', label: 'Default Due Days', type: 'number' },
              { key: 'reviewSlaDays', label: 'Review SLA Days', type: 'number' },
              { key: 'warningThresholdDays', label: 'Warning Threshold Days', type: 'number' },
            ]}
            defaultNewItem={{ severity: '', defaultDueDays: 30, reviewSlaDays: 5, warningThresholdDays: 5 }}
            onAdd={(item) => { setCapaSeveritySLAs([...capaSeveritySLAs, item as any]); markChanged(); }}
            onEdit={(item) => { setCapaSeveritySLAs(capaSeveritySLAs.map(s => s.id === item.id ? item : s)); markChanged(); }}
            onDelete={(id) => { setCapaSeveritySLAs(capaSeveritySLAs.filter(s => s.id !== id)); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="templates" className="mt-4">
          <AdminConfigCRUDTable
            title="CAPA Templates"
            description="Pre-configured templates with required sections"
            data={capaTemplates}
            columns={[
              { key: 'name', label: 'Template Name' },
              { key: 'description', label: 'Description' },
              { key: 'isLTC', label: 'LTC', render: (t) => t.isLTC ? <Badge>LTC</Badge> : '-' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Template Name', type: 'text' },
              { key: 'description', label: 'Description', type: 'textarea' },
              { key: 'requiresContainment', label: 'Requires Containment', type: 'switch' },
              { key: 'requiresRCA', label: 'Requires RCA', type: 'switch' },
              { key: 'requiresVerification', label: 'Requires Verification', type: 'switch' },
              { key: 'requiresEffectivenessMonitoring', label: 'Requires Effectiveness', type: 'switch' },
              { key: 'requiresManagementReview', label: 'Requires Management Review', type: 'switch' },
              { key: 'isLTC', label: 'LTC Template', type: 'switch' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', description: '', requiresContainment: false, requiresRCA: true, requiresPreventiveActions: true, requiresVerification: true, requiresEffectivenessMonitoring: false, requiresManagementReview: false, defaultActionTypes: [], monitoringDurationDays: 30, monitoringFrequency: 'Monthly', isLTC: false, isActive: true }}
            onAdd={(item) => { setCapaTemplates([...capaTemplates, item as any]); markChanged(); }}
            onEdit={(item) => { setCapaTemplates(capaTemplates.map(t => t.id === item.id ? item : t)); markChanged(); }}
            onDelete={(id) => { setCapaTemplates(capaTemplates.filter(t => t.id !== id)); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="actions" className="mt-4">
          <AdminConfigCRUDTable
            title="CAPA Action Types"
            description="Categories of corrective and preventive actions"
            data={capaActionTypes}
            columns={[
              { key: 'name', label: 'Name' },
              { key: 'description', label: 'Description' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Action Type', type: 'text' },
              { key: 'description', label: 'Description', type: 'textarea' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', description: '', isActive: true, order: capaActionTypes.length + 1 }}
            onAdd={(item) => { setCapaActionTypes([...capaActionTypes, item as any]); markChanged(); }}
            onEdit={(item) => { setCapaActionTypes(capaActionTypes.map(a => a.id === item.id ? item : a)); markChanged(); }}
            onDelete={(id) => { setCapaActionTypes(capaActionTypes.filter(a => a.id !== id)); markChanged(); }}
            reorderable
          />
        </TabsContent>
        <TabsContent value="rca" className="mt-4">
          <div className="space-y-6">
            <AdminConfigCRUDTable
              title="RCA Methods"
              description="Root cause analysis methodologies"
              data={rcaMethods}
              columns={[
                { key: 'name', label: 'Method' },
                { key: 'description', label: 'Description' },
                { key: 'isActive', label: 'Status' },
              ]}
              formFields={[
                { key: 'name', label: 'Method Name', type: 'text' },
                { key: 'description', label: 'Description', type: 'textarea' },
                { key: 'isActive', label: 'Active', type: 'switch' },
              ]}
              defaultNewItem={{ name: '', description: '', isActive: true, order: rcaMethods.length + 1 }}
              onAdd={(item) => { setRcaMethods([...rcaMethods, item as any]); markChanged(); }}
              onEdit={(item) => { setRcaMethods(rcaMethods.map(r => r.id === item.id ? item : r)); markChanged(); }}
              onDelete={(id) => { setRcaMethods(rcaMethods.filter(r => r.id !== id)); markChanged(); }}
            />
            <AdminConfigCRUDTable
              title="Contributing Factor Categories"
              description="Categories for root cause contributing factors"
              data={contributingFactors}
              columns={[
                { key: 'category', label: 'Category' },
                { key: 'name', label: 'Factor' },
                { key: 'isActive', label: 'Status' },
              ]}
              formFields={[
                { key: 'category', label: 'Category', type: 'text' },
                { key: 'name', label: 'Factor Name', type: 'text' },
                { key: 'isActive', label: 'Active', type: 'switch' },
              ]}
              defaultNewItem={{ category: '', name: '', isActive: true }}
              onAdd={(item) => { setContributingFactors([...contributingFactors, item as any]); markChanged(); }}
              onEdit={(item) => { setContributingFactors(contributingFactors.map(c => c.id === item.id ? item : c)); markChanged(); }}
              onDelete={(id) => { setContributingFactors(contributingFactors.filter(c => c.id !== id)); markChanged(); }}
            />
          </div>
        </TabsContent>
        <TabsContent value="verification" className="mt-4">
          <AdminConfigCRUDTable
            title="Verification Types"
            description="Types of verification for CAPA actions"
            data={verificationTypes}
            columns={[
              { key: 'name', label: 'Type' },
              { key: 'description', label: 'Description' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Verification Type', type: 'text' },
              { key: 'description', label: 'Description', type: 'textarea' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', description: '', isActive: true }}
            onAdd={(item) => { setVerificationTypes([...verificationTypes, item as any]); markChanged(); }}
            onEdit={(item) => { setVerificationTypes(verificationTypes.map(v => v.id === item.id ? item : v)); markChanged(); }}
            onDelete={(id) => { setVerificationTypes(verificationTypes.filter(v => v.id !== id)); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="effectiveness" className="mt-4">
          <AdminConfigCRUDTable
            title="Effectiveness KPIs"
            description="LTC-specific metrics for measuring CAPA effectiveness"
            data={effectivenessKPIs}
            columns={[
              { key: 'name', label: 'KPI' },
              { key: 'description', label: 'Description' },
              { key: 'unit', label: 'Unit' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'KPI Name', type: 'text' },
              { key: 'description', label: 'Description', type: 'textarea' },
              { key: 'unit', label: 'Unit of Measure', type: 'text' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', description: '', unit: '', isActive: true }}
            onAdd={(item) => { setEffectivenessKPIs([...effectivenessKPIs, item as any]); markChanged(); }}
            onEdit={(item) => { setEffectivenessKPIs(effectivenessKPIs.map(k => k.id === item.id ? item : k)); markChanged(); }}
            onDelete={(id) => { setEffectivenessKPIs(effectivenessKPIs.filter(k => k.id !== id)); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="closure" className="mt-4">
          <div className="space-y-6">
            <AdminConfigCRUDTable
              title="Closure Reasons"
              description="Valid reasons for closing a CAPA"
              data={closureReasons}
              columns={[
                { key: 'name', label: 'Reason' },
                { key: 'description', label: 'Description' },
                { key: 'requiresJustification', label: 'Requires Justification', render: (r) => r.requiresJustification ? 'Yes' : 'No' },
                { key: 'isActive', label: 'Status' },
              ]}
              formFields={[
                { key: 'name', label: 'Closure Reason', type: 'text' },
                { key: 'description', label: 'Description', type: 'textarea' },
                { key: 'requiresJustification', label: 'Requires Justification', type: 'switch' },
                { key: 'isActive', label: 'Active', type: 'switch' },
              ]}
              defaultNewItem={{ name: '', description: '', requiresJustification: false, isActive: true }}
              onAdd={(item) => { setClosureReasons([...closureReasons, item as any]); markChanged(); }}
              onEdit={(item) => { setClosureReasons(closureReasons.map(r => r.id === item.id ? item : r)); markChanged(); }}
              onDelete={(id) => { setClosureReasons(closureReasons.filter(r => r.id !== id)); markChanged(); }}
            />
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Closure & Reopen Rules</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between py-2 border-b">
                  <div>
                    <p className="text-sm font-medium">Management Review Required</p>
                    <p className="text-xs text-muted-foreground">Require sign-off before closure</p>
                  </div>
                  <Badge>Default: ON</Badge>
                </div>
                <div className="flex items-center justify-between py-2 border-b">
                  <div>
                    <p className="text-sm font-medium">Who Can Close/Reopen</p>
                    <p className="text-xs text-muted-foreground">Role restriction for closure</p>
                  </div>
                  <Badge variant="outline">Compliance Head, Admin</Badge>
                </div>
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium">Override Allowed</p>
                    <p className="text-xs text-muted-foreground">Allow override with justification</p>
                  </div>
                  <Badge>Yes (with justification)</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );

  const renderCitationsSection = () => (
    <div className="space-y-6">
      <Tabs defaultValue="sources" className="w-full">
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="sources">Sources</TabsTrigger>
          <TabsTrigger value="jurisdictions">Jurisdictions</TabsTrigger>
          <TabsTrigger value="facilitytypes">Facility Types</TabsTrigger>
          <TabsTrigger value="evidencetypes">Evidence Types</TabsTrigger>
          <TabsTrigger value="riskdomains">Risk Domains</TabsTrigger>
          <TabsTrigger value="versioning">Versioning</TabsTrigger>
        </TabsList>
        <TabsContent value="sources" className="mt-4">
          <AdminConfigCRUDTable
            title="Citation Sources"
            description="Regulatory bodies and standards organizations"
            data={citationSources}
            columns={[
              { key: 'name', label: 'Source' },
              { key: 'abbreviation', label: 'Abbreviation' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Source Name', type: 'text' },
              { key: 'abbreviation', label: 'Abbreviation', type: 'text' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', abbreviation: '', isActive: true, order: citationSources.length + 1 }}
            onAdd={(item) => { setCitationSources([...citationSources, item as any]); markChanged(); }}
            onEdit={(item) => { setCitationSources(citationSources.map(s => s.id === item.id ? item : s)); markChanged(); }}
            onDelete={(id) => { setCitationSources(citationSources.filter(s => s.id !== id)); markChanged(); }}
            reorderable
          />
        </TabsContent>
        <TabsContent value="jurisdictions" className="mt-4">
          <AdminConfigCRUDTable
            title="Jurisdictions"
            description="Federal, state, and local jurisdictions"
            data={jurisdictions}
            columns={[
              { key: 'name', label: 'Jurisdiction' },
              { key: 'type', label: 'Type' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Jurisdiction Name', type: 'text' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', type: 'State', isActive: true }}
            onAdd={(item) => { setJurisdictions([...jurisdictions, item as any]); markChanged(); }}
            onEdit={(item) => { setJurisdictions(jurisdictions.map(j => j.id === item.id ? item : j)); markChanged(); }}
            onDelete={(id) => { setJurisdictions(jurisdictions.filter(j => j.id !== id)); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="facilitytypes" className="mt-4">
          <AdminConfigCRUDTable
            title="Facility Types"
            description="Types of healthcare facilities"
            data={facilityTypes}
            columns={[
              { key: 'name', label: 'Facility Type' },
              { key: 'abbreviation', label: 'Abbreviation' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Facility Type', type: 'text' },
              { key: 'abbreviation', label: 'Abbreviation', type: 'text' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', abbreviation: '', isActive: true }}
            onAdd={(item) => { setFacilityTypes([...facilityTypes, item as any]); markChanged(); }}
            onEdit={(item) => { setFacilityTypes(facilityTypes.map(f => f.id === item.id ? item : f)); markChanged(); }}
            onDelete={(id) => { setFacilityTypes(facilityTypes.filter(f => f.id !== id)); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="evidencetypes" className="mt-4">
          <AdminConfigCRUDTable
            title="Evidence Types"
            description="Acceptable types of evidence for citations"
            data={evidenceTypes}
            columns={[
              { key: 'name', label: 'Evidence Type' },
              { key: 'description', label: 'Description' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Evidence Type', type: 'text' },
              { key: 'description', label: 'Description', type: 'textarea' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', description: '', isActive: true, order: evidenceTypes.length + 1 }}
            onAdd={(item) => { setEvidenceTypes([...evidenceTypes, item as any]); markChanged(); }}
            onEdit={(item) => { setEvidenceTypes(evidenceTypes.map(e => e.id === item.id ? item : e)); markChanged(); }}
            onDelete={(id) => { setEvidenceTypes(evidenceTypes.filter(e => e.id !== id)); markChanged(); }}
            reorderable
          />
        </TabsContent>
        <TabsContent value="riskdomains" className="mt-4">
          <AdminConfigCRUDTable
            title="Risk Domains"
            description="Risk categories for classification"
            data={riskDomains}
            columns={[
              { key: 'name', label: 'Domain' },
              { key: 'description', label: 'Description' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Domain Name', type: 'text' },
              { key: 'description', label: 'Description', type: 'textarea' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', description: '', isActive: true, order: riskDomains.length + 1 }}
            onAdd={(item) => { setRiskDomains([...riskDomains, item as any]); markChanged(); }}
            onEdit={(item) => { setRiskDomains(riskDomains.map(r => r.id === item.id ? item : r)); markChanged(); }}
            onDelete={(id) => { setRiskDomains(riskDomains.filter(r => r.id !== id)); markChanged(); }}
            reorderable
          />
        </TabsContent>
        <TabsContent value="versioning" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Versioning Rules</CardTitle>
              <CardDescription>Control citation version management</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <p className="text-sm font-medium">Auto-Supersede Old Versions</p>
                  <p className="text-xs text-muted-foreground">Automatically mark old version as superseded when publishing new</p>
                </div>
                <Badge>Enabled</Badge>
              </div>
              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="text-sm font-medium">Require Review Before Active</p>
                  <p className="text-xs text-muted-foreground">Citations must be reviewed before activation</p>
                </div>
                <Badge>Enabled</Badge>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );

  const renderCitationCasesSection = () => (
    <div className="space-y-6">
      <Tabs defaultValue="modes" className="w-full">
        <TabsList>
          <TabsTrigger value="modes">Authority Modes</TabsTrigger>
          <TabsTrigger value="timeliness">Timeliness Rules</TabsTrigger>
          <TabsTrigger value="closure">Closure Reasons</TabsTrigger>
          <TabsTrigger value="escalation">Escalation Rules</TabsTrigger>
        </TabsList>
        <TabsContent value="modes" className="mt-4">
          <AdminConfigCRUDTable
            title="Authority Type → Mode Mapping"
            description="Map authority types to their default operational mode"
            data={authorityModeMappings}
            columns={[
              { key: 'authorityType', label: 'Authority Type' },
              { key: 'defaultMode', label: 'Default Mode', render: (m) => <Badge variant="outline">{m.defaultMode}</Badge> },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'authorityType', label: 'Authority Type', type: 'text' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ authorityType: '', defaultMode: 'General', isActive: true }}
            onAdd={(item) => { setAuthorityModeMappings([...authorityModeMappings, item as any]); markChanged(); }}
            onEdit={(item) => { setAuthorityModeMappings(authorityModeMappings.map(m => m.id === item.id ? item : m)); markChanged(); }}
            onDelete={(id) => { setAuthorityModeMappings(authorityModeMappings.filter(m => m.id !== id)); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="timeliness" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Timeliness Rules</CardTitle>
              <CardDescription>Due date calculations and warning thresholds</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">PoC Mode (CMS/State)</h4>
                  <div className="space-y-2 text-sm">
                    <p><span className="text-muted-foreground">Due Calculation:</span> 2567 received + 10 days</p>
                    <p><span className="text-muted-foreground">Warnings at:</span> 7, 3, 1 days</p>
                    <p><span className="text-muted-foreground">Escalate to:</span> Compliance Head, Admin</p>
                  </div>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">ESC Mode (Joint Commission)</h4>
                  <div className="space-y-2 text-sm">
                    <p><span className="text-muted-foreground">Due Calculation:</span> Findings posted + 60 days</p>
                    <p><span className="text-muted-foreground">Warnings at:</span> 14, 7, 3 days</p>
                    <p><span className="text-muted-foreground">Escalate to:</span> Compliance Head, Admin</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="closure" className="mt-4">
          <AdminConfigCRUDTable
            title="Citation Case Closure Reasons"
            description="Valid reasons for closing a citation case"
            data={caseClosureReasons}
            columns={[
              { key: 'name', label: 'Reason' },
              { key: 'requiresOverride', label: 'Requires Override', render: (r) => r.requiresOverride ? 'Yes' : 'No' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Closure Reason', type: 'text' },
              { key: 'requiresOverride', label: 'Requires Override', type: 'switch' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', requiresOverride: false, isActive: true }}
            onAdd={(item) => { setCaseClosureReasons([...caseClosureReasons, item as any]); markChanged(); }}
            onEdit={(item) => { setCaseClosureReasons(caseClosureReasons.map(r => r.id === item.id ? item : r)); markChanged(); }}
            onDelete={(id) => { setCaseClosureReasons(caseClosureReasons.filter(r => r.id !== id)); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="escalation" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Auto-Escalation to CAPA Rules</CardTitle>
              <CardDescription>When to require CAPA linkage</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <p className="text-sm font-medium">High/Critical Severity</p>
                  <p className="text-xs text-muted-foreground">Require CAPA link for high severity cases</p>
                </div>
                <Badge>Required (or override)</Badge>
              </div>
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <p className="text-sm font-medium">Pattern/Widespread Scope</p>
                  <p className="text-xs text-muted-foreground">Require CAPA link when scope is systemic</p>
                </div>
                <Badge>Required (or override)</Badge>
              </div>
              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="text-sm font-medium">Override Authority</p>
                  <p className="text-xs text-muted-foreground">Who can override CAPA requirement</p>
                </div>
                <Badge variant="outline">Compliance Head only</Badge>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );

  const renderEvidenceSection = () => (
    <div className="space-y-6">
      <Tabs defaultValue="filetypes" className="w-full">
        <TabsList>
          <TabsTrigger value="filetypes">File Types</TabsTrigger>
          <TabsTrigger value="sensitivity">Sensitivity Tags</TabsTrigger>
          <TabsTrigger value="requirements">Requirements</TabsTrigger>
          <TabsTrigger value="retention">Retention</TabsTrigger>
        </TabsList>
        <TabsContent value="filetypes" className="mt-4">
          <AdminConfigCRUDTable
            title="Allowed File Types"
            description="Accepted file formats for uploads"
            data={allowedFileTypes}
            columns={[
              { key: 'extension', label: 'Extension' },
              { key: 'mimeType', label: 'MIME Type' },
              { key: 'maxSizeMB', label: 'Max Size (MB)' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'extension', label: 'File Extension', type: 'text' },
              { key: 'mimeType', label: 'MIME Type', type: 'text' },
              { key: 'maxSizeMB', label: 'Max Size (MB)', type: 'number' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ extension: '', mimeType: '', maxSizeMB: 10, isActive: true }}
            onAdd={(item) => { setAllowedFileTypes([...allowedFileTypes, item as any]); markChanged(); }}
            onEdit={(item) => { setAllowedFileTypes(allowedFileTypes.map(f => f.id === item.id ? item : f)); markChanged(); }}
            onDelete={(id) => { setAllowedFileTypes(allowedFileTypes.filter(f => f.id !== id)); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="sensitivity" className="mt-4">
          <AdminConfigCRUDTable
            title="Sensitivity Tags"
            description="Tags for classifying sensitive information"
            data={sensitivityTags}
            columns={[
              { key: 'name', label: 'Tag' },
              { key: 'description', label: 'Description' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Tag Name', type: 'text' },
              { key: 'description', label: 'Description', type: 'textarea' },
              { key: 'color', label: 'Color', type: 'text' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', description: '', color: 'yellow', isActive: true }}
            onAdd={(item) => { setSensitivityTags([...sensitivityTags, item as any]); markChanged(); }}
            onEdit={(item) => { setSensitivityTags(sensitivityTags.map(s => s.id === item.id ? item : s)); markChanged(); }}
            onDelete={(id) => { setSensitivityTags(sensitivityTags.filter(s => s.id !== id)); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="requirements" className="mt-4">
          <AdminConfigSettingsCard
            title="Evidence Requirements"
            description="Configure when evidence is mandatory"
            settings={{ requireIssueEvidence: true, requireCapaEvidence: true, requireCaseChecklist: true }}
            fields={[
              { key: 'requireIssueEvidence', label: 'Require Evidence for Issue Completion', description: 'Issues cannot be completed without evidence', type: 'switch' },
              { key: 'requireCapaEvidence', label: 'Require Evidence for CAPA Actions', description: 'CAPA actions marked evidence_required must have evidence', type: 'switch' },
              { key: 'requireCaseChecklist', label: 'Require Checklist for Citation Case QA', description: 'QA verification requires completed checklist', type: 'switch' },
            ]}
            onChange={(key, value) => { markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="retention" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Retention Labels</CardTitle>
              <CardDescription>Guidance for document retention (display only)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {mockRetentionLabels.map((label) => (
                  <div key={label.id} className="flex items-center justify-between py-2 border-b last:border-0">
                    <div>
                      <p className="text-sm font-medium">{label.name}</p>
                      <p className="text-xs text-muted-foreground">{label.description}</p>
                    </div>
                    <Badge variant="outline">{label.durationMonths} months</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );

  const renderNotificationsSection = () => (
    <div className="space-y-6">
      <Tabs defaultValue="templates" className="w-full">
        <TabsList>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="rules">Rules</TabsTrigger>
          <TabsTrigger value="escalation">Escalation Chains</TabsTrigger>
        </TabsList>
        <TabsContent value="templates" className="mt-4">
          <AdminConfigCRUDTable
            title="Notification Templates"
            description="Email and in-app notification templates"
            data={notificationTemplates}
            columns={[
              { key: 'name', label: 'Template' },
              { key: 'triggerEvent', label: 'Trigger Event' },
              { key: 'subject', label: 'Subject' },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'name', label: 'Template Name', type: 'text' },
              { key: 'triggerEvent', label: 'Trigger Event', type: 'text' },
              { key: 'subject', label: 'Subject Line', type: 'text' },
              { key: 'body', label: 'Body Text', type: 'textarea' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ name: '', triggerEvent: '', subject: '', body: '', isActive: true }}
            onAdd={(item) => { setNotificationTemplates([...notificationTemplates, item as any]); markChanged(); }}
            onEdit={(item) => { setNotificationTemplates(notificationTemplates.map(t => t.id === item.id ? item : t)); markChanged(); }}
            onDelete={(id) => { setNotificationTemplates(notificationTemplates.filter(t => t.id !== id)); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="rules" className="mt-4">
          <AdminConfigCRUDTable
            title="Notification Rules"
            description="Configure who receives notifications for each event"
            data={notificationRules}
            columns={[
              { key: 'module', label: 'Module' },
              { key: 'triggerEvent', label: 'Trigger Event' },
              { key: 'recipients', label: 'Recipients', render: (r) => r.recipients.join(', ') },
              { key: 'isActive', label: 'Status' },
            ]}
            formFields={[
              { key: 'triggerEvent', label: 'Trigger Event', type: 'text' },
              { key: 'isActive', label: 'Active', type: 'switch' },
            ]}
            defaultNewItem={{ module: 'Issues', triggerEvent: '', recipients: [], isActive: true }}
            onAdd={(item) => { setNotificationRules([...notificationRules, item as any]); markChanged(); }}
            onEdit={(item) => { setNotificationRules(notificationRules.map(r => r.id === item.id ? item : r)); markChanged(); }}
            onDelete={(id) => { setNotificationRules(notificationRules.filter(r => r.id !== id)); markChanged(); }}
          />
        </TabsContent>
        <TabsContent value="escalation" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Escalation Chains</CardTitle>
              <CardDescription>Define escalation paths with timing</CardDescription>
            </CardHeader>
            <CardContent>
              {mockEscalationChains.map((chain) => (
                <div key={chain.id} className="mb-4 p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">{chain.name}</h4>
                  <div className="flex items-center gap-2 flex-wrap">
                    {chain.levels.map((level, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <Badge variant="outline">{level.role}</Badge>
                        <span className="text-xs text-muted-foreground">after {level.delayHours}h</span>
                        {idx < chain.levels.length - 1 && <span className="text-muted-foreground">→</span>}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );

  const renderReportingSection = () => (
    <div className="space-y-6">
      <AdminConfigSettingsCard
        title="Reporting Settings"
        description="Configure report access and thresholds"
        settings={reportingSettings}
        fields={[
          { key: 'allowStaffExport', label: 'Allow Staff CSV Export', description: 'Staff role can download CSV reports', type: 'switch' },
          { key: 'issueAgingSLADays', label: 'Issue Aging SLA', description: 'Days before issue is flagged as at-risk', type: 'number', suffix: 'days' },
          { key: 'capaDueSLADays', label: 'CAPA Due SLA', description: 'Days before CAPA is flagged as at-risk', type: 'number', suffix: 'days' },
          { key: 'pocEscWarningDays', label: 'PoC/ESC Warning', description: 'Days before due date to show warning', type: 'number', suffix: 'days' },
          { key: 'savedViewsRetentionDays', label: 'Saved Views Retention', description: 'Days to keep saved report views', type: 'number', suffix: 'days' },
        ]}
        onChange={(key, value) => { setReportingSettings({ ...reportingSettings, [key]: value }); markChanged(); }}
      />
    </div>
  );

  const renderIntegrationsSection = () => (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2">
        {[
          { name: 'EHR Integration', description: 'Connect to Electronic Health Record systems' },
          { name: 'HR Training Systems', description: 'Sync with training and competency platforms' },
          { name: 'Document Repository', description: 'Link to document management systems' },
          { name: 'Incident Reporting', description: 'Integrate with incident reporting tools' },
        ].map((integration) => (
          <Card key={integration.name} className="opacity-60">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Plug className="h-4 w-4" />
                {integration.name}
              </CardTitle>
              <CardDescription>{integration.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <Badge variant="secondary">Coming Soon</Badge>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderSectionContent = () => {
    switch (activeSection) {
      case 'complianceconnect': return renderComplianceIssuesSection();
      case 'actionguard': return renderCAPASection();
      case 'citations': return renderCitationsSection();
      case 'citationcases': return renderCitationCasesSection();
      case 'evidence': return renderEvidenceSection();
      case 'notifications': return renderNotificationsSection();
      case 'reporting': return renderReportingSection();
      case 'integrations': return renderIntegrationsSection();
      default: return null;
    }
  };

  const currentSection = adminSections.find(s => s.id === activeSection);

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      {/* Left Subnav */}
      <aside className="w-64 border-r border-border bg-muted/30 p-4 space-y-1 overflow-y-auto shrink-0">
        <div className="flex items-center gap-2 mb-4 px-2">
          <Settings className="h-5 w-5 text-primary" />
          <h2 className="font-semibold">Admin Configuration</h2>
        </div>
        {adminSections.map((section) => (
          <button
            key={section.id}
            onClick={() => setActiveSection(section.id)}
            className={cn(
              'w-full flex items-start gap-3 p-3 rounded-lg text-left transition-colors',
              activeSection === section.id
                ? 'bg-primary text-primary-foreground'
                : 'hover:bg-muted text-foreground'
            )}
          >
            <section.icon className="h-5 w-5 shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-sm">{section.label}</p>
              <p className={cn(
                'text-xs',
                activeSection === section.id ? 'text-primary-foreground/70' : 'text-muted-foreground'
              )}>
                {section.description}
              </p>
            </div>
          </button>
        ))}
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top Actions Bar */}
        <div className="border-b border-border p-4 flex items-center justify-between bg-background shrink-0">
          <div>
            <h3 className="text-lg font-semibold">{currentSection?.label}</h3>
            <p className="text-sm text-muted-foreground">{currentSection?.description}</p>
          </div>
          <div className="flex items-center gap-2">
            {hasChanges && (
              <Badge variant="outline" className="text-yellow-600 border-yellow-600">Unsaved Changes</Badge>
            )}
            <Button variant="outline" size="sm" onClick={() => toast({ title: 'Audit Log', description: 'Viewing configuration audit log...' })}>
              <History className="h-4 w-4 mr-1" /> Audit Log
            </Button>
            <Button variant="outline" size="sm" onClick={handleCancel} disabled={!hasChanges}>
              <X className="h-4 w-4 mr-1" /> Cancel
            </Button>
            <Button variant="outline" size="sm" onClick={handleSave} disabled={!hasChanges}>
              <Save className="h-4 w-4 mr-1" /> Save Draft
            </Button>
            <Button size="sm" onClick={handlePublish} disabled={!hasChanges}>
              <Upload className="h-4 w-4 mr-1" /> Publish Changes
            </Button>
          </div>
        </div>

        {/* Content Area with Guidance Panel */}
        <div className="flex-1 overflow-y-auto">
          <div className="flex gap-6 p-6">
            <div className="flex-1 min-w-0">
              {renderSectionContent()}
            </div>
            <div className="w-72 shrink-0 hidden xl:block">
              <AdminGuidancePanel section={activeSection} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
