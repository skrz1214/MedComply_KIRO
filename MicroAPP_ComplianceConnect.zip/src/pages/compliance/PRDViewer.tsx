import { useState } from 'react';
import { FileDown, Printer, ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useNavigate } from 'react-router-dom';

export default function PRDViewer() {
  const navigate = useNavigate();

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header - hidden when printing */}
      <div className="print:hidden sticky top-0 z-10 bg-background border-b border-border px-6 py-4">
        <div className="flex items-center justify-between max-w-5xl mx-auto">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => navigate(-1)}>
              <ChevronLeft className="h-4 w-4 mr-1" /> Back
            </Button>
            <div>
              <h1 className="text-xl font-bold">Product Requirements Document</h1>
              <p className="text-sm text-muted-foreground">ComplianceConnect Platform v2.0</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={handlePrint}>
              <Printer className="h-4 w-4 mr-2" /> Print / Save PDF
            </Button>
          </div>
        </div>
      </div>

      {/* PRD Content */}
      <div className="max-w-5xl mx-auto px-6 py-8 print:p-0 print:max-w-none">
        <article className="prose prose-slate max-w-none print:prose-sm">
          {/* Title Page */}
          <div className="text-center mb-12 print:mb-8">
            <h1 className="text-4xl font-bold mb-4 print:text-3xl">ComplianceConnect Platform</h1>
            <h2 className="text-2xl text-muted-foreground mb-6 print:text-xl">Complete Product Requirements Document (PRD)</h2>
            <div className="flex justify-center gap-4 flex-wrap">
              <Badge variant="outline" className="text-sm">Version 2.0</Badge>
              <Badge variant="outline" className="text-sm">December 2024</Badge>
              <Badge variant="outline" className="text-sm">MedComply Suite</Badge>
            </div>
          </div>

          <Separator className="my-8" />

          {/* Table of Contents */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4">Table of Contents</h2>
            <ol className="list-decimal list-inside space-y-2 text-primary">
              <li><a href="#executive-summary" className="hover:underline">Executive Summary</a></li>
              <li><a href="#platform-overview" className="hover:underline">Platform Overview</a></li>
              <li><a href="#user-roles" className="hover:underline">User Roles & Permissions</a></li>
              <li><a href="#module-issues" className="hover:underline">Module A: ComplianceConnect Issues</a></li>
              <li><a href="#module-citations" className="hover:underline">Module B: Citations Library</a></li>
              <li><a href="#module-cases" className="hover:underline">Module C: Citation Cases</a></li>
              <li><a href="#module-capa" className="hover:underline">Module D: ActionGuard (CAPA)</a></li>
              <li><a href="#module-reports" className="hover:underline">Module E: Enterprise Reporting</a></li>
              <li><a href="#module-admin" className="hover:underline">Module F: Admin Configuration</a></li>
              <li><a href="#cross-module" className="hover:underline">Cross-Module Features</a></li>
              <li><a href="#technical" className="hover:underline">Technical Requirements</a></li>
              <li><a href="#appendix" className="hover:underline">Appendix</a></li>
            </ol>
          </section>

          <Separator className="my-8 print:hidden" />
          <div className="print:break-before-page" />

          {/* 1. Executive Summary */}
          <section id="executive-summary" className="mb-12">
            <h2 className="text-2xl font-bold mb-4">1. Executive Summary</h2>
            
            <h3 className="text-xl font-semibold mb-3">1.1 Purpose</h3>
            <p className="mb-4">
              ComplianceConnect is a comprehensive healthcare compliance management platform designed for Long-Term Care (LTC) providers, 
              Skilled Nursing Facilities (SNFs), hospitals, and clinics. The platform manages the complete lifecycle of compliance issues, 
              regulatory citations, and corrective/preventive actions (CAPA) with full audit trail and regulatory submission support.
            </p>

            <h3 className="text-xl font-semibold mb-3">1.2 Key Objectives</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li>Streamline compliance issue reporting and resolution workflows</li>
              <li>Maintain a centralized citation/standards library with evidence expectations</li>
              <li>Manage regulatory citation cases with PoC/ESC clock tracking</li>
              <li>Implement healthcare-grade CAPA workflows aligned with CMS, Joint Commission, and FDA requirements</li>
              <li>Provide enterprise-wide reporting and analytics</li>
              <li>Ensure WCAG 2.1 AA accessibility compliance</li>
              <li>Support PHI-safe handling with appropriate warnings and controls</li>
            </ul>

            <h3 className="text-xl font-semibold mb-3">1.3 Target Regulatory Frameworks</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li>CMS (Centers for Medicare & Medicaid Services) - CMS-2567 Plan of Correction</li>
              <li>Joint Commission - Evidence of Standards Compliance (ESC)</li>
              <li>State Department of Health (DOH) surveys</li>
              <li>HIPAA privacy and security requirements</li>
              <li>OSHA workplace safety</li>
              <li>21 CFR 820.100 (CAPA requirements)</li>
            </ul>
          </section>

          <div className="print:break-before-page" />

          {/* 2. Platform Overview */}
          <section id="platform-overview" className="mb-12">
            <h2 className="text-2xl font-bold mb-4">2. Platform Overview</h2>
            
            <h3 className="text-xl font-semibold mb-3">2.1 Architecture</h3>
            <Card className="mb-4">
              <CardContent className="pt-4">
                <pre className="text-xs overflow-x-auto bg-muted p-4 rounded">
{`┌─────────────────────────────────────────────────────────────────┐
│                    ComplianceConnect Platform                    │
├─────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Compliance   │  │  Citations   │  │    ActionGuard       │  │
│  │   Issues     │◄─┤   Library    │◄─┤      (CAPA)          │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
│         │                 │                      │              │
│         │    ┌────────────┴────────────┐        │              │
│         │    │     Citation Cases      │────────┘              │
│         │    └─────────────────────────┘                       │
│  ┌──────┴───────────────────────────────────────────────────┐  │
│  │              Cross-Module Connections Panel               │  │
│  └───────────────────────────────────────────────────────────┘  │
│  ┌──────────────────────┐  ┌──────────────────────────────────┐ │
│  │  Enterprise Reports  │  │      Admin Configuration         │ │
│  └──────────────────────┘  └──────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘`}
                </pre>
              </CardContent>
            </Card>

            <h3 className="text-xl font-semibold mb-3">2.2 Navigation Structure</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li>Dashboard</li>
              <li>Issues (ComplianceConnect)</li>
              <li>Citations (Library, Cases)</li>
              <li>ActionGuard (Dashboard, CAPAs, Approvals, My Work)</li>
              <li>Reports</li>
              <li>Admin Configuration</li>
            </ul>
          </section>

          <div className="print:break-before-page" />

          {/* 3. User Roles */}
          <section id="user-roles" className="mb-12">
            <h2 className="text-2xl font-bold mb-4">3. User Roles & Permissions</h2>
            
            <h3 className="text-xl font-semibold mb-3">3.1 Role Definitions</h3>
            <div className="overflow-x-auto mb-4">
              <table className="w-full border-collapse border border-border text-sm">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-2 text-left">Role</th>
                    <th className="border border-border p-2 text-left">Scope</th>
                    <th className="border border-border p-2 text-left">Description</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border border-border p-2 font-medium">Admin</td><td className="border border-border p-2">System-wide</td><td className="border border-border p-2">Full system control including configuration</td></tr>
                  <tr><td className="border border-border p-2 font-medium">Compliance Head</td><td className="border border-border p-2">Organization-wide</td><td className="border border-border p-2">Org-wide oversight, approvals, closures</td></tr>
                  <tr><td className="border border-border p-2 font-medium">Department Head</td><td className="border border-border p-2">Department-scoped</td><td className="border border-border p-2">Department management and assignments</td></tr>
                  <tr><td className="border border-border p-2 font-medium">Staff</td><td className="border border-border p-2">Personal</td><td className="border border-border p-2">Work assigned items, upload evidence</td></tr>
                </tbody>
              </table>
            </div>

            <h3 className="text-xl font-semibold mb-3">3.2 Permission Matrix</h3>
            <div className="overflow-x-auto mb-4">
              <table className="w-full border-collapse border border-border text-sm">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-2 text-left">Permission</th>
                    <th className="border border-border p-2 text-center">Admin</th>
                    <th className="border border-border p-2 text-center">Compliance Head</th>
                    <th className="border border-border p-2 text-center">Dept Head</th>
                    <th className="border border-border p-2 text-center">Staff</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border border-border p-2">Edit Admin Configuration</td><td className="border border-border p-2 text-center">✓</td><td className="border border-border p-2 text-center">Read-only</td><td className="border border-border p-2 text-center">✗</td><td className="border border-border p-2 text-center">✗</td></tr>
                  <tr><td className="border border-border p-2">View All Records</td><td className="border border-border p-2 text-center">✓</td><td className="border border-border p-2 text-center">✓</td><td className="border border-border p-2 text-center">Dept only</td><td className="border border-border p-2 text-center">Own only</td></tr>
                  <tr><td className="border border-border p-2">Create Issues</td><td className="border border-border p-2 text-center">✓</td><td className="border border-border p-2 text-center">✓</td><td className="border border-border p-2 text-center">✓</td><td className="border border-border p-2 text-center">✓</td></tr>
                  <tr><td className="border border-border p-2">Approve/Close CAPAs</td><td className="border border-border p-2 text-center">✓</td><td className="border border-border p-2 text-center">✓</td><td className="border border-border p-2 text-center">✗</td><td className="border border-border p-2 text-center">✗</td></tr>
                  <tr><td className="border border-border p-2">Export Reports</td><td className="border border-border p-2 text-center">✓</td><td className="border border-border p-2 text-center">✓</td><td className="border border-border p-2 text-center">✓</td><td className="border border-border p-2 text-center">Config</td></tr>
                </tbody>
              </table>
            </div>
          </section>

          <div className="print:break-before-page" />

          {/* 4. Module A: Issues */}
          <section id="module-issues" className="mb-12">
            <h2 className="text-2xl font-bold mb-4">4. Module A: ComplianceConnect Issues</h2>
            
            <h3 className="text-xl font-semibold mb-3">4.1 Issue Lifecycle Stages</h3>
            <Card className="mb-4">
              <CardContent className="pt-4">
                <pre className="text-xs overflow-x-auto bg-muted p-4 rounded">
{`Reported → Initiation → In Progress → QA Review → Completed
                              ↑              │
                              └──────────────┘ (Return for revision)
                                              ↓
                                         Monitoring (Optional)`}
                </pre>
              </CardContent>
            </Card>

            <h3 className="text-xl font-semibold mb-3">4.2 Issue Reporting Wizard (4 Steps)</h3>
            <ol className="list-decimal list-inside mb-4 space-y-2">
              <li><strong>Basic Information:</strong> Title, description, department, facility, date discovered</li>
              <li><strong>Classification:</strong> Issue type, category (recommended actions shown after BOTH selected), priority, severity</li>
              <li><strong>Action Steps:</strong> Select recommended actions, add custom steps (NO attachments at this step)</li>
              <li><strong>Assignment & Evidence:</strong> Assign user, due date, upload attachments, cross-app linking</li>
            </ol>

            <h3 className="text-xl font-semibold mb-3">4.3 Issue Detail Page Tabs</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li><strong>Work:</strong> Current stage action steps, attachment uploads</li>
              <li><strong>Stage Details:</strong> History of each workflow stage</li>
              <li><strong>Files:</strong> Aggregated attachments across stages</li>
              <li><strong>Connections:</strong> Linked Citations, CAPAs, external references</li>
              <li><strong>History:</strong> Audit log timeline</li>
            </ul>

            <h3 className="text-xl font-semibold mb-3">4.4 QA Review Options</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li>Approve & Complete</li>
              <li>Return for Revision (with comments)</li>
              <li>Approve, Complete & Route to Monitoring (Risk/Enforcement/Audit/Compliance)</li>
            </ul>
          </section>

          <div className="print:break-before-page" />

          {/* 5. Module B: Citations */}
          <section id="module-citations" className="mb-12">
            <h2 className="text-2xl font-bold mb-4">5. Module B: Citations Library</h2>
            
            <h3 className="text-xl font-semibold mb-3">5.1 Citation Sources</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li>CMS (Centers for Medicare & Medicaid Services)</li>
              <li>Joint Commission</li>
              <li>State DOH</li>
              <li>HIPAA</li>
              <li>OSHA</li>
              <li>Internal Policy</li>
            </ul>

            <h3 className="text-xl font-semibold mb-3">5.2 Citation Status Lifecycle</h3>
            <p className="mb-4">Draft → Active → Deprecated | Superseded</p>

            <h3 className="text-xl font-semibold mb-3">5.3 Citation Detail Tabs</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li>Overview, Citation Text, Evidence Expectations (CRUD)</li>
              <li>Mappings (CRUD), Remediation Steps (CRUD)</li>
              <li>Linked Work, Files, History</li>
            </ul>

            <h3 className="text-xl font-semibold mb-3">5.4 Quality Indicators</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li><strong>Unmapped:</strong> Active citations without control/policy mappings</li>
              <li><strong>Missing Evidence:</strong> Citations without evidence expectations</li>
            </ul>
          </section>

          <div className="print:break-before-page" />

          {/* 6. Module C: Citation Cases */}
          <section id="module-cases" className="mb-12">
            <h2 className="text-2xl font-bold mb-4">6. Module C: Citation Cases</h2>
            
            <h3 className="text-xl font-semibold mb-3">6.1 Authority Types & Modes</h3>
            <div className="overflow-x-auto mb-4">
              <table className="w-full border-collapse border border-border text-sm">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-2 text-left">Authority</th>
                    <th className="border border-border p-2 text-left">Mode</th>
                    <th className="border border-border p-2 text-left">Clock Calculation</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border border-border p-2">CMS/State Survey</td><td className="border border-border p-2">PoC</td><td className="border border-border p-2">cms2567_received + 10 days</td></tr>
                  <tr><td className="border border-border p-2">Joint Commission</td><td className="border border-border p-2">ESC</td><td className="border border-border p-2">report_posted + 60 days</td></tr>
                  <tr><td className="border border-border p-2">Internal Audit</td><td className="border border-border p-2">General</td><td className="border border-border p-2">Organization SLA</td></tr>
                </tbody>
              </table>
            </div>

            <h3 className="text-xl font-semibold mb-3">6.2 Citation Case Lifecycle</h3>
            <p className="mb-4">Draft → Reported → Triage (Mandatory) → Remediation → QA Verification → Closed → Monitoring</p>

            <h3 className="text-xl font-semibold mb-3">6.3 Triage Phase Requirements</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li>Confirm citation selection and version</li>
              <li>Set severity/priority with rationale</li>
              <li>For TJC: Set SAFER-like fields (impact, scope)</li>
              <li>Choose remediation path (Link/Create Issue, Link/Create CAPA, Quick Fix)</li>
              <li>If High/Critical OR Pattern/Widespread: CAPA required or Compliance Head override</li>
            </ul>
          </section>

          <div className="print:break-before-page" />

          {/* 7. Module D: CAPA */}
          <section id="module-capa" className="mb-12">
            <h2 className="text-2xl font-bold mb-4">7. Module D: ActionGuard (CAPA)</h2>
            
            <h3 className="text-xl font-semibold mb-3">7.1 CAPA Status Lifecycle</h3>
            <p className="mb-4">Draft → Submitted → In Review → Approved → In Progress → Verification → Effectiveness → Closed | Reopened</p>

            <h3 className="text-xl font-semibold mb-3">7.2 CAPA Buckets</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li><strong>NEW:</strong> Draft, Submitted, In Review</li>
              <li><strong>OPEN:</strong> Approved, In Progress, Verification, Effectiveness, Reopened</li>
              <li><strong>CLOSED:</strong> Closed</li>
            </ul>

            <h3 className="text-xl font-semibold mb-3">7.3 CAPA Origin Types (LTC-Specific)</h3>
            <ol className="list-decimal list-inside mb-4 space-y-1 text-sm">
              <li>CMS/State Survey Deficiency (CMS-2567)</li>
              <li>Internal Audit/Mock Survey Finding</li>
              <li>Resident Incident/Near Miss</li>
              <li>Abuse/Neglect Allegation</li>
              <li>Complaint/Grievance</li>
              <li>Infection Prevention/Outbreak</li>
              <li>Medication Error/Pharmacy</li>
              <li>Dietary/Kitchen</li>
              <li>Life Safety/Environment of Care</li>
              <li>Staffing/Competency</li>
              <li>Documentation/Records</li>
              <li>Policy/Procedure Gap</li>
              <li>Other</li>
            </ol>

            <h3 className="text-xl font-semibold mb-3">7.4 CAPA Creation Wizard (6 Steps)</h3>
            <ol className="list-decimal list-inside mb-4 space-y-1">
              <li>Basics & Template Selection</li>
              <li>Containment/Immediate Correction</li>
              <li>Root Cause Analysis</li>
              <li>Action Plan (Corrective & Preventive)</li>
              <li>Monitoring & Effectiveness</li>
              <li>Review & Submit</li>
            </ol>

            <h3 className="text-xl font-semibold mb-3">7.5 Management Review Requirement</h3>
            <p className="mb-4">Required for High/Critical severity or CMS/State Survey origin. Requires Compliance Head sign-off before closure.</p>
          </section>

          <div className="print:break-before-page" />

          {/* 8. Module E: Reports */}
          <section id="module-reports" className="mb-12">
            <h2 className="text-2xl font-bold mb-4">8. Module E: Enterprise Reporting</h2>
            
            <h3 className="text-xl font-semibold mb-3">8.1 Report Catalog (12 Reports)</h3>
            <div className="overflow-x-auto mb-4">
              <table className="w-full border-collapse border border-border text-sm">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-2 text-left">Domain</th>
                    <th className="border border-border p-2 text-left">Reports</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border border-border p-2">Executive</td><td className="border border-border p-2">R0: Executive Compliance Overview</td></tr>
                  <tr><td className="border border-border p-2">Issues</td><td className="border border-border p-2">R1: Inventory, R2: Aging, R3: QA Outcomes</td></tr>
                  <tr><td className="border border-border p-2">CAPA</td><td className="border border-border p-2">R4: Workload, R5: Overdue, R6: Cycle Time, R7: Effectiveness</td></tr>
                  <tr><td className="border border-border p-2">Citations</td><td className="border border-border p-2">R8: Library Coverage, R9: Cases, R10: PoC/ESC Timeliness</td></tr>
                  <tr><td className="border border-border p-2">Cross-Module</td><td className="border border-border p-2">R11: Evidence Gaps, R12: Repeat Findings</td></tr>
                </tbody>
              </table>
            </div>

            <h3 className="text-xl font-semibold mb-3">8.2 CSV Export Requirements</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li>Respects current filters, search, sort, selected columns</li>
              <li>Exports ALL rows (not just current page)</li>
              <li>Includes metadata (report name, timestamp, filters)</li>
              <li>File naming: ComplianceConnect_&lt;Report&gt;_&lt;Date&gt;_&lt;Time&gt;.csv</li>
            </ul>
          </section>

          <div className="print:break-before-page" />

          {/* 9. Module F: Admin */}
          <section id="module-admin" className="mb-12">
            <h2 className="text-2xl font-bold mb-4">9. Module F: Admin Configuration</h2>
            
            <h3 className="text-xl font-semibold mb-3">9.1 Configuration Sections</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li><strong>Compliance Issues:</strong> Types, Categories, Priorities, Workflow, Recommended Actions, Monitoring</li>
              <li><strong>CAPA:</strong> Origins, SLAs, Templates, Action Types, RCA Methods, Verification, Effectiveness, Closure</li>
              <li><strong>Citations:</strong> Sources, Jurisdictions, Facility Types, Evidence Types, Risk Domains, Versioning</li>
              <li><strong>Citation Cases:</strong> Authority Modes, Timeliness, Closure Reasons, Auto-escalation</li>
              <li><strong>Evidence:</strong> File Types, Sensitivity Tags, Requirements, Retention</li>
              <li><strong>Notifications:</strong> Templates, Rules, Escalation Chains</li>
              <li><strong>Reporting:</strong> Role Access, SLAs, Saved Views</li>
            </ul>

            <h3 className="text-xl font-semibold mb-3">9.2 Recommended Actions Configuration</h3>
            <p className="mb-4">When configuring recommended actions, set:</p>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li>Issue Type (required)</li>
              <li>Category Rule (all or specific)</li>
              <li>Priority Condition (any or specific)</li>
              <li>Default Owner Role, Due Days</li>
              <li>Evidence Required toggle</li>
              <li>Source URL reference</li>
            </ul>
          </section>

          <div className="print:break-before-page" />

          {/* 10. Cross-Module */}
          <section id="cross-module" className="mb-12">
            <h2 className="text-2xl font-bold mb-4">10. Cross-Module Features</h2>
            
            <h3 className="text-xl font-semibold mb-3">10.1 Connections Panel</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li>Issue ↔ Citation(s)</li>
              <li>Issue ↔ CAPA(s)</li>
              <li>CAPA ↔ Citation(s)</li>
              <li>Citation ↔ Citation Case(s)</li>
            </ul>

            <h3 className="text-xl font-semibold mb-3">10.2 Cross-Microapp References</h3>
            <p className="mb-4">External connections to: RiskGuard, AuditPro, FeedbackHub, EnforcementPoint</p>

            <h3 className="text-xl font-semibold mb-3">10.3 PHI-Safe UX</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li>Warnings near free text and upload fields</li>
              <li>Sensitivity tagging (PHI, PII, Internal Only, Public)</li>
              <li>Redaction notes support</li>
            </ul>
          </section>

          <div className="print:break-before-page" />

          {/* 11. Technical */}
          <section id="technical" className="mb-12">
            <h2 className="text-2xl font-bold mb-4">11. Technical Requirements</h2>
            
            <h3 className="text-xl font-semibold mb-3">11.1 Accessibility (WCAG 2.1 AA)</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li>Keyboard navigation for all elements</li>
              <li>Focus states clearly visible</li>
              <li>ARIA labels on controls</li>
              <li>Semantic HTML, single H1 per page</li>
              <li>Color contrast ≥ 4.5:1</li>
            </ul>

            <h3 className="text-xl font-semibold mb-3">11.2 Security</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li>Role-based access control (RBAC)</li>
              <li>Audit logging of all actions</li>
              <li>PHI/PII handling warnings</li>
              <li>Server-side permission checks</li>
            </ul>
          </section>

          <div className="print:break-before-page" />

          {/* 12. Appendix */}
          <section id="appendix" className="mb-12">
            <h2 className="text-2xl font-bold mb-4">12. Appendix</h2>
            
            <h3 className="text-xl font-semibold mb-3">12.1 Glossary</h3>
            <div className="overflow-x-auto mb-4">
              <table className="w-full border-collapse border border-border text-sm">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-2 text-left">Term</th>
                    <th className="border border-border p-2 text-left">Definition</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border border-border p-2">CAPA</td><td className="border border-border p-2">Corrective and Preventive Action</td></tr>
                  <tr><td className="border border-border p-2">CMS</td><td className="border border-border p-2">Centers for Medicare & Medicaid Services</td></tr>
                  <tr><td className="border border-border p-2">ESC</td><td className="border border-border p-2">Evidence of Standards Compliance (Joint Commission)</td></tr>
                  <tr><td className="border border-border p-2">LTC</td><td className="border border-border p-2">Long-Term Care</td></tr>
                  <tr><td className="border border-border p-2">PoC</td><td className="border border-border p-2">Plan of Correction</td></tr>
                  <tr><td className="border border-border p-2">RCA</td><td className="border border-border p-2">Root Cause Analysis</td></tr>
                  <tr><td className="border border-border p-2">SNF</td><td className="border border-border p-2">Skilled Nursing Facility</td></tr>
                </tbody>
              </table>
            </div>

            <h3 className="text-xl font-semibold mb-3">12.2 Date Calculations</h3>
            <ul className="list-disc list-inside mb-4 space-y-1">
              <li><strong>PoC Due:</strong> cms2567_received_date + 10 calendar days</li>
              <li><strong>ESC Due:</strong> authority_report_posted_date + 60 calendar days</li>
              <li><strong>Warnings:</strong> PoC: 7, 3, 1 days | ESC: 14, 7, 3 days</li>
            </ul>
          </section>

          <Separator className="my-8" />

          {/* Footer */}
          <footer className="text-center text-sm text-muted-foreground">
            <p>Document Control: Version 2.0 | December 2024 | ComplianceConnect Product Team</p>
          </footer>
        </article>
      </div>

      {/* Print styles */}
      <style>{`
        @media print {
          body { 
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          .print\\:break-before-page { break-before: page; }
          .print\\:hidden { display: none !important; }
          .print\\:p-0 { padding: 0 !important; }
          .print\\:max-w-none { max-width: none !important; }
          .print\\:prose-sm { font-size: 12px !important; }
          .print\\:text-3xl { font-size: 1.875rem !important; }
          .print\\:text-xl { font-size: 1.25rem !important; }
          .print\\:mb-8 { margin-bottom: 2rem !important; }
        }
      `}</style>
    </div>
  );
}
