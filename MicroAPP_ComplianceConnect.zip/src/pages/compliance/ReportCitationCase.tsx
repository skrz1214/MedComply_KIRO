import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '@/components/compliance/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { AttachmentUploader } from '@/components/compliance/AttachmentUploader';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { mockCitations } from '@/data/mockData';
import { 
  ArrowLeft, 
  ArrowRight, 
  Check, 
  FileText,
  Search,
  ClipboardList,
  Users,
  AlertTriangle,
  BookOpen,
  ExternalLink,
  Link2,
  Shield,
  FileSearch,
  MessageSquare,
  Scale,
  X,
  Plus
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import type { 
  CitationCaseAuthorityType, 
  CitationCaseOrigin, 
  RiskDomain, 
  Priority,
  Department,
  Attachment
} from '@/types/compliance';
import { microappConfigs, type CrossReference, type MicroappType, type CrossReferenceItemType } from '@/types/crossReference';

interface FormData {
  title: string;
  description: string;
  origin: CitationCaseOrigin | '';
  facility: string;
  department: Department | '';
  reporter: string;
  citationId: string;
  findingsSummary: string;
  severity: Priority;
  priority: Priority;
  tags: string[];
  owner: string;
  ownerDepartment: string;
  triageDueDate: string;
  remediationDueDate: string;
  authorityType: CitationCaseAuthorityType | '';
  cms2567ReceivedDate: string;
  authorityReportPostedDate: string;
}

const steps = [
  { id: 1, name: 'Basics', icon: FileText },
  { id: 2, name: 'Select Citation', icon: Search },
  { id: 3, name: 'Finding Details', icon: ClipboardList },
  { id: 4, name: 'Evidence & Assignment', icon: Users },
];

export default function ReportCitationCase() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [citationSearch, setCitationSearch] = useState('');
  const [formData, setFormData] = useState<FormData>({
    title: '',
    description: '',
    origin: '',
    facility: '',
    department: '',
    reporter: '',
    citationId: '',
    findingsSummary: '',
    severity: 'medium',
    priority: 'medium',
    tags: [],
    owner: '',
    ownerDepartment: '',
    triageDueDate: '',
    remediationDueDate: '',
    authorityType: '',
    cms2567ReceivedDate: '',
    authorityReportPostedDate: '',
  });
  const [tagInput, setTagInput] = useState('');
  const [crossReferences, setCrossReferences] = useState<Array<{
    microapp: MicroappType;
    itemType: CrossReferenceItemType;
    itemId: string;
    itemTitle: string;
  }>>([]);
  const [showCrossRefForm, setShowCrossRefForm] = useState(false);
  const [newCrossRef, setNewCrossRef] = useState({
    microapp: '' as MicroappType | '',
    itemType: '' as CrossReferenceItemType | '',
    itemId: '',
    itemTitle: ''
  });

  const externalMicroapps = microappConfigs.filter(m => 
    ['riskguard', 'auditpro', 'feedbackhub', 'enforcementpoint'].includes(m.id)
  );

  const getMicroappIcon = (microapp: MicroappType) => {
    switch (microapp) {
      case 'riskguard': return Shield;
      case 'auditpro': return FileSearch;
      case 'feedbackhub': return MessageSquare;
      case 'enforcementpoint': return Scale;
      default: return Link2;
    }
  };

  const handleAddCrossRef = () => {
    if (newCrossRef.microapp && newCrossRef.itemType && newCrossRef.itemId && newCrossRef.itemTitle) {
      setCrossReferences(prev => [...prev, {
        microapp: newCrossRef.microapp as MicroappType,
        itemType: newCrossRef.itemType as CrossReferenceItemType,
        itemId: newCrossRef.itemId,
        itemTitle: newCrossRef.itemTitle
      }]);
      setNewCrossRef({ microapp: '', itemType: '', itemId: '', itemTitle: '' });
      setShowCrossRefForm(false);
    }
  };

  const handleRemoveCrossRef = (index: number) => {
    setCrossReferences(prev => prev.filter((_, i) => i !== index));
  };

  const updateFormData = (field: keyof FormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const selectedCitation = mockCitations.find(c => c.id === formData.citationId);

  const filteredCitations = mockCitations.filter(c =>
    c.title.toLowerCase().includes(citationSearch.toLowerCase()) ||
    c.citationCode.toLowerCase().includes(citationSearch.toLowerCase())
  );

  const handleAddTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      updateFormData('tags', [...formData.tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    updateFormData('tags', formData.tags.filter(t => t !== tag));
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return formData.title && formData.origin && formData.facility && formData.department && formData.reporter;
      case 2:
        return formData.citationId;
      case 3:
        return formData.findingsSummary && formData.severity;
      case 4:
        return formData.owner && formData.ownerDepartment;
      default:
        return false;
    }
  };

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const getSourceBadgeColor = (source: string) => {
    switch (source) {
      case 'cms': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'joint_commission': return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
      case 'state_doh': return 'bg-orange-500/10 text-orange-600 border-orange-500/20';
      case 'hipaa': return 'bg-red-500/10 text-red-600 border-red-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const handleSubmit = () => {
    toast({
      title: 'Citation Case Reported',
      description: `Case has been created and routed to triage.`,
    });
    navigate('/citations/cases');
  };

  return (
    <div className="min-h-screen">
      <Header 
        title="Report Citation Case" 
        subtitle="Create a new citation deficiency case" 
      />

      <div className="p-6 space-y-6">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate('/citations/cases')}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Citation Cases
        </Button>

        {/* Stepper */}
        <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isActive = currentStep === step.id;
              const isCompleted = currentStep > step.id;
              
              return (
                <div key={step.id} className="flex items-center flex-1">
                  <div className="flex flex-col items-center">
                    <div className={cn(
                      'w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all',
                      isActive && 'border-primary bg-primary text-white',
                      isCompleted && 'border-success bg-success text-white',
                      !isActive && !isCompleted && 'border-muted-foreground/30 text-muted-foreground'
                    )}>
                      {isCompleted ? <Check className="h-5 w-5" /> : <Icon className="h-5 w-5" />}
                    </div>
                    <span className={cn(
                      'text-xs mt-2 font-medium',
                      isActive && 'text-primary',
                      isCompleted && 'text-success',
                      !isActive && !isCompleted && 'text-muted-foreground'
                    )}>
                      {step.name}
                    </span>
                  </div>
                  {index < steps.length - 1 && (
                    <div className={cn(
                      'flex-1 h-0.5 mx-4 mt-[-1rem]',
                      isCompleted ? 'bg-success' : 'bg-muted'
                    )} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Form Content */}
        <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
          {/* Step 1: Basics */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Case Basic Information</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Enter the basic details for this citation case.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2 md:col-span-2">
                  <Label>Case Title *</Label>
                  <Input
                    placeholder="Brief descriptive title for this case"
                    value={formData.title}
                    onChange={(e) => updateFormData('title', e.target.value)}
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label>Description</Label>
                  <Textarea
                    placeholder="Brief description of the deficiency..."
                    value={formData.description}
                    onChange={(e) => updateFormData('description', e.target.value)}
                    className="min-h-[80px]"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Origin *</Label>
                  <Select value={formData.origin} onValueChange={(v) => updateFormData('origin', v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select origin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="survey_inspection">Survey/Inspection</SelectItem>
                      <SelectItem value="internal_audit">Internal Audit</SelectItem>
                      <SelectItem value="complaint">Complaint</SelectItem>
                      <SelectItem value="incident_event">Incident/Event</SelectItem>
                      <SelectItem value="rounds">Rounds</SelectItem>
                      <SelectItem value="self_assessment">Self-Assessment</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Authority Type *</Label>
                  <Select value={formData.authorityType} onValueChange={(v) => updateFormData('authorityType', v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select authority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cms_state_survey">CMS/State Survey</SelectItem>
                      <SelectItem value="joint_commission">Joint Commission</SelectItem>
                      <SelectItem value="internal_audit">Internal Audit</SelectItem>
                      <SelectItem value="other_accreditor">Other Accreditor</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Facility *</Label>
                  <Select value={formData.facility} onValueChange={(v) => updateFormData('facility', v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select facility" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Main Hospital">Main Hospital</SelectItem>
                      <SelectItem value="Downtown Clinic">Downtown Clinic</SelectItem>
                      <SelectItem value="Sunrise Nursing Home">Sunrise Nursing Home</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Department *</Label>
                  <Select value={formData.department} onValueChange={(v) => updateFormData('department', v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nursing">Nursing</SelectItem>
                      <SelectItem value="pharmacy">Pharmacy</SelectItem>
                      <SelectItem value="laboratory">Laboratory</SelectItem>
                      <SelectItem value="radiology">Radiology</SelectItem>
                      <SelectItem value="administration">Administration</SelectItem>
                      <SelectItem value="it">IT</SelectItem>
                      <SelectItem value="quality_assurance">Quality Assurance</SelectItem>
                      <SelectItem value="compliance">Compliance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Reporter *</Label>
                  <Input
                    placeholder="Your name or surveyor name"
                    value={formData.reporter}
                    onChange={(e) => updateFormData('reporter', e.target.value)}
                  />
                </div>

                {formData.authorityType === 'cms_state_survey' && (
                  <div className="space-y-2">
                    <Label>CMS-2567 Received Date</Label>
                    <Input
                      type="date"
                      value={formData.cms2567ReceivedDate}
                      onChange={(e) => updateFormData('cms2567ReceivedDate', e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">PoC due 10 days from receipt</p>
                  </div>
                )}

                {formData.authorityType === 'joint_commission' && (
                  <div className="space-y-2">
                    <Label>Final Summary Posted Date</Label>
                    <Input
                      type="date"
                      value={formData.authorityReportPostedDate}
                      onChange={(e) => updateFormData('authorityReportPostedDate', e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">ESC due 60 days from posting</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Step 2: Select Citation */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Select Citation</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Choose the regulatory citation this case relates to.
                </p>
              </div>

              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search citations by code or title..."
                  value={citationSearch}
                  onChange={(e) => setCitationSearch(e.target.value)}
                  className="pl-10"
                />
              </div>

              <div className="space-y-3 max-h-[400px] overflow-y-auto">
                {filteredCitations.map((citation) => (
                  <Card 
                    key={citation.id}
                    className={cn(
                      'cursor-pointer transition-all',
                      formData.citationId === citation.id 
                        ? 'border-primary ring-1 ring-primary bg-primary/5' 
                        : 'hover:border-primary/50'
                    )}
                    onClick={() => updateFormData('citationId', citation.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="p-2 rounded-lg bg-primary/10">
                          <BookOpen className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-mono text-sm text-muted-foreground">{citation.citationCode}</span>
                            <Badge variant="outline" className={getSourceBadgeColor(citation.source)}>
                              {citation.source.replace('_', ' ')}
                            </Badge>
                          </div>
                          <h4 className="font-medium">{citation.title}</h4>
                          <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                            {citation.fullText?.substring(0, 120)}...
                          </p>
                          <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                            <span>{citation.evidenceExpectations?.length || 0} evidence expectations</span>
                            <span>{citation.remediationSteps?.length || 0} remediation steps</span>
                          </div>
                        </div>
                        {formData.citationId === citation.id && (
                          <Check className="h-5 w-5 text-primary" />
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {selectedCitation && (
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/30">
                  <h4 className="font-semibold text-foreground mb-3">Selected Citation Evidence Expectations:</h4>
                  <ul className="text-sm space-y-2">
                    {selectedCitation.evidenceExpectations.map((ee) => (
                      <li key={ee.id} className="flex items-start gap-2">
                        <Check className="h-4 w-4 mt-0.5 text-primary shrink-0" />
                        <span className="text-foreground">{ee.description}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* Step 3: Finding Details */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Finding Details</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Document the specific findings and assessment.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-warning/10 border border-warning/20 flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-warning mt-0.5 shrink-0" />
                <p className="text-sm text-warning-foreground">
                  <strong>PHI/PII Warning:</strong> Do not include patient or employee personal information in findings summary.
                </p>
              </div>

              <div className="space-y-2">
                <Label>Findings Summary *</Label>
                <Textarea
                  placeholder="Describe what was observed during the survey/audit..."
                  value={formData.findingsSummary}
                  onChange={(e) => updateFormData('findingsSummary', e.target.value)}
                  className="min-h-[150px]"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Severity *</Label>
                  <Select value={formData.severity} onValueChange={(v: Priority) => updateFormData('severity', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Priority *</Label>
                  <Select value={formData.priority} onValueChange={(v: Priority) => updateFormData('priority', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Tags</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Add a tag..."
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                  />
                  <Button type="button" variant="outline" onClick={handleAddTag}>
                    Add
                  </Button>
                </div>
                {formData.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {formData.tags.map(tag => (
                      <Badge 
                        key={tag} 
                        variant="secondary"
                        className="cursor-pointer hover:bg-destructive/20"
                        onClick={() => handleRemoveTag(tag)}
                      >
                        {tag} ×
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Step 4: Evidence & Assignment */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Evidence & Assignment</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Upload supporting evidence and assign ownership.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-warning/10 border border-warning/20 flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-warning mt-0.5 shrink-0" />
                <p className="text-sm text-warning-foreground">
                  <strong>Sensitivity Notice:</strong> Tag any files containing PHI/PII appropriately.
                </p>
              </div>

              <div className="space-y-2">
                <Label>Upload Evidence</Label>
                <AttachmentUploader
                  attachments={attachments}
                  onAttachmentsChange={setAttachments}
                  stage="reported"
                  uploadedBy={formData.reporter}
                  isEditable={true}
                />
              </div>

              {/* Cross-Microapp Linking */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="flex items-center gap-2">
                    <Link2 className="h-4 w-4" />
                    Cross-Reference to Other Modules
                  </Label>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setShowCrossRefForm(true)}
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add Link
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground">
                  Link this case to related items in RiskGuard, AuditPro, FeedbackHub, or EnforcementPoint.
                </p>

                {showCrossRefForm && (
                  <Card className="border-primary/30">
                    <CardContent className="p-4 space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Module</Label>
                          <Select 
                            value={newCrossRef.microapp} 
                            onValueChange={(v: MicroappType) => setNewCrossRef(prev => ({ 
                              ...prev, 
                              microapp: v, 
                              itemType: '' 
                            }))}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select module" />
                            </SelectTrigger>
                            <SelectContent>
                              {externalMicroapps.map(m => (
                                <SelectItem key={m.id} value={m.id}>
                                  {m.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label>Item Type</Label>
                          <Select 
                            value={newCrossRef.itemType}
                            onValueChange={(v: CrossReferenceItemType) => setNewCrossRef(prev => ({ ...prev, itemType: v }))}
                            disabled={!newCrossRef.microapp}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                            <SelectContent>
                              {newCrossRef.microapp && externalMicroapps
                                .find(m => m.id === newCrossRef.microapp)
                                ?.itemTypes.map(type => (
                                  <SelectItem key={type} value={type}>
                                    {type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                  </SelectItem>
                                ))
                              }
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label>Item ID</Label>
                          <Input
                            placeholder="e.g., RISK-2024-001"
                            value={newCrossRef.itemId}
                            onChange={(e) => setNewCrossRef(prev => ({ ...prev, itemId: e.target.value }))}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>Item Title</Label>
                          <Input
                            placeholder="Brief description"
                            value={newCrossRef.itemTitle}
                            onChange={(e) => setNewCrossRef(prev => ({ ...prev, itemTitle: e.target.value }))}
                          />
                        </div>
                      </div>

                      <div className="flex justify-end gap-2">
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setShowCrossRefForm(false);
                            setNewCrossRef({ microapp: '', itemType: '', itemId: '', itemTitle: '' });
                          }}
                        >
                          Cancel
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          onClick={handleAddCrossRef}
                          disabled={!newCrossRef.microapp || !newCrossRef.itemType || !newCrossRef.itemId || !newCrossRef.itemTitle}
                        >
                          Add Reference
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {crossReferences.length > 0 && (
                  <div className="space-y-2">
                    {crossReferences.map((ref, index) => {
                      const IconComponent = getMicroappIcon(ref.microapp);
                      const config = externalMicroapps.find(m => m.id === ref.microapp);
                      return (
                        <div 
                          key={index}
                          className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border"
                        >
                          <div className="flex items-center gap-3">
                            <div className="p-2 rounded-md bg-background">
                              <IconComponent className="h-4 w-4 text-primary" />
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <Badge variant="outline" className="text-xs">
                                  {config?.name}
                                </Badge>
                                <span className="text-sm font-mono text-muted-foreground">{ref.itemId}</span>
                              </div>
                              <p className="text-sm font-medium">{ref.itemTitle}</p>
                            </div>
                          </div>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemoveCrossRef(index)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Assign Owner *</Label>
                  <Input
                    placeholder="Enter owner name"
                    value={formData.owner}
                    onChange={(e) => updateFormData('owner', e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Owner Department *</Label>
                  <Select value={formData.ownerDepartment} onValueChange={(v) => updateFormData('ownerDepartment', v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nursing">Nursing</SelectItem>
                      <SelectItem value="pharmacy">Pharmacy</SelectItem>
                      <SelectItem value="laboratory">Laboratory</SelectItem>
                      <SelectItem value="radiology">Radiology</SelectItem>
                      <SelectItem value="administration">Administration</SelectItem>
                      <SelectItem value="it">IT</SelectItem>
                      <SelectItem value="quality_assurance">Quality Assurance</SelectItem>
                      <SelectItem value="compliance">Compliance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Triage Due Date</Label>
                  <Input
                    type="date"
                    value={formData.triageDueDate}
                    onChange={(e) => updateFormData('triageDueDate', e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Remediation Due Date</Label>
                  <Input
                    type="date"
                    value={formData.remediationDueDate}
                    onChange={(e) => updateFormData('remediationDueDate', e.target.value)}
                  />
                </div>
              </div>

              {selectedCitation && selectedCitation.remediationSteps.length > 0 && (
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <h4 className="font-medium mb-3">Recommended Remediation Steps</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    These will be available during triage for selection:
                  </p>
                  <ul className="space-y-2">
                    {selectedCitation.remediationSteps.map((step) => (
                      <li key={step.id} className="flex items-start gap-2 text-sm">
                        <Check className="h-4 w-4 mt-0.5 text-success" />
                        <span>{step.description}</span>
                        {step.sourceUrl && (
                          <a href={step.sourceUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        )}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="p-4 rounded-lg bg-muted border border-border">
                <p className="text-sm text-foreground">
                  <strong>Note:</strong> After submission, the case will be routed to Triage where scope and remediation path will be determined.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <Button 
            variant="outline" 
            onClick={handleBack}
            disabled={currentStep === 1}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>

          {currentStep < 4 ? (
            <Button 
              onClick={handleNext}
              disabled={!canProceed()}
            >
              Next
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          ) : (
            <Button 
              variant="hero"
              onClick={handleSubmit}
              disabled={!canProceed()}
            >
              <Check className="h-4 w-4 mr-2" />
              Submit Case
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}