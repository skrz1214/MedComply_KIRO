import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Download, Clock, FileText, Trash2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { mockExportHistory } from '@/data/reportsMockData';

export default function ExportHistory() {
  const navigate = useNavigate();

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate('/reports')}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-xl font-bold text-foreground">Export History</h1>
          <p className="text-sm text-muted-foreground">View previous report exports</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-blue-500/10">
              <Download className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{mockExportHistory.length}</p>
              <p className="text-sm text-muted-foreground">Total Exports</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-green-500/10">
              <FileText className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">
                {mockExportHistory.reduce((sum, e) => sum + e.rowCount, 0)}
              </p>
              <p className="text-sm text-muted-foreground">Total Rows Exported</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-purple-500/10">
              <Clock className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">
                {mockExportHistory.length > 0 
                  ? new Date(mockExportHistory[0].exportedAt).toLocaleDateString()
                  : '-'
                }
              </p>
              <p className="text-sm text-muted-foreground">Last Export</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Export History Table */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Exports</CardTitle>
        </CardHeader>
        <CardContent>
          {mockExportHistory.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Download className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No exports yet</p>
              <p className="text-sm">Export a report to see it here</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Report</TableHead>
                  <TableHead>Exported At</TableHead>
                  <TableHead>Exported By</TableHead>
                  <TableHead>Filters</TableHead>
                  <TableHead>Rows</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockExportHistory.map((entry) => (
                  <TableRow key={entry.id}>
                    <TableCell>
                      <Button 
                        variant="link" 
                        className="p-0 h-auto"
                        onClick={() => navigate(`/reports/${entry.reportId}`)}
                      >
                        {entry.reportName}
                      </Button>
                    </TableCell>
                    <TableCell>
                      {new Date(entry.exportedAt).toLocaleString()}
                    </TableCell>
                    <TableCell>{entry.exportedBy}</TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground truncate max-w-[200px] block">
                        {entry.filterSummary}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{entry.rowCount} rows</Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Trash2 className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
