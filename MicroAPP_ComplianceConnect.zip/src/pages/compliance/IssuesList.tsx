import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '@/components/compliance/Header';
import { IssueCard } from '@/components/compliance/IssueCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { mockIssues } from '@/data/mockData';
import { IssueStatus } from '@/types/compliance';
import { Search, Filter, Plus, SlidersHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';

const statusFilters: { value: IssueStatus | 'all'; label: string }[] = [
  { value: 'all', label: 'All Issues' },
  { value: 'reported', label: 'Reported' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'qa_review', label: 'QA Review' },
  { value: 'completed', label: 'Completed' },
  { value: 'rejected', label: 'Rejected' },
];

export default function IssuesList() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<IssueStatus | 'all'>('all');
  const [sortBy, setSortBy] = useState('newest');

  const filteredIssues = mockIssues
    .filter(issue => {
      const matchesSearch = issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           issue.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           issue.id.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === 'all' || issue.status === statusFilter;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      if (sortBy === 'newest') {
        return new Date(b.reportedAt).getTime() - new Date(a.reportedAt).getTime();
      }
      if (sortBy === 'oldest') {
        return new Date(a.reportedAt).getTime() - new Date(b.reportedAt).getTime();
      }
      if (sortBy === 'priority') {
        const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
        return priorityOrder[a.priority] - priorityOrder[b.priority];
      }
      return 0;
    });

  const statusCounts = mockIssues.reduce((acc, issue) => {
    acc[issue.status] = (acc[issue.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="min-h-screen">
      <Header 
        title="All Issues" 
        subtitle="Manage and track compliance issues" 
      />

      <div className="p-6 space-y-6">
        {/* Status Tabs */}
        <div className="flex flex-wrap gap-2">
          {statusFilters.map((filter) => {
            const count = filter.value === 'all' 
              ? mockIssues.length 
              : statusCounts[filter.value] || 0;
            
            return (
              <button
                key={filter.value}
                onClick={() => setStatusFilter(filter.value)}
                className={cn(
                  'px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200',
                  'flex items-center gap-2',
                  statusFilter === filter.value
                    ? 'bg-primary text-white shadow-soft'
                    : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                )}
              >
                {filter.label}
                <Badge 
                  variant={statusFilter === filter.value ? 'secondary' : 'muted'}
                  className="text-xs"
                >
                  {count}
                </Badge>
              </button>
            );
          })}
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by title, description, or ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>

          <div className="flex gap-2">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[160px]">
                <SlidersHorizontal className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="oldest">Oldest First</SelectItem>
                <SelectItem value="priority">Priority</SelectItem>
              </SelectContent>
            </Select>

            <Button 
              variant="hero"
              onClick={() => navigate('/report')}
            >
              <Plus className="h-4 w-4 mr-2" />
              Report Issue
            </Button>
          </div>
        </div>

        {/* Issues List */}
        <div className="space-y-4">
          {filteredIssues.length === 0 ? (
            <div className="text-center py-12 rounded-xl border border-dashed border-border">
              <Filter className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-semibold text-lg mb-2">No issues found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your search or filter criteria
              </p>
              <Button 
                variant="outline"
                onClick={() => {
                  setSearchQuery('');
                  setStatusFilter('all');
                }}
              >
                Clear Filters
              </Button>
            </div>
          ) : (
            filteredIssues.map((issue) => (
              <IssueCard 
                key={issue.id} 
                issue={issue}
                onViewDetails={(id) => navigate(`/issues/${id}`)}
              />
            ))
          )}
        </div>

        {/* Results Summary */}
        {filteredIssues.length > 0 && (
          <p className="text-sm text-muted-foreground text-center">
            Showing {filteredIssues.length} of {mockIssues.length} issues
          </p>
        )}
      </div>
    </div>
  );
}
