import { BarChart3, FileText, TrendingUp, AlertTriangle, Clock, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';

export default function Reports() {
  const reportTypes = [
    {
      title: 'Open Issues by Department',
      description: 'View open compliance issues grouped by department, type, and priority',
      icon: FileText,
      color: 'text-blue-600',
      bgColor: 'bg-blue-500/10',
    },
    {
      title: 'Overdue CAPA Actions',
      description: 'Track overdue corrective and preventive actions by department',
      icon: AlertTriangle,
      color: 'text-red-600',
      bgColor: 'bg-red-500/10',
    },
    {
      title: 'CAPA Cycle Time',
      description: 'Analyze average time from CAPA creation to closure',
      icon: Clock,
      color: 'text-purple-600',
      bgColor: 'bg-purple-500/10',
    },
    {
      title: 'Repeat Findings',
      description: 'Citations with most linked issues and recurring patterns',
      icon: TrendingUp,
      color: 'text-orange-600',
      bgColor: 'bg-orange-500/10',
    },
    {
      title: 'Evidence Coverage',
      description: 'Citations missing evidence expectations or mappings',
      icon: CheckCircle,
      color: 'text-green-600',
      bgColor: 'bg-green-500/10',
    },
    {
      title: 'Compliance Dashboard',
      description: 'Executive summary of overall compliance posture',
      icon: BarChart3,
      color: 'text-cyan-600',
      bgColor: 'bg-cyan-500/10',
    },
  ];

  const handleGenerateReport = (reportTitle: string) => {
    toast({
      title: 'Generating Report',
      description: `${reportTitle} report is being generated. This feature will be fully implemented soon.`,
    });
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Reports</h1>
        <p className="text-muted-foreground">Generate and view compliance reports</p>
      </div>

      {/* Report Types Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {reportTypes.map((report) => (
          <Card key={report.title} className="hover:border-primary/50 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${report.bgColor}`}>
                  <report.icon className={`h-5 w-5 ${report.color}`} />
                </div>
                <CardTitle className="text-base">{report.title}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">{report.description}</p>
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full"
                onClick={() => handleGenerateReport(report.title)}
              >
                Generate Report
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
