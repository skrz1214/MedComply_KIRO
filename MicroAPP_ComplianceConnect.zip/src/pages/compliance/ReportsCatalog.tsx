import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, FileText, Clock, CheckSquare, Layers, AlertTriangle, 
  Timer, CheckCircle, Library, FileCheck, Calendar, Search, TrendingUp,
  Download, Filter, Settings
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { reportDefinitions, getReportData } from '@/data/reportsMockData';
import { ReportDomain } from '@/types/reports';

const iconMap: Record<string, any> = {
  LayoutDashboard, FileText, Clock, CheckSquare, Layers, AlertTriangle,
  Timer, CheckCircle, Library, FileCheck, Calendar, Search, TrendingUp
};

const domainLabels: Record<ReportDomain, string> = {
  executive: 'Executive Overview',
  issues: 'Compliance Items (Issues)',
  capa: 'CAPA (ActionGuard)',
  citations: 'Citations & Citation Cases',
  'cross-module': 'Cross-Module / Evidence',
};

const domainColors: Record<ReportDomain, string> = {
  executive: 'bg-indigo-500/10 text-indigo-600 border-indigo-500/20',
  issues: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  capa: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  citations: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  'cross-module': 'bg-cyan-500/10 text-cyan-600 border-cyan-500/20',
};

export default function ReportsCatalog() {
  const navigate = useNavigate();
  const [selectedDomain, setSelectedDomain] = useState<ReportDomain | 'all'>('all');
  const [facility, setFacility] = useState<string>('all');

  const filteredReports = selectedDomain === 'all' 
    ? reportDefinitions 
    : reportDefinitions.filter(r => r.domain === selectedDomain);

  const groupedReports = filteredReports.reduce((acc, report) => {
    if (!acc[report.domain]) acc[report.domain] = [];
    acc[report.domain].push(report);
    return acc;
  }, {} as Record<ReportDomain, typeof reportDefinitions>);

  // Get quick stats from executive overview
  const execData = getReportData('executive-overview');

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Reports & Analytics</h1>
          <p className="text-muted-foreground">Enterprise reporting across Issues, CAPAs, and Citations</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={facility} onValueChange={setFacility}>
            <SelectTrigger className="w-[180px] bg-background">
              <SelectValue placeholder="All Facilities" />
            </SelectTrigger>
            <SelectContent className="bg-background">
              <SelectItem value="all">All Facilities</SelectItem>
              <SelectItem value="main_campus">Main Campus</SelectItem>
              <SelectItem value="north_wing">North Wing</SelectItem>
              <SelectItem value="south_wing">South Wing</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={() => navigate('/reports/exports')}>
            <Download className="h-4 w-4 mr-2" />
            Export History
          </Button>
          <Button variant="outline" onClick={() => navigate('/admin')}>
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
        </div>
      </div>

      {/* Quick KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {execData.metrics.slice(0, 6).map((metric) => (
          <Card key={metric.id} className={`${
            metric.color === 'danger' ? 'border-red-500/30' : 
            metric.color === 'warning' ? 'border-amber-500/30' : 
            metric.color === 'success' ? 'border-green-500/30' : ''
          }`}>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">{metric.label}</p>
              <p className={`text-2xl font-bold ${
                metric.color === 'danger' ? 'text-red-600' : 
                metric.color === 'warning' ? 'text-amber-600' : 
                metric.color === 'success' ? 'text-green-600' : 'text-foreground'
              }`}>{metric.value}</p>
              {metric.change !== undefined && (
                <p className={`text-xs ${metric.change < 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {metric.change > 0 ? '+' : ''}{metric.change} {metric.changeLabel}
                </p>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Domain Filter Tabs */}
      <Tabs value={selectedDomain} onValueChange={(v) => setSelectedDomain(v as ReportDomain | 'all')}>
        <TabsList className="flex flex-wrap h-auto gap-1">
          <TabsTrigger value="all">All Reports</TabsTrigger>
          <TabsTrigger value="executive">Executive</TabsTrigger>
          <TabsTrigger value="issues">Issues</TabsTrigger>
          <TabsTrigger value="capa">CAPA</TabsTrigger>
          <TabsTrigger value="citations">Citations</TabsTrigger>
          <TabsTrigger value="cross-module">Cross-Module</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedDomain} className="mt-6">
          {Object.entries(groupedReports).map(([domain, reports]) => (
            <div key={domain} className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <Badge variant="outline" className={domainColors[domain as ReportDomain]}>
                  {domainLabels[domain as ReportDomain]}
                </Badge>
                <span className="text-sm text-muted-foreground">({reports.length} reports)</span>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {reports.map((report) => {
                  const Icon = iconMap[report.icon] || FileText;
                  const reportData = getReportData(report.id);
                  const primaryMetric = reportData.metrics[0];
                  
                  return (
                    <Card 
                      key={report.id} 
                      className="hover:border-primary/50 transition-colors cursor-pointer group"
                      onClick={() => navigate(`/reports/${report.id}`)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex items-start justify-between">
                          <div className={`p-2 rounded-lg ${domainColors[report.domain].split(' ')[0]}`}>
                            <Icon className={`h-5 w-5 ${domainColors[report.domain].split(' ')[1]}`} />
                          </div>
                          {primaryMetric && (
                            <div className="text-right">
                              <p className={`text-lg font-bold ${
                                primaryMetric.color === 'danger' ? 'text-red-600' : 
                                primaryMetric.color === 'warning' ? 'text-amber-600' : 
                                primaryMetric.color === 'success' ? 'text-green-600' : 'text-foreground'
                              }`}>{primaryMetric.value}</p>
                              <p className="text-xs text-muted-foreground">{primaryMetric.label}</p>
                            </div>
                          )}
                        </div>
                        <CardTitle className="text-base mt-2 group-hover:text-primary transition-colors">
                          {report.title}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription className="text-sm line-clamp-2 mb-3">
                          {report.description}
                        </CardDescription>
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">
                            {report.columns.length} columns • {report.filters.length} filters
                          </span>
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="gap-1 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={(e) => {
                              e.stopPropagation();
                              navigate(`/reports/${report.id}`);
                            }}
                          >
                            Open <Filter className="h-3 w-3" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
