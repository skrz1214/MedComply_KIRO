import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookOpen, Plus, Search, Filter, AlertCircle, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { mockCitations, mockCitationStats, mockCitationCaseStats } from '@/data/mockData';

export default function CitationsList() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCitations = mockCitations.filter(citation =>
    citation.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    citation.citationCode.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': return 'bg-green-500/10 text-green-600 border-green-500/20';
      case 'Draft': return 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20';
      case 'Deprecated': return 'bg-muted text-muted-foreground border-muted';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getSourceColor = (source: string) => {
    switch (source) {
      case 'CMS': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'Joint Commission': return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
      case 'State DOH': return 'bg-orange-500/10 text-orange-600 border-orange-500/20';
      case 'HIPAA': return 'bg-red-500/10 text-red-600 border-red-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Active Cases Alert Banner */}
      {(mockCitationCaseStats.overduePoCCount > 0 || mockCitationCaseStats.inProgressCases > 0) && (
        <Card className="border-warning/50 bg-warning/5">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AlertCircle className="h-5 w-5 text-warning" />
              <div>
                <p className="font-medium text-warning-foreground">Active Citation Cases Requiring Attention</p>
                <p className="text-sm text-muted-foreground">
                  {mockCitationCaseStats.overduePoCCount} overdue PoC • {mockCitationCaseStats.inProgressCases} in progress • {mockCitationCaseStats.triageCases} awaiting triage
                </p>
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate('/citations/cases')} className="gap-2">
              View Cases
              <ArrowRight className="h-4 w-4" />
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Citations Library</h1>
          <p className="text-muted-foreground">Manage compliance citations and standards</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => navigate('/citations/cases')}>
            Citation Cases
          </Button>
          <Button className="gap-2" onClick={() => navigate('/citations/new')}>
            <Plus className="h-4 w-4" />
            New Citation
          </Button>
        </div>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Active</p>
            <p className="text-2xl font-bold text-green-600">{mockCitationStats.activeCitations}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Draft</p>
            <p className="text-2xl font-bold text-yellow-600">{mockCitationStats.draftCitations}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Deprecated</p>
            <p className="text-2xl font-bold text-muted-foreground">{mockCitationStats.deprecatedCitations}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Total</p>
            <p className="text-2xl font-bold">{mockCitationStats.totalCitations}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Unmapped</p>
            <p className="text-2xl font-bold text-orange-600">{mockCitationStats.unmappedCitations}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Missing Evidence</p>
            <p className="text-2xl font-bold text-red-600">{mockCitationStats.missingEvidenceExpectations}</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search citations by code or title..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button variant="outline" className="gap-2">
          <Filter className="h-4 w-4" />
          Filters
        </Button>
      </div>

      {/* Citations Grid */}
      <div className="space-y-3">
        {filteredCitations.map((citation) => (
          <Card 
            key={citation.id} 
            className="hover:border-primary/50 transition-colors cursor-pointer"
            onClick={() => navigate(`/citations/${citation.id}`)}
          >
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3 flex-1">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <BookOpen className="h-5 w-5 text-primary" />
                  </div>
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-sm text-muted-foreground">{citation.citationCode}</span>
                      <Badge variant="outline" className={getSourceColor(citation.source)}>
                        {citation.source}
                      </Badge>
                      <Badge variant="outline" className={getStatusColor(citation.status)}>
                        {citation.status}
                      </Badge>
                      {(!citation.mappings || citation.mappings.length === 0) && (
                        <Badge variant="outline" className="bg-orange-500/10 text-orange-600 border-orange-500/20">
                          Unmapped
                        </Badge>
                      )}
                      {(!citation.evidenceExpectations || citation.evidenceExpectations.length === 0) && (
                        <Badge variant="outline" className="bg-red-500/10 text-red-600 border-red-500/20">
                          Missing Evidence
                        </Badge>
                      )}
                    </div>
                    <h3 className="font-semibold text-foreground">{citation.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {citation.fullText?.substring(0, 150)}...
                    </p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground mt-2">
                      <span>{citation.evidenceExpectations?.length || 0} evidence expectations</span>
                      <span>{citation.mappings?.length || 0} mappings</span>
                      <span>Risk: {citation.riskDomain}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredCitations.length === 0 && (
          <Card>
            <CardContent className="p-8 text-center">
              <BookOpen className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="font-semibold text-foreground mb-1">No citations found</h3>
              <p className="text-sm text-muted-foreground">Try adjusting your search or filters</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
