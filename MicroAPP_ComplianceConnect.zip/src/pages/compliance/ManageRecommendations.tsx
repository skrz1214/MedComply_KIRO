import { useState } from 'react';
import { Header } from '@/components/compliance/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { toast } from '@/hooks/use-toast';
import { IssueType, IssueCategory } from '@/types/compliance';
import { recommendedActions } from '@/data/mockData';
import { 
  Plus, 
  Pencil, 
  Trash2, 
  ExternalLink,
  Search,
  Sparkles,
  AlertTriangle,
  Shield,
  Scale,
  FileSearch,
  ClipboardCheck,
  BookOpen,
  Lock,
  Building2,
  MessageSquare
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface RecommendationStep {
  id: string;
  description: string;
  sourceUrl: string;
}

interface RecommendationsByType {
  [key: string]: RecommendationStep[];
}

const issueTypeConfig: { value: IssueType; label: string; icon: typeof Shield; color: string }[] = [
  { value: 'risk', label: 'Risk', icon: AlertTriangle, color: 'text-orange-500' },
  { value: 'incident_event', label: 'Incident/Event', icon: AlertTriangle, color: 'text-red-500' },
  { value: 'investigation_enforcement', label: 'Investigation & Enforcement', icon: Scale, color: 'text-purple-500' },
  { value: 'audit', label: 'Audit', icon: FileSearch, color: 'text-blue-500' },
  { value: 'policy_procedure', label: 'Policy/Procedure', icon: BookOpen, color: 'text-teal-500' },
  { value: 'complaint', label: 'Complaint', icon: MessageSquare, color: 'text-yellow-500' },
  { value: 'training_competency', label: 'Training/Competency', icon: ClipboardCheck, color: 'text-green-500' },
  { value: 'privacy_data_rights', label: 'Privacy and Data Rights', icon: Lock, color: 'text-indigo-500' },
  { value: 'governance', label: 'Governance', icon: Building2, color: 'text-slate-500' },
];

const issueCategories: { value: IssueCategory; label: string }[] = [
  { value: 'patient_safety', label: 'Patient Safety' },
  { value: 'data_privacy', label: 'Data Privacy' },
  { value: 'regulatory', label: 'Regulatory' },
  { value: 'documentation', label: 'Documentation' },
  { value: 'operational', label: 'Operational' },
  { value: 'other', label: 'Other' },
];

export default function ManageRecommendations() {
  const [recommendations, setRecommendations] = useState<RecommendationsByType>(() => {
    const initial: RecommendationsByType = {};
    Object.entries(recommendedActions).forEach(([type, actions]) => {
      initial[type] = actions.map((action, idx) => ({
        id: `${type}-${idx}`,
        description: action.description,
        sourceUrl: action.sourceUrl,
      }));
    });
    return initial;
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingStep, setEditingStep] = useState<{ type: string; step: RecommendationStep } | null>(null);

  const [newStep, setNewStep] = useState({
    issueType: '' as IssueType | '',
    description: '',
    sourceUrl: '',
  });

  const handleAddStep = () => {
    if (!newStep.issueType || !newStep.description.trim()) return;

    const step: RecommendationStep = {
      id: `${newStep.issueType}-${Date.now()}`,
      description: newStep.description.trim(),
      sourceUrl: newStep.sourceUrl.trim(),
    };

    setRecommendations(prev => ({
      ...prev,
      [newStep.issueType]: [...(prev[newStep.issueType] || []), step],
    }));

    toast({
      title: 'Step Added',
      description: 'Recommended action step has been added successfully.',
    });

    setNewStep({ issueType: '', description: '', sourceUrl: '' });
    setShowAddDialog(false);
  };

  const handleEditStep = () => {
    if (!editingStep || !editingStep.step.description.trim()) return;

    setRecommendations(prev => ({
      ...prev,
      [editingStep.type]: prev[editingStep.type].map(s =>
        s.id === editingStep.step.id ? editingStep.step : s
      ),
    }));

    toast({
      title: 'Step Updated',
      description: 'Recommended action step has been updated.',
    });

    setEditingStep(null);
    setShowEditDialog(false);
  };

  const handleDeleteStep = (type: string, stepId: string) => {
    setRecommendations(prev => ({
      ...prev,
      [type]: prev[type].filter(s => s.id !== stepId),
    }));

    toast({
      title: 'Step Deleted',
      description: 'Recommended action step has been removed.',
    });
  };

  const openEditDialog = (type: string, step: RecommendationStep) => {
    setEditingStep({ type, step: { ...step } });
    setShowEditDialog(true);
  };

  const filteredTypes = issueTypeConfig.filter(type => {
    if (filterType !== 'all' && type.value !== filterType) return false;
    if (searchQuery) {
      const steps = recommendations[type.value] || [];
      const matchesSearch = steps.some(s => 
        s.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
      if (!matchesSearch && !type.label.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
    }
    return true;
  });

  const getTotalSteps = () => {
    return Object.values(recommendations).reduce((acc, steps) => acc + steps.length, 0);
  };

  return (
    <div className="min-h-screen">
      <Header 
        title="Manage Recommendations" 
        subtitle="Configure recommended action steps by issue type"
      />

      <div className="p-6 space-y-6">
        {/* Stats & Actions Bar */}
        <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary/10 border border-primary/20">
              <Sparkles className="h-5 w-5 text-primary" />
              <span className="font-semibold">{getTotalSteps()}</span>
              <span className="text-sm text-muted-foreground">Total Steps</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-muted border border-border">
              <span className="font-semibold">{issueTypeConfig.length}</span>
              <span className="text-sm text-muted-foreground">Issue Types</span>
            </div>
          </div>

          <Button onClick={() => setShowAddDialog(true)} variant="hero">
            <Plus className="h-4 w-4 mr-2" />
            Add Recommendation
          </Button>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search recommendations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-[220px]">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Issue Types</SelectItem>
              {issueTypeConfig.map(type => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Recommendations by Type */}
        <div className="rounded-xl border border-border bg-card shadow-soft">
          <Accordion type="multiple" className="w-full" defaultValue={issueTypeConfig.map(t => t.value)}>
            {filteredTypes.map(typeConfig => {
              const Icon = typeConfig.icon;
              const steps = recommendations[typeConfig.value] || [];
              const filteredSteps = searchQuery
                ? steps.filter(s => s.description.toLowerCase().includes(searchQuery.toLowerCase()))
                : steps;

              return (
                <AccordionItem key={typeConfig.value} value={typeConfig.value} className="border-b last:border-b-0">
                  <AccordionTrigger className="px-6 py-4 hover:no-underline hover:bg-muted/50">
                    <div className="flex items-center gap-3">
                      <div className={cn('p-2 rounded-lg bg-muted', typeConfig.color)}>
                        <Icon className="h-4 w-4" />
                      </div>
                      <span className="font-semibold">{typeConfig.label}</span>
                      <Badge variant="secondary" className="ml-2">
                        {steps.length} steps
                      </Badge>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-6 pb-4">
                    {filteredSteps.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <p>No recommended steps for this issue type.</p>
                        <Button
                          variant="link"
                          onClick={() => {
                            setNewStep(prev => ({ ...prev, issueType: typeConfig.value }));
                            setShowAddDialog(true);
                          }}
                        >
                          Add the first step
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {filteredSteps.map((step, index) => (
                          <div
                            key={step.id}
                            className="flex items-start gap-4 p-4 rounded-lg border border-border bg-background hover:bg-muted/30 transition-colors group"
                          >
                            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-semibold text-sm shrink-0">
                              {index + 1}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-foreground">{step.description}</p>
                              {step.sourceUrl && (
                                <a
                                  href={step.sourceUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1 text-sm text-primary hover:underline mt-1"
                                >
                                  <ExternalLink className="h-3 w-3" />
                                  Reference Documentation
                                </a>
                              )}
                            </div>
                            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => openEditDialog(typeConfig.value, step)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="text-destructive hover:text-destructive"
                                onClick={() => handleDeleteStep(typeConfig.value, step.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </AccordionContent>
                </AccordionItem>
              );
            })}
          </Accordion>
        </div>
      </div>

      {/* Add Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Add Recommended Action Step</DialogTitle>
            <DialogDescription>
              Create a new recommended action step that will be suggested when users report issues.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Issue Type *</label>
              <Select
                value={newStep.issueType}
                onValueChange={(value) => setNewStep(prev => ({ ...prev, issueType: value as IssueType }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select issue type" />
                </SelectTrigger>
                <SelectContent>
                  {issueTypeConfig.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Description *</label>
              <Textarea
                placeholder="Describe the recommended action step..."
                value={newStep.description}
                onChange={(e) => setNewStep(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Source URL</label>
              <Input
                placeholder="https://example.com/reference"
                value={newStep.sourceUrl}
                onChange={(e) => setNewStep(prev => ({ ...prev, sourceUrl: e.target.value }))}
              />
              <p className="text-xs text-muted-foreground">
                Optional reference link for compliance documentation
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowAddDialog(false)}>
              Cancel
            </Button>
            <Button
              variant="hero"
              onClick={handleAddStep}
              disabled={!newStep.issueType || !newStep.description.trim()}
            >
              Add Step
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Recommended Action Step</DialogTitle>
            <DialogDescription>
              Update the details of this recommended action step.
            </DialogDescription>
          </DialogHeader>
          {editingStep && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Issue Type</label>
                <Input
                  value={issueTypeConfig.find(t => t.value === editingStep.type)?.label || editingStep.type}
                  disabled
                  className="bg-muted"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Description *</label>
                <Textarea
                  placeholder="Describe the recommended action step..."
                  value={editingStep.step.description}
                  onChange={(e) => setEditingStep(prev => prev ? {
                    ...prev,
                    step: { ...prev.step, description: e.target.value }
                  } : null)}
                  rows={3}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Source URL</label>
                <Input
                  placeholder="https://example.com/reference"
                  value={editingStep.step.sourceUrl}
                  onChange={(e) => setEditingStep(prev => prev ? {
                    ...prev,
                    step: { ...prev.step, sourceUrl: e.target.value }
                  } : null)}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowEditDialog(false)}>
              Cancel
            </Button>
            <Button
              variant="hero"
              onClick={handleEditStep}
              disabled={!editingStep?.step.description.trim()}
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
