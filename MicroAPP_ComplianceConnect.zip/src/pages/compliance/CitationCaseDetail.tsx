import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Header } from '@/components/compliance/Header';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { mockCitationCases, mockCitations } from '@/data/mockData';
import { toast } from '@/hooks/use-toast';
import { 
  ArrowLeft, Clock, AlertTriangle, CheckCircle2, User, Building2, Calendar, 
  FileText, ClipboardList, Shield, Link2, Send, XCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, differenceInDays, isPast } from 'date-fns';

export default function CitationCaseDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const caseItem = mockCitationCases.find(c => c.id === id);
  const citation = caseItem ? mockCitations.find(c => c.id === caseItem.citationId) : null;

  if (!caseItem) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Case not found</p>
      </div>
    );
  }

  const dueDate = caseItem.pocDueDate || caseItem.escDueDate || caseItem.remediationDueDate;
  const daysUntil = dueDate ? differenceInDays(new Date(dueDate), new Date()) : null;
  const isOverdue = dueDate ? isPast(new Date(dueDate)) : false;

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'reported': return { color: 'bg-blue-500/10 text-blue-600', label: 'Reported' };
      case 'triage': return { color: 'bg-yellow-500/10 text-yellow-600', label: 'Triage' };
      case 'remediation_in_progress': return { color: 'bg-orange-500/10 text-orange-600', label: 'In Progress' };
      case 'qa_verification': return { color: 'bg-purple-500/10 text-purple-600', label: 'QA Verification' };
      case 'closed': return { color: 'bg-green-500/10 text-green-600', label: 'Closed' };
      default: return { color: 'bg-muted text-muted-foreground', label: status };
    }
  };

  const statusConfig = getStatusConfig(caseItem.status);
  const pocProgress = caseItem.pocElements ? (caseItem.pocElements.filter(e => e.completionDate).length / 5) * 100 : 0;

  return (
    <div className="min-h-screen">
      <Header title={caseItem.title} subtitle={`Case ${caseItem.id}`} />

      <div className="p-6 space-y-6">
        <Button variant="ghost" size="sm" onClick={() => navigate('/citations/cases')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Cases
        </Button>

        {/* Clock Card for PoC/ESC */}
        {dueDate && caseItem.status !== 'closed' && (
          <Card className={cn(
            'border-2',
            isOverdue ? 'border-destructive bg-destructive/5' : daysUntil! <= 3 ? 'border-warning bg-warning/5' : 'border-primary bg-primary/5'
          )}>
            <CardContent className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {isOverdue ? <AlertTriangle className="h-6 w-6 text-destructive" /> : <Clock className="h-6 w-6 text-primary" />}
                <div>
                  <p className="font-semibold">{caseItem.mode === 'poc' ? 'Plan of Correction Due' : caseItem.mode === 'esc' ? 'ESC Submission Due' : 'Remediation Due'}</p>
                  <p className="text-sm text-muted-foreground">{format(new Date(dueDate), 'MMMM d, yyyy')}</p>
                </div>
              </div>
              <div className={cn('text-2xl font-bold', isOverdue ? 'text-destructive' : 'text-primary')}>
                {isOverdue ? `${Math.abs(daysUntil!)} days overdue` : `${daysUntil} days remaining`}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={statusConfig.color}>{statusConfig.label}</Badge>
                  <Badge variant="secondary">{caseItem.mode.toUpperCase()}</Badge>
                  <Badge variant="outline" className="capitalize">{caseItem.severity}</Badge>
                </div>
                <CardTitle className="mt-2">{caseItem.title}</CardTitle>
                <p className="text-muted-foreground">{caseItem.description}</p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div className="flex items-center gap-2"><Building2 className="h-4 w-4 text-muted-foreground" /><div><p className="text-muted-foreground">Facility</p><p className="font-medium">{caseItem.facility}</p></div></div>
                  <div className="flex items-center gap-2"><User className="h-4 w-4 text-muted-foreground" /><div><p className="text-muted-foreground">Owner</p><p className="font-medium">{caseItem.owner || 'Unassigned'}</p></div></div>
                  <div className="flex items-center gap-2"><Calendar className="h-4 w-4 text-muted-foreground" /><div><p className="text-muted-foreground">Reported</p><p className="font-medium">{format(new Date(caseItem.reportedDate), 'MMM d, yyyy')}</p></div></div>
                  <div className="flex items-center gap-2"><FileText className="h-4 w-4 text-muted-foreground" /><div><p className="text-muted-foreground">Citation</p><p className="font-medium font-mono">{caseItem.citationCode}</p></div></div>
                </div>
              </CardContent>
            </Card>

            <Tabs defaultValue="findings">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="findings">Findings</TabsTrigger>
                <TabsTrigger value="poc">{caseItem.mode === 'esc' ? 'ESC' : 'PoC'}</TabsTrigger>
                <TabsTrigger value="verification">Verification</TabsTrigger>
                <TabsTrigger value="audit">Audit Log</TabsTrigger>
              </TabsList>

              <TabsContent value="findings" className="space-y-4">
                <Card>
                  <CardHeader><CardTitle className="text-base">Findings Summary</CardTitle></CardHeader>
                  <CardContent><p className="text-sm">{caseItem.findingsSummary}</p></CardContent>
                </Card>
                {caseItem.containmentActions.length > 0 && (
                  <Card>
                    <CardHeader><CardTitle className="text-base">Containment Actions</CardTitle></CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {caseItem.containmentActions.map(action => (
                          <li key={action.id} className="flex items-start gap-2 text-sm">
                            <CheckCircle2 className="h-4 w-4 text-success mt-0.5" />
                            <div>
                              <p>{action.description}</p>
                              {action.completedAt && <p className="text-xs text-muted-foreground">Completed by {action.completedBy} on {format(new Date(action.completedAt), 'MMM d')}</p>}
                            </div>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="poc">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">{caseItem.mode === 'esc' ? 'ESC Package' : 'Plan of Correction Elements'}</CardTitle>
                    {caseItem.mode === 'poc' && <Progress value={pocProgress} className="mt-2" />}
                  </CardHeader>
                  <CardContent>
                    {caseItem.pocElements && caseItem.pocElements.length > 0 ? (
                      <div className="space-y-4">
                        {caseItem.pocElements.map(elem => (
                          <div key={elem.id} className="p-3 rounded-lg border bg-muted/30">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-medium text-sm">Element {elem.elementNumber}: {elem.title}</h4>
                              {elem.completionDate ? <Badge variant="outline" className="bg-success/10 text-success">Complete</Badge> : <Badge variant="outline">Pending</Badge>}
                            </div>
                            <p className="text-sm text-muted-foreground">{elem.content}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-4">No {caseItem.mode === 'esc' ? 'ESC' : 'PoC'} elements defined yet.</p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="verification">
                <Card>
                  <CardHeader><CardTitle className="text-base">Evidence Expectations Checklist</CardTitle></CardHeader>
                  <CardContent>
                    {caseItem.verificationChecklist.length > 0 ? (
                      <ul className="space-y-2">
                        {caseItem.verificationChecklist.map(item => (
                          <li key={item.id} className="flex items-start gap-2 text-sm p-2 rounded border">
                            {item.result === 'met' ? <CheckCircle2 className="h-4 w-4 text-success mt-0.5" /> : item.result === 'not_met' ? <XCircle className="h-4 w-4 text-destructive mt-0.5" /> : <Clock className="h-4 w-4 text-muted-foreground mt-0.5" />}
                            <div>
                              <p>{item.expectationDescription}</p>
                              {item.notes && <p className="text-xs text-muted-foreground">{item.notes}</p>}
                            </div>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-4">No verification checklist items yet.</p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="audit">
                <Card>
                  <CardHeader><CardTitle className="text-base">Audit Trail</CardTitle></CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {caseItem.auditLog.map(entry => (
                        <li key={entry.id} className="flex items-start gap-2 text-sm border-l-2 border-muted pl-3 py-1">
                          <div>
                            <p className="font-medium">{entry.action}</p>
                            <p className="text-xs text-muted-foreground">{entry.performedBy} • {format(new Date(entry.performedAt), 'MMM d, yyyy h:mm a')}</p>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {caseItem.status !== 'closed' && (
              <Card>
                <CardHeader><CardTitle className="text-base">Actions</CardTitle></CardHeader>
                <CardContent className="space-y-2">
                  {caseItem.status === 'triage' && <Button className="w-full" onClick={() => toast({ title: 'Triage Complete', description: 'Case moved to remediation.' })}><Send className="h-4 w-4 mr-2" />Complete Triage</Button>}
                  {caseItem.status === 'remediation_in_progress' && <Button className="w-full" onClick={() => toast({ title: 'Routed to QA', description: 'Case sent for verification.' })}><Send className="h-4 w-4 mr-2" />Route to QA</Button>}
                  {caseItem.status === 'qa_verification' && <Button className="w-full" variant="success" onClick={() => toast({ title: 'Case Closed', description: 'Verification passed.' })}><CheckCircle2 className="h-4 w-4 mr-2" />Approve & Close</Button>}
                </CardContent>
              </Card>
            )}

            {caseItem.status === 'closed' && (
              <Card className="border-success/30 bg-success/5">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2"><CheckCircle2 className="h-5 w-5 text-success" /><span className="font-semibold text-success">Case Closed</span></div>
                  <p className="text-sm text-muted-foreground">{caseItem.closureSummary}</p>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader><CardTitle className="text-base">Case Info</CardTitle></CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Case ID</span><span className="font-mono">{caseItem.id}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Authority</span><span className="capitalize">{caseItem.authorityType.replace('_', ' ')}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Origin</span><span className="capitalize">{caseItem.origin.replace('_', ' ')}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Department</span><span className="capitalize">{caseItem.department}</span></div>
                {caseItem.linkedCapaId && <div className="flex justify-between"><span className="text-muted-foreground">Linked CAPA</span><span className="text-primary">{caseItem.linkedCapaId}</span></div>}
                {caseItem.linkedIssueId && <div className="flex justify-between"><span className="text-muted-foreground">Linked Issue</span><span className="text-info">{caseItem.linkedIssueId}</span></div>}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}