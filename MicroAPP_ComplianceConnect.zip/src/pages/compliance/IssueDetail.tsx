import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Header } from '@/components/compliance/Header';
import { WorkflowStepper } from '@/components/compliance/WorkflowStepper';
import { ActionStepItem } from '@/components/compliance/ActionStepItem';
import { AttachmentUploader } from '@/components/compliance/AttachmentUploader';
import { StageAttachmentsView } from '@/components/compliance/StageAttachmentsView';
import { StageDetailsView } from '@/components/compliance/StageDetailsView';
import { ConnectionsPanel } from '@/components/compliance/ConnectionsPanel';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';
import { mockIssues, recommendedActions } from '@/data/mockData';
import { ComplianceIssue, ActionStep, ActionStepStatus, Attachment, WorkflowStage } from '@/types/compliance';
import { 
  ArrowLeft, 
  Calendar, 
  User, 
  Building2, 
  AlertTriangle,
  Plus,
  Send,
  CheckCircle2,
  XCircle,
  Paperclip,
  History,
  ListTodo,
  FileText,
  Eye,
  Shield,
  Scale,
  FileSearch,
  ClipboardCheck
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

export default function IssueDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [issue, setIssue] = useState<ComplianceIssue | null>(null);
  const [showAddStep, setShowAddStep] = useState(false);
  const [newStepDescription, setNewStepDescription] = useState('');
  const [assignTo, setAssignTo] = useState('');
  const [showMonitoringDialog, setShowMonitoringDialog] = useState(false);
  const [selectedMonitoring, setSelectedMonitoring] = useState<string>('');
  const [monitoringDepartment, setMonitoringDepartment] = useState<string>('');
  const [monitoringUser, setMonitoringUser] = useState<string>('');
  const [showRevisionDialog, setShowRevisionDialog] = useState(false);
  const [revisionDepartment, setRevisionDepartment] = useState<string>('');
  const [revisionUser, setRevisionUser] = useState<string>('');
  const [showSendBackDialog, setShowSendBackDialog] = useState(false);
  const [sendBackDepartment, setSendBackDepartment] = useState<string>('');
  const [sendBackUser, setSendBackUser] = useState<string>('');
  const [reassignTo, setReassignTo] = useState('');
  const [reassignDepartment, setReassignDepartment] = useState('');

  const departments = [
    { value: 'nursing', label: 'Nursing' },
    { value: 'pharmacy', label: 'Pharmacy' },
    { value: 'lab', label: 'Laboratory' },
    { value: 'radiology', label: 'Radiology' },
    { value: 'administration', label: 'Administration' },
    { value: 'quality', label: 'Quality Assurance' },
    { value: 'compliance', label: 'Compliance' },
    { value: 'risk_management', label: 'Risk Management' },
  ];

  const mockUsers = [
    { value: 'john.smith', label: 'John Smith', department: 'compliance' },
    { value: 'sarah.johnson', label: 'Sarah Johnson', department: 'quality' },
    { value: 'michael.chen', label: 'Michael Chen', department: 'risk_management' },
    { value: 'emily.davis', label: 'Emily Davis', department: 'nursing' },
    { value: 'robert.wilson', label: 'Robert Wilson', department: 'pharmacy' },
    { value: 'lisa.anderson', label: 'Lisa Anderson', department: 'administration' },
    { value: 'david.martinez', label: 'David Martinez', department: 'lab' },
    { value: 'jennifer.taylor', label: 'Jennifer Taylor', department: 'radiology' },
  ];

  const filteredUsers = monitoringDepartment 
    ? mockUsers.filter(u => u.department === monitoringDepartment)
    : mockUsers;

  useEffect(() => {
    const foundIssue = mockIssues.find(i => i.id === id);
    if (foundIssue) {
      setIssue({ ...foundIssue });
    }
  }, [id]);

  if (!issue) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Issue not found</p>
      </div>
    );
  }

  const getCurrentWorkflowStage = (): WorkflowStage => {
    if (issue.status === 'reported') return 'reported';
    if (issue.status === 'in_progress') return 'in_progress';
    if (issue.status === 'qa_review') return 'qa_review';
    if (issue.status === 'completed') return 'completed';
    return 'reported';
  };

  const handleAttachmentsChange = (newAttachments: Attachment[]) => {
    setIssue(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        attachments: newAttachments
      };
    });
  };

  const handleUpdateStepStatus = (stepId: string, status: ActionStepStatus, notes?: string, evidence?: string) => {
    setIssue(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        actionSteps: prev.actionSteps.map(step => 
          step.id === stepId 
            ? { 
                ...step, 
                status, 
                notes: notes || step.notes,
                evidence: evidence || step.evidence,
                completedAt: status === 'complete' ? new Date() : step.completedAt
              }
            : step
        )
      };
    });

    toast({
      title: 'Step Updated',
      description: `Action step marked as ${status}`,
    });
  };

  const handleAddCustomStep = () => {
    if (!newStepDescription.trim()) return;

    const newStep: ActionStep = {
      id: `step-${Date.now()}`,
      description: newStepDescription,
      isCustom: true,
      status: 'pending',
    };

    setIssue(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        actionSteps: [...prev.actionSteps, newStep]
      };
    });

    setNewStepDescription('');
    setShowAddStep(false);

    toast({
      title: 'Step Added',
      description: 'Custom action step has been added',
    });
  };

  const handleLoadRecommendations = () => {
    const recommendations = recommendedActions[issue.issueType] || [];
    const newSteps: ActionStep[] = recommendations.map((rec, index) => ({
      id: `rec-${Date.now()}-${index}`,
      description: rec.description,
      sourceUrl: rec.sourceUrl,
      isCustom: false,
      status: 'pending' as ActionStepStatus,
    }));

    setIssue(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        actionSteps: [...prev.actionSteps, ...newSteps]
      };
    });

    toast({
      title: 'Recommendations Loaded',
      description: `${recommendations.length} recommended action steps added`,
    });
  };

  const handleAssign = () => {
    if (!assignTo.trim()) return;

    setIssue(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        assignedTo: assignTo,
        status: 'in_progress'
      };
    });

    toast({
      title: 'Issue Assigned',
      description: `Issue has been assigned to ${assignTo}`,
    });
  };

  const handleRouteToQA = () => {
    setIssue(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        status: 'qa_review'
      };
    });

    toast({
      title: 'Routed to QA',
      description: 'Issue has been sent to Quality Assurance for review',
    });
  };

  const handleReassign = () => {
    if (!reassignTo.trim()) return;

    setIssue(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        assignedTo: reassignTo,
        department: reassignDepartment ? reassignDepartment as any : prev.department
      };
    });

    toast({
      title: 'Issue Re-assigned',
      description: `Issue has been re-assigned to ${reassignTo}${reassignDepartment ? ` in ${reassignDepartment.replace('_', ' ')}` : ''}`,
    });

    setReassignTo('');
    setReassignDepartment('');
  };

  const handleSendBackToReported = () => {
    const deptLabel = departments.find(d => d.value === sendBackDepartment)?.label || '';
    const userLabel = mockUsers.find(u => u.value === sendBackUser)?.label || '';

    setIssue(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        status: 'reported',
        assignedTo: userLabel || undefined,
        department: sendBackDepartment ? sendBackDepartment as any : prev.department
      };
    });

    let description = 'Issue has been sent back to reported stage for re-initiation';
    if (deptLabel) description += ` to ${deptLabel}`;
    if (userLabel) description += ` - ${userLabel}`;

    toast({
      title: 'Returned to Reported',
      description,
      variant: 'destructive',
    });

    setShowSendBackDialog(false);
    setSendBackDepartment('');
    setSendBackUser('');
  };

  const handleReturnForRevision = () => {
    const deptLabel = departments.find(d => d.value === revisionDepartment)?.label || '';
    const userLabel = mockUsers.find(u => u.value === revisionUser)?.label || '';

    setIssue(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        status: 'in_progress',
        assignedTo: userLabel || prev.assignedTo,
        department: revisionDepartment ? revisionDepartment as any : prev.department
      };
    });

    let description = 'Issue has been sent back for additional work';
    if (deptLabel) description += ` to ${deptLabel}`;
    if (userLabel) description += ` - ${userLabel}`;

    toast({
      title: 'Returned for Revision',
      description,
      variant: 'destructive',
    });

    setShowRevisionDialog(false);
    setRevisionDepartment('');
    setRevisionUser('');
  };

  const handleComplete = () => {
    setIssue(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        status: 'completed',
        closedAt: new Date()
      };
    });

    toast({
      title: 'Issue Completed',
      description: 'The compliance issue has been closed',
    });
  };

  const handleCompleteWithMonitoring = () => {
    if (!selectedMonitoring) return;

    setIssue(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        status: 'completed',
        closedAt: new Date()
      };
    });

    const monitoringLabel = monitoringOptions.find(o => o.value === selectedMonitoring)?.label || selectedMonitoring;
    const deptLabel = departments.find(d => d.value === monitoringDepartment)?.label || '';
    const userLabel = mockUsers.find(u => u.value === monitoringUser)?.label || '';
    
    let description = `Issue has been closed and routed to ${monitoringLabel} for monitoring`;
    if (deptLabel) description += ` (${deptLabel}`;
    if (userLabel) description += ` - ${userLabel}`;
    if (deptLabel) description += ')';

    toast({
      title: 'Issue Completed & Routed',
      description,
    });

    setShowMonitoringDialog(false);
    setSelectedMonitoring('');
    setMonitoringDepartment('');
    setMonitoringUser('');
  };

  const monitoringOptions = [
    { value: 'risk', label: 'Risk', icon: Shield, description: 'Route to Risk Management team' },
    { value: 'enforcement', label: 'Enforcement', icon: Scale, description: 'Route to Enforcement team' },
    { value: 'audit', label: 'Audit', icon: FileSearch, description: 'Route to Internal Audit team' },
    { value: 'compliance', label: 'Compliance', icon: ClipboardCheck, description: 'Route to Compliance team' },
  ];

  const priorityConfig = {
    low: 'bg-muted text-muted-foreground',
    medium: 'bg-info/10 text-info',
    high: 'bg-warning/10 text-warning',
    critical: 'bg-destructive/10 text-destructive',
  };

  const allStepsComplete = issue.actionSteps.length > 0 && 
    issue.actionSteps.every(s => s.status === 'complete' || s.status === 'deferred');

  const currentStage = getCurrentWorkflowStage();

  return (
    <div className="min-h-screen">
      <Header 
        title={issue.title} 
        subtitle={`Issue ${issue.id}`} 
      />

      <div className="p-6 space-y-6">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate('/issues')}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Issues
        </Button>

        {/* Workflow Progress */}
        <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
          <h3 className="font-semibold mb-4">Workflow Progress</h3>
          <WorkflowStepper currentStatus={issue.status} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Issue Details */}
            <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className={cn(
                      'text-xs font-semibold px-2 py-1 rounded-full capitalize',
                      priorityConfig[issue.priority]
                    )}>
                      {issue.priority} Priority
                    </span>
                    <Badge variant="secondary" className="capitalize">
                      {issue.issueCategory.replace('_', ' ')}
                    </Badge>
                  </div>
                  <h2 className="text-xl font-bold">{issue.title}</h2>
                </div>
              </div>

              <p className="text-muted-foreground mb-6">{issue.description}</p>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-muted-foreground">Reported By</p>
                    <p className="font-medium">{issue.reportedBy}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-muted-foreground">Reported</p>
                    <p className="font-medium">{format(new Date(issue.reportedAt), 'MMM d, yyyy')}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-muted-foreground">Department</p>
                    <p className="font-medium capitalize">{issue.department.replace('_', ' ')}</p>
                  </div>
                </div>
                {issue.dueDate && (
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-muted-foreground">Due Date</p>
                      <p className="font-medium">{format(new Date(issue.dueDate), 'MMM d, yyyy')}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Tabbed Content */}
            <Tabs defaultValue="work" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-4">
                <TabsTrigger value="work" className="flex items-center gap-2">
                  <ListTodo className="h-4 w-4" />
                  Work
                </TabsTrigger>
                <TabsTrigger value="timeline" className="flex items-center gap-2">
                  <History className="h-4 w-4" />
                  Stage Details
                </TabsTrigger>
                <TabsTrigger value="attachments" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Files ({issue.attachments.length})
                </TabsTrigger>
              </TabsList>

              {/* Work Tab - Action Steps */}
              <TabsContent value="work" className="space-y-6">
                {/* Action Steps */}
                <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold">Action Steps</h3>
                    <div className="flex gap-2">
                      {issue.actionSteps.length === 0 && (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={handleLoadRecommendations}
                        >
                          Load Recommendations
                        </Button>
                      )}
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setShowAddStep(true)}
                      >
                        <Plus className="h-4 w-4 mr-1" />
                        Add Step
                      </Button>
                    </div>
                  </div>

                  {showAddStep && (
                    <div className="mb-4 p-4 rounded-lg border border-primary/20 bg-primary/5 animate-fade-in">
                      <h4 className="font-medium mb-2">Add Custom Action Step</h4>
                      <Textarea
                        placeholder="Describe the action step..."
                        value={newStepDescription}
                        onChange={(e) => setNewStepDescription(e.target.value)}
                        className="mb-3"
                      />
                      <div className="flex gap-2">
                        <Button size="sm" onClick={handleAddCustomStep}>
                          Add Step
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => {
                            setShowAddStep(false);
                            setNewStepDescription('');
                          }}
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  )}

                  {issue.actionSteps.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <p>No action steps defined yet.</p>
                      <p className="text-sm">Load recommendations or add custom steps to get started.</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {issue.actionSteps.map((step, index) => (
                        <ActionStepItem
                          key={step.id}
                          step={step}
                          index={index}
                          onUpdateStatus={handleUpdateStepStatus}
                          isEditable={issue.status === 'in_progress'}
                        />
                      ))}
                    </div>
                  )}
                </div>

                {/* Quick Upload for Current Stage */}
                <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
                  <div className="flex items-center gap-2 mb-4">
                    <Paperclip className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">Add Evidence</h3>
                    <Badge variant="outline" className="capitalize text-xs">
                      {currentStage.replace('_', ' ')}
                    </Badge>
                  </div>
                  <AttachmentUploader
                    attachments={issue.attachments}
                    onAttachmentsChange={handleAttachmentsChange}
                    stage={currentStage}
                    uploadedBy={issue.assignedTo || issue.reportedBy}
                    isEditable={issue.status !== 'completed'}
                  />
                </div>
              </TabsContent>

              {/* Timeline Tab - Stage Details */}
              <TabsContent value="timeline">
                <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
                  <StageDetailsView issue={issue} />
                </div>
              </TabsContent>

              {/* Attachments Tab - All Files */}
              <TabsContent value="attachments">
                <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Paperclip className="h-5 w-5 text-primary" />
                      <h3 className="font-semibold">All Attachments</h3>
                      <Badge variant="secondary" className="text-xs">
                        {issue.attachments.length} total
                      </Badge>
                    </div>
                  </div>

                  <StageAttachmentsView 
                    attachments={issue.attachments}
                    currentStage={currentStage}
                  />

                  {issue.status !== 'completed' && (
                    <div className="mt-6 pt-6 border-t border-border">
                      <p className="text-sm font-medium mb-3 flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                        Add attachments for current stage
                      </p>
                      <AttachmentUploader
                        attachments={issue.attachments}
                        onAttachmentsChange={handleAttachmentsChange}
                        stage={currentStage}
                        uploadedBy={issue.assignedTo || issue.reportedBy}
                        isEditable={true}
                      />
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar Actions */}
          <div className="space-y-6">
            {/* Assignment */}
            {issue.status === 'reported' && (
              <div className="rounded-xl border border-border bg-card p-5 shadow-soft">
                <h3 className="font-semibold mb-4">Initiate & Assign</h3>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-muted-foreground mb-1.5 block">Assign To</label>
                    <Input
                      placeholder="Enter assignee name"
                      value={assignTo}
                      onChange={(e) => setAssignTo(e.target.value)}
                    />
                  </div>
                  <Button 
                    className="w-full" 
                    variant="hero"
                    onClick={handleAssign}
                    disabled={!assignTo.trim() || issue.actionSteps.length === 0}
                  >
                    <Send className="h-4 w-4 mr-2" />
                    Assign Issue
                  </Button>
                  {issue.actionSteps.length === 0 && (
                    <p className="text-xs text-muted-foreground text-center">
                      Add action steps before assigning
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Work in Progress Actions */}
            {issue.status === 'in_progress' && (
              <div className="rounded-xl border border-border bg-card p-5 shadow-soft">
                <h3 className="font-semibold mb-4">Actions</h3>
                <div className="space-y-4">
                  {/* Re-assign Section */}
                  <div className="space-y-3 pb-4 border-b border-border">
                    <p className="text-sm font-medium text-muted-foreground">Re-assign Issue</p>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1.5 block">Department</label>
                      <Select value={reassignDepartment} onValueChange={setReassignDepartment}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="nursing">Nursing</SelectItem>
                          <SelectItem value="pharmacy">Pharmacy</SelectItem>
                          <SelectItem value="laboratory">Laboratory</SelectItem>
                          <SelectItem value="radiology">Radiology</SelectItem>
                          <SelectItem value="emergency">Emergency</SelectItem>
                          <SelectItem value="surgery">Surgery</SelectItem>
                          <SelectItem value="administration">Administration</SelectItem>
                          <SelectItem value="it">IT</SelectItem>
                          <SelectItem value="facilities">Facilities</SelectItem>
                          <SelectItem value="compliance">Compliance</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1.5 block">Assign To</label>
                      <Input
                        placeholder="Enter new assignee"
                        value={reassignTo}
                        onChange={(e) => setReassignTo(e.target.value)}
                      />
                    </div>
                    <Button 
                      className="w-full" 
                      variant="outline"
                      onClick={handleReassign}
                      disabled={!reassignTo.trim()}
                    >
                      <User className="h-4 w-4 mr-2" />
                      Re-assign
                    </Button>
                  </div>

                  {/* Route to QA */}
                  <div className="space-y-3">
                    <Button 
                      className="w-full" 
                      variant="hero"
                      onClick={handleRouteToQA}
                      disabled={!allStepsComplete}
                    >
                      <Send className="h-4 w-4 mr-2" />
                      Route to QA Review
                    </Button>
                    {!allStepsComplete && (
                      <p className="text-xs text-muted-foreground text-center">
                        Complete all action steps to proceed
                      </p>
                    )}
                  </div>

                  {/* Send Back */}
                  <div className="pt-3 border-t border-border">
                    <Button 
                      className="w-full" 
                      variant="destructive"
                      onClick={() => setShowSendBackDialog(true)}
                    >
                      <XCircle className="h-4 w-4 mr-2" />
                      Send Back to Reported
                    </Button>
                    <p className="text-xs text-muted-foreground text-center mt-2">
                      Returns issue for re-initiation
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* QA Review Actions */}
            {issue.status === 'qa_review' && (
              <div className="rounded-xl border border-border bg-card p-5 shadow-soft">
                <h3 className="font-semibold mb-4">QA Review</h3>
                <div className="space-y-3">
                  <Button 
                    className="w-full" 
                    variant="success"
                    onClick={handleComplete}
                  >
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Approve & Complete
                  </Button>
                  <Button 
                    className="w-full" 
                    variant="outline"
                    onClick={() => setShowMonitoringDialog(true)}
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    Approve, Complete & Route to Monitoring
                  </Button>
                  <Button 
                    className="w-full" 
                    variant="destructive"
                    onClick={() => setShowRevisionDialog(true)}
                  >
                    <XCircle className="h-4 w-4 mr-2" />
                    Return for Revision
                  </Button>
                </div>
              </div>
            )}

            {/* Monitoring Destination Dialog */}
            <Dialog open={showMonitoringDialog} onOpenChange={setShowMonitoringDialog}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Route to Monitoring</DialogTitle>
                  <DialogDescription>
                    Select monitoring destination, department, and assignee.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  {/* Monitoring Destination */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Monitoring Destination</label>
                    <div className="grid gap-2">
                      {monitoringOptions.map((option) => {
                        const Icon = option.icon;
                        return (
                          <button
                            key={option.value}
                            onClick={() => setSelectedMonitoring(option.value)}
                            className={cn(
                              'flex items-center gap-3 p-3 rounded-lg border text-left transition-all',
                              selectedMonitoring === option.value
                                ? 'border-primary bg-primary/5 ring-1 ring-primary'
                                : 'border-border hover:border-primary/50 hover:bg-muted/50'
                            )}
                          >
                            <div className={cn(
                              'p-2 rounded-lg',
                              selectedMonitoring === option.value
                                ? 'bg-primary text-primary-foreground'
                                : 'bg-muted text-muted-foreground'
                            )}>
                              <Icon className="h-4 w-4" />
                            </div>
                            <div>
                              <p className="font-medium text-sm">{option.label}</p>
                              <p className="text-xs text-muted-foreground">{option.description}</p>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Department Selection */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Department</label>
                    <Select value={monitoringDepartment} onValueChange={(value) => {
                      setMonitoringDepartment(value);
                      setMonitoringUser(''); // Reset user when department changes
                    }}>
                      <SelectTrigger className="bg-background">
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent className="bg-background">
                        {departments.map((dept) => (
                          <SelectItem key={dept.value} value={dept.value}>
                            {dept.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* User Selection */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Assign To</label>
                    <Select value={monitoringUser} onValueChange={setMonitoringUser}>
                      <SelectTrigger className="bg-background">
                        <SelectValue placeholder="Select user" />
                      </SelectTrigger>
                      <SelectContent className="bg-background">
                        {filteredUsers.map((user) => (
                          <SelectItem key={user.value} value={user.value}>
                            {user.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {monitoringDepartment && filteredUsers.length === 0 && (
                      <p className="text-xs text-muted-foreground">No users in selected department</p>
                    )}
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="ghost" onClick={() => {
                    setShowMonitoringDialog(false);
                    setSelectedMonitoring('');
                    setMonitoringDepartment('');
                    setMonitoringUser('');
                  }}>
                    Cancel
                  </Button>
                  <Button 
                    variant="hero"
                    onClick={handleCompleteWithMonitoring}
                    disabled={!selectedMonitoring}
                  >
                    <Send className="h-4 w-4 mr-2" />
                    Complete & Route
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            {/* Return for Revision Dialog */}
            <Dialog open={showRevisionDialog} onOpenChange={setShowRevisionDialog}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Return for Revision</DialogTitle>
                  <DialogDescription>
                    Select department and assignee for the revision work.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  {/* Department Selection */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Department</label>
                    <Select value={revisionDepartment} onValueChange={(value) => {
                      setRevisionDepartment(value);
                      setRevisionUser('');
                    }}>
                      <SelectTrigger className="bg-background">
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent className="bg-background">
                        {departments.map((dept) => (
                          <SelectItem key={dept.value} value={dept.value}>
                            {dept.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* User Selection */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Assign To</label>
                    <Select value={revisionUser} onValueChange={setRevisionUser}>
                      <SelectTrigger className="bg-background">
                        <SelectValue placeholder="Select user" />
                      </SelectTrigger>
                      <SelectContent className="bg-background">
                        {(revisionDepartment 
                          ? mockUsers.filter(u => u.department === revisionDepartment) 
                          : mockUsers
                        ).map((user) => (
                          <SelectItem key={user.value} value={user.value}>
                            {user.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {revisionDepartment && mockUsers.filter(u => u.department === revisionDepartment).length === 0 && (
                      <p className="text-xs text-muted-foreground">No users in selected department</p>
                    )}
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="ghost" onClick={() => {
                    setShowRevisionDialog(false);
                    setRevisionDepartment('');
                    setRevisionUser('');
                  }}>
                    Cancel
                  </Button>
                  <Button 
                    variant="destructive"
                    onClick={handleReturnForRevision}
                  >
                    <XCircle className="h-4 w-4 mr-2" />
                    Return for Revision
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            {/* Send Back to Reported Dialog */}
            <Dialog open={showSendBackDialog} onOpenChange={setShowSendBackDialog}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Send Back to Reported</DialogTitle>
                  <DialogDescription>
                    Select department and assignee for re-initiation.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  {/* Department Selection */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Department</label>
                    <Select value={sendBackDepartment} onValueChange={(value) => {
                      setSendBackDepartment(value);
                      setSendBackUser('');
                    }}>
                      <SelectTrigger className="bg-background">
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent className="bg-background">
                        {departments.map((dept) => (
                          <SelectItem key={dept.value} value={dept.value}>
                            {dept.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* User Selection */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Assign To</label>
                    <Select value={sendBackUser} onValueChange={setSendBackUser}>
                      <SelectTrigger className="bg-background">
                        <SelectValue placeholder="Select user" />
                      </SelectTrigger>
                      <SelectContent className="bg-background">
                        {(sendBackDepartment 
                          ? mockUsers.filter(u => u.department === sendBackDepartment) 
                          : mockUsers
                        ).map((user) => (
                          <SelectItem key={user.value} value={user.value}>
                            {user.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {sendBackDepartment && mockUsers.filter(u => u.department === sendBackDepartment).length === 0 && (
                      <p className="text-xs text-muted-foreground">No users in selected department</p>
                    )}
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="ghost" onClick={() => {
                    setShowSendBackDialog(false);
                    setSendBackDepartment('');
                    setSendBackUser('');
                  }}>
                    Cancel
                  </Button>
                  <Button 
                    variant="destructive"
                    onClick={handleSendBackToReported}
                  >
                    <XCircle className="h-4 w-4 mr-2" />
                    Send Back
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            {/* Completed Status */}
            {issue.status === 'completed' && (
              <div className="rounded-xl border border-success/30 bg-success/5 p-5">
                <div className="flex items-center gap-3 mb-2">
                  <CheckCircle2 className="h-6 w-6 text-success" />
                  <h3 className="font-semibold text-success">Issue Completed</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  This compliance issue has been successfully resolved and closed.
                </p>
                {issue.closedAt && (
                  <p className="text-xs text-muted-foreground mt-2">
                    Closed on {format(new Date(issue.closedAt), 'MMMM d, yyyy')}
                  </p>
                )}
              </div>
            )}

            {/* Issue Info */}
            <div className="rounded-xl border border-border bg-card p-5 shadow-soft">
              <h3 className="font-semibold mb-4">Issue Information</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Issue ID</span>
                  <span className="font-mono font-medium">{issue.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Type</span>
                  <span className="capitalize">{issue.issueType.replace('_', ' ')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Assigned To</span>
                  <span>{issue.assignedTo || 'Unassigned'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Steps</span>
                  <span>
                    {issue.actionSteps.filter(s => s.status === 'complete').length} / {issue.actionSteps.length} complete
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Attachments</span>
                  <span>{issue.attachments.length} file(s)</span>
                </div>
              </div>
            </div>

            {/* Cross-References Panel */}
            <ConnectionsPanel
              sourceType="complianceconnect"
              sourceId={issue.id}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
