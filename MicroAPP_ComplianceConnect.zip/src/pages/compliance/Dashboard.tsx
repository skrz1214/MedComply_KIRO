import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { mockIssues, mockStats, mockCapaStats, mockCitationStats } from '@/data/mockData';
import { 
  FileText, 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  Plus,
  ArrowRight,
  Download,
  Building2,
  User,
  FileCheck,
  Search,
  ClipboardList,
  BookOpen,
  ClipboardCheck,
  UserCog
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

// Mock users for impersonation
const mockUsers = [
  { id: 'admin-1', name: 'Sarah Johnson', role: 'Super Admin', department: 'Administration' },
  { id: 'compliance-mgr-1', name: 'Michael Chen', role: 'Compliance Manager', department: 'Compliance' },
  { id: 'dept-head-1', name: 'Emily Davis', role: 'Department Head', department: 'Nursing' },
  { id: 'qa-1', name: 'Robert Wilson', role: 'QA Reviewer', department: 'Quality Assurance' },
  { id: 'contributor-1', name: 'Lisa Brown', role: 'Contributor', department: 'Pharmacy' },
  { id: 'reporter-1', name: 'James Miller', role: 'Reporter', department: 'Laboratory' },
];

export default function Dashboard() {
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState<'organization' | 'personal'>('organization');
  const [currentUser, setCurrentUser] = useState(mockUsers[0]);

  const recentIssues = mockIssues.slice(0, 5);
  const urgentIssues = mockIssues.filter(i => i.priority === 'critical' || i.priority === 'high').slice(0, 3);

  const stageData = [
    { stage: 'Reported', count: mockIssues.filter(i => i.status === 'reported').length, color: 'text-slate-600', bgColor: 'bg-slate-100' },
    { stage: 'In Progress', count: mockIssues.filter(i => i.status === 'in_progress').length, color: 'text-blue-600', bgColor: 'bg-blue-100' },
    { stage: 'QA Review', count: mockIssues.filter(i => i.status === 'qa_review').length, color: 'text-amber-600', bgColor: 'bg-amber-100' },
    { stage: 'Completed', count: mockIssues.filter(i => i.status === 'completed').length, color: 'text-green-600', bgColor: 'bg-green-100' },
  ];

  const priorityData = [
    { level: 'Critical', count: mockIssues.filter(i => i.priority === 'critical').length, color: 'bg-red-500', textColor: 'text-red-600', badgeColor: 'bg-red-100 text-red-700' },
    { level: 'High', count: mockIssues.filter(i => i.priority === 'high').length, color: 'bg-orange-500', textColor: 'text-orange-600', badgeColor: 'bg-orange-100 text-orange-700' },
    { level: 'Medium', count: mockIssues.filter(i => i.priority === 'medium').length, color: 'bg-yellow-500', textColor: 'text-yellow-600', badgeColor: 'bg-yellow-100 text-yellow-700' },
    { level: 'Low', count: mockIssues.filter(i => i.priority === 'low').length, color: 'bg-green-500', textColor: 'text-green-600', badgeColor: 'bg-green-100 text-green-700' },
  ];

  const totalForPercentage = mockIssues.length || 1;

  const categories = [
    { name: 'Patient Safety', count: mockIssues.filter(i => i.issueCategory === 'patient_safety').length },
    { name: 'Data Privacy', count: mockIssues.filter(i => i.issueCategory === 'data_privacy').length },
    { name: 'Regulatory', count: mockIssues.filter(i => i.issueCategory === 'regulatory').length },
    { name: 'Documentation', count: mockIssues.filter(i => i.issueCategory === 'documentation').length },
    { name: 'Operational', count: mockIssues.filter(i => i.issueCategory === 'operational').length },
  ].sort((a, b) => b.count - a.count);

  const getStatusBadge = (status: string) => {
    const statusConfig: Record<string, string> = {
      'reported': 'bg-slate-100 text-slate-700',
      'in_progress': 'bg-blue-100 text-blue-700',
      'qa_review': 'bg-amber-100 text-amber-700',
      'completed': 'bg-green-100 text-green-700',
    };
    return statusConfig[status] || 'bg-gray-100 text-gray-700';
  };

  const formatStatus = (status: string) => {
    return status.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  const exportToCSV = () => {
    const today = new Date().toISOString().split('T')[0];
    
    // Build CSV content
    let csvContent = 'ComplianceConnect Dashboard Metrics Report\n';
    csvContent += `Generated: ${new Date().toLocaleString()}\n`;
    csvContent += `View Mode: ${viewMode === 'organization' ? 'Organization' : 'Personal'}\n`;
    csvContent += `User: ${currentUser.name} (${currentUser.role})\n\n`;

    // Summary Statistics
    csvContent += 'SUMMARY STATISTICS\n';
    csvContent += 'Metric,Value\n';
    csvContent += `Total Issues,${mockStats.totalIssues}\n`;
    csvContent += `Open Issues,${mockStats.openIssues}\n`;
    csvContent += `Critical/High Priority,${mockIssues.filter(i => i.priority === 'critical' || i.priority === 'high').length}\n`;
    csvContent += `Completed This Month,${mockStats.completedThisMonth}\n\n`;

    // Issues by Stage
    csvContent += 'ISSUES BY STAGE\n';
    csvContent += 'Stage,Count,Percentage\n';
    stageData.forEach(item => {
      csvContent += `${item.stage},${item.count},${Math.round((item.count / totalForPercentage) * 100)}%\n`;
    });
    csvContent += '\n';

    // Priority Distribution
    csvContent += 'PRIORITY DISTRIBUTION\n';
    csvContent += 'Priority Level,Count,Percentage\n';
    priorityData.forEach(item => {
      csvContent += `${item.level},${item.count},${Math.round((item.count / totalForPercentage) * 100)}%\n`;
    });
    csvContent += '\n';

    // Top Categories
    csvContent += 'TOP CATEGORIES\n';
    csvContent += 'Category,Count\n';
    categories.forEach(cat => {
      csvContent += `${cat.name},${cat.count}\n`;
    });
    csvContent += '\n';

    // Module Stats
    csvContent += 'MODULE STATISTICS\n';
    csvContent += 'Module,Total Count\n';
    csvContent += `Issues,${mockStats.totalIssues}\n`;
    csvContent += `Citations,${mockCitationStats.totalCitations}\n`;
    csvContent += `CAPAs,${mockCapaStats.totalCapas}\n`;

    // Create and download the file
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `compliance-dashboard-${today}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header Section */}
      <div className="bg-gradient-to-r from-blue-600 via-blue-500 to-cyan-500 px-6 py-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">ComplianceConnect Dashboard</h1>
            <p className="text-blue-100">Healthcare Compliance Management System</p>
          </div>
          <div className="flex items-center gap-3">
            {/* User Impersonation */}
            <div className="flex items-center gap-2">
              <UserCog className="h-4 w-4 text-white/70" />
              <Select value={currentUser.id} onValueChange={(id) => setCurrentUser(mockUsers.find(u => u.id === id) || mockUsers[0])}>
                <SelectTrigger className="w-48 bg-white/10 border-white/20 text-white text-sm h-9 [&>svg]:text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {mockUsers.map(user => (
                    <SelectItem key={user.id} value={user.id}>
                      <div className="flex flex-col">
                        <span className="font-medium">{user.name}</span>
                        <span className="text-xs text-muted-foreground">{user.role}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg px-3 py-2 text-white text-sm">
              {currentUser.role}
            </div>
            {/* Organization/Personal Toggle */}
            <div className="flex bg-white rounded-lg p-1">
              <button 
                onClick={() => setViewMode('organization')}
                className={cn(
                  "flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium transition-colors",
                  viewMode === 'organization' 
                    ? "bg-blue-50 text-blue-700" 
                    : "text-gray-600 hover:bg-gray-50"
                )}
              >
                <Building2 className="h-4 w-4" />
                Organization
              </button>
              <button 
                onClick={() => setViewMode('personal')}
                className={cn(
                  "flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium transition-colors",
                  viewMode === 'personal' 
                    ? "bg-blue-50 text-blue-700" 
                    : "text-gray-600 hover:bg-gray-50"
                )}
              >
                <User className="h-4 w-4" />
                Personal
              </button>
            </div>
            <Button variant="outline" className="bg-white text-blue-600 border-white hover:bg-blue-50" onClick={exportToCSV}>
              <Download className="h-4 w-4 mr-2" />
              Export CSV
            </Button>
            <Button onClick={() => navigate('/report')} className="bg-red-500 hover:bg-red-600 text-white">
              <Plus className="h-4 w-4 mr-2" />
              Report Issue
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* View Mode Indicator */}
        {viewMode === 'personal' && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-center gap-2">
            <User className="h-4 w-4 text-blue-600" />
            <span className="text-sm text-blue-700">
              Showing personal view for <strong>{currentUser.name}</strong> ({currentUser.department})
            </span>
          </div>
        )}

        {/* Stats Row */}
        <Card>
          <CardContent className="p-0">
            <div className="grid grid-cols-4 divide-x divide-border">
              <div className="p-6">
                <p className="text-sm text-muted-foreground">Total Issues</p>
                <p className="text-3xl font-bold mt-1">{mockStats.totalIssues}</p>
                <p className="text-xs text-muted-foreground mt-1">All time records</p>
              </div>
              <div className="p-6">
                <p className="text-sm text-muted-foreground">Open Issues</p>
                <p className="text-3xl font-bold text-blue-600 mt-1">{mockStats.openIssues}</p>
                <p className="text-xs text-muted-foreground mt-1">Requiring attention</p>
              </div>
              <div className="p-6">
                <p className="text-sm text-muted-foreground">Critical / High</p>
                <p className="text-3xl font-bold text-red-600 mt-1">
                  {mockIssues.filter(i => i.priority === 'critical' || i.priority === 'high').length}
                </p>
                <p className="text-xs text-muted-foreground mt-1">Priority items</p>
              </div>
              <div className="p-6">
                <p className="text-sm text-muted-foreground">Completed This Month</p>
                <p className="text-3xl font-bold text-green-600 mt-1">{mockStats.completedThisMonth}</p>
                <p className="text-xs text-muted-foreground mt-1">Successfully resolved</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Issues by Stage */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Issues by Stage</CardTitle>
            <p className="text-sm text-muted-foreground">Current distribution across the lifecycle</p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 gap-4">
              {stageData.map((item) => (
                <div key={item.stage} className={cn("rounded-lg p-4", item.bgColor)}>
                  <div className="flex items-center gap-2">
                    <FileCheck className={cn("h-4 w-4", item.color)} />
                    <span className={cn("text-sm font-medium", item.color)}>{item.stage}</span>
                  </div>
                  <p className="text-2xl font-bold mt-2">{item.count}</p>
                  <p className="text-xs text-muted-foreground">{Math.round((item.count / totalForPercentage) * 100)}% of total</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Two Column Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Priority Distribution */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Priority Distribution</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {priorityData.map((item) => (
                <div key={item.level} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Badge className={item.badgeColor}>{item.level}</Badge>
                    <span className="text-sm text-muted-foreground">{item.count} ({Math.round((item.count / totalForPercentage) * 100)}%)</span>
                  </div>
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div 
                      className={cn("h-full rounded-full", item.color)} 
                      style={{ width: `${(item.count / totalForPercentage) * 100}%` }} 
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Top Categories */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Top Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {categories.map((cat) => (
                  <div key={cat.name} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                    <span className="text-sm">{cat.name}</span>
                    <Badge variant="secondary" className="bg-primary/10 text-primary">{cat.count}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Issues and Urgent Attention */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Issues */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-lg">Recent Issues</CardTitle>
                <p className="text-sm text-muted-foreground">Latest reported issues</p>
              </div>
              <Button variant="ghost" size="sm" onClick={() => navigate('/issues')}>
                View All
                <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentIssues.map((issue) => (
                <div 
                  key={issue.id} 
                  className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                  onClick={() => navigate(`/issues/${issue.id}`)}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-mono text-muted-foreground">{issue.id}</span>
                      <Badge className={getStatusBadge(issue.status)} variant="secondary">
                        {formatStatus(issue.status)}
                      </Badge>
                    </div>
                    <p className="text-sm font-medium truncate">{issue.title}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Urgent Attention */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Urgent Attention</CardTitle>
              <p className="text-sm text-muted-foreground">Immediate and urgent priority issues</p>
            </CardHeader>
            <CardContent className="space-y-3">
              {urgentIssues.length > 0 ? urgentIssues.map((issue) => (
                <div 
                  key={issue.id} 
                  className="p-3 rounded-lg border border-red-200 bg-red-50/50 hover:bg-red-50 cursor-pointer transition-colors"
                  onClick={() => navigate(`/issues/${issue.id}`)}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono text-muted-foreground">{issue.id}</span>
                    <Badge className="bg-red-100 text-red-700">Urgent</Badge>
                  </div>
                  <p className="text-sm font-medium">{issue.title}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {issue.issueCategory.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')} • {issue.reportedBy}
                  </p>
                </div>
              )) : (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle2 className="h-12 w-12 mx-auto mb-2 text-green-500" />
                  <p className="text-sm">No urgent issues at this time</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Module Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="hover:border-primary/50 cursor-pointer transition-colors" onClick={() => navigate('/issues')}>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="p-3 rounded-lg bg-blue-100">
                <ClipboardList className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Issues</p>
                <p className="text-2xl font-bold">{mockStats.totalIssues}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="hover:border-primary/50 cursor-pointer transition-colors" onClick={() => navigate('/citations')}>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="p-3 rounded-lg bg-purple-100">
                <BookOpen className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Citations</p>
                <p className="text-2xl font-bold">{mockCitationStats.totalCitations}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="hover:border-primary/50 cursor-pointer transition-colors" onClick={() => navigate('/actionguard')}>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="p-3 rounded-lg bg-green-100">
                <ClipboardCheck className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">CAPAs</p>
                <p className="text-2xl font-bold">{mockCapaStats.totalCapas}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
