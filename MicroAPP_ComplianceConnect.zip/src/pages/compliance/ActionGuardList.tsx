import { useState } from 'react';
import { ClipboardCheck, Plus, Search, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { mockCapas, mockCapaStats } from '@/data/mockData';

export default function ActionGuardList() {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCapas = mockCapas.filter(capa =>
    capa.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    capa.problemStatement.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Closed': return 'bg-green-500/10 text-green-600 border-green-500/20';
      case 'In Progress': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'Effectiveness Review': return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
      case 'Approved': return 'bg-cyan-500/10 text-cyan-600 border-cyan-500/20';
      case 'Draft': return 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20';
      case 'Submitted': return 'bg-orange-500/10 text-orange-600 border-orange-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Corrective': return 'bg-red-500/10 text-red-600 border-red-500/20';
      case 'Preventive': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'Both': return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">ActionGuard (CAPA)</h1>
          <p className="text-muted-foreground">Corrective and Preventive Action Management</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          New CAPA
        </Button>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Draft</p>
            <p className="text-2xl font-bold text-yellow-600">{mockCapaStats.draftCapas}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">In Progress</p>
            <p className="text-2xl font-bold text-blue-600">{mockCapaStats.inProgressCapas}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Effectiveness Review</p>
            <p className="text-2xl font-bold text-purple-600">{mockCapaStats.effectivenessReview}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Closed This Month</p>
            <p className="text-2xl font-bold text-green-600">{mockCapaStats.closedThisMonth}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Overdue Actions</p>
            <p className="text-2xl font-bold text-red-600">{mockCapaStats.overdueActions}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Pending Approval</p>
            <p className="text-2xl font-bold">{mockCapaStats.pendingApproval}</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search CAPAs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button variant="outline" className="gap-2">
          <Filter className="h-4 w-4" />
          Filters
        </Button>
      </div>

      {/* CAPA Grid */}
      <div className="space-y-3">
        {filteredCapas.map((capa) => (
          <Card key={capa.id} className="hover:border-primary/50 transition-colors cursor-pointer">
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3 flex-1">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <ClipboardCheck className="h-5 w-5 text-primary" />
                  </div>
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant="outline" className={getStatusColor(capa.status)}>
                        {capa.status}
                      </Badge>
                      <Badge variant="outline" className={getTypeColor(capa.type)}>
                        {capa.type}
                      </Badge>
                      <Badge variant="outline">{capa.originType}</Badge>
                    </div>
                    <h3 className="font-semibold text-foreground">{capa.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {capa.problemStatement}
                    </p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground mt-2">
                      <span>Department: {capa.department}</span>
                      <span>Owner: {capa.owner}</span>
                      <span>Due: {new Date(capa.dueDate).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredCapas.length === 0 && (
          <Card>
            <CardContent className="p-8 text-center">
              <ClipboardCheck className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="font-semibold text-foreground mb-1">No CAPAs found</h3>
              <p className="text-sm text-muted-foreground">Try adjusting your search or filters</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
