import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '@/components/compliance/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { mockCitationCases, mockCitationCaseStats } from '@/data/mockData';
import { 
  Plus, 
  Search, 
  Filter,
  AlertTriangle,
  Clock,
  CheckCircle2,
  FileSearch,
  ClipboardList,
  Building2,
  Calendar,
  User,
  Link2
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, differenceInDays, isPast } from 'date-fns';

const statusFilters = [
  { value: 'all', label: 'All Cases' },
  { value: 'reported', label: 'Reported' },
  { value: 'triage', label: 'Triage' },
  { value: 'remediation_in_progress', label: 'In Progress' },
  { value: 'qa_verification', label: 'QA Verification' },
  { value: 'closed', label: 'Closed' },
  { value: 'monitoring', label: 'Monitoring' },
];

export default function CitationCasesList() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [authorityFilter, setAuthorityFilter] = useState('all');

  const filteredCases = mockCitationCases.filter(caseItem => {
    const matchesSearch = 
      caseItem.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      caseItem.citationCode?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      caseItem.id.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || caseItem.status === statusFilter;
    const matchesAuthority = authorityFilter === 'all' || caseItem.authorityType === authorityFilter;
    
    return matchesSearch && matchesStatus && matchesAuthority;
  });

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'draft': return { color: 'bg-muted text-muted-foreground', label: 'Draft' };
      case 'reported': return { color: 'bg-blue-500/10 text-blue-600', label: 'Reported' };
      case 'triage': return { color: 'bg-yellow-500/10 text-yellow-600', label: 'Triage' };
      case 'remediation_in_progress': return { color: 'bg-orange-500/10 text-orange-600', label: 'In Progress' };
      case 'qa_verification': return { color: 'bg-purple-500/10 text-purple-600', label: 'QA Review' };
      case 'closed': return { color: 'bg-green-500/10 text-green-600', label: 'Closed' };
      case 'monitoring': return { color: 'bg-info/10 text-info', label: 'Monitoring' };
      default: return { color: 'bg-muted text-muted-foreground', label: status };
    }
  };

  const getSeverityConfig = (severity: string) => {
    switch (severity) {
      case 'low': return 'bg-muted text-muted-foreground';
      case 'medium': return 'bg-info/10 text-info';
      case 'high': return 'bg-warning/10 text-warning';
      case 'critical': return 'bg-destructive/10 text-destructive';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getModeLabel = (mode: string) => {
    switch (mode) {
      case 'poc': return 'PoC';
      case 'esc': return 'ESC';
      case 'general': return 'General';
      default: return mode;
    }
  };

  const getDueInfo = (caseItem: typeof mockCitationCases[0]) => {
    const dueDate = caseItem.pocDueDate || caseItem.escDueDate || caseItem.remediationDueDate;
    if (!dueDate) return null;
    
    const daysUntil = differenceInDays(new Date(dueDate), new Date());
    const isOverdue = isPast(new Date(dueDate));
    
    return {
      date: dueDate,
      daysUntil,
      isOverdue,
      label: caseItem.pocDueDate ? 'PoC Due' : caseItem.escDueDate ? 'ESC Due' : 'Due'
    };
  };

  return (
    <div className="min-h-screen">
      <Header 
        title="Citation Cases" 
        subtitle="Manage citation deficiency cases and remediation" 
      />

      <div className="p-6 space-y-6">
        {/* KPI Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Total Cases</p>
              <p className="text-2xl font-bold">{mockCitationCaseStats.totalCases}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Triage</p>
              <p className="text-2xl font-bold text-yellow-600">{mockCitationCaseStats.triageCases}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">In Progress</p>
              <p className="text-2xl font-bold text-orange-600">{mockCitationCaseStats.inProgressCases}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">QA Verification</p>
              <p className="text-2xl font-bold text-purple-600">{mockCitationCaseStats.qaVerificationCases}</p>
            </CardContent>
          </Card>
          <Card className="border-destructive/30">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Overdue PoC</p>
              <p className="text-2xl font-bold text-destructive">{mockCitationCaseStats.overduePoCCount}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Closed</p>
              <p className="text-2xl font-bold text-green-600">{mockCitationCaseStats.closedCases}</p>
            </CardContent>
          </Card>
        </div>

        {/* Actions Bar */}
        <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
          <div className="flex flex-1 gap-4 w-full md:w-auto">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search cases..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                {statusFilters.map(f => (
                  <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={authorityFilter} onValueChange={setAuthorityFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Authority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Authorities</SelectItem>
                <SelectItem value="cms_state_survey">CMS/State Survey</SelectItem>
                <SelectItem value="joint_commission">Joint Commission</SelectItem>
                <SelectItem value="internal_audit">Internal Audit</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={() => navigate('/citations/cases/new')} className="gap-2">
            <Plus className="h-4 w-4" />
            Report Case
          </Button>
        </div>

        {/* Cases List */}
        <div className="space-y-3">
          {filteredCases.map((caseItem) => {
            const statusConfig = getStatusConfig(caseItem.status);
            const dueInfo = getDueInfo(caseItem);
            
            return (
              <Card 
                key={caseItem.id}
                className="hover:border-primary/50 transition-colors cursor-pointer"
                onClick={() => navigate(`/citations/cases/${caseItem.id}`)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3 flex-1">
                      <div className={cn(
                        'p-2 rounded-lg',
                        caseItem.status === 'closed' ? 'bg-success/10' : 'bg-primary/10'
                      )}>
                        {caseItem.status === 'closed' ? (
                          <CheckCircle2 className="h-5 w-5 text-success" />
                        ) : caseItem.status === 'qa_verification' ? (
                          <FileSearch className="h-5 w-5 text-purple-600" />
                        ) : (
                          <ClipboardList className="h-5 w-5 text-primary" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <span className="font-mono text-sm text-muted-foreground">{caseItem.id}</span>
                          <Badge variant="outline" className={statusConfig.color}>
                            {statusConfig.label}
                          </Badge>
                          <Badge variant="outline" className={getSeverityConfig(caseItem.severity)}>
                            {caseItem.severity}
                          </Badge>
                          <Badge variant="secondary" className="text-xs">
                            {getModeLabel(caseItem.mode)}
                          </Badge>
                        </div>
                        <h3 className="font-semibold text-foreground truncate">{caseItem.title}</h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          <span className="font-mono">{caseItem.citationCode}</span> - {caseItem.citationTitle}
                        </p>
                        <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground flex-wrap">
                          <span className="flex items-center gap-1">
                            <Building2 className="h-3 w-3" />
                            {caseItem.facility}
                          </span>
                          <span className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            {caseItem.owner || 'Unassigned'}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {format(new Date(caseItem.reportedDate), 'MMM d, yyyy')}
                          </span>
                          {caseItem.linkedCapaId && (
                            <span className="flex items-center gap-1 text-primary">
                              <Link2 className="h-3 w-3" />
                              CAPA
                            </span>
                          )}
                          {caseItem.linkedIssueId && (
                            <span className="flex items-center gap-1 text-info">
                              <Link2 className="h-3 w-3" />
                              Issue
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {/* Due Date Clock */}
                    {dueInfo && caseItem.status !== 'closed' && (
                      <div className={cn(
                        'text-right px-3 py-2 rounded-lg border',
                        dueInfo.isOverdue 
                          ? 'bg-destructive/10 border-destructive/30 text-destructive' 
                          : dueInfo.daysUntil <= 3 
                            ? 'bg-warning/10 border-warning/30 text-warning'
                            : 'bg-muted border-border text-muted-foreground'
                      )}>
                        <div className="flex items-center gap-1 justify-end">
                          {dueInfo.isOverdue ? (
                            <AlertTriangle className="h-4 w-4" />
                          ) : (
                            <Clock className="h-4 w-4" />
                          )}
                          <span className="text-xs font-medium">{dueInfo.label}</span>
                        </div>
                        <p className="text-sm font-bold">
                          {dueInfo.isOverdue 
                            ? `${Math.abs(dueInfo.daysUntil)}d overdue`
                            : `${dueInfo.daysUntil}d left`
                          }
                        </p>
                        <p className="text-xs">
                          {format(new Date(dueInfo.date), 'MMM d')}
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}

          {filteredCases.length === 0 && (
            <Card>
              <CardContent className="p-8 text-center">
                <ClipboardList className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="font-semibold text-foreground mb-1">No cases found</h3>
                <p className="text-sm text-muted-foreground">Try adjusting your search or filters</p>
              </CardContent>
            </Card>
          )}
        </div>

        <p className="text-sm text-muted-foreground text-center">
          Showing {filteredCases.length} of {mockCitationCases.length} cases
        </p>
      </div>
    </div>
  );
}