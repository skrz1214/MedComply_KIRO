import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '@/components/compliance/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { IssueType, IssueCategory, Department, Attachment, ActionStep } from '@/types/compliance';
import { AttachmentUploader } from '@/components/compliance/AttachmentUploader';
import { ConnectionsPanel } from '@/components/compliance/ConnectionsPanel';
import { recommendedActions } from '@/data/mockData';
import { 
  AlertCircle, Send, ArrowLeft, ArrowRight, Paperclip, 
  Plus, Trash2, ExternalLink, CheckCircle2, Sparkles,
  FileText, User, Calendar, ClipboardList, Link2
} from 'lucide-react';
import { cn } from '@/lib/utils';

const issueTypes: { value: IssueType; label: string }[] = [
  { value: 'risk', label: 'Risk' },
  { value: 'incident_event', label: 'Incident/Event' },
  { value: 'investigation_enforcement', label: 'Investigation & Enforcement' },
  { value: 'audit', label: 'Audit' },
  { value: 'policy_procedure', label: 'Policy/Procedure' },
  { value: 'complaint', label: 'Complaint' },
  { value: 'training_competency', label: 'Training/Competency' },
  { value: 'privacy_data_rights', label: 'Privacy and Data Rights' },
  { value: 'governance', label: 'Governance' },
];

const issueCategories: { value: IssueCategory; label: string }[] = [
  { value: 'patient_safety', label: 'Patient Safety' },
  { value: 'data_privacy', label: 'Data Privacy' },
  { value: 'regulatory', label: 'Regulatory' },
  { value: 'documentation', label: 'Documentation' },
  { value: 'operational', label: 'Operational' },
  { value: 'other', label: 'Other' },
];

const departments: { value: Department; label: string }[] = [
  { value: 'nursing', label: 'Nursing' },
  { value: 'pharmacy', label: 'Pharmacy' },
  { value: 'laboratory', label: 'Laboratory' },
  { value: 'radiology', label: 'Radiology' },
  { value: 'administration', label: 'Administration' },
  { value: 'it', label: 'IT' },
  { value: 'quality_assurance', label: 'Quality Assurance' },
];

const priorities = [
  { value: 'low', label: 'Low', description: 'Non-urgent, can be addressed within 30 days' },
  { value: 'medium', label: 'Medium', description: 'Should be addressed within 14 days' },
  { value: 'high', label: 'High', description: 'Requires attention within 7 days' },
  { value: 'critical', label: 'Critical', description: 'Immediate action required' },
];

const steps = [
  { id: 1, name: 'Basic Info', icon: FileText },
  { id: 2, name: 'Classification', icon: ClipboardList },
  { id: 3, name: 'Action Steps', icon: CheckCircle2 },
  { id: 4, name: 'Assignment', icon: User },
];

interface SelectedActionStep {
  id: string;
  description: string;
  sourceUrl?: string;
  isCustom: boolean;
  selected: boolean;
}

export default function ReportIssue() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [actionSteps, setActionSteps] = useState<SelectedActionStep[]>([]);
  const [customStepDescription, setCustomStepDescription] = useState('');

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    issueType: '' as IssueType | '',
    issueCategory: '' as IssueCategory | '',
    department: '' as Department | '',
    priority: 'medium',
    reportedBy: '',
    assignedTo: '',
    dueDate: '',
  });

  const canProceedStep1 = formData.title && formData.description && formData.department && formData.priority && formData.reportedBy;
  const canProceedStep2 = formData.issueType && formData.issueCategory;
  const canProceedStep3 = actionSteps.some(step => step.selected);

  const handleContinueToRecommendations = () => {
    if (!formData.issueType) return;
    
    const recommended = recommendedActions[formData.issueType] || [];
    const steps: SelectedActionStep[] = recommended.map((action, index) => ({
      id: `rec-${index}`,
      description: action.description,
      sourceUrl: action.sourceUrl,
      isCustom: false,
      selected: true,
    }));
    setActionSteps(steps);
    setCurrentStep(3);
  };

  const toggleActionStep = (stepId: string) => {
    setActionSteps(prev => prev.map(step => 
      step.id === stepId ? { ...step, selected: !step.selected } : step
    ));
  };

  const addCustomStep = () => {
    if (!customStepDescription.trim()) return;
    
    const newStep: SelectedActionStep = {
      id: `custom-${Date.now()}`,
      description: customStepDescription.trim(),
      isCustom: true,
      selected: true,
    };
    setActionSteps(prev => [...prev, newStep]);
    setCustomStepDescription('');
  };

  const removeCustomStep = (stepId: string) => {
    setActionSteps(prev => prev.filter(step => step.id !== stepId));
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    const selectedSteps: ActionStep[] = actionSteps
      .filter(step => step.selected)
      .map(step => ({
        id: step.id,
        description: step.description,
        sourceUrl: step.sourceUrl,
        isCustom: step.isCustom,
        status: 'pending' as const,
      }));

    toast({
      title: 'Issue Reported Successfully',
      description: `Your compliance issue has been submitted with ${selectedSteps.length} action steps and ${attachments.length} attachment(s).`,
    });

    navigate('/issues');
  };

  const renderStepIndicator = () => (
    <div className="flex items-center justify-center mb-8">
      {steps.map((step, index) => {
        const Icon = step.icon;
        const isActive = currentStep === step.id;
        const isCompleted = currentStep > step.id;
        
        return (
          <div key={step.id} className="flex items-center">
            <div className="flex flex-col items-center">
              <div className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300",
                isActive && "bg-primary text-white shadow-glow",
                isCompleted && "bg-success text-white",
                !isActive && !isCompleted && "bg-muted text-muted-foreground"
              )}>
                {isCompleted ? (
                  <CheckCircle2 className="h-5 w-5" />
                ) : (
                  <Icon className="h-5 w-5" />
                )}
              </div>
              <span className={cn(
                "text-xs mt-2 font-medium",
                isActive && "text-primary",
                isCompleted && "text-success",
                !isActive && !isCompleted && "text-muted-foreground"
              )}>
                {step.name}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div className={cn(
                "w-16 h-0.5 mx-2 mt-[-20px]",
                currentStep > step.id ? "bg-success" : "bg-border"
              )} />
            )}
          </div>
        );
      })}
    </div>
  );

  const renderStep1 = () => (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-start gap-4 p-4 rounded-lg bg-info/10 border border-info/20">
        <AlertCircle className="h-5 w-5 text-info shrink-0 mt-0.5" />
        <div>
          <h3 className="font-semibold text-info mb-1">Step 1: Basic Information</h3>
          <p className="text-sm text-muted-foreground">
            Provide the essential details about the compliance issue you're reporting.
          </p>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="title">Issue Title *</Label>
        <Input
          id="title"
          placeholder="Brief, descriptive title for the compliance issue"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description *</Label>
        <Textarea
          id="description"
          placeholder="Provide a detailed description of the compliance issue..."
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className="min-h-[120px]"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Responsible Department *</Label>
          <Select 
            value={formData.department}
            onValueChange={(value) => setFormData({ ...formData, department: value as Department })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select department" />
            </SelectTrigger>
            <SelectContent>
              {departments.map((dept) => (
                <SelectItem key={dept.value} value={dept.value}>
                  {dept.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Priority Level *</Label>
          <Select 
            value={formData.priority}
            onValueChange={(value) => setFormData({ ...formData, priority: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select priority" />
            </SelectTrigger>
            <SelectContent>
              {priorities.map((p) => (
                <SelectItem key={p.value} value={p.value}>
                  <span className="font-medium">{p.label}</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="reportedBy">Your Name *</Label>
        <Input
          id="reportedBy"
          placeholder="Enter your full name"
          value={formData.reportedBy}
          onChange={(e) => setFormData({ ...formData, reportedBy: e.target.value })}
        />
      </div>

      <div className="flex justify-end pt-4">
        <Button 
          onClick={() => setCurrentStep(2)}
          disabled={!canProceedStep1}
          variant="hero"
        >
          Continue to Classification
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-start gap-4 p-4 rounded-lg bg-info/10 border border-info/20">
        <Sparkles className="h-5 w-5 text-info shrink-0 mt-0.5" />
        <div>
          <h3 className="font-semibold text-info mb-1">Step 2: Issue Classification</h3>
          <p className="text-sm text-muted-foreground">
            Select the issue type and category. Our system will provide recommended action steps based on your selection.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label>Issue Type *</Label>
          <Select 
            value={formData.issueType}
            onValueChange={(value) => setFormData({ ...formData, issueType: value as IssueType })}
          >
            <SelectTrigger className="h-12">
              <SelectValue placeholder="Select issue type" />
            </SelectTrigger>
            <SelectContent>
              {issueTypes.map((type) => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Issue Category *</Label>
          <Select 
            value={formData.issueCategory}
            onValueChange={(value) => setFormData({ ...formData, issueCategory: value as IssueCategory })}
          >
            <SelectTrigger className="h-12">
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              {issueCategories.map((cat) => (
                <SelectItem key={cat.value} value={cat.value}>
                  {cat.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {formData.issueType && formData.issueCategory && (
        <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
          <p className="text-sm text-muted-foreground">
            <span className="font-semibold text-primary">
              {recommendedActions[formData.issueType]?.length || 0} recommended action steps
            </span>{' '}
            will be suggested based on your selection.
          </p>
        </div>
      )}

      <div className="flex justify-between pt-4">
        <Button variant="outline" onClick={() => setCurrentStep(1)}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <Button 
          onClick={handleContinueToRecommendations}
          disabled={!canProceedStep2}
          variant="hero"
        >
          <Sparkles className="h-4 w-4 mr-2" />
          Continue to Recommendations
        </Button>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-start gap-4 p-4 rounded-lg bg-success/10 border border-success/20">
        <CheckCircle2 className="h-5 w-5 text-success shrink-0 mt-0.5" />
        <div>
          <h3 className="font-semibold text-success mb-1">Step 3: Action Steps</h3>
          <p className="text-sm text-muted-foreground">
            Review and select the recommended action steps. You can also add custom steps as needed.
          </p>
        </div>
      </div>

      {/* Recommended Steps */}
      <div className="space-y-3">
        <h4 className="font-semibold flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          Recommended Action Steps
        </h4>
        {actionSteps.filter(s => !s.isCustom).map((step) => (
          <div 
            key={step.id}
            className={cn(
              "p-4 rounded-lg border transition-all cursor-pointer",
              step.selected 
                ? "bg-primary/5 border-primary/30" 
                : "bg-card border-border hover:border-primary/20"
            )}
            onClick={() => toggleActionStep(step.id)}
          >
            <div className="flex items-start gap-3">
              <Checkbox 
                checked={step.selected}
                onCheckedChange={() => toggleActionStep(step.id)}
                className="mt-0.5"
              />
              <div className="flex-1">
                <p className="text-sm font-medium">{step.description}</p>
                {step.sourceUrl && (
                  <a 
                    href={step.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-primary hover:underline flex items-center gap-1 mt-1"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <ExternalLink className="h-3 w-3" />
                    View Source
                  </a>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Custom Steps */}
      {actionSteps.filter(s => s.isCustom).length > 0 && (
        <div className="space-y-3">
          <h4 className="font-semibold">Custom Action Steps</h4>
          {actionSteps.filter(s => s.isCustom).map((step) => (
            <div 
              key={step.id}
              className="p-4 rounded-lg bg-card border border-border flex items-start gap-3"
            >
              <Checkbox 
                checked={step.selected}
                onCheckedChange={() => toggleActionStep(step.id)}
                className="mt-0.5"
              />
              <p className="text-sm flex-1">{step.description}</p>
              <Button 
                variant="ghost" 
                size="icon"
                className="h-8 w-8 text-destructive hover:text-destructive"
                onClick={() => removeCustomStep(step.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      )}

      {/* Add Custom Step */}
      <div className="p-4 rounded-lg border border-dashed border-border">
        <h4 className="font-semibold mb-3 flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Add Custom Action Step
        </h4>
        <div className="flex gap-2">
          <Input
            placeholder="Enter action step description..."
            value={customStepDescription}
            onChange={(e) => setCustomStepDescription(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addCustomStep()}
          />
          <Button onClick={addCustomStep} disabled={!customStepDescription.trim()}>
            Add
          </Button>
        </div>
      </div>

      <div className="flex justify-between pt-4">
        <Button variant="outline" onClick={() => setCurrentStep(2)}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <Button 
          onClick={() => setCurrentStep(4)}
          disabled={!canProceedStep3}
          variant="hero"
        >
          Continue to Assignment
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-start gap-4 p-4 rounded-lg bg-info/10 border border-info/20">
        <User className="h-5 w-5 text-info shrink-0 mt-0.5" />
        <div>
          <h3 className="font-semibold text-info mb-1">Step 4: Assignment & Attachments</h3>
          <p className="text-sm text-muted-foreground">
            Assign the issue to a team member, set a due date, and attach any supporting documents.
          </p>
        </div>
      </div>

      {/* Summary */}
      <div className="p-4 rounded-lg bg-muted/50 border border-border">
        <h4 className="font-semibold mb-2">Issue Summary</h4>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div><span className="text-muted-foreground">Title:</span> {formData.title}</div>
          <div><span className="text-muted-foreground">Type:</span> {issueTypes.find(t => t.value === formData.issueType)?.label}</div>
          <div><span className="text-muted-foreground">Category:</span> {issueCategories.find(c => c.value === formData.issueCategory)?.label}</div>
          <div><span className="text-muted-foreground">Department:</span> {departments.find(d => d.value === formData.department)?.label}</div>
          <div><span className="text-muted-foreground">Action Steps:</span> {actionSteps.filter(s => s.selected).length} selected</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="assignedTo">Assign To</Label>
          <Input
            id="assignedTo"
            placeholder="Enter assignee name"
            value={formData.assignedTo}
            onChange={(e) => setFormData({ ...formData, assignedTo: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="dueDate">Due Date</Label>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              id="dueDate"
              type="date"
              className="pl-10"
              value={formData.dueDate}
              onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
            />
          </div>
        </div>
      </div>

      {/* Attachments */}
      <div className="space-y-2">
        <Label className="flex items-center gap-2">
          <Paperclip className="h-4 w-4" />
          Supporting Documents
        </Label>
        <p className="text-xs text-muted-foreground mb-2">
          Upload any relevant documents, photos, or evidence to support your report.
        </p>
        <AttachmentUploader
          attachments={attachments}
          onAttachmentsChange={setAttachments}
          stage="reported"
          uploadedBy={formData.reportedBy || 'Reporter'}
        />
      </div>

      {/* Cross-References */}
      <div className="space-y-2">
        <Label className="flex items-center gap-2">
          <Link2 className="h-4 w-4" />
          Related Items
        </Label>
        <p className="text-xs text-muted-foreground mb-2">
          Link this issue to related items from other modules (RiskGuard, AuditPro, etc.).
        </p>
        <ConnectionsPanel
          sourceType="complianceconnect"
          sourceId="new-issue"
        />
      </div>

      <div className="flex justify-between pt-4 border-t border-border">
        <Button variant="outline" onClick={() => setCurrentStep(3)}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <Button 
          onClick={handleSubmit}
          disabled={isSubmitting}
          variant="hero"
        >
          {isSubmitting ? (
            <>Submitting...</>
          ) : (
            <>
              <Send className="h-4 w-4 mr-2" />
              Submit Issue
            </>
          )}
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen">
      <Header 
        title="Report Compliance Issue" 
        subtitle="Submit a new compliance concern" 
      />

      <div className="p-6 max-w-3xl mx-auto">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate('/compliance')}
          className="mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>

        <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
          {renderStepIndicator()}
          
          {currentStep === 1 && renderStep1()}
          {currentStep === 2 && renderStep2()}
          {currentStep === 3 && renderStep3()}
          {currentStep === 4 && renderStep4()}
        </div>
      </div>
    </div>
  );
}
