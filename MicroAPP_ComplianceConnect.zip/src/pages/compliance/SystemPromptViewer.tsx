import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Printer, Copy, Check } from "lucide-react";
import { toast } from "sonner";

const SystemPromptViewer = () => {
  const [content, setContent] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetch("/docs/SystemPrompt-AITesting.md")
      .then((res) => res.text())
      .then((text) => {
        setContent(text);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to load system prompt:", err);
        setLoading(false);
      });
  }, []);

  const handlePrint = () => {
    window.print();
  };

  const handleCopyPrompt = () => {
    const promptMatch = content.match(/```\n(You are an AI QA Testing Agent[\s\S]*?)```/);
    if (promptMatch) {
      navigator.clipboard.writeText(promptMatch[1].trim());
      setCopied(true);
      toast.success("System prompt copied to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const renderMarkdown = (text: string) => {
    const lines = text.split("\n");
    const elements: JSX.Element[] = [];
    let inCodeBlock = false;
    let codeContent: string[] = [];

    lines.forEach((line, index) => {
      if (line.startsWith("```")) {
        if (inCodeBlock) {
          elements.push(
            <pre
              key={`code-${index}`}
              className="bg-muted p-4 rounded-lg overflow-x-auto my-4 text-sm font-mono whitespace-pre-wrap"
            >
              <code>{codeContent.join("\n")}</code>
            </pre>
          );
          codeContent = [];
          inCodeBlock = false;
        } else {
          inCodeBlock = true;
        }
        return;
      }

      if (inCodeBlock) {
        codeContent.push(line);
        return;
      }

      if (line.startsWith("# ")) {
        elements.push(
          <h1 key={index} className="text-3xl font-bold mt-8 mb-4 text-foreground">
            {line.slice(2)}
          </h1>
        );
      } else if (line.startsWith("## ")) {
        elements.push(
          <h2 key={index} className="text-2xl font-semibold mt-6 mb-3 text-foreground border-b pb-2">
            {line.slice(3)}
          </h2>
        );
      } else if (line.startsWith("### ")) {
        elements.push(
          <h3 key={index} className="text-xl font-medium mt-4 mb-2 text-foreground">
            {line.slice(4)}
          </h3>
        );
      } else if (line.startsWith("#### ")) {
        elements.push(
          <h4 key={index} className="text-lg font-medium mt-3 mb-2 text-foreground">
            {line.slice(5)}
          </h4>
        );
      } else if (line.startsWith("- ")) {
        elements.push(
          <li key={index} className="ml-6 mb-1 text-muted-foreground list-disc">
            {line.slice(2)}
          </li>
        );
      } else if (line.match(/^\d+\. /)) {
        elements.push(
          <li key={index} className="ml-6 mb-1 text-muted-foreground list-decimal">
            {line.replace(/^\d+\. /, "")}
          </li>
        );
      } else if (line.startsWith("---")) {
        elements.push(<hr key={index} className="my-6 border-border" />);
      } else if (line.startsWith("|")) {
        const cells = line.split("|").filter((c) => c.trim());
        if (!line.includes("---")) {
          elements.push(
            <tr key={index} className="border-b border-border">
              {cells.map((cell, i) => (
                <td key={i} className="px-4 py-2 text-muted-foreground">
                  {cell.trim()}
                </td>
              ))}
            </tr>
          );
        }
      } else if (line.trim()) {
        const formattedLine = line
          .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
          .replace(/`(.*?)`/g, '<code class="bg-muted px-1 rounded text-sm">$1</code>');
        elements.push(
          <p
            key={index}
            className="mb-2 text-muted-foreground leading-relaxed"
            dangerouslySetInnerHTML={{ __html: formattedLine }}
          />
        );
      }
    });

    return elements;
  };

  return (
    <div className="space-y-6 print:space-y-4">
      <div className="flex justify-between items-center print:hidden">
        <div>
          <h1 className="text-2xl font-bold text-foreground">AI Testing System Prompt</h1>
          <p className="text-muted-foreground">
            System prompt for configuring AI agents to execute test cases
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleCopyPrompt}>
            {copied ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
            {copied ? "Copied!" : "Copy Prompt"}
          </Button>
          <Button variant="outline" onClick={handlePrint}>
            <Printer className="h-4 w-4 mr-2" />
            Print / Save PDF
          </Button>
        </div>
      </div>

      <Card className="print:shadow-none print:border-none">
        <CardHeader className="print:pb-2">
          <CardTitle className="print:text-xl">System Prompt Document</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="prose prose-sm max-w-none dark:prose-invert">
              {renderMarkdown(content)}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default SystemPromptViewer;
