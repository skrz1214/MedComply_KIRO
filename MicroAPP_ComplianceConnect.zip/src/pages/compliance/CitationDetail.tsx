import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Header } from '@/components/compliance/Header';
import { ConnectionsPanel } from '@/components/compliance/ConnectionsPanel';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { toast } from '@/hooks/use-toast';
import { mockCitations, mockIssues, mockCapas } from '@/data/mockData';
import { 
  Citation, 
  EvidenceExpectation, 
  CitationMapping, 
  RemediationStep,
  EvidenceType,
  EvidenceFrequency,
  MappingTarget,
  MappingStrength,
  UserRole,
  SensitivityTag
} from '@/types/compliance';
import { 
  ArrowLeft, 
  Calendar, 
  Building2, 
  AlertTriangle,
  Plus,
  Edit,
  Trash2,
  FileText,
  Link2,
  History,
  ExternalLink,
  Shield,
  Copy,
  Archive,
  Download,
  CheckCircle2,
  ListChecks,
  ClipboardList,
  Wrench,
  BookOpen,
  RefreshCw,
  RotateCcw,
  AlertCircle,
  UserPlus,
  User
} from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const evidenceTypes: { value: EvidenceType; label: string }[] = [
  { value: 'policy', label: 'Policy' },
  { value: 'procedure', label: 'Procedure' },
  { value: 'training_record', label: 'Training Record' },
  { value: 'audit_result', label: 'Audit Result' },
  { value: 'log', label: 'Log' },
  { value: 'screenshot', label: 'Screenshot' },
  { value: 'report', label: 'Report' },
  { value: 'credentialing', label: 'Credentialing' },
  { value: 'consent', label: 'Consent' },
  { value: 'other', label: 'Other' },
];

const frequencies: { value: EvidenceFrequency; label: string }[] = [
  { value: 'one_time', label: 'One Time' },
  { value: 'monthly', label: 'Monthly' },
  { value: 'quarterly', label: 'Quarterly' },
  { value: 'annual', label: 'Annual' },
  { value: 'per_event', label: 'Per Event' },
];

const mappingTargets: { value: MappingTarget; label: string }[] = [
  { value: 'policy', label: 'Policy' },
  { value: 'procedure', label: 'Procedure' },
  { value: 'control', label: 'Control' },
  { value: 'training', label: 'Training' },
  { value: 'audit_checklist', label: 'Audit Checklist' },
];

const mappingStrengths: { value: MappingStrength; label: string }[] = [
  { value: 'strong', label: 'Strong' },
  { value: 'medium', label: 'Medium' },
  { value: 'weak', label: 'Weak' },
];

const ownerRoles: { value: UserRole; label: string }[] = [
  { value: 'super_admin', label: 'Super Admin' },
  { value: 'org_admin', label: 'Org Admin' },
  { value: 'compliance_manager', label: 'Compliance Manager' },
  { value: 'department_head', label: 'Department Head' },
  { value: 'qa_reviewer', label: 'QA Reviewer' },
  { value: 'contributor', label: 'Contributor' },
  { value: 'reporter', label: 'Reporter' },
];

const sensitivityTags: { value: SensitivityTag | 'none_tag'; label: string }[] = [
  { value: 'none_tag', label: 'None' },
  { value: 'phi', label: 'PHI' },
  { value: 'pii', label: 'PII' },
  { value: 'confidential', label: 'Confidential' },
  { value: 'internal', label: 'Internal' },
  { value: 'public', label: 'Public' },
];

export default function CitationDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [citation, setCitation] = useState<Citation | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editForm, setEditForm] = useState<{
    title: string;
    citationCode: string;
    fullText: string;
    interpretationNotes: string;
    source: string;
    jurisdiction: string;
    facilityType: string;
    riskDomain: string;
    status: string;
    tags: string[];
    references: string[];
  }>({
    title: '',
    citationCode: '',
    fullText: '',
    interpretationNotes: '',
    source: '',
    jurisdiction: '',
    facilityType: '',
    riskDomain: '',
    status: '',
    tags: [],
    references: []
  });
  const [editTagInput, setEditTagInput] = useState('');
  const [editRefInput, setEditRefInput] = useState('');
  
  // Evidence Expectation Dialog State
  const [showEvidenceDialog, setShowEvidenceDialog] = useState(false);
  const [editingEvidence, setEditingEvidence] = useState<EvidenceExpectation | null>(null);
  const [evidenceForm, setEvidenceForm] = useState<Partial<EvidenceExpectation>>({
    evidenceType: 'policy',
    description: '',
    frequency: 'annual',
    ownerRole: 'compliance_manager',
    sampleArtifacts: '',
    sensitivityTag: undefined
  });

  // Mapping Dialog State
  const [showMappingDialog, setShowMappingDialog] = useState(false);
  const [editingMapping, setEditingMapping] = useState<CitationMapping | null>(null);
  const [mappingForm, setMappingForm] = useState<Partial<CitationMapping>>({
    mapsTo: 'policy',
    mappedItemName: '',
    mappingStrength: 'medium',
    notes: ''
  });

  // Remediation Dialog State
  const [showRemediationDialog, setShowRemediationDialog] = useState(false);
  const [editingRemediation, setEditingRemediation] = useState<RemediationStep | null>(null);
  const [remediationForm, setRemediationForm] = useState<Partial<RemediationStep>>({
    description: '',
    sourceUrl: '',
    defaultOwnerRole: 'compliance_manager',
    defaultDueInDays: 30
  });

  // Assign for Review State
  const [showAssignReviewDialog, setShowAssignReviewDialog] = useState(false);
  const [selectedReviewer, setSelectedReviewer] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [reviewNotes, setReviewNotes] = useState('');
  const [assignedReviewer, setAssignedReviewer] = useState<{ name: string; department?: string; assignedAt: Date } | null>(null);

  // Mock reviewers list
  const mockReviewers = [
    { id: 'user-1', name: 'Dr. Sarah Chen', role: 'Compliance Manager' },
    { id: 'user-2', name: 'Michael Rodriguez', role: 'QA Reviewer' },
    { id: 'user-3', name: 'Jennifer Walsh', role: 'Department Head' },
    { id: 'user-4', name: 'David Thompson', role: 'Compliance Manager' },
  ];

  // Mock departments list
  const mockDepartments = [
    { id: 'dept-1', name: 'Nursing' },
    { id: 'dept-2', name: 'Pharmacy' },
    { id: 'dept-3', name: 'Laboratory' },
    { id: 'dept-4', name: 'Radiology' },
    { id: 'dept-5', name: 'Emergency' },
    { id: 'dept-6', name: 'Surgery' },
    { id: 'dept-7', name: 'Compliance' },
  ];

  useEffect(() => {
    const foundCitation = mockCitations.find(c => c.id === id);
    if (foundCitation) {
      setCitation({ ...foundCitation });
    }
  }, [id]);

  if (!citation) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Citation not found</p>
      </div>
    );
  }

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400';
      case 'draft': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400';
      case 'deprecated': return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400';
      case 'superseded': return 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getSourceBadgeColor = (source: string) => {
    switch (source) {
      case 'cms': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400';
      case 'joint_commission': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400';
      case 'state_doh': return 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400';
      case 'hipaa': return 'bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-400';
      case 'osha': return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const linkedIssues = mockIssues.filter(i => citation.linkedIssueIds?.includes(i.id));
  const linkedCapas = mockCapas.filter(c => citation.linkedCapaIds?.includes(c.id));

  // Evidence Expectation handlers
  const openAddEvidence = () => {
    setEditingEvidence(null);
    setEvidenceForm({
      evidenceType: 'policy',
      description: '',
      frequency: 'annual',
      ownerRole: 'compliance_manager',
      sampleArtifacts: '',
      sensitivityTag: undefined
    });
    setShowEvidenceDialog(true);
  };

  const openEditEvidence = (evidence: EvidenceExpectation) => {
    setEditingEvidence(evidence);
    setEvidenceForm({ ...evidence });
    setShowEvidenceDialog(true);
  };

  const handleSaveEvidence = () => {
    if (!evidenceForm.description) {
      toast({ title: 'Error', description: 'Description is required', variant: 'destructive' });
      return;
    }

    if (editingEvidence) {
      // Update existing
      setCitation(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          evidenceExpectations: prev.evidenceExpectations.map(ee =>
            ee.id === editingEvidence.id ? { ...ee, ...evidenceForm } : ee
          )
        };
      });
      toast({ title: 'Success', description: 'Evidence expectation updated' });
    } else {
      // Add new
      const newEvidence: EvidenceExpectation = {
        id: `ee-${Date.now()}`,
        evidenceType: evidenceForm.evidenceType as EvidenceType,
        description: evidenceForm.description!,
        frequency: evidenceForm.frequency as EvidenceFrequency,
        ownerRole: evidenceForm.ownerRole as UserRole,
        sampleArtifacts: evidenceForm.sampleArtifacts,
        sensitivityTag: evidenceForm.sensitivityTag as SensitivityTag
      };
      setCitation(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          evidenceExpectations: [...prev.evidenceExpectations, newEvidence]
        };
      });
      toast({ title: 'Success', description: 'Evidence expectation added' });
    }
    setShowEvidenceDialog(false);
  };

  const handleDeleteEvidence = (evidenceId: string) => {
    setCitation(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        evidenceExpectations: prev.evidenceExpectations.filter(ee => ee.id !== evidenceId)
      };
    });
    toast({ title: 'Deleted', description: 'Evidence expectation removed' });
  };

  // Mapping handlers
  const openAddMapping = () => {
    setEditingMapping(null);
    setMappingForm({
      mapsTo: 'policy',
      mappedItemName: '',
      mappingStrength: 'medium',
      notes: ''
    });
    setShowMappingDialog(true);
  };

  const openEditMapping = (mapping: CitationMapping) => {
    setEditingMapping(mapping);
    setMappingForm({ ...mapping });
    setShowMappingDialog(true);
  };

  const handleSaveMapping = () => {
    if (!mappingForm.mappedItemName) {
      toast({ title: 'Error', description: 'Item name is required', variant: 'destructive' });
      return;
    }

    if (editingMapping) {
      setCitation(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          mappings: prev.mappings.map(m =>
            m.id === editingMapping.id ? { ...m, ...mappingForm } : m
          )
        };
      });
      toast({ title: 'Success', description: 'Mapping updated' });
    } else {
      const newMapping: CitationMapping = {
        id: `map-${Date.now()}`,
        mapsTo: mappingForm.mapsTo as MappingTarget,
        mappedItemName: mappingForm.mappedItemName!,
        mappingStrength: mappingForm.mappingStrength as MappingStrength,
        notes: mappingForm.notes,
        lastReviewedDate: new Date()
      };
      setCitation(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          mappings: [...prev.mappings, newMapping]
        };
      });
      toast({ title: 'Success', description: 'Mapping added' });
    }
    setShowMappingDialog(false);
  };

  const handleDeleteMapping = (mappingId: string) => {
    setCitation(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        mappings: prev.mappings.filter(m => m.id !== mappingId)
      };
    });
    toast({ title: 'Deleted', description: 'Mapping removed' });
  };

  // Remediation handlers
  const openAddRemediation = () => {
    setEditingRemediation(null);
    setRemediationForm({
      description: '',
      sourceUrl: '',
      defaultOwnerRole: 'compliance_manager',
      defaultDueInDays: 30
    });
    setShowRemediationDialog(true);
  };

  const openEditRemediation = (step: RemediationStep) => {
    setEditingRemediation(step);
    setRemediationForm({ ...step });
    setShowRemediationDialog(true);
  };

  const handleSaveRemediation = () => {
    if (!remediationForm.description) {
      toast({ title: 'Error', description: 'Description is required', variant: 'destructive' });
      return;
    }

    if (editingRemediation) {
      setCitation(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          remediationSteps: prev.remediationSteps.map(r =>
            r.id === editingRemediation.id ? { ...r, ...remediationForm } : r
          )
        };
      });
      toast({ title: 'Success', description: 'Remediation step updated' });
    } else {
      const newStep: RemediationStep = {
        id: `rem-${Date.now()}`,
        description: remediationForm.description!,
        sourceUrl: remediationForm.sourceUrl,
        defaultOwnerRole: remediationForm.defaultOwnerRole as UserRole,
        defaultDueInDays: remediationForm.defaultDueInDays
      };
      setCitation(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          remediationSteps: [...prev.remediationSteps, newStep]
        };
      });
      toast({ title: 'Success', description: 'Remediation step added' });
    }
    setShowRemediationDialog(false);
  };

  const handleDeleteRemediation = (stepId: string) => {
    setCitation(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        remediationSteps: prev.remediationSteps.filter(r => r.id !== stepId)
      };
    });
    toast({ title: 'Deleted', description: 'Remediation step removed' });
  };

  // Citation status handlers
  const handleReactivate = () => {
    setCitation(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        status: 'active',
        auditLog: [...prev.auditLog, {
          id: `al-${Date.now()}`,
          action: 'Re-activated from Deprecated status',
          performedBy: 'Current User',
          performedAt: new Date()
        }]
      };
    });
    toast({ title: 'Citation Re-activated', description: 'This citation is now active again' });
  };

  const handleDeprecate = () => {
    setCitation(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        status: 'deprecated',
        auditLog: [...prev.auditLog, {
          id: `al-${Date.now()}`,
          action: 'Deprecated',
          performedBy: 'Current User',
          performedAt: new Date()
        }]
      };
    });
    toast({ title: 'Citation Deprecated', description: 'This citation has been marked as deprecated' });
  };

  const handleDelete = () => {
    toast({ title: 'Citation Deleted', description: 'This citation has been permanently removed' });
    navigate('/citations');
  };

  const handleActivate = () => {
    setCitation(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        status: 'active',
        auditLog: [...prev.auditLog, {
          id: `al-${Date.now()}`,
          action: 'Activated from Draft status',
          performedBy: 'Current User',
          performedAt: new Date()
        }]
      };
    });
    toast({ title: 'Citation Activated', description: 'This citation is now active' });
  };

  // Edit and Duplicate handlers
  const openEditDialog = () => {
    if (!citation) return;
    setEditForm({
      title: citation.title,
      citationCode: citation.citationCode,
      fullText: citation.fullText,
      interpretationNotes: citation.interpretationNotes || '',
      source: citation.source,
      jurisdiction: citation.jurisdiction,
      facilityType: citation.facilityType,
      riskDomain: citation.riskDomain,
      status: citation.status,
      tags: [...citation.tags],
      references: [...citation.references]
    });
    setEditTagInput('');
    setEditRefInput('');
    setShowEditDialog(true);
  };

  const handleSaveEdit = () => {
    setCitation(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        title: editForm.title,
        citationCode: editForm.citationCode,
        fullText: editForm.fullText,
        interpretationNotes: editForm.interpretationNotes,
        source: editForm.source as any,
        jurisdiction: editForm.jurisdiction as any,
        facilityType: editForm.facilityType as any,
        riskDomain: editForm.riskDomain as any,
        status: editForm.status as any,
        tags: editForm.tags,
        references: editForm.references,
        updatedAt: new Date(),
        auditLog: [...prev.auditLog, {
          id: `al-${Date.now()}`,
          action: 'Citation details updated',
          performedBy: 'Current User',
          performedAt: new Date()
        }]
      };
    });
    setShowEditDialog(false);
    toast({ title: 'Citation Updated', description: 'Changes saved successfully' });
  };

  const handleEditAddTag = () => {
    if (editTagInput.trim() && !editForm.tags.includes(editTagInput.trim())) {
      setEditForm({ ...editForm, tags: [...editForm.tags, editTagInput.trim()] });
      setEditTagInput('');
    }
  };

  const handleEditRemoveTag = (tag: string) => {
    setEditForm({ ...editForm, tags: editForm.tags.filter(t => t !== tag) });
  };

  const handleEditAddRef = () => {
    if (editRefInput.trim() && !editForm.references.includes(editRefInput.trim())) {
      try {
        new URL(editRefInput.trim());
        setEditForm({ ...editForm, references: [...editForm.references, editRefInput.trim()] });
        setEditRefInput('');
      } catch {
        toast({ title: 'Invalid URL', description: 'Please enter a valid URL', variant: 'destructive' });
      }
    }
  };

  const handleEditRemoveRef = (ref: string) => {
    setEditForm({ ...editForm, references: editForm.references.filter(r => r !== ref) });
  };

  const handleDuplicate = () => {
    if (!citation) return;
    const newId = `CIT-${Date.now()}`;
    toast({ 
      title: 'Citation Duplicated', 
      description: `New citation ${newId} created as draft. Redirecting...` 
    });
    // In a real app, this would create the citation in the database
    // For now, navigate to the new citation (mock behavior)
    setTimeout(() => {
      navigate(`/citations/new?duplicate=${citation.id}`);
    }, 1000);
  };

  const handleAssignForReview = () => {
    if (!selectedReviewer) {
      toast({ title: 'Select Reviewer', description: 'Please select a reviewer', variant: 'destructive' });
      return;
    }
    const reviewer = mockReviewers.find(r => r.id === selectedReviewer);
    const department = mockDepartments.find(d => d.id === selectedDepartment);
    if (reviewer) {
      setAssignedReviewer({ 
        name: reviewer.name, 
        department: department?.name,
        assignedAt: new Date() 
      });
      toast({ 
        title: 'Assigned for Review', 
        description: `Citation assigned to ${reviewer.name}${department ? ` (${department.name})` : ''} for final review` 
      });
    }
    setShowAssignReviewDialog(false);
    setSelectedReviewer('');
    setSelectedDepartment('');
    setReviewNotes('');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header title="Citation Library" subtitle="View and manage citation details" />
      
      <main className="container mx-auto px-6 py-6">
        {/* Back button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate('/citations')}
          className="mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Citations
        </Button>

        <div className="flex gap-6">
          {/* Main Content */}
          <div className="flex-1">
            {/* Header Card */}
            <Card className="mb-6">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge className={getSourceBadgeColor(citation.source)}>
                        {citation.source.toUpperCase().replace('_', ' ')}
                      </Badge>
                      <Badge className={getStatusBadgeColor(citation.status)}>
                        {citation.status}
                      </Badge>
                      <Badge variant="outline">{citation.riskDomain.replace('_', ' ')}</Badge>
                    </div>
                    <CardTitle className="text-2xl">{citation.citationCode}</CardTitle>
                    <CardDescription className="text-lg">{citation.title}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Jurisdiction</span>
                    <p className="font-medium capitalize">{citation.jurisdiction}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Facility Type</span>
                    <p className="font-medium capitalize">{citation.facilityType.replace('_', ' ')}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Effective Date</span>
                    <p className="font-medium">{format(new Date(citation.effectiveDate), 'MMM d, yyyy')}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Version</span>
                    <p className="font-medium">v{citation.version}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tabs */}
            <Tabs defaultValue="overview" className="space-y-4">
              <TabsList className="grid grid-cols-7 w-full">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="text">Citation Text</TabsTrigger>
                <TabsTrigger value="evidence">Evidence ({citation.evidenceExpectations.length})</TabsTrigger>
                <TabsTrigger value="mappings">Mappings ({citation.mappings.length})</TabsTrigger>
                <TabsTrigger value="remediation">Remediation ({citation.remediationSteps.length})</TabsTrigger>
                <TabsTrigger value="linked">Linked Work</TabsTrigger>
                <TabsTrigger value="history">History</TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Citation Overview</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <h4 className="font-medium mb-2">Full Text</h4>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap bg-muted/50 p-4 rounded-lg">
                        {citation.fullText}
                      </p>
                    </div>
                    {citation.interpretationNotes && (
                      <div>
                        <h4 className="font-medium mb-2">Interpretation Notes</h4>
                        <p className="text-sm text-muted-foreground">{citation.interpretationNotes}</p>
                      </div>
                    )}
                    {citation.references.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-2">References</h4>
                        <ul className="text-sm space-y-1">
                          {citation.references.map((ref, i) => (
                            <li key={i} className="flex items-center gap-2">
                              <ExternalLink className="h-3 w-3" />
                              <a href={ref} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                                {ref}
                              </a>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {citation.tags.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-2">Tags</h4>
                        <div className="flex flex-wrap gap-2">
                          {citation.tags.map(tag => (
                            <Badge key={tag} variant="secondary">{tag}</Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Citation Text Tab */}
              <TabsContent value="text">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <BookOpen className="h-5 w-5" />
                      Full Citation Text
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-muted/50 p-6 rounded-lg">
                      <p className="text-sm whitespace-pre-wrap leading-relaxed">
                        {citation.fullText}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Evidence Expectations Tab */}
              <TabsContent value="evidence">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <ListChecks className="h-5 w-5" />
                        Evidence Expectations
                      </CardTitle>
                      <CardDescription>Define what evidence is required to demonstrate compliance</CardDescription>
                    </div>
                    <Button onClick={openAddEvidence}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Evidence Expectation
                    </Button>
                  </CardHeader>
                  <CardContent>
                    {citation.evidenceExpectations.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <ListChecks className="h-12 w-12 mx-auto mb-3 opacity-50" />
                        <p>No evidence expectations defined yet</p>
                        <p className="text-sm">Add evidence expectations to specify what proof is needed for compliance</p>
                      </div>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Type</TableHead>
                            <TableHead className="w-[40%]">Description</TableHead>
                            <TableHead>Frequency</TableHead>
                            <TableHead>Owner</TableHead>
                            <TableHead>Sensitivity</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {citation.evidenceExpectations.map((ee) => (
                            <TableRow key={ee.id}>
                              <TableCell>
                                <Badge variant="outline" className="capitalize">
                                  {ee.evidenceType.replace('_', ' ')}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-sm">{ee.description}</TableCell>
                              <TableCell className="capitalize">{ee.frequency.replace('_', ' ')}</TableCell>
                              <TableCell className="capitalize text-sm">
                                {ee.ownerRole?.replace('_', ' ') || '-'}
                              </TableCell>
                              <TableCell>
                                {ee.sensitivityTag && (
                                  <Badge variant="destructive" className="text-xs">
                                    {ee.sensitivityTag.toUpperCase()}
                                  </Badge>
                                )}
                              </TableCell>
                              <TableCell className="text-right">
                                <Button variant="ghost" size="sm" onClick={() => openEditEvidence(ee)}>
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm" onClick={() => handleDeleteEvidence(ee.id)}>
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Mappings Tab */}
              <TabsContent value="mappings">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Link2 className="h-5 w-5" />
                        Citation Mappings
                      </CardTitle>
                      <CardDescription>Map this citation to policies, controls, training, and checklists</CardDescription>
                    </div>
                    <Button onClick={openAddMapping}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Mapping
                    </Button>
                  </CardHeader>
                  <CardContent>
                    {citation.mappings.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <Link2 className="h-12 w-12 mx-auto mb-3 opacity-50" />
                        <p>No mappings defined yet</p>
                        <p className="text-sm">Link this citation to internal policies, controls, or training</p>
                      </div>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Maps To</TableHead>
                            <TableHead className="w-[40%]">Item Name</TableHead>
                            <TableHead>Strength</TableHead>
                            <TableHead>Notes</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {citation.mappings.map((mapping) => (
                            <TableRow key={mapping.id}>
                              <TableCell>
                                <Badge variant="outline" className="capitalize">
                                  {mapping.mapsTo.replace('_', ' ')}
                                </Badge>
                              </TableCell>
                              <TableCell className="font-medium">{mapping.mappedItemName}</TableCell>
                              <TableCell>
                                <Badge className={cn(
                                  mapping.mappingStrength === 'strong' && 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
                                  mapping.mappingStrength === 'medium' && 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
                                  mapping.mappingStrength === 'weak' && 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                                )}>
                                  {mapping.mappingStrength}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-sm text-muted-foreground">{mapping.notes || '-'}</TableCell>
                              <TableCell className="text-right">
                                <Button variant="ghost" size="sm" onClick={() => openEditMapping(mapping)}>
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm" onClick={() => handleDeleteMapping(mapping.id)}>
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Remediation Steps Tab */}
              <TabsContent value="remediation">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Wrench className="h-5 w-5" />
                        Remediation Steps
                      </CardTitle>
                      <CardDescription>Recommended actions when this citation is found deficient</CardDescription>
                    </div>
                    <Button onClick={openAddRemediation}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Remediation Step
                    </Button>
                  </CardHeader>
                  <CardContent>
                    {citation.remediationSteps.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <Wrench className="h-12 w-12 mx-auto mb-3 opacity-50" />
                        <p>No remediation steps defined yet</p>
                        <p className="text-sm">Add recommended actions to address deficiencies</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {citation.remediationSteps.map((step, index) => (
                          <div key={step.id} className="flex items-start gap-4 p-4 border rounded-lg bg-card">
                            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-semibold shrink-0">
                              {index + 1}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm">{step.description}</p>
                              <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                                {step.sourceUrl && (
                                  <a href={step.sourceUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-primary hover:underline">
                                    <ExternalLink className="h-3 w-3" />
                                    Source
                                  </a>
                                )}
                                {step.defaultOwnerRole && (
                                  <span className="capitalize">Owner: {step.defaultOwnerRole.replace('_', ' ')}</span>
                                )}
                                {step.defaultDueInDays && (
                                  <span>Due in: {step.defaultDueInDays} days</span>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-1 shrink-0">
                              <Button variant="ghost" size="sm" onClick={() => openEditRemediation(step)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm" onClick={() => handleDeleteRemediation(step.id)}>
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Linked Work Tab */}
              <TabsContent value="linked">
                <div className="grid gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Linked Issues ({linkedIssues.length})</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {linkedIssues.length === 0 ? (
                        <p className="text-sm text-muted-foreground">No linked issues</p>
                      ) : (
                        <div className="space-y-2">
                          {linkedIssues.map(issue => (
                            <div key={issue.id} className="flex items-center justify-between p-3 border rounded-lg">
                              <div>
                                <p className="font-medium">{issue.title}</p>
                                <p className="text-sm text-muted-foreground">{issue.status}</p>
                              </div>
                              <Button variant="ghost" size="sm" onClick={() => navigate(`/issues/${issue.id}`)}>
                                View
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Linked CAPAs ({linkedCapas.length})</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {linkedCapas.length === 0 ? (
                        <p className="text-sm text-muted-foreground">No linked CAPAs</p>
                      ) : (
                        <div className="space-y-2">
                          {linkedCapas.map(capa => (
                            <div key={capa.id} className="flex items-center justify-between p-3 border rounded-lg">
                              <div>
                                <p className="font-medium">{capa.title}</p>
                                <p className="text-sm text-muted-foreground">{capa.status}</p>
                              </div>
                              <Button variant="ghost" size="sm" onClick={() => navigate(`/actionguard/${capa.id}`)}>
                                View
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* History Tab */}
              <TabsContent value="history">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <History className="h-5 w-5" />
                      Audit History
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {citation.auditLog.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-8">No audit history available</p>
                    ) : (
                      <div className="space-y-3">
                        {citation.auditLog.map((entry, i) => (
                          <div key={i} className="flex items-start gap-3 p-3 border rounded-lg">
                            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                              <History className="h-4 w-4" />
                            </div>
                            <div className="flex-1">
                              <p className="text-sm font-medium">{entry.action}</p>
                              <p className="text-xs text-muted-foreground">
                                {entry.performedBy} • {format(new Date(entry.performedAt), 'MMM d, yyyy h:mm a')}
                              </p>
                              {entry.details && (
                                <p className="text-sm text-muted-foreground mt-1">{entry.details}</p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Right Action Rail */}
          <div className="w-80 shrink-0 space-y-4">
            {/* Deprecated Warning Banner */}
            {citation.status === 'deprecated' && (
              <Card className="border-destructive/50 bg-destructive/5">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-destructive">Deprecated Citation</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        This citation is no longer in use. You can re-activate it or permanently delete it.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Draft Warning Banner */}
            {citation.status === 'draft' && (
              <Card className="border-warning/50 bg-warning/5">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 text-warning shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-warning-foreground">Draft Citation</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        This citation is in draft. Activate it when ready for use.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {/* Common actions */}
                <Button 
                  variant="outline" 
                  className="w-full justify-start" 
                  size="sm"
                  onClick={openEditDialog}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Citation
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start" 
                  size="sm"
                  onClick={handleDuplicate}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Duplicate
                </Button>
                
                {/* Status-specific actions */}
                {citation.status === 'deprecated' && (
                  <>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start text-green-600 hover:text-green-700 hover:bg-green-50" 
                      size="sm"
                      onClick={handleReactivate}
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Re-activate Citation
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10" 
                      size="sm"
                      onClick={() => setShowDeleteDialog(true)}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete Permanently
                    </Button>
                  </>
                )}

                {citation.status === 'draft' && (
                  <>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start text-blue-600 hover:text-blue-700 hover:bg-blue-50" 
                      size="sm"
                      onClick={() => setShowAssignReviewDialog(true)}
                    >
                      <UserPlus className="h-4 w-4 mr-2" />
                      Assign for Review
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start text-green-600 hover:text-green-700 hover:bg-green-50" 
                      size="sm"
                      onClick={handleActivate}
                    >
                      <CheckCircle2 className="h-4 w-4 mr-2" />
                      Activate Citation
                    </Button>
                  </>
                )}

                {citation.status === 'active' && (
                  <Button 
                    variant="outline" 
                    className="w-full justify-start" 
                    size="sm"
                    onClick={handleDeprecate}
                  >
                    <Archive className="h-4 w-4 mr-2" />
                    Deprecate
                  </Button>
                )}

                <Button 
                  variant="outline" 
                  className="w-full justify-start" 
                  size="sm"
                  onClick={() => {
                    if (!citation) return;
                    const exportData = JSON.stringify(citation, null, 2);
                    const blob = new Blob([exportData], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `${citation.citationCode}-export.json`;
                    a.click();
                    URL.revokeObjectURL(url);
                    toast({ title: 'Citation Exported', description: `${citation.citationCode} exported as JSON` });
                  }}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Evidence Expectations</span>
                  <span className="font-medium">{citation.evidenceExpectations.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Mappings</span>
                  <span className="font-medium">{citation.mappings.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Remediation Steps</span>
                  <span className="font-medium">{citation.remediationSteps.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Linked Issues</span>
                  <span className="font-medium">{linkedIssues.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Linked CAPAs</span>
                  <span className="font-medium">{linkedCapas.length}</span>
                </div>
                {assignedReviewer && citation.status === 'draft' && (
                  <div className="pt-3 mt-3 border-t border-border">
                    <div className="flex items-center gap-2 text-blue-600">
                      <User className="h-4 w-4" />
                      <span className="font-medium text-sm">Assigned for Review</span>
                    </div>
                    <p className="text-sm mt-1">{assignedReviewer.name}</p>
                    {assignedReviewer.department && (
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Building2 className="h-3 w-3" />
                        {assignedReviewer.department}
                      </p>
                    )}
                    <p className="text-xs text-muted-foreground">
                      {format(assignedReviewer.assignedAt, 'MMM d, yyyy h:mm a')}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Evidence Expectation Dialog */}
      <Dialog open={showEvidenceDialog} onOpenChange={setShowEvidenceDialog}>
        <DialogContent className="max-w-lg bg-background">
          <DialogHeader>
            <DialogTitle>{editingEvidence ? 'Edit' : 'Add'} Evidence Expectation</DialogTitle>
            <DialogDescription>
              Define what evidence is needed to demonstrate compliance with this citation.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Evidence Type *</label>
              <Select
                value={evidenceForm.evidenceType}
                onValueChange={(v) => setEvidenceForm({ ...evidenceForm, evidenceType: v as EvidenceType })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-background z-50">
                  {evidenceTypes.map(t => (
                    <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Description *</label>
              <Textarea
                value={evidenceForm.description}
                onChange={(e) => setEvidenceForm({ ...evidenceForm, description: e.target.value })}
                placeholder="Describe the evidence required..."
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Frequency</label>
                <Select
                  value={evidenceForm.frequency}
                  onValueChange={(v) => setEvidenceForm({ ...evidenceForm, frequency: v as EvidenceFrequency })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    {frequencies.map(f => (
                      <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Owner Role</label>
                <Select
                  value={evidenceForm.ownerRole}
                  onValueChange={(v) => setEvidenceForm({ ...evidenceForm, ownerRole: v as UserRole })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    {ownerRoles.map(r => (
                      <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Sample Artifacts</label>
              <Input
                value={evidenceForm.sampleArtifacts || ''}
                onChange={(e) => setEvidenceForm({ ...evidenceForm, sampleArtifacts: e.target.value })}
                placeholder="e.g., Policy document, training certificate..."
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Sensitivity Tag</label>
              <Select
                value={evidenceForm.sensitivityTag}
                onValueChange={(v) => setEvidenceForm({ ...evidenceForm, sensitivityTag: v as SensitivityTag })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-background z-50">
                  {sensitivityTags.map(t => (
                    <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEvidenceDialog(false)}>Cancel</Button>
            <Button onClick={handleSaveEvidence}>
              {editingEvidence ? 'Update' : 'Add'} Evidence Expectation
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Mapping Dialog */}
      <Dialog open={showMappingDialog} onOpenChange={setShowMappingDialog}>
        <DialogContent className="max-w-lg bg-background">
          <DialogHeader>
            <DialogTitle>{editingMapping ? 'Edit' : 'Add'} Mapping</DialogTitle>
            <DialogDescription>
              Link this citation to internal policies, controls, training, or checklists.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Maps To *</label>
              <Select
                value={mappingForm.mapsTo}
                onValueChange={(v) => setMappingForm({ ...mappingForm, mapsTo: v as MappingTarget })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-background z-50">
                  {mappingTargets.map(t => (
                    <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Item Name *</label>
              <Input
                value={mappingForm.mappedItemName || ''}
                onChange={(e) => setMappingForm({ ...mappingForm, mappedItemName: e.target.value })}
                placeholder="e.g., Infection Control Policy v2.1"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Mapping Strength</label>
              <Select
                value={mappingForm.mappingStrength}
                onValueChange={(v) => setMappingForm({ ...mappingForm, mappingStrength: v as MappingStrength })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-background z-50">
                  {mappingStrengths.map(s => (
                    <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Notes</label>
              <Textarea
                value={mappingForm.notes || ''}
                onChange={(e) => setMappingForm({ ...mappingForm, notes: e.target.value })}
                placeholder="Additional notes about this mapping..."
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowMappingDialog(false)}>Cancel</Button>
            <Button onClick={handleSaveMapping}>
              {editingMapping ? 'Update' : 'Add'} Mapping
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Remediation Step Dialog */}
      <Dialog open={showRemediationDialog} onOpenChange={setShowRemediationDialog}>
        <DialogContent className="max-w-lg bg-background">
          <DialogHeader>
            <DialogTitle>{editingRemediation ? 'Edit' : 'Add'} Remediation Step</DialogTitle>
            <DialogDescription>
              Define recommended actions to address deficiencies related to this citation.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Description *</label>
              <Textarea
                value={remediationForm.description || ''}
                onChange={(e) => setRemediationForm({ ...remediationForm, description: e.target.value })}
                placeholder="Describe the remediation action..."
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Source URL</label>
              <Input
                value={remediationForm.sourceUrl || ''}
                onChange={(e) => setRemediationForm({ ...remediationForm, sourceUrl: e.target.value })}
                placeholder="https://example.com/guidance"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Default Owner</label>
                <Select
                  value={remediationForm.defaultOwnerRole}
                  onValueChange={(v) => setRemediationForm({ ...remediationForm, defaultOwnerRole: v as UserRole })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    {ownerRoles.map(r => (
                      <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Due In (Days)</label>
                <Input
                  type="number"
                  value={remediationForm.defaultDueInDays || ''}
                  onChange={(e) => setRemediationForm({ ...remediationForm, defaultDueInDays: parseInt(e.target.value) || undefined })}
                  placeholder="30"
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRemediationDialog(false)}>Cancel</Button>
            <Button onClick={handleSaveRemediation}>
              {editingRemediation ? 'Update' : 'Add'} Remediation Step
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent className="bg-background">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Citation Permanently?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the citation
              <strong className="text-foreground"> {citation.citationCode} - {citation.title}</strong> and
              remove all associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete Permanently
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Edit Citation Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-3xl bg-background max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Citation</DialogTitle>
            <DialogDescription>
              Update all citation details. Evidence expectations, mappings, and remediation steps can be edited in their respective tabs.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            {/* Basic Info */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Citation Code *</label>
                <Input
                  value={editForm.citationCode}
                  onChange={(e) => setEditForm({ ...editForm, citationCode: e.target.value })}
                  placeholder="e.g., F-tag 880"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Title *</label>
                <Input
                  value={editForm.title}
                  onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                  placeholder="Citation title"
                />
              </div>
            </div>

            {/* Classification */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Source</label>
                <Select
                  value={editForm.source}
                  onValueChange={(v) => setEditForm({ ...editForm, source: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="cms">CMS</SelectItem>
                    <SelectItem value="joint_commission">Joint Commission</SelectItem>
                    <SelectItem value="state_doh">State DOH</SelectItem>
                    <SelectItem value="hipaa">HIPAA</SelectItem>
                    <SelectItem value="osha">OSHA</SelectItem>
                    <SelectItem value="internal_policy">Internal Policy</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Jurisdiction</label>
                <Select
                  value={editForm.jurisdiction}
                  onValueChange={(v) => setEditForm({ ...editForm, jurisdiction: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="federal">Federal</SelectItem>
                    <SelectItem value="state">State</SelectItem>
                    <SelectItem value="local">Local</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Facility Type</label>
                <Select
                  value={editForm.facilityType}
                  onValueChange={(v) => setEditForm({ ...editForm, facilityType: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="hospital">Hospital</SelectItem>
                    <SelectItem value="nursing_home">Nursing Home</SelectItem>
                    <SelectItem value="clinic">Clinic</SelectItem>
                    <SelectItem value="pharmacy">Pharmacy</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Risk Domain</label>
                <Select
                  value={editForm.riskDomain}
                  onValueChange={(v) => setEditForm({ ...editForm, riskDomain: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="patient_safety">Patient Safety</SelectItem>
                    <SelectItem value="data_privacy">Data Privacy</SelectItem>
                    <SelectItem value="regulatory">Regulatory</SelectItem>
                    <SelectItem value="documentation">Documentation</SelectItem>
                    <SelectItem value="operational">Operational</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Text Content */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Full Text *</label>
              <Textarea
                value={editForm.fullText}
                onChange={(e) => setEditForm({ ...editForm, fullText: e.target.value })}
                placeholder="The full regulatory text..."
                rows={4}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Interpretation Notes</label>
              <Textarea
                value={editForm.interpretationNotes}
                onChange={(e) => setEditForm({ ...editForm, interpretationNotes: e.target.value })}
                placeholder="Additional guidance on interpretation and compliance..."
                rows={2}
              />
            </div>

            {/* References */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Reference URLs</label>
              <div className="flex gap-2">
                <Input
                  placeholder="https://example.com/regulation"
                  value={editRefInput}
                  onChange={(e) => setEditRefInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleEditAddRef())}
                />
                <Button type="button" variant="outline" onClick={handleEditAddRef}>
                  Add
                </Button>
              </div>
              {editForm.references.length > 0 && (
                <div className="space-y-2 mt-2">
                  {editForm.references.map((ref, index) => (
                    <div 
                      key={index} 
                      className="flex items-center gap-2 p-2 rounded-lg bg-muted/50 group"
                    >
                      <ExternalLink className="h-4 w-4 text-muted-foreground shrink-0" />
                      <span className="text-sm text-primary truncate flex-1">{ref}</span>
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="sm" 
                        className="opacity-0 group-hover:opacity-100 h-6 w-6 p-0"
                        onClick={() => handleEditRemoveRef(ref)}
                      >
                        ×
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Tags */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Tags</label>
              <div className="flex gap-2">
                <Input
                  placeholder="Add a tag..."
                  value={editTagInput}
                  onChange={(e) => setEditTagInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleEditAddTag())}
                />
                <Button type="button" variant="outline" onClick={handleEditAddTag}>
                  Add
                </Button>
              </div>
              {editForm.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {editForm.tags.map(tag => (
                    <Badge 
                      key={tag} 
                      variant="secondary"
                      className="cursor-pointer hover:bg-destructive/20"
                      onClick={() => handleEditRemoveTag(tag)}
                    >
                      {tag} ×
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>Cancel</Button>
            <Button onClick={handleSaveEdit} disabled={!editForm.title || !editForm.citationCode}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Assign for Review Dialog */}
      <Dialog open={showAssignReviewDialog} onOpenChange={setShowAssignReviewDialog}>
        <DialogContent className="bg-background">
          <DialogHeader>
            <DialogTitle>Assign Citation for Review</DialogTitle>
            <DialogDescription>
              Select a reviewer to finalize this citation before activating it.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Select Reviewer *</label>
              <Select value={selectedReviewer} onValueChange={setSelectedReviewer}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a reviewer" />
                </SelectTrigger>
                <SelectContent>
                  {mockReviewers.map((reviewer) => (
                    <SelectItem key={reviewer.id} value={reviewer.id}>
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <span>{reviewer.name}</span>
                        <span className="text-muted-foreground text-xs">({reviewer.role})</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Department (Optional)</label>
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {mockDepartments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id}>
                      <div className="flex items-center gap-2">
                        <Building2 className="h-4 w-4 text-muted-foreground" />
                        <span>{dept.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Review Notes (Optional)</label>
              <Textarea
                value={reviewNotes}
                onChange={(e) => setReviewNotes(e.target.value)}
                placeholder="Add any notes for the reviewer..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAssignReviewDialog(false)}>Cancel</Button>
            <Button onClick={handleAssignForReview} disabled={!selectedReviewer}>
              Assign for Review
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
