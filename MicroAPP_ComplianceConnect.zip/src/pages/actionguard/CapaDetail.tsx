import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Clock, User, Building2, AlertTriangle, CheckCircle2, XCircle, RotateCcw, FileText, MessageSquare, History, Link2, Folder, Activity, Target, Shield, ClipboardList, Search, BarChart3, Calendar, ChevronRight, Plus, Pencil, X, FileSearch, Scale, Trash2, Lock } from 'lucide-react';
import { 
  CapaModeBanner, 
  ReadinessChecklist, 
  ExecutionProgressMeter,
  getCapaBucket,
  BUCKET_LABELS
} from '@/components/actionguard/CapaBucketHelpers';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { mockCapasNew, originTypeLabels, actionTypeLabels, mockActionGuardUsers } from '@/data/actionguardMockData';
import { CapaStatusNew, CapaNew, ContainmentActionNew, RootCauseNew, CapaActionNew, EffectivenessCriteria, MonitoringEntry, VerificationStep, CapaAttachment } from '@/types/actionguard';
import { microappConfigs, CrossReferenceItemType, MicroappType } from '@/types/crossReference';
import { 
  ContainmentDialog, 
  RootCauseDialog, 
  ActionDialog, 
  VerificationStepDialog,
  EffectivenessCriteriaDialog, 
  MonitoringEntryDialog,
  FileAttachmentDialog,
  DeleteConfirmDialog,
  CrudToolbar,
  ItemActions
} from '@/components/actionguard/CapaCrudDialogs';

const statusConfig: Record<CapaStatusNew, { label: string; color: string; icon: any }> = {
  draft: { label: 'Draft', color: 'bg-gray-500/10 text-gray-600 border-gray-500/20', icon: FileText },
  submitted: { label: 'Submitted', color: 'bg-orange-500/10 text-orange-600 border-orange-500/20', icon: Clock },
  in_review: { label: 'In Review', color: 'bg-amber-500/10 text-amber-600 border-amber-500/20', icon: Search },
  approved: { label: 'Approved', color: 'bg-cyan-500/10 text-cyan-600 border-cyan-500/20', icon: CheckCircle2 },
  in_progress: { label: 'In Progress', color: 'bg-blue-500/10 text-blue-600 border-blue-500/20', icon: Activity },
  verification: { label: 'Verification', color: 'bg-purple-500/10 text-purple-600 border-purple-500/20', icon: Shield },
  effectiveness_monitoring: { label: 'Effectiveness Monitoring', color: 'bg-indigo-500/10 text-indigo-600 border-indigo-500/20', icon: BarChart3 },
  closed: { label: 'Closed', color: 'bg-green-500/10 text-green-600 border-green-500/20', icon: CheckCircle2 },
  reopened: { label: 'Reopened', color: 'bg-red-500/10 text-red-600 border-red-500/20', icon: RotateCcw },
};

const severityColors: Record<string, string> = {
  low: 'bg-green-500/10 text-green-600 border-green-500/20',
  medium: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
  high: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
  critical: 'bg-red-500/10 text-red-600 border-red-500/20',
};

const departments = ['nursing', 'pharmacy', 'laboratory', 'radiology', 'administration', 'it', 'quality_assurance', 'compliance', 'dietary', 'maintenance'];

// Mock cross-reference items
const mockCrossReferenceItems: { microapp: MicroappType; itemType: CrossReferenceItemType; id: string; title: string; status: string }[] = [
  { microapp: 'riskguard', itemType: 'risk_assessment', id: 'RISK-2024-001', title: 'Patient Safety Risk Assessment Q4', status: 'active' },
  { microapp: 'riskguard', itemType: 'risk_register', id: 'RISK-2024-002', title: 'Fall Prevention Risk Register', status: 'active' },
  { microapp: 'auditpro', itemType: 'audit_finding', id: 'AUD-2024-015', title: 'Documentation Gap - Medication Administration', status: 'open' },
  { microapp: 'auditpro', itemType: 'audit_report', id: 'AUD-2024-008', title: 'Q3 Internal Compliance Audit', status: 'completed' },
  { microapp: 'feedbackhub', itemType: 'complaint', id: 'FB-2024-042', title: 'Patient Wait Time Complaint', status: 'resolved' },
  { microapp: 'feedbackhub', itemType: 'feedback_item', id: 'FB-2024-051', title: 'Staff Communication Feedback', status: 'open' },
  { microapp: 'enforcementpoint', itemType: 'investigation', id: 'ENF-2024-003', title: 'CMS Survey Follow-up Investigation', status: 'in_progress' },
  { microapp: 'complianceconnect', itemType: 'issue', id: 'ISS-001', title: 'Medication Documentation Non-Compliance', status: 'in_progress' },
  { microapp: 'citations', itemType: 'citation', id: 'CIT-001', title: 'F689 - Free of Accident Hazards', status: 'active' },
];

const getMicroappIcon = (microapp: MicroappType) => {
  switch (microapp) {
    case 'riskguard': return <Shield className="h-4 w-4" />;
    case 'auditpro': return <FileSearch className="h-4 w-4" />;
    case 'feedbackhub': return <MessageSquare className="h-4 w-4" />;
    case 'enforcementpoint': return <Scale className="h-4 w-4" />;
    case 'complianceconnect': return <ClipboardList className="h-4 w-4" />;
    case 'citations': return <FileText className="h-4 w-4" />;
    case 'actionguard': return <Target className="h-4 w-4" />;
    default: return <Link2 className="h-4 w-4" />;
  }
};

const getMicroappColor = (microapp: MicroappType) => {
  switch (microapp) {
    case 'riskguard': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
    case 'auditpro': return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
    case 'feedbackhub': return 'bg-green-500/10 text-green-600 border-green-500/20';
    case 'enforcementpoint': return 'bg-red-500/10 text-red-600 border-red-500/20';
    case 'complianceconnect': return 'bg-cyan-500/10 text-cyan-600 border-cyan-500/20';
    case 'citations': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
    case 'actionguard': return 'bg-orange-500/10 text-orange-600 border-orange-500/20';
    default: return 'bg-muted text-muted-foreground';
  }
};

interface LinkedItem {
  microapp: MicroappType;
  itemType: CrossReferenceItemType;
  id: string;
  title: string;
  status: string;
}

export default function CapaDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const [showStartReviewDialog, setShowStartReviewDialog] = useState(false);
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [showVerificationDialog, setShowVerificationDialog] = useState(false);
  const [showEffectivenessDialog, setShowEffectivenessDialog] = useState(false);
  const [showCloseDialog, setShowCloseDialog] = useState(false);
  const [showReopenDialog, setShowReopenDialog] = useState(false);
  const [approvalComments, setApprovalComments] = useState('');
  const [transitionComments, setTransitionComments] = useState('');
  
  // Edit states
  const [showEditOwnerDialog, setShowEditOwnerDialog] = useState(false);
  const [showEditDeptDialog, setShowEditDeptDialog] = useState(false);
  const [showLinkDialog, setShowLinkDialog] = useState(false);
  const [editOwner, setEditOwner] = useState('');
  const [editDeptHead, setEditDeptHead] = useState('');
  const [editCompHead, setEditCompHead] = useState('');
  const [editDepartment, setEditDepartment] = useState('');
  const [selectedMicroapp, setSelectedMicroapp] = useState<MicroappType | ''>('');
  const [linkedItems, setLinkedItems] = useState<LinkedItem[]>([]);

  // CRUD Dialog States
  const [showContainmentDialog, setShowContainmentDialog] = useState(false);
  const [showRootCauseDialog, setShowRootCauseDialog] = useState(false);
  const [showCorrectiveActionDialog, setShowCorrectiveActionDialog] = useState(false);
  const [showPreventiveActionDialog, setShowPreventiveActionDialog] = useState(false);
  const [showVerificationStepDialog, setShowVerificationStepDialog] = useState(false);
  const [showEffectivenessCriteriaDialog, setShowEffectivenessCriteriaDialog] = useState(false);
  const [showMonitoringEntryDialog, setShowMonitoringEntryDialog] = useState(false);
  const [showFileAttachmentDialog, setShowFileAttachmentDialog] = useState(false);
  const [showDeleteConfirmDialog, setShowDeleteConfirmDialog] = useState(false);
  
  // Edit mode and selected item
  const [crudMode, setCrudMode] = useState<'add' | 'edit'>('add');
  const [selectedContainment, setSelectedContainment] = useState<ContainmentActionNew | undefined>();
  const [selectedRootCause, setSelectedRootCause] = useState<RootCauseNew | undefined>();
  const [selectedAction, setSelectedAction] = useState<CapaActionNew | undefined>();
  const [selectedVerificationStep, setSelectedVerificationStep] = useState<VerificationStep | undefined>();
  const [selectedEffectivenessCriteria, setSelectedEffectivenessCriteria] = useState<EffectivenessCriteria | undefined>();
  const [selectedMonitoringEntry, setSelectedMonitoringEntry] = useState<MonitoringEntry | undefined>();
  const [deleteItemType, setDeleteItemType] = useState('');
  const [deleteCallback, setDeleteCallback] = useState<(() => void) | null>(null);

  const capa = mockCapasNew.find(c => c.id === id);

  if (!capa) {
    return (
      <div className="p-6">
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold text-foreground">CAPA not found</h2>
          <Button variant="outline" onClick={() => navigate('/actionguard')} className="mt-4">
            Back to CAPAs
          </Button>
        </div>
      </div>
    );
  }

  const isCmsSurvey = capa.originType === 'cms_state_survey';
  const status = statusConfig[capa.status];
  const StatusIcon = status.icon;

  const totalActions = capa.correctiveActions.length + capa.preventiveActions.length;
  const completedActions = [...capa.correctiveActions, ...capa.preventiveActions].filter(a => a.status === 'done').length;
  const actionProgress = totalActions > 0 ? (completedActions / totalActions) * 100 : 0;

  const isOverdue = new Date(capa.dueDate) < new Date() && capa.status !== 'closed';
  const isPocOverdue = isCmsSurvey && capa.surveyPocData?.pocDueDate && new Date(capa.surveyPocData.pocDueDate) < new Date() && !capa.surveyPocData.pocSubmissionDate;

  const daysUntilDue = Math.ceil((new Date(capa.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
  const pocDaysUntilDue = isCmsSurvey && capa.surveyPocData?.pocDueDate 
    ? Math.ceil((new Date(capa.surveyPocData.pocDueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
    : null;

  const handleApprove = () => {
    toast({ title: 'CAPA Approved', description: 'The CAPA has been approved and moved to In Progress.' });
    setShowApproveDialog(false);
  };

  const handleReject = () => {
    toast({ title: 'Changes Requested', description: 'The CAPA has been returned for changes.' });
    setShowRejectDialog(false);
  };

  const handleSaveOwnership = () => {
    toast({ title: 'Ownership Updated', description: 'The CAPA ownership has been updated.' });
    setShowEditOwnerDialog(false);
  };

  const handleSaveDepartment = () => {
    toast({ title: 'Department Updated', description: 'The CAPA department has been updated.' });
    setShowEditDeptDialog(false);
  };

  const addLinkedItem = (item: LinkedItem) => {
    if (!linkedItems.find(i => i.id === item.id)) {
      setLinkedItems([...linkedItems, item]);
      toast({ title: 'Item Linked', description: `${item.title} has been linked to this CAPA.` });
    }
    setShowLinkDialog(false);
    setSelectedMicroapp('');
  };

  const removeLinkedItem = (itemId: string) => {
    setLinkedItems(linkedItems.filter(i => i.id !== itemId));
    toast({ title: 'Item Unlinked', description: 'The cross-reference has been removed.' });
  };

  const filteredCrossRefItems = selectedMicroapp 
    ? mockCrossReferenceItems.filter(i => i.microapp === selectedMicroapp)
    : mockCrossReferenceItems;

  const departmentHeads = mockActionGuardUsers.filter(u => u.role === 'Department Head' || u.role === 'Admin');
  const complianceHeads = mockActionGuardUsers.filter(u => u.role === 'Compliance Head' || u.role === 'Admin');
  const staffUsers = mockActionGuardUsers.filter(u => u.role === 'Staff' || u.role === 'Department Head');

  const getActionStatusColor = (status: string) => {
    switch (status) {
      case 'done': return 'bg-green-500/10 text-green-600 border-green-500/20';
      case 'in_progress': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'blocked': return 'bg-red-500/10 text-red-600 border-red-500/20';
      case 'cancelled': return 'bg-gray-500/10 text-gray-600 border-gray-500/20';
      default: return 'bg-gray-500/10 text-gray-600 border-gray-500/20';
    }
  };

  // CRUD Helper Functions
  const openAddContainment = () => {
    setCrudMode('add');
    setSelectedContainment(undefined);
    setShowContainmentDialog(true);
  };
  const openEditContainment = (item: ContainmentActionNew) => {
    setCrudMode('edit');
    setSelectedContainment(item);
    setShowContainmentDialog(true);
  };
  const openAddRootCause = () => {
    setCrudMode('add');
    setSelectedRootCause(undefined);
    setShowRootCauseDialog(true);
  };
  const openEditRootCause = (item: RootCauseNew) => {
    setCrudMode('edit');
    setSelectedRootCause(item);
    setShowRootCauseDialog(true);
  };
  const openAddCorrectiveAction = () => {
    setCrudMode('add');
    setSelectedAction(undefined);
    setShowCorrectiveActionDialog(true);
  };
  const openEditCorrectiveAction = (item: CapaActionNew) => {
    setCrudMode('edit');
    setSelectedAction(item);
    setShowCorrectiveActionDialog(true);
  };
  const openAddPreventiveAction = () => {
    setCrudMode('add');
    setSelectedAction(undefined);
    setShowPreventiveActionDialog(true);
  };
  const openEditPreventiveAction = (item: CapaActionNew) => {
    setCrudMode('edit');
    setSelectedAction(item);
    setShowPreventiveActionDialog(true);
  };
  const openAddVerificationStep = () => {
    setCrudMode('add');
    setSelectedVerificationStep(undefined);
    setShowVerificationStepDialog(true);
  };
  const openEditVerificationStep = (item: VerificationStep) => {
    setCrudMode('edit');
    setSelectedVerificationStep(item);
    setShowVerificationStepDialog(true);
  };
  const openAddEffectivenessCriteria = () => {
    setCrudMode('add');
    setSelectedEffectivenessCriteria(undefined);
    setShowEffectivenessCriteriaDialog(true);
  };
  const openEditEffectivenessCriteria = (item: EffectivenessCriteria) => {
    setCrudMode('edit');
    setSelectedEffectivenessCriteria(item);
    setShowEffectivenessCriteriaDialog(true);
  };
  const openAddMonitoringEntry = () => {
    setCrudMode('add');
    setSelectedMonitoringEntry(undefined);
    setShowMonitoringEntryDialog(true);
  };
  const openEditMonitoringEntry = (item: MonitoringEntry) => {
    setCrudMode('edit');
    setSelectedMonitoringEntry(item);
    setShowMonitoringEntryDialog(true);
  };
  const confirmDelete = (itemType: string, callback: () => void) => {
    setDeleteItemType(itemType);
    setDeleteCallback(() => callback);
    setShowDeleteConfirmDialog(true);
  };
  const handleConfirmDelete = () => {
    if (deleteCallback) deleteCallback();
    setShowDeleteConfirmDialog(false);
    setDeleteCallback(null);
  };

  return (
    <div className="flex h-full">
      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-start gap-4 mb-6">
            <Button variant="ghost" size="icon" onClick={() => navigate('/actionguard')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2 flex-wrap">
                <Badge variant="outline" className={status.color}>
                  <StatusIcon className="h-3 w-3 mr-1" />
                  {status.label}
                </Badge>
                <Badge variant="outline" className={severityColors[capa.severity]}>
                  {capa.severity.charAt(0).toUpperCase() + capa.severity.slice(1)} Severity
                </Badge>
                <Badge variant="outline">
                  {originTypeLabels[capa.originType]}
                </Badge>
                {capa.qapiFlag && (
                  <Badge variant="outline" className="bg-purple-500/10 text-purple-600 border-purple-500/20">
                    QAPI
                  </Badge>
                )}
              </div>
              <h1 className="text-2xl font-bold text-foreground mb-1">{capa.title}</h1>
              <p className="text-muted-foreground">{capa.id}</p>
            </div>
          </div>

          {/* Alerts */}
          {isOverdue && (
            <Alert variant="destructive" className="mb-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                This CAPA is overdue by {Math.abs(daysUntilDue)} days. Due date was {new Date(capa.dueDate).toLocaleDateString()}.
              </AlertDescription>
            </Alert>
          )}

          {isPocOverdue && (
            <Alert variant="destructive" className="mb-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Plan of Correction is OVERDUE!</strong> PoC was due {Math.abs(pocDaysUntilDue!)} days ago on {new Date(capa.surveyPocData!.pocDueDate!).toLocaleDateString()}.
              </AlertDescription>
            </Alert>
          )}

          {capa.status === 'reopened' && capa.reopenReason && (
            <Alert className="mb-4 border-amber-500/50 bg-amber-500/10">
              <RotateCcw className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-amber-700">
                <strong>Reopened:</strong> {capa.reopenReason}
              </AlertDescription>
            </Alert>
          )}

          {/* Mode Banner (NEW / OPEN / CLOSED) */}
          <CapaModeBanner status={capa.status} className="mb-6" />

          {/* PoC Clock Card for CMS/State Survey */}
          {isCmsSurvey && capa.surveyPocData && (
            <Card className={`mb-6 ${isPocOverdue ? 'border-red-500' : pocDaysUntilDue && pocDaysUntilDue <= 3 ? 'border-amber-500' : 'border-blue-500'}`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-lg ${isPocOverdue ? 'bg-red-500/10' : 'bg-blue-500/10'}`}>
                      <Clock className={`h-6 w-6 ${isPocOverdue ? 'text-red-600' : 'text-blue-600'}`} />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Plan of Correction Due</p>
                      <p className={`text-lg font-bold ${isPocOverdue ? 'text-red-600' : 'text-foreground'}`}>
                        {capa.surveyPocData.pocDueDate ? new Date(capa.surveyPocData.pocDueDate).toLocaleDateString() : 'Not set'}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    {capa.surveyPocData.pocSubmissionDate ? (
                      <div>
                        <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/20">
                          Submitted {new Date(capa.surveyPocData.pocSubmissionDate).toLocaleDateString()}
                        </Badge>
                        {capa.surveyPocData.pocAcceptedStatus && (
                          <Badge variant="outline" className={`ml-2 ${
                            capa.surveyPocData.pocAcceptedStatus === 'accepted' ? 'bg-green-500/10 text-green-600' :
                            capa.surveyPocData.pocAcceptedStatus === 'returned' ? 'bg-red-500/10 text-red-600' :
                            'bg-amber-500/10 text-amber-600'
                          }`}>
                            {capa.surveyPocData.pocAcceptedStatus.charAt(0).toUpperCase() + capa.surveyPocData.pocAcceptedStatus.slice(1)}
                          </Badge>
                        )}
                      </div>
                    ) : (
                      <div className={`text-2xl font-bold ${isPocOverdue ? 'text-red-600' : pocDaysUntilDue && pocDaysUntilDue <= 3 ? 'text-amber-600' : 'text-blue-600'}`}>
                        {isPocOverdue ? `${Math.abs(pocDaysUntilDue!)} days overdue` : `${pocDaysUntilDue} days`}
                      </div>
                    )}
                  </div>
                </div>
                {capa.surveyPocData.ftag && (
                  <div className="mt-3 pt-3 border-t border-border flex gap-4 text-sm">
                    <span><strong>F-Tag:</strong> {capa.surveyPocData.ftag}</span>
                    {capa.surveyPocData.scopeSeverity && <span><strong>Scope/Severity:</strong> {capa.surveyPocData.scopeSeverity}</span>}
                    {capa.surveyPocData.surveyDate && <span><strong>Survey Date:</strong> {new Date(capa.surveyPocData.surveyDate).toLocaleDateString()}</span>}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-4 flex-wrap h-auto">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              {isCmsSurvey && <TabsTrigger value="poc">Survey & PoC</TabsTrigger>}
              <TabsTrigger value="containment">Containment</TabsTrigger>
              <TabsTrigger value="rca">RCA</TabsTrigger>
              <TabsTrigger value="actions">Actions</TabsTrigger>
              <TabsTrigger value="verification">Verification</TabsTrigger>
              <TabsTrigger value="effectiveness">Effectiveness</TabsTrigger>
              {capa.qapiFlag && <TabsTrigger value="qapi">QAPI</TabsTrigger>}
              <TabsTrigger value="files">Files</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Problem Statement</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground">{capa.problemStatement}</p>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Facility</span>
                      <span className="font-medium">{capa.facility}</span>
                    </div>
                    {capa.unitWing && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Unit/Wing</span>
                        <span className="font-medium">{capa.unitWing}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Department</span>
                      <span className="font-medium">{capa.department}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Patient Risk</span>
                      <span className="font-medium">{capa.patientRisk}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Created</span>
                      <span className="font-medium">{new Date(capa.createdAt).toLocaleDateString()}</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Progress</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-muted-foreground">Actions Completed</span>
                        <span className="font-medium">{completedActions} / {totalActions}</span>
                      </div>
                      <Progress value={actionProgress} className="h-2" />
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div className="p-3 bg-muted/50 rounded-lg">
                        <p className="text-2xl font-bold text-red-600">{capa.correctiveActions.length}</p>
                        <p className="text-xs text-muted-foreground">Corrective</p>
                      </div>
                      <div className="p-3 bg-muted/50 rounded-lg">
                        <p className="text-2xl font-bold text-blue-600">{capa.preventiveActions.length}</p>
                        <p className="text-xs text-muted-foreground">Preventive</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {capa.harmPotentialNotes && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Harm Potential Notes</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-foreground">{capa.harmPotentialNotes}</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Survey & PoC Tab */}
            {isCmsSurvey && (
              <TabsContent value="poc" className="space-y-6">
                {capa.surveyPocData?.pocElements && capa.surveyPocData.pocElements.length > 0 ? (
                  <div className="space-y-4">
                    <h3 className="font-semibold text-foreground">Plan of Correction Elements</h3>
                    {capa.surveyPocData.pocElements.map((element) => (
                      <Card key={element.id}>
                        <CardHeader className="pb-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{element.elementNumber}</Badge>
                            <CardTitle className="text-base">{element.title}</CardTitle>
                          </div>
                          <CardDescription>{element.description}</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-foreground whitespace-pre-wrap">{element.content}</p>
                          {element.completionDate && (
                            <p className="text-sm text-muted-foreground mt-2">
                              Completion Date: {new Date(element.completionDate).toLocaleDateString()}
                            </p>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card className="border-dashed">
                    <CardContent className="p-8 text-center">
                      <p className="text-muted-foreground">No PoC elements documented yet</p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            )}

            {/* Containment Tab */}
            <TabsContent value="containment" className="space-y-6">
              <CrudToolbar onAdd={openAddContainment} addLabel="Add Containment Action" />
              {capa.containmentActions.length > 0 ? (
                <div className="space-y-4">
                  {capa.containmentActions.map((action, idx) => (
                    <Card key={action.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <p className="font-medium text-foreground">{action.description}</p>
                            <div className="flex gap-4 mt-2 text-sm text-muted-foreground">
                              <span>Who: {action.who}</span>
                              <span>When: {new Date(action.when).toLocaleDateString()}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {action.completedAt ? (
                              <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/20">
                                <CheckCircle2 className="h-3 w-3 mr-1" />
                                Completed
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/20">
                                Pending
                              </Badge>
                            )}
                            <ItemActions 
                              onEdit={() => openEditContainment(action)} 
                              onDelete={() => confirmDelete('Containment Action', () => toast({ title: 'Deleted', description: 'Containment action deleted.' }))} 
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="border-dashed">
                  <CardContent className="p-8 text-center">
                    <p className="text-muted-foreground">No containment actions documented</p>
                    <Button variant="outline" className="mt-4 gap-2" onClick={openAddContainment}>
                      <Plus className="h-4 w-4" /> Add Containment Action
                    </Button>
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    {capa.immediateRiskMitigationComplete ? (
                      <CheckCircle2 className="h-5 w-5 text-green-600" />
                    ) : (
                      <XCircle className="h-5 w-5 text-amber-600" />
                    )}
                    <div>
                      <p className="font-medium text-foreground">
                        Immediate Risk Mitigation {capa.immediateRiskMitigationComplete ? 'Complete' : 'In Progress'}
                      </p>
                      {capa.riskMitigationNotes && (
                        <p className="text-sm text-muted-foreground">{capa.riskMitigationNotes}</p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* RCA Tab */}
            <TabsContent value="rca" className="space-y-6">
              <CrudToolbar onAdd={openAddRootCause} addLabel="Add Root Cause" />
              {capa.rca ? (
                <>
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Analysis Method</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Badge variant="outline">
                        {capa.rca.method === 'five_whys' ? '5 Whys' : 
                         capa.rca.method === 'fishbone' ? 'Fishbone (Ishikawa)' :
                         capa.rca.method === 'process_map' ? 'Process Map' : 'Other'}
                      </Badge>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-foreground">{capa.rca.summary}</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Contributing Factors</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {capa.rca.contributingFactors.map((factor) => (
                          <Badge key={factor} variant="outline">
                            {factor.charAt(0).toUpperCase() + factor.slice(1)}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold text-foreground">Root Causes</h3>
                    </div>
                    {capa.rca.rootCauses.map((rc, idx) => (
                      <Card key={rc.id}>
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium text-primary">
                              {idx + 1}
                            </div>
                            <div className="flex-1">
                              <p className="font-medium text-foreground">{rc.statement}</p>
                              <div className="flex items-center gap-2 mt-2">
                                <Badge variant="outline">{rc.category}</Badge>
                                <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-500/20">
                                  {rc.confidence} confidence
                                </Badge>
                              </div>
                              {rc.justification && (
                                <p className="text-sm text-muted-foreground mt-2">
                                  <strong>Evidence:</strong> {rc.justification}
                                </p>
                              )}
                            </div>
                            <ItemActions 
                              onEdit={() => openEditRootCause(rc)} 
                              onDelete={() => confirmDelete('Root Cause', () => toast({ title: 'Deleted', description: 'Root cause deleted.' }))} 
                            />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </>
              ) : (
                <Card className="border-dashed">
                  <CardContent className="p-8 text-center">
                    <p className="text-muted-foreground">No root cause analysis documented</p>
                    <Button variant="outline" className="mt-4 gap-2" onClick={openAddRootCause}>
                      <Plus className="h-4 w-4" /> Add Root Cause
                    </Button>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Actions Tab */}
            <TabsContent value="actions" className="space-y-6">
              {/* Corrective Actions */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-foreground flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-red-500"></span>
                    Corrective Actions ({capa.correctiveActions.length})
                  </h3>
                  <Button variant="outline" size="sm" onClick={openAddCorrectiveAction} className="gap-2">
                    <Plus className="h-4 w-4" /> Add
                  </Button>
                </div>
                {capa.correctiveActions.length > 0 ? (
                  capa.correctiveActions.map((action) => (
                    <Card key={action.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className={getActionStatusColor(action.status)}>
                              {action.status.replace('_', ' ')}
                            </Badge>
                            <Badge variant="outline">{actionTypeLabels[action.actionType]}</Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            {action.evidenceRequired && (
                              <Badge variant="outline" className="text-xs">Evidence Required</Badge>
                            )}
                            <ItemActions 
                              onEdit={() => openEditCorrectiveAction(action)} 
                              onDelete={() => confirmDelete('Corrective Action', () => toast({ title: 'Deleted', description: 'Corrective action deleted.' }))} 
                            />
                          </div>
                        </div>
                        <h4 className="font-medium text-foreground">{action.title}</h4>
                        <p className="text-sm text-muted-foreground mt-1">{action.description}</p>
                        <div className="flex gap-4 mt-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <User className="h-3 w-3" /> {action.owner}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" /> Due: {new Date(action.dueDate).toLocaleDateString()}
                          </span>
                          {action.completedAt && (
                            <span className="flex items-center gap-1 text-green-600">
                              <CheckCircle2 className="h-3 w-3" /> Completed: {new Date(action.completedAt).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <Card className="border-dashed">
                    <CardContent className="p-6 text-center">
                      <p className="text-muted-foreground">No corrective actions</p>
                    </CardContent>
                  </Card>
                )}
              </div>

              <Separator />

              {/* Preventive Actions */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-foreground flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-blue-500"></span>
                    Preventive Actions ({capa.preventiveActions.length})
                  </h3>
                  <Button variant="outline" size="sm" onClick={openAddPreventiveAction} className="gap-2">
                    <Plus className="h-4 w-4" /> Add
                  </Button>
                </div>
                {capa.preventiveActions.length > 0 ? (
                  capa.preventiveActions.map((action) => (
                    <Card key={action.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className={getActionStatusColor(action.status)}>
                              {action.status.replace('_', ' ')}
                            </Badge>
                            <Badge variant="outline">{actionTypeLabels[action.actionType]}</Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            {action.evidenceRequired && (
                              <Badge variant="outline" className="text-xs">Evidence Required</Badge>
                            )}
                            <ItemActions 
                              onEdit={() => openEditPreventiveAction(action)} 
                              onDelete={() => confirmDelete('Preventive Action', () => toast({ title: 'Deleted', description: 'Preventive action deleted.' }))} 
                            />
                          </div>
                        </div>
                        <h4 className="font-medium text-foreground">{action.title}</h4>
                        <p className="text-sm text-muted-foreground mt-1">{action.description}</p>
                        <div className="flex gap-4 mt-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <User className="h-3 w-3" /> {action.owner}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" /> Due: {new Date(action.dueDate).toLocaleDateString()}
                          </span>
                          {action.completedAt && (
                            <span className="flex items-center gap-1 text-green-600">
                              <CheckCircle2 className="h-3 w-3" /> Completed: {new Date(action.completedAt).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <Card className="border-dashed">
                    <CardContent className="p-6 text-center">
                      <p className="text-muted-foreground">No preventive actions</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>

            {/* Verification Tab */}
            <TabsContent value="verification" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Verification Status</CardTitle>
                  <CardDescription>Verification checks for completed actions</CardDescription>
                </CardHeader>
                <CardContent>
                  {[...capa.correctiveActions, ...capa.preventiveActions].filter(a => a.status === 'done').length > 0 ? (
                    <div className="space-y-4">
                      {[...capa.correctiveActions, ...capa.preventiveActions]
                        .filter(a => a.status === 'done')
                        .map((action) => (
                          <div key={action.id} className="p-3 border rounded-lg">
                            <div className="flex items-center justify-between">
                              <span className="font-medium text-foreground">{action.title}</span>
                              <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/20">
                                {action.verificationType}
                              </Badge>
                            </div>
                            {action.verificationSteps.length > 0 && (
                              <div className="mt-2 space-y-2">
                                {action.verificationSteps.map((step) => (
                                  <div key={step.id} className="flex items-center gap-2 text-sm">
                                    {step.completed ? (
                                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                                    ) : (
                                      <div className="h-4 w-4 rounded-full border-2 border-muted-foreground" />
                                    )}
                                    <span className={step.completed ? 'text-muted-foreground line-through' : 'text-foreground'}>
                                      {step.description}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground text-center py-4">No completed actions to verify</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Effectiveness Tab */}
            <TabsContent value="effectiveness" className="space-y-6">
              {/* Criteria */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-base">Effectiveness Criteria</CardTitle>
                  <Button variant="outline" size="sm" onClick={openAddEffectivenessCriteria} className="gap-2">
                    <Plus className="h-4 w-4" /> Add
                  </Button>
                </CardHeader>
                <CardContent>
                  {capa.effectivenessCriteria.length > 0 ? (
                    <div className="space-y-4">
                      {capa.effectivenessCriteria.map((ec) => (
                        <div key={ec.id} className="flex items-start justify-between p-3 border rounded-lg">
                          <div>
                            <p className="font-medium text-foreground">{ec.criteria}</p>
                            <div className="flex gap-4 mt-2 text-sm">
                              {ec.kpi && <span className="text-muted-foreground">KPI: {ec.kpi}</span>}
                              {ec.baseline && <span className="text-muted-foreground">Baseline: {ec.baseline}</span>}
                              <span className="text-primary font-medium">Target: {ec.target}</span>
                            </div>
                          </div>
                          <ItemActions 
                            onEdit={() => openEditEffectivenessCriteria(ec)} 
                            onDelete={() => confirmDelete('Effectiveness Criteria', () => toast({ title: 'Deleted', description: 'Criteria deleted.' }))} 
                          />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground text-center py-4">No effectiveness criteria defined</p>
                  )}
                </CardContent>
              </Card>

              {/* Monitoring Entries */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-base">Monitoring Entries</CardTitle>
                  <Button variant="outline" size="sm" onClick={openAddMonitoringEntry} className="gap-2">
                    <Plus className="h-4 w-4" /> Add Entry
                  </Button>
                </CardHeader>
                <CardContent>
                  {capa.monitoringEntries.length > 0 ? (
                    <div className="space-y-3">
                      {capa.monitoringEntries.map((entry) => (
                        <div key={entry.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <p className="font-medium text-foreground">{entry.metricValue}</p>
                            {entry.notes && <p className="text-sm text-muted-foreground">{entry.notes}</p>}
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="text-right text-sm text-muted-foreground">
                              <p>{new Date(entry.date).toLocaleDateString()}</p>
                              <p>by {entry.recordedBy}</p>
                            </div>
                            <ItemActions 
                              onEdit={() => openEditMonitoringEntry(entry)} 
                              onDelete={() => confirmDelete('Monitoring Entry', () => toast({ title: 'Deleted', description: 'Entry deleted.' }))} 
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground text-center py-4">No monitoring entries recorded</p>
                  )}
                </CardContent>
              </Card>

              {/* Effectiveness Result */}
              {capa.effectivenessResult && (
                <Card className={capa.effectivenessResult === 'pass' ? 'border-green-500' : 'border-red-500'}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      {capa.effectivenessResult === 'pass' ? (
                        <CheckCircle2 className="h-8 w-8 text-green-600" />
                      ) : (
                        <XCircle className="h-8 w-8 text-red-600" />
                      )}
                      <div>
                        <p className={`font-bold text-lg ${capa.effectivenessResult === 'pass' ? 'text-green-600' : 'text-red-600'}`}>
                          Effectiveness: {capa.effectivenessResult.toUpperCase()}
                        </p>
                        {capa.effectivenessNotes && (
                          <p className="text-sm text-muted-foreground">{capa.effectivenessNotes}</p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* QAPI Tab */}
            {capa.qapiFlag && (
              <TabsContent value="qapi" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">QAPI Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="h-5 w-5 text-green-600" />
                      <span className="font-medium">Included in QAPI Reporting</span>
                    </div>
                    {capa.pipReference && (
                      <div>
                        <Label className="text-muted-foreground">PIP Reference</Label>
                        <p className="font-medium">{capa.pipReference}</p>
                      </div>
                    )}
                    {capa.qapiMetricsLinked && capa.qapiMetricsLinked.length > 0 && (
                      <div>
                        <Label className="text-muted-foreground">Linked Metrics</Label>
                        <div className="flex flex-wrap gap-2 mt-1">
                          {capa.qapiMetricsLinked.map((metric) => (
                            <Badge key={metric} variant="outline">{metric}</Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            )}

            {/* Files Tab */}
            <TabsContent value="files">
              <CrudToolbar onAdd={() => setShowFileAttachmentDialog(true)} addLabel="Upload File" />
              {capa.attachments && capa.attachments.length > 0 ? (
                <div className="space-y-3">
                  {capa.attachments.map((file) => (
                    <Card key={file.id}>
                      <CardContent className="p-4 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Folder className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="font-medium text-foreground">{file.fileName}</p>
                            <p className="text-xs text-muted-foreground">Uploaded by {file.uploadedBy} on {new Date(file.uploadedAt).toLocaleDateString()}</p>
                          </div>
                        </div>
                        <ItemActions onDelete={() => confirmDelete('File', () => toast({ title: 'Deleted', description: 'File deleted.' }))} />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="border-dashed">
                  <CardContent className="p-8 text-center">
                    <Folder className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">No files attached</p>
                    <Button variant="outline" className="mt-4 gap-2" onClick={() => setShowFileAttachmentDialog(true)}>
                      <Plus className="h-4 w-4" /> Upload File
                    </Button>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* History Tab */}
            <TabsContent value="history">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Audit History</CardTitle>
                </CardHeader>
                <CardContent>
                  {capa.auditLog.length > 0 ? (
                    <div className="space-y-4">
                      {capa.auditLog.map((entry) => (
                        <div key={entry.id} className="flex items-start gap-3">
                          <div className="w-2 h-2 rounded-full bg-primary mt-2" />
                          <div className="flex-1">
                            <p className="font-medium text-foreground">{entry.action}</p>
                            {entry.details && <p className="text-sm text-muted-foreground">{entry.details}</p>}
                            <p className="text-xs text-muted-foreground mt-1">
                              {entry.performedBy} • {new Date(entry.performedAt).toLocaleString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground text-center py-4">No audit history</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Action Center Rail */}
      <div className="w-80 border-l border-border bg-muted/30 p-4 overflow-auto hidden lg:block">
        <h3 className="font-semibold text-foreground mb-4">Action Center</h3>

        {/* Bucket Badge */}
        <div className="mb-4">
          <Badge 
            variant="outline" 
            className={`text-xs ${
              getCapaBucket(capa.status) === 'new' ? 'bg-amber-500/10 text-amber-600 border-amber-500/20' :
              getCapaBucket(capa.status) === 'open' ? 'bg-blue-500/10 text-blue-600 border-blue-500/20' :
              'bg-green-500/10 text-green-600 border-green-500/20'
            }`}
          >
            {BUCKET_LABELS[getCapaBucket(capa.status)].label}
          </Badge>
        </div>

        {/* Readiness Checklist for NEW CAPAs */}
        {getCapaBucket(capa.status) === 'new' && (
          <div className="mb-6 p-3 bg-amber-500/5 border border-amber-500/20 rounded-lg">
            <ReadinessChecklist
              hasTitle={!!capa.title}
              hasProblemStatement={!!capa.problemStatement}
              hasOwner={!!capa.owner}
              hasDueDate={!!capa.dueDate}
              hasRootCause={capa.rca?.rootCauses && capa.rca.rootCauses.length > 0}
              hasActions={capa.correctiveActions.length > 0 || capa.preventiveActions.length > 0}
            />
          </div>
        )}

        {/* Progress Meter for OPEN CAPAs */}
        {getCapaBucket(capa.status) === 'open' && (
          <div className="mb-6 p-3 bg-blue-500/5 border border-blue-500/20 rounded-lg">
            <ExecutionProgressMeter
              actionsCompleted={completedActions}
              totalActions={totalActions}
              verificationComplete={capa.status === 'effectiveness_monitoring' || capa.status === 'closed'}
              effectivenessDueDate={capa.effectivenessDueDate instanceof Date ? capa.effectivenessDueDate.toISOString() : capa.effectivenessDueDate}
            />
          </div>
        )}

        {/* Closed indicator */}
        {getCapaBucket(capa.status) === 'closed' && (
          <div className="mb-6 p-3 bg-green-500/5 border border-green-500/20 rounded-lg text-center">
            <Lock className="h-8 w-8 mx-auto text-green-600 mb-2" />
            <p className="text-sm font-medium text-green-700">CAPA Completed</p>
            <p className="text-xs text-green-600/70">Read-only unless reopened</p>
          </div>
        )}

        {/* Quick Actions */}
        <div className="space-y-2 mb-6">
          {/* Draft Actions */}
          {capa.status === 'draft' && (
            <>
              <Button variant="outline" className="w-full gap-2" onClick={() => navigate(`/actionguard/edit/${capa.id}`)}>
                <Pencil className="h-4 w-4" /> Edit CAPA
              </Button>
              <Button variant="outline" className="w-full gap-2" onClick={() => setActiveTab('files')}>
                <Folder className="h-4 w-4" /> Attach Files
              </Button>
              <Dialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
                <DialogTrigger asChild>
                  <Button className="w-full gap-2">
                    <ChevronRight className="h-4 w-4" /> Submit for Review
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Submit CAPA for Review</DialogTitle>
                    <DialogDescription>
                      This CAPA will be formally submitted for approval. Reviewers will be notified.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <Alert className="bg-blue-500/10 border-blue-500/20">
                      <User className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-blue-600 text-sm">
                        Need to change the owner or department? Use the <span className="font-semibold">Ownership</span> section before submitting.
                      </AlertDescription>
                    </Alert>
                    <div>
                      <Label>Submission Notes (optional)</Label>
                      <Textarea value={transitionComments} onChange={(e) => setTransitionComments(e.target.value)} placeholder="Add any notes for reviewers..." />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setShowSubmitDialog(false)}>Cancel</Button>
                    <Button onClick={() => {
                      toast({ title: 'CAPA Submitted', description: 'CAPA has been submitted for review.' });
                      setShowSubmitDialog(false);
                      setTransitionComments('');
                    }}>Submit</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </>
          )}

          {/* Submitted Actions */}
          {capa.status === 'submitted' && (
            <>
              <Button variant="outline" className="w-full gap-2" onClick={() => navigate(`/actionguard/edit/${capa.id}`)}>
                <Pencil className="h-4 w-4" /> Edit CAPA
              </Button>
              <Button variant="outline" className="w-full gap-2" onClick={() => setActiveTab('files')}>
                <Folder className="h-4 w-4" /> View/Attach Files
              </Button>
              <Dialog open={showStartReviewDialog} onOpenChange={setShowStartReviewDialog}>
                <DialogTrigger asChild>
                  <Button className="w-full gap-2">
                    <Search className="h-4 w-4" /> Start Review
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Start CAPA Review</DialogTitle>
                    <DialogDescription>
                      Begin evaluating the CAPA quality: problem statement, containment, RCA, action plan, and verification setup.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <Alert className="bg-blue-500/10 border-blue-500/20">
                      <User className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-blue-600 text-sm">
                        Need to change the owner or department? Use the <span className="font-semibold">Ownership</span> section before starting review.
                      </AlertDescription>
                    </Alert>
                    <div>
                      <Label>Review Notes (optional)</Label>
                      <Textarea value={transitionComments} onChange={(e) => setTransitionComments(e.target.value)} placeholder="Add any initial review notes..." />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setShowStartReviewDialog(false)}>Cancel</Button>
                    <Button onClick={() => {
                      toast({ title: 'Review Started', description: 'CAPA is now in review.' });
                      setShowStartReviewDialog(false);
                      setTransitionComments('');
                    }}>Start Review</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
              <Separator className="my-2" />
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" className="w-full gap-2 text-muted-foreground">
                    <RotateCcw className="h-4 w-4" /> Return to Draft
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Return to Draft</DialogTitle>
                    <DialogDescription>This will move the CAPA back to Draft status for further editing.</DialogDescription>
                  </DialogHeader>
                  <div>
                    <Label>Reason for returning *</Label>
                    <Textarea placeholder="Explain why this CAPA needs to return to draft..." />
                  </div>
                  <DialogFooter>
                    <Button variant="outline">Cancel</Button>
                    <Button variant="destructive" onClick={() => toast({ title: 'Status Updated', description: 'CAPA returned to Draft.' })}>Return to Draft</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </>
          )}

          {/* In Review Actions */}
          {capa.status === 'in_review' && (
            <>
              <Button variant="outline" className="w-full gap-2" onClick={() => navigate(`/actionguard/edit/${capa.id}`)}>
                <Pencil className="h-4 w-4" /> Edit CAPA
              </Button>
              <Button variant="outline" className="w-full gap-2" onClick={() => setActiveTab('files')}>
                <Folder className="h-4 w-4" /> View/Attach Files
              </Button>
              <Dialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
                <DialogTrigger asChild>
                  <Button className="w-full gap-2">
                    <CheckCircle2 className="h-4 w-4" /> Approve
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Approve CAPA</DialogTitle>
                    <DialogDescription>This will move the CAPA to In Progress status.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <Alert className="bg-blue-500/10 border-blue-500/20">
                      <User className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-blue-600 text-sm">
                        Need to change the owner or department? Use the <span className="font-semibold">Ownership</span> section in the Action Center before approving.
                      </AlertDescription>
                    </Alert>
                    <div>
                      <Label>Comments (optional)</Label>
                      <Textarea value={approvalComments} onChange={(e) => setApprovalComments(e.target.value)} />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setShowApproveDialog(false)}>Cancel</Button>
                    <Button onClick={handleApprove}>Approve</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full gap-2">
                    <XCircle className="h-4 w-4" /> Request Changes
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Request Changes</DialogTitle>
                    <DialogDescription>Return this CAPA to the owner for revisions. You can optionally reassign to a different person or department.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Reassign To (optional)</Label>
                        <Select>
                          <SelectTrigger className="bg-background">
                            <SelectValue placeholder="Keep current owner" />
                          </SelectTrigger>
                          <SelectContent className="bg-background z-50">
                            <SelectItem value="current">Keep current owner</SelectItem>
                            {mockActionGuardUsers.map(user => (
                              <SelectItem key={user.id} value={user.id}>{user.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Department (optional)</Label>
                        <Select>
                          <SelectTrigger className="bg-background">
                            <SelectValue placeholder="Keep current dept" />
                          </SelectTrigger>
                          <SelectContent className="bg-background z-50">
                            <SelectItem value="current">Keep current dept</SelectItem>
                            {departments.map(dept => (
                              <SelectItem key={dept} value={dept}>{dept.replace('_', ' ')}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div>
                      <Label>Reason for changes *</Label>
                      <Textarea value={approvalComments} onChange={(e) => setApprovalComments(e.target.value)} placeholder="Explain what needs to be changed..." />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setShowRejectDialog(false)}>Cancel</Button>
                    <Button variant="destructive" onClick={handleReject}>Request Changes</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
              <Separator className="my-2" />
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" className="w-full gap-2 text-muted-foreground">
                    <RotateCcw className="h-4 w-4" /> Return to Submitted
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Return to Submitted</DialogTitle>
                    <DialogDescription>This will move the CAPA back to Submitted status.</DialogDescription>
                  </DialogHeader>
                  <div>
                    <Label>Reason for returning *</Label>
                    <Textarea placeholder="Explain why this CAPA needs to return to submitted..." />
                  </div>
                  <DialogFooter>
                    <Button variant="outline">Cancel</Button>
                    <Button variant="destructive" onClick={() => toast({ title: 'Status Updated', description: 'CAPA returned to Submitted.' })}>Return to Submitted</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </>
          )}

          {/* Approved Actions */}
          {capa.status === 'approved' && (
            <>
              <Button variant="outline" className="w-full gap-2" onClick={() => navigate(`/actionguard/edit/${capa.id}`)}>
                <Pencil className="h-4 w-4" /> Edit CAPA
              </Button>
              <Button variant="outline" className="w-full gap-2" onClick={() => setActiveTab('actions')}>
                <ClipboardList className="h-4 w-4" /> View Actions
              </Button>
              <Button variant="outline" className="w-full gap-2" onClick={() => setActiveTab('files')}>
                <Folder className="h-4 w-4" /> Attach Evidence
              </Button>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="w-full gap-2">
                    <Activity className="h-4 w-4" /> Start Work
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Start Work on CAPA</DialogTitle>
                    <DialogDescription>Begin executing corrective and preventive actions. This will move the CAPA to "In Progress" status.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <Alert className="bg-blue-500/10 border-blue-500/20">
                      <User className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-blue-600 text-sm">
                        Need to change the owner? Use the <span className="font-semibold">Ownership</span> section before starting work.
                      </AlertDescription>
                    </Alert>
                    <div>
                      <Label>Comments (optional)</Label>
                      <Textarea value={transitionComments} onChange={(e) => setTransitionComments(e.target.value)} placeholder="Add any notes..." />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline">Cancel</Button>
                    <Button onClick={() => {
                      toast({ title: 'Work Started', description: 'CAPA is now In Progress.' });
                      setTransitionComments('');
                    }}>Start Work</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
              <Separator className="my-2" />
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" className="w-full gap-2 text-muted-foreground">
                    <RotateCcw className="h-4 w-4" /> Return to In Review
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Return to In Review</DialogTitle>
                    <DialogDescription>This will move the CAPA back to In Review status for re-evaluation.</DialogDescription>
                  </DialogHeader>
                  <div>
                    <Label>Reason for returning *</Label>
                    <Textarea placeholder="Explain why this CAPA needs to return to review..." />
                  </div>
                  <DialogFooter>
                    <Button variant="outline">Cancel</Button>
                    <Button variant="destructive" onClick={() => toast({ title: 'Status Updated', description: 'CAPA returned to In Review.' })}>Return to Review</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </>
          )}

          {/* In Progress Actions */}
          {capa.status === 'in_progress' && (
            <>
              <Button variant="outline" className="w-full gap-2" onClick={() => navigate(`/actionguard/edit/${capa.id}`)}>
                <Pencil className="h-4 w-4" /> Edit CAPA
              </Button>
              <Button variant="outline" className="w-full gap-2" onClick={() => setActiveTab('actions')}>
                <ClipboardList className="h-4 w-4" /> Update Actions
              </Button>
              <Button variant="outline" className="w-full gap-2" onClick={() => setActiveTab('files')}>
                <Folder className="h-4 w-4" /> Attach Evidence
              </Button>
              <Dialog open={showVerificationDialog} onOpenChange={setShowVerificationDialog}>
                <DialogTrigger asChild>
                  <Button className="w-full gap-2">
                    <ChevronRight className="h-4 w-4" /> Move to Verification
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Move to Verification</DialogTitle>
                    <DialogDescription>Confirm that all actions are complete and ready for verification.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <Alert className="bg-blue-500/10 border-blue-500/20">
                      <User className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-blue-600 text-sm">
                        Need to change the owner or department? Use the <span className="font-semibold">Ownership</span> section before proceeding.
                      </AlertDescription>
                    </Alert>
                    <div>
                      <Label>Comments (optional)</Label>
                      <Textarea value={transitionComments} onChange={(e) => setTransitionComments(e.target.value)} placeholder="Add any notes about this transition..." />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setShowVerificationDialog(false)}>Cancel</Button>
                    <Button onClick={() => {
                      toast({ title: 'Status Updated', description: 'CAPA moved to Verification phase.' });
                      setShowVerificationDialog(false);
                      setTransitionComments('');
                    }}>Confirm</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
              <Separator className="my-2" />
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" className="w-full gap-2 text-muted-foreground">
                    <RotateCcw className="h-4 w-4" /> Return to In Review
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Return to In Review</DialogTitle>
                    <DialogDescription>This will move the CAPA back to In Review status for re-evaluation.</DialogDescription>
                  </DialogHeader>
                  <div>
                    <Label>Reason for returning *</Label>
                    <Textarea placeholder="Explain why this CAPA needs to return to review..." />
                  </div>
                  <DialogFooter>
                    <Button variant="outline">Cancel</Button>
                    <Button variant="destructive" onClick={() => toast({ title: 'Status Updated', description: 'CAPA returned to In Review.' })}>Return to In Review</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </>
          )}

          {/* Verification Actions */}
          {capa.status === 'verification' && (
            <>
              <Button variant="outline" className="w-full gap-2" onClick={() => navigate(`/actionguard/edit/${capa.id}`)}>
                <Pencil className="h-4 w-4" /> Edit CAPA
              </Button>
              <Button variant="outline" className="w-full gap-2" onClick={() => setActiveTab('verification')}>
                <Shield className="h-4 w-4" /> Update Verification
              </Button>
              <Button variant="outline" className="w-full gap-2" onClick={() => setActiveTab('files')}>
                <Folder className="h-4 w-4" /> Attach Evidence
              </Button>
              <Dialog open={showEffectivenessDialog} onOpenChange={setShowEffectivenessDialog}>
                <DialogTrigger asChild>
                  <Button className="w-full gap-2">
                    <ChevronRight className="h-4 w-4" /> Move to Effectiveness
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Move to Effectiveness Monitoring</DialogTitle>
                    <DialogDescription>Confirm that verification is complete and ready for effectiveness monitoring.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <Alert className="bg-blue-500/10 border-blue-500/20">
                      <User className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-blue-600 text-sm">
                        Need to change the owner or department? Use the <span className="font-semibold">Ownership</span> section before proceeding.
                      </AlertDescription>
                    </Alert>
                    <div>
                      <Label>Comments (optional)</Label>
                      <Textarea value={transitionComments} onChange={(e) => setTransitionComments(e.target.value)} placeholder="Add any notes about this transition..." />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setShowEffectivenessDialog(false)}>Cancel</Button>
                    <Button onClick={() => {
                      toast({ title: 'Status Updated', description: 'CAPA moved to Effectiveness Monitoring phase.' });
                      setShowEffectivenessDialog(false);
                      setTransitionComments('');
                    }}>Confirm</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
              <Separator className="my-2" />
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" className="w-full gap-2 text-muted-foreground">
                    <RotateCcw className="h-4 w-4" /> Return to In Progress
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Return to In Progress</DialogTitle>
                    <DialogDescription>This will move the CAPA back to In Progress status for additional work.</DialogDescription>
                  </DialogHeader>
                  <div>
                    <Label>Reason for returning *</Label>
                    <Textarea placeholder="Explain why this CAPA needs to return to in progress..." />
                  </div>
                  <DialogFooter>
                    <Button variant="outline">Cancel</Button>
                    <Button variant="destructive" onClick={() => toast({ title: 'Status Updated', description: 'CAPA returned to In Progress.' })}>Return to In Progress</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </>
          )}

          {/* Effectiveness Monitoring Actions */}
          {capa.status === 'effectiveness_monitoring' && (
            <>
              <Button variant="outline" className="w-full gap-2" onClick={() => navigate(`/actionguard/edit/${capa.id}`)}>
                <Pencil className="h-4 w-4" /> Edit CAPA
              </Button>
              <Button variant="outline" className="w-full gap-2" onClick={() => setActiveTab('effectiveness')}>
                <BarChart3 className="h-4 w-4" /> Update Monitoring
              </Button>
              <Button variant="outline" className="w-full gap-2" onClick={() => setActiveTab('files')}>
                <Folder className="h-4 w-4" /> Attach Evidence
              </Button>
              <Dialog open={showCloseDialog} onOpenChange={setShowCloseDialog}>
                <DialogTrigger asChild>
                  <Button className="w-full gap-2">
                    <CheckCircle2 className="h-4 w-4" /> Close CAPA
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Close CAPA</DialogTitle>
                    <DialogDescription>Confirm that effectiveness monitoring is complete and CAPA can be closed.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <Alert className="bg-blue-500/10 border-blue-500/20">
                      <User className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-blue-600 text-sm">
                        Need to change the owner or department? Use the <span className="font-semibold">Ownership</span> section before closing.
                      </AlertDescription>
                    </Alert>
                    <div>
                      <Label>Closure Notes (optional)</Label>
                      <Textarea value={transitionComments} onChange={(e) => setTransitionComments(e.target.value)} placeholder="Add any final notes about this CAPA..." />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setShowCloseDialog(false)}>Cancel</Button>
                    <Button onClick={() => {
                      toast({ title: 'CAPA Closed', description: 'CAPA has been successfully closed.' });
                      setShowCloseDialog(false);
                      setTransitionComments('');
                    }}>Close CAPA</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
              <Separator className="my-2" />
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" className="w-full gap-2 text-muted-foreground">
                    <RotateCcw className="h-4 w-4" /> Return to Verification
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Return to Verification</DialogTitle>
                    <DialogDescription>This will move the CAPA back to Verification status for additional verification.</DialogDescription>
                  </DialogHeader>
                  <div>
                    <Label>Reason for returning *</Label>
                    <Textarea placeholder="Explain why this CAPA needs to return to verification..." />
                  </div>
                  <DialogFooter>
                    <Button variant="outline">Cancel</Button>
                    <Button variant="destructive" onClick={() => toast({ title: 'Status Updated', description: 'CAPA returned to Verification.' })}>Return to Verification</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </>
          )}

          {/* Closed Actions */}

          {capa.status === 'closed' && (
            <Dialog open={showReopenDialog} onOpenChange={setShowReopenDialog}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full gap-2">
                  <RotateCcw className="h-4 w-4" /> Reopen CAPA
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Reopen CAPA</DialogTitle>
                  <DialogDescription>Provide a reason for reopening this CAPA.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Reason for Reopening *</Label>
                    <Textarea value={transitionComments} onChange={(e) => setTransitionComments(e.target.value)} placeholder="Explain why this CAPA needs to be reopened..." />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowReopenDialog(false)}>Cancel</Button>
                  <Button variant="destructive" onClick={() => {
                    toast({ title: 'CAPA Reopened', description: 'CAPA has been reopened for further action.' });
                    setShowReopenDialog(false);
                    setTransitionComments('');
                  }}>Reopen CAPA</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>

        <Separator className="my-4" />

        {/* Next Steps */}
        <div className="mb-6">
          <h4 className="text-sm font-medium text-muted-foreground mb-3">Next Steps</h4>
          <div className="space-y-2 text-sm">
            {capa.status === 'draft' && (
              <div className="p-2 bg-background rounded-lg">
                <p className="font-medium text-foreground">Complete CAPA form</p>
                <p className="text-xs text-muted-foreground">Fill in required fields and submit for review</p>
              </div>
            )}
            {capa.status === 'approved' && (
              <div className="p-2 bg-cyan-500/10 rounded-lg border border-cyan-500/20">
                <p className="font-medium text-cyan-600">Begin action execution</p>
                <p className="text-xs text-cyan-600/70">Start working on corrective and preventive actions</p>
              </div>
            )}
            {capa.status === 'in_progress' && (
              <>
                {[...capa.correctiveActions, ...capa.preventiveActions]
                  .filter(a => a.status !== 'done')
                  .slice(0, 3)
                  .map((action) => (
                    <div key={action.id} className="p-2 bg-background rounded-lg">
                      <p className="font-medium text-foreground line-clamp-1">{action.title}</p>
                      <p className="text-xs text-muted-foreground">Due: {new Date(action.dueDate).toLocaleDateString()}</p>
                    </div>
                  ))}
                {[...capa.correctiveActions, ...capa.preventiveActions].filter(a => a.status !== 'done').length === 0 && (
                  <div className="p-2 bg-green-500/10 rounded-lg border border-green-500/20">
                    <p className="font-medium text-green-600">All actions complete</p>
                    <p className="text-xs text-green-600/70">Ready to move to verification</p>
                  </div>
                )}
              </>
            )}
            {capa.status === 'verification' && (
              <div className="p-2 bg-purple-500/10 rounded-lg border border-purple-500/20">
                <p className="font-medium text-purple-600">Complete verification checks</p>
                <p className="text-xs text-purple-600/70">Verify each action was implemented correctly</p>
              </div>
            )}
            {capa.status === 'effectiveness_monitoring' && (
              <div className="p-2 bg-indigo-500/10 rounded-lg border border-indigo-500/20">
                <p className="font-medium text-indigo-600">Monitor effectiveness</p>
                <p className="text-xs text-indigo-600/70">Track metrics and record monitoring entries</p>
              </div>
            )}
            {capa.status === 'reopened' && (
              <div className="p-2 bg-red-500/10 rounded-lg border border-red-500/20">
                <p className="font-medium text-red-600">Address reopened issues</p>
                <p className="text-xs text-red-600/70">Review failure reason and update action plan</p>
              </div>
            )}
            {isPocOverdue && (
              <div className="p-2 bg-red-500/10 rounded-lg border border-red-500/20">
                <p className="font-medium text-red-600">Submit PoC immediately</p>
                <p className="text-xs text-red-600/70">PoC is overdue</p>
              </div>
            )}
          </div>
        </div>

        <Separator className="my-4" />

        {/* Ownership */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-medium text-muted-foreground">Ownership</h4>
            <Dialog open={showEditOwnerDialog} onOpenChange={setShowEditOwnerDialog}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="sm" className="h-6 px-2">
                  <Pencil className="h-3 w-3" />
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-background">
                <DialogHeader>
                  <DialogTitle>Edit Ownership</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Owner (Assignee)</Label>
                    <Select value={editOwner || capa.owner} onValueChange={setEditOwner}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-background">
                        {staffUsers.map((u) => (
                          <SelectItem key={u.id} value={u.name}>{u.name} ({u.role})</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Department Head</Label>
                    <Select value={editDeptHead || capa.departmentHead || ''} onValueChange={setEditDeptHead}>
                      <SelectTrigger><SelectValue placeholder="Select department head" /></SelectTrigger>
                      <SelectContent className="bg-background">
                        {departmentHeads.map((u) => (
                          <SelectItem key={u.id} value={u.name}>{u.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Compliance Head</Label>
                    <Select value={editCompHead || capa.complianceHead || ''} onValueChange={setEditCompHead}>
                      <SelectTrigger><SelectValue placeholder="Select compliance head" /></SelectTrigger>
                      <SelectContent className="bg-background">
                        {complianceHeads.map((u) => (
                          <SelectItem key={u.id} value={u.name}>{u.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowEditOwnerDialog(false)}>Cancel</Button>
                  <Button onClick={handleSaveOwnership}>Save</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Owner</p>
                <p className="font-medium">{editOwner || capa.owner}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Dept Head</p>
                <p className="font-medium">{editDeptHead || capa.departmentHead || '-'}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Compliance Head</p>
                <p className="font-medium">{editCompHead || capa.complianceHead || '-'}</p>
              </div>
            </div>
          </div>
        </div>

        <Separator className="my-4" />

        {/* Department */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-medium text-muted-foreground">Department</h4>
            <Dialog open={showEditDeptDialog} onOpenChange={setShowEditDeptDialog}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="sm" className="h-6 px-2">
                  <Pencil className="h-3 w-3" />
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-background">
                <DialogHeader>
                  <DialogTitle>Edit Department</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Department</Label>
                    <Select value={editDepartment || capa.department} onValueChange={setEditDepartment}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-background">
                        {departments.map((d) => (
                          <SelectItem key={d} value={d}>{d.charAt(0).toUpperCase() + d.slice(1).replace('_', ' ')}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowEditDeptDialog(false)}>Cancel</Button>
                  <Button onClick={handleSaveDepartment}>Save</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Building2 className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{(editDepartment || capa.department).charAt(0).toUpperCase() + (editDepartment || capa.department).slice(1).replace('_', ' ')}</span>
          </div>
        </div>

        <Separator className="my-4" />

        {/* Cross-References */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-medium text-muted-foreground">Cross-References</h4>
            <Dialog open={showLinkDialog} onOpenChange={setShowLinkDialog}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="sm" className="h-6 px-2 gap-1">
                  <Plus className="h-3 w-3" />
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl bg-background">
                <DialogHeader>
                  <DialogTitle>Link to External Item</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Filter by Module</Label>
                    <Select value={selectedMicroapp || 'all'} onValueChange={(v) => setSelectedMicroapp(v === 'all' ? '' : v as MicroappType)}>
                      <SelectTrigger><SelectValue placeholder="All modules" /></SelectTrigger>
                      <SelectContent className="bg-background">
                        <SelectItem value="all">All Modules</SelectItem>
                        {microappConfigs.filter(m => m.id !== 'actionguard').map((m) => (
                          <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="max-h-80 overflow-y-auto space-y-2">
                    {filteredCrossRefItems.filter(i => i.microapp !== 'actionguard').map((item) => {
                      const isLinked = linkedItems.some(l => l.id === item.id);
                      const config = microappConfigs.find(m => m.id === item.microapp);
                      return (
                        <div 
                          key={item.id}
                          className={`p-3 border rounded-lg cursor-pointer transition-colors ${isLinked ? 'border-primary bg-primary/5' : 'hover:border-primary/50'}`}
                          onClick={() => !isLinked && addLinkedItem(item)}
                        >
                          <div className="flex items-start gap-3">
                            <div className={`p-1.5 rounded ${getMicroappColor(item.microapp)}`}>
                              {getMicroappIcon(item.microapp)}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <Badge variant="outline" className="text-xs">{config?.name}</Badge>
                                <span className="text-xs text-muted-foreground">{item.id}</span>
                                {isLinked && <Badge variant="default" className="text-xs">Linked</Badge>}
                              </div>
                              <p className="font-medium text-sm">{item.title}</p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          
          {linkedItems.length > 0 ? (
            <div className="space-y-2">
              {linkedItems.map((item) => {
                const config = microappConfigs.find(m => m.id === item.microapp);
                return (
                  <div key={item.id} className="flex items-center gap-2 p-2 bg-background rounded-lg text-sm">
                    <div className={`p-1 rounded ${getMicroappColor(item.microapp)}`}>
                      {getMicroappIcon(item.microapp)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{item.title}</p>
                      <p className="text-xs text-muted-foreground">{config?.name} • {item.id}</p>
                    </div>
                    <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => removeLinkedItem(item.id)}>
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">No cross-references linked</p>
          )}
        </div>

        <Separator className="my-4" />

        {/* Key Dates */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-muted-foreground">Key Dates</h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Due Date</span>
              <span className={`font-medium ${isOverdue ? 'text-red-600' : ''}`}>
                {new Date(capa.dueDate).toLocaleDateString()}
              </span>
            </div>
            {capa.effectivenessDueDate && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Effectiveness Due</span>
                <span className="font-medium">{new Date(capa.effectivenessDueDate).toLocaleDateString()}</span>
              </div>
            )}
            {isCmsSurvey && capa.surveyPocData?.pocDueDate && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">PoC Due</span>
                <span className={`font-medium ${isPocOverdue ? 'text-red-600' : ''}`}>
                  {new Date(capa.surveyPocData.pocDueDate).toLocaleDateString()}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* CRUD Dialogs */}
      <ContainmentDialog open={showContainmentDialog} onOpenChange={setShowContainmentDialog} action={selectedContainment} onSave={() => {}} mode={crudMode} />
      <RootCauseDialog open={showRootCauseDialog} onOpenChange={setShowRootCauseDialog} rootCause={selectedRootCause} onSave={() => {}} mode={crudMode} />
      <ActionDialog open={showCorrectiveActionDialog} onOpenChange={setShowCorrectiveActionDialog} action={selectedAction} onSave={() => {}} mode={crudMode} actionType="corrective" />
      <ActionDialog open={showPreventiveActionDialog} onOpenChange={setShowPreventiveActionDialog} action={selectedAction} onSave={() => {}} mode={crudMode} actionType="preventive" />
      <VerificationStepDialog open={showVerificationStepDialog} onOpenChange={setShowVerificationStepDialog} step={selectedVerificationStep} onSave={() => {}} mode={crudMode} />
      <EffectivenessCriteriaDialog open={showEffectivenessCriteriaDialog} onOpenChange={setShowEffectivenessCriteriaDialog} criteria={selectedEffectivenessCriteria} onSave={() => {}} mode={crudMode} />
      <MonitoringEntryDialog open={showMonitoringEntryDialog} onOpenChange={setShowMonitoringEntryDialog} entry={selectedMonitoringEntry} onSave={() => {}} mode={crudMode} />
      <FileAttachmentDialog open={showFileAttachmentDialog} onOpenChange={setShowFileAttachmentDialog} onSave={() => {}} />
      <DeleteConfirmDialog open={showDeleteConfirmDialog} onOpenChange={setShowDeleteConfirmDialog} onConfirm={handleConfirmDelete} itemType={deleteItemType} />
    </div>
  );
}
