import { useState, useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ClipboardCheck, Plus, Search, Filter, AlertTriangle, Clock, Building2, User, Calendar, ChevronDown, X, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DropdownMenu, DropdownMenuContent, DropdownMenuCheckboxItem, DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuLabel } from '@/components/ui/dropdown-menu';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { mockCapasNew, mockActionGuardStats, originTypeLabels } from '@/data/actionguardMockData';
import { CapaStatusNew, CapaOriginTypeNew } from '@/types/actionguard';
import { 
  BUCKET_STATUSES, 
  BUCKET_LABELS, 
  BucketTabBadge, 
  CapaBucket,
  PhaseTooltip,
  PHASE_DEFINITIONS
} from '@/components/actionguard/CapaBucketHelpers';

const statusOptions: { value: CapaStatusNew; label: string }[] = [
  { value: 'draft', label: 'Draft' },
  { value: 'submitted', label: 'Submitted' },
  { value: 'in_review', label: 'In Review' },
  { value: 'approved', label: 'Approved' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'verification', label: 'Verification' },
  { value: 'effectiveness_monitoring', label: 'Effectiveness Monitoring' },
  { value: 'closed', label: 'Closed' },
  { value: 'reopened', label: 'Reopened' },
];

const severityOptions = ['low', 'medium', 'high', 'critical'];
const facilities = ['Main Hospital', 'Downtown Clinic', 'Sunrise Nursing Home'];

export default function ActionGuardList() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  
  // Get bucket from URL or default to 'new'
  const initialBucket = (searchParams.get('bucket') as CapaBucket) || 'new';
  const [activeBucket, setActiveBucket] = useState<CapaBucket>(initialBucket);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<CapaStatusNew[]>(
    searchParams.get('status') ? [searchParams.get('status') as CapaStatusNew] : []
  );
  const [originFilter, setOriginFilter] = useState<CapaOriginTypeNew[]>([]);
  const [severityFilter, setSeverityFilter] = useState<string[]>([]);
  const [facilityFilter, setFacilityFilter] = useState('');
  const [showOverdueOnly, setShowOverdueOnly] = useState(searchParams.get('overdue') === 'true');

  // Count CAPAs by bucket
  const bucketCounts = useMemo(() => ({
    new: mockCapasNew.filter(c => BUCKET_STATUSES.new.includes(c.status)).length,
    open: mockCapasNew.filter(c => BUCKET_STATUSES.open.includes(c.status)).length,
    closed: mockCapasNew.filter(c => BUCKET_STATUSES.closed.includes(c.status)).length,
  }), []);

  // Filter CAPAs based on bucket and other filters
  const filteredCapas = useMemo(() => {
    return mockCapasNew.filter(capa => {
      // Bucket filter (always applied)
      if (!BUCKET_STATUSES[activeBucket].includes(capa.status)) {
        return false;
      }
      // Search
      if (searchQuery && !capa.title.toLowerCase().includes(searchQuery.toLowerCase()) && 
          !capa.problemStatement.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !capa.id.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      // Status (within bucket)
      if (statusFilter.length > 0 && !statusFilter.includes(capa.status)) {
        return false;
      }
      // Origin
      if (originFilter.length > 0 && !originFilter.includes(capa.originType)) {
        return false;
      }
      // Severity
      if (severityFilter.length > 0 && !severityFilter.includes(capa.severity)) {
        return false;
      }
      // Facility
      if (facilityFilter && capa.facility !== facilityFilter) {
        return false;
      }
      // Overdue
      if (showOverdueOnly) {
        const isOverdue = new Date(capa.dueDate) < new Date() && capa.status !== 'closed';
        if (!isOverdue) return false;
      }
      return true;
    });
  }, [activeBucket, searchQuery, statusFilter, originFilter, severityFilter, facilityFilter, showOverdueOnly]);

  // Sort based on bucket
  const sortedCapas = useMemo(() => {
    return [...filteredCapas].sort((a, b) => {
      if (activeBucket === 'new') {
        // Newest first, then review SLA due soon
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      } else if (activeBucket === 'open') {
        // Overdue first, then due soon, then severity
        const aOverdue = new Date(a.dueDate) < new Date() ? 1 : 0;
        const bOverdue = new Date(b.dueDate) < new Date() ? 1 : 0;
        if (aOverdue !== bOverdue) return bOverdue - aOverdue;
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      } else {
        // Recently closed first
        return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
      }
    });
  }, [filteredCapas, activeBucket]);

  const handleBucketChange = (bucket: CapaBucket) => {
    setActiveBucket(bucket);
    setStatusFilter([]); // Reset status filter when changing buckets
    setSearchParams({ bucket });
  };

  const getStatusColor = (status: CapaStatusNew) => {
    switch (status) {
      case 'closed': return 'bg-green-500/10 text-green-600 border-green-500/20';
      case 'in_progress': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'verification': return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
      case 'effectiveness_monitoring': return 'bg-indigo-500/10 text-indigo-600 border-indigo-500/20';
      case 'approved': return 'bg-cyan-500/10 text-cyan-600 border-cyan-500/20';
      case 'draft': return 'bg-gray-500/10 text-gray-600 border-gray-500/20';
      case 'submitted': case 'in_review': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      case 'reopened': return 'bg-red-500/10 text-red-600 border-red-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500/10 text-red-600 border-red-500/20';
      case 'high': return 'bg-orange-500/10 text-orange-600 border-orange-500/20';
      case 'medium': return 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20';
      default: return 'bg-green-500/10 text-green-600 border-green-500/20';
    }
  };

  const clearFilters = () => {
    setStatusFilter([]);
    setOriginFilter([]);
    setSeverityFilter([]);
    setFacilityFilter('');
    setShowOverdueOnly(false);
  };

  const hasActiveFilters = statusFilter.length > 0 || originFilter.length > 0 || severityFilter.length > 0 || facilityFilter || showOverdueOnly;

  // Get status options for current bucket
  const bucketStatusOptions = statusOptions.filter(opt => BUCKET_STATUSES[activeBucket].includes(opt.value));

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">CAPAs</h1>
          <p className="text-muted-foreground">Corrective and Preventive Action Management</p>
        </div>
        <Button onClick={() => navigate('/actionguard/new')} className="gap-2">
          <Plus className="h-4 w-4" />
          New CAPA
        </Button>
      </div>

      {/* Bucket Tabs */}
      <Tabs value={activeBucket} onValueChange={(v) => handleBucketChange(v as CapaBucket)} className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="new" className="gap-2">
            NEW
            <BucketTabBadge bucket="new" count={bucketCounts.new} />
          </TabsTrigger>
          <TabsTrigger value="open" className="gap-2">
            OPEN
            <BucketTabBadge bucket="open" count={bucketCounts.open} />
          </TabsTrigger>
          <TabsTrigger value="closed" className="gap-2">
            CLOSED
            <BucketTabBadge bucket="closed" count={bucketCounts.closed} />
          </TabsTrigger>
        </TabsList>

        {/* Tab description */}
        <p className="text-sm text-muted-foreground mt-2">{BUCKET_LABELS[activeBucket].description}</p>
      </Tabs>

      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search CAPAs by title, ID, or problem statement..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <div className="flex gap-2 flex-wrap">
          {/* Status Filter (within bucket) */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                Phase {statusFilter.length > 0 && `(${statusFilter.length})`}
                <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 bg-background">
              <DropdownMenuLabel>Filter by Phase</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {bucketStatusOptions.map(option => (
                <DropdownMenuCheckboxItem
                  key={option.value}
                  checked={statusFilter.includes(option.value)}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setStatusFilter([...statusFilter, option.value]);
                    } else {
                      setStatusFilter(statusFilter.filter(s => s !== option.value));
                    }
                  }}
                >
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span className="flex items-center gap-2">
                        {option.label}
                        <Info className="h-3 w-3 text-muted-foreground" />
                      </span>
                    </TooltipTrigger>
                    <TooltipContent>{PHASE_DEFINITIONS[option.value].definition}</TooltipContent>
                  </Tooltip>
                </DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Origin Filter */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                Origin {originFilter.length > 0 && `(${originFilter.length})`}
                <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-64 bg-background">
              <DropdownMenuLabel>Filter by Origin Type</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {Object.entries(originTypeLabels).map(([value, label]) => (
                <DropdownMenuCheckboxItem
                  key={value}
                  checked={originFilter.includes(value as CapaOriginTypeNew)}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setOriginFilter([...originFilter, value as CapaOriginTypeNew]);
                    } else {
                      setOriginFilter(originFilter.filter(o => o !== value));
                    }
                  }}
                >
                  {label}
                </DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Severity Filter */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                Severity {severityFilter.length > 0 && `(${severityFilter.length})`}
                <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-background">
              <DropdownMenuLabel>Filter by Severity</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {severityOptions.map(option => (
                <DropdownMenuCheckboxItem
                  key={option}
                  checked={severityFilter.includes(option)}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setSeverityFilter([...severityFilter, option]);
                    } else {
                      setSeverityFilter(severityFilter.filter(s => s !== option));
                    }
                  }}
                >
                  {option.charAt(0).toUpperCase() + option.slice(1)}
                </DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Facility Filter */}
          <Select value={facilityFilter || 'all'} onValueChange={(v) => setFacilityFilter(v === 'all' ? '' : v)}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Facility" />
            </SelectTrigger>
            <SelectContent className="bg-background">
              <SelectItem value="all">All Facilities</SelectItem>
              {facilities.map(f => (
                <SelectItem key={f} value={f}>{f}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {activeBucket === 'open' && (
            <Button 
              variant={showOverdueOnly ? "destructive" : "outline"} 
              onClick={() => setShowOverdueOnly(!showOverdueOnly)}
              className="gap-1"
            >
              <AlertTriangle className="h-4 w-4" />
              Overdue Only
            </Button>
          )}

          {hasActiveFilters && (
            <Button variant="ghost" onClick={clearFilters} className="gap-1">
              <X className="h-4 w-4" /> Clear
            </Button>
          )}
        </div>
      </div>

      {/* Active Filter Chips */}
      {hasActiveFilters && (
        <div className="flex flex-wrap gap-2">
          {statusFilter.map(status => (
            <Badge key={status} variant="secondary" className="gap-1">
              Phase: {status.replace('_', ' ')}
              <X className="h-3 w-3 cursor-pointer" onClick={() => setStatusFilter(statusFilter.filter(s => s !== status))} />
            </Badge>
          ))}
          {originFilter.map(origin => (
            <Badge key={origin} variant="secondary" className="gap-1">
              Origin: {originTypeLabels[origin]}
              <X className="h-3 w-3 cursor-pointer" onClick={() => setOriginFilter(originFilter.filter(o => o !== origin))} />
            </Badge>
          ))}
          {severityFilter.map(severity => (
            <Badge key={severity} variant="secondary" className="gap-1">
              Severity: {severity}
              <X className="h-3 w-3 cursor-pointer" onClick={() => setSeverityFilter(severityFilter.filter(s => s !== severity))} />
            </Badge>
          ))}
          {facilityFilter && (
            <Badge variant="secondary" className="gap-1">
              Facility: {facilityFilter}
              <X className="h-3 w-3 cursor-pointer" onClick={() => setFacilityFilter('')} />
            </Badge>
          )}
          {showOverdueOnly && (
            <Badge variant="secondary" className="gap-1 bg-red-500/10 text-red-600">
              Overdue Only
              <X className="h-3 w-3 cursor-pointer" onClick={() => setShowOverdueOnly(false)} />
            </Badge>
          )}
        </div>
      )}

      {/* Results count */}
      <p className="text-sm text-muted-foreground">
        Showing {sortedCapas.length} of {bucketCounts[activeBucket]} {BUCKET_LABELS[activeBucket].label} CAPAs
      </p>

      {/* CAPA Table - Tab-specific columns */}
      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Department</TableHead>
              <TableHead>Severity</TableHead>
              <TableHead>Owner</TableHead>
              {activeBucket === 'new' && (
                <>
                  <TableHead>Submitted</TableHead>
                  <TableHead>Review SLA</TableHead>
                </>
              )}
              {activeBucket === 'open' && (
                <>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Overdue Actions</TableHead>
                  <TableHead>Verification</TableHead>
                </>
              )}
              {activeBucket === 'closed' && (
                <>
                  <TableHead>Closed Date</TableHead>
                  <TableHead>Cycle Time</TableHead>
                  <TableHead>Origin</TableHead>
                </>
              )}
              <TableHead>
                <Tooltip>
                  <TooltipTrigger className="flex items-center gap-1">
                    Phase <Info className="h-3 w-3" />
                  </TooltipTrigger>
                  <TooltipContent>Current workflow phase</TooltipContent>
                </Tooltip>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedCapas.map((capa) => {
              const isOverdue = new Date(capa.dueDate) < new Date() && capa.status !== 'closed';
              const isPocOverdue = capa.originType === 'cms_state_survey' && 
                capa.surveyPocData?.pocDueDate && 
                new Date(capa.surveyPocData.pocDueDate) < new Date() && 
                !capa.surveyPocData.pocSubmissionDate;
              const totalActions = capa.correctiveActions.length + capa.preventiveActions.length;
              const completedActions = [...capa.correctiveActions, ...capa.preventiveActions].filter(a => a.status === 'done').length;
              const overdueActions = [...capa.correctiveActions, ...capa.preventiveActions].filter(a => 
                a.status !== 'done' && a.status !== 'cancelled' && new Date(a.dueDate) < new Date()
              ).length;
              const verificationComplete = capa.status === 'effectiveness_monitoring' || capa.status === 'closed';
              
              // Calculate cycle time for closed CAPAs
              const cycleTime = capa.status === 'closed' 
                ? Math.ceil((new Date(capa.updatedAt).getTime() - new Date(capa.createdAt).getTime()) / (1000 * 60 * 60 * 24))
                : null;

              // Calculate review SLA for NEW CAPAs
              const reviewSla = capa.submittedAt 
                ? Math.ceil((new Date().getTime() - new Date(capa.submittedAt).getTime()) / (1000 * 60 * 60 * 24))
                : null;

              return (
                <TableRow 
                  key={capa.id} 
                  className={`cursor-pointer hover:bg-muted/50 ${isPocOverdue ? 'bg-red-500/5' : isOverdue ? 'bg-amber-500/5' : ''}`}
                  onClick={() => navigate(`/actionguard/${capa.id}`)}
                >
                  <TableCell>
                    <div>
                      <p className="font-medium">{capa.title}</p>
                      <p className="text-xs text-muted-foreground">{capa.id}</p>
                    </div>
                  </TableCell>
                  <TableCell>{capa.department}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={getSeverityColor(capa.severity)}>
                      {capa.severity}
                    </Badge>
                  </TableCell>
                  <TableCell>{capa.owner}</TableCell>
                  
                  {activeBucket === 'new' && (
                    <>
                      <TableCell>
                        {capa.submittedAt ? new Date(capa.submittedAt).toLocaleDateString() : '-'}
                      </TableCell>
                      <TableCell>
                        {reviewSla !== null ? (
                          <span className={reviewSla > 2 ? 'text-red-600 font-medium' : reviewSla > 1 ? 'text-amber-600' : ''}>
                            {reviewSla}d ago
                          </span>
                        ) : '-'}
                      </TableCell>
                    </>
                  )}
                  
                  {activeBucket === 'open' && (
                    <>
                      <TableCell>
                        <span className={isOverdue ? 'text-red-600 font-medium' : ''}>
                          {new Date(capa.dueDate).toLocaleDateString()}
                          {isOverdue && ' (OVERDUE)'}
                        </span>
                      </TableCell>
                      <TableCell>
                        {overdueActions > 0 ? (
                          <Badge variant="outline" className="bg-red-500/10 text-red-600 border-red-500/20">
                            {overdueActions} overdue
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground">{completedActions}/{totalActions}</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={verificationComplete 
                          ? 'bg-green-500/10 text-green-600 border-green-500/20' 
                          : 'bg-muted text-muted-foreground'
                        }>
                          {verificationComplete ? 'Complete' : 'Pending'}
                        </Badge>
                      </TableCell>
                    </>
                  )}
                  
                  {activeBucket === 'closed' && (
                    <>
                      <TableCell>{new Date(capa.updatedAt).toLocaleDateString()}</TableCell>
                      <TableCell>{cycleTime}d</TableCell>
                      <TableCell>
                        <Badge variant="outline">{originTypeLabels[capa.originType]}</Badge>
                      </TableCell>
                    </>
                  )}
                  
                  <TableCell>
                    <Badge variant="outline" className={getStatusColor(capa.status)}>
                      <PhaseTooltip status={capa.status} />
                    </Badge>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Card>

      {sortedCapas.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <ClipboardCheck className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="font-semibold text-foreground mb-1">No {BUCKET_LABELS[activeBucket].label} CAPAs found</h3>
            <p className="text-sm text-muted-foreground">Try adjusting your search or filters</p>
            {hasActiveFilters && (
              <Button variant="outline" onClick={clearFilters} className="mt-4">
                Clear all filters
              </Button>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
