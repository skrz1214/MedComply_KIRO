import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Calendar, AlertTriangle, CheckCircle2, Clock, ChevronRight, ClipboardList, FileText, Activity } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { mockCapasNew, mockActionGuardUsers, actionTypeLabels } from '@/data/actionguardMockData';

// Simulated current user
const currentUser = mockActionGuardUsers[5]; // Amanda Foster - Staff

export default function ActionGuardMyWork() {
  const navigate = useNavigate();

  // CAPAs owned by current user
  const myCapas = mockCapasNew.filter(c => c.owner === currentUser.name);

  // Actions assigned to current user across all CAPAs
  const myActions: { capaId: string; capaTitle: string; action: any; type: 'corrective' | 'preventive' }[] = [];
  mockCapasNew.forEach(capa => {
    capa.correctiveActions.forEach(action => {
      if (action.owner === currentUser.name) {
        myActions.push({ capaId: capa.id, capaTitle: capa.title, action, type: 'corrective' });
      }
    });
    capa.preventiveActions.forEach(action => {
      if (action.owner === currentUser.name) {
        myActions.push({ capaId: capa.id, capaTitle: capa.title, action, type: 'preventive' });
      }
    });
  });

  // CAPAs with changes requested (returned to draft)
  const changesRequested = mockCapasNew.filter(c => 
    c.owner === currentUser.name && 
    c.status === 'draft' && 
    c.approvals.some(a => a.decision === 'request_changes')
  );

  // Overdue items
  const overdueActions = myActions.filter(item => 
    new Date(item.action.dueDate) < new Date() && 
    item.action.status !== 'done' && 
    item.action.status !== 'cancelled'
  );

  const pendingActions = myActions.filter(item => 
    item.action.status !== 'done' && item.action.status !== 'cancelled'
  );

  const completedActions = myActions.filter(item => item.action.status === 'done');

  const getActionStatusColor = (status: string) => {
    switch (status) {
      case 'done': return 'bg-green-500/10 text-green-600 border-green-500/20';
      case 'in_progress': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'blocked': return 'bg-red-500/10 text-red-600 border-red-500/20';
      case 'cancelled': return 'bg-gray-500/10 text-gray-600 border-gray-500/20';
      default: return 'bg-gray-500/10 text-gray-600 border-gray-500/20';
    }
  };

  const isOverdue = (dueDate: Date) => new Date(dueDate) < new Date();

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">My Work</h1>
          <p className="text-muted-foreground">Your assigned CAPAs and actions</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <User className="h-4 w-4" />
          Logged in as: <span className="font-medium text-foreground">{currentUser.name}</span>
          <Badge variant="outline">{currentUser.role}</Badge>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <ClipboardList className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{myCapas.length}</p>
                <p className="text-sm text-muted-foreground">My CAPAs</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10">
                <Activity className="h-5 w-5 text-amber-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{pendingActions.length}</p>
                <p className="text-sm text-muted-foreground">Pending Actions</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-red-500/10">
                <AlertTriangle className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-red-600">{overdueActions.length}</p>
                <p className="text-sm text-muted-foreground">Overdue</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/10">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-green-600">{completedActions.length}</p>
                <p className="text-sm text-muted-foreground">Completed</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Changes Requested Alert */}
      {changesRequested.length > 0 && (
        <Card className="border-amber-500 bg-amber-500/5">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2 text-amber-700">
              <AlertTriangle className="h-5 w-5" />
              Changes Requested
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {changesRequested.map(capa => (
                <div 
                  key={capa.id}
                  className="p-3 border border-amber-500/30 rounded-lg hover:bg-amber-500/10 cursor-pointer"
                  onClick={() => navigate(`/actionguard/${capa.id}`)}
                >
                  <p className="font-medium text-foreground">{capa.title}</p>
                  <p className="text-sm text-amber-700">
                    {capa.approvals.find(a => a.decision === 'request_changes')?.comments || 'Review required'}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="actions">
        <TabsList>
          <TabsTrigger value="actions">My Actions ({pendingActions.length})</TabsTrigger>
          <TabsTrigger value="capas">My CAPAs ({myCapas.length})</TabsTrigger>
          <TabsTrigger value="completed">Completed ({completedActions.length})</TabsTrigger>
        </TabsList>

        {/* Actions Tab */}
        <TabsContent value="actions" className="space-y-4 mt-4">
          {pendingActions.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="p-8 text-center">
                <CheckCircle2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="font-semibold text-foreground mb-1">All caught up!</h3>
                <p className="text-sm text-muted-foreground">No pending actions assigned to you</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {/* Overdue First */}
              {overdueActions.length > 0 && (
                <div className="space-y-2">
                  <h3 className="text-sm font-medium text-red-600 flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" /> Overdue ({overdueActions.length})
                  </h3>
                  {overdueActions.map(item => (
                    <Card key={item.action.id} className="border-red-500/50 hover:border-red-500 transition-colors">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant="outline" className={getActionStatusColor(item.action.status)}>
                                {item.action.status.replace('_', ' ')}
                              </Badge>
                              <Badge variant="outline" className={item.type === 'corrective' ? 'bg-red-500/10 text-red-600' : 'bg-blue-500/10 text-blue-600'}>
                                {item.type}
                              </Badge>
                              <Badge variant="outline">{actionTypeLabels[item.action.actionType]}</Badge>
                            </div>
                            <h4 className="font-medium text-foreground">{item.action.title}</h4>
                            <p className="text-sm text-muted-foreground mt-1">
                              CAPA: <span className="text-primary cursor-pointer hover:underline" onClick={() => navigate(`/actionguard/${item.capaId}`)}>{item.capaTitle}</span>
                            </p>
                            <div className="flex items-center gap-2 mt-2 text-xs text-red-600">
                              <Calendar className="h-3 w-3" />
                              Due: {new Date(item.action.dueDate).toLocaleDateString()} (OVERDUE)
                            </div>
                          </div>
                          <Button size="sm" onClick={() => navigate(`/actionguard/${item.capaId}`)}>
                            Work on This
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {/* Not Overdue */}
              {pendingActions.filter(item => !isOverdue(item.action.dueDate)).length > 0 && (
                <div className="space-y-2">
                  <h3 className="text-sm font-medium text-muted-foreground">Upcoming</h3>
                  {pendingActions
                    .filter(item => !isOverdue(item.action.dueDate))
                    .sort((a, b) => new Date(a.action.dueDate).getTime() - new Date(b.action.dueDate).getTime())
                    .map(item => (
                      <Card key={item.action.id} className="hover:border-primary/50 transition-colors">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <Badge variant="outline" className={getActionStatusColor(item.action.status)}>
                                  {item.action.status.replace('_', ' ')}
                                </Badge>
                                <Badge variant="outline" className={item.type === 'corrective' ? 'bg-red-500/10 text-red-600' : 'bg-blue-500/10 text-blue-600'}>
                                  {item.type}
                                </Badge>
                              </div>
                              <h4 className="font-medium text-foreground">{item.action.title}</h4>
                              <p className="text-sm text-muted-foreground mt-1">
                                CAPA: <span className="text-primary cursor-pointer hover:underline" onClick={() => navigate(`/actionguard/${item.capaId}`)}>{item.capaTitle}</span>
                              </p>
                              <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                                <Calendar className="h-3 w-3" />
                                Due: {new Date(item.action.dueDate).toLocaleDateString()}
                              </div>
                            </div>
                            <Button size="sm" variant="outline" onClick={() => navigate(`/actionguard/${item.capaId}`)}>
                              View <ChevronRight className="h-4 w-4 ml-1" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              )}
            </div>
          )}
        </TabsContent>

        {/* My CAPAs Tab */}
        <TabsContent value="capas" className="space-y-4 mt-4">
          {myCapas.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="p-8 text-center">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="font-semibold text-foreground mb-1">No CAPAs assigned</h3>
                <p className="text-sm text-muted-foreground">You are not the owner of any CAPAs</p>
              </CardContent>
            </Card>
          ) : (
            myCapas.map(capa => {
              const totalActions = capa.correctiveActions.length + capa.preventiveActions.length;
              const completedActions = [...capa.correctiveActions, ...capa.preventiveActions].filter(a => a.status === 'done').length;
              const progress = totalActions > 0 ? (completedActions / totalActions) * 100 : 0;

              return (
                <Card 
                  key={capa.id} 
                  className="hover:border-primary/50 transition-colors cursor-pointer"
                  onClick={() => navigate(`/actionguard/${capa.id}`)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className={
                            capa.status === 'closed' ? 'bg-green-500/10 text-green-600 border-green-500/20' :
                            capa.status === 'in_progress' ? 'bg-blue-500/10 text-blue-600 border-blue-500/20' :
                            capa.status === 'draft' ? 'bg-gray-500/10 text-gray-600 border-gray-500/20' :
                            'bg-amber-500/10 text-amber-600 border-amber-500/20'
                          }>
                            {capa.status.replace('_', ' ')}
                          </Badge>
                          <Badge variant="outline" className={
                            capa.severity === 'critical' ? 'bg-red-500/10 text-red-600' :
                            capa.severity === 'high' ? 'bg-orange-500/10 text-orange-600' :
                            'bg-yellow-500/10 text-yellow-600'
                          }>
                            {capa.severity}
                          </Badge>
                        </div>
                        <h3 className="font-semibold text-foreground">{capa.title}</h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {capa.facility} • Due: {new Date(capa.dueDate).toLocaleDateString()}
                        </p>
                        <div className="mt-3">
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-muted-foreground">Progress</span>
                            <span>{completedActions}/{totalActions} actions</span>
                          </div>
                          <Progress value={progress} className="h-2" />
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 text-muted-foreground" />
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </TabsContent>

        {/* Completed Tab */}
        <TabsContent value="completed" className="space-y-4 mt-4">
          {completedActions.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground">No completed actions yet</p>
              </CardContent>
            </Card>
          ) : (
            completedActions.map(item => (
              <Card key={item.action.id} className="opacity-75 hover:opacity-100 transition-opacity">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/20">
                          <CheckCircle2 className="h-3 w-3 mr-1" /> Done
                        </Badge>
                        <Badge variant="outline">{item.type}</Badge>
                      </div>
                      <h4 className="font-medium text-foreground">{item.action.title}</h4>
                      <p className="text-sm text-muted-foreground">
                        Completed: {item.action.completedAt ? new Date(item.action.completedAt).toLocaleDateString() : 'N/A'}
                      </p>
                    </div>
                    <Button size="sm" variant="ghost" onClick={() => navigate(`/actionguard/${item.capaId}`)}>
                      View CAPA
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
