import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Check, Save, AlertTriangle, Calendar, Plus, Trash2, Info, Link2, X, Shield, FileSearch, MessageSquare, Scale, ClipboardList, BookOpen, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';
import { CapaOriginTypeNew, CapaActionType, RcaMethodNew, ContributingFactor, PatientRisk, VerificationType } from '@/types/actionguard';
import { Priority } from '@/types/compliance';
import { originTypeLabels, actionTypeLabels, mockActionGuardUsers } from '@/data/actionguardMockData';
import { microappConfigs, CrossReferenceItemType, MicroappType } from '@/types/crossReference';

const STEPS = [
  { id: 1, title: 'Basics', description: 'Origin, location, severity' },
  { id: 2, title: 'Containment', description: 'Immediate actions' },
  { id: 3, title: 'RCA', description: 'Root cause analysis' },
  { id: 4, title: 'Action Plan', description: 'Corrective & preventive' },
  { id: 5, title: 'Verification', description: 'Verification & effectiveness' },
  { id: 6, title: 'QAPI', description: 'Quality improvement' },
  { id: 7, title: 'Review', description: 'Review & submit' },
];

const facilities = [
  { id: 'fac-1', name: 'Main Hospital', units: ['ICU', 'Med-Surg', 'Emergency', 'Pediatrics'] },
  { id: 'fac-2', name: 'Downtown Clinic', units: ['Outpatient', 'Urgent Care'] },
  { id: 'fac-3', name: 'Sunrise Nursing Home', units: ['Memory Care Unit', 'East Wing', 'West Wing', 'South Wing'] },
];

const departments = ['nursing', 'pharmacy', 'laboratory', 'radiology', 'administration', 'it', 'quality_assurance', 'compliance', 'dietary', 'maintenance'];

// Mock cross-reference items for linking
const mockCrossReferenceItems: { microapp: MicroappType; itemType: CrossReferenceItemType; id: string; title: string; status: string }[] = [
  { microapp: 'riskguard', itemType: 'risk_assessment', id: 'RISK-2024-001', title: 'Patient Safety Risk Assessment Q4', status: 'active' },
  { microapp: 'riskguard', itemType: 'risk_register', id: 'RISK-2024-002', title: 'Fall Prevention Risk Register', status: 'active' },
  { microapp: 'auditpro', itemType: 'audit_finding', id: 'AUD-2024-015', title: 'Documentation Gap - Medication Administration', status: 'open' },
  { microapp: 'auditpro', itemType: 'audit_report', id: 'AUD-2024-008', title: 'Q3 Internal Compliance Audit', status: 'completed' },
  { microapp: 'feedbackhub', itemType: 'complaint', id: 'FB-2024-042', title: 'Patient Wait Time Complaint', status: 'resolved' },
  { microapp: 'feedbackhub', itemType: 'feedback_item', id: 'FB-2024-051', title: 'Staff Communication Feedback', status: 'open' },
  { microapp: 'enforcementpoint', itemType: 'investigation', id: 'ENF-2024-003', title: 'CMS Survey Follow-up Investigation', status: 'in_progress' },
  { microapp: 'enforcementpoint', itemType: 'enforcement_action', id: 'ENF-2024-001', title: 'State Citation Response', status: 'pending' },
  { microapp: 'complianceconnect', itemType: 'issue', id: 'ISS-001', title: 'Medication Documentation Non-Compliance', status: 'in_progress' },
  { microapp: 'complianceconnect', itemType: 'issue', id: 'ISS-002', title: 'Hand Hygiene Protocol Violation', status: 'reported' },
  { microapp: 'citations', itemType: 'citation', id: 'CIT-001', title: 'F689 - Free of Accident Hazards', status: 'active' },
  { microapp: 'citations', itemType: 'citation', id: 'CIT-002', title: 'F880 - Infection Prevention and Control', status: 'active' },
];

const getMicroappIcon = (microapp: MicroappType) => {
  switch (microapp) {
    case 'riskguard': return <Shield className="h-4 w-4" />;
    case 'auditpro': return <FileSearch className="h-4 w-4" />;
    case 'feedbackhub': return <MessageSquare className="h-4 w-4" />;
    case 'enforcementpoint': return <Scale className="h-4 w-4" />;
    case 'complianceconnect': return <ClipboardList className="h-4 w-4" />;
    case 'citations': return <BookOpen className="h-4 w-4" />;
    case 'actionguard': return <Target className="h-4 w-4" />;
    default: return <Link2 className="h-4 w-4" />;
  }
};

const getMicroappColor = (microapp: MicroappType) => {
  switch (microapp) {
    case 'riskguard': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
    case 'auditpro': return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
    case 'feedbackhub': return 'bg-green-500/10 text-green-600 border-green-500/20';
    case 'enforcementpoint': return 'bg-red-500/10 text-red-600 border-red-500/20';
    case 'complianceconnect': return 'bg-cyan-500/10 text-cyan-600 border-cyan-500/20';
    case 'citations': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
    case 'actionguard': return 'bg-orange-500/10 text-orange-600 border-orange-500/20';
    default: return 'bg-muted text-muted-foreground';
  }
};

interface LinkedItem {
  microapp: MicroappType;
  itemType: CrossReferenceItemType;
  id: string;
  title: string;
  status: string;
}

export default function CreateCapa() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isDraft, setIsDraft] = useState(true);

  // Step 1: Basics
  const [title, setTitle] = useState('');
  const [problemStatement, setProblemStatement] = useState('');
  const [originType, setOriginType] = useState<CapaOriginTypeNew | ''>('');
  const [facility, setFacility] = useState('');
  const [unitWing, setUnitWing] = useState('');
  const [department, setDepartment] = useState('');
  const [severity, setSeverity] = useState<Priority | ''>('');
  const [priority, setPriority] = useState<Priority | ''>('');
  const [patientRisk, setPatientRisk] = useState<PatientRisk>('none');
  const [harmPotentialNotes, setHarmPotentialNotes] = useState('');
  const [owner, setOwner] = useState('');
  const [departmentHead, setDepartmentHead] = useState('');
  const [complianceHead, setComplianceHead] = useState('');
  const [dueDate, setDueDate] = useState('');
  
  // CMS/State Survey fields
  const [surveyDate, setSurveyDate] = useState('');
  const [cms2567ReceivedDate, setCms2567ReceivedDate] = useState('');
  const [ftag, setFtag] = useState('');
  const [scopeSeverity, setScopeSeverity] = useState('');

  // Cross-references
  const [linkedItems, setLinkedItems] = useState<LinkedItem[]>([]);
  const [showLinkDialog, setShowLinkDialog] = useState(false);
  const [selectedMicroapp, setSelectedMicroapp] = useState<MicroappType | ''>('');

  // Step 2: Containment
  const [containmentActions, setContainmentActions] = useState<{ description: string; who: string; when: string }[]>([]);
  const [immediateRiskMitigationComplete, setImmediateRiskMitigationComplete] = useState(false);
  const [riskMitigationNotes, setRiskMitigationNotes] = useState('');

  // Step 3: RCA
  const [rcaMethod, setRcaMethod] = useState<RcaMethodNew | ''>('');
  const [rcaSummary, setRcaSummary] = useState('');
  const [contributingFactors, setContributingFactors] = useState<ContributingFactor[]>([]);
  const [rootCauses, setRootCauses] = useState<{ statement: string; category: ContributingFactor | ''; justification: string }[]>([]);

  // Step 4: Actions
  const [correctiveActions, setCorrectiveActions] = useState<{ actionType: CapaActionType | ''; title: string; description: string; owner: string; dueDate: string; evidenceRequired: boolean }[]>([]);
  const [preventiveActions, setPreventiveActions] = useState<{ actionType: CapaActionType | ''; title: string; description: string; owner: string; dueDate: string; evidenceRequired: boolean }[]>([]);

  // Step 5: Verification & Effectiveness
  const [effectivenessCriteria, setEffectivenessCriteria] = useState<{ criteria: string; kpi: string; baseline: string; target: string }[]>([]);
  const [monitoringWhatToMonitor, setMonitoringWhatToMonitor] = useState('');
  const [monitoringFrequency, setMonitoringFrequency] = useState('');
  const [monitoringDuration, setMonitoringDuration] = useState('');
  const [monitoringOwner, setMonitoringOwner] = useState('');
  const [monitoringEscalation, setMonitoringEscalation] = useState('');
  const [effectivenessDueDate, setEffectivenessDueDate] = useState('');

  // Step 6: QAPI
  const [qapiFlag, setQapiFlag] = useState(false);
  const [pipReference, setPipReference] = useState('');
  const [qapiMetrics, setQapiMetrics] = useState<string[]>([]);

  // Filter users by role for assignment
  const departmentHeads = mockActionGuardUsers.filter(u => u.role === 'Department Head' || u.role === 'Admin');
  const complianceHeads = mockActionGuardUsers.filter(u => u.role === 'Compliance Head' || u.role === 'Admin');
  const staffUsers = mockActionGuardUsers.filter(u => u.role === 'Staff' || u.role === 'Department Head');

  const addLinkedItem = (item: LinkedItem) => {
    if (!linkedItems.find(i => i.id === item.id)) {
      setLinkedItems([...linkedItems, item]);
    }
    setShowLinkDialog(false);
    setSelectedMicroapp('');
  };

  const removeLinkedItem = (id: string) => {
    setLinkedItems(linkedItems.filter(i => i.id !== id));
  };

  const filteredCrossRefItems = selectedMicroapp 
    ? mockCrossReferenceItems.filter(i => i.microapp === selectedMicroapp)
    : mockCrossReferenceItems;

  const selectedFacility = facilities.find(f => f.name === facility);
  const isCmsSurvey = originType === 'cms_state_survey';

  // Calculate PoC due date (CMS-2567 received + 10 days)
  const pocDueDate = cms2567ReceivedDate 
    ? new Date(new Date(cms2567ReceivedDate).getTime() + 10 * 24 * 60 * 60 * 1000).toLocaleDateString()
    : null;

  const addContainmentAction = () => {
    setContainmentActions([...containmentActions, { description: '', who: '', when: '' }]);
  };

  const addRootCause = () => {
    setRootCauses([...rootCauses, { statement: '', category: '', justification: '' }]);
  };

  const addCorrectiveAction = () => {
    setCorrectiveActions([...correctiveActions, { actionType: '', title: '', description: '', owner: '', dueDate: '', evidenceRequired: true }]);
  };

  const addPreventiveAction = () => {
    setPreventiveActions([...preventiveActions, { actionType: '', title: '', description: '', owner: '', dueDate: '', evidenceRequired: true }]);
  };

  const addEffectivenessCriteria = () => {
    setEffectivenessCriteria([...effectivenessCriteria, { criteria: '', kpi: '', baseline: '', target: '' }]);
  };

  const toggleFactor = (factor: ContributingFactor) => {
    setContributingFactors(prev => 
      prev.includes(factor) ? prev.filter(f => f !== factor) : [...prev, factor]
    );
  };

  const handleSaveDraft = () => {
    toast({ title: 'Draft saved', description: 'Your CAPA draft has been saved.' });
  };

  const handleSubmit = () => {
    toast({ title: 'CAPA Submitted', description: 'Your CAPA has been submitted for review.' });
    navigate('/actionguard');
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return title && problemStatement && originType && facility && department && severity && owner && dueDate;
      case 2:
        return true; // Containment is optional initially
      case 3:
        return true; // RCA can be completed later
      case 4:
        return correctiveActions.length > 0 || preventiveActions.length > 0;
      case 5:
        return true;
      case 6:
        return true;
      case 7:
        return true;
      default:
        return true;
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <Label>Title *</Label>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Brief description of the issue" />
              </div>
              
              <div className="md:col-span-2">
                <Label>Problem Statement *</Label>
                <Textarea value={problemStatement} onChange={(e) => setProblemStatement(e.target.value)} placeholder="Detailed description of what happened..." rows={4} />
              </div>

              <div>
                <Label>Origin Type *</Label>
                <Select value={originType} onValueChange={(v) => setOriginType(v as CapaOriginTypeNew)}>
                  <SelectTrigger><SelectValue placeholder="Select origin type" /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(originTypeLabels).map(([value, label]) => (
                      <SelectItem key={value} value={value}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Facility *</Label>
                <Select value={facility} onValueChange={setFacility}>
                  <SelectTrigger><SelectValue placeholder="Select facility" /></SelectTrigger>
                  <SelectContent>
                    {facilities.map((f) => (
                      <SelectItem key={f.id} value={f.name}>{f.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedFacility && (
                <div>
                  <Label>Unit/Wing</Label>
                  <Select value={unitWing} onValueChange={setUnitWing}>
                    <SelectTrigger><SelectValue placeholder="Select unit" /></SelectTrigger>
                    <SelectContent>
                      {selectedFacility.units.map((u) => (
                        <SelectItem key={u} value={u}>{u}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div>
                <Label>Department *</Label>
                <Select value={department} onValueChange={setDepartment}>
                  <SelectTrigger><SelectValue placeholder="Select department" /></SelectTrigger>
                  <SelectContent>
                    {departments.map((d) => (
                      <SelectItem key={d} value={d}>{d.charAt(0).toUpperCase() + d.slice(1).replace('_', ' ')}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Severity *</Label>
                <Select value={severity} onValueChange={(v) => setSeverity(v as Priority)}>
                  <SelectTrigger><SelectValue placeholder="Select severity" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Priority *</Label>
                <Select value={priority} onValueChange={(v) => setPriority(v as Priority)}>
                  <SelectTrigger><SelectValue placeholder="Select priority" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Patient Risk Level</Label>
                <Select value={patientRisk} onValueChange={(v) => setPatientRisk(v as PatientRisk)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="moderate">Moderate</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="md:col-span-2">
                <Label>Harm Potential Notes</Label>
                <Textarea value={harmPotentialNotes} onChange={(e) => setHarmPotentialNotes(e.target.value)} placeholder="Describe potential for patient harm..." rows={2} />
              </div>
            </div>

            {/* Assignment Section */}
            <Separator />
            <div className="space-y-4">
              <h3 className="font-semibold text-foreground">Assignment</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Owner (Assignee) *</Label>
                  <Select value={owner} onValueChange={setOwner}>
                    <SelectTrigger><SelectValue placeholder="Select owner" /></SelectTrigger>
                    <SelectContent className="bg-background">
                      {staffUsers.map((u) => (
                        <SelectItem key={u.id} value={u.name}>{u.name} ({u.role})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-1">Primary person responsible for this CAPA</p>
                </div>

                <div>
                  <Label>Department Head</Label>
                  <Select value={departmentHead} onValueChange={setDepartmentHead}>
                    <SelectTrigger><SelectValue placeholder="Select department head" /></SelectTrigger>
                    <SelectContent className="bg-background">
                      {departmentHeads.map((u) => (
                        <SelectItem key={u.id} value={u.name}>{u.name} ({u.department})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-1">Department-level reviewer/approver</p>
                </div>

                <div>
                  <Label>Compliance Head</Label>
                  <Select value={complianceHead} onValueChange={setComplianceHead}>
                    <SelectTrigger><SelectValue placeholder="Select compliance head" /></SelectTrigger>
                    <SelectContent className="bg-background">
                      {complianceHeads.map((u) => (
                        <SelectItem key={u.id} value={u.name}>{u.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-1">Final approver for closure</p>
                </div>

                <div>
                  <Label>Due Date *</Label>
                  <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
                </div>
              </div>
            </div>

            {/* CMS/State Survey Fields */}
            {isCmsSurvey && (
              <>
                <Separator />
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-amber-500" />
                    <h3 className="font-semibold text-foreground">CMS/State Survey Information</h3>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Survey Date</Label>
                      <Input type="date" value={surveyDate} onChange={(e) => setSurveyDate(e.target.value)} />
                    </div>
                    <div>
                      <Label>CMS-2567 Received Date *</Label>
                      <Input type="date" value={cms2567ReceivedDate} onChange={(e) => setCms2567ReceivedDate(e.target.value)} />
                    </div>
                    <div>
                      <Label>F-Tag (e.g., F689, F880)</Label>
                      <Input value={ftag} onChange={(e) => setFtag(e.target.value)} placeholder="F-tag number" />
                    </div>
                    <div>
                      <Label>Scope/Severity (A-L)</Label>
                      <Select value={scopeSeverity} onValueChange={setScopeSeverity}>
                        <SelectTrigger><SelectValue placeholder="Select scope/severity" /></SelectTrigger>
                        <SelectContent className="bg-background">
                          {['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L'].map((s) => (
                            <SelectItem key={s} value={s}>{s}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {pocDueDate && (
                    <Alert className="border-amber-500/50 bg-amber-500/10">
                      <Calendar className="h-4 w-4 text-amber-600" />
                      <AlertDescription className="text-amber-700">
                        <strong>Plan of Correction Due:</strong> {pocDueDate} (10 calendar days from CMS-2567 receipt)
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              </>
            )}

            {/* Cross-Reference Linking Section */}
            <Separator />
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-foreground flex items-center gap-2">
                    <Link2 className="h-4 w-4" /> Cross-Reference Links
                  </h3>
                  <p className="text-sm text-muted-foreground">Link to related items from other modules</p>
                </div>
                <Dialog open={showLinkDialog} onOpenChange={setShowLinkDialog}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-2">
                      <Plus className="h-4 w-4" /> Add Link
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl bg-background">
                    <DialogHeader>
                      <DialogTitle>Link to External Item</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label>Filter by Module</Label>
                        <Select value={selectedMicroapp || 'all'} onValueChange={(v) => setSelectedMicroapp(v === 'all' ? '' : v as MicroappType)}>
                          <SelectTrigger><SelectValue placeholder="All modules" /></SelectTrigger>
                          <SelectContent className="bg-background">
                            <SelectItem value="all">All Modules</SelectItem>
                            {microappConfigs.filter(m => m.id !== 'actionguard').map((m) => (
                              <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="max-h-80 overflow-y-auto space-y-2">
                        {filteredCrossRefItems.filter(i => i.microapp !== 'actionguard').map((item) => {
                          const isLinked = linkedItems.some(l => l.id === item.id);
                          const config = microappConfigs.find(m => m.id === item.microapp);
                          return (
                            <div 
                              key={item.id}
                              className={`p-3 border rounded-lg cursor-pointer transition-colors ${isLinked ? 'border-primary bg-primary/5' : 'hover:border-primary/50'}`}
                              onClick={() => !isLinked && addLinkedItem(item)}
                            >
                              <div className="flex items-start gap-3">
                                <div className={`p-1.5 rounded ${getMicroappColor(item.microapp)}`}>
                                  {getMicroappIcon(item.microapp)}
                                </div>
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-1">
                                    <Badge variant="outline" className="text-xs">{config?.name}</Badge>
                                    <span className="text-xs text-muted-foreground">{item.id}</span>
                                    {isLinked && <Badge variant="default" className="text-xs">Linked</Badge>}
                                  </div>
                                  <p className="font-medium text-sm">{item.title}</p>
                                  <p className="text-xs text-muted-foreground capitalize">Status: {item.status.replace('_', ' ')}</p>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              {linkedItems.length > 0 ? (
                <div className="space-y-2">
                  {linkedItems.map((item) => {
                    const config = microappConfigs.find(m => m.id === item.microapp);
                    return (
                      <div key={item.id} className="flex items-center gap-3 p-3 border rounded-lg">
                        <div className={`p-1.5 rounded ${getMicroappColor(item.microapp)}`}>
                          {getMicroappIcon(item.microapp)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-xs">{config?.name}</Badge>
                            <span className="text-xs text-muted-foreground">{item.id}</span>
                          </div>
                          <p className="font-medium text-sm">{item.title}</p>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => removeLinkedItem(item.id)}>
                          <X className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                        </Button>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <Card className="border-dashed">
                  <CardContent className="p-6 text-center">
                    <Link2 className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">No cross-references linked yet</p>
                    <p className="text-xs text-muted-foreground mt-1">Link this CAPA to related items from RiskGuard, AuditPro, FeedbackHub, and more</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-foreground">Containment Actions</h3>
                <p className="text-sm text-muted-foreground">Immediate protective/stop-gap measures taken</p>
              </div>
              <Button variant="outline" onClick={addContainmentAction} className="gap-2">
                <Plus className="h-4 w-4" /> Add Action
              </Button>
            </div>

            {containmentActions.length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="p-8 text-center">
                  <p className="text-muted-foreground">No containment actions added yet</p>
                  <Button variant="outline" onClick={addContainmentAction} className="mt-4 gap-2">
                    <Plus className="h-4 w-4" /> Add First Action
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {containmentActions.map((action, idx) => (
                  <Card key={idx}>
                    <CardContent className="p-4 space-y-4">
                      <div className="flex items-start justify-between">
                        <span className="text-sm font-medium text-muted-foreground">Action {idx + 1}</span>
                        <Button variant="ghost" size="icon" onClick={() => setContainmentActions(containmentActions.filter((_, i) => i !== idx))}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="md:col-span-3">
                          <Label>What was done?</Label>
                          <Textarea 
                            value={action.description} 
                            onChange={(e) => {
                              const updated = [...containmentActions];
                              updated[idx].description = e.target.value;
                              setContainmentActions(updated);
                            }}
                            placeholder="Describe the immediate action taken..."
                          />
                        </div>
                        <div>
                          <Label>Who?</Label>
                          <Input 
                            value={action.who} 
                            onChange={(e) => {
                              const updated = [...containmentActions];
                              updated[idx].who = e.target.value;
                              setContainmentActions(updated);
                            }}
                            placeholder="Person/role responsible"
                          />
                        </div>
                        <div>
                          <Label>When?</Label>
                          <Input 
                            type="date"
                            value={action.when} 
                            onChange={(e) => {
                              const updated = [...containmentActions];
                              updated[idx].when = e.target.value;
                              setContainmentActions(updated);
                            }}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            <Separator />

            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Checkbox 
                  checked={immediateRiskMitigationComplete} 
                  onCheckedChange={(checked) => setImmediateRiskMitigationComplete(checked as boolean)} 
                />
                <Label>Immediate risk mitigation complete</Label>
              </div>
              <div>
                <Label>Risk Mitigation Notes</Label>
                <Textarea value={riskMitigationNotes} onChange={(e) => setRiskMitigationNotes(e.target.value)} placeholder="Additional notes about risk mitigation status..." rows={3} />
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label>RCA Method</Label>
                <Select value={rcaMethod} onValueChange={(v) => setRcaMethod(v as RcaMethodNew)}>
                  <SelectTrigger><SelectValue placeholder="Select method" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="five_whys">5 Whys</SelectItem>
                    <SelectItem value="fishbone">Fishbone (Ishikawa)</SelectItem>
                    <SelectItem value="process_map">Process Map</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>RCA Summary</Label>
              <Textarea value={rcaSummary} onChange={(e) => setRcaSummary(e.target.value)} placeholder="Summary of root cause analysis findings..." rows={4} />
            </div>

            <div>
              <Label>Contributing Factors</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {(['people', 'process', 'technology', 'environment', 'policy', 'communication'] as ContributingFactor[]).map((factor) => (
                  <Badge 
                    key={factor}
                    variant={contributingFactors.includes(factor) ? 'default' : 'outline'}
                    className="cursor-pointer"
                    onClick={() => toggleFactor(factor)}
                  >
                    {factor.charAt(0).toUpperCase() + factor.slice(1)}
                  </Badge>
                ))}
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-foreground">Root Causes</h3>
                  <p className="text-sm text-muted-foreground">Identified root causes with justification</p>
                </div>
                <Button variant="outline" onClick={addRootCause} className="gap-2">
                  <Plus className="h-4 w-4" /> Add Root Cause
                </Button>
              </div>

              {rootCauses.map((rc, idx) => (
                <Card key={idx}>
                  <CardContent className="p-4 space-y-4">
                    <div className="flex items-start justify-between">
                      <span className="text-sm font-medium text-muted-foreground">Root Cause {idx + 1}</span>
                      <Button variant="ghost" size="icon" onClick={() => setRootCauses(rootCauses.filter((_, i) => i !== idx))}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="md:col-span-2">
                        <Label>Statement</Label>
                        <Textarea 
                          value={rc.statement}
                          onChange={(e) => {
                            const updated = [...rootCauses];
                            updated[idx].statement = e.target.value;
                            setRootCauses(updated);
                          }}
                          placeholder="Root cause statement..."
                        />
                      </div>
                      <div>
                        <Label>Category</Label>
                        <Select 
                          value={rc.category} 
                          onValueChange={(v) => {
                            const updated = [...rootCauses];
                            updated[idx].category = v as ContributingFactor;
                            setRootCauses(updated);
                          }}
                        >
                          <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                          <SelectContent>
                            {['people', 'process', 'technology', 'environment', 'policy', 'communication'].map((c) => (
                              <SelectItem key={c} value={c}>{c.charAt(0).toUpperCase() + c.slice(1)}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="md:col-span-2">
                        <Label>Justification/Evidence</Label>
                        <Textarea 
                          value={rc.justification}
                          onChange={(e) => {
                            const updated = [...rootCauses];
                            updated[idx].justification = e.target.value;
                            setRootCauses(updated);
                          }}
                          placeholder="Evidence supporting this root cause..."
                          rows={2}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {rootCauses.length === 0 && (
                <Card className="border-dashed">
                  <CardContent className="p-8 text-center">
                    <p className="text-muted-foreground">No root causes added yet</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            {/* Corrective Actions */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-foreground">Corrective Actions</h3>
                  <p className="text-sm text-muted-foreground">Actions to fix the immediate problem</p>
                </div>
                <Button variant="outline" onClick={addCorrectiveAction} className="gap-2">
                  <Plus className="h-4 w-4" /> Add Corrective Action
                </Button>
              </div>

              {correctiveActions.map((action, idx) => (
                <Card key={idx}>
                  <CardContent className="p-4 space-y-4">
                    <div className="flex items-start justify-between">
                      <Badge variant="outline" className="bg-red-500/10 text-red-600 border-red-500/20">Corrective {idx + 1}</Badge>
                      <Button variant="ghost" size="icon" onClick={() => setCorrectiveActions(correctiveActions.filter((_, i) => i !== idx))}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Action Type *</Label>
                        <Select 
                          value={action.actionType}
                          onValueChange={(v) => {
                            const updated = [...correctiveActions];
                            updated[idx].actionType = v as CapaActionType;
                            setCorrectiveActions(updated);
                          }}
                        >
                          <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                          <SelectContent>
                            {Object.entries(actionTypeLabels).map(([value, label]) => (
                              <SelectItem key={value} value={value}>{label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Title *</Label>
                        <Input 
                          value={action.title}
                          onChange={(e) => {
                            const updated = [...correctiveActions];
                            updated[idx].title = e.target.value;
                            setCorrectiveActions(updated);
                          }}
                          placeholder="Action title"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <Label>Description</Label>
                        <Textarea 
                          value={action.description}
                          onChange={(e) => {
                            const updated = [...correctiveActions];
                            updated[idx].description = e.target.value;
                            setCorrectiveActions(updated);
                          }}
                          placeholder="Detailed description..."
                          rows={2}
                        />
                      </div>
                      <div>
                        <Label>Owner *</Label>
                        <Select 
                          value={action.owner}
                          onValueChange={(v) => {
                            const updated = [...correctiveActions];
                            updated[idx].owner = v;
                            setCorrectiveActions(updated);
                          }}
                        >
                          <SelectTrigger><SelectValue placeholder="Select owner" /></SelectTrigger>
                          <SelectContent>
                            {mockActionGuardUsers.map((u) => (
                              <SelectItem key={u.id} value={u.name}>{u.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Due Date *</Label>
                        <Input 
                          type="date"
                          value={action.dueDate}
                          onChange={(e) => {
                            const updated = [...correctiveActions];
                            updated[idx].dueDate = e.target.value;
                            setCorrectiveActions(updated);
                          }}
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox 
                          checked={action.evidenceRequired}
                          onCheckedChange={(checked) => {
                            const updated = [...correctiveActions];
                            updated[idx].evidenceRequired = checked as boolean;
                            setCorrectiveActions(updated);
                          }}
                        />
                        <Label>Evidence Required</Label>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {correctiveActions.length === 0 && (
                <Card className="border-dashed">
                  <CardContent className="p-8 text-center">
                    <p className="text-muted-foreground">No corrective actions added yet</p>
                  </CardContent>
                </Card>
              )}
            </div>

            <Separator />

            {/* Preventive Actions */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-foreground">Preventive Actions</h3>
                  <p className="text-sm text-muted-foreground">Actions to prevent recurrence</p>
                </div>
                <Button variant="outline" onClick={addPreventiveAction} className="gap-2">
                  <Plus className="h-4 w-4" /> Add Preventive Action
                </Button>
              </div>

              {preventiveActions.map((action, idx) => (
                <Card key={idx}>
                  <CardContent className="p-4 space-y-4">
                    <div className="flex items-start justify-between">
                      <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-500/20">Preventive {idx + 1}</Badge>
                      <Button variant="ghost" size="icon" onClick={() => setPreventiveActions(preventiveActions.filter((_, i) => i !== idx))}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Action Type *</Label>
                        <Select 
                          value={action.actionType}
                          onValueChange={(v) => {
                            const updated = [...preventiveActions];
                            updated[idx].actionType = v as CapaActionType;
                            setPreventiveActions(updated);
                          }}
                        >
                          <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                          <SelectContent>
                            {Object.entries(actionTypeLabels).map(([value, label]) => (
                              <SelectItem key={value} value={value}>{label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Title *</Label>
                        <Input 
                          value={action.title}
                          onChange={(e) => {
                            const updated = [...preventiveActions];
                            updated[idx].title = e.target.value;
                            setPreventiveActions(updated);
                          }}
                          placeholder="Action title"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <Label>Description</Label>
                        <Textarea 
                          value={action.description}
                          onChange={(e) => {
                            const updated = [...preventiveActions];
                            updated[idx].description = e.target.value;
                            setPreventiveActions(updated);
                          }}
                          placeholder="Detailed description..."
                          rows={2}
                        />
                      </div>
                      <div>
                        <Label>Owner *</Label>
                        <Select 
                          value={action.owner}
                          onValueChange={(v) => {
                            const updated = [...preventiveActions];
                            updated[idx].owner = v;
                            setPreventiveActions(updated);
                          }}
                        >
                          <SelectTrigger><SelectValue placeholder="Select owner" /></SelectTrigger>
                          <SelectContent>
                            {mockActionGuardUsers.map((u) => (
                              <SelectItem key={u.id} value={u.name}>{u.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Due Date *</Label>
                        <Input 
                          type="date"
                          value={action.dueDate}
                          onChange={(e) => {
                            const updated = [...preventiveActions];
                            updated[idx].dueDate = e.target.value;
                            setPreventiveActions(updated);
                          }}
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox 
                          checked={action.evidenceRequired}
                          onCheckedChange={(checked) => {
                            const updated = [...preventiveActions];
                            updated[idx].evidenceRequired = checked as boolean;
                            setPreventiveActions(updated);
                          }}
                        />
                        <Label>Evidence Required</Label>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {preventiveActions.length === 0 && (
                <Card className="border-dashed">
                  <CardContent className="p-8 text-center">
                    <p className="text-muted-foreground">No preventive actions added yet</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            {/* Effectiveness Criteria */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-foreground">Effectiveness Criteria</h3>
                  <p className="text-sm text-muted-foreground">Measurable criteria to determine if actions were effective</p>
                </div>
                <Button variant="outline" onClick={addEffectivenessCriteria} className="gap-2">
                  <Plus className="h-4 w-4" /> Add Criteria
                </Button>
              </div>

              {effectivenessCriteria.map((ec, idx) => (
                <Card key={idx}>
                  <CardContent className="p-4 space-y-4">
                    <div className="flex items-start justify-between">
                      <span className="text-sm font-medium text-muted-foreground">Criteria {idx + 1}</span>
                      <Button variant="ghost" size="icon" onClick={() => setEffectivenessCriteria(effectivenessCriteria.filter((_, i) => i !== idx))}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="md:col-span-2">
                        <Label>Criteria Description *</Label>
                        <Textarea 
                          value={ec.criteria}
                          onChange={(e) => {
                            const updated = [...effectivenessCriteria];
                            updated[idx].criteria = e.target.value;
                            setEffectivenessCriteria(updated);
                          }}
                          placeholder="What will be measured to determine effectiveness?"
                        />
                      </div>
                      <div>
                        <Label>KPI Name</Label>
                        <Input 
                          value={ec.kpi}
                          onChange={(e) => {
                            const updated = [...effectivenessCriteria];
                            updated[idx].kpi = e.target.value;
                            setEffectivenessCriteria(updated);
                          }}
                          placeholder="e.g., Fall Rate"
                        />
                      </div>
                      <div>
                        <Label>Baseline</Label>
                        <Input 
                          value={ec.baseline}
                          onChange={(e) => {
                            const updated = [...effectivenessCriteria];
                            updated[idx].baseline = e.target.value;
                            setEffectivenessCriteria(updated);
                          }}
                          placeholder="Current value"
                        />
                      </div>
                      <div>
                        <Label>Target *</Label>
                        <Input 
                          value={ec.target}
                          onChange={(e) => {
                            const updated = [...effectivenessCriteria];
                            updated[idx].target = e.target.value;
                            setEffectivenessCriteria(updated);
                          }}
                          placeholder="Target value"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {effectivenessCriteria.length === 0 && (
                <Card className="border-dashed">
                  <CardContent className="p-8 text-center">
                    <p className="text-muted-foreground">No effectiveness criteria added yet</p>
                  </CardContent>
                </Card>
              )}
            </div>

            <Separator />

            {/* Monitoring Plan */}
            <div className="space-y-4">
              <h3 className="font-semibold text-foreground">Monitoring Plan</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <Label>What to Monitor</Label>
                  <Textarea value={monitoringWhatToMonitor} onChange={(e) => setMonitoringWhatToMonitor(e.target.value)} placeholder="Describe what will be monitored..." rows={2} />
                </div>
                <div>
                  <Label>Frequency</Label>
                  <Select value={monitoringFrequency} onValueChange={setMonitoringFrequency}>
                    <SelectTrigger><SelectValue placeholder="Select frequency" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Duration</Label>
                  <Input value={monitoringDuration} onChange={(e) => setMonitoringDuration(e.target.value)} placeholder="e.g., 6 months" />
                </div>
                <div>
                  <Label>Monitoring Owner</Label>
                  <Select value={monitoringOwner} onValueChange={setMonitoringOwner}>
                    <SelectTrigger><SelectValue placeholder="Select owner" /></SelectTrigger>
                    <SelectContent>
                      {mockActionGuardUsers.map((u) => (
                        <SelectItem key={u.id} value={u.name}>{u.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Effectiveness Due Date</Label>
                  <Input type="date" value={effectivenessDueDate} onChange={(e) => setEffectivenessDueDate(e.target.value)} />
                </div>
                <div className="md:col-span-2">
                  <Label>Escalation Rule</Label>
                  <Input value={monitoringEscalation} onChange={(e) => setMonitoringEscalation(e.target.value)} placeholder="When and how to escalate issues..." />
                </div>
              </div>
            </div>
          </div>
        );

      case 6:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <Checkbox checked={qapiFlag} onCheckedChange={(checked) => setQapiFlag(checked as boolean)} />
              <div>
                <Label className="font-semibold">Include in QAPI Reporting</Label>
                <p className="text-sm text-muted-foreground">This CAPA will count toward Quality Assurance Performance Improvement metrics</p>
              </div>
            </div>

            {qapiFlag && (
              <div className="space-y-4 pl-8">
                <div>
                  <Label>Performance Improvement Project (PIP) Reference</Label>
                  <Input value={pipReference} onChange={(e) => setPipReference(e.target.value)} placeholder="e.g., PIP-2024-FALL-001" />
                </div>
                <div>
                  <Label>Linked QAPI Metrics</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {['Falls', 'Infections', 'Pressure Ulcers', 'Weight Loss', 'Antipsychotic Use', 'Re-hospitalizations', 'Medication Errors'].map((metric) => (
                      <Badge 
                        key={metric}
                        variant={qapiMetrics.includes(metric) ? 'default' : 'outline'}
                        className="cursor-pointer"
                        onClick={() => setQapiMetrics(prev => prev.includes(metric) ? prev.filter(m => m !== metric) : [...prev, metric])}
                      >
                        {metric}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        );

      case 7:
        return (
          <div className="space-y-6">
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                Review all information before submitting. Required fields marked with * must be completed.
              </AlertDescription>
            </Alert>

            <Card>
              <CardHeader>
                <CardTitle>Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Title:</span>
                    <p className="font-medium">{title || '-'}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Origin:</span>
                    <p className="font-medium">{originType ? originTypeLabels[originType] : '-'}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Facility:</span>
                    <p className="font-medium">{facility || '-'}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Department:</span>
                    <p className="font-medium">{department || '-'}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Severity:</span>
                    <p className="font-medium">{severity || '-'}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Owner (Assignee):</span>
                    <p className="font-medium">{owner || '-'}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Department Head:</span>
                    <p className="font-medium">{departmentHead || '-'}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Compliance Head:</span>
                    <p className="font-medium">{complianceHead || '-'}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Due Date:</span>
                    <p className="font-medium">{dueDate || '-'}</p>
                  </div>
                  {isCmsSurvey && (
                    <div>
                      <span className="text-muted-foreground">PoC Due:</span>
                      <p className="font-medium text-amber-600">{pocDueDate || '-'}</p>
                    </div>
                  )}
                </div>

                <Separator />

                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  <div className="text-center p-3 bg-muted/50 rounded-lg">
                    <p className="text-2xl font-bold">{containmentActions.length}</p>
                    <p className="text-xs text-muted-foreground">Containment</p>
                  </div>
                  <div className="text-center p-3 bg-muted/50 rounded-lg">
                    <p className="text-2xl font-bold">{rootCauses.length}</p>
                    <p className="text-xs text-muted-foreground">Root Causes</p>
                  </div>
                  <div className="text-center p-3 bg-muted/50 rounded-lg">
                    <p className="text-2xl font-bold">{correctiveActions.length + preventiveActions.length}</p>
                    <p className="text-xs text-muted-foreground">Actions</p>
                  </div>
                  <div className="text-center p-3 bg-muted/50 rounded-lg">
                    <p className="text-2xl font-bold">{effectivenessCriteria.length}</p>
                    <p className="text-xs text-muted-foreground">Effectiveness</p>
                  </div>
                  <div className="text-center p-3 bg-muted/50 rounded-lg">
                    <p className="text-2xl font-bold">{linkedItems.length}</p>
                    <p className="text-xs text-muted-foreground">Cross-Links</p>
                  </div>
                </div>

                {/* Cross-Reference Links Summary */}
                {linkedItems.length > 0 && (
                  <>
                    <Separator />
                    <div>
                      <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                        <Link2 className="h-4 w-4" /> Cross-Referenced Items
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {linkedItems.map((item) => {
                          const config = microappConfigs.find(m => m.id === item.microapp);
                          return (
                            <Badge key={item.id} variant="outline" className={`${getMicroappColor(item.microapp)} gap-1`}>
                              {getMicroappIcon(item.microapp)}
                              {config?.name}: {item.id}
                            </Badge>
                          );
                        })}
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Validation warnings */}
            {(!title || !problemStatement || !originType || !facility || !department || !severity || !owner || !dueDate) && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Please complete all required fields in Step 1 (Basics) before submitting.
                </AlertDescription>
              </Alert>
            )}
            
            {correctiveActions.length === 0 && preventiveActions.length === 0 && (
              <Alert className="border-amber-500/50 bg-amber-500/10">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
                <AlertDescription className="text-amber-700">
                  At least one corrective or preventive action is recommended before submission.
                </AlertDescription>
              </Alert>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <Button variant="ghost" size="icon" onClick={() => navigate('/actionguard')}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-foreground">Create CAPA</h1>
          <p className="text-muted-foreground">Corrective and Preventive Action</p>
        </div>
        <Button variant="outline" onClick={handleSaveDraft} className="gap-2">
          <Save className="h-4 w-4" /> Save Draft
        </Button>
      </div>

      {/* Stepper */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          {STEPS.map((step, idx) => (
            <div key={step.id} className="flex items-center">
              <div 
                className={`flex flex-col items-center cursor-pointer ${currentStep >= step.id ? 'text-primary' : 'text-muted-foreground'}`}
                onClick={() => setCurrentStep(step.id)}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium mb-1 ${
                  currentStep > step.id ? 'bg-primary text-primary-foreground' :
                  currentStep === step.id ? 'bg-primary text-primary-foreground' :
                  'bg-muted text-muted-foreground'
                }`}>
                  {currentStep > step.id ? <Check className="h-4 w-4" /> : step.id}
                </div>
                <span className="text-xs font-medium hidden md:block">{step.title}</span>
              </div>
              {idx < STEPS.length - 1 && (
                <div className={`h-0.5 w-8 md:w-16 mx-2 ${currentStep > step.id ? 'bg-primary' : 'bg-muted'}`} />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Step Content */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>{STEPS[currentStep - 1].title}</CardTitle>
          <CardDescription>{STEPS[currentStep - 1].description}</CardDescription>
        </CardHeader>
        <CardContent>
          {renderStepContent()}
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex items-center justify-between">
        <Button 
          variant="outline" 
          onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
          disabled={currentStep === 1}
          className="gap-2"
        >
          <ArrowLeft className="h-4 w-4" /> Previous
        </Button>
        
        {currentStep < STEPS.length ? (
          <Button 
            onClick={() => setCurrentStep(Math.min(STEPS.length, currentStep + 1))}
            className="gap-2"
          >
            Next <ArrowRight className="h-4 w-4" />
          </Button>
        ) : (
          <Button onClick={handleSubmit} className="gap-2">
            <Check className="h-4 w-4" /> Submit CAPA
          </Button>
        )}
      </div>
    </div>
  );
}
