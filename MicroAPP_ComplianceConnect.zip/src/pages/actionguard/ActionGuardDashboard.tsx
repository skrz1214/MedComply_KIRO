import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, AlertTriangle, Clock, CheckCircle2, Activity, Search, BarChart3, TrendingUp, Calendar, ChevronRight, FileText, RotateCcw, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { mockCapasNew, mockActionGuardStats, originTypeLabels } from '@/data/actionguardMockData';
import { 
  BUCKET_STATUSES, 
  BUCKET_LABELS, 
  BucketTabBadge, 
  CapaBucket, 
  getCapaBucket,
  PHASE_DEFINITIONS,
  PhaseTooltip 
} from '@/components/actionguard/CapaBucketHelpers';

const facilities = ['All Facilities', 'Main Hospital', 'Downtown Clinic', 'Sunrise Nursing Home'];

export default function ActionGuardDashboard() {
  const navigate = useNavigate();
  const [selectedFacility, setSelectedFacility] = useState('All Facilities');
  const [viewMode, setViewMode] = useState<'organization' | 'personal'>('organization');
  const [activeBucket, setActiveBucket] = useState<CapaBucket>('new');

  const stats = mockActionGuardStats;

  // Filter CAPAs based on selected facility
  const filteredCapas = selectedFacility === 'All Facilities' 
    ? mockCapasNew 
    : mockCapasNew.filter(c => c.facility === selectedFacility);

  // Count CAPAs by bucket
  const bucketCounts = {
    new: filteredCapas.filter(c => BUCKET_STATUSES.new.includes(c.status)).length,
    open: filteredCapas.filter(c => BUCKET_STATUSES.open.includes(c.status)).length,
    closed: filteredCapas.filter(c => BUCKET_STATUSES.closed.includes(c.status)).length,
  };

  // Get CAPAs for current bucket
  const bucketCapas = filteredCapas.filter(c => BUCKET_STATUSES[activeBucket].includes(c.status));

  // Sort based on bucket
  const sortedBucketCapas = [...bucketCapas].sort((a, b) => {
    if (activeBucket === 'new') {
      // Newest first, then review SLA due soon
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    } else if (activeBucket === 'open') {
      // Overdue first, then due soon, then severity
      const aOverdue = new Date(a.dueDate) < new Date() ? 1 : 0;
      const bOverdue = new Date(b.dueDate) < new Date() ? 1 : 0;
      if (aOverdue !== bOverdue) return bOverdue - aOverdue;
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    } else {
      // Recently closed first
      return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
    }
  }).slice(0, 5);

  const overdueCapas = filteredCapas.filter(c => 
    new Date(c.dueDate) < new Date() && c.status !== 'closed'
  );

  const pocOverdueCapas = filteredCapas.filter(c => 
    c.originType === 'cms_state_survey' && 
    c.surveyPocData?.pocDueDate && 
    new Date(c.surveyPocData.pocDueDate) < new Date() && 
    !c.surveyPocData.pocSubmissionDate
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'closed': return 'bg-green-500/10 text-green-600 border-green-500/20';
      case 'in_progress': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'verification': return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
      case 'effectiveness_monitoring': return 'bg-indigo-500/10 text-indigo-600 border-indigo-500/20';
      case 'approved': return 'bg-cyan-500/10 text-cyan-600 border-cyan-500/20';
      case 'draft': return 'bg-gray-500/10 text-gray-600 border-gray-500/20';
      case 'submitted': case 'in_review': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      case 'reopened': return 'bg-red-500/10 text-red-600 border-red-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">ActionGuard Dashboard</h1>
          <p className="text-muted-foreground">CAPA Management Overview</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedFacility} onValueChange={setSelectedFacility}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {facilities.map(f => (
                <SelectItem key={f} value={f}>{f}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="flex rounded-lg border border-border overflow-hidden">
            <button 
              className={`px-3 py-1.5 text-sm ${viewMode === 'organization' ? 'bg-primary text-primary-foreground' : 'bg-background text-muted-foreground'}`}
              onClick={() => setViewMode('organization')}
            >
              Organization
            </button>
            <button 
              className={`px-3 py-1.5 text-sm ${viewMode === 'personal' ? 'bg-primary text-primary-foreground' : 'bg-background text-muted-foreground'}`}
              onClick={() => setViewMode('personal')}
            >
              Personal
            </button>
          </div>
          <Button onClick={() => navigate('/actionguard/new')} className="gap-2">
            <Plus className="h-4 w-4" /> New CAPA
          </Button>
        </div>
      </div>

      {/* Critical Alerts */}
      {(pocOverdueCapas.length > 0 || overdueCapas.length > 0) && (
        <div className="space-y-2">
          {pocOverdueCapas.map(capa => (
            <Card key={capa.id} className="border-red-500 bg-red-500/5 cursor-pointer hover:bg-red-500/10" onClick={() => navigate(`/actionguard/${capa.id}`)}>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="p-2 rounded-lg bg-red-500/10">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-red-600">PoC OVERDUE: {capa.title}</p>
                  <p className="text-sm text-red-600/70">
                    {capa.surveyPocData?.ftag && `F-Tag ${capa.surveyPocData.ftag} • `}
                    PoC was due {capa.surveyPocData?.pocDueDate ? new Date(capa.surveyPocData.pocDueDate).toLocaleDateString() : 'N/A'}
                  </p>
                </div>
                <ChevronRight className="h-5 w-5 text-red-600" />
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Bucket Tabs */}
      <Tabs value={activeBucket} onValueChange={(v) => setActiveBucket(v as CapaBucket)} className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="new" className="gap-2">
            NEW
            <BucketTabBadge bucket="new" count={bucketCounts.new} />
          </TabsTrigger>
          <TabsTrigger value="open" className="gap-2">
            OPEN
            <BucketTabBadge bucket="open" count={bucketCounts.open} />
          </TabsTrigger>
          <TabsTrigger value="closed" className="gap-2">
            CLOSED
            <BucketTabBadge bucket="closed" count={bucketCounts.closed} />
          </TabsTrigger>
        </TabsList>

        <TabsContent value="new" className="mt-6 space-y-6">
          {/* NEW KPI Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="cursor-pointer hover:border-primary/50" onClick={() => navigate('/actionguard/list?bucket=new&status=draft')}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <FileText className="h-5 w-5 text-gray-500" />
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>{PHASE_DEFINITIONS.draft.definition}</TooltipContent>
                  </Tooltip>
                </div>
                <p className="text-2xl font-bold mt-2">{stats.draft}</p>
                <p className="text-sm text-muted-foreground">Draft</p>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:border-primary/50" onClick={() => navigate('/actionguard/list?bucket=new&status=submitted')}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <Clock className="h-5 w-5 text-orange-500" />
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>{PHASE_DEFINITIONS.submitted.definition}</TooltipContent>
                  </Tooltip>
                </div>
                <p className="text-2xl font-bold mt-2 text-orange-600">{filteredCapas.filter(c => c.status === 'submitted').length}</p>
                <p className="text-sm text-muted-foreground">Submitted</p>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:border-primary/50" onClick={() => navigate('/actionguard/list?bucket=new&status=in_review')}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <Search className="h-5 w-5 text-amber-500" />
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>{PHASE_DEFINITIONS.in_review.definition}</TooltipContent>
                  </Tooltip>
                </div>
                <p className="text-2xl font-bold mt-2 text-amber-600">{stats.inReview}</p>
                <p className="text-sm text-muted-foreground">In Review</p>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:border-primary/50" onClick={() => navigate('/actionguard/approvals')}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <CheckCircle2 className="h-5 w-5 text-cyan-500" />
                </div>
                <p className="text-2xl font-bold mt-2 text-cyan-600">{bucketCounts.new}</p>
                <p className="text-sm text-muted-foreground">Pending Approval</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="open" className="mt-6 space-y-6">
          {/* OPEN KPI Cards */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <Card className="cursor-pointer hover:border-primary/50" onClick={() => navigate('/actionguard/list?bucket=open&status=approved')}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <CheckCircle2 className="h-5 w-5 text-cyan-500" />
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>{PHASE_DEFINITIONS.approved.definition}</TooltipContent>
                  </Tooltip>
                </div>
                <p className="text-2xl font-bold mt-2 text-cyan-600">{filteredCapas.filter(c => c.status === 'approved').length}</p>
                <p className="text-sm text-muted-foreground">Approved</p>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:border-primary/50" onClick={() => navigate('/actionguard/list?bucket=open&status=in_progress')}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <Activity className="h-5 w-5 text-blue-500" />
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>{PHASE_DEFINITIONS.in_progress.definition}</TooltipContent>
                  </Tooltip>
                </div>
                <p className="text-2xl font-bold mt-2 text-blue-600">{stats.inProgress}</p>
                <p className="text-sm text-muted-foreground">In Progress</p>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:border-primary/50" onClick={() => navigate('/actionguard/list?bucket=open&status=verification')}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <CheckCircle2 className="h-5 w-5 text-purple-500" />
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>{PHASE_DEFINITIONS.verification.definition}</TooltipContent>
                  </Tooltip>
                </div>
                <p className="text-2xl font-bold mt-2 text-purple-600">{stats.verification}</p>
                <p className="text-sm text-muted-foreground">Verification</p>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:border-primary/50" onClick={() => navigate('/actionguard/list?bucket=open&status=effectiveness_monitoring')}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <BarChart3 className="h-5 w-5 text-indigo-500" />
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>{PHASE_DEFINITIONS.effectiveness_monitoring.definition}</TooltipContent>
                  </Tooltip>
                </div>
                <p className="text-2xl font-bold mt-2 text-indigo-600">{stats.effectivenessMonitoring}</p>
                <p className="text-sm text-muted-foreground">Effectiveness</p>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:border-primary/50" onClick={() => navigate('/actionguard/list?bucket=open&overdue=true')}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <AlertTriangle className="h-5 w-5 text-red-500" />
                </div>
                <p className="text-2xl font-bold mt-2 text-red-600">{stats.overdueActions}</p>
                <p className="text-sm text-muted-foreground">Overdue</p>
              </CardContent>
            </Card>
          </div>

          {/* PoC Status */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-amber-500/10">
                    <Clock className="h-5 w-5 text-amber-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stats.pocDueSoon}</p>
                    <p className="text-sm text-muted-foreground">PoC Due Soon (≤3 days)</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-red-500/10">
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-red-600">{stats.pocOverdue}</p>
                    <p className="text-sm text-muted-foreground">PoC Overdue</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-red-500/10">
                    <RotateCcw className="h-5 w-5 text-red-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-red-600">{filteredCapas.filter(c => c.status === 'reopened').length}</p>
                    <p className="text-sm text-muted-foreground">Reopened</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="closed" className="mt-6 space-y-6">
          {/* CLOSED KPI Cards */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-green-500/10">
                    <CheckCircle2 className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-green-600">{bucketCounts.closed}</p>
                    <p className="text-sm text-muted-foreground">Total Closed</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-green-500/10">
                    <TrendingUp className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-green-600">{stats.closedThisMonth}</p>
                    <p className="text-sm text-muted-foreground">Closed This Month</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-blue-500/10">
                    <Calendar className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">--</p>
                    <p className="text-sm text-muted-foreground">Avg. Cycle Time</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity for current bucket */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recent {BUCKET_LABELS[activeBucket].label} CAPAs</CardTitle>
            <CardDescription>{BUCKET_LABELS[activeBucket].description}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {sortedBucketCapas.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">No CAPAs in this bucket</p>
              ) : (
                sortedBucketCapas.map(capa => (
                  <div 
                    key={capa.id} 
                    className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                    onClick={() => navigate(`/actionguard/${capa.id}`)}
                  >
                    <div className={`w-2 h-2 rounded-full mt-2 ${
                      capa.status === 'closed' ? 'bg-green-500' :
                      capa.status === 'in_progress' ? 'bg-blue-500' :
                      capa.status === 'reopened' ? 'bg-red-500' :
                      'bg-amber-500'
                    }`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className={`text-xs ${getStatusColor(capa.status)}`}>
                          <PhaseTooltip status={capa.status} />
                        </Badge>
                        {capa.originType === 'cms_state_survey' && (
                          <Badge variant="outline" className="text-xs">CMS Survey</Badge>
                        )}
                      </div>
                      <p className="font-medium text-foreground truncate">{capa.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {capa.facility} • {capa.department} • Updated {new Date(capa.updatedAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
            <Button variant="ghost" className="w-full mt-4" onClick={() => navigate(`/actionguard/list?bucket=${activeBucket}`)}>
              View All {BUCKET_LABELS[activeBucket].label} CAPAs
            </Button>
          </CardContent>
        </Card>

        {/* CAPAs by Origin Type */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">CAPAs by Origin</CardTitle>
            <CardDescription>Distribution across origin types</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(
                filteredCapas.reduce((acc, capa) => {
                  acc[capa.originType] = (acc[capa.originType] || 0) + 1;
                  return acc;
                }, {} as Record<string, number>)
              )
                .sort((a, b) => b[1] - a[1])
                .slice(0, 6)
                .map(([origin, count]) => {
                  const total = filteredCapas.length;
                  const percentage = total > 0 ? (count / total) * 100 : 0;
                  return (
                    <div key={origin} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-foreground">{originTypeLabels[origin as keyof typeof originTypeLabels]}</span>
                        <span className="font-medium">{count}</span>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                  );
                })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Reopened CAPAs Alert */}
      {activeBucket === 'open' && filteredCapas.filter(c => c.status === 'reopened').length > 0 && (
        <Card className="border-amber-500">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <RotateCcw className="h-5 w-5 text-amber-600" />
              Reopened CAPAs Requiring Attention
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {filteredCapas
                .filter(c => c.status === 'reopened')
                .map(capa => (
                  <div 
                    key={capa.id}
                    className="p-3 border rounded-lg hover:bg-muted/50 cursor-pointer"
                    onClick={() => navigate(`/actionguard/${capa.id}`)}
                  >
                    <p className="font-medium text-foreground">{capa.title}</p>
                    <p className="text-sm text-amber-600 mt-1">{capa.reopenReason}</p>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
