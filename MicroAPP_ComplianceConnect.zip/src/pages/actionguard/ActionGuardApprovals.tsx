import { useState, useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { CheckCircle2, XCircle, Clock, AlertTriangle, User, Calendar, Building2, ChevronRight, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { mockCapasNew, originTypeLabels } from '@/data/actionguardMockData';
import { 
  BUCKET_STATUSES, 
  BucketTabBadge,
  PhaseTooltip
} from '@/components/actionguard/CapaBucketHelpers';

export default function ActionGuardApprovals() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState<'new' | 'open'>('new');

  // CAPAs pending approval (NEW: submitted or in_review status) - DEFAULT FOCUS
  const pendingApproval = useMemo(() => 
    mockCapasNew.filter(c => BUCKET_STATUSES.new.includes(c.status) && c.status !== 'draft'),
    []
  );
  
  // CAPAs pending management review (OPEN: effectiveness_monitoring with managementReviewRequired)
  const pendingManagementReview = useMemo(() => 
    mockCapasNew.filter(c => 
      c.status === 'effectiveness_monitoring' && 
      c.managementReviewRequired && 
      !c.managementReviewSignoff
    ),
    []
  );

  // High severity or SLA breaches
  const highPriority = useMemo(() => 
    pendingApproval.filter(c => c.severity === 'critical' || c.severity === 'high'),
    [pendingApproval]
  );

  // Recently approved
  const recentlyApproved = useMemo(() => 
    mockCapasNew
      .filter(c => c.approvedAt && new Date(c.approvedAt) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000))
      .sort((a, b) => new Date(b.approvedAt!).getTime() - new Date(a.approvedAt!).getTime())
      .slice(0, 5),
    []
  );

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500/10 text-red-600 border-red-500/20';
      case 'high': return 'bg-orange-500/10 text-orange-600 border-orange-500/20';
      case 'medium': return 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20';
      default: return 'bg-green-500/10 text-green-600 border-green-500/20';
    }
  };

  // Calculate review SLA for NEW CAPAs
  const getReviewSla = (submittedAt?: string) => {
    if (!submittedAt) return null;
    return Math.ceil((new Date().getTime() - new Date(submittedAt).getTime()) / (1000 * 60 * 60 * 24));
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Approvals</h1>
        <p className="text-muted-foreground">Review and approve CAPAs awaiting your decision</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-amber-500/30">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-amber-500/10">
              <Clock className="h-6 w-6 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{pendingApproval.length}</p>
              <p className="text-sm text-muted-foreground">NEW Pending Review</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-red-500/10">
              <AlertTriangle className="h-6 w-6 text-red-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-red-600">{highPriority.length}</p>
              <p className="text-sm text-muted-foreground">High/Critical Severity</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-purple-500/10">
              <CheckCircle2 className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{pendingManagementReview.length}</p>
              <p className="text-sm text-muted-foreground">OPEN Mgmt Review</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-green-500/10">
              <CheckCircle2 className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{recentlyApproved.length}</p>
              <p className="text-sm text-muted-foreground">Approved (30 Days)</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bucket Tabs - Default to NEW */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'new' | 'open')}>
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="new" className="gap-2">
            NEW Approvals
            <BucketTabBadge bucket="new" count={pendingApproval.length} />
          </TabsTrigger>
          <TabsTrigger value="open" className="gap-2">
            OPEN Reviews
            <BucketTabBadge bucket="open" count={pendingManagementReview.length} />
          </TabsTrigger>
        </TabsList>

        {/* NEW Approvals Tab (Default) */}
        <TabsContent value="new" className="space-y-4 mt-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <Info className="h-4 w-4" />
            <span>Showing Submitted and In Review CAPAs awaiting approval</span>
          </div>

          {pendingApproval.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="p-8 text-center">
                <CheckCircle2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="font-semibold text-foreground mb-1">All caught up!</h3>
                <p className="text-sm text-muted-foreground">No NEW CAPAs pending your approval</p>
              </CardContent>
            </Card>
          ) : (
            pendingApproval
              .sort((a, b) => {
                // High severity first, then by SLA
                const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
                const aSeverity = severityOrder[a.severity as keyof typeof severityOrder] || 3;
                const bSeverity = severityOrder[b.severity as keyof typeof severityOrder] || 3;
                if (aSeverity !== bSeverity) return aSeverity - bSeverity;
                return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
              })
              .map(capa => {
                const reviewSla = getReviewSla(capa.submittedAt instanceof Date ? capa.submittedAt.toISOString() : capa.submittedAt);
                const isSlaBreached = reviewSla !== null && reviewSla > 2;
                
                return (
                  <Card 
                    key={capa.id} 
                    className={`hover:border-primary/50 transition-colors ${isSlaBreached ? 'border-red-500/50' : ''}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2 flex-wrap">
                            <Badge variant="outline" className={getSeverityColor(capa.severity)}>
                              {capa.severity} severity
                            </Badge>
                            <Badge variant="outline" className={
                              capa.status === 'submitted' 
                                ? 'bg-orange-500/10 text-orange-600 border-orange-500/20'
                                : 'bg-amber-500/10 text-amber-600 border-amber-500/20'
                            }>
                              <PhaseTooltip status={capa.status} />
                            </Badge>
                            <Badge variant="outline">
                              {originTypeLabels[capa.originType]}
                            </Badge>
                            {capa.originType === 'cms_state_survey' && capa.surveyPocData?.ftag && (
                              <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-500/20">
                                {capa.surveyPocData.ftag}
                              </Badge>
                            )}
                            {isSlaBreached && (
                              <Badge variant="outline" className="bg-red-500/10 text-red-600 border-red-500/20">
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                SLA Breach ({reviewSla}d)
                              </Badge>
                            )}
                          </div>
                          <h3 
                            className="font-semibold text-foreground hover:text-primary cursor-pointer"
                            onClick={() => navigate(`/actionguard/${capa.id}`)}
                          >
                            {capa.title}
                          </h3>
                          <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{capa.problemStatement}</p>
                          <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Building2 className="h-3 w-3" /> {capa.facility}
                            </span>
                            <span className="flex items-center gap-1">
                              <User className="h-3 w-3" /> {capa.owner}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" /> Due: {new Date(capa.dueDate).toLocaleDateString()}
                            </span>
                            {reviewSla !== null && (
                              <span className={`flex items-center gap-1 ${isSlaBreached ? 'text-red-600' : ''}`}>
                                <Clock className="h-3 w-3" /> Waiting {reviewSla}d
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-4 mt-2 text-xs">
                            <span>{capa.correctiveActions.length} corrective actions</span>
                            <span>{capa.preventiveActions.length} preventive actions</span>
                            <span>{capa.effectivenessCriteria.length} effectiveness criteria</span>
                          </div>
                        </div>
                        <Button size="sm" onClick={() => navigate(`/actionguard/${capa.id}`)} className="gap-1">
                          View Details <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
          )}
        </TabsContent>

        {/* OPEN Management Review Tab */}
        <TabsContent value="open" className="space-y-4 mt-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <Info className="h-4 w-4" />
            <span>Showing OPEN CAPAs in Effectiveness Monitoring requiring management sign-off</span>
          </div>

          {pendingManagementReview.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="p-8 text-center">
                <CheckCircle2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="font-semibold text-foreground mb-1">No pending reviews</h3>
                <p className="text-sm text-muted-foreground">No OPEN CAPAs require management review sign-off</p>
              </CardContent>
            </Card>
          ) : (
            pendingManagementReview.map(capa => (
              <Card key={capa.id} className="hover:border-primary/50 transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline" className="bg-indigo-500/10 text-indigo-600 border-indigo-500/20">
                          <PhaseTooltip status={capa.status} />
                        </Badge>
                        <Badge variant="outline">Requires Management Sign-off</Badge>
                      </div>
                      <h3 
                        className="font-semibold text-foreground hover:text-primary cursor-pointer"
                        onClick={() => navigate(`/actionguard/${capa.id}`)}
                      >
                        {capa.title}
                      </h3>
                      <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Building2 className="h-3 w-3" /> {capa.facility}
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3" /> {capa.owner}
                        </span>
                      </div>
                      {capa.effectivenessResult && (
                        <div className={`mt-2 inline-flex items-center gap-1 text-sm ${
                          capa.effectivenessResult === 'pass' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {capa.effectivenessResult === 'pass' ? (
                            <CheckCircle2 className="h-4 w-4" />
                          ) : (
                            <XCircle className="h-4 w-4" />
                          )}
                          Effectiveness: {capa.effectivenessResult.toUpperCase()}
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col gap-2">
                      <Button size="sm" onClick={() => navigate(`/actionguard/${capa.id}`)} className="gap-1">
                        Review & Sign-off <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}

          {/* Recently Approved Section */}
          {recentlyApproved.length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-base">Recently Approved (Last 30 Days)</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {recentlyApproved.map(capa => (
                  <div 
                    key={capa.id} 
                    className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 cursor-pointer"
                    onClick={() => navigate(`/actionguard/${capa.id}`)}
                  >
                    <div>
                      <p className="font-medium text-foreground text-sm">{capa.title}</p>
                      <p className="text-xs text-muted-foreground">
                        Approved {capa.approvedAt ? new Date(capa.approvedAt).toLocaleDateString() : 'N/A'} • {capa.facility}
                      </p>
                    </div>
                    <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/20 text-xs">
                      <CheckCircle2 className="h-3 w-3 mr-1" /> Approved
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

    </div>
  );
}
