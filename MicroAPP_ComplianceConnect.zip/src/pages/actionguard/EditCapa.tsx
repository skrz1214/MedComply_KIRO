import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Check, Save, AlertTriangle, Calendar, Plus, Trash2, Info, Link2, X, Shield, FileSearch, MessageSquare, Scale, ClipboardList, BookOpen, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';
import { CapaOriginTypeNew, CapaActionType, RcaMethodNew, ContributingFactor, PatientRisk, VerificationType } from '@/types/actionguard';
import { Priority } from '@/types/compliance';
import { originTypeLabels, actionTypeLabels, mockActionGuardUsers, mockCapasNew } from '@/data/actionguardMockData';
import { microappConfigs, CrossReferenceItemType, MicroappType } from '@/types/crossReference';

const STEPS = [
  { id: 1, title: 'Basics', description: 'Origin, location, severity' },
  { id: 2, title: 'Containment', description: 'Immediate actions' },
  { id: 3, title: 'RCA', description: 'Root cause analysis' },
  { id: 4, title: 'Action Plan', description: 'Corrective & preventive' },
  { id: 5, title: 'Verification', description: 'Verification & effectiveness' },
  { id: 6, title: 'QAPI', description: 'Quality improvement' },
  { id: 7, title: 'Review', description: 'Review & save' },
];

const facilities = [
  { id: 'fac-1', name: 'Main Hospital', units: ['ICU', 'Med-Surg', 'Emergency', 'Pediatrics'] },
  { id: 'fac-2', name: 'Downtown Clinic', units: ['Outpatient', 'Urgent Care'] },
  { id: 'fac-3', name: 'Sunrise Nursing Home', units: ['Memory Care Unit', 'East Wing', 'West Wing', 'South Wing'] },
];

const departments = ['nursing', 'pharmacy', 'laboratory', 'radiology', 'administration', 'it', 'quality_assurance', 'compliance', 'dietary', 'maintenance'];

interface LinkedItem {
  microapp: MicroappType;
  itemType: CrossReferenceItemType;
  id: string;
  title: string;
  status: string;
}

export default function EditCapa() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(true);

  // Find the CAPA to edit
  const capa = mockCapasNew.find(c => c.id === id);

  // Step 1: Basics
  const [title, setTitle] = useState('');
  const [problemStatement, setProblemStatement] = useState('');
  const [originType, setOriginType] = useState<CapaOriginTypeNew | ''>('');
  const [facility, setFacility] = useState('');
  const [unitWing, setUnitWing] = useState('');
  const [department, setDepartment] = useState('');
  const [severity, setSeverity] = useState<Priority | ''>('');
  const [priority, setPriority] = useState<Priority | ''>('');
  const [patientRisk, setPatientRisk] = useState<PatientRisk>('none');
  const [harmPotentialNotes, setHarmPotentialNotes] = useState('');
  const [owner, setOwner] = useState('');
  const [departmentHead, setDepartmentHead] = useState('');
  const [complianceHead, setComplianceHead] = useState('');
  const [dueDate, setDueDate] = useState('');
  
  // CMS/State Survey fields
  const [surveyDate, setSurveyDate] = useState('');
  const [cms2567ReceivedDate, setCms2567ReceivedDate] = useState('');
  const [ftag, setFtag] = useState('');
  const [scopeSeverity, setScopeSeverity] = useState('');

  // Cross-references
  const [linkedItems, setLinkedItems] = useState<LinkedItem[]>([]);
  const [showLinkDialog, setShowLinkDialog] = useState(false);
  const [selectedMicroapp, setSelectedMicroapp] = useState<MicroappType | ''>('');

  // Step 2: Containment
  const [containmentActions, setContainmentActions] = useState<{ description: string; who: string; when: string }[]>([]);
  const [immediateRiskMitigationComplete, setImmediateRiskMitigationComplete] = useState(false);
  const [riskMitigationNotes, setRiskMitigationNotes] = useState('');

  // Step 3: RCA
  const [rcaMethod, setRcaMethod] = useState<RcaMethodNew | ''>('');
  const [rcaSummary, setRcaSummary] = useState('');
  const [contributingFactors, setContributingFactors] = useState<ContributingFactor[]>([]);
  const [rootCauses, setRootCauses] = useState<{ statement: string; category: ContributingFactor | ''; justification: string }[]>([]);

  // Step 4: Actions
  const [correctiveActions, setCorrectiveActions] = useState<{ actionType: CapaActionType | ''; title: string; description: string; owner: string; dueDate: string; evidenceRequired: boolean }[]>([]);
  const [preventiveActions, setPreventiveActions] = useState<{ actionType: CapaActionType | ''; title: string; description: string; owner: string; dueDate: string; evidenceRequired: boolean }[]>([]);

  // Step 5: Verification & Effectiveness
  const [effectivenessCriteria, setEffectivenessCriteria] = useState<{ criteria: string; kpi: string; baseline: string; target: string }[]>([]);
  const [monitoringWhatToMonitor, setMonitoringWhatToMonitor] = useState('');
  const [monitoringFrequency, setMonitoringFrequency] = useState('');
  const [monitoringDuration, setMonitoringDuration] = useState('');
  const [monitoringOwner, setMonitoringOwner] = useState('');
  const [monitoringEscalation, setMonitoringEscalation] = useState('');
  const [effectivenessDueDate, setEffectivenessDueDate] = useState('');

  // Step 6: QAPI
  const [qapiFlag, setQapiFlag] = useState(false);
  const [pipReference, setPipReference] = useState('');
  const [qapiMetrics, setQapiMetrics] = useState<string[]>([]);

  // Load existing CAPA data
  useEffect(() => {
    if (capa) {
      setTitle(capa.title);
      setProblemStatement(capa.problemStatement);
      setOriginType(capa.originType);
      setFacility(capa.facility);
      setUnitWing(capa.unitWing || '');
      setDepartment(capa.department);
      setSeverity(capa.severity as Priority);
      setPriority(capa.priority as Priority);
      setPatientRisk(capa.patientRisk);
      setHarmPotentialNotes(capa.harmPotentialNotes || '');
      setOwner(capa.owner);
      setDepartmentHead(capa.departmentHead || '');
      setComplianceHead(capa.complianceHead || '');
      setDueDate(capa.dueDate instanceof Date ? capa.dueDate.toISOString().split('T')[0] : String(capa.dueDate).split('T')[0]);
      
      // Containment
      if (capa.containmentActions) {
        setContainmentActions(capa.containmentActions.map(a => ({
          description: a.description,
          who: a.who,
          when: a.when instanceof Date ? a.when.toISOString().split('T')[0] : ''
        })));
      }
      setImmediateRiskMitigationComplete(capa.immediateRiskMitigationComplete || false);
      setRiskMitigationNotes(capa.riskMitigationNotes || '');
      
      // RCA
      if (capa.rca) {
        setRcaMethod(capa.rca.method);
        setRcaSummary(capa.rca.summary);
        setContributingFactors(capa.rca.contributingFactors || []);
        if (capa.rca.rootCauses) {
          setRootCauses(capa.rca.rootCauses.map(rc => ({
            statement: rc.statement,
            category: rc.category,
            justification: rc.justification
          })));
        }
      }
      
      // Actions
      if (capa.correctiveActions) {
        setCorrectiveActions(capa.correctiveActions.map(a => ({
          actionType: a.actionType,
          title: a.title,
          description: a.description,
          owner: a.owner,
          dueDate: a.dueDate instanceof Date ? a.dueDate.toISOString().split('T')[0] : String(a.dueDate).split('T')[0],
          evidenceRequired: a.evidenceRequired
        })));
      }
      if (capa.preventiveActions) {
        setPreventiveActions(capa.preventiveActions.map(a => ({
          actionType: a.actionType,
          title: a.title,
          description: a.description,
          owner: a.owner,
          dueDate: a.dueDate instanceof Date ? a.dueDate.toISOString().split('T')[0] : String(a.dueDate).split('T')[0],
          evidenceRequired: a.evidenceRequired
        })));
      }
      
      // Effectiveness
      if (capa.effectivenessCriteria) {
        setEffectivenessCriteria(capa.effectivenessCriteria.map(ec => ({
          criteria: ec.criteria,
          kpi: ec.kpi || '',
          baseline: ec.baseline || '',
          target: ec.target
        })));
      }
      if (capa.monitoringPlan) {
        setMonitoringWhatToMonitor(capa.monitoringPlan.whatToMonitor);
        setMonitoringFrequency(capa.monitoringPlan.frequency);
        setMonitoringDuration(capa.monitoringPlan.duration);
        setMonitoringOwner(capa.monitoringPlan.owner);
        setMonitoringEscalation(capa.monitoringPlan.escalationRule || '');
      }
      if (capa.effectivenessDueDate) {
        const effDate = capa.effectivenessDueDate instanceof Date ? capa.effectivenessDueDate.toISOString().split('T')[0] : String(capa.effectivenessDueDate).split('T')[0];
        setEffectivenessDueDate(effDate);
      }
      
      // QAPI
      setQapiFlag(capa.qapiFlag || false);
      setPipReference(capa.pipReference || '');
      setQapiMetrics(capa.qapiMetricsLinked || []);
      
      // Survey data
      if (capa.surveyPocData) {
        if (capa.surveyPocData.surveyDate) {
          const survDate = capa.surveyPocData.surveyDate instanceof Date ? capa.surveyPocData.surveyDate.toISOString().split('T')[0] : '';
          setSurveyDate(survDate);
        }
        if (capa.surveyPocData.cms2567ReceivedDate) {
          const cmsDate = capa.surveyPocData.cms2567ReceivedDate instanceof Date ? capa.surveyPocData.cms2567ReceivedDate.toISOString().split('T')[0] : '';
          setCms2567ReceivedDate(cmsDate);
        }
        setFtag(capa.surveyPocData.ftag || '');
        setScopeSeverity(capa.surveyPocData.scopeSeverity || '');
      }
      
      setIsLoading(false);
    }
  }, [capa]);

  const selectedFacility = facilities.find(f => f.name === facility);
  const departmentHeads = mockActionGuardUsers.filter(u => u.role === 'Department Head' || u.role === 'Admin');
  const complianceHeads = mockActionGuardUsers.filter(u => u.role === 'Compliance Head' || u.role === 'Admin');
  const staffUsers = mockActionGuardUsers.filter(u => u.role === 'Staff' || u.role === 'Department Head');

  const handleSave = () => {
    toast({
      title: 'CAPA Updated',
      description: 'Your changes have been saved successfully.',
    });
    navigate(`/actionguard/${id}`);
  };

  const handleCancel = () => {
    navigate(`/actionguard/${id}`);
  };

  if (!capa) {
    return (
      <div className="p-6">
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold text-foreground">CAPA not found</h2>
          <Button variant="outline" onClick={() => navigate('/actionguard')} className="mt-4">
            Back to CAPAs
          </Button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="text-center py-12">
          <p className="text-muted-foreground">Loading CAPA data...</p>
        </div>
      </div>
    );
  }

  const addContainmentAction = () => {
    setContainmentActions([...containmentActions, { description: '', who: '', when: '' }]);
  };

  const removeContainmentAction = (index: number) => {
    setContainmentActions(containmentActions.filter((_, i) => i !== index));
  };

  const addRootCause = () => {
    setRootCauses([...rootCauses, { statement: '', category: '', justification: '' }]);
  };

  const removeRootCause = (index: number) => {
    setRootCauses(rootCauses.filter((_, i) => i !== index));
  };

  const addCorrectiveAction = () => {
    setCorrectiveActions([...correctiveActions, { actionType: '', title: '', description: '', owner: '', dueDate: '', evidenceRequired: false }]);
  };

  const removeCorrectiveAction = (index: number) => {
    setCorrectiveActions(correctiveActions.filter((_, i) => i !== index));
  };

  const addPreventiveAction = () => {
    setPreventiveActions([...preventiveActions, { actionType: '', title: '', description: '', owner: '', dueDate: '', evidenceRequired: false }]);
  };

  const removePreventiveAction = (index: number) => {
    setPreventiveActions(preventiveActions.filter((_, i) => i !== index));
  };

  const addEffectivenessCriteria = () => {
    setEffectivenessCriteria([...effectivenessCriteria, { criteria: '', kpi: '', baseline: '', target: '' }]);
  };

  const removeEffectivenessCriteria = (index: number) => {
    setEffectivenessCriteria(effectivenessCriteria.filter((_, i) => i !== index));
  };

  const nextStep = () => {
    if (currentStep < STEPS.length) setCurrentStep(currentStep + 1);
  };

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card/50 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={handleCancel}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-xl font-semibold text-foreground">Edit CAPA: {capa.id}</h1>
              <p className="text-sm text-muted-foreground">Modify CAPA details</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
            <Button onClick={handleSave} className="gap-2">
              <Save className="h-4 w-4" /> Save Changes
            </Button>
          </div>
        </div>
      </div>

      <div className="flex">
        {/* Stepper Sidebar */}
        <div className="w-64 border-r border-border bg-muted/30 p-4 min-h-[calc(100vh-73px)]">
          <div className="space-y-1">
            {STEPS.map((step, index) => (
              <button
                key={step.id}
                onClick={() => setCurrentStep(step.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors text-left ${
                  currentStep === step.id
                    ? 'bg-primary/10 text-primary'
                    : currentStep > step.id
                    ? 'text-green-600'
                    : 'text-muted-foreground hover:bg-muted'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                    currentStep === step.id
                      ? 'bg-primary text-white'
                      : currentStep > step.id
                      ? 'bg-green-600 text-white'
                      : 'bg-muted text-muted-foreground'
                  }`}
                >
                  {currentStep > step.id ? <Check className="h-3 w-3" /> : step.id}
                </div>
                <div>
                  <p className="text-sm font-medium">{step.title}</p>
                  <p className="text-xs text-muted-foreground">{step.description}</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6 overflow-auto max-h-[calc(100vh-73px)]">
          {/* Step 1: Basics */}
          {currentStep === 1 && (
            <div className="space-y-6 max-w-3xl">
              <Card>
                <CardHeader>
                  <CardTitle>Basic Information</CardTitle>
                  <CardDescription>Edit the core CAPA details</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="title">CAPA Title *</Label>
                    <Input
                      id="title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="Brief descriptive title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="problem">Problem Statement *</Label>
                    <Textarea
                      id="problem"
                      value={problemStatement}
                      onChange={(e) => setProblemStatement(e.target.value)}
                      placeholder="Describe the problem or nonconformance"
                      rows={4}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Origin Type *</Label>
                      <Select value={originType} onValueChange={(v) => setOriginType(v as CapaOriginTypeNew)}>
                        <SelectTrigger><SelectValue placeholder="Select origin" /></SelectTrigger>
                        <SelectContent className="bg-background border">
                          {Object.entries(originTypeLabels).map(([key, label]) => (
                            <SelectItem key={key} value={key}>{label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Facility *</Label>
                      <Select value={facility} onValueChange={setFacility}>
                        <SelectTrigger><SelectValue placeholder="Select facility" /></SelectTrigger>
                        <SelectContent className="bg-background border">
                          {facilities.map(f => (
                            <SelectItem key={f.id} value={f.name}>{f.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Unit/Wing</Label>
                      <Select value={unitWing} onValueChange={setUnitWing} disabled={!selectedFacility}>
                        <SelectTrigger><SelectValue placeholder="Select unit" /></SelectTrigger>
                        <SelectContent className="bg-background border">
                          {selectedFacility?.units.map(u => (
                            <SelectItem key={u} value={u}>{u}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Department *</Label>
                      <Select value={department} onValueChange={setDepartment}>
                        <SelectTrigger><SelectValue placeholder="Select department" /></SelectTrigger>
                        <SelectContent className="bg-background border">
                          {departments.map(d => (
                            <SelectItem key={d} value={d}>{d.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Severity *</Label>
                      <Select value={severity} onValueChange={(v) => setSeverity(v as Priority)}>
                        <SelectTrigger><SelectValue placeholder="Select severity" /></SelectTrigger>
                        <SelectContent className="bg-background border">
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="critical">Critical</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Priority *</Label>
                      <Select value={priority} onValueChange={(v) => setPriority(v as Priority)}>
                        <SelectTrigger><SelectValue placeholder="Select priority" /></SelectTrigger>
                        <SelectContent className="bg-background border">
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="critical">Critical</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label>Due Date *</Label>
                    <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Ownership</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label>Owner *</Label>
                      <Select value={owner} onValueChange={setOwner}>
                        <SelectTrigger><SelectValue placeholder="Select owner" /></SelectTrigger>
                        <SelectContent className="bg-background border">
                          {staffUsers.map(u => (
                            <SelectItem key={u.id} value={u.name}>{u.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Department Head</Label>
                      <Select value={departmentHead} onValueChange={setDepartmentHead}>
                        <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                        <SelectContent className="bg-background border">
                          {departmentHeads.map(u => (
                            <SelectItem key={u.id} value={u.name}>{u.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Compliance Head</Label>
                      <Select value={complianceHead} onValueChange={setComplianceHead}>
                        <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                        <SelectContent className="bg-background border">
                          {complianceHeads.map(u => (
                            <SelectItem key={u.id} value={u.name}>{u.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Step 2: Containment */}
          {currentStep === 2 && (
            <div className="space-y-6 max-w-3xl">
              <Card>
                <CardHeader>
                  <CardTitle>Containment Actions</CardTitle>
                  <CardDescription>Immediate actions taken to contain the problem</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {containmentActions.map((action, index) => (
                    <div key={index} className="p-4 border rounded-lg space-y-3">
                      <div className="flex justify-between items-start">
                        <Label>Action {index + 1}</Label>
                        <Button variant="ghost" size="icon" onClick={() => removeContainmentAction(index)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                      <Textarea
                        value={action.description}
                        onChange={(e) => {
                          const updated = [...containmentActions];
                          updated[index].description = e.target.value;
                          setContainmentActions(updated);
                        }}
                        placeholder="Describe the containment action"
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Responsible Person</Label>
                          <Input
                            value={action.who}
                            onChange={(e) => {
                              const updated = [...containmentActions];
                              updated[index].who = e.target.value;
                              setContainmentActions(updated);
                            }}
                          />
                        </div>
                        <div>
                          <Label>Date Implemented</Label>
                          <Input
                            type="date"
                            value={action.when}
                            onChange={(e) => {
                              const updated = [...containmentActions];
                              updated[index].when = e.target.value;
                              setContainmentActions(updated);
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                  <Button variant="outline" onClick={addContainmentAction} className="gap-2">
                    <Plus className="h-4 w-4" /> Add Containment Action
                  </Button>

                  <Separator />

                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="risk-complete"
                      checked={immediateRiskMitigationComplete}
                      onCheckedChange={(v) => setImmediateRiskMitigationComplete(v as boolean)}
                    />
                    <Label htmlFor="risk-complete">Immediate risk mitigation complete</Label>
                  </div>
                  <div>
                    <Label>Risk Mitigation Notes</Label>
                    <Textarea
                      value={riskMitigationNotes}
                      onChange={(e) => setRiskMitigationNotes(e.target.value)}
                      placeholder="Additional notes about risk mitigation..."
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Step 3: RCA */}
          {currentStep === 3 && (
            <div className="space-y-6 max-w-3xl">
              <Card>
                <CardHeader>
                  <CardTitle>Root Cause Analysis</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>RCA Method</Label>
                    <Select value={rcaMethod} onValueChange={(v) => setRcaMethod(v as RcaMethodNew)}>
                      <SelectTrigger><SelectValue placeholder="Select method" /></SelectTrigger>
                      <SelectContent className="bg-background border">
                        <SelectItem value="five_whys">5 Whys</SelectItem>
                        <SelectItem value="fishbone">Fishbone (Ishikawa)</SelectItem>
                        <SelectItem value="pareto">Pareto Analysis</SelectItem>
                        <SelectItem value="fault_tree">Fault Tree</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>RCA Summary</Label>
                    <Textarea
                      value={rcaSummary}
                      onChange={(e) => setRcaSummary(e.target.value)}
                      placeholder="Summary of root cause analysis findings"
                      rows={4}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Root Causes</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {rootCauses.map((rc, index) => (
                    <div key={index} className="p-4 border rounded-lg space-y-3">
                      <div className="flex justify-between items-start">
                        <Label>Root Cause {index + 1}</Label>
                        <Button variant="ghost" size="icon" onClick={() => removeRootCause(index)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                      <Input
                        value={rc.statement}
                        onChange={(e) => {
                          const updated = [...rootCauses];
                          updated[index].statement = e.target.value;
                          setRootCauses(updated);
                        }}
                        placeholder="Root cause statement"
                      />
                      <Select
                        value={rc.category}
                        onValueChange={(v) => {
                          const updated = [...rootCauses];
                          updated[index].category = v as ContributingFactor;
                          setRootCauses(updated);
                        }}
                      >
                        <SelectTrigger><SelectValue placeholder="Category" /></SelectTrigger>
                        <SelectContent className="bg-background border">
                          <SelectItem value="human_factors">Human Factors</SelectItem>
                          <SelectItem value="process_system">Process/System</SelectItem>
                          <SelectItem value="equipment">Equipment</SelectItem>
                          <SelectItem value="environment">Environment</SelectItem>
                          <SelectItem value="communication">Communication</SelectItem>
                          <SelectItem value="training">Training</SelectItem>
                          <SelectItem value="policy_procedure">Policy/Procedure</SelectItem>
                          <SelectItem value="supervision">Supervision</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <Textarea
                        value={rc.justification}
                        onChange={(e) => {
                          const updated = [...rootCauses];
                          updated[index].justification = e.target.value;
                          setRootCauses(updated);
                        }}
                        placeholder="Justification / evidence"
                      />
                    </div>
                  ))}
                  <Button variant="outline" onClick={addRootCause} className="gap-2">
                    <Plus className="h-4 w-4" /> Add Root Cause
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Step 4: Action Plan */}
          {currentStep === 4 && (
            <div className="space-y-6 max-w-3xl">
              <Card>
                <CardHeader>
                  <CardTitle>Corrective Actions</CardTitle>
                  <CardDescription>Actions to correct the identified problem</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {correctiveActions.map((action, index) => (
                    <div key={index} className="p-4 border rounded-lg space-y-3">
                      <div className="flex justify-between items-start">
                        <Label>Corrective Action {index + 1}</Label>
                        <Button variant="ghost" size="icon" onClick={() => removeCorrectiveAction(index)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                      <Input
                        value={action.title}
                        onChange={(e) => {
                          const updated = [...correctiveActions];
                          updated[index].title = e.target.value;
                          setCorrectiveActions(updated);
                        }}
                        placeholder="Action title"
                      />
                      <Select
                        value={action.actionType}
                        onValueChange={(v) => {
                          const updated = [...correctiveActions];
                          updated[index].actionType = v as CapaActionType;
                          setCorrectiveActions(updated);
                        }}
                      >
                        <SelectTrigger><SelectValue placeholder="Action type" /></SelectTrigger>
                        <SelectContent className="bg-background border">
                          {Object.entries(actionTypeLabels).map(([key, label]) => (
                            <SelectItem key={key} value={key}>{label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Textarea
                        value={action.description}
                        onChange={(e) => {
                          const updated = [...correctiveActions];
                          updated[index].description = e.target.value;
                          setCorrectiveActions(updated);
                        }}
                        placeholder="Description"
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Owner</Label>
                          <Select
                            value={action.owner}
                            onValueChange={(v) => {
                              const updated = [...correctiveActions];
                              updated[index].owner = v;
                              setCorrectiveActions(updated);
                            }}
                          >
                            <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                            <SelectContent className="bg-background border">
                              {staffUsers.map(u => (
                                <SelectItem key={u.id} value={u.name}>{u.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Due Date</Label>
                          <Input
                            type="date"
                            value={action.dueDate}
                            onChange={(e) => {
                              const updated = [...correctiveActions];
                              updated[index].dueDate = e.target.value;
                              setCorrectiveActions(updated);
                            }}
                          />
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={action.evidenceRequired}
                          onCheckedChange={(v) => {
                            const updated = [...correctiveActions];
                            updated[index].evidenceRequired = v as boolean;
                            setCorrectiveActions(updated);
                          }}
                        />
                        <Label>Evidence required</Label>
                      </div>
                    </div>
                  ))}
                  <Button variant="outline" onClick={addCorrectiveAction} className="gap-2">
                    <Plus className="h-4 w-4" /> Add Corrective Action
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Preventive Actions</CardTitle>
                  <CardDescription>Actions to prevent recurrence</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {preventiveActions.map((action, index) => (
                    <div key={index} className="p-4 border rounded-lg space-y-3">
                      <div className="flex justify-between items-start">
                        <Label>Preventive Action {index + 1}</Label>
                        <Button variant="ghost" size="icon" onClick={() => removePreventiveAction(index)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                      <Input
                        value={action.title}
                        onChange={(e) => {
                          const updated = [...preventiveActions];
                          updated[index].title = e.target.value;
                          setPreventiveActions(updated);
                        }}
                        placeholder="Action title"
                      />
                      <Select
                        value={action.actionType}
                        onValueChange={(v) => {
                          const updated = [...preventiveActions];
                          updated[index].actionType = v as CapaActionType;
                          setPreventiveActions(updated);
                        }}
                      >
                        <SelectTrigger><SelectValue placeholder="Action type" /></SelectTrigger>
                        <SelectContent className="bg-background border">
                          {Object.entries(actionTypeLabels).map(([key, label]) => (
                            <SelectItem key={key} value={key}>{label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Textarea
                        value={action.description}
                        onChange={(e) => {
                          const updated = [...preventiveActions];
                          updated[index].description = e.target.value;
                          setPreventiveActions(updated);
                        }}
                        placeholder="Description"
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Owner</Label>
                          <Select
                            value={action.owner}
                            onValueChange={(v) => {
                              const updated = [...preventiveActions];
                              updated[index].owner = v;
                              setPreventiveActions(updated);
                            }}
                          >
                            <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                            <SelectContent className="bg-background border">
                              {staffUsers.map(u => (
                                <SelectItem key={u.id} value={u.name}>{u.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Due Date</Label>
                          <Input
                            type="date"
                            value={action.dueDate}
                            onChange={(e) => {
                              const updated = [...preventiveActions];
                              updated[index].dueDate = e.target.value;
                              setPreventiveActions(updated);
                            }}
                          />
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={action.evidenceRequired}
                          onCheckedChange={(v) => {
                            const updated = [...preventiveActions];
                            updated[index].evidenceRequired = v as boolean;
                            setPreventiveActions(updated);
                          }}
                        />
                        <Label>Evidence required</Label>
                      </div>
                    </div>
                  ))}
                  <Button variant="outline" onClick={addPreventiveAction} className="gap-2">
                    <Plus className="h-4 w-4" /> Add Preventive Action
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Step 5: Verification & Effectiveness */}
          {currentStep === 5 && (
            <div className="space-y-6 max-w-3xl">
              <Card>
                <CardHeader>
                  <CardTitle>Effectiveness Criteria</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {effectivenessCriteria.map((ec, index) => (
                    <div key={index} className="p-4 border rounded-lg space-y-3">
                      <div className="flex justify-between items-start">
                        <Label>Criteria {index + 1}</Label>
                        <Button variant="ghost" size="icon" onClick={() => removeEffectivenessCriteria(index)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                      <Input
                        value={ec.criteria}
                        onChange={(e) => {
                          const updated = [...effectivenessCriteria];
                          updated[index].criteria = e.target.value;
                          setEffectivenessCriteria(updated);
                        }}
                        placeholder="Success criteria"
                      />
                      <div className="grid grid-cols-3 gap-4">
                        <Input
                          value={ec.kpi}
                          onChange={(e) => {
                            const updated = [...effectivenessCriteria];
                            updated[index].kpi = e.target.value;
                            setEffectivenessCriteria(updated);
                          }}
                          placeholder="KPI"
                        />
                        <Input
                          value={ec.baseline}
                          onChange={(e) => {
                            const updated = [...effectivenessCriteria];
                            updated[index].baseline = e.target.value;
                            setEffectivenessCriteria(updated);
                          }}
                          placeholder="Baseline"
                        />
                        <Input
                          value={ec.target}
                          onChange={(e) => {
                            const updated = [...effectivenessCriteria];
                            updated[index].target = e.target.value;
                            setEffectivenessCriteria(updated);
                          }}
                          placeholder="Target"
                        />
                      </div>
                    </div>
                  ))}
                  <Button variant="outline" onClick={addEffectivenessCriteria} className="gap-2">
                    <Plus className="h-4 w-4" /> Add Criteria
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Monitoring Plan</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>What to Monitor</Label>
                    <Textarea
                      value={monitoringWhatToMonitor}
                      onChange={(e) => setMonitoringWhatToMonitor(e.target.value)}
                      placeholder="Describe what will be monitored"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Frequency</Label>
                      <Select value={monitoringFrequency} onValueChange={setMonitoringFrequency}>
                        <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                        <SelectContent className="bg-background border">
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="biweekly">Bi-weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                          <SelectItem value="quarterly">Quarterly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Duration</Label>
                      <Select value={monitoringDuration} onValueChange={setMonitoringDuration}>
                        <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                        <SelectContent className="bg-background border">
                          <SelectItem value="30_days">30 Days</SelectItem>
                          <SelectItem value="60_days">60 Days</SelectItem>
                          <SelectItem value="90_days">90 Days</SelectItem>
                          <SelectItem value="6_months">6 Months</SelectItem>
                          <SelectItem value="1_year">1 Year</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label>Monitoring Owner</Label>
                    <Select value={monitoringOwner} onValueChange={setMonitoringOwner}>
                      <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                      <SelectContent className="bg-background border">
                        {staffUsers.map(u => (
                          <SelectItem key={u.id} value={u.name}>{u.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Escalation Criteria</Label>
                    <Textarea
                      value={monitoringEscalation}
                      onChange={(e) => setMonitoringEscalation(e.target.value)}
                      placeholder="When/how to escalate if targets not met"
                    />
                  </div>
                  <div>
                    <Label>Effectiveness Due Date</Label>
                    <Input
                      type="date"
                      value={effectivenessDueDate}
                      onChange={(e) => setEffectivenessDueDate(e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Step 6: QAPI */}
          {currentStep === 6 && (
            <div className="space-y-6 max-w-3xl">
              <Card>
                <CardHeader>
                  <CardTitle>QAPI Integration</CardTitle>
                  <CardDescription>Quality Assurance & Performance Improvement</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="qapi-flag"
                      checked={qapiFlag}
                      onCheckedChange={(v) => setQapiFlag(v as boolean)}
                    />
                    <Label htmlFor="qapi-flag">Include in QAPI Reporting</Label>
                  </div>
                  {qapiFlag && (
                    <>
                      <div>
                        <Label>PIP Reference (optional)</Label>
                        <Input
                          value={pipReference}
                          onChange={(e) => setPipReference(e.target.value)}
                          placeholder="Related Performance Improvement Project"
                        />
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {/* Step 7: Review */}
          {currentStep === 7 && (
            <div className="space-y-6 max-w-3xl">
              <Card>
                <CardHeader>
                  <CardTitle>Review & Save</CardTitle>
                  <CardDescription>Review your changes before saving</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-muted-foreground">Title</Label>
                      <p className="font-medium">{title || '-'}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Origin Type</Label>
                      <p className="font-medium">{originType ? originTypeLabels[originType] : '-'}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Facility</Label>
                      <p className="font-medium">{facility || '-'}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Department</Label>
                      <p className="font-medium">{department?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) || '-'}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Owner</Label>
                      <p className="font-medium">{owner || '-'}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Due Date</Label>
                      <p className="font-medium">{dueDate || '-'}</p>
                    </div>
                  </div>
                  <Separator />
                  <div>
                    <Label className="text-muted-foreground">Problem Statement</Label>
                    <p className="mt-1">{problemStatement || '-'}</p>
                  </div>
                  <Separator />
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label className="text-muted-foreground">Containment Actions</Label>
                      <p className="font-medium">{containmentActions.length}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Root Causes</Label>
                      <p className="font-medium">{rootCauses.length}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Total Actions</Label>
                      <p className="font-medium">{correctiveActions.length + preventiveActions.length}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={handleCancel}>Cancel</Button>
                <Button onClick={handleSave} className="gap-2">
                  <Save className="h-4 w-4" /> Save Changes
                </Button>
              </div>
            </div>
          )}

          {/* Navigation */}
          {currentStep < 7 && (
            <div className="flex justify-between mt-6 max-w-3xl">
              <Button variant="outline" onClick={prevStep} disabled={currentStep === 1}>
                <ArrowLeft className="h-4 w-4 mr-2" /> Previous
              </Button>
              <Button onClick={nextStep}>
                Next <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
