// Admin Configuration Types

export type AdminRole = 'Admin' | 'Compliance Head' | 'Department Head' | 'Staff';

// Organization & Access
export interface Facility {
  id: string;
  name: string;
  address?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Department {
  id: string;
  name: string;
  facilityId: string;
  departmentHeadId?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: AdminRole;
  departmentId?: string;
  facilityId?: string;
  isActive: boolean;
  createdAt: string;
}

// Compliance Issues Configuration
export interface IssueType {
  id: string;
  name: string;
  description: string;
  isActive: boolean;
  order: number;
}

export interface IssueCategory {
  id: string;
  typeId: string;
  name: string;
  description?: string;
  isActive: boolean;
  order: number;
}

export interface PriorityLevel {
  id: string;
  name: string;
  description: string;
  slaDays: number;
  color: string;
  order: number;
}

export interface RecommendedAction {
  id: string;
  typeId: string;
  categoryId?: string;
  text: string;
  defaultOwnerRole: AdminRole;
  defaultDueDays: number;
  evidenceRequired: boolean;
  sourceUrl?: string;
  isActive: boolean;
}

export interface MonitoringDestination {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
  order: number;
}

// CAPA Configuration
export interface CapaOriginType {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
  order: number;
}

export interface CapaSeveritySLA {
  id: string;
  severity: string;
  defaultDueDays: number;
  reviewSlaDays: number;
  warningThresholdDays: number;
}

export interface CapaTemplate {
  id: string;
  name: string;
  description: string;
  requiresContainment: boolean;
  requiresRCA: boolean;
  requiresPreventiveActions: boolean;
  requiresVerification: boolean;
  requiresEffectivenessMonitoring: boolean;
  requiresManagementReview: boolean;
  defaultActionTypes: string[];
  monitoringDurationDays: number;
  monitoringFrequency: string;
  isLTC: boolean;
  isActive: boolean;
}

export interface CapaActionType {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
  order: number;
}

export interface RCAMethod {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
  order: number;
}

export interface ContributingFactor {
  id: string;
  category: string;
  name: string;
  isActive: boolean;
}

export interface VerificationType {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
}

export interface EffectivenessKPI {
  id: string;
  name: string;
  description?: string;
  unit: string;
  isActive: boolean;
}

export interface ClosureReason {
  id: string;
  name: string;
  description?: string;
  requiresJustification: boolean;
  isActive: boolean;
}

// Citations Configuration
export interface CitationSource {
  id: string;
  name: string;
  abbreviation?: string;
  isActive: boolean;
  order: number;
}

export interface Jurisdiction {
  id: string;
  name: string;
  type: 'Federal' | 'State' | 'Local';
  isActive: boolean;
}

export interface FacilityType {
  id: string;
  name: string;
  abbreviation?: string;
  isActive: boolean;
}

export interface EvidenceType {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
  order: number;
}

export interface RiskDomain {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
  order: number;
}

// Citation Cases Configuration
export interface AuthorityModeMapping {
  id: string;
  authorityType: string;
  defaultMode: 'PoC' | 'ESC' | 'General';
  isActive: boolean;
}

export interface TimelinessRule {
  id: string;
  mode: 'PoC' | 'ESC';
  dueDays: number;
  warningDays: number[];
  escalationRecipients: string[];
}

export interface CaseClosureReason {
  id: string;
  name: string;
  requiresOverride: boolean;
  isActive: boolean;
}

// Evidence & Attachments
export interface AllowedFileType {
  id: string;
  extension: string;
  mimeType: string;
  maxSizeMB: number;
  isActive: boolean;
}

export interface SensitivityTag {
  id: string;
  name: string;
  color: string;
  description?: string;
  isActive: boolean;
}

export interface RetentionLabel {
  id: string;
  name: string;
  durationMonths: number;
  description?: string;
}

// Notifications & Escalations
export interface NotificationTemplate {
  id: string;
  name: string;
  triggerEvent: string;
  subject: string;
  body: string;
  isActive: boolean;
}

export interface NotificationRule {
  id: string;
  module: 'Issues' | 'CAPA' | 'CitationCases';
  triggerEvent: string;
  recipients: string[];
  isActive: boolean;
}

export interface EscalationChain {
  id: string;
  name: string;
  levels: { role: AdminRole; delayHours: number }[];
}

// Reporting Settings
export interface ReportingSettings {
  allowStaffExport: boolean;
  issueAgingSLADays: number;
  capaDueSLADays: number;
  pocEscWarningDays: number;
  savedViewsRetentionDays: number;
}

// Workflow Settings
export interface IssueWorkflowSettings {
  qaReviewRequired: boolean;
  returnToInProgressAllowed: boolean;
  completionRequiresEvidence: boolean;
  closeWithoutCapaReasons: string[];
}

// Audit Log
export interface ConfigAuditEntry {
  id: string;
  section: string;
  action: 'create' | 'update' | 'delete' | 'publish';
  itemId: string;
  itemName: string;
  changedBy: string;
  changedAt: string;
  oldValue?: string;
  newValue?: string;
}

// Admin Section Definition
export interface AdminSection {
  id: string;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  description: string;
  subsections?: { id: string; label: string }[];
}
