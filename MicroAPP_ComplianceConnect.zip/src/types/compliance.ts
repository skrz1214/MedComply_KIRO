// ========================================
// CORE ENUMS AND TYPES
// ========================================

export type UserRole = 
  | 'super_admin' 
  | 'org_admin' 
  | 'compliance_manager' 
  | 'department_head' 
  | 'qa_reviewer' 
  | 'contributor' 
  | 'reporter' 
  | 'read_only';

export type IssueStatus = 
  | 'reported' 
  | 'in_progress' 
  | 'qa_review' 
  | 'completed' 
  | 'rejected';

export type IssueCategory = 
  | 'patient_safety' 
  | 'data_privacy' 
  | 'regulatory' 
  | 'documentation' 
  | 'operational' 
  | 'other';

export type IssueType = 
  | 'risk' 
  | 'incident_event' 
  | 'investigation_enforcement' 
  | 'audit' 
  | 'policy_procedure' 
  | 'complaint' 
  | 'training_competency' 
  | 'privacy_data_rights' 
  | 'governance';

export type ActionStepStatus = 
  | 'pending' 
  | 'complete' 
  | 'rejected' 
  | 'deferred' 
  | 'saved';

export type Department = 
  | 'nursing' 
  | 'pharmacy' 
  | 'laboratory' 
  | 'radiology' 
  | 'administration' 
  | 'it' 
  | 'quality_assurance'
  | 'compliance'
  | 'risk_management'
  | 'human_resources';

export type WorkflowStage = 
  | 'reported'
  | 'initiation'
  | 'in_progress'
  | 'qa_review'
  | 'completed';

export type MonitoringDestination = 
  | 'risk' 
  | 'enforcement' 
  | 'audit' 
  | 'compliance';

export type Priority = 'low' | 'medium' | 'high' | 'critical';

export type SensitivityTag = 'phi' | 'pii' | 'confidential' | 'internal' | 'public';

// ========================================
// ATTACHMENT & EVIDENCE TYPES
// ========================================

export interface Attachment {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  url: string;
  uploadedBy: string;
  uploadedAt: Date;
  stage: WorkflowStage;
  description?: string;
  sensitivityTag?: SensitivityTag;
}

export interface Evidence {
  id: string;
  type: EvidenceType;
  description: string;
  attachmentIds: string[];
  linkedActionId?: string;
  linkedExpectationId?: string;
  uploadedBy: string;
  uploadedAt: Date;
  notes?: string;
}

// ========================================
// ACTION STEPS
// ========================================

export interface ActionStep {
  id: string;
  description: string;
  sourceUrl?: string;
  isCustom: boolean;
  status: ActionStepStatus;
  evidence?: string;
  notes?: string;
  completedAt?: Date;
  attachments?: Attachment[];
}

// ========================================
// COMPLIANCE ISSUE
// ========================================

export interface ComplianceIssue {
  id: string;
  title: string;
  description: string;
  issueType: IssueType;
  issueCategory: IssueCategory;
  status: IssueStatus;
  priority: Priority;
  department: Department;
  facility?: string;
  organization?: string;
  reportedBy: string;
  reportedAt: Date;
  assignedTo?: string;
  actionSteps: ActionStep[];
  dueDate?: Date;
  closedAt?: Date;
  attachments: Attachment[];
  linkedCitationIds: string[];
  linkedCapaIds: string[];
  monitoringDestination?: MonitoringDestination;
  auditLog: AuditLogEntry[];
}

// ========================================
// CITATIONS MODULE TYPES
// ========================================

export type CitationSource = 
  | 'cms' 
  | 'joint_commission' 
  | 'state_doh' 
  | 'hipaa' 
  | 'osha' 
  | 'internal_policy' 
  | 'other';

export type CitationStatus = 'draft' | 'active' | 'deprecated' | 'superseded';

export type Jurisdiction = 'federal' | 'state' | 'local';

export type FacilityType = 'hospital' | 'nursing_home' | 'clinic' | 'pharmacy' | 'other';

export type RiskDomain = 
  | 'patient_safety' 
  | 'data_privacy' 
  | 'regulatory' 
  | 'documentation' 
  | 'operational' 
  | 'other';

export type EvidenceType = 
  | 'policy' 
  | 'procedure' 
  | 'training_record' 
  | 'audit_result' 
  | 'log' 
  | 'screenshot' 
  | 'report' 
  | 'credentialing' 
  | 'consent' 
  | 'other';

export type EvidenceFrequency = 'one_time' | 'monthly' | 'quarterly' | 'annual' | 'per_event';

export type MappingTarget = 'policy' | 'procedure' | 'control' | 'training' | 'audit_checklist';

export type MappingStrength = 'strong' | 'medium' | 'weak';

export interface EvidenceExpectation {
  id: string;
  evidenceType: EvidenceType;
  description: string;
  frequency: EvidenceFrequency;
  ownerRole?: UserRole;
  sampleArtifacts?: string;
  sensitivityTag?: SensitivityTag;
}

export interface CitationMapping {
  id: string;
  mapsTo: MappingTarget;
  mappedItemName: string;
  mappingStrength: MappingStrength;
  notes?: string;
  lastReviewedDate?: Date;
}

export interface RemediationStep {
  id: string;
  description: string;
  sourceUrl?: string;
  defaultOwnerRole?: UserRole;
  defaultDueInDays?: number;
}

export interface Citation {
  id: string;
  source: CitationSource;
  jurisdiction: Jurisdiction;
  program?: string;
  facilityType: FacilityType;
  citationCode: string;
  title: string;
  fullText: string;
  interpretationNotes?: string;
  effectiveDate: Date;
  version: number;
  status: CitationStatus;
  riskDomain: RiskDomain;
  evidenceExpectations: EvidenceExpectation[];
  mappings: CitationMapping[];
  remediationSteps: RemediationStep[];
  references: string[];
  attachments: Attachment[];
  tags: string[];
  linkedIssueIds: string[];
  linkedCapaIds: string[];
  previousVersionId?: string;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
  auditLog: AuditLogEntry[];
}

// ========================================
// ACTIONGUARD (CAPA) MODULE TYPES
// ========================================

export type CapaOriginType = 
  | 'issue' 
  | 'audit_finding' 
  | 'survey_deficiency' 
  | 'complaint' 
  | 'incident_event' 
  | 'other';

export type CapaType = 'corrective' | 'preventive' | 'both';

export type CapaStatus = 
  | 'draft' 
  | 'submitted' 
  | 'approved' 
  | 'in_progress' 
  | 'effectiveness_review' 
  | 'closed' 
  | 'reopened';

export type RcaMethod = 
  | 'five_whys' 
  | 'fishbone' 
  | 'pareto' 
  | 'fault_tree' 
  | 'other';

export type ContributingFactorCategory = 
  | 'people' 
  | 'process' 
  | 'technology' 
  | 'environment' 
  | 'policy' 
  | 'communication';

export type CapaActionStatus = 
  | 'pending' 
  | 'in_progress' 
  | 'completed' 
  | 'overdue' 
  | 'deferred';

export type VerificationMethod = 
  | 'document_review' 
  | 'observation' 
  | 'testing' 
  | 'audit' 
  | 'interview' 
  | 'data_analysis';

export type ApprovalDecision = 'approve' | 'request_changes' | 'reject';

export type CapaTemplate = 'cms_poc' | 'tjc_esc' | 'general';

export interface ContainmentAction {
  id: string;
  description: string;
  completedAt?: Date;
  completedBy?: string;
}

export interface RootCause {
  id: string;
  description: string;
  contributingFactors: ContributingFactorCategory[];
}

export interface RootCauseAnalysis {
  method: RcaMethod;
  summary: string;
  contributingFactors: ContributingFactorCategory[];
  rootCauses: RootCause[];
}

export interface CapaAction {
  id: string;
  type: 'corrective' | 'preventive';
  title: string;
  description: string;
  owner: string;
  dueDate: Date;
  dependencies?: string[];
  status: CapaActionStatus;
  evidenceRequired: boolean;
  evidenceType?: EvidenceType;
  verificationMethod?: VerificationMethod;
  completedAt?: Date;
  completedBy?: string;
  evidence?: Evidence[];
  attachments?: Attachment[];
  notes?: string;
}

export interface MonitoringPlan {
  whatToMonitor: string;
  frequency: EvidenceFrequency;
  duration: string;
  owner: string;
  escalationRule?: string;
}

export interface EffectivenessCheck {
  id: string;
  criteria: string;
  checkDate: Date;
  result?: 'pass' | 'fail';
  notes?: string;
  evidenceIds?: string[];
  performedBy?: string;
}

export interface CapaApproval {
  id: string;
  approverId: string;
  approverName: string;
  decision: ApprovalDecision;
  comments?: string;
  decidedAt: Date;
}

export interface Capa {
  id: string;
  title: string;
  originType: CapaOriginType;
  linkedIssueId?: string;
  linkedCitationIds: string[];
  problemStatement: string;
  department: Department;
  facility?: string;
  organization?: string;
  severity: Priority;
  priority: Priority;
  type: CapaType;
  status: CapaStatus;
  template: CapaTemplate;
  owner: string;
  approver: string;
  dueDate: Date;
  containmentActions: ContainmentAction[];
  rca?: RootCauseAnalysis;
  correctiveActions: CapaAction[];
  preventiveActions: CapaAction[];
  monitoringPlan?: MonitoringPlan;
  effectivenessChecks: EffectivenessCheck[];
  approvals: CapaApproval[];
  closureSummary?: string;
  closedAt?: Date;
  closedBy?: string;
  reopenReason?: string;
  reopenedAt?: Date;
  attachments: Attachment[];
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
  auditLog: AuditLogEntry[];
}

// ========================================
// AUDIT LOG
// ========================================

export interface AuditLogEntry {
  id: string;
  action: string;
  performedBy: string;
  performedAt: Date;
  details?: string;
  previousValue?: string;
  newValue?: string;
}

// ========================================
// DASHBOARD & STATS
// ========================================

export interface DashboardStats {
  totalIssues: number;
  openIssues: number;
  inProgress: number;
  awaitingQA: number;
  completedThisMonth: number;
  overdueItems: number;
}

export interface CitationStats {
  totalCitations: number;
  activeCitations: number;
  draftCitations: number;
  deprecatedCitations: number;
  unmappedCitations: number;
  missingEvidenceExpectations: number;
}

export interface CapaStats {
  totalCapas: number;
  draftCapas: number;
  inProgressCapas: number;
  pendingApproval: number;
  effectivenessReview: number;
  closedThisMonth: number;
  overdueActions: number;
}

// ========================================
// ADMIN CONFIGURATION TYPES
// ========================================

export interface Organization {
  id: string;
  name: string;
  facilities: Facility[];
}

export interface Facility {
  id: string;
  name: string;
  type: FacilityType;
  departments: string[];
}

export interface ConfigOption {
  id: string;
  value: string;
  label: string;
  isActive: boolean;
}

export interface CapaTemplateConfig {
  id: string;
  name: string;
  type: CapaTemplate;
  requiredFields: string[];
  defaultSlaDays: number;
  requiresMonitoringPlan: boolean;
  requiresEffectivenessCriteria: boolean;
}

// ========================================
// CITATION CASE MANAGEMENT TYPES
// ========================================

export type CitationCaseAuthorityType = 
  | 'cms_state_survey' 
  | 'joint_commission' 
  | 'internal_audit' 
  | 'other_accreditor' 
  | 'other';

export type CitationCaseOrigin = 
  | 'survey_inspection' 
  | 'internal_audit' 
  | 'complaint' 
  | 'incident_event' 
  | 'rounds' 
  | 'self_assessment' 
  | 'other';

export type CitationCaseStatus = 
  | 'draft' 
  | 'reported' 
  | 'triage' 
  | 'remediation_in_progress' 
  | 'qa_verification' 
  | 'closed' 
  | 'monitoring';

export type CitationCaseMode = 'poc' | 'esc' | 'general';

export type PatientImpactLikelihood = 'low' | 'moderate' | 'high';

export type ScopePrevalence = 'limited' | 'pattern' | 'widespread';

export type VerificationOutcome = 'pass' | 'fail' | 'needs_follow_up';

export type ClosureReason = 
  | 'verified_fixed' 
  | 'not_applicable' 
  | 'duplicate' 
  | 'accepted_risk' 
  | 'referred_out';

export type RemediationPath = 'issue' | 'capa' | 'quick_fix';

export interface ContainmentAction {
  id: string;
  description: string;
  completedBy?: string;
  completedAt?: Date;
}

export interface PoCElement {
  id: string;
  elementNumber: 1 | 2 | 3 | 4 | 5;
  title: string;
  content: string;
  responsibleRole?: string;
  completionDate?: Date;
}

export interface ESCElement {
  id: string;
  rfiReferences: string;
  correctiveActionsTaken: string;
  evidenceList: string;
  sustainmentPlan: string;
  completionDate?: Date;
}

export interface VerificationChecklistItem {
  id: string;
  expectationId: string;
  expectationDescription: string;
  result: 'met' | 'not_met' | 'not_applicable' | 'pending';
  notes?: string;
  linkedEvidenceIds: string[];
}

export interface CitationCaseComment {
  id: string;
  author: string;
  content: string;
  createdAt: Date;
}

export interface CitationCaseMonitoringPlan {
  whatToMonitor: string;
  frequency: EvidenceFrequency;
  duration: string;
  owner: string;
  escalationRule?: string;
}

export interface CitationCase {
  id: string;
  title: string;
  description: string;
  
  // Citation reference
  citationId: string;
  citationVersion: number;
  citationCode?: string;
  citationTitle?: string;
  
  // Authority & Origin
  authorityType: CitationCaseAuthorityType;
  origin: CitationCaseOrigin;
  mode: CitationCaseMode;
  
  // Location
  facility: string;
  department: Department;
  serviceLine?: string;
  program?: string;
  organization?: string;
  
  // Risk Assessment
  riskDomain: RiskDomain;
  severity: Priority;
  priority: Priority;
  
  // SAFER-like scoring (for TJC)
  patientImpactLikelihood?: PatientImpactLikelihood;
  scopePrevalence?: ScopePrevalence;
  
  // Status & Workflow
  status: CitationCaseStatus;
  remediationPath?: RemediationPath;
  
  // People
  reporter: string;
  owner?: string;
  qaReviewer?: string;
  complianceManager?: string;
  departmentHead?: string;
  watchers: string[];
  
  // Key Dates
  reportedDate: Date;
  authorityReportPostedDate?: Date;
  cms2567ReceivedDate?: Date;
  escDueDate?: Date;
  pocDueDate?: Date;
  triageDueDate?: Date;
  remediationDueDate?: Date;
  verificationDueDate?: Date;
  closedAt?: Date;
  
  // Findings & Actions
  findingsSummary: string;
  containmentActions: ContainmentAction[];
  correctionPlanSummary?: string;
  recommendedRemediationSteps: string[];
  
  // PoC Elements (CMS/State mode)
  pocElements?: PoCElement[];
  pocSubmittedDate?: Date;
  pocAccepted?: boolean;
  pocRevisionNotes?: string;
  
  // ESC Elements (Joint Commission mode)
  escElements?: ESCElement;
  escSubmittedDate?: Date;
  escAccepted?: boolean;
  escRevisionNotes?: string;
  
  // Evidence
  evidenceItems: Attachment[];
  
  // Verification
  verificationChecklist: VerificationChecklistItem[];
  verificationOutcome?: VerificationOutcome;
  verificationNotes?: string;
  
  // Closure
  closureReason?: ClosureReason;
  closureSummary?: string;
  overrideJustification?: string;
  
  // Monitoring
  monitoringPlan?: CitationCaseMonitoringPlan;
  recurrenceFlag: boolean;
  
  // Links
  linkedIssueId?: string;
  linkedCapaId?: string;
  
  // Comments & Audit
  comments: CitationCaseComment[];
  auditLog: AuditLogEntry[];
  
  createdAt: Date;
  updatedAt: Date;
}

export interface CitationCaseStats {
  totalCases: number;
  draftCases: number;
  reportedCases: number;
  triageCases: number;
  inProgressCases: number;
  qaVerificationCases: number;
  closedCases: number;
  monitoringCases: number;
  overduePoCCount: number;
  overdueESCCount: number;
  highSeverityCases: number;
}
