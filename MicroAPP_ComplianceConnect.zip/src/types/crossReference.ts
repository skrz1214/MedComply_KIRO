// Cross-Reference Types for External Microapp Linking

export type MicroappType = 
  | 'riskguard' 
  | 'auditpro' 
  | 'feedbackhub' 
  | 'enforcementpoint'
  | 'complianceconnect'
  | 'citations'
  | 'actionguard';

export type CrossReferenceItemType = 
  | 'risk_assessment'
  | 'risk_register'
  | 'audit_finding'
  | 'audit_report'
  | 'feedback_item'
  | 'complaint'
  | 'enforcement_action'
  | 'investigation'
  | 'issue'
  | 'citation'
  | 'capa';

export interface MicroappConfig {
  id: MicroappType;
  name: string;
  color: string;
  icon: string;
  itemTypes: CrossReferenceItemType[];
}

export interface CrossReference {
  id: string;
  sourceType: MicroappType;
  sourceId: string;
  targetType: MicroappType;
  targetId: string;
  targetItemType: CrossReferenceItemType;
  targetTitle: string;
  targetStatus?: string;
  linkedBy: string;
  linkedAt: Date;
  notes?: string;
}

export const microappConfigs: MicroappConfig[] = [
  {
    id: 'riskguard',
    name: 'RiskGuard',
    color: 'hsl(var(--chart-1))',
    icon: 'Shield',
    itemTypes: ['risk_assessment', 'risk_register']
  },
  {
    id: 'auditpro',
    name: 'AuditPro',
    color: 'hsl(var(--chart-2))',
    icon: 'FileSearch',
    itemTypes: ['audit_finding', 'audit_report']
  },
  {
    id: 'feedbackhub',
    name: 'FeedbackHub',
    color: 'hsl(var(--chart-3))',
    icon: 'MessageSquare',
    itemTypes: ['feedback_item', 'complaint']
  },
  {
    id: 'enforcementpoint',
    name: 'EnforcementPoint',
    color: 'hsl(var(--chart-4))',
    icon: 'Scale',
    itemTypes: ['enforcement_action', 'investigation']
  },
  {
    id: 'complianceconnect',
    name: 'ComplianceConnect',
    color: 'hsl(var(--primary))',
    icon: 'ClipboardList',
    itemTypes: ['issue']
  },
  {
    id: 'citations',
    name: 'Citations',
    color: 'hsl(var(--chart-5))',
    icon: 'BookOpen',
    itemTypes: ['citation']
  },
  {
    id: 'actionguard',
    name: 'ActionGuard',
    color: 'hsl(var(--warning))',
    icon: 'Target',
    itemTypes: ['capa']
  }
];

// Mock cross-references for demo
export const mockCrossReferences: CrossReference[] = [
  {
    id: 'xref-1',
    sourceType: 'complianceconnect',
    sourceId: 'ISS-001',
    targetType: 'riskguard',
    targetId: 'RISK-2024-001',
    targetItemType: 'risk_assessment',
    targetTitle: 'Patient Safety Risk Assessment Q4',
    targetStatus: 'active',
    linkedBy: 'John Smith',
    linkedAt: new Date('2024-12-10')
  },
  {
    id: 'xref-2',
    sourceType: 'complianceconnect',
    sourceId: 'ISS-001',
    targetType: 'auditpro',
    targetId: 'AUD-2024-015',
    targetItemType: 'audit_finding',
    targetTitle: 'Documentation Gap - Medication Administration',
    targetStatus: 'open',
    linkedBy: 'Jane Doe',
    linkedAt: new Date('2024-12-08')
  },
  {
    id: 'xref-3',
    sourceType: 'complianceconnect',
    sourceId: 'ISS-002',
    targetType: 'feedbackhub',
    targetId: 'FB-2024-042',
    targetItemType: 'complaint',
    targetTitle: 'Patient Wait Time Complaint',
    targetStatus: 'resolved',
    linkedBy: 'John Smith',
    linkedAt: new Date('2024-12-05')
  },
  {
    id: 'xref-4',
    sourceType: 'complianceconnect',
    sourceId: 'ISS-001',
    targetType: 'enforcementpoint',
    targetId: 'ENF-2024-003',
    targetItemType: 'investigation',
    targetTitle: 'CMS Survey Follow-up Investigation',
    targetStatus: 'in_progress',
    linkedBy: 'Mary Johnson',
    linkedAt: new Date('2024-12-12')
  }
];
