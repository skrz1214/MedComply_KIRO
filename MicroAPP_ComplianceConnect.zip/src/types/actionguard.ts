// ========================================
// ACTIONGUARD (CAPA) - HEALTHCARE PROVIDER + LTC TYPES
// ========================================

import { Priority, SensitivityTag, AuditLogEntry, Department, EvidenceType, EvidenceFrequency } from './compliance';

// ========================================
// ROLES (4 ROLES ONLY)
// ========================================

export type ActionGuardRole = 'admin' | 'compliance_head' | 'department_head' | 'staff';

// ========================================
// CAPA STATUS LIFECYCLE
// ========================================

export type CapaStatusNew = 
  | 'draft'
  | 'submitted'
  | 'in_review'
  | 'approved'
  | 'in_progress'
  | 'verification'
  | 'effectiveness_monitoring'
  | 'closed'
  | 'reopened';

// ========================================
// ORIGIN TYPES (PROVIDER + LTC)
// ========================================

export type CapaOriginTypeNew = 
  | 'cms_state_survey'           // CMS-2567 / Plan of Correction
  | 'internal_audit'             // Internal Audit/Mock Survey Finding
  | 'resident_incident'          // Resident Incident / Near Miss
  | 'abuse_neglect_allegation'   // Abuse/Neglect Allegation (internal)
  | 'complaint_grievance'        // Complaint/Grievance
  | 'infection_prevention'       // Infection Prevention / Outbreak
  | 'medication_error'           // Medication Error / Pharmacy
  | 'dietary_kitchen'            // Dietary/Kitchen
  | 'life_safety'                // Life Safety / Environment of Care
  | 'staffing_competency'        // Staffing/Competency
  | 'documentation_records'      // Documentation/Records
  | 'policy_procedure_gap'       // Policy/Procedure Gap
  | 'other';

// ========================================
// ACTION TYPES (PROVIDER + LTC)
// ========================================

export type CapaActionType = 
  | 'policy_procedure_update'
  | 'training_competency'
  | 'workflow_process_change'
  | 'technology_system_change'
  | 'staffing_role_clarification'
  | 'audit_monitoring'
  | 'environment_safety_fix'
  | 'infection_prevention_control'
  | 'medication_management'
  | 'dietary_nutrition'
  | 'documentation_charting'
  | 'resident_family_communication'
  | 'other';

// ========================================
// RCA METHODS
// ========================================

export type RcaMethodNew = 
  | 'five_whys'
  | 'fishbone'
  | 'process_map'
  | 'other';

// ========================================
// CONTRIBUTING FACTORS
// ========================================

export type ContributingFactor = 
  | 'people'
  | 'process'
  | 'technology'
  | 'environment'
  | 'policy'
  | 'communication';

// ========================================
// ACTION STATUS
// ========================================

export type CapaActionStatusNew = 
  | 'not_started'
  | 'in_progress'
  | 'blocked'
  | 'done'
  | 'cancelled';

// ========================================
// VERIFICATION TYPES
// ========================================

export type VerificationType = 
  | 'verification'   // Did we do it?
  | 'validation'     // Did it work in real use?
  | 'both';

// ========================================
// PATIENT RISK LEVELS
// ========================================

export type PatientRisk = 'none' | 'low' | 'moderate' | 'high';

// ========================================
// POC ACCEPTANCE STATUS
// ========================================

export type PocAcceptanceStatus = 'pending' | 'accepted' | 'returned';

// ========================================
// CMS/STATE SURVEY SCOPE SEVERITY
// ========================================

export type ScopeSeverity = 
  | 'A' | 'B' | 'C' | 'D' 
  | 'E' | 'F' | 'G' | 'H' 
  | 'I' | 'J' | 'K' | 'L';

// ========================================
// INTERFACES
// ========================================

export interface ContainmentActionNew {
  id: string;
  description: string;
  who: string;
  when: Date;
  completedAt?: Date;
  completedBy?: string;
  notes?: string;
}

export interface RootCauseNew {
  id: string;
  statement: string;
  category: ContributingFactor;
  justification: string;
  evidenceLinks?: string[];
  confidence: 'low' | 'medium' | 'high';
}

export interface RootCauseAnalysisNew {
  method: RcaMethodNew;
  summary: string;
  contributingFactors: ContributingFactor[];
  rootCauses: RootCauseNew[];
}

export interface VerificationStep {
  id: string;
  description: string;
  requiredEvidence: string;
  completed: boolean;
  completedAt?: Date;
  completedBy?: string;
  evidenceIds?: string[];
}

export interface CapaActionNew {
  id: string;
  type: 'corrective' | 'preventive';
  actionType: CapaActionType;
  title: string;
  description: string;
  owner: string;
  dueDate: Date;
  dependency?: string;
  status: CapaActionStatusNew;
  evidenceRequired: boolean;
  evidenceType?: EvidenceType;
  evidenceLinks?: string[];
  verificationType: VerificationType;
  verificationSteps: VerificationStep[];
  completedAt?: Date;
  completedBy?: string;
  notes?: string;
}

export interface MonitoringPlanNew {
  whatToMonitor: string;
  frequency: EvidenceFrequency;
  duration: string;
  owner: string;
  escalationRule?: string;
}

export interface MonitoringEntry {
  id: string;
  date: Date;
  metricValue: string;
  notes?: string;
  evidenceIds?: string[];
  recordedBy: string;
}

export interface EffectivenessCriteria {
  id: string;
  criteria: string;
  kpi?: string;
  baseline?: string;
  target: string;
}

export interface EffectivenessCheckNew {
  id: string;
  criteriaId: string;
  checkDate: Date;
  result?: 'pass' | 'fail';
  notes?: string;
  evidenceIds?: string[];
  performedBy?: string;
}

export interface ManagementReviewSignoff {
  signedBy: string;
  signedAt: Date;
  notes?: string;
  departmentHeadAttestation?: {
    signedBy: string;
    signedAt: Date;
  };
}

export interface PlanOfCorrectionElement {
  id: string;
  elementNumber: 1 | 2 | 3 | 4 | 5;
  title: string;
  description: string;
  content: string;
  completionDate?: Date;
  evidenceIds?: string[];
}

export interface SurveyPocData {
  surveyDate?: Date;
  cms2567ReceivedDate?: Date;
  ftag?: string;
  deficiencyTag?: string;
  scopeSeverity?: ScopeSeverity;
  pocDueDate?: Date;
  pocSubmissionDate?: Date;
  pocAcceptedStatus?: PocAcceptanceStatus;
  pocNotes?: string;
  pocElements: PlanOfCorrectionElement[];
}

export interface CapaApprovalNew {
  id: string;
  approverId: string;
  approverName: string;
  approverRole: ActionGuardRole;
  decision: 'approve' | 'request_changes' | 'reject';
  comments?: string;
  decidedAt: Date;
}

export interface CapaAttachment {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  url: string;
  uploadedBy: string;
  uploadedAt: Date;
  sensitivityTag?: SensitivityTag;
  redactionNote?: string;
  linkedActionId?: string;
  linkedVerificationStepId?: string;
  linkedEffectivenessCriteriaId?: string;
  linkedPocElementId?: string;
}

export interface CapaComment {
  id: string;
  content: string;
  authorId: string;
  authorName: string;
  createdAt: Date;
  updatedAt?: Date;
}

// ========================================
// MAIN CAPA INTERFACE
// ========================================

export interface CapaNew {
  id: string;
  title: string;
  problemStatement: string;
  
  // Origin
  originType: CapaOriginTypeNew;
  
  // Location
  facility: string;
  unitWing?: string;
  department: Department;
  
  // Risk Assessment
  severity: Priority;
  priority: Priority;
  patientRisk: PatientRisk;
  harmPotentialNotes?: string;
  
  // Status
  status: CapaStatusNew;
  
  // Ownership
  owner: string;
  ownerId: string;
  departmentHead?: string;
  departmentHeadId?: string;
  complianceHead?: string;
  complianceHeadId?: string;
  
  // Key Dates
  createdAt: Date;
  createdBy: string;
  submittedAt?: Date;
  approvedAt?: Date;
  dueDate: Date;
  verificationDate?: Date;
  effectivenessDueDate?: Date;
  closedAt?: Date;
  closedBy?: string;
  
  // Survey/PoC Data (only for CMS/State Survey origin)
  surveyPocData?: SurveyPocData;
  
  // Containment
  containmentActions: ContainmentActionNew[];
  immediateRiskMitigationComplete: boolean;
  riskMitigationNotes?: string;
  
  // RCA
  rca?: RootCauseAnalysisNew;
  
  // Action Plan
  correctiveActions: CapaActionNew[];
  preventiveActions: CapaActionNew[];
  
  // Verification & Effectiveness
  effectivenessCriteria: EffectivenessCriteria[];
  monitoringPlan?: MonitoringPlanNew;
  monitoringEntries: MonitoringEntry[];
  effectivenessChecks: EffectivenessCheckNew[];
  effectivenessResult?: 'pass' | 'fail';
  effectivenessNotes?: string;
  
  // QAPI
  qapiFlag: boolean;
  pipReference?: string;
  qapiMetricsLinked?: string[];
  
  // Management Review
  managementReviewRequired: boolean;
  managementReviewSignoff?: ManagementReviewSignoff;
  
  // Approvals
  approvals: CapaApprovalNew[];
  
  // Closure
  closureSummary?: string;
  reopenReason?: string;
  reopenedAt?: Date;
  
  // Linked Items
  linkedIssueId?: string;
  linkedCitationCaseId?: string;
  linkedCitationIds?: string[];
  
  // Files & Comments
  attachments: CapaAttachment[];
  comments: CapaComment[];
  watchers: string[];
  
  // Audit Log
  auditLog: AuditLogEntry[];
  
  // Override tracking
  overrideJustification?: string;
  overridePatientRiskRationale?: string;
  overrideApprovedBy?: string;
  
  updatedAt: Date;
}

// ========================================
// STATS
// ========================================

export interface ActionGuardStats {
  draft: number;
  submitted: number;
  inReview: number;
  approved: number;
  inProgress: number;
  verification: number;
  effectivenessMonitoring: number;
  closed: number;
  reopened: number;
  overdueActions: number;
  pocDueSoon: number;
  pocOverdue: number;
  closedThisMonth: number;
}

// ========================================
// CONFIGURATION
// ========================================

export interface ActionGuardConfig {
  facilities: { id: string; name: string; units: string[] }[];
  departments: { id: string; name: string; headId: string; headName: string }[];
  originTypes: { value: CapaOriginTypeNew; label: string }[];
  actionTypes: { value: CapaActionType; label: string }[];
  rcaMethods: { value: RcaMethodNew; label: string }[];
  factorCategories: ContributingFactor[];
  severityDefinitions: { value: Priority; label: string; slaDefaultDays: number }[];
  effectivenessKpis: { id: string; name: string; description: string }[];
}
