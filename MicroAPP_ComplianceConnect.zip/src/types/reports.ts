// Report Types and Definitions

export type ReportDomain = 'executive' | 'issues' | 'capa' | 'citations' | 'cross-module';

export type UserRole = 'admin' | 'compliance_head' | 'department_head' | 'staff';

export interface ReportDefinition {
  id: string;
  title: string;
  description: string;
  domain: ReportDomain;
  icon: string;
  metrics: ReportMetric[];
  columns: ReportColumn[];
  filters: ReportFilter[];
  drillDownType?: 'issue' | 'capa' | 'citation' | 'citation_case';
}

export interface ReportMetric {
  id: string;
  label: string;
  value: number | string;
  change?: number;
  changeLabel?: string;
  color?: 'default' | 'success' | 'warning' | 'danger';
}

export interface ReportColumn {
  id: string;
  label: string;
  sortable?: boolean;
  visible?: boolean;
  width?: string;
}

export interface ReportFilter {
  id: string;
  label: string;
  type: 'select' | 'multi-select' | 'date-range' | 'toggle' | 'typeahead';
  options?: { value: string; label: string }[];
}

export interface ReportRow {
  id: string;
  [key: string]: any;
}

export interface ReportExportMetadata {
  reportName: string;
  exportedAt: string;
  userRole: UserRole;
  organization: string;
  facility?: string;
  filterSummary: string;
}

export interface SavedReportView {
  id: string;
  name: string;
  reportId: string;
  filters: Record<string, any>;
  columns: string[];
  sortBy?: string;
  sortDirection?: 'asc' | 'desc';
  createdBy: string;
  createdAt: string;
}

export interface ExportHistoryEntry {
  id: string;
  reportId: string;
  reportName: string;
  exportedAt: string;
  exportedBy: string;
  filterSummary: string;
  rowCount: number;
}

// Domain-specific filter options
export const ISSUE_STAGES = [
  { value: 'reported', label: 'Reported' },
  { value: 'initiation', label: 'Initiation' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'qa_review', label: 'QA Review' },
  { value: 'completed', label: 'Completed' },
];

export const CAPA_BUCKETS = [
  { value: 'new', label: 'NEW' },
  { value: 'open', label: 'OPEN' },
  { value: 'closed', label: 'CLOSED' },
];

export const CAPA_STATUSES = [
  { value: 'draft', label: 'Draft' },
  { value: 'submitted', label: 'Submitted' },
  { value: 'in_review', label: 'In Review' },
  { value: 'approved', label: 'Approved' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'verification', label: 'Verification' },
  { value: 'effectiveness_monitoring', label: 'Effectiveness Monitoring' },
  { value: 'closed', label: 'Closed' },
  { value: 'reopened', label: 'Reopened' },
];

export const SEVERITY_LEVELS = [
  { value: 'critical', label: 'Critical' },
  { value: 'high', label: 'High' },
  { value: 'medium', label: 'Medium' },
  { value: 'low', label: 'Low' },
];

export const PRIORITY_LEVELS = [
  { value: 'urgent', label: 'Urgent' },
  { value: 'high', label: 'High' },
  { value: 'medium', label: 'Medium' },
  { value: 'low', label: 'Low' },
];

export const CITATION_STATUSES = [
  { value: 'active', label: 'Active' },
  { value: 'draft', label: 'Draft' },
  { value: 'deprecated', label: 'Deprecated' },
];

export const CITATION_CASE_MODES = [
  { value: 'poc', label: 'CMS/State PoC' },
  { value: 'esc', label: 'Joint Commission ESC' },
  { value: 'general', label: 'General' },
];

export const MONITORING_DESTINATIONS = [
  { value: 'risk', label: 'Risk' },
  { value: 'enforcement', label: 'Enforcement' },
  { value: 'audit', label: 'Audit' },
  { value: 'compliance', label: 'Compliance' },
];

export const DEPARTMENTS = [
  { value: 'nursing', label: 'Nursing' },
  { value: 'dietary', label: 'Dietary' },
  { value: 'pharmacy', label: 'Pharmacy' },
  { value: 'administration', label: 'Administration' },
  { value: 'environmental_services', label: 'Environmental Services' },
  { value: 'maintenance', label: 'Maintenance' },
  { value: 'activities', label: 'Activities' },
  { value: 'social_services', label: 'Social Services' },
];

export const FACILITIES = [
  { value: 'main_campus', label: 'Main Campus' },
  { value: 'north_wing', label: 'North Wing' },
  { value: 'south_wing', label: 'South Wing' },
  { value: 'rehab_center', label: 'Rehab Center' },
];
