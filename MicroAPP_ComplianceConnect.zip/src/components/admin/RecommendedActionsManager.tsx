import { useState } from 'react';
import { Plus, Pencil, Trash2, Search, Filter, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { toast } from '@/hooks/use-toast';
import { RecommendedAction, IssueType, IssueCategory, PriorityLevel } from '@/types/adminConfig';
import { AdminRole } from '@/types/adminConfig';

interface RecommendedActionsManagerProps {
  actions: RecommendedAction[];
  issueTypes: IssueType[];
  issueCategories: IssueCategory[];
  priorityLevels: PriorityLevel[];
  onAdd: (action: RecommendedAction) => void;
  onEdit: (action: RecommendedAction) => void;
  onDelete: (id: string) => void;
}

const defaultAction: Partial<RecommendedAction> = {
  text: '',
  typeId: '',
  categoryId: undefined,
  defaultOwnerRole: 'Staff',
  defaultDueDays: 7,
  evidenceRequired: false,
  sourceUrl: '',
  isActive: true,
};

interface ActionRules {
  applyToAllCategories: boolean;
  selectedCategories: string[];
  priorityCondition: 'any' | 'specific';
  selectedPriorities: string[];
}

const defaultRules: ActionRules = {
  applyToAllCategories: true,
  selectedCategories: [],
  priorityCondition: 'any',
  selectedPriorities: [],
};

export function RecommendedActionsManager({
  actions,
  issueTypes,
  issueCategories,
  priorityLevels,
  onAdd,
  onEdit,
  onDelete,
}: RecommendedActionsManagerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [editingAction, setEditingAction] = useState<RecommendedAction | null>(null);
  const [formData, setFormData] = useState<Partial<RecommendedAction>>(defaultAction);
  const [rules, setRules] = useState<ActionRules>(defaultRules);

  const filteredActions = actions.filter(action => {
    const matchesSearch = action.text.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || action.typeId === filterType;
    return matchesSearch && matchesType;
  });

  const getCategoriesForType = (typeId: string) => {
    return issueCategories.filter(cat => cat.typeId === typeId);
  };

  const handleOpenAdd = () => {
    setEditingAction(null);
    setFormData(defaultAction);
    setRules(defaultRules);
    setIsDialogOpen(true);
  };

  const handleOpenEdit = (action: RecommendedAction) => {
    setEditingAction(action);
    setFormData(action);
    // Parse existing rules from action
    setRules({
      applyToAllCategories: !action.categoryId,
      selectedCategories: action.categoryId ? [action.categoryId] : [],
      priorityCondition: 'any',
      selectedPriorities: [],
    });
    setIsDialogOpen(true);
  };

  const handleOpenDelete = (action: RecommendedAction) => {
    setEditingAction(action);
    setIsDeleteOpen(true);
  };

  const handleSave = () => {
    if (!formData.text?.trim()) {
      toast({ title: 'Validation Error', description: 'Action text is required', variant: 'destructive' });
      return;
    }
    if (!formData.typeId) {
      toast({ title: 'Validation Error', description: 'Issue type is required', variant: 'destructive' });
      return;
    }

    const actionData: RecommendedAction = {
      id: editingAction?.id || `rec-${Date.now()}`,
      text: formData.text || '',
      typeId: formData.typeId || '',
      categoryId: rules.applyToAllCategories ? undefined : rules.selectedCategories[0],
      defaultOwnerRole: formData.defaultOwnerRole || 'Staff',
      defaultDueDays: formData.defaultDueDays || 7,
      evidenceRequired: formData.evidenceRequired || false,
      sourceUrl: formData.sourceUrl,
      isActive: formData.isActive ?? true,
    };

    if (editingAction) {
      onEdit(actionData);
      toast({ title: 'Action Updated', description: 'Recommended action has been updated.' });
    } else {
      onAdd(actionData);
      toast({ title: 'Action Added', description: 'New recommended action has been added.' });
    }
    setIsDialogOpen(false);
  };

  const handleConfirmDelete = () => {
    if (editingAction) {
      onDelete(editingAction.id);
      toast({ title: 'Action Deleted', description: 'Recommended action has been deleted.' });
    }
    setIsDeleteOpen(false);
  };

  const getTypeName = (typeId: string) => issueTypes.find(t => t.id === typeId)?.name || '-';
  const getCategoryName = (categoryId?: string) => {
    if (!categoryId) return 'All Categories';
    return issueCategories.find(c => c.id === categoryId)?.name || '-';
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="font-medium">Recommended Action Steps</h4>
          <p className="text-sm text-muted-foreground">
            Pre-defined actions that auto-populate based on issue type and category selection
          </p>
        </div>
        <Button onClick={handleOpenAdd} size="sm">
          <Plus className="h-4 w-4 mr-1" /> Add Action
        </Button>
      </div>

      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search actions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-48">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Filter by type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            {issueTypes.filter(t => t.isActive).map(type => (
              <SelectItem key={type.id} value={type.id}>{type.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Action Text</TableHead>
              <TableHead>Rule (Type → Category)</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Due</TableHead>
              <TableHead>Evidence</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-24 text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredActions.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  No recommended actions found
                </TableCell>
              </TableRow>
            ) : (
              filteredActions.map((action) => (
                <TableRow key={action.id}>
                  <TableCell className="max-w-xs">
                    <div className="truncate font-medium">{action.text}</div>
                    {action.sourceUrl && (
                      <a href={action.sourceUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-primary flex items-center gap-1 mt-1">
                        <ExternalLink className="h-3 w-3" /> Source
                      </a>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-1">
                      <Badge variant="outline" className="w-fit">{getTypeName(action.typeId)}</Badge>
                      <span className="text-xs text-muted-foreground">→ {getCategoryName(action.categoryId)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary">{action.defaultOwnerRole}</Badge>
                  </TableCell>
                  <TableCell>{action.defaultDueDays} days</TableCell>
                  <TableCell>
                    {action.evidenceRequired ? (
                      <Badge variant="default">Required</Badge>
                    ) : (
                      <span className="text-muted-foreground text-sm">Optional</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge variant={action.isActive ? 'default' : 'secondary'}>
                      {action.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" size="icon" onClick={() => handleOpenEdit(action)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleOpenDelete(action)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingAction ? 'Edit' : 'Add'} Recommended Action</DialogTitle>
            <DialogDescription>
              Configure the action and set rules for when it should appear in issue wizards.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Action Details */}
            <div className="space-y-4">
              <h4 className="font-medium text-sm">Action Details</h4>
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="text">Action Text *</Label>
                  <Textarea
                    id="text"
                    placeholder="Describe the recommended action..."
                    value={formData.text || ''}
                    onChange={(e) => setFormData({ ...formData, text: e.target.value })}
                    className="min-h-[80px]"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="sourceUrl">Source URL (optional)</Label>
                    <Input
                      id="sourceUrl"
                      placeholder="https://..."
                      value={formData.sourceUrl || ''}
                      onChange={(e) => setFormData({ ...formData, sourceUrl: e.target.value })}
                    />
                    <p className="text-xs text-muted-foreground">Link to guidance document or regulation</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Status</Label>
                    <div className="flex items-center gap-2 pt-2">
                      <Switch
                        checked={formData.isActive ?? true}
                        onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                      />
                      <span className="text-sm">{formData.isActive ? 'Active' : 'Inactive'}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Display Rules */}
            <div className="space-y-4">
              <h4 className="font-medium text-sm">Display Rules</h4>
              <p className="text-xs text-muted-foreground">
                Define when this action should appear in the issue reporting wizard
              </p>

              <Card className="bg-muted/30">
                <CardContent className="pt-4 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="typeId">Issue Type *</Label>
                    <Select
                      value={formData.typeId || ''}
                      onValueChange={(value) => {
                        setFormData({ ...formData, typeId: value });
                        setRules({ ...rules, selectedCategories: [], applyToAllCategories: true });
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select issue type..." />
                      </SelectTrigger>
                      <SelectContent>
                        {issueTypes.filter(t => t.isActive).map(type => (
                          <SelectItem key={type.id} value={type.id}>{type.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {formData.typeId && (
                    <div className="space-y-3">
                      <Label>Category Rule</Label>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Checkbox
                            id="allCategories"
                            checked={rules.applyToAllCategories}
                            onCheckedChange={(checked) => setRules({ ...rules, applyToAllCategories: !!checked, selectedCategories: [] })}
                          />
                          <Label htmlFor="allCategories" className="text-sm font-normal">
                            Apply to all categories of this type
                          </Label>
                        </div>
                        {!rules.applyToAllCategories && (
                          <div className="ml-6 space-y-2">
                            <Label className="text-xs text-muted-foreground">Select specific category:</Label>
                            <Select
                              value={rules.selectedCategories[0] || ''}
                              onValueChange={(value) => setRules({ ...rules, selectedCategories: [value] })}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Select category..." />
                              </SelectTrigger>
                              <SelectContent>
                                {getCategoriesForType(formData.typeId).filter(c => c.isActive).map(cat => (
                                  <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="space-y-3">
                    <Label>Priority Condition (optional)</Label>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          id="anyPriority"
                          checked={rules.priorityCondition === 'any'}
                          onCheckedChange={(checked) => setRules({ ...rules, priorityCondition: checked ? 'any' : 'specific', selectedPriorities: [] })}
                        />
                        <Label htmlFor="anyPriority" className="text-sm font-normal">
                          Show for any priority level
                        </Label>
                      </div>
                      {rules.priorityCondition === 'specific' && (
                        <div className="ml-6 space-y-2">
                          <Label className="text-xs text-muted-foreground">Only show for these priorities:</Label>
                          <div className="flex flex-wrap gap-2">
                            {priorityLevels.map(priority => (
                              <div key={priority.id} className="flex items-center gap-1">
                                <Checkbox
                                  id={`priority-${priority.id}`}
                                  checked={rules.selectedPriorities.includes(priority.id)}
                                  onCheckedChange={(checked) => {
                                    if (checked) {
                                      setRules({ ...rules, selectedPriorities: [...rules.selectedPriorities, priority.id] });
                                    } else {
                                      setRules({ ...rules, selectedPriorities: rules.selectedPriorities.filter(p => p !== priority.id) });
                                    }
                                  }}
                                />
                                <Label htmlFor={`priority-${priority.id}`} className="text-sm font-normal">{priority.name}</Label>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Separator />

            {/* Defaults */}
            <div className="space-y-4">
              <h4 className="font-medium text-sm">Default Values</h4>
              <p className="text-xs text-muted-foreground">
                These values will be pre-filled when the action is added to an issue
              </p>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="defaultOwnerRole">Default Owner Role</Label>
                  <Select
                    value={formData.defaultOwnerRole || 'Staff'}
                    onValueChange={(value) => setFormData({ ...formData, defaultOwnerRole: value as AdminRole })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Staff">Staff</SelectItem>
                      <SelectItem value="Department Head">Department Head</SelectItem>
                      <SelectItem value="Compliance Head">Compliance Head</SelectItem>
                      <SelectItem value="Admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="defaultDueDays">Default Due (Days)</Label>
                  <Input
                    id="defaultDueDays"
                    type="number"
                    min={1}
                    value={formData.defaultDueDays || 7}
                    onChange={(e) => setFormData({ ...formData, defaultDueDays: parseInt(e.target.value) || 7 })}
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 border rounded-lg bg-muted/30">
                <Switch
                  id="evidenceRequired"
                  checked={formData.evidenceRequired || false}
                  onCheckedChange={(checked) => setFormData({ ...formData, evidenceRequired: checked })}
                />
                <div>
                  <Label htmlFor="evidenceRequired" className="text-sm font-medium">Evidence Required</Label>
                  <p className="text-xs text-muted-foreground">
                    When enabled, this action step cannot be completed without uploading evidence
                  </p>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editingAction ? 'Update' : 'Add'} Action</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Recommended Action?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this action? This will remove it from all future issue wizards.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
