import { useState } from 'react';
import { Plus, Pencil, Trash2, Search, GripVertical, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/hooks/use-toast';

interface Column<T> {
  key: keyof T | string;
  label: string;
  render?: (item: T) => React.ReactNode;
  editable?: boolean;
  type?: 'text' | 'textarea' | 'number' | 'switch' | 'select';
  options?: { value: string; label: string }[];
}

interface AdminConfigCRUDTableProps<T extends { id: string; isActive?: boolean }> {
  title: string;
  description?: string;
  data: T[];
  columns: Column<T>[];
  onAdd: (item: Partial<T>) => void;
  onEdit: (item: T) => void;
  onDelete: (id: string) => void;
  onReorder?: (items: T[]) => void;
  formFields: Column<T>[];
  defaultNewItem: Partial<T>;
  searchable?: boolean;
  reorderable?: boolean;
}

export function AdminConfigCRUDTable<T extends { id: string; isActive?: boolean; name?: string }>({
  title,
  description,
  data,
  columns,
  onAdd,
  onEdit,
  onDelete,
  formFields,
  defaultNewItem,
  searchable = true,
  reorderable = false,
}: AdminConfigCRUDTableProps<T>) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<T | null>(null);
  const [formData, setFormData] = useState<Partial<T>>(defaultNewItem);

  const filteredData = searchable && searchQuery
    ? data.filter(item => 
        Object.values(item).some(val => 
          String(val).toLowerCase().includes(searchQuery.toLowerCase())
        )
      )
    : data;

  const handleAdd = () => {
    setFormData(defaultNewItem);
    setIsAddOpen(true);
  };

  const handleEdit = (item: T) => {
    setSelectedItem(item);
    setFormData(item);
    setIsEditOpen(true);
  };

  const handleDeleteClick = (item: T) => {
    setSelectedItem(item);
    setIsDeleteOpen(true);
  };

  const handleSaveNew = () => {
    onAdd({ ...formData, id: `new-${Date.now()}` });
    setIsAddOpen(false);
    toast({ title: 'Item Added', description: `New ${title.toLowerCase().slice(0, -1)} has been added.` });
  };

  const handleSaveEdit = () => {
    if (selectedItem) {
      onEdit({ ...selectedItem, ...formData } as T);
      setIsEditOpen(false);
      toast({ title: 'Item Updated', description: `${title.slice(0, -1)} has been updated.` });
    }
  };

  const handleConfirmDelete = () => {
    if (selectedItem) {
      onDelete(selectedItem.id);
      setIsDeleteOpen(false);
      toast({ title: 'Item Deleted', description: `${title.slice(0, -1)} has been deleted.` });
    }
  };

  const renderFormField = (field: Column<T>) => {
    const value = formData[field.key as keyof T];
    
    switch (field.type) {
      case 'textarea':
        return (
          <Textarea
            value={String(value || '')}
            onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
            className="min-h-[80px]"
          />
        );
      case 'number':
        return (
          <Input
            type="number"
            value={Number(value) || 0}
            onChange={(e) => setFormData({ ...formData, [field.key]: parseInt(e.target.value) })}
          />
        );
      case 'switch':
        return (
          <Switch
            checked={Boolean(value)}
            onCheckedChange={(checked) => setFormData({ ...formData, [field.key]: checked })}
          />
        );
      default:
        return (
          <Input
            value={String(value || '')}
            onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
          />
        );
    }
  };

  const FormDialog = ({ isOpen, onClose, onSave, title: dialogTitle }: { isOpen: boolean; onClose: () => void; onSave: () => void; title: string }) => (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{dialogTitle}</DialogTitle>
          <DialogDescription>Fill in the details below.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          {formFields.map((field) => (
            <div key={String(field.key)} className="space-y-2">
              <Label htmlFor={String(field.key)}>{field.label}</Label>
              {renderFormField(field)}
            </div>
          ))}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={onSave}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="font-medium">{title}</h4>
          {description && <p className="text-sm text-muted-foreground">{description}</p>}
        </div>
        <Button onClick={handleAdd} size="sm">
          <Plus className="h-4 w-4 mr-1" /> Add
        </Button>
      </div>

      {searchable && (
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={`Search ${title.toLowerCase()}...`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
      )}

      <div className="border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              {reorderable && <TableHead className="w-10"></TableHead>}
              {columns.map((col) => (
                <TableHead key={String(col.key)}>{col.label}</TableHead>
              ))}
              <TableHead className="w-24 text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredData.length === 0 ? (
              <TableRow>
                <TableCell colSpan={columns.length + (reorderable ? 2 : 1)} className="text-center py-8 text-muted-foreground">
                  No items found
                </TableCell>
              </TableRow>
            ) : (
              filteredData.map((item) => (
                <TableRow key={item.id}>
                  {reorderable && (
                    <TableCell className="cursor-move">
                      <GripVertical className="h-4 w-4 text-muted-foreground" />
                    </TableCell>
                  )}
                  {columns.map((col) => (
                    <TableCell key={String(col.key)}>
                      {col.render 
                        ? col.render(item) 
                        : col.key === 'isActive'
                          ? <Badge variant={item.isActive ? 'default' : 'secondary'}>{item.isActive ? 'Active' : 'Inactive'}</Badge>
                          : String(item[col.key as keyof T] || '-')
                      }
                    </TableCell>
                  ))}
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" size="icon" onClick={() => handleEdit(item)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDeleteClick(item)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <FormDialog
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        onSave={handleSaveNew}
        title={`Add ${title.slice(0, -1)}`}
      />

      <FormDialog
        isOpen={isEditOpen}
        onClose={() => setIsEditOpen(false)}
        onSave={handleSaveEdit}
        title={`Edit ${title.slice(0, -1)}`}
      />

      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {title.slice(0, -1)}?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{selectedItem?.name || 'this item'}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
