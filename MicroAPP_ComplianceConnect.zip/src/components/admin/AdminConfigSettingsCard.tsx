import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface SettingField {
  key: string;
  label: string;
  description?: string;
  type: 'switch' | 'number' | 'text' | 'select';
  options?: { value: string; label: string }[];
  suffix?: string;
}

interface AdminConfigSettingsCardProps {
  title: string;
  description?: string;
  settings: Record<string, any>;
  fields: SettingField[];
  onChange: (key: string, value: any) => void;
}

export function AdminConfigSettingsCard({
  title,
  description,
  settings,
  fields,
  onChange,
}: AdminConfigSettingsCardProps) {
  const renderField = (field: SettingField) => {
    const value = settings[field.key];

    switch (field.type) {
      case 'switch':
        return (
          <div className="flex items-center justify-between py-3 border-b last:border-0">
            <div className="space-y-0.5">
              <Label htmlFor={field.key} className="text-sm font-medium">{field.label}</Label>
              {field.description && (
                <p className="text-xs text-muted-foreground">{field.description}</p>
              )}
            </div>
            <Switch
              id={field.key}
              checked={Boolean(value)}
              onCheckedChange={(checked) => onChange(field.key, checked)}
            />
          </div>
        );
      case 'number':
        return (
          <div className="flex items-center justify-between py-3 border-b last:border-0">
            <div className="space-y-0.5">
              <Label htmlFor={field.key} className="text-sm font-medium">{field.label}</Label>
              {field.description && (
                <p className="text-xs text-muted-foreground">{field.description}</p>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Input
                id={field.key}
                type="number"
                value={value}
                onChange={(e) => onChange(field.key, parseInt(e.target.value))}
                className="w-20 text-right"
              />
              {field.suffix && <span className="text-sm text-muted-foreground">{field.suffix}</span>}
            </div>
          </div>
        );
      case 'select':
        return (
          <div className="flex items-center justify-between py-3 border-b last:border-0">
            <div className="space-y-0.5">
              <Label htmlFor={field.key} className="text-sm font-medium">{field.label}</Label>
              {field.description && (
                <p className="text-xs text-muted-foreground">{field.description}</p>
              )}
            </div>
            <Select value={value} onValueChange={(v) => onChange(field.key, v)}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {field.options?.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        );
      default:
        return (
          <div className="flex items-center justify-between py-3 border-b last:border-0">
            <div className="space-y-0.5">
              <Label htmlFor={field.key} className="text-sm font-medium">{field.label}</Label>
              {field.description && (
                <p className="text-xs text-muted-foreground">{field.description}</p>
              )}
            </div>
            <Input
              id={field.key}
              value={value}
              onChange={(e) => onChange(field.key, e.target.value)}
              className="w-48"
            />
          </div>
        );
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent className="space-y-0">
        {fields.map((field) => (
          <div key={field.key}>{renderField(field)}</div>
        ))}
      </CardContent>
    </Card>
  );
}
