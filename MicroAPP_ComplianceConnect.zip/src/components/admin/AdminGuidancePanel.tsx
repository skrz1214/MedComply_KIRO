import { HelpCircle, ExternalLink, Lightbulb } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface GuidanceItem {
  title: string;
  description: string;
  link?: string;
}

interface AdminGuidancePanelProps {
  section: string;
}

const guidanceContent: Record<string, { title: string; tips: GuidanceItem[]; examples?: string[] }> = {
  organization: {
    title: 'Organization & Access',
    tips: [
      { title: 'Facilities', description: 'Define all healthcare facilities in your organization. Each facility can have multiple departments.' },
      { title: 'Departments', description: 'Departments are organizational units within facilities. Assign a Department Head for routing workflows.' },
      { title: 'Users', description: 'Manage user accounts and role assignments. Users can be assigned to specific departments and facilities.' },
    ],
    examples: ['Main Hospital', 'Skilled Nursing Facility', 'Outpatient Clinic'],
  },
  complianceconnect: {
    title: 'Compliance Issues',
    tips: [
      { title: 'Issue Types', description: 'Define broad categories like Regulatory, Safety, Documentation. These drive workflow routing.' },
      { title: 'Categories', description: 'Subcategories within types for more specific classification. E.g., "Fall Prevention" under Safety.' },
      { title: 'Recommended Actions', description: 'Pre-defined action steps that auto-populate based on issue type/category selection.' },
    ],
    examples: ['Regulatory → CMS Deficiency', 'Safety → Medication Error', 'Documentation → Missing Records'],
  },
  actionguard: {
    title: 'CAPA Configuration',
    tips: [
      { title: 'Templates', description: 'Use templates to standardize CAPA requirements. The CMS/State Survey template enforces PoC elements.' },
      { title: 'RCA Methods', description: '5 Whys and Fishbone are commonly used. Configure methods available to your team.' },
      { title: 'Effectiveness KPIs', description: 'LTC-specific metrics like fall rate, pressure injuries help measure CAPA success.' },
    ],
    examples: ['CMS/State Survey Deficiency (PoC-aligned)', 'Joint Commission ESC', 'General CAPA'],
  },
  citations: {
    title: 'Citations Library',
    tips: [
      { title: 'Sources', description: 'Regulatory bodies like CMS, Joint Commission, State DOH. Internal Policy for organizational standards.' },
      { title: 'Evidence Types', description: 'Define what evidence is acceptable: policies, training records, audit results, etc.' },
      { title: 'Risk Domains', description: 'Categorize citations by risk area for reporting and prioritization.' },
    ],
    examples: ['CMS F-Tags', 'Joint Commission Standards', 'HIPAA Requirements'],
  },
  citationcases: {
    title: 'Citation Cases',
    tips: [
      { title: 'Authority Modes', description: 'CMS/State triggers PoC mode (10-day clock). Joint Commission triggers ESC mode (60-day clock).' },
      { title: 'Timeliness', description: 'Configure due date calculations and warning thresholds for regulatory deadlines.' },
      { title: 'Escalation', description: 'Set up auto-escalation rules when scope is Pattern/Widespread or severity is High/Critical.' },
    ],
    examples: ['PoC due = 2567 received + 10 days', 'ESC due = findings posted + 60 days'],
  },
  evidence: {
    title: 'Evidence & Attachments',
    tips: [
      { title: 'File Types', description: 'Control which file formats are accepted. PDF, DOCX, images are common.' },
      { title: 'Sensitivity Tags', description: 'PHI and PII tags help users handle sensitive information appropriately.' },
      { title: 'Requirements', description: 'Toggle whether evidence is required for issue completion or CAPA action verification.' },
    ],
    examples: ['PHI - Protected Health Information', 'PII - Personally Identifiable Information'],
  },
  notifications: {
    title: 'Notifications',
    tips: [
      { title: 'Templates', description: 'Customize notification text for different events. Keep messages clear and actionable.' },
      { title: 'Rules', description: 'Configure who receives notifications for specific events in each module.' },
      { title: 'Escalation', description: 'Define escalation chains with timing. Critical items escalate faster.' },
    ],
    examples: ['Due Soon (3 days)', 'Overdue Alert', 'QA Return Notification'],
  },
  reporting: {
    title: 'Reporting Settings',
    tips: [
      { title: 'Export Permissions', description: 'Control whether Staff role can export CSV reports.' },
      { title: 'SLA Thresholds', description: 'Configure aging thresholds that trigger "At Risk" status in reports.' },
      { title: 'Saved Views', description: 'Set retention period for saved report views.' },
    ],
    examples: ['Issue aging SLA: 14 days', 'CAPA due warning: 3 days before'],
  },
  integrations: {
    title: 'Integrations',
    tips: [
      { title: 'Coming Soon', description: 'Integration capabilities are under development. Connect with EHR, HR systems, and more.' },
    ],
  },
};

export function AdminGuidancePanel({ section }: AdminGuidancePanelProps) {
  const guidance = guidanceContent[section] || guidanceContent.organization;

  return (
    <Card className="h-fit sticky top-6">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center gap-2">
          <HelpCircle className="h-4 w-4 text-primary" />
          Guidance: {guidance.title}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {guidance.tips.map((tip, index) => (
            <div key={index} className="space-y-1">
              <div className="flex items-start gap-2">
                <Lightbulb className="h-4 w-4 text-yellow-500 shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium">{tip.title}</p>
                  <p className="text-xs text-muted-foreground">{tip.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {guidance.examples && guidance.examples.length > 0 && (
          <div className="pt-3 border-t">
            <p className="text-xs font-medium text-muted-foreground mb-2">Examples:</p>
            <ul className="space-y-1">
              {guidance.examples.map((example, index) => (
                <li key={index} className="text-xs text-muted-foreground flex items-center gap-1">
                  <span className="w-1 h-1 rounded-full bg-primary shrink-0" />
                  {example}
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
