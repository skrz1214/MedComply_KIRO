import { useState } from 'react';
import { Plus, Pencil, Trash2, Upload, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { 
  ContainmentActionNew, 
  RootCauseNew, 
  CapaActionNew, 
  EffectivenessCriteria,
  MonitoringEntry,
  VerificationStep,
  CapaAttachment,
  ContributingFactor,
  CapaActionType,
  CapaActionStatusNew,
  VerificationType
} from '@/types/actionguard';
import { actionTypeLabels } from '@/data/actionguardMockData';

// ==================== CONTAINMENT DIALOGS ====================

interface ContainmentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  action?: ContainmentActionNew;
  onSave: (action: Partial<ContainmentActionNew>) => void;
  mode: 'add' | 'edit';
}

export function ContainmentDialog({ open, onOpenChange, action, onSave, mode }: ContainmentDialogProps) {
  const [description, setDescription] = useState(action?.description || '');
  const [who, setWho] = useState(action?.who || '');
  const [when, setWhen] = useState(action?.when ? new Date(action.when).toISOString().split('T')[0] : '');
  const [notes, setNotes] = useState(action?.notes || '');

  const handleSave = () => {
    if (!description || !who || !when) {
      toast({ title: 'Error', description: 'Please fill in all required fields', variant: 'destructive' });
      return;
    }
    onSave({ description, who, when: new Date(when), notes });
    onOpenChange(false);
    toast({ title: mode === 'add' ? 'Added' : 'Updated', description: 'Containment action saved.' });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{mode === 'add' ? 'Add' : 'Edit'} Containment Action</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Description *</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Describe the containment action..." />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Who *</Label>
              <Input value={who} onChange={(e) => setWho(e.target.value)} placeholder="Responsible person" />
            </div>
            <div>
              <Label>When *</Label>
              <Input type="date" value={when} onChange={(e) => setWhen(e.target.value)} />
            </div>
          </div>
          <div>
            <Label>Notes</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Additional notes..." />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave}>{mode === 'add' ? 'Add' : 'Save'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ==================== ROOT CAUSE DIALOGS ====================

interface RootCauseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  rootCause?: RootCauseNew;
  onSave: (rc: Partial<RootCauseNew>) => void;
  mode: 'add' | 'edit';
}

export function RootCauseDialog({ open, onOpenChange, rootCause, onSave, mode }: RootCauseDialogProps) {
  const [statement, setStatement] = useState(rootCause?.statement || '');
  const [category, setCategory] = useState<ContributingFactor>(rootCause?.category || 'process');
  const [justification, setJustification] = useState(rootCause?.justification || '');
  const [confidence, setConfidence] = useState<'low' | 'medium' | 'high'>(rootCause?.confidence || 'medium');

  const handleSave = () => {
    if (!statement || !justification) {
      toast({ title: 'Error', description: 'Please fill in all required fields', variant: 'destructive' });
      return;
    }
    onSave({ statement, category, justification, confidence });
    onOpenChange(false);
    toast({ title: mode === 'add' ? 'Added' : 'Updated', description: 'Root cause saved.' });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{mode === 'add' ? 'Add' : 'Edit'} Root Cause</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Statement *</Label>
            <Textarea value={statement} onChange={(e) => setStatement(e.target.value)} placeholder="Root cause statement..." />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Category *</Label>
              <Select value={category} onValueChange={(v) => setCategory(v as ContributingFactor)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="people">People</SelectItem>
                  <SelectItem value="process">Process</SelectItem>
                  <SelectItem value="technology">Technology</SelectItem>
                  <SelectItem value="environment">Environment</SelectItem>
                  <SelectItem value="policy">Policy</SelectItem>
                  <SelectItem value="communication">Communication</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Confidence *</Label>
              <Select value={confidence} onValueChange={(v) => setConfidence(v as 'low' | 'medium' | 'high')}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label>Justification/Evidence *</Label>
            <Textarea value={justification} onChange={(e) => setJustification(e.target.value)} placeholder="Evidence supporting this root cause..." />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave}>{mode === 'add' ? 'Add' : 'Save'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ==================== ACTION DIALOGS ====================

interface ActionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  action?: CapaActionNew;
  onSave: (action: Partial<CapaActionNew>) => void;
  mode: 'add' | 'edit';
  actionType: 'corrective' | 'preventive';
}

export function ActionDialog({ open, onOpenChange, action, onSave, mode, actionType }: ActionDialogProps) {
  const [title, setTitle] = useState(action?.title || '');
  const [description, setDescription] = useState(action?.description || '');
  const [actionTypeVal, setActionTypeVal] = useState<CapaActionType>(action?.actionType || 'policy_procedure_update');
  const [owner, setOwner] = useState(action?.owner || '');
  const [dueDate, setDueDate] = useState(action?.dueDate ? new Date(action.dueDate).toISOString().split('T')[0] : '');
  const [status, setStatus] = useState<CapaActionStatusNew>(action?.status || 'not_started');
  const [evidenceRequired, setEvidenceRequired] = useState(action?.evidenceRequired || false);
  const [verificationType, setVerificationType] = useState<VerificationType>(action?.verificationType || 'verification');

  const handleSave = () => {
    if (!title || !description || !owner || !dueDate) {
      toast({ title: 'Error', description: 'Please fill in all required fields', variant: 'destructive' });
      return;
    }
    onSave({ 
      type: actionType, 
      title, 
      description, 
      actionType: actionTypeVal, 
      owner, 
      dueDate: new Date(dueDate), 
      status, 
      evidenceRequired,
      verificationType
    });
    onOpenChange(false);
    toast({ title: mode === 'add' ? 'Added' : 'Updated', description: `${actionType === 'corrective' ? 'Corrective' : 'Preventive'} action saved.` });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{mode === 'add' ? 'Add' : 'Edit'} {actionType === 'corrective' ? 'Corrective' : 'Preventive'} Action</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
          <div>
            <Label>Title *</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Action title..." />
          </div>
          <div>
            <Label>Description *</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Detailed description..." />
          </div>
          <div>
            <Label>Action Type *</Label>
            <Select value={actionTypeVal} onValueChange={(v) => setActionTypeVal(v as CapaActionType)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(actionTypeLabels).map(([key, label]) => (
                  <SelectItem key={key} value={key}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Owner *</Label>
              <Input value={owner} onChange={(e) => setOwner(e.target.value)} placeholder="Responsible person" />
            </div>
            <div>
              <Label>Due Date *</Label>
              <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Status</Label>
              <Select value={status} onValueChange={(v) => setStatus(v as CapaActionStatusNew)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="not_started">Not Started</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="blocked">Blocked</SelectItem>
                  <SelectItem value="done">Done</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Verification Type</Label>
              <Select value={verificationType} onValueChange={(v) => setVerificationType(v as VerificationType)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="verification">Verification</SelectItem>
                  <SelectItem value="validation">Validation</SelectItem>
                  <SelectItem value="both">Both</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <input 
              type="checkbox" 
              id="evidence-required" 
              checked={evidenceRequired} 
              onChange={(e) => setEvidenceRequired(e.target.checked)}
              className="rounded border-border"
            />
            <Label htmlFor="evidence-required">Evidence Required</Label>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave}>{mode === 'add' ? 'Add' : 'Save'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ==================== VERIFICATION STEP DIALOG ====================

interface VerificationStepDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  step?: VerificationStep;
  onSave: (step: Partial<VerificationStep>) => void;
  mode: 'add' | 'edit';
}

export function VerificationStepDialog({ open, onOpenChange, step, onSave, mode }: VerificationStepDialogProps) {
  const [description, setDescription] = useState(step?.description || '');
  const [requiredEvidence, setRequiredEvidence] = useState(step?.requiredEvidence || '');
  const [completed, setCompleted] = useState(step?.completed || false);

  const handleSave = () => {
    if (!description || !requiredEvidence) {
      toast({ title: 'Error', description: 'Please fill in all required fields', variant: 'destructive' });
      return;
    }
    onSave({ description, requiredEvidence, completed });
    onOpenChange(false);
    toast({ title: mode === 'add' ? 'Added' : 'Updated', description: 'Verification step saved.' });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{mode === 'add' ? 'Add' : 'Edit'} Verification Step</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Description *</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="What needs to be verified..." />
          </div>
          <div>
            <Label>Required Evidence *</Label>
            <Textarea value={requiredEvidence} onChange={(e) => setRequiredEvidence(e.target.value)} placeholder="What evidence is needed..." />
          </div>
          <div className="flex items-center gap-2">
            <input 
              type="checkbox" 
              id="completed" 
              checked={completed} 
              onChange={(e) => setCompleted(e.target.checked)}
              className="rounded border-border"
            />
            <Label htmlFor="completed">Completed</Label>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave}>{mode === 'add' ? 'Add' : 'Save'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ==================== EFFECTIVENESS CRITERIA DIALOG ====================

interface EffectivenessCriteriaDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  criteria?: EffectivenessCriteria;
  onSave: (criteria: Partial<EffectivenessCriteria>) => void;
  mode: 'add' | 'edit';
}

export function EffectivenessCriteriaDialog({ open, onOpenChange, criteria, onSave, mode }: EffectivenessCriteriaDialogProps) {
  const [criteriaText, setCriteriaText] = useState(criteria?.criteria || '');
  const [kpi, setKpi] = useState(criteria?.kpi || '');
  const [baseline, setBaseline] = useState(criteria?.baseline || '');
  const [target, setTarget] = useState(criteria?.target || '');

  const handleSave = () => {
    if (!criteriaText || !target) {
      toast({ title: 'Error', description: 'Please fill in all required fields', variant: 'destructive' });
      return;
    }
    onSave({ criteria: criteriaText, kpi, baseline, target });
    onOpenChange(false);
    toast({ title: mode === 'add' ? 'Added' : 'Updated', description: 'Effectiveness criteria saved.' });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{mode === 'add' ? 'Add' : 'Edit'} Effectiveness Criteria</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Criteria *</Label>
            <Textarea value={criteriaText} onChange={(e) => setCriteriaText(e.target.value)} placeholder="What will be measured..." />
          </div>
          <div>
            <Label>KPI</Label>
            <Input value={kpi} onChange={(e) => setKpi(e.target.value)} placeholder="Key performance indicator" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Baseline</Label>
              <Input value={baseline} onChange={(e) => setBaseline(e.target.value)} placeholder="Current value" />
            </div>
            <div>
              <Label>Target *</Label>
              <Input value={target} onChange={(e) => setTarget(e.target.value)} placeholder="Target value" />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave}>{mode === 'add' ? 'Add' : 'Save'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ==================== MONITORING ENTRY DIALOG ====================

interface MonitoringEntryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  entry?: MonitoringEntry;
  onSave: (entry: Partial<MonitoringEntry>) => void;
  mode: 'add' | 'edit';
}

export function MonitoringEntryDialog({ open, onOpenChange, entry, onSave, mode }: MonitoringEntryDialogProps) {
  const [date, setDate] = useState(entry?.date ? new Date(entry.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]);
  const [metricValue, setMetricValue] = useState(entry?.metricValue || '');
  const [notes, setNotes] = useState(entry?.notes || '');
  const [recordedBy, setRecordedBy] = useState(entry?.recordedBy || '');

  const handleSave = () => {
    if (!date || !metricValue || !recordedBy) {
      toast({ title: 'Error', description: 'Please fill in all required fields', variant: 'destructive' });
      return;
    }
    onSave({ date: new Date(date), metricValue, notes, recordedBy });
    onOpenChange(false);
    toast({ title: mode === 'add' ? 'Added' : 'Updated', description: 'Monitoring entry saved.' });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{mode === 'add' ? 'Add' : 'Edit'} Monitoring Entry</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Date *</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div>
              <Label>Recorded By *</Label>
              <Input value={recordedBy} onChange={(e) => setRecordedBy(e.target.value)} placeholder="Your name" />
            </div>
          </div>
          <div>
            <Label>Metric Value *</Label>
            <Input value={metricValue} onChange={(e) => setMetricValue(e.target.value)} placeholder="Observed value" />
          </div>
          <div>
            <Label>Notes</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Additional observations..." />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave}>{mode === 'add' ? 'Add' : 'Save'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ==================== FILE ATTACHMENT DIALOG ====================

interface FileAttachmentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (attachment: Partial<CapaAttachment>) => void;
}

export function FileAttachmentDialog({ open, onOpenChange, onSave }: FileAttachmentDialogProps) {
  const [fileName, setFileName] = useState('');
  const [description, setDescription] = useState('');

  const handleSave = () => {
    if (!fileName) {
      toast({ title: 'Error', description: 'Please select a file', variant: 'destructive' });
      return;
    }
    onSave({ 
      fileName, 
      fileType: fileName.split('.').pop() || 'unknown',
      fileSize: 0,
      url: '#',
      uploadedBy: 'Current User',
      uploadedAt: new Date()
    });
    onOpenChange(false);
    setFileName('');
    setDescription('');
    toast({ title: 'Uploaded', description: 'File attachment saved.' });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Upload Attachment</DialogTitle>
          <DialogDescription>Attach supporting documents or evidence files.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
            <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground mb-2">Drag and drop or click to upload</p>
            <Input 
              type="file" 
              onChange={(e) => setFileName(e.target.files?.[0]?.name || '')}
              className="cursor-pointer"
            />
          </div>
          {fileName && (
            <p className="text-sm text-foreground">Selected: {fileName}</p>
          )}
          <div>
            <Label>Description (optional)</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Describe this attachment..." />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave}>Upload</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ==================== DELETE CONFIRMATION DIALOG ====================

interface DeleteConfirmDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
  itemType: string;
}

export function DeleteConfirmDialog({ open, onOpenChange, onConfirm, itemType }: DeleteConfirmDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Delete {itemType}?</DialogTitle>
          <DialogDescription>
            Are you sure you want to delete this {itemType.toLowerCase()}? This action cannot be undone.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button variant="destructive" onClick={() => {
            onConfirm();
            onOpenChange(false);
            toast({ title: 'Deleted', description: `${itemType} has been deleted.` });
          }}>Delete</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ==================== CRUD TOOLBAR COMPONENT ====================

interface CrudToolbarProps {
  onAdd?: () => void;
  addLabel?: string;
  showAdd?: boolean;
}

export function CrudToolbar({ onAdd, addLabel = 'Add', showAdd = true }: CrudToolbarProps) {
  if (!showAdd) return null;
  
  return (
    <div className="flex justify-end mb-4">
      <Button variant="outline" size="sm" onClick={onAdd} className="gap-2">
        <Plus className="h-4 w-4" /> {addLabel}
      </Button>
    </div>
  );
}

// ==================== ITEM ACTIONS COMPONENT ====================

interface ItemActionsProps {
  onEdit?: () => void;
  onDelete?: () => void;
}

export function ItemActions({ onEdit, onDelete }: ItemActionsProps) {
  return (
    <div className="flex items-center gap-1">
      {onEdit && (
        <Button variant="ghost" size="icon" onClick={onEdit} className="h-8 w-8">
          <Pencil className="h-4 w-4" />
        </Button>
      )}
      {onDelete && (
        <Button variant="ghost" size="icon" onClick={onDelete} className="h-8 w-8 text-destructive hover:text-destructive">
          <Trash2 className="h-4 w-4" />
        </Button>
      )}
    </div>
  );
}
