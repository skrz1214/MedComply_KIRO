import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Info, FileText, Clock, Search, CheckCircle2, Activity, Shield, BarChart3, RotateCcw, Lock } from 'lucide-react';
import { CapaStatusNew } from '@/types/actionguard';

// Bucket definitions
export type CapaBucket = 'new' | 'open' | 'closed';

export const BUCKET_STATUSES: Record<CapaBucket, CapaStatusNew[]> = {
  new: ['draft', 'submitted', 'in_review'],
  open: ['approved', 'in_progress', 'verification', 'effectiveness_monitoring', 'reopened'],
  closed: ['closed'],
};

export const BUCKET_LABELS: Record<CapaBucket, { label: string; description: string }> = {
  new: { 
    label: 'NEW', 
    description: 'CAPAs being authored or awaiting review approval' 
  },
  open: { 
    label: 'OPEN', 
    description: 'CAPAs approved and in active execution or monitoring' 
  },
  closed: { 
    label: 'CLOSED', 
    description: 'Completed CAPAs that have been signed off' 
  },
};

// Phase definitions with tooltips
export const PHASE_DEFINITIONS: Record<CapaStatusNew, { 
  label: string; 
  definition: string; 
  nextAction: string;
  icon: any;
}> = {
  draft: {
    label: 'Draft',
    definition: 'CAPA is being authored; not yet submitted for approval.',
    nextAction: 'Complete all required fields and submit for review.',
    icon: FileText,
  },
  submitted: {
    label: 'Submitted',
    definition: 'CAPA is sent for review; waiting for approver action.',
    nextAction: 'Awaiting approver to begin review.',
    icon: Clock,
  },
  in_review: {
    label: 'In Review',
    definition: 'Approvers are evaluating; may approve or request changes.',
    nextAction: 'Approver will approve, request changes, or reject.',
    icon: Search,
  },
  approved: {
    label: 'Approved',
    definition: 'Authorized to execute; ready for action execution.',
    nextAction: 'Start working on corrective and preventive actions.',
    icon: CheckCircle2,
  },
  in_progress: {
    label: 'In Progress',
    definition: 'Actions are being executed; evidence collected.',
    nextAction: 'Complete all required actions and move to verification.',
    icon: Activity,
  },
  verification: {
    label: 'Verification',
    definition: 'Confirm implementation ("did we do it?").',
    nextAction: 'Verify all actions were implemented as planned.',
    icon: Shield,
  },
  effectiveness_monitoring: {
    label: 'Effectiveness Monitoring',
    definition: 'Confirm outcome over time ("did it work?").',
    nextAction: 'Monitor metrics and determine if fix is effective.',
    icon: BarChart3,
  },
  reopened: {
    label: 'Reopened',
    definition: 'Returned due to failure/recurrence; requires updated actions.',
    nextAction: 'Add new actions and reset monitoring window.',
    icon: RotateCcw,
  },
  closed: {
    label: 'Closed',
    definition: 'Completed and signed off; read-only unless reopened by authorized role.',
    nextAction: 'No action required. CAPA is complete.',
    icon: Lock,
  },
};

// Helper to get bucket for a status
export function getCapaBucket(status: CapaStatusNew): CapaBucket {
  if (BUCKET_STATUSES.new.includes(status)) return 'new';
  if (BUCKET_STATUSES.open.includes(status)) return 'open';
  return 'closed';
}

// Phase tooltip component
export function PhaseTooltip({ status }: { status: CapaStatusNew }) {
  const phase = PHASE_DEFINITIONS[status];
  const PhaseIcon = phase.icon;
  
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span className="inline-flex items-center gap-1 cursor-help">
          <PhaseIcon className="h-3 w-3" />
          {phase.label}
          <Info className="h-3 w-3 text-muted-foreground" />
        </span>
      </TooltipTrigger>
      <TooltipContent side="top" className="max-w-xs">
        <p className="font-medium">{phase.label}</p>
        <p className="text-xs text-muted-foreground mt-1">{phase.definition}</p>
      </TooltipContent>
    </Tooltip>
  );
}

// Bucket tab badges
export function BucketTabBadge({ bucket, count }: { bucket: CapaBucket; count: number }) {
  const colors: Record<CapaBucket, string> = {
    new: 'bg-amber-500/10 text-amber-600',
    open: 'bg-blue-500/10 text-blue-600',
    closed: 'bg-green-500/10 text-green-600',
  };
  
  return (
    <span className={`ml-2 px-2 py-0.5 text-xs font-medium rounded-full ${colors[bucket]}`}>
      {count}
    </span>
  );
}

// Mode banner for detail page
export function CapaModeBanner({ 
  status, 
  className = '' 
}: { 
  status: CapaStatusNew; 
  className?: string;
}) {
  const bucket = getCapaBucket(status);
  const phase = PHASE_DEFINITIONS[status];
  const PhaseIcon = phase.icon;
  
  const bannerStyles: Record<CapaBucket, string> = {
    new: 'bg-amber-500/10 border-amber-500/30 text-amber-800',
    open: 'bg-blue-500/10 border-blue-500/30 text-blue-800',
    closed: 'bg-green-500/10 border-green-500/30 text-green-800',
  };
  
  const bannerTitles: Record<CapaBucket, string> = {
    new: 'Authoring & Review',
    open: 'Execution',
    closed: 'Closed',
  };

  return (
    <div className={`rounded-lg border p-4 ${bannerStyles[bucket]} ${className}`}>
      <div className="flex items-start gap-3">
        <div className="p-2 rounded-lg bg-background/50">
          <PhaseIcon className="h-5 w-5" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-semibold">{bannerTitles[bucket]}</span>
            <Badge variant="outline" className="text-xs">
              {BUCKET_LABELS[bucket].label}
            </Badge>
          </div>
          <p className="text-sm font-medium">{phase.label}: {phase.definition}</p>
          <p className="text-sm mt-2 opacity-80">
            <strong>Next:</strong> {phase.nextAction}
          </p>
        </div>
      </div>
    </div>
  );
}

// Readiness checklist widget for NEW CAPAs
export function ReadinessChecklist({ 
  hasTitle,
  hasProblemStatement,
  hasOwner,
  hasDueDate,
  hasRootCause,
  hasActions,
}: {
  hasTitle: boolean;
  hasProblemStatement: boolean;
  hasOwner: boolean;
  hasDueDate: boolean;
  hasRootCause: boolean;
  hasActions: boolean;
}) {
  const items = [
    { label: 'Title', complete: hasTitle },
    { label: 'Problem Statement', complete: hasProblemStatement },
    { label: 'Owner Assigned', complete: hasOwner },
    { label: 'Due Date Set', complete: hasDueDate },
    { label: 'Root Cause Identified', complete: hasRootCause },
    { label: 'Actions Defined', complete: hasActions },
  ];
  
  const completedCount = items.filter(i => i.complete).length;
  const progress = (completedCount / items.length) * 100;
  
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-sm">
        <span className="font-medium">Readiness Checklist</span>
        <span className="text-muted-foreground">{completedCount}/{items.length}</span>
      </div>
      <div className="h-2 rounded-full bg-muted overflow-hidden">
        <div 
          className="h-full bg-amber-500 transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>
      <div className="space-y-2">
        {items.map((item) => (
          <div key={item.label} className="flex items-center gap-2 text-sm">
            {item.complete ? (
              <CheckCircle2 className="h-4 w-4 text-green-600" />
            ) : (
              <div className="h-4 w-4 rounded-full border-2 border-muted-foreground/30" />
            )}
            <span className={item.complete ? 'text-foreground' : 'text-muted-foreground'}>
              {item.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// Progress meter widget for OPEN CAPAs
export function ExecutionProgressMeter({
  actionsCompleted,
  totalActions,
  verificationComplete,
  effectivenessDueDate,
}: {
  actionsCompleted: number;
  totalActions: number;
  verificationComplete: boolean;
  effectivenessDueDate?: string;
}) {
  const actionProgress = totalActions > 0 ? (actionsCompleted / totalActions) * 100 : 0;
  const daysUntilEffectiveness = effectivenessDueDate
    ? Math.ceil((new Date(effectivenessDueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
    : null;
  
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="font-medium">Actions Progress</span>
          <span className="text-muted-foreground">{actionsCompleted}/{totalActions}</span>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden">
          <div 
            className="h-full bg-blue-500 transition-all duration-300"
            style={{ width: `${actionProgress}%` }}
          />
        </div>
      </div>
      
      <div className="flex items-center justify-between text-sm">
        <span>Verification</span>
        <Badge variant="outline" className={verificationComplete 
          ? 'bg-green-500/10 text-green-600 border-green-500/20' 
          : 'bg-muted text-muted-foreground'
        }>
          {verificationComplete ? 'Complete' : 'Pending'}
        </Badge>
      </div>
      
      {daysUntilEffectiveness !== null && (
        <div className="flex items-center justify-between text-sm">
          <span>Effectiveness Due</span>
          <span className={daysUntilEffectiveness < 0 
            ? 'text-red-600 font-medium' 
            : daysUntilEffectiveness <= 7 
              ? 'text-amber-600 font-medium' 
              : 'text-muted-foreground'
          }>
            {daysUntilEffectiveness < 0 
              ? `${Math.abs(daysUntilEffectiveness)} days overdue`
              : daysUntilEffectiveness === 0 
                ? 'Due today'
                : `${daysUntilEffectiveness} days`
            }
          </span>
        </div>
      )}
    </div>
  );
}
