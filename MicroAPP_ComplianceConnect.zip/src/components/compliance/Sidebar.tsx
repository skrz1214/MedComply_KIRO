import { NavLink } from '@/components/NavLink';
import { cn } from '@/lib/utils';
import { 
  LayoutDashboard, 
  FileText, 
  ClipboardList, 
  Shield,
  ChevronLeft,
  ChevronDown,
  Menu,
  BookOpen,
  ClipboardCheck,
  BarChart3,
  Settings,
  FolderOpen,
  AlertCircle,
  FileStack
} from 'lucide-react';
import { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';

interface NavItem {
  to: string;
  icon: any;
  label: string;
  end?: boolean;
  children?: { to: string; label: string }[];
}

const navItems: NavItem[] = [
  { to: '/', icon: LayoutDashboard, label: 'Dashboard', end: true },
  { to: '/report', icon: FileText, label: 'Report Issue' },
  { to: '/issues', icon: ClipboardList, label: 'Issues' },
  { 
    to: '/citations', 
    icon: BookOpen, 
    label: 'Citations',
    children: [
      { to: '/citations', label: 'Citation Library' },
      { to: '/citations/cases', label: 'Citation Cases' },
    ]
  },
  { 
    to: '/actionguard', 
    icon: ClipboardCheck, 
    label: 'ActionGuard (CAPA)',
    children: [
      { to: '/actionguard', label: 'Dashboard' },
      { to: '/actionguard/list', label: 'CAPAs' },
      { to: '/actionguard/approvals', label: 'Approvals' },
      { to: '/actionguard/my-work', label: 'My Work' },
    ]
  },
  { to: '/reports', icon: BarChart3, label: 'Reports' },
  { 
    to: '/docs', 
    icon: FileStack, 
    label: 'Documentation',
    children: [
      { to: '/prd', label: 'PRD Document' },
      { to: '/qa-tests', label: 'QA Test Cases' },
      { to: '/uat-tests', label: 'UAT Test Cases' },
      { to: '/system-prompt', label: 'AI System Prompt' },
    ]
  },
  { to: '/admin', icon: Settings, label: 'Admin Config' },
];

export function Sidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [expandedItems, setExpandedItems] = useState<string[]>(['/citations', '/docs']);
  const location = useLocation();

  const toggleExpanded = (path: string) => {
    setExpandedItems(prev => 
      prev.includes(path) ? prev.filter(p => p !== path) : [...prev, path]
    );
  };

  const isChildActive = (item: NavItem) => {
    return item.children?.some(child => location.pathname === child.to || location.pathname.startsWith(child.to + '/'));
  };

  return (
    <aside 
      className={cn(
        'fixed left-0 top-0 h-screen bg-white border-r border-gray-200 transition-all duration-300 z-50',
        isCollapsed ? 'w-16' : 'w-56'
      )}
    >
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="h-14 flex items-center justify-between px-3 border-b border-gray-200">
          {!isCollapsed && (
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                <Shield className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-gray-900 text-sm">ComplianceConnect</span>
            </div>
          )}
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="text-gray-500 hover:bg-gray-100 shrink-0 h-8 w-8"
          >
            {isCollapsed ? <Menu className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>

        {/* Navigation Label */}
        {!isCollapsed && (
          <div className="px-4 py-3">
            <span className="text-xs font-medium text-gray-400 uppercase tracking-wider">Navigation</span>
          </div>
        )}

        {/* Navigation */}
        <nav className="flex-1 px-2 space-y-0.5 overflow-y-auto">
          {navItems.map((item) => (
            <div key={item.to}>
              {item.children ? (
                <>
                  <button
                    onClick={() => toggleExpanded(item.to)}
                    className={cn(
                      'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-200',
                      'text-gray-600 hover:text-gray-900 hover:bg-gray-100',
                      isChildActive(item) && 'bg-blue-50 text-blue-700 font-medium'
                    )}
                  >
                    <item.icon className="h-5 w-5 shrink-0" />
                    {!isCollapsed && (
                      <>
                        <span className="flex-1 text-left">{item.label}</span>
                        <ChevronDown className={cn(
                          'h-4 w-4 transition-transform',
                          expandedItems.includes(item.to) && 'rotate-180'
                        )} />
                      </>
                    )}
                  </button>
                  {!isCollapsed && expandedItems.includes(item.to) && (
                    <div className="ml-5 pl-3 border-l border-gray-200 space-y-0.5 mt-0.5">
                      {item.children.map(child => (
                        <NavLink
                          key={child.to}
                          to={child.to}
                          end={child.to === '/citations'}
                          className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm text-gray-500 hover:text-gray-900 hover:bg-gray-100"
                          activeClassName="text-blue-700 bg-blue-50 font-medium"
                        >
                          {child.label}
                        </NavLink>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <NavLink
                  to={item.to}
                  end={item.end}
                  className={cn(
                    'flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-200',
                    'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  )}
                  activeClassName="bg-blue-50 text-blue-700 hover:bg-blue-50 hover:text-blue-700 font-medium"
                >
                  <item.icon className="h-5 w-5 shrink-0" />
                  {!isCollapsed && <span>{item.label}</span>}
                </NavLink>
              )}
            </div>
          ))}
        </nav>

        {/* Footer */}
        {!isCollapsed && (
          <div className="p-3 border-t border-gray-200">
            <div className="rounded-lg bg-gray-50 p-3">
              <p className="text-xs font-medium text-gray-700 mb-0.5">Need Help?</p>
              <p className="text-xs text-gray-500">Contact compliance support</p>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
