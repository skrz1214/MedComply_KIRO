import { useState } from 'react';
import { ComplianceIssue, WorkflowStage, Attachment, ActionStep } from '@/types/compliance';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  ChevronDown, 
  ChevronUp,
  FileText,
  Image,
  File,
  Download,
  Eye,
  Calendar,
  User,
  CheckCircle2,
  Clock,
  XCircle,
  AlertTriangle,
  Send,
  ClipboardList,
  MessageSquare,
  Paperclip
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

interface StageDetailsViewProps {
  issue: ComplianceIssue;
}

interface StageInfo {
  stage: WorkflowStage;
  label: string;
  description: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  borderColor: string;
}

const stageConfig: StageInfo[] = [
  {
    stage: 'reported',
    label: 'Initial Report',
    description: 'Issue was reported and submitted for review',
    icon: AlertTriangle,
    color: 'text-info',
    bgColor: 'bg-info/10',
    borderColor: 'border-info/30',
  },
  {
    stage: 'initiation',
    label: 'Initiation',
    description: 'Admin reviewed and assigned action steps',
    icon: ClipboardList,
    color: 'text-accent',
    bgColor: 'bg-accent/10',
    borderColor: 'border-accent/30',
  },
  {
    stage: 'in_progress',
    label: 'Work in Progress',
    description: 'Assignee working through action steps',
    icon: Clock,
    color: 'text-warning',
    bgColor: 'bg-warning/10',
    borderColor: 'border-warning/30',
  },
  {
    stage: 'qa_review',
    label: 'QA Review',
    description: 'Quality assurance reviewing completed work',
    icon: CheckCircle2,
    color: 'text-primary',
    bgColor: 'bg-primary/10',
    borderColor: 'border-primary/30',
  },
  {
    stage: 'completed',
    label: 'Completed',
    description: 'Issue resolved and closed',
    icon: CheckCircle2,
    color: 'text-success',
    bgColor: 'bg-success/10',
    borderColor: 'border-success/30',
  },
];

const getStageIndex = (status: string): number => {
  const statusToStage: Record<string, number> = {
    'reported': 0,
    'in_progress': 2,
    'qa_review': 3,
    'completed': 4,
    'rejected': 2,
  };
  return statusToStage[status] ?? 0;
};

export function StageDetailsView({ issue }: StageDetailsViewProps) {
  const [expandedStages, setExpandedStages] = useState<Set<WorkflowStage>>(new Set(['reported']));

  const toggleStage = (stage: WorkflowStage) => {
    const newExpanded = new Set(expandedStages);
    if (newExpanded.has(stage)) {
      newExpanded.delete(stage);
    } else {
      newExpanded.add(stage);
    }
    setExpandedStages(newExpanded);
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) return Image;
    if (fileType.includes('pdf') || fileType.includes('document')) return FileText;
    return File;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const currentStageIndex = getStageIndex(issue.status);

  // Generate stage-specific details
  const getStageDetails = (stageInfo: StageInfo) => {
    const stageIndex = stageConfig.findIndex(s => s.stage === stageInfo.stage);
    const isCompleted = stageIndex < currentStageIndex;
    const isCurrent = stageIndex === currentStageIndex;
    const isPending = stageIndex > currentStageIndex;

    const attachments = issue.attachments.filter(a => a.stage === stageInfo.stage);
    
    // Get action steps completed during this stage (for in_progress stage)
    const completedSteps = stageInfo.stage === 'in_progress' 
      ? issue.actionSteps.filter(s => s.status === 'complete' || s.status === 'deferred' || s.status === 'rejected')
      : [];

    // Stage-specific information
    let stageData: {
      actor?: string;
      date?: Date;
      notes?: string[];
      actions?: string[];
    } = {};

    switch (stageInfo.stage) {
      case 'reported':
        stageData = {
          actor: issue.reportedBy,
          date: issue.reportedAt,
          notes: [issue.description],
          actions: ['Submitted compliance issue report'],
        };
        break;
      case 'initiation':
        if (issue.assignedTo) {
          stageData = {
            actor: 'Department Admin',
            date: issue.reportedAt,
            actions: [
              `Selected issue type: ${issue.issueType.replace('_', ' ')}`,
              `Set priority: ${issue.priority}`,
              `Added ${issue.actionSteps.length} action steps`,
              issue.assignedTo ? `Assigned to ${issue.assignedTo}` : 'Pending assignment',
            ],
          };
        }
        break;
      case 'in_progress':
        if (issue.status === 'in_progress' || currentStageIndex > 2) {
          stageData = {
            actor: issue.assignedTo || 'Assignee',
            actions: completedSteps.map(s => 
              `${s.status === 'complete' ? '✓' : s.status === 'deferred' ? '⏸' : '✗'} ${s.description}`
            ),
          };
        }
        break;
      case 'qa_review':
        if (issue.status === 'qa_review' || issue.status === 'completed') {
          stageData = {
            actor: 'QA Reviewer',
            actions: issue.status === 'completed' 
              ? ['Reviewed all action steps', 'Verified evidence and documentation', 'Approved for closure']
              : ['Reviewing submitted work...'],
          };
        }
        break;
      case 'completed':
        if (issue.status === 'completed') {
          stageData = {
            actor: 'Department Admin',
            date: issue.closedAt,
            actions: ['Issue verified and closed', 'Audit trail finalized'],
          };
        }
        break;
    }

    return { stageData, attachments, isCompleted, isCurrent, isPending };
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <h3 className="font-semibold">Issue Timeline</h3>
        <Badge variant="secondary" className="text-xs">
          Stage {currentStageIndex + 1} of {stageConfig.length}
        </Badge>
      </div>

      <div className="relative">
        {/* Timeline line */}
        <div className="absolute left-6 top-8 bottom-8 w-0.5 bg-border" />

        <div className="space-y-4">
          {stageConfig.map((stageInfo, index) => {
            const { stageData, attachments, isCompleted, isCurrent, isPending } = getStageDetails(stageInfo);
            const isExpanded = expandedStages.has(stageInfo.stage);
            const StageIcon = stageInfo.icon;

            return (
              <div key={stageInfo.stage} className="relative">
                <div 
                  className={cn(
                    'rounded-xl border transition-all',
                    isCurrent && `${stageInfo.borderColor} ${stageInfo.bgColor}`,
                    isCompleted && 'border-success/30 bg-success/5',
                    isPending && 'border-border bg-card/50 opacity-60'
                  )}
                >
                  <button
                    className="w-full flex items-center gap-4 p-4 text-left"
                    onClick={() => toggleStage(stageInfo.stage)}
                    disabled={isPending}
                  >
                    {/* Stage icon */}
                    <div 
                      className={cn(
                        'w-12 h-12 rounded-full flex items-center justify-center shrink-0 z-10',
                        isCompleted && 'bg-success text-success-foreground',
                        isCurrent && `${stageInfo.bgColor} ${stageInfo.color}`,
                        isPending && 'bg-muted text-muted-foreground'
                      )}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="h-6 w-6" />
                      ) : (
                        <StageIcon className="h-6 w-6" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className={cn(
                          'font-semibold',
                          isPending && 'text-muted-foreground'
                        )}>
                          {stageInfo.label}
                        </h4>
                        {isCurrent && (
                          <Badge variant="default" className="text-xs animate-pulse">
                            Current
                          </Badge>
                        )}
                        {isCompleted && (
                          <Badge variant="success" className="text-xs">
                            Completed
                          </Badge>
                        )}
                        {isPending && (
                          <Badge variant="muted" className="text-xs">
                            Pending
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{stageInfo.description}</p>
                      
                      {!isPending && (stageData.actor || attachments.length > 0) && (
                        <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                          {stageData.actor && (
                            <span className="flex items-center gap-1">
                              <User className="h-3 w-3" />
                              {stageData.actor}
                            </span>
                          )}
                          {stageData.date && (
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {format(new Date(stageData.date), 'MMM d, yyyy')}
                            </span>
                          )}
                          {attachments.length > 0 && (
                            <span className="flex items-center gap-1">
                              <Paperclip className="h-3 w-3" />
                              {attachments.length} file(s)
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    {!isPending && (
                      isExpanded ? (
                        <ChevronUp className="h-5 w-5 text-muted-foreground" />
                      ) : (
                        <ChevronDown className="h-5 w-5 text-muted-foreground" />
                      )
                    )}
                  </button>

                  {isExpanded && !isPending && (
                    <div className="px-4 pb-4 pt-2 border-t border-border/50 ml-16 space-y-4 animate-fade-in">
                      {/* Actions/Notes */}
                      {stageData.actions && stageData.actions.length > 0 && (
                        <div>
                          <label className="text-sm font-medium mb-2 block flex items-center gap-2">
                            <MessageSquare className="h-4 w-4 text-muted-foreground" />
                            Activity
                          </label>
                          <div className="space-y-2">
                            {stageData.actions.map((action, idx) => (
                              <div 
                                key={idx}
                                className="text-sm p-2 rounded-lg bg-secondary/50 flex items-start gap-2"
                              >
                                <span className="text-muted-foreground">•</span>
                                <span>{action}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Notes */}
                      {stageData.notes && stageData.notes.length > 0 && (
                        <div>
                          <label className="text-sm font-medium mb-2 block">Description</label>
                          {stageData.notes.map((note, idx) => (
                            <p key={idx} className="text-sm text-muted-foreground bg-secondary/50 p-3 rounded-lg">
                              {note}
                            </p>
                          ))}
                        </div>
                      )}

                      {/* Attachments */}
                      {attachments.length > 0 && (
                        <div>
                          <label className="text-sm font-medium mb-2 block flex items-center gap-2">
                            <Paperclip className="h-4 w-4 text-muted-foreground" />
                            Attachments ({attachments.length})
                          </label>
                          <div className="space-y-2">
                            {attachments.map((attachment) => {
                              const FileIcon = getFileIcon(attachment.fileType);
                              const isImage = attachment.fileType.startsWith('image/');

                              return (
                                <div
                                  key={attachment.id}
                                  className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card group"
                                >
                                  <div className={cn(
                                    'w-10 h-10 rounded-lg flex items-center justify-center shrink-0',
                                    isImage ? 'bg-transparent' : 'bg-muted'
                                  )}>
                                    {isImage ? (
                                      <img 
                                        src={attachment.url} 
                                        alt={attachment.fileName}
                                        className="w-10 h-10 rounded-lg object-cover"
                                      />
                                    ) : (
                                      <FileIcon className="h-5 w-5 text-muted-foreground" />
                                    )}
                                  </div>

                                  <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium truncate">{attachment.fileName}</p>
                                    <p className="text-xs text-muted-foreground">
                                      {formatFileSize(attachment.fileSize)} • {attachment.uploadedBy} • {format(new Date(attachment.uploadedAt), 'MMM d, h:mm a')}
                                    </p>
                                  </div>

                                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-8 w-8"
                                      onClick={() => window.open(attachment.url, '_blank')}
                                    >
                                      <Eye className="h-4 w-4" />
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-8 w-8"
                                      onClick={() => {
                                        const link = document.createElement('a');
                                        link.href = attachment.url;
                                        link.download = attachment.fileName;
                                        link.click();
                                      }}
                                    >
                                      <Download className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Empty state */}
                      {(!stageData.actions || stageData.actions.length === 0) && 
                       (!stageData.notes || stageData.notes.length === 0) && 
                       attachments.length === 0 && (
                        <p className="text-sm text-muted-foreground text-center py-4">
                          No detailed information recorded for this stage yet.
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
