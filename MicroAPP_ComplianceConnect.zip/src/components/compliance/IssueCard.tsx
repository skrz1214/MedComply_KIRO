import { ComplianceIssue } from '@/types/compliance';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Calendar, 
  User, 
  ArrowRight, 
  AlertCircle,
  Clock,
  CheckCircle2
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

interface IssueCardProps {
  issue: ComplianceIssue;
  onViewDetails: (id: string) => void;
}

export function IssueCard({ issue, onViewDetails }: IssueCardProps) {
  const statusConfig = {
    reported: { label: 'Reported', variant: 'info' as const, icon: AlertCircle },
    in_progress: { label: 'In Progress', variant: 'pending' as const, icon: Clock },
    qa_review: { label: 'QA Review', variant: 'warning' as const, icon: Clock },
    completed: { label: 'Completed', variant: 'success' as const, icon: CheckCircle2 },
    rejected: { label: 'Rejected', variant: 'destructive' as const, icon: AlertCircle },
  };

  const priorityConfig = {
    low: 'bg-muted text-muted-foreground',
    medium: 'bg-info/10 text-info',
    high: 'bg-warning/10 text-warning',
    critical: 'bg-destructive/10 text-destructive',
  };

  const status = statusConfig[issue.status];
  const StatusIcon = status.icon;

  const isOverdue = issue.dueDate && new Date(issue.dueDate) < new Date() && issue.status !== 'completed';

  return (
    <div className="group rounded-xl border border-border bg-card p-5 shadow-soft transition-all duration-200 hover:shadow-medium hover:border-primary/20">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-mono text-muted-foreground">{issue.id}</span>
            <Badge variant={status.variant} className="gap-1">
              <StatusIcon className="h-3 w-3" />
              {status.label}
            </Badge>
            <span className={cn(
              'text-xs font-semibold px-2 py-0.5 rounded-full capitalize',
              priorityConfig[issue.priority]
            )}>
              {issue.priority}
            </span>
          </div>
          
          <h3 className="font-semibold text-foreground mb-2 line-clamp-1 group-hover:text-primary transition-colors">
            {issue.title}
          </h3>
          
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
            {issue.description}
          </p>

          <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <User className="h-3.5 w-3.5" />
              <span>{issue.reportedBy}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5" />
              <span>{format(new Date(issue.reportedAt), 'MMM d, yyyy')}</span>
            </div>
            {issue.dueDate && (
              <div className={cn(
                'flex items-center gap-1.5',
                isOverdue && 'text-destructive font-medium'
              )}>
                <Clock className="h-3.5 w-3.5" />
                <span>Due {format(new Date(issue.dueDate), 'MMM d')}</span>
                {isOverdue && <span className="text-destructive">• Overdue</span>}
              </div>
            )}
          </div>
        </div>

        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => onViewDetails(issue.id)}
          className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>

      {issue.actionSteps.length > 0 && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">
              Action Steps Progress
            </span>
            <span className="text-xs font-medium">
              {issue.actionSteps.filter(s => s.status === 'complete').length} / {issue.actionSteps.length}
            </span>
          </div>
          <div className="mt-2 h-1.5 bg-secondary rounded-full overflow-hidden">
            <div 
              className="h-full bg-primary rounded-full transition-all duration-300"
              style={{ 
                width: `${(issue.actionSteps.filter(s => s.status === 'complete').length / issue.actionSteps.length) * 100}%` 
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
}
