import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Attachment, WorkflowStage } from '@/types/compliance';
import { 
  Upload, 
  Paperclip, 
  X, 
  FileText, 
  Image, 
  File,
  Download,
  Eye
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

interface AttachmentUploaderProps {
  attachments: Attachment[];
  onAttachmentsChange: (attachments: Attachment[]) => void;
  stage: WorkflowStage;
  uploadedBy: string;
  isEditable?: boolean;
  maxFiles?: number;
  maxSizeMB?: number;
}

export function AttachmentUploader({
  attachments,
  onAttachmentsChange,
  stage,
  uploadedBy,
  isEditable = true,
  maxFiles = 10,
  maxSizeMB = 10
}: AttachmentUploaderProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) return Image;
    if (fileType.includes('pdf') || fileType.includes('document')) return FileText;
    return File;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const handleFileSelect = (files: FileList | null) => {
    if (!files || files.length === 0) return;

    const currentCount = attachments.filter(a => a.stage === stage).length;
    if (currentCount + files.length > maxFiles) {
      toast({
        title: 'Too many files',
        description: `You can only upload up to ${maxFiles} files per stage.`,
        variant: 'destructive',
      });
      return;
    }

    const newAttachments: Attachment[] = [];

    Array.from(files).forEach((file) => {
      if (file.size > maxSizeMB * 1024 * 1024) {
        toast({
          title: 'File too large',
          description: `${file.name} exceeds the ${maxSizeMB}MB limit.`,
          variant: 'destructive',
        });
        return;
      }

      // Create a mock URL for demo purposes
      const mockUrl = URL.createObjectURL(file);

      newAttachments.push({
        id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        fileName: file.name,
        fileType: file.type,
        fileSize: file.size,
        url: mockUrl,
        uploadedBy,
        uploadedAt: new Date(),
        stage,
      });
    });

    onAttachmentsChange([...attachments, ...newAttachments]);

    toast({
      title: 'Files uploaded',
      description: `${newAttachments.length} file(s) added successfully.`,
    });
  };

  const handleRemoveAttachment = (id: string) => {
    onAttachmentsChange(attachments.filter(a => a.id !== id));
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileSelect(e.dataTransfer.files);
  };

  const stageAttachments = attachments.filter(a => a.stage === stage);

  return (
    <div className="space-y-3">
      {isEditable && (
        <div
          className={cn(
            'border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-all',
            isDragging 
              ? 'border-primary bg-primary/5' 
              : 'border-border hover:border-primary/50 hover:bg-muted/30'
          )}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => handleFileSelect(e.target.files)}
          />
          <Upload className="h-6 w-6 mx-auto text-muted-foreground mb-2" />
          <p className="text-sm text-muted-foreground">
            Drag & drop files here or click to browse
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Max {maxSizeMB}MB per file • Up to {maxFiles} files
          </p>
        </div>
      )}

      {stageAttachments.length > 0 && (
        <div className="space-y-2">
          {stageAttachments.map((attachment) => {
            const FileIcon = getFileIcon(attachment.fileType);
            const isImage = attachment.fileType.startsWith('image/');

            return (
              <div
                key={attachment.id}
                className="flex items-center gap-3 p-3 rounded-lg border border-border bg-secondary/30 group"
              >
                <div className={cn(
                  'w-10 h-10 rounded-lg flex items-center justify-center shrink-0',
                  isImage ? 'bg-accent/20' : 'bg-muted'
                )}>
                  {isImage ? (
                    <img 
                      src={attachment.url} 
                      alt={attachment.fileName}
                      className="w-10 h-10 rounded-lg object-cover"
                    />
                  ) : (
                    <FileIcon className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{attachment.fileName}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatFileSize(attachment.fileSize)} • {attachment.uploadedBy}
                  </p>
                </div>

                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={(e) => {
                      e.stopPropagation();
                      window.open(attachment.url, '_blank');
                    }}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={(e) => {
                      e.stopPropagation();
                      const link = document.createElement('a');
                      link.href = attachment.url;
                      link.download = attachment.fileName;
                      link.click();
                    }}
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                  {isEditable && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-destructive hover:text-destructive"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveAttachment(attachment.id);
                      }}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
