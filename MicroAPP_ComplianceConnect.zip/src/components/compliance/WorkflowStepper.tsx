import { cn } from '@/lib/utils';
import { Check, Circle, Clock, AlertCircle } from 'lucide-react';
import { IssueStatus } from '@/types/compliance';

interface WorkflowStep {
  id: IssueStatus;
  label: string;
}

const steps: WorkflowStep[] = [
  { id: 'reported', label: 'Reported' },
  { id: 'in_progress', label: 'In Progress' },
  { id: 'qa_review', label: 'QA Review' },
  { id: 'completed', label: 'Completed' },
];

interface WorkflowStepperProps {
  currentStatus: IssueStatus;
  className?: string;
}

export function WorkflowStepper({ currentStatus, className }: WorkflowStepperProps) {
  const currentIndex = steps.findIndex(s => s.id === currentStatus);
  const isRejected = currentStatus === 'rejected';

  return (
    <div className={cn('flex items-center justify-between', className)}>
      {steps.map((step, index) => {
        const isCompleted = index < currentIndex;
        const isCurrent = index === currentIndex;
        
        return (
          <div key={step.id} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center">
              <div 
                className={cn(
                  'w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300',
                  isCompleted && 'bg-success border-success text-success-foreground',
                  isCurrent && !isRejected && 'bg-primary border-primary text-primary-foreground animate-pulse-slow',
                  isCurrent && isRejected && 'bg-destructive border-destructive text-destructive-foreground',
                  !isCompleted && !isCurrent && 'bg-secondary border-border text-muted-foreground'
                )}
              >
                {isCompleted ? (
                  <Check className="h-5 w-5" />
                ) : isCurrent ? (
                  isRejected ? <AlertCircle className="h-5 w-5" /> : <Clock className="h-5 w-5" />
                ) : (
                  <Circle className="h-5 w-5" />
                )}
              </div>
              <span 
                className={cn(
                  'mt-2 text-xs font-medium text-center',
                  (isCompleted || isCurrent) ? 'text-foreground' : 'text-muted-foreground'
                )}
              >
                {step.label}
              </span>
            </div>
            
            {index < steps.length - 1 && (
              <div className="flex-1 h-0.5 mx-3 mt-[-20px]">
                <div 
                  className={cn(
                    'h-full transition-all duration-500',
                    index < currentIndex ? 'bg-success' : 'bg-border'
                  )}
                />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
