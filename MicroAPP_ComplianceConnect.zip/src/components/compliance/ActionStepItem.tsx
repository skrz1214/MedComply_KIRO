import { useState } from 'react';
import { ActionStep, ActionStepStatus, Attachment } from '@/types/compliance';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { AttachmentUploader } from '@/components/compliance/AttachmentUploader';
import { 
  Check, 
  X, 
  Clock, 
  Save, 
  ExternalLink,
  ChevronDown,
  ChevronUp,
  FileText,
  Paperclip
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface ActionStepItemProps {
  step: ActionStep;
  index: number;
  onUpdateStatus: (stepId: string, status: ActionStepStatus, notes?: string, evidence?: string, attachments?: Attachment[]) => void;
  isEditable?: boolean;
}

export function ActionStepItem({ step, index, onUpdateStatus, isEditable = true }: ActionStepItemProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [notes, setNotes] = useState(step.notes || '');
  const [evidence, setEvidence] = useState(step.evidence || '');
  const [stepAttachments, setStepAttachments] = useState<Attachment[]>(step.attachments || []);

  const statusConfig = {
    pending: { label: 'Pending', variant: 'muted' as const, icon: Clock },
    complete: { label: 'Complete', variant: 'success' as const, icon: Check },
    rejected: { label: 'Rejected', variant: 'destructive' as const, icon: X },
    deferred: { label: 'Deferred', variant: 'warning' as const, icon: Clock },
    saved: { label: 'Saved', variant: 'info' as const, icon: Save },
  };

  const config = statusConfig[step.status];
  const StatusIcon = config.icon;

  const handleStatusChange = (newStatus: ActionStepStatus) => {
    onUpdateStatus(step.id, newStatus, notes, evidence, stepAttachments);
  };

  const handleAttachmentsChange = (newAttachments: Attachment[]) => {
    setStepAttachments(newAttachments);
  };

  return (
    <div 
      className={cn(
        'rounded-lg border transition-all duration-200',
        step.status === 'complete' && 'border-success/30 bg-success/5',
        step.status === 'rejected' && 'border-destructive/30 bg-destructive/5',
        step.status === 'deferred' && 'border-warning/30 bg-warning/5',
        step.status === 'pending' && 'border-border bg-card',
        step.status === 'saved' && 'border-info/30 bg-info/5'
      )}
    >
      <div 
        className="flex items-start gap-4 p-4 cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div 
          className={cn(
            'w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold shrink-0',
            step.status === 'complete' && 'bg-success text-success-foreground',
            step.status === 'rejected' && 'bg-destructive text-destructive-foreground',
            step.status === 'deferred' && 'bg-warning text-warning-foreground',
            step.status === 'pending' && 'bg-secondary text-secondary-foreground',
            step.status === 'saved' && 'bg-info text-info-foreground'
          )}
        >
          {step.status === 'complete' ? <Check className="h-4 w-4" /> : index + 1}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className={cn(
                'font-medium',
                step.status === 'complete' && 'line-through text-muted-foreground'
              )}>
                {step.description}
              </p>
              <div className="flex items-center gap-2 mt-1">
                {step.isCustom && (
                  <span className="text-xs text-muted-foreground">Custom step</span>
                )}
                {stepAttachments.length > 0 && (
                  <span className="text-xs text-primary flex items-center gap-1">
                    <Paperclip className="h-3 w-3" />
                    {stepAttachments.length} file(s)
                  </span>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <Badge variant={config.variant} className="gap-1">
                <StatusIcon className="h-3 w-3" />
                {config.label}
              </Badge>
              {isExpanded ? (
                <ChevronUp className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              )}
            </div>
          </div>

          {step.sourceUrl && (
            <a 
              href={step.sourceUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="inline-flex items-center gap-1 text-xs text-primary hover:underline mt-1"
            >
              <ExternalLink className="h-3 w-3" />
              Reference Documentation
            </a>
          )}
        </div>
      </div>

      {isExpanded && (
        <div className="px-4 pb-4 pt-2 border-t border-border/50 space-y-4 animate-fade-in">
          {isEditable && (
            <>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Evidence</label>
                <Textarea 
                  placeholder="Add evidence or documentation references..."
                  value={evidence}
                  onChange={(e) => setEvidence(e.target.value)}
                  className="min-h-[80px] resize-none"
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-1.5 block">Notes</label>
                <Textarea 
                  placeholder="Add notes about this action step..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="min-h-[80px] resize-none"
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-1.5 block flex items-center gap-2">
                  <Paperclip className="h-4 w-4" />
                  Step Attachments
                </label>
                <AttachmentUploader
                  attachments={stepAttachments}
                  onAttachmentsChange={handleAttachmentsChange}
                  stage="in_progress"
                  uploadedBy="Current User"
                  isEditable={true}
                  maxFiles={5}
                />
              </div>

              <div className="flex flex-wrap gap-2 pt-2">
                <Button 
                  size="sm" 
                  variant="success"
                  onClick={() => handleStatusChange('complete')}
                  disabled={step.status === 'complete'}
                >
                  <Check className="h-4 w-4 mr-1" />
                  Complete
                </Button>
                <Button 
                  size="sm" 
                  variant="destructive"
                  onClick={() => handleStatusChange('rejected')}
                  disabled={step.status === 'rejected'}
                >
                  <X className="h-4 w-4 mr-1" />
                  Reject
                </Button>
                <Button 
                  size="sm" 
                  variant="warning"
                  onClick={() => handleStatusChange('deferred')}
                  disabled={step.status === 'deferred'}
                >
                  <Clock className="h-4 w-4 mr-1" />
                  Defer
                </Button>
                <Button 
                  size="sm" 
                  variant="secondary"
                  onClick={() => handleStatusChange('saved')}
                >
                  <Save className="h-4 w-4 mr-1" />
                  Save Progress
                </Button>
              </div>
            </>
          )}

          {!isEditable && (step.notes || step.evidence || stepAttachments.length > 0) && (
            <div className="space-y-3">
              {step.evidence && (
                <div>
                  <label className="text-sm font-medium text-muted-foreground mb-1 block flex items-center gap-1">
                    <FileText className="h-3 w-3" />
                    Evidence
                  </label>
                  <p className="text-sm bg-secondary/50 rounded-md p-3">{step.evidence}</p>
                </div>
              )}
              {step.notes && (
                <div>
                  <label className="text-sm font-medium text-muted-foreground mb-1 block">Notes</label>
                  <p className="text-sm bg-secondary/50 rounded-md p-3">{step.notes}</p>
                </div>
              )}
              {stepAttachments.length > 0 && (
                <div>
                  <label className="text-sm font-medium text-muted-foreground mb-1 block flex items-center gap-1">
                    <Paperclip className="h-3 w-3" />
                    Attachments
                  </label>
                  <AttachmentUploader
                    attachments={stepAttachments}
                    onAttachmentsChange={() => {}}
                    stage="in_progress"
                    uploadedBy=""
                    isEditable={false}
                  />
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
