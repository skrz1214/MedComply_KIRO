import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';

export function ComplianceLayout() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar />
      <main className="ml-56 transition-all duration-300">
        <Outlet />
      </main>
    </div>
  );
}
