import { useState } from 'react';
import { Attachment, WorkflowStage } from '@/types/compliance';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Paperclip, 
  ChevronDown, 
  ChevronUp,
  FileText,
  Image,
  File,
  Download,
  Eye,
  Calendar,
  User
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

interface StageAttachmentsViewProps {
  attachments: Attachment[];
  currentStage?: WorkflowStage;
}

const stageConfig: Record<WorkflowStage, { label: string; color: string }> = {
  reported: { label: 'Initial Report', color: 'bg-info/10 text-info border-info/30' },
  initiation: { label: 'Initiation', color: 'bg-accent/10 text-accent border-accent/30' },
  in_progress: { label: 'Work in Progress', color: 'bg-warning/10 text-warning border-warning/30' },
  qa_review: { label: 'QA Review', color: 'bg-primary/10 text-primary border-primary/30' },
  completed: { label: 'Completed', color: 'bg-success/10 text-success border-success/30' },
};

const stageOrder: WorkflowStage[] = ['reported', 'initiation', 'in_progress', 'qa_review', 'completed'];

export function StageAttachmentsView({ attachments, currentStage }: StageAttachmentsViewProps) {
  const [expandedStages, setExpandedStages] = useState<Set<WorkflowStage>>(
    new Set(currentStage ? [currentStage] : ['reported'])
  );

  const toggleStage = (stage: WorkflowStage) => {
    const newExpanded = new Set(expandedStages);
    if (newExpanded.has(stage)) {
      newExpanded.delete(stage);
    } else {
      newExpanded.add(stage);
    }
    setExpandedStages(newExpanded);
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) return Image;
    if (fileType.includes('pdf') || fileType.includes('document')) return FileText;
    return File;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  // Group attachments by stage
  const attachmentsByStage = stageOrder.reduce((acc, stage) => {
    acc[stage] = attachments.filter(a => a.stage === stage);
    return acc;
  }, {} as Record<WorkflowStage, Attachment[]>);

  const stagesWithAttachments = stageOrder.filter(stage => attachmentsByStage[stage].length > 0);

  if (attachments.length === 0) {
    return (
      <div className="text-center py-6 text-muted-foreground">
        <Paperclip className="h-8 w-8 mx-auto mb-2 opacity-50" />
        <p className="text-sm">No attachments yet</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {stageOrder.map((stage) => {
        const stageAttachments = attachmentsByStage[stage];
        if (stageAttachments.length === 0) return null;

        const config = stageConfig[stage];
        const isExpanded = expandedStages.has(stage);
        const isCurrent = stage === currentStage;

        return (
          <div 
            key={stage}
            className={cn(
              'rounded-lg border transition-all',
              isCurrent ? 'border-primary/50 bg-primary/5' : 'border-border bg-card'
            )}
          >
            <button
              className="w-full flex items-center justify-between p-3 text-left"
              onClick={() => toggleStage(stage)}
            >
              <div className="flex items-center gap-3">
                <Badge variant="outline" className={cn('text-xs', config.color)}>
                  {config.label}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {stageAttachments.length} file{stageAttachments.length !== 1 ? 's' : ''}
                </span>
                {isCurrent && (
                  <Badge variant="secondary" className="text-xs">Current Stage</Badge>
                )}
              </div>
              {isExpanded ? (
                <ChevronUp className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              )}
            </button>

            {isExpanded && (
              <div className="px-3 pb-3 space-y-2 animate-fade-in">
                {stageAttachments.map((attachment) => {
                  const FileIcon = getFileIcon(attachment.fileType);
                  const isImage = attachment.fileType.startsWith('image/');

                  return (
                    <div
                      key={attachment.id}
                      className="flex items-center gap-3 p-3 rounded-lg border border-border bg-secondary/20 group"
                    >
                      <div className={cn(
                        'w-12 h-12 rounded-lg flex items-center justify-center shrink-0 overflow-hidden',
                        isImage ? 'bg-transparent' : 'bg-muted'
                      )}>
                        {isImage ? (
                          <img 
                            src={attachment.url} 
                            alt={attachment.fileName}
                            className="w-12 h-12 rounded-lg object-cover"
                          />
                        ) : (
                          <FileIcon className="h-6 w-6 text-muted-foreground" />
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{attachment.fileName}</p>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                          <span>{formatFileSize(attachment.fileSize)}</span>
                          <span className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            {attachment.uploadedBy}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {format(new Date(attachment.uploadedAt), 'MMM d, h:mm a')}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => window.open(attachment.url, '_blank')}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = attachment.url;
                            link.download = attachment.fileName;
                            link.click();
                          }}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
