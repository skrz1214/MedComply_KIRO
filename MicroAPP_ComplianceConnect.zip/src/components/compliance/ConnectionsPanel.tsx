import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/hooks/use-toast';
import { 
  CrossReference, 
  MicroappType, 
  CrossReferenceItemType,
  microappConfigs,
  mockCrossReferences 
} from '@/types/crossReference';
import { 
  Link2, 
  Plus, 
  ExternalLink, 
  Trash2, 
  Shield, 
  FileSearch, 
  MessageSquare, 
  Scale,
  ClipboardList,
  BookOpen,
  Target,
  X
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface ConnectionsPanelProps {
  sourceType: MicroappType;
  sourceId: string;
  className?: string;
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Shield,
  FileSearch,
  MessageSquare,
  Scale,
  ClipboardList,
  BookOpen,
  Target,
};

const itemTypeLabels: Record<CrossReferenceItemType, string> = {
  risk_assessment: 'Risk Assessment',
  risk_register: 'Risk Register',
  audit_finding: 'Audit Finding',
  audit_report: 'Audit Report',
  feedback_item: 'Feedback Item',
  complaint: 'Complaint',
  enforcement_action: 'Enforcement Action',
  investigation: 'Investigation',
  issue: 'Issue',
  citation: 'Citation',
  capa: 'CAPA',
};

export function ConnectionsPanel({ sourceType, sourceId, className }: ConnectionsPanelProps) {
  const [connections, setConnections] = useState<CrossReference[]>(
    mockCrossReferences.filter(ref => ref.sourceId === sourceId)
  );
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [selectedMicroapp, setSelectedMicroapp] = useState<MicroappType | ''>('');
  const [selectedItemType, setSelectedItemType] = useState<CrossReferenceItemType | ''>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItem, setSelectedItem] = useState<{id: string; title: string} | null>(null);
  const [linkNotes, setLinkNotes] = useState('');

  // Group connections by microapp
  const groupedConnections = connections.reduce((acc, conn) => {
    if (!acc[conn.targetType]) {
      acc[conn.targetType] = [];
    }
    acc[conn.targetType].push(conn);
    return acc;
  }, {} as Record<MicroappType, CrossReference[]>);

  const getIcon = (iconName: string) => {
    const IconComponent = iconMap[iconName];
    return IconComponent ? <IconComponent className="h-4 w-4" /> : null;
  };

  const getMicroappConfig = (type: MicroappType) => {
    return microappConfigs.find(m => m.id === type);
  };

  const handleAddConnection = () => {
    if (!selectedMicroapp || !selectedItemType || !selectedItem) {
      toast({
        title: 'Missing Information',
        description: 'Please select a microapp, item type, and item to link.',
        variant: 'destructive'
      });
      return;
    }

    const newConnection: CrossReference = {
      id: `xref-${Date.now()}`,
      sourceType,
      sourceId,
      targetType: selectedMicroapp,
      targetId: selectedItem.id,
      targetItemType: selectedItemType,
      targetTitle: selectedItem.title,
      targetStatus: 'active',
      linkedBy: 'Current User',
      linkedAt: new Date(),
      notes: linkNotes || undefined
    };

    setConnections(prev => [...prev, newConnection]);
    
    toast({
      title: 'Connection Added',
      description: `Linked to ${selectedItem.title}`,
    });

    // Reset form
    setShowAddDialog(false);
    setSelectedMicroapp('');
    setSelectedItemType('');
    setSearchQuery('');
    setSelectedItem(null);
    setLinkNotes('');
  };

  const handleRemoveConnection = (connectionId: string) => {
    setConnections(prev => prev.filter(c => c.id !== connectionId));
    toast({
      title: 'Connection Removed',
      description: 'The cross-reference has been removed.',
    });
  };

  // Mock search results based on selected microapp
  const mockSearchResults = selectedMicroapp && searchQuery.length > 0 ? [
    { id: `${selectedMicroapp.toUpperCase()}-001`, title: `${searchQuery} - Sample Item 1` },
    { id: `${selectedMicroapp.toUpperCase()}-002`, title: `${searchQuery} - Sample Item 2` },
    { id: `${selectedMicroapp.toUpperCase()}-003`, title: `${searchQuery} - Related Finding` },
  ] : [];

  const availableItemTypes = selectedMicroapp 
    ? getMicroappConfig(selectedMicroapp)?.itemTypes || []
    : [];

  return (
    <div className={cn("rounded-xl border border-border bg-card p-4 shadow-soft", className)}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Link2 className="h-5 w-5 text-primary" />
          <h3 className="font-semibold">Cross-References</h3>
          <Badge variant="secondary" className="text-xs">
            {connections.length}
          </Badge>
        </div>
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => setShowAddDialog(true)}
        >
          <Plus className="h-4 w-4 mr-1" />
          Link
        </Button>
      </div>

      {connections.length === 0 ? (
        <div className="text-center py-6 text-muted-foreground">
          <Link2 className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">No cross-references yet</p>
          <p className="text-xs">Link items from other microapps</p>
        </div>
      ) : (
        <div className="space-y-4">
          {Object.entries(groupedConnections).map(([microappType, refs]) => {
            const config = getMicroappConfig(microappType as MicroappType);
            if (!config) return null;

            return (
              <div key={microappType} className="space-y-2">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <div 
                    className="p-1 rounded"
                    style={{ backgroundColor: `${config.color}20` }}
                  >
                    {getIcon(config.icon)}
                  </div>
                  <span>{config.name}</span>
                  <span className="text-muted-foreground">({refs.length})</span>
                </div>
                
                <div className="space-y-2 pl-7">
                  {refs.map(ref => (
                    <div 
                      key={ref.id}
                      className="group flex items-start justify-between p-2 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground font-mono">
                            {ref.targetId}
                          </span>
                          {ref.targetStatus && (
                            <Badge 
                              variant="outline" 
                              className="text-xs capitalize"
                            >
                              {ref.targetStatus.replace('_', ' ')}
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm font-medium truncate mt-0.5">
                          {ref.targetTitle}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {itemTypeLabels[ref.targetItemType]} • Linked by {ref.linkedBy} on {format(new Date(ref.linkedAt), 'MMM d, yyyy')}
                        </p>
                        {ref.notes && (
                          <p className="text-xs text-muted-foreground mt-1 italic">
                            "{ref.notes}"
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => toast({ title: 'Opening...', description: `Navigate to ${ref.targetId}` })}
                        >
                          <ExternalLink className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive hover:text-destructive"
                          onClick={() => handleRemoveConnection(ref.id)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Connection Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add Cross-Reference</DialogTitle>
            <DialogDescription>
              Link this item to related items in other microapps for traceability.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            {/* Microapp Selection */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Select Microapp</label>
              <div className="grid grid-cols-2 gap-2">
                {microappConfigs
                  .filter(m => m.id !== sourceType)
                  .map(config => (
                    <button
                      key={config.id}
                      onClick={() => {
                        setSelectedMicroapp(config.id);
                        setSelectedItemType('');
                        setSelectedItem(null);
                      }}
                      className={cn(
                        "flex items-center gap-2 p-3 rounded-lg border transition-all text-left",
                        selectedMicroapp === config.id
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/50"
                      )}
                    >
                      <div 
                        className="p-1.5 rounded"
                        style={{ backgroundColor: `${config.color}20` }}
                      >
                        {getIcon(config.icon)}
                      </div>
                      <span className="text-sm font-medium">{config.name}</span>
                    </button>
                  ))}
              </div>
            </div>

            {/* Item Type Selection */}
            {selectedMicroapp && (
              <div className="space-y-2">
                <label className="text-sm font-medium">Item Type</label>
                <Select 
                  value={selectedItemType} 
                  onValueChange={(value) => setSelectedItemType(value as CrossReferenceItemType)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select item type..." />
                  </SelectTrigger>
                  <SelectContent>
                    {availableItemTypes.map(type => (
                      <SelectItem key={type} value={type}>
                        {itemTypeLabels[type]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Search and Select Item */}
            {selectedItemType && (
              <div className="space-y-2">
                <label className="text-sm font-medium">Search & Select Item</label>
                <Input
                  placeholder="Search by ID or title..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setSelectedItem(null);
                  }}
                />
                
                {searchQuery && mockSearchResults.length > 0 && !selectedItem && (
                  <div className="border rounded-lg max-h-40 overflow-y-auto">
                    {mockSearchResults.map(item => (
                      <button
                        key={item.id}
                        onClick={() => {
                          setSelectedItem(item);
                          setSearchQuery(item.title);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-muted transition-colors border-b last:border-b-0"
                      >
                        <span className="text-xs text-muted-foreground font-mono">{item.id}</span>
                        <p className="text-sm">{item.title}</p>
                      </button>
                    ))}
                  </div>
                )}

                {selectedItem && (
                  <div className="flex items-center gap-2 p-2 rounded-lg bg-primary/5 border border-primary/20">
                    <div className="flex-1">
                      <span className="text-xs text-muted-foreground font-mono">{selectedItem.id}</span>
                      <p className="text-sm font-medium">{selectedItem.title}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => {
                        setSelectedItem(null);
                        setSearchQuery('');
                      }}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            )}

            {/* Notes */}
            {selectedItem && (
              <div className="space-y-2">
                <label className="text-sm font-medium">Notes (Optional)</label>
                <Textarea
                  placeholder="Add context about this connection..."
                  value={linkNotes}
                  onChange={(e) => setLinkNotes(e.target.value)}
                  rows={2}
                />
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleAddConnection}
              disabled={!selectedItem}
            >
              <Link2 className="h-4 w-4 mr-2" />
              Add Connection
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
