import { ReportDefinition, ReportRow, ReportMetric, ExportHistoryEntry, SavedReportView } from '@/types/reports';

// Report Definitions
export const reportDefinitions: ReportDefinition[] = [
  // EXECUTIVE
  {
    id: 'executive-overview',
    title: 'Executive Compliance Overview',
    description: 'High-level KPIs across Issues, CAPAs, and Citation Cases with at-risk work items.',
    domain: 'executive',
    icon: 'LayoutDashboard',
    metrics: [],
    columns: [
      { id: 'type', label: 'Type', sortable: true },
      { id: 'id', label: 'ID', sortable: true },
      { id: 'title', label: 'Title', sortable: true },
      { id: 'severity', label: 'Severity', sortable: true },
      { id: 'department', label: 'Department', sortable: true },
      { id: 'owner', label: 'Owner', sortable: true },
      { id: 'dueDate', label: 'Due Date', sortable: true },
      { id: 'daysOverdue', label: 'Days Overdue', sortable: true },
      { id: 'status', label: 'Status', sortable: true },
    ],
    filters: [
      { id: 'dateRange', label: 'Date Range', type: 'date-range' },
      { id: 'facility', label: 'Facility', type: 'select', options: [] },
      { id: 'department', label: 'Department', type: 'multi-select', options: [] },
      { id: 'overdueOnly', label: 'Overdue Only', type: 'toggle' },
    ],
    drillDownType: undefined,
  },
  // ISSUES
  {
    id: 'issues-inventory',
    title: 'Issues Inventory Report',
    description: 'Complete inventory of compliance issues with status, ownership, and evidence tracking.',
    domain: 'issues',
    icon: 'FileText',
    metrics: [],
    columns: [
      { id: 'issueId', label: 'Issue ID', sortable: true },
      { id: 'title', label: 'Title', sortable: true },
      { id: 'stage', label: 'Stage', sortable: true },
      { id: 'priority', label: 'Priority', sortable: true },
      { id: 'department', label: 'Department', sortable: true },
      { id: 'owner', label: 'Owner', sortable: true },
      { id: 'created', label: 'Created', sortable: true },
      { id: 'lastUpdated', label: 'Last Updated', sortable: true },
      { id: 'actionSteps', label: 'Actions Done/Total', sortable: true },
      { id: 'evidenceCount', label: 'Evidence', sortable: true },
      { id: 'monitoringDest', label: 'Monitoring', sortable: true },
    ],
    filters: [
      { id: 'dateRangeType', label: 'Date Type', type: 'select', options: [{ value: 'created', label: 'Created' }, { value: 'updated', label: 'Updated' }, { value: 'closed', label: 'Closed' }] },
      { id: 'dateRange', label: 'Date Range', type: 'date-range' },
      { id: 'stage', label: 'Stage', type: 'multi-select', options: [] },
      { id: 'priority', label: 'Priority', type: 'multi-select', options: [] },
      { id: 'department', label: 'Department', type: 'multi-select', options: [] },
      { id: 'owner', label: 'Owner', type: 'typeahead' },
      { id: 'overdueOnly', label: 'Overdue Only', type: 'toggle' },
    ],
    drillDownType: 'issue',
  },
  {
    id: 'issues-aging',
    title: 'Issues Aging & Bottlenecks',
    description: 'Track issue age by stage, identify bottlenecks, and monitor QA return rates.',
    domain: 'issues',
    icon: 'Clock',
    metrics: [],
    columns: [
      { id: 'issueId', label: 'Issue ID', sortable: true },
      { id: 'title', label: 'Title', sortable: true },
      { id: 'currentStage', label: 'Current Stage', sortable: true },
      { id: 'daysInStage', label: 'Days in Stage', sortable: true },
      { id: 'owner', label: 'Owner', sortable: true },
      { id: 'qaReturns', label: 'QA Returns', sortable: true },
      { id: 'overdue', label: 'Overdue', sortable: true },
    ],
    filters: [
      { id: 'stage', label: 'Stage', type: 'multi-select', options: [] },
      { id: 'department', label: 'Department', type: 'multi-select', options: [] },
      { id: 'overdueOnly', label: 'Overdue Only', type: 'toggle' },
    ],
    drillDownType: 'issue',
  },
  {
    id: 'qa-review-outcomes',
    title: 'QA Review Outcomes',
    description: 'QA approval rates, return-for-revision rates, and cycle time analysis.',
    domain: 'issues',
    icon: 'CheckSquare',
    metrics: [],
    columns: [
      { id: 'issueId', label: 'Issue ID', sortable: true },
      { id: 'title', label: 'Title', sortable: true },
      { id: 'qaReviewer', label: 'QA Reviewer', sortable: true },
      { id: 'qaDecision', label: 'QA Decision', sortable: true },
      { id: 'returnCount', label: '# Returns', sortable: true },
      { id: 'qaStartDate', label: 'QA Start', sortable: true },
      { id: 'qaEndDate', label: 'QA End', sortable: true },
      { id: 'notesCount', label: 'Notes', sortable: true },
    ],
    filters: [
      { id: 'dateRange', label: 'Date Range', type: 'date-range' },
      { id: 'qaReviewer', label: 'QA Reviewer', type: 'typeahead' },
      { id: 'qaDecision', label: 'Decision', type: 'multi-select', options: [{ value: 'approved', label: 'Approved' }, { value: 'returned', label: 'Returned' }, { value: 'pending', label: 'Pending' }] },
    ],
    drillDownType: 'issue',
  },
  // CAPA
  {
    id: 'capa-workload',
    title: 'CAPA Workload (NEW/OPEN/CLOSED)',
    description: 'CAPA distribution across workflow buckets with severity and due date tracking.',
    domain: 'capa',
    icon: 'Layers',
    metrics: [],
    columns: [
      { id: 'capaId', label: 'CAPA ID', sortable: true },
      { id: 'title', label: 'Title', sortable: true },
      { id: 'bucket', label: 'Bucket', sortable: true },
      { id: 'status', label: 'Status', sortable: true },
      { id: 'severity', label: 'Severity', sortable: true },
      { id: 'department', label: 'Department', sortable: true },
      { id: 'owner', label: 'Owner', sortable: true },
      { id: 'dueDate', label: 'Due Date', sortable: true },
      { id: 'overdueActions', label: 'Overdue Actions', sortable: true },
      { id: 'verification', label: 'Verification', sortable: true },
      { id: 'effectiveness', label: 'Effectiveness', sortable: true },
    ],
    filters: [
      { id: 'bucket', label: 'Bucket', type: 'multi-select', options: [] },
      { id: 'status', label: 'Status', type: 'multi-select', options: [] },
      { id: 'severity', label: 'Severity', type: 'multi-select', options: [] },
      { id: 'department', label: 'Department', type: 'multi-select', options: [] },
      { id: 'overdueOnly', label: 'Overdue Only', type: 'toggle' },
    ],
    drillDownType: 'capa',
  },
  {
    id: 'capa-overdue-actions',
    title: 'Overdue CAPA Actions',
    description: 'Track all overdue corrective and preventive actions across CAPAs.',
    domain: 'capa',
    icon: 'AlertTriangle',
    metrics: [],
    columns: [
      { id: 'capaId', label: 'CAPA ID', sortable: true },
      { id: 'capaTitle', label: 'CAPA Title', sortable: true },
      { id: 'actionTitle', label: 'Action Title', sortable: true },
      { id: 'actionOwner', label: 'Action Owner', sortable: true },
      { id: 'actionDueDate', label: 'Due Date', sortable: true },
      { id: 'daysOverdue', label: 'Days Overdue', sortable: true },
      { id: 'capaStatus', label: 'CAPA Status', sortable: true },
      { id: 'severity', label: 'Severity', sortable: true },
    ],
    filters: [
      { id: 'department', label: 'Department', type: 'multi-select', options: [] },
      { id: 'severity', label: 'Severity', type: 'multi-select', options: [] },
      { id: 'actionOwner', label: 'Action Owner', type: 'typeahead' },
    ],
    drillDownType: 'capa',
  },
  {
    id: 'capa-cycle-time',
    title: 'CAPA Cycle Time & SLA',
    description: 'Analyze CAPA processing times and SLA compliance rates.',
    domain: 'capa',
    icon: 'Timer',
    metrics: [],
    columns: [
      { id: 'capaId', label: 'CAPA ID', sortable: true },
      { id: 'title', label: 'Title', sortable: true },
      { id: 'origin', label: 'Origin', sortable: true },
      { id: 'severity', label: 'Severity', sortable: true },
      { id: 'department', label: 'Department', sortable: true },
      { id: 'created', label: 'Created', sortable: true },
      { id: 'approved', label: 'Approved', sortable: true },
      { id: 'closed', label: 'Closed', sortable: true },
      { id: 'totalDays', label: 'Total Days', sortable: true },
      { id: 'slaMet', label: 'SLA Met', sortable: true },
    ],
    filters: [
      { id: 'dateRange', label: 'Date Range', type: 'date-range' },
      { id: 'origin', label: 'Origin Type', type: 'multi-select', options: [] },
      { id: 'severity', label: 'Severity', type: 'multi-select', options: [] },
      { id: 'slaMet', label: 'SLA Status', type: 'select', options: [{ value: 'all', label: 'All' }, { value: 'met', label: 'Met' }, { value: 'missed', label: 'Missed' }] },
    ],
    drillDownType: 'capa',
  },
  {
    id: 'capa-verification-effectiveness',
    title: 'Verification & Effectiveness Outcomes',
    description: 'Track verification completion and effectiveness pass/fail rates.',
    domain: 'capa',
    icon: 'CheckCircle',
    metrics: [],
    columns: [
      { id: 'capaId', label: 'CAPA ID', sortable: true },
      { id: 'title', label: 'Title', sortable: true },
      { id: 'status', label: 'Status', sortable: true },
      { id: 'verificationComplete', label: 'Verification Complete', sortable: true },
      { id: 'effectivenessResult', label: 'Effectiveness Result', sortable: true },
      { id: 'monitoringEntries', label: 'Monitoring Entries', sortable: true },
      { id: 'reopened', label: 'Reopened', sortable: true },
    ],
    filters: [
      { id: 'status', label: 'Status', type: 'multi-select', options: [] },
      { id: 'verificationComplete', label: 'Verification', type: 'select', options: [{ value: 'all', label: 'All' }, { value: 'complete', label: 'Complete' }, { value: 'incomplete', label: 'Incomplete' }] },
      { id: 'effectivenessResult', label: 'Effectiveness', type: 'select', options: [{ value: 'all', label: 'All' }, { value: 'pass', label: 'Pass' }, { value: 'fail', label: 'Fail' }, { value: 'pending', label: 'Pending' }] },
    ],
    drillDownType: 'capa',
  },
  // CITATIONS
  {
    id: 'citation-library-coverage',
    title: 'Citation Library Coverage',
    description: 'Citation library completeness: mappings, evidence expectations, and linked work.',
    domain: 'citations',
    icon: 'Library',
    metrics: [],
    columns: [
      { id: 'citationCode', label: 'Citation Code', sortable: true },
      { id: 'title', label: 'Title', sortable: true },
      { id: 'source', label: 'Source', sortable: true },
      { id: 'status', label: 'Status', sortable: true },
      { id: 'version', label: 'Version', sortable: true },
      { id: 'mappingsCount', label: 'Mappings', sortable: true },
      { id: 'evidenceExpCount', label: 'Evidence Exp.', sortable: true },
      { id: 'linkedCases', label: 'Linked Cases', sortable: true },
      { id: 'linkedIssues', label: 'Linked Issues', sortable: true },
      { id: 'linkedCapas', label: 'Linked CAPAs', sortable: true },
    ],
    filters: [
      { id: 'source', label: 'Source', type: 'multi-select', options: [] },
      { id: 'status', label: 'Status', type: 'multi-select', options: [] },
      { id: 'unmapped', label: 'Unmapped Only', type: 'toggle' },
      { id: 'missingEvidence', label: 'Missing Evidence', type: 'toggle' },
    ],
    drillDownType: 'citation',
  },
  {
    id: 'citation-cases-operational',
    title: 'Citation Cases Operational Report',
    description: 'Track open citation cases, PoC/ESC due dates, and verification outcomes.',
    domain: 'citations',
    icon: 'FileCheck',
    metrics: [],
    columns: [
      { id: 'caseId', label: 'Case ID', sortable: true },
      { id: 'citationCode', label: 'Citation Code', sortable: true },
      { id: 'mode', label: 'Mode', sortable: true },
      { id: 'status', label: 'Status', sortable: true },
      { id: 'severity', label: 'Severity', sortable: true },
      { id: 'owner', label: 'Owner', sortable: true },
      { id: 'pocEscDue', label: 'PoC/ESC Due', sortable: true },
      { id: 'verification', label: 'Verification', sortable: true },
      { id: 'linkedIssue', label: 'Linked Issue', sortable: true },
      { id: 'linkedCapa', label: 'Linked CAPA', sortable: true },
    ],
    filters: [
      { id: 'mode', label: 'Mode', type: 'multi-select', options: [] },
      { id: 'status', label: 'Status', type: 'multi-select', options: [] },
      { id: 'overdueOnly', label: 'Overdue Only', type: 'toggle' },
    ],
    drillDownType: 'citation_case',
  },
  {
    id: 'poc-esc-timeliness',
    title: 'PoC / ESC Compliance Timeliness',
    description: 'Track Plan of Correction and ESC submission compliance and timeliness.',
    domain: 'citations',
    icon: 'Calendar',
    metrics: [],
    columns: [
      { id: 'caseId', label: 'Case ID', sortable: true },
      { id: 'facility', label: 'Facility', sortable: true },
      { id: 'mode', label: 'Mode', sortable: true },
      { id: 'receivedDate', label: 'Received/Posted', sortable: true },
      { id: 'dueDate', label: 'Due Date', sortable: true },
      { id: 'submittedDate', label: 'Submitted', sortable: true },
      { id: 'overdue', label: 'Overdue', sortable: true },
      { id: 'acceptanceStatus', label: 'Acceptance', sortable: true },
    ],
    filters: [
      { id: 'mode', label: 'Mode', type: 'multi-select', options: [] },
      { id: 'facility', label: 'Facility', type: 'multi-select', options: [] },
      { id: 'overdueOnly', label: 'Overdue Only', type: 'toggle' },
    ],
    drillDownType: 'citation_case',
  },
  // CROSS-MODULE
  {
    id: 'evidence-coverage-gaps',
    title: 'Evidence Coverage & Gaps',
    description: 'Identify missing evidence across Issues, CAPAs, and Citation Cases.',
    domain: 'cross-module',
    icon: 'Search',
    metrics: [],
    columns: [
      { id: 'type', label: 'Type', sortable: true },
      { id: 'recordId', label: 'Record ID', sortable: true },
      { id: 'title', label: 'Title', sortable: true },
      { id: 'missingEvidence', label: 'Missing Evidence', sortable: true },
      { id: 'department', label: 'Department', sortable: true },
      { id: 'owner', label: 'Owner', sortable: true },
    ],
    filters: [
      { id: 'type', label: 'Record Type', type: 'multi-select', options: [{ value: 'issue', label: 'Issue' }, { value: 'capa', label: 'CAPA' }, { value: 'citation_case', label: 'Citation Case' }] },
      { id: 'department', label: 'Department', type: 'multi-select', options: [] },
    ],
    drillDownType: undefined,
  },
  {
    id: 'repeat-findings',
    title: 'Repeat Findings / Trend Report',
    description: 'Identify citations with highest recurrence and departments with repeat findings.',
    domain: 'cross-module',
    icon: 'TrendingUp',
    metrics: [],
    columns: [
      { id: 'citationCode', label: 'Citation Code', sortable: true },
      { id: 'title', label: 'Title', sortable: true },
      { id: 'casesLast90Days', label: 'Cases (90 days)', sortable: true },
      { id: 'reopens', label: 'Reopens', sortable: true },
      { id: 'avgTimeToClose', label: 'Avg Days to Close', sortable: true },
      { id: 'topDepartments', label: 'Top Departments', sortable: false },
    ],
    filters: [
      { id: 'dateRange', label: 'Date Range', type: 'date-range' },
      { id: 'source', label: 'Source', type: 'multi-select', options: [] },
    ],
    drillDownType: 'citation',
  },
];

// Mock Data Generation
export function generateExecutiveOverviewData(): { metrics: ReportMetric[]; rows: ReportRow[] } {
  return {
    metrics: [
      { id: 'openIssues', label: 'Open Issues', value: 24, change: -3, changeLabel: 'vs last month', color: 'warning' },
      { id: 'qaReview', label: 'Issues in QA Review', value: 8, change: 2, changeLabel: 'vs last week', color: 'default' },
      { id: 'openCapas', label: 'Open CAPAs', value: 12, change: 1, changeLabel: 'vs last month', color: 'warning' },
      { id: 'overdueActions', label: 'Overdue CAPA Actions', value: 5, color: 'danger' },
      { id: 'pocEscDue', label: 'PoC/ESC Due Soon', value: 3, color: 'warning' },
      { id: 'evidenceCoverage', label: 'Evidence Coverage', value: '78%', color: 'success' },
    ],
    rows: [
      { id: '1', type: 'Issue', recordId: 'ISS-2024-042', title: 'Medication documentation gap', severity: 'High', department: 'Nursing', owner: 'Sarah Johnson', dueDate: '2024-12-10', daysOverdue: 7, status: 'In Progress' },
      { id: '2', type: 'CAPA', recordId: 'CAPA-2024-015', title: 'Fall prevention protocol update', severity: 'Critical', department: 'Nursing', owner: 'Michael Chen', dueDate: '2024-12-08', daysOverdue: 9, status: 'In Progress' },
      { id: '3', type: 'Citation Case', recordId: 'CC-2024-008', title: 'F689 - Free of Accidents', severity: 'High', department: 'Environmental Services', owner: 'Lisa Williams', dueDate: '2024-12-15', daysOverdue: 2, status: 'Remediation' },
      { id: '4', type: 'Issue', recordId: 'ISS-2024-038', title: 'Training record incomplete', severity: 'Medium', department: 'Administration', owner: 'David Park', dueDate: '2024-12-12', daysOverdue: 5, status: 'QA Review' },
      { id: '5', type: 'CAPA', recordId: 'CAPA-2024-018', title: 'Infection control audit findings', severity: 'High', department: 'Pharmacy', owner: 'Jennifer Lee', dueDate: '2024-12-14', daysOverdue: 3, status: 'Verification' },
    ],
  };
}

export function generateIssuesInventoryData(): { metrics: ReportMetric[]; rows: ReportRow[] } {
  return {
    metrics: [
      { id: 'totalIssues', label: 'Total Issues', value: 156, color: 'default' },
      { id: 'openIssues', label: 'Open', value: 24, color: 'warning' },
      { id: 'inProgress', label: 'In Progress', value: 18, color: 'default' },
      { id: 'qaReview', label: 'QA Review', value: 8, color: 'default' },
      { id: 'completed', label: 'Completed (30d)', value: 42, color: 'success' },
    ],
    rows: [
      { id: '1', issueId: 'ISS-2024-042', title: 'Medication documentation gap', stage: 'In Progress', priority: 'High', department: 'Nursing', owner: 'Sarah Johnson', created: '2024-11-15', lastUpdated: '2024-12-12', actionSteps: '3/5', evidenceCount: 2, monitoringDest: 'Risk' },
      { id: '2', issueId: 'ISS-2024-041', title: 'Resident assessment delay', stage: 'QA Review', priority: 'Medium', department: 'Nursing', owner: 'Michael Chen', created: '2024-11-18', lastUpdated: '2024-12-14', actionSteps: '4/4', evidenceCount: 5, monitoringDest: 'Compliance' },
      { id: '3', issueId: 'ISS-2024-040', title: 'Fire drill documentation', stage: 'Completed', priority: 'Low', department: 'Environmental Services', owner: 'Lisa Williams', created: '2024-11-10', lastUpdated: '2024-12-10', actionSteps: '3/3', evidenceCount: 3, monitoringDest: '-' },
      { id: '4', issueId: 'ISS-2024-039', title: 'Dietary preference tracking', stage: 'Reported', priority: 'Medium', department: 'Dietary', owner: 'David Park', created: '2024-12-01', lastUpdated: '2024-12-01', actionSteps: '0/3', evidenceCount: 0, monitoringDest: '-' },
      { id: '5', issueId: 'ISS-2024-038', title: 'Training record incomplete', stage: 'QA Review', priority: 'High', department: 'Administration', owner: 'Jennifer Lee', created: '2024-11-20', lastUpdated: '2024-12-13', actionSteps: '5/5', evidenceCount: 4, monitoringDest: 'Audit' },
      { id: '6', issueId: 'ISS-2024-037', title: 'Equipment maintenance log', stage: 'In Progress', priority: 'Low', department: 'Maintenance', owner: 'Robert Taylor', created: '2024-11-22', lastUpdated: '2024-12-11', actionSteps: '2/4', evidenceCount: 1, monitoringDest: '-' },
    ],
  };
}

export function generateIssuesAgingData(): { metrics: ReportMetric[]; rows: ReportRow[] } {
  return {
    metrics: [
      { id: 'avgDaysReported', label: 'Avg Days in Reported', value: 2.3, color: 'success' },
      { id: 'avgDaysInProgress', label: 'Avg Days in Progress', value: 8.5, color: 'warning' },
      { id: 'avgDaysQaReview', label: 'Avg Days in QA', value: 3.2, color: 'default' },
      { id: 'overdueCount', label: 'Overdue Issues', value: 6, color: 'danger' },
    ],
    rows: [
      { id: '1', issueId: 'ISS-2024-033', title: 'Wound care protocol adherence', currentStage: 'In Progress', daysInStage: 21, owner: 'Sarah Johnson', qaReturns: 2, overdue: 'Yes' },
      { id: '2', issueId: 'ISS-2024-035', title: 'Admission paperwork delays', currentStage: 'QA Review', daysInStage: 8, owner: 'Michael Chen', qaReturns: 1, overdue: 'Yes' },
      { id: '3', issueId: 'ISS-2024-036', title: 'Shift change communication', currentStage: 'In Progress', daysInStage: 14, owner: 'Lisa Williams', qaReturns: 0, overdue: 'No' },
      { id: '4', issueId: 'ISS-2024-037', title: 'Equipment maintenance log', currentStage: 'Reported', daysInStage: 5, owner: 'David Park', qaReturns: 0, overdue: 'No' },
    ],
  };
}

export function generateQaReviewOutcomesData(): { metrics: ReportMetric[]; rows: ReportRow[] } {
  return {
    metrics: [
      { id: 'approvalRate', label: 'Approval Rate', value: '72%', color: 'success' },
      { id: 'returnRate', label: 'Return Rate', value: '28%', color: 'warning' },
      { id: 'avgCycleTime', label: 'Avg QA Cycle Time', value: '3.2 days', color: 'default' },
      { id: 'pendingReview', label: 'Pending Review', value: 8, color: 'default' },
    ],
    rows: [
      { id: '1', issueId: 'ISS-2024-041', title: 'Resident assessment delay', qaReviewer: 'Quality Team Lead', qaDecision: 'Approved', returnCount: 1, qaStartDate: '2024-12-10', qaEndDate: '2024-12-14', notesCount: 3 },
      { id: '2', issueId: 'ISS-2024-038', title: 'Training record incomplete', qaReviewer: 'Compliance Manager', qaDecision: 'Pending', returnCount: 0, qaStartDate: '2024-12-13', qaEndDate: '-', notesCount: 1 },
      { id: '3', issueId: 'ISS-2024-035', title: 'Admission paperwork delays', qaReviewer: 'Quality Team Lead', qaDecision: 'Returned', returnCount: 2, qaStartDate: '2024-12-08', qaEndDate: '2024-12-12', notesCount: 4 },
    ],
  };
}

export function generateCapaWorkloadData(): { metrics: ReportMetric[]; rows: ReportRow[] } {
  return {
    metrics: [
      { id: 'newCapas', label: 'NEW', value: 5, color: 'warning' },
      { id: 'openCapas', label: 'OPEN', value: 12, color: 'default' },
      { id: 'closedCapas', label: 'CLOSED (30d)', value: 8, color: 'success' },
      { id: 'overdueActions', label: 'Overdue Actions', value: 7, color: 'danger' },
    ],
    rows: [
      { id: '1', capaId: 'CAPA-2024-015', title: 'Fall prevention protocol update', bucket: 'OPEN', status: 'In Progress', severity: 'Critical', department: 'Nursing', owner: 'Michael Chen', dueDate: '2024-12-20', overdueActions: 2, verification: 'Pending', effectiveness: '-' },
      { id: '2', capaId: 'CAPA-2024-018', title: 'Infection control audit findings', bucket: 'OPEN', status: 'Verification', severity: 'High', department: 'Pharmacy', owner: 'Jennifer Lee', dueDate: '2024-12-25', overdueActions: 0, verification: 'In Progress', effectiveness: '-' },
      { id: '3', capaId: 'CAPA-2024-019', title: 'Medication storage compliance', bucket: 'NEW', status: 'Submitted', severity: 'High', department: 'Pharmacy', owner: 'David Park', dueDate: '2024-12-30', overdueActions: 0, verification: '-', effectiveness: '-' },
      { id: '4', capaId: 'CAPA-2024-012', title: 'Dietary allergen tracking', bucket: 'CLOSED', status: 'Closed', severity: 'Medium', department: 'Dietary', owner: 'Lisa Williams', dueDate: '2024-11-30', overdueActions: 0, verification: 'Complete', effectiveness: 'Pass' },
      { id: '5', capaId: 'CAPA-2024-020', title: 'Emergency evacuation drill gaps', bucket: 'NEW', status: 'Draft', severity: 'Medium', department: 'Environmental Services', owner: 'Robert Taylor', dueDate: '2025-01-05', overdueActions: 0, verification: '-', effectiveness: '-' },
    ],
  };
}

export function generateCapaOverdueActionsData(): { metrics: ReportMetric[]; rows: ReportRow[] } {
  return {
    metrics: [
      { id: 'totalOverdue', label: 'Total Overdue', value: 7, color: 'danger' },
      { id: 'criticalOverdue', label: 'Critical Severity', value: 3, color: 'danger' },
      { id: 'avgDaysOverdue', label: 'Avg Days Overdue', value: 5.2, color: 'warning' },
    ],
    rows: [
      { id: '1', capaId: 'CAPA-2024-015', capaTitle: 'Fall prevention protocol update', actionTitle: 'Update fall risk assessment tool', actionOwner: 'Sarah Johnson', actionDueDate: '2024-12-10', daysOverdue: 7, capaStatus: 'In Progress', severity: 'Critical' },
      { id: '2', capaId: 'CAPA-2024-015', capaTitle: 'Fall prevention protocol update', actionTitle: 'Train nursing staff on new protocol', actionOwner: 'Michael Chen', actionDueDate: '2024-12-12', daysOverdue: 5, capaStatus: 'In Progress', severity: 'Critical' },
      { id: '3', capaId: 'CAPA-2024-016', capaTitle: 'Documentation audit response', actionTitle: 'Review and update charting templates', actionOwner: 'Lisa Williams', actionDueDate: '2024-12-14', daysOverdue: 3, capaStatus: 'In Progress', severity: 'High' },
      { id: '4', capaId: 'CAPA-2024-017', capaTitle: 'Pharmacy inventory control', actionTitle: 'Implement barcode scanning', actionOwner: 'David Park', actionDueDate: '2024-12-15', daysOverdue: 2, capaStatus: 'In Progress', severity: 'Medium' },
    ],
  };
}

export function generateCapaCycleTimeData(): { metrics: ReportMetric[]; rows: ReportRow[] } {
  return {
    metrics: [
      { id: 'avgTimeToApprove', label: 'Avg Time to Approve', value: '4.2 days', color: 'default' },
      { id: 'avgTimeToClose', label: 'Avg Time to Close', value: '28 days', color: 'default' },
      { id: 'slaMetRate', label: 'SLA Met Rate', value: '85%', color: 'success' },
    ],
    rows: [
      { id: '1', capaId: 'CAPA-2024-012', title: 'Dietary allergen tracking', origin: 'Internal Audit', severity: 'Medium', department: 'Dietary', created: '2024-11-01', approved: '2024-11-04', closed: '2024-11-28', totalDays: 27, slaMet: 'Yes' },
      { id: '2', capaId: 'CAPA-2024-011', title: 'Hand hygiene compliance', origin: 'Infection Prevention', severity: 'High', department: 'Nursing', created: '2024-10-15', approved: '2024-10-18', closed: '2024-11-20', totalDays: 36, slaMet: 'No' },
      { id: '3', capaId: 'CAPA-2024-010', title: 'Resident rights training', origin: 'CMS Survey', severity: 'Critical', department: 'Administration', created: '2024-10-01', approved: '2024-10-03', closed: '2024-10-25', totalDays: 24, slaMet: 'Yes' },
    ],
  };
}

export function generateCapaVerificationEffectivenessData(): { metrics: ReportMetric[]; rows: ReportRow[] } {
  return {
    metrics: [
      { id: 'verificationRate', label: 'Verification Complete', value: '68%', color: 'default' },
      { id: 'effectivenessPass', label: 'Effectiveness Pass Rate', value: '91%', color: 'success' },
      { id: 'reopenRate', label: 'Reopen Rate', value: '9%', color: 'warning' },
    ],
    rows: [
      { id: '1', capaId: 'CAPA-2024-012', title: 'Dietary allergen tracking', status: 'Closed', verificationComplete: 'Yes', effectivenessResult: 'Pass', monitoringEntries: 4, reopened: 'No' },
      { id: '2', capaId: 'CAPA-2024-018', title: 'Infection control audit findings', status: 'Verification', verificationComplete: 'In Progress', effectivenessResult: '-', monitoringEntries: 0, reopened: 'No' },
      { id: '3', capaId: 'CAPA-2024-009', title: 'Medication error reduction', status: 'Effectiveness Monitoring', verificationComplete: 'Yes', effectivenessResult: 'Pending', monitoringEntries: 2, reopened: 'No' },
      { id: '4', capaId: 'CAPA-2024-008', title: 'Pressure ulcer prevention', status: 'Reopened', verificationComplete: 'Yes', effectivenessResult: 'Fail', monitoringEntries: 3, reopened: 'Yes' },
    ],
  };
}

export function generateCitationLibraryCoverageData(): { metrics: ReportMetric[]; rows: ReportRow[] } {
  return {
    metrics: [
      { id: 'totalCitations', label: 'Total Citations', value: 245, color: 'default' },
      { id: 'withMappings', label: 'With Mappings', value: '82%', color: 'success' },
      { id: 'withEvidence', label: 'With Evidence Exp.', value: '74%', color: 'warning' },
      { id: 'deprecated', label: 'Deprecated', value: 18, color: 'default' },
    ],
    rows: [
      { id: '1', citationCode: 'F689', title: 'Free of Accidents', source: 'CMS', status: 'Active', version: '2.1', mappingsCount: 5, evidenceExpCount: 4, linkedCases: 3, linkedIssues: 2, linkedCapas: 1 },
      { id: '2', citationCode: 'F684', title: 'Quality of Care', source: 'CMS', status: 'Active', version: '1.0', mappingsCount: 8, evidenceExpCount: 6, linkedCases: 5, linkedIssues: 4, linkedCapas: 2 },
      { id: '3', citationCode: 'F880', title: 'Infection Prevention', source: 'CMS', status: 'Active', version: '3.0', mappingsCount: 6, evidenceExpCount: 5, linkedCases: 2, linkedIssues: 3, linkedCapas: 1 },
      { id: '4', citationCode: 'EC.02.01', title: 'Environment of Care', source: 'Joint Commission', status: 'Active', version: '1.2', mappingsCount: 4, evidenceExpCount: 3, linkedCases: 1, linkedIssues: 1, linkedCapas: 0 },
      { id: '5', citationCode: 'F656', title: 'Comprehensive Care Plan', source: 'CMS', status: 'Deprecated', version: '1.0', mappingsCount: 0, evidenceExpCount: 0, linkedCases: 0, linkedIssues: 0, linkedCapas: 0 },
    ],
  };
}

export function generateCitationCasesOperationalData(): { metrics: ReportMetric[]; rows: ReportRow[] } {
  return {
    metrics: [
      { id: 'openCases', label: 'Open Cases', value: 8, color: 'warning' },
      { id: 'overduePocEsc', label: 'Overdue PoC/ESC', value: 2, color: 'danger' },
      { id: 'avgTimeToVerify', label: 'Avg Time to Verify', value: '12 days', color: 'default' },
    ],
    rows: [
      { id: '1', caseId: 'CC-2024-008', citationCode: 'F689', mode: 'CMS PoC', status: 'Remediation', severity: 'High', owner: 'Lisa Williams', pocEscDue: '2024-12-20', verification: 'Pending', linkedIssue: 'ISS-2024-042', linkedCapa: 'CAPA-2024-015' },
      { id: '2', caseId: 'CC-2024-007', citationCode: 'F880', mode: 'CMS PoC', status: 'QA Verification', severity: 'Critical', owner: 'Michael Chen', pocEscDue: '2024-12-18', verification: 'In Progress', linkedIssue: '-', linkedCapa: 'CAPA-2024-018' },
      { id: '3', caseId: 'CC-2024-006', citationCode: 'EC.02.01', mode: 'Joint Commission ESC', status: 'Triage', severity: 'Medium', owner: 'Sarah Johnson', pocEscDue: '2025-01-15', verification: '-', linkedIssue: '-', linkedCapa: '-' },
    ],
  };
}

export function generatePocEscTimelinessData(): { metrics: ReportMetric[]; rows: ReportRow[] } {
  return {
    metrics: [
      { id: 'onTimeRate', label: 'On-Time Submission', value: '88%', color: 'success' },
      { id: 'avgDaysToSubmit', label: 'Avg Days to Submit', value: 7.2, color: 'default' },
      { id: 'acceptanceRate', label: 'Acceptance Rate', value: '92%', color: 'success' },
    ],
    rows: [
      { id: '1', caseId: 'CC-2024-005', facility: 'Main Campus', mode: 'CMS PoC', receivedDate: '2024-11-20', dueDate: '2024-11-30', submittedDate: '2024-11-28', overdue: 'No', acceptanceStatus: 'Accepted' },
      { id: '2', caseId: 'CC-2024-004', facility: 'North Wing', mode: 'Joint Commission ESC', receivedDate: '2024-10-15', dueDate: '2024-12-14', submittedDate: '2024-12-10', overdue: 'No', acceptanceStatus: 'Accepted' },
      { id: '3', caseId: 'CC-2024-003', facility: 'Main Campus', mode: 'CMS PoC', receivedDate: '2024-11-01', dueDate: '2024-11-11', submittedDate: '2024-11-13', overdue: 'Yes', acceptanceStatus: 'Returned' },
    ],
  };
}

export function generateEvidenceCoverageGapsData(): { metrics: ReportMetric[]; rows: ReportRow[] } {
  return {
    metrics: [
      { id: 'issuesWithEvidence', label: 'Issues with Evidence', value: '85%', color: 'success' },
      { id: 'capaActionsWithEvidence', label: 'CAPA Actions with Evidence', value: '72%', color: 'warning' },
      { id: 'casesChecklistComplete', label: 'Cases Checklist Complete', value: '68%', color: 'warning' },
    ],
    rows: [
      { id: '1', type: 'Issue', recordId: 'ISS-2024-039', title: 'Dietary preference tracking', missingEvidence: 'Initial documentation, corrective action proof', department: 'Dietary', owner: 'David Park' },
      { id: '2', type: 'CAPA Action', recordId: 'CAPA-2024-015-A3', title: 'Train nursing staff on new protocol', missingEvidence: 'Training attendance roster', department: 'Nursing', owner: 'Michael Chen' },
      { id: '3', type: 'Citation Case', recordId: 'CC-2024-006', title: 'Environment of Care deficiency', missingEvidence: 'Verification checklist items 2, 4, 5', department: 'Environmental Services', owner: 'Sarah Johnson' },
    ],
  };
}

export function generateRepeatFindingsData(): { metrics: ReportMetric[]; rows: ReportRow[] } {
  return {
    metrics: [
      { id: 'topRecurring', label: 'Most Recurring Citation', value: 'F689', color: 'danger' },
      { id: 'repeatRate', label: 'Repeat Finding Rate', value: '18%', color: 'warning' },
      { id: 'avgReopenTime', label: 'Avg Days Before Reopen', value: 45, color: 'default' },
    ],
    rows: [
      { id: '1', citationCode: 'F689', title: 'Free of Accidents', casesLast90Days: 5, reopens: 2, avgTimeToClose: 28, topDepartments: 'Nursing, Environmental Services' },
      { id: '2', citationCode: 'F880', title: 'Infection Prevention', casesLast90Days: 3, reopens: 1, avgTimeToClose: 32, topDepartments: 'Nursing, Pharmacy' },
      { id: '3', citationCode: 'F684', title: 'Quality of Care', casesLast90Days: 4, reopens: 0, avgTimeToClose: 24, topDepartments: 'Nursing' },
    ],
  };
}

// Data fetcher by report ID
export function getReportData(reportId: string): { metrics: ReportMetric[]; rows: ReportRow[] } {
  switch (reportId) {
    case 'executive-overview': return generateExecutiveOverviewData();
    case 'issues-inventory': return generateIssuesInventoryData();
    case 'issues-aging': return generateIssuesAgingData();
    case 'qa-review-outcomes': return generateQaReviewOutcomesData();
    case 'capa-workload': return generateCapaWorkloadData();
    case 'capa-overdue-actions': return generateCapaOverdueActionsData();
    case 'capa-cycle-time': return generateCapaCycleTimeData();
    case 'capa-verification-effectiveness': return generateCapaVerificationEffectivenessData();
    case 'citation-library-coverage': return generateCitationLibraryCoverageData();
    case 'citation-cases-operational': return generateCitationCasesOperationalData();
    case 'poc-esc-timeliness': return generatePocEscTimelinessData();
    case 'evidence-coverage-gaps': return generateEvidenceCoverageGapsData();
    case 'repeat-findings': return generateRepeatFindingsData();
    default: return { metrics: [], rows: [] };
  }
}

// Mock export history
export const mockExportHistory: ExportHistoryEntry[] = [
  { id: '1', reportId: 'executive-overview', reportName: 'Executive Compliance Overview', exportedAt: '2024-12-15T10:30:00Z', exportedBy: 'Admin User', filterSummary: 'All facilities, Last 30 days', rowCount: 45 },
  { id: '2', reportId: 'capa-overdue-actions', reportName: 'Overdue CAPA Actions', exportedAt: '2024-12-14T14:15:00Z', exportedBy: 'Compliance Head', filterSummary: 'Nursing dept, Critical severity', rowCount: 12 },
  { id: '3', reportId: 'issues-inventory', reportName: 'Issues Inventory Report', exportedAt: '2024-12-13T09:45:00Z', exportedBy: 'Department Head', filterSummary: 'Main Campus, Open status', rowCount: 28 },
];

// Mock saved views
export const mockSavedViews: SavedReportView[] = [
  { id: '1', name: 'My Department Issues', reportId: 'issues-inventory', filters: { department: ['nursing'] }, columns: ['issueId', 'title', 'stage', 'priority', 'owner'], createdBy: 'Sarah Johnson', createdAt: '2024-12-01' },
  { id: '2', name: 'Critical CAPAs', reportId: 'capa-workload', filters: { severity: ['critical', 'high'] }, columns: ['capaId', 'title', 'status', 'severity', 'dueDate'], createdBy: 'Michael Chen', createdAt: '2024-12-05' },
];
