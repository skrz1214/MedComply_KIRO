import {
  Facility, Department, User, IssueType, IssueCategory, PriorityLevel,
  RecommendedAction, MonitoringDestination, CapaOriginType, CapaSeveritySLA,
  CapaTemplate, CapaActionType, RCAMethod, ContributingFactor, VerificationType,
  EffectivenessKPI, ClosureReason, CitationSource, Jurisdiction, FacilityType,
  EvidenceType, RiskDomain, AuthorityModeMapping, TimelinessRule, CaseClosureReason,
  AllowedFileType, SensitivityTag, RetentionLabel, NotificationTemplate,
  NotificationRule, EscalationChain, ReportingSettings, IssueWorkflowSettings,
  ConfigAuditEntry
} from '@/types/adminConfig';

// Organization & Access
export const mockFacilities: Facility[] = [
  { id: 'fac-1', name: 'Main Campus Hospital', address: '123 Healthcare Blvd, Suite 100', isActive: true, createdAt: '2024-01-01', updatedAt: '2024-01-01' },
  { id: 'fac-2', name: 'North Wing SNF', address: '456 Care Lane', isActive: true, createdAt: '2024-01-01', updatedAt: '2024-01-01' },
  { id: 'fac-3', name: 'Rehabilitation Center', address: '789 Recovery Road', isActive: true, createdAt: '2024-01-01', updatedAt: '2024-01-01' },
  { id: 'fac-4', name: 'Outpatient Clinic', address: '321 Wellness Ave', isActive: false, createdAt: '2024-01-01', updatedAt: '2024-06-15' },
];

export const mockDepartments: Department[] = [
  { id: 'dept-1', name: 'Nursing', facilityId: 'fac-1', departmentHeadId: 'user-3', isActive: true, createdAt: '2024-01-01', updatedAt: '2024-01-01' },
  { id: 'dept-2', name: 'Pharmacy', facilityId: 'fac-1', departmentHeadId: 'user-4', isActive: true, createdAt: '2024-01-01', updatedAt: '2024-01-01' },
  { id: 'dept-3', name: 'Dietary', facilityId: 'fac-1', isActive: true, createdAt: '2024-01-01', updatedAt: '2024-01-01' },
  { id: 'dept-4', name: 'Environmental Services', facilityId: 'fac-2', isActive: true, createdAt: '2024-01-01', updatedAt: '2024-01-01' },
  { id: 'dept-5', name: 'Infection Prevention', facilityId: 'fac-1', isActive: true, createdAt: '2024-01-01', updatedAt: '2024-01-01' },
];

export const mockUsers: User[] = [
  { id: 'user-1', name: 'Sarah Admin', email: 'sarah.admin@medcomply.com', role: 'Admin', facilityId: 'fac-1', isActive: true, createdAt: '2024-01-01' },
  { id: 'user-2', name: 'Michael Compliance', email: 'michael.compliance@medcomply.com', role: 'Compliance Head', facilityId: 'fac-1', isActive: true, createdAt: '2024-01-01' },
  { id: 'user-3', name: 'Jennifer DeptHead', email: 'jennifer.depthead@medcomply.com', role: 'Department Head', departmentId: 'dept-1', facilityId: 'fac-1', isActive: true, createdAt: '2024-01-01' },
  { id: 'user-4', name: 'David DeptHead', email: 'david.depthead@medcomply.com', role: 'Department Head', departmentId: 'dept-2', facilityId: 'fac-1', isActive: true, createdAt: '2024-01-01' },
  { id: 'user-5', name: 'Emily Staff', email: 'emily.staff@medcomply.com', role: 'Staff', departmentId: 'dept-1', facilityId: 'fac-1', isActive: true, createdAt: '2024-01-01' },
  { id: 'user-6', name: 'Robert Staff', email: 'robert.staff@medcomply.com', role: 'Staff', departmentId: 'dept-2', facilityId: 'fac-2', isActive: false, createdAt: '2024-01-01' },
];

// Compliance Issues Configuration
export const mockIssueTypes: IssueType[] = [
  { id: 'type-1', name: 'Regulatory', description: 'Issues related to regulatory compliance', isActive: true, order: 1 },
  { id: 'type-2', name: 'Safety', description: 'Patient and staff safety concerns', isActive: true, order: 2 },
  { id: 'type-3', name: 'Documentation', description: 'Medical records and documentation issues', isActive: true, order: 3 },
  { id: 'type-4', name: 'Privacy', description: 'HIPAA and patient privacy concerns', isActive: true, order: 4 },
  { id: 'type-5', name: 'Staffing', description: 'Staffing levels and competency issues', isActive: true, order: 5 },
  { id: 'type-6', name: 'Infection Prevention', description: 'Infection control and prevention issues', isActive: true, order: 6 },
  { id: 'type-7', name: 'Dietary', description: 'Dietary and nutrition concerns', isActive: true, order: 7 },
  { id: 'type-8', name: 'Environment', description: 'Environment of care and life safety', isActive: true, order: 8 },
  { id: 'type-9', name: 'Other', description: 'Other compliance issues', isActive: true, order: 9 },
];

export const mockIssueCategories: IssueCategory[] = [
  { id: 'cat-1', typeId: 'type-1', name: 'CMS Deficiency', description: 'CMS survey deficiency', isActive: true, order: 1 },
  { id: 'cat-2', typeId: 'type-1', name: 'State Survey Finding', description: 'State DOH finding', isActive: true, order: 2 },
  { id: 'cat-3', typeId: 'type-2', name: 'Fall Prevention', description: 'Fall risk and prevention', isActive: true, order: 1 },
  { id: 'cat-4', typeId: 'type-2', name: 'Medication Error', description: 'Medication administration errors', isActive: true, order: 2 },
  { id: 'cat-5', typeId: 'type-3', name: 'Missing Documentation', description: 'Required documentation missing', isActive: true, order: 1 },
  { id: 'cat-6', typeId: 'type-3', name: 'Late Entry', description: 'Documentation timing issues', isActive: true, order: 2 },
  { id: 'cat-7', typeId: 'type-4', name: 'PHI Breach', description: 'Protected health information breach', isActive: true, order: 1 },
  { id: 'cat-8', typeId: 'type-6', name: 'Outbreak', description: 'Infection outbreak', isActive: true, order: 1 },
];

export const mockPriorityLevels: PriorityLevel[] = [
  { id: 'pri-1', name: 'Critical', description: 'Immediate attention required. Patient safety at risk.', slaDays: 1, color: 'destructive', order: 1 },
  { id: 'pri-2', name: 'High', description: 'Urgent. Regulatory or significant operational impact.', slaDays: 3, color: 'orange', order: 2 },
  { id: 'pri-3', name: 'Medium', description: 'Standard priority. Address within normal workflow.', slaDays: 7, color: 'yellow', order: 3 },
  { id: 'pri-4', name: 'Low', description: 'Minor issue. Address when resources permit.', slaDays: 14, color: 'green', order: 4 },
];

export const mockRecommendedActions: RecommendedAction[] = [
  { id: 'rec-1', typeId: 'type-1', text: 'Review and update affected policies', defaultOwnerRole: 'Department Head', defaultDueDays: 7, evidenceRequired: true, sourceUrl: 'https://cms.gov/guidance', isActive: true },
  { id: 'rec-2', typeId: 'type-1', text: 'Conduct staff education session', defaultOwnerRole: 'Staff', defaultDueDays: 5, evidenceRequired: true, isActive: true },
  { id: 'rec-3', typeId: 'type-2', categoryId: 'cat-3', text: 'Implement fall prevention protocol', defaultOwnerRole: 'Staff', defaultDueDays: 3, evidenceRequired: true, isActive: true },
  { id: 'rec-4', typeId: 'type-2', categoryId: 'cat-4', text: 'Review medication administration process', defaultOwnerRole: 'Department Head', defaultDueDays: 5, evidenceRequired: true, isActive: true },
  { id: 'rec-5', typeId: 'type-3', text: 'Complete missing documentation', defaultOwnerRole: 'Staff', defaultDueDays: 2, evidenceRequired: true, isActive: true },
  { id: 'rec-6', typeId: 'type-6', text: 'Implement isolation precautions', defaultOwnerRole: 'Staff', defaultDueDays: 1, evidenceRequired: true, isActive: true },
];

export const mockMonitoringDestinations: MonitoringDestination[] = [
  { id: 'mon-1', name: 'Risk', description: 'Route to Risk Management for ongoing monitoring', isActive: true, order: 1 },
  { id: 'mon-2', name: 'Enforcement', description: 'Route to Enforcement tracking', isActive: true, order: 2 },
  { id: 'mon-3', name: 'Audit', description: 'Route to Internal Audit queue', isActive: true, order: 3 },
  { id: 'mon-4', name: 'Compliance', description: 'Route to Compliance monitoring', isActive: true, order: 4 },
];

export const mockIssueWorkflowSettings: IssueWorkflowSettings = {
  qaReviewRequired: true,
  returnToInProgressAllowed: true,
  completionRequiresEvidence: true,
  closeWithoutCapaReasons: ['Duplicate Issue', 'Not Applicable', 'Resolved by Other Means', 'Accepted Risk'],
};

// CAPA Configuration
export const mockCapaOriginTypes: CapaOriginType[] = [
  { id: 'origin-1', name: 'CMS/State Survey Deficiency (CMS-2567)', description: 'Deficiency from CMS or State survey', isActive: true, order: 1 },
  { id: 'origin-2', name: 'Internal Audit/Mock Survey Finding', description: 'Finding from internal audit', isActive: true, order: 2 },
  { id: 'origin-3', name: 'Resident Incident/Near Miss', description: 'Resident safety incident', isActive: true, order: 3 },
  { id: 'origin-4', name: 'Abuse/Neglect Allegation (internal)', description: 'Internal abuse allegation', isActive: true, order: 4 },
  { id: 'origin-5', name: 'Complaint/Grievance', description: 'Patient or family complaint', isActive: true, order: 5 },
  { id: 'origin-6', name: 'Infection Prevention/Outbreak', description: 'Infection control issue', isActive: true, order: 6 },
  { id: 'origin-7', name: 'Medication Error/Pharmacy', description: 'Medication-related error', isActive: true, order: 7 },
  { id: 'origin-8', name: 'Dietary/Kitchen', description: 'Dietary services issue', isActive: true, order: 8 },
  { id: 'origin-9', name: 'Life Safety/Environment of Care', description: 'Life safety code issue', isActive: true, order: 9 },
  { id: 'origin-10', name: 'Staffing/Competency', description: 'Staffing or training issue', isActive: true, order: 10 },
  { id: 'origin-11', name: 'Documentation/Records', description: 'Documentation deficiency', isActive: true, order: 11 },
  { id: 'origin-12', name: 'Policy/Procedure Gap', description: 'Policy gap identified', isActive: true, order: 12 },
  { id: 'origin-13', name: 'Other', description: 'Other origin type', isActive: true, order: 13 },
];

export const mockCapaSeveritySLAs: CapaSeveritySLA[] = [
  { id: 'sla-1', severity: 'Critical', defaultDueDays: 7, reviewSlaDays: 1, warningThresholdDays: 2 },
  { id: 'sla-2', severity: 'High', defaultDueDays: 14, reviewSlaDays: 2, warningThresholdDays: 3 },
  { id: 'sla-3', severity: 'Medium', defaultDueDays: 30, reviewSlaDays: 5, warningThresholdDays: 5 },
  { id: 'sla-4', severity: 'Low', defaultDueDays: 60, reviewSlaDays: 7, warningThresholdDays: 7 },
];

export const mockCapaTemplates: CapaTemplate[] = [
  {
    id: 'tmpl-1',
    name: 'CMS/State Survey Deficiency (PoC-aligned)',
    description: 'Template for CMS-2567 Plan of Correction requirements',
    requiresContainment: true,
    requiresRCA: true,
    requiresPreventiveActions: true,
    requiresVerification: true,
    requiresEffectivenessMonitoring: true,
    requiresManagementReview: true,
    defaultActionTypes: ['Policy/Procedure Update', 'Training/Competency Validation', 'Audit/Monitoring Implementation'],
    monitoringDurationDays: 90,
    monitoringFrequency: 'Weekly',
    isLTC: true,
    isActive: true,
  },
  {
    id: 'tmpl-2',
    name: 'Joint Commission ESC',
    description: 'Template for Joint Commission Evidence of Standards Compliance',
    requiresContainment: true,
    requiresRCA: true,
    requiresPreventiveActions: true,
    requiresVerification: true,
    requiresEffectivenessMonitoring: true,
    requiresManagementReview: true,
    defaultActionTypes: ['Workflow/Process Change', 'Documentation/Charting Change'],
    monitoringDurationDays: 60,
    monitoringFrequency: 'Bi-weekly',
    isLTC: false,
    isActive: true,
  },
  {
    id: 'tmpl-3',
    name: 'General CAPA',
    description: 'Standard CAPA template for internal findings',
    requiresContainment: false,
    requiresRCA: true,
    requiresPreventiveActions: true,
    requiresVerification: true,
    requiresEffectivenessMonitoring: false,
    requiresManagementReview: false,
    defaultActionTypes: ['Workflow/Process Change'],
    monitoringDurationDays: 30,
    monitoringFrequency: 'Monthly',
    isLTC: false,
    isActive: true,
  },
];

export const mockCapaActionTypes: CapaActionType[] = [
  { id: 'act-1', name: 'Policy/Procedure Update', description: 'Update policies or procedures', isActive: true, order: 1 },
  { id: 'act-2', name: 'Training/Competency Validation', description: 'Staff training or competency check', isActive: true, order: 2 },
  { id: 'act-3', name: 'Workflow/Process Change', description: 'Change to operational workflow', isActive: true, order: 3 },
  { id: 'act-4', name: 'Technology/System Change', description: 'IT or system modification', isActive: true, order: 4 },
  { id: 'act-5', name: 'Staffing/Role Clarification', description: 'Staffing or role adjustment', isActive: true, order: 5 },
  { id: 'act-6', name: 'Audit/Monitoring Implementation', description: 'New audit or monitoring process', isActive: true, order: 6 },
  { id: 'act-7', name: 'Environment/Safety Fix', description: 'Environmental or safety correction', isActive: true, order: 7 },
  { id: 'act-8', name: 'Infection Prevention Control Change', description: 'Infection control update', isActive: true, order: 8 },
  { id: 'act-9', name: 'Medication Management Change', description: 'Medication process change', isActive: true, order: 9 },
  { id: 'act-10', name: 'Dietary/Resident Nutrition Change', description: 'Dietary services change', isActive: true, order: 10 },
  { id: 'act-11', name: 'Documentation/Charting Change', description: 'Documentation practice change', isActive: true, order: 11 },
  { id: 'act-12', name: 'Resident/Family Communication', description: 'Communication improvement', isActive: true, order: 12 },
  { id: 'act-13', name: 'Other', description: 'Other action type', isActive: true, order: 13 },
];

export const mockRCAMethods: RCAMethod[] = [
  { id: 'rca-1', name: '5 Whys', description: 'Iterative questioning to identify root cause', isActive: true, order: 1 },
  { id: 'rca-2', name: 'Fishbone (Ishikawa)', description: 'Cause and effect diagram analysis', isActive: true, order: 2 },
  { id: 'rca-3', name: 'Pareto Analysis', description: '80/20 rule for prioritizing causes', isActive: true, order: 3 },
  { id: 'rca-4', name: 'Fault Tree Analysis', description: 'Top-down deductive failure analysis', isActive: true, order: 4 },
  { id: 'rca-5', name: 'FMEA', description: 'Failure Mode and Effects Analysis', isActive: true, order: 5 },
];

export const mockContributingFactors: ContributingFactor[] = [
  { id: 'cf-1', category: 'People', name: 'Training Gaps', isActive: true },
  { id: 'cf-2', category: 'People', name: 'Staffing Levels', isActive: true },
  { id: 'cf-3', category: 'People', name: 'Communication', isActive: true },
  { id: 'cf-4', category: 'Process', name: 'Unclear Procedures', isActive: true },
  { id: 'cf-5', category: 'Process', name: 'Workflow Bottleneck', isActive: true },
  { id: 'cf-6', category: 'Technology', name: 'System Limitations', isActive: true },
  { id: 'cf-7', category: 'Technology', name: 'Equipment Failure', isActive: true },
  { id: 'cf-8', category: 'Environment', name: 'Physical Layout', isActive: true },
  { id: 'cf-9', category: 'Policy', name: 'Outdated Policy', isActive: true },
];

export const mockVerificationTypes: VerificationType[] = [
  { id: 'ver-1', name: 'Verification', description: 'Confirm action was implemented as planned', isActive: true },
  { id: 'ver-2', name: 'Validation', description: 'Confirm action achieves intended outcome', isActive: true },
  { id: 'ver-3', name: 'Both', description: 'Both verification and validation required', isActive: true },
];

export const mockEffectivenessKPIs: EffectivenessKPI[] = [
  { id: 'kpi-1', name: 'Fall Rate', description: 'Falls per 1000 resident days', unit: 'per 1000 days', isActive: true },
  { id: 'kpi-2', name: 'Pressure Injury Rate', description: 'New pressure injuries per month', unit: 'count/month', isActive: true },
  { id: 'kpi-3', name: 'Medication Error Rate', description: 'Medication errors per 1000 doses', unit: 'per 1000 doses', isActive: true },
  { id: 'kpi-4', name: 'Infection Rate', description: 'Healthcare-associated infections', unit: 'per 1000 days', isActive: true },
  { id: 'kpi-5', name: 'Elopement Incidents', description: 'Elopement attempts or incidents', unit: 'count/month', isActive: true },
  { id: 'kpi-6', name: 'Weight Loss Rate', description: 'Significant weight loss percentage', unit: 'percentage', isActive: true },
];

export const mockClosureReasons: ClosureReason[] = [
  { id: 'close-1', name: 'Effectiveness Confirmed', description: 'Actions verified effective', requiresJustification: false, isActive: true },
  { id: 'close-2', name: 'Superseded by New CAPA', description: 'Replaced by another CAPA', requiresJustification: true, isActive: true },
  { id: 'close-3', name: 'No Longer Applicable', description: 'Conditions have changed', requiresJustification: true, isActive: true },
  { id: 'close-4', name: 'Duplicate', description: 'Duplicate of existing CAPA', requiresJustification: true, isActive: true },
  { id: 'close-5', name: 'Accepted Risk', description: 'Risk accepted by leadership', requiresJustification: true, isActive: true },
];

// Citations Configuration
export const mockCitationSources: CitationSource[] = [
  { id: 'src-1', name: 'CMS', abbreviation: 'CMS', isActive: true, order: 1 },
  { id: 'src-2', name: 'Joint Commission', abbreviation: 'TJC', isActive: true, order: 2 },
  { id: 'src-3', name: 'State DOH', abbreviation: 'State', isActive: true, order: 3 },
  { id: 'src-4', name: 'HIPAA', abbreviation: 'HIPAA', isActive: true, order: 4 },
  { id: 'src-5', name: 'OSHA', abbreviation: 'OSHA', isActive: true, order: 5 },
  { id: 'src-6', name: 'Internal Policy', abbreviation: 'Internal', isActive: true, order: 6 },
  { id: 'src-7', name: 'Other', abbreviation: 'Other', isActive: true, order: 7 },
];

export const mockJurisdictions: Jurisdiction[] = [
  { id: 'jur-1', name: 'Federal', type: 'Federal', isActive: true },
  { id: 'jur-2', name: 'California', type: 'State', isActive: true },
  { id: 'jur-3', name: 'Texas', type: 'State', isActive: true },
  { id: 'jur-4', name: 'Florida', type: 'State', isActive: true },
  { id: 'jur-5', name: 'New York', type: 'State', isActive: true },
];

export const mockFacilityTypes: FacilityType[] = [
  { id: 'ft-1', name: 'Skilled Nursing Facility', abbreviation: 'SNF', isActive: true },
  { id: 'ft-2', name: 'Assisted Living Facility', abbreviation: 'ALF', isActive: true },
  { id: 'ft-3', name: 'Hospital', abbreviation: 'Hosp', isActive: true },
  { id: 'ft-4', name: 'Clinic', abbreviation: 'Clinic', isActive: true },
  { id: 'ft-5', name: 'Other', abbreviation: 'Other', isActive: true },
];

export const mockEvidenceTypes: EvidenceType[] = [
  { id: 'ev-1', name: 'Policy', description: 'Policy document', isActive: true, order: 1 },
  { id: 'ev-2', name: 'Procedure', description: 'Procedure document', isActive: true, order: 2 },
  { id: 'ev-3', name: 'Training Record', description: 'Training completion record', isActive: true, order: 3 },
  { id: 'ev-4', name: 'Audit Result', description: 'Audit or inspection result', isActive: true, order: 4 },
  { id: 'ev-5', name: 'Log', description: 'Activity or monitoring log', isActive: true, order: 5 },
  { id: 'ev-6', name: 'Screenshot', description: 'System screenshot', isActive: true, order: 6 },
  { id: 'ev-7', name: 'Report', description: 'Generated report', isActive: true, order: 7 },
  { id: 'ev-8', name: 'Credentialing', description: 'Credentialing documentation', isActive: true, order: 8 },
  { id: 'ev-9', name: 'Consent', description: 'Consent form', isActive: true, order: 9 },
  { id: 'ev-10', name: 'Other', description: 'Other evidence type', isActive: true, order: 10 },
];

export const mockRiskDomains: RiskDomain[] = [
  { id: 'rd-1', name: 'Patient Safety', description: 'Risks to patient safety', isActive: true, order: 1 },
  { id: 'rd-2', name: 'Documentation', description: 'Medical record risks', isActive: true, order: 2 },
  { id: 'rd-3', name: 'Privacy', description: 'Privacy and data protection', isActive: true, order: 3 },
  { id: 'rd-4', name: 'Regulatory', description: 'Regulatory compliance risks', isActive: true, order: 4 },
  { id: 'rd-5', name: 'Operational', description: 'Operational risks', isActive: true, order: 5 },
  { id: 'rd-6', name: 'Financial', description: 'Financial and billing risks', isActive: true, order: 6 },
  { id: 'rd-7', name: 'Other', description: 'Other risk domains', isActive: true, order: 7 },
];

// Citation Cases Configuration
export const mockAuthorityModeMappings: AuthorityModeMapping[] = [
  { id: 'map-1', authorityType: 'CMS/State Survey', defaultMode: 'PoC', isActive: true },
  { id: 'map-2', authorityType: 'Joint Commission', defaultMode: 'ESC', isActive: true },
  { id: 'map-3', authorityType: 'Internal Audit', defaultMode: 'General', isActive: true },
  { id: 'map-4', authorityType: 'Other', defaultMode: 'General', isActive: true },
];

export const mockTimelinessRules: TimelinessRule[] = [
  { id: 'time-1', mode: 'PoC', dueDays: 10, warningDays: [7, 3, 1], escalationRecipients: ['Compliance Head', 'Admin'] },
  { id: 'time-2', mode: 'ESC', dueDays: 60, warningDays: [14, 7, 3], escalationRecipients: ['Compliance Head', 'Admin'] },
];

export const mockCaseClosureReasons: CaseClosureReason[] = [
  { id: 'ccr-1', name: 'Verified Fixed', requiresOverride: false, isActive: true },
  { id: 'ccr-2', name: 'Not Applicable', requiresOverride: true, isActive: true },
  { id: 'ccr-3', name: 'Duplicate', requiresOverride: true, isActive: true },
  { id: 'ccr-4', name: 'Accepted Risk', requiresOverride: true, isActive: true },
  { id: 'ccr-5', name: 'Referred Out', requiresOverride: true, isActive: true },
];

// Evidence & Attachments
export const mockAllowedFileTypes: AllowedFileType[] = [
  { id: 'file-1', extension: 'pdf', mimeType: 'application/pdf', maxSizeMB: 25, isActive: true },
  { id: 'file-2', extension: 'docx', mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', maxSizeMB: 15, isActive: true },
  { id: 'file-3', extension: 'xlsx', mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', maxSizeMB: 15, isActive: true },
  { id: 'file-4', extension: 'jpg', mimeType: 'image/jpeg', maxSizeMB: 10, isActive: true },
  { id: 'file-5', extension: 'png', mimeType: 'image/png', maxSizeMB: 10, isActive: true },
];

export const mockSensitivityTags: SensitivityTag[] = [
  { id: 'sens-1', name: 'PHI', color: 'destructive', description: 'Protected Health Information', isActive: true },
  { id: 'sens-2', name: 'PII', color: 'orange', description: 'Personally Identifiable Information', isActive: true },
  { id: 'sens-3', name: 'Internal Only', color: 'yellow', description: 'Internal use only', isActive: true },
  { id: 'sens-4', name: 'Public', color: 'green', description: 'Public information', isActive: true },
];

export const mockRetentionLabels: RetentionLabel[] = [
  { id: 'ret-1', name: 'Short', durationMonths: 12, description: '1 year retention' },
  { id: 'ret-2', name: 'Standard', durationMonths: 84, description: '7 year retention (standard medical records)' },
  { id: 'ret-3', name: 'Extended', durationMonths: 120, description: '10 year retention' },
];

// Notifications & Escalations
export const mockNotificationTemplates: NotificationTemplate[] = [
  { id: 'notif-1', name: 'Submitted for Review', triggerEvent: 'submit_for_review', subject: 'New Item Submitted for Review', body: 'A new item has been submitted for your review. Please review at your earliest convenience.', isActive: true },
  { id: 'notif-2', name: 'Changes Requested', triggerEvent: 'changes_requested', subject: 'Changes Requested on Your Submission', body: 'Changes have been requested on your submission. Please review the feedback and resubmit.', isActive: true },
  { id: 'notif-3', name: 'Due Soon', triggerEvent: 'due_soon', subject: 'Reminder: Item Due Soon', body: 'This is a reminder that an item assigned to you is due soon. Please complete the required actions.', isActive: true },
  { id: 'notif-4', name: 'Overdue', triggerEvent: 'overdue', subject: 'Alert: Item Overdue', body: 'An item assigned to you is now overdue. Please take immediate action.', isActive: true },
  { id: 'notif-5', name: 'QA Return', triggerEvent: 'qa_return', subject: 'Item Returned from QA Review', body: 'Your submission has been returned from QA review with comments. Please address and resubmit.', isActive: true },
  { id: 'notif-6', name: 'Closed', triggerEvent: 'closed', subject: 'Item Closed', body: 'An item you were involved with has been closed.', isActive: true },
  { id: 'notif-7', name: 'Reopened', triggerEvent: 'reopened', subject: 'Item Reopened', body: 'A previously closed item has been reopened. Please review.', isActive: true },
];

export const mockNotificationRules: NotificationRule[] = [
  { id: 'rule-1', module: 'Issues', triggerEvent: 'new_issue_reported', recipients: ['Department Head', 'Compliance Head'], isActive: true },
  { id: 'rule-2', module: 'Issues', triggerEvent: 'qa_return', recipients: ['Owner'], isActive: true },
  { id: 'rule-3', module: 'CAPA', triggerEvent: 'submitted', recipients: ['Department Head', 'Compliance Head'], isActive: true },
  { id: 'rule-4', module: 'CAPA', triggerEvent: 'poc_due_reminder', recipients: ['Owner', 'Department Head'], isActive: true },
  { id: 'rule-5', module: 'CAPA', triggerEvent: 'overdue_action', recipients: ['Owner', 'Department Head'], isActive: true },
  { id: 'rule-6', module: 'CitationCases', triggerEvent: 'triage_queue', recipients: ['Compliance Head'], isActive: true },
  { id: 'rule-7', module: 'CitationCases', triggerEvent: 'poc_esc_due_reminder', recipients: ['Owner', 'Compliance Head'], isActive: true },
];

export const mockEscalationChains: EscalationChain[] = [
  { id: 'esc-1', name: 'Standard Escalation', levels: [{ role: 'Department Head', delayHours: 24 }, { role: 'Compliance Head', delayHours: 48 }, { role: 'Admin', delayHours: 72 }] },
  { id: 'esc-2', name: 'Critical Escalation', levels: [{ role: 'Compliance Head', delayHours: 4 }, { role: 'Admin', delayHours: 8 }] },
];

// Reporting Settings
export const mockReportingSettings: ReportingSettings = {
  allowStaffExport: true,
  issueAgingSLADays: 14,
  capaDueSLADays: 30,
  pocEscWarningDays: 3,
  savedViewsRetentionDays: 90,
};

// Audit Log
export const mockConfigAuditLog: ConfigAuditEntry[] = [
  { id: 'audit-1', section: 'Issue Types', action: 'create', itemId: 'type-9', itemName: 'Other', changedBy: 'Sarah Admin', changedAt: '2024-12-01T10:30:00Z', newValue: 'Other (active)' },
  { id: 'audit-2', section: 'Priority Levels', action: 'update', itemId: 'pri-2', itemName: 'High', changedBy: 'Sarah Admin', changedAt: '2024-12-05T14:15:00Z', oldValue: 'SLA: 5 days', newValue: 'SLA: 3 days' },
  { id: 'audit-3', section: 'CAPA Templates', action: 'publish', itemId: 'tmpl-1', itemName: 'CMS/State Survey Deficiency', changedBy: 'Michael Compliance', changedAt: '2024-12-10T09:00:00Z' },
];
