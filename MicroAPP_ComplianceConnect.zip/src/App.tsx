import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import NotFound from "./pages/NotFound";
import { ComplianceLayout } from "./components/compliance/ComplianceLayout";
import Dashboard from "./pages/compliance/Dashboard";
import ReportIssue from "./pages/compliance/ReportIssue";
import IssuesList from "./pages/compliance/IssuesList";
import IssueDetail from "./pages/compliance/IssueDetail";
import TodoList from "./pages/compliance/TodoList";
import ManageRecommendations from "./pages/compliance/ManageRecommendations";
import CitationsList from "./pages/compliance/CitationsList";
import CreateCitation from "./pages/compliance/CreateCitation";
import CitationDetail from "./pages/compliance/CitationDetail";
import CitationCasesList from "./pages/compliance/CitationCasesList";
import ReportCitationCase from "./pages/compliance/ReportCitationCase";
import CitationCaseDetail from "./pages/compliance/CitationCaseDetail";
import ReportsCatalog from "./pages/compliance/ReportsCatalog";
import ReportDetail from "./pages/compliance/ReportDetail";
import ExportHistory from "./pages/compliance/ExportHistory";
import AdminConfiguration from "./pages/compliance/AdminConfiguration";
import PRDViewer from "./pages/compliance/PRDViewer";
import QATestCasesViewer from "./pages/compliance/QATestCasesViewer";
import UATTestCasesViewer from "./pages/compliance/UATTestCasesViewer";
import SystemPromptViewer from "./pages/compliance/SystemPromptViewer";

// ActionGuard Pages
import ActionGuardDashboard from "./pages/actionguard/ActionGuardDashboard";
import ActionGuardList from "./pages/actionguard/ActionGuardList";
import CreateCapa from "./pages/actionguard/CreateCapa";
import EditCapa from "./pages/actionguard/EditCapa";
import CapaDetail from "./pages/actionguard/CapaDetail";
import ActionGuardApprovals from "./pages/actionguard/ActionGuardApprovals";
import ActionGuardMyWork from "./pages/actionguard/ActionGuardMyWork";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<ComplianceLayout />}>
            <Route index element={<Dashboard />} />
            <Route path="report" element={<ReportIssue />} />
            <Route path="issues" element={<IssuesList />} />
            <Route path="issues/:id" element={<IssueDetail />} />
            <Route path="todo" element={<TodoList />} />
            <Route path="recommendations" element={<ManageRecommendations />} />
            <Route path="citations" element={<CitationsList />} />
            <Route path="citations/new" element={<CreateCitation />} />
            <Route path="citations/:id" element={<CitationDetail />} />
            <Route path="citations/cases" element={<CitationCasesList />} />
            <Route path="citations/cases/new" element={<ReportCitationCase />} />
            <Route path="citations/cases/:id" element={<CitationCaseDetail />} />
            
            {/* ActionGuard Routes */}
            <Route path="actionguard" element={<ActionGuardDashboard />} />
            <Route path="actionguard/list" element={<ActionGuardList />} />
            <Route path="actionguard/new" element={<CreateCapa />} />
            <Route path="actionguard/edit/:id" element={<EditCapa />} />
            <Route path="actionguard/:id" element={<CapaDetail />} />
            <Route path="actionguard/approvals" element={<ActionGuardApprovals />} />
            <Route path="actionguard/my-work" element={<ActionGuardMyWork />} />
            
            <Route path="reports" element={<ReportsCatalog />} />
            <Route path="reports/exports" element={<ExportHistory />} />
            <Route path="reports/:reportId" element={<ReportDetail />} />
            <Route path="prd" element={<PRDViewer />} />
            <Route path="qa-tests" element={<QATestCasesViewer />} />
            <Route path="uat-tests" element={<UATTestCasesViewer />} />
            <Route path="system-prompt" element={<SystemPromptViewer />} />
            <Route path="admin" element={<AdminConfiguration />} />
          </Route>
          <Route path="/compliance/*" element={<Navigate to="/" replace />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
