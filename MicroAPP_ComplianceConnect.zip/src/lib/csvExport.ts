import { ReportColumn, ReportRow, ReportExportMetadata } from '@/types/reports';

interface ExportOptions {
  includeHiddenColumns?: boolean;
  includeLinkedIds?: boolean;
}

export function generateCSV(
  rows: ReportRow[],
  columns: ReportColumn[],
  metadata: ReportExportMetadata,
  options: ExportOptions = {}
): string {
  const { includeHiddenColumns = false, includeLinkedIds = true } = options;

  // Filter columns based on visibility
  const visibleColumns = includeHiddenColumns 
    ? columns 
    : columns.filter(col => col.visible !== false);

  // Filter out ID columns if not including linked IDs
  const finalColumns = includeLinkedIds 
    ? visibleColumns 
    : visibleColumns.filter(col => !col.id.toLowerCase().includes('id') || col.id === 'id');

  // Build CSV content
  const lines: string[] = [];

  // Add metadata as comments
  lines.push(`# Report: ${metadata.reportName}`);
  lines.push(`# Exported: ${metadata.exportedAt}`);
  lines.push(`# User Role: ${metadata.userRole}`);
  lines.push(`# Organization: ${metadata.organization}`);
  if (metadata.facility) {
    lines.push(`# Facility: ${metadata.facility}`);
  }
  lines.push(`# Filters: ${metadata.filterSummary}`);
  lines.push('');

  // Add header row
  const headers = finalColumns.map(col => escapeCSVField(col.label));
  lines.push(headers.join(','));

  // Add data rows
  rows.forEach(row => {
    const values = finalColumns.map(col => {
      const value = row[col.id];
      return escapeCSVField(value?.toString() ?? '');
    });
    lines.push(values.join(','));
  });

  return lines.join('\n');
}

function escapeCSVField(field: string): string {
  // If field contains comma, newline, or quote, wrap in quotes and escape quotes
  if (field.includes(',') || field.includes('\n') || field.includes('"')) {
    return `"${field.replace(/"/g, '""')}"`;
  }
  return field;
}

export function downloadCSV(content: string, filename: string): void {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  URL.revokeObjectURL(url);
}

export function generateExportFilename(reportName: string): string {
  const now = new Date();
  const dateStr = now.toISOString().split('T')[0]; // YYYY-MM-DD
  const timeStr = now.toTimeString().slice(0, 5).replace(':', ''); // HHmm
  const sanitizedName = reportName.replace(/[^a-zA-Z0-9]/g, '_');
  
  return `ComplianceConnect_${sanitizedName}_${dateStr}_${timeStr}.csv`;
}

export function generateFilterSummary(filters: Record<string, any>): string {
  const parts: string[] = [];
  
  Object.entries(filters).forEach(([key, value]) => {
    if (value === undefined || value === null || value === '' || (Array.isArray(value) && value.length === 0)) {
      return;
    }
    
    const label = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
    
    if (Array.isArray(value)) {
      parts.push(`${label}: ${value.join(', ')}`);
    } else if (typeof value === 'boolean') {
      if (value) parts.push(label);
    } else {
      parts.push(`${label}: ${value}`);
    }
  });
  
  return parts.length > 0 ? parts.join('; ') : 'No filters applied';
}
