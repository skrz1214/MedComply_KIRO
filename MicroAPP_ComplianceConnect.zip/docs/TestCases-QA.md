# ComplianceConnect QA Test Cases

**Version:** 1.0  
**Last Updated:** December 2024  
**Module Coverage:** Issues, Citations, Citation Cases, ActionGuard (CAPA), Reports, Admin Configuration

---

## Test Case Format

Each test case follows this structure for AI testing tool compatibility:

```
TEST_ID: [Unique identifier]
MODULE: [Module name]
FEATURE: [Feature being tested]
PRIORITY: [P0/P1/P2/P3]
PRECONDITIONS: [Required state before test]
STEPS:
1. [Action step]
2. [Action step]
EXPECTED_RESULT: [Expected outcome]
TEST_DATA: [Sample data if needed]
```

---

# Module A: ComplianceConnect Issues

## A1. Issue Reporting

### A1.1 Create New Issue - Happy Path

```
TEST_ID: QA-ISS-001
MODULE: ComplianceConnect Issues
FEATURE: Issue Creation Wizard
PRIORITY: P0
PRECONDITIONS: User is logged in with Reporter role or higher
STEPS:
1. Navigate to /issues
2. Click "Report Issue" button
3. Step 1 - Enter title: "Medication Documentation Gap"
4. Step 1 - Enter description: "Missing signature on medication administration records for Unit 2A"
5. Step 1 - Select facility: "Main Campus"
6. Step 1 - Select department: "Nursing"
7. Click "Next"
8. Step 2 - Select issue type: "Documentation"
9. Step 2 - Select category: "Medication Administration"
10. Verify recommended actions appear after both type and category are selected
11. Click "Next"
12. Step 3 - Select 2 recommended action steps
13. Step 3 - Add 1 custom action step with description
14. Click "Next"
15. Step 4 - Upload 1 attachment (PDF file)
16. Step 4 - Set due date to 14 days from today
17. Step 4 - Assign to a staff member
18. Click "Submit"
EXPECTED_RESULT: Issue is created with status "Reported", confirmation toast appears, user redirected to issue detail page, all entered data is saved correctly
TEST_DATA: {"title": "Medication Documentation Gap", "description": "Missing signature on medication administration records for Unit 2A", "facility": "Main Campus", "department": "Nursing", "type": "Documentation", "category": "Medication Administration"}
```

### A1.2 Recommendations Only Show After Type AND Category Selection

```
TEST_ID: QA-ISS-002
MODULE: ComplianceConnect Issues
FEATURE: Issue Creation Wizard - Classification Step
PRIORITY: P0
PRECONDITIONS: User is on Step 2 of issue creation wizard
STEPS:
1. Observe the recommended actions section
2. Select only Issue Type: "Documentation"
3. Observe the recommended actions section
4. Select Issue Category: "Medication Administration"
5. Observe the recommended actions section
EXPECTED_RESULT: Recommended actions should NOT appear after selecting only Issue Type. Recommended actions should ONLY appear after BOTH Issue Type AND Category are selected.
TEST_DATA: {}
```

### A1.3 Attachment Restriction in Step 3

```
TEST_ID: QA-ISS-003
MODULE: ComplianceConnect Issues
FEATURE: Issue Creation Wizard - Action Steps
PRIORITY: P1
PRECONDITIONS: User is on Step 3 of issue creation wizard
STEPS:
1. Navigate to Step 3 (Action Steps) of issue creation
2. Attempt to locate any file upload or attachment functionality
3. Verify no attachment upload controls exist on this step
EXPECTED_RESULT: No attachment upload functionality should be available on Step 3. Attachments are only allowed in Step 4 (Assignment step).
TEST_DATA: {}
```

### A1.4 PHI Warning Display

```
TEST_ID: QA-ISS-004
MODULE: ComplianceConnect Issues
FEATURE: PHI-Safe UX Defaults
PRIORITY: P0
PRECONDITIONS: User is on issue creation wizard
STEPS:
1. Navigate to Step 1 of issue creation
2. Locate free text fields (title, description)
3. Verify PHI/PII warning is displayed near text fields
4. Navigate to Step 4 (Assignment)
5. Locate attachment upload section
6. Verify PHI/PII sensitivity warning is displayed near upload
EXPECTED_RESULT: PHI/PII warnings should be visible near all free text fields and attachment upload areas
TEST_DATA: {}
```

## A2. Issue Workflow

### A2.1 Issue Status Transition - Reported to Initiation

```
TEST_ID: QA-ISS-010
MODULE: ComplianceConnect Issues
FEATURE: Issue Workflow
PRIORITY: P0
PRECONDITIONS: Issue exists with status "Reported", user has Department Head role
STEPS:
1. Navigate to issue detail page
2. Click "Start Initiation" in action rail
3. Review issue details
4. Confirm action in dialog
EXPECTED_RESULT: Issue status changes to "Initiation", audit log entry created, stage details updated
TEST_DATA: {"issueId": "ISS-001", "currentStatus": "reported"}
```

### A2.2 Issue Status Transition - In Progress to QA Review

```
TEST_ID: QA-ISS-011
MODULE: ComplianceConnect Issues
FEATURE: Issue Workflow
PRIORITY: P0
PRECONDITIONS: Issue is in "In Progress" status with all required actions marked complete
STEPS:
1. Navigate to issue detail page
2. Verify all action steps are marked as Complete, Rejected, or Deferred
3. Click "Submit for QA Review" in action rail
4. Confirm submission in dialog
EXPECTED_RESULT: Issue status changes to "QA Review", issue routed to QA reviewer, audit log updated
TEST_DATA: {"issueId": "ISS-001", "currentStatus": "in_progress"}
```

### A2.3 QA Review - Route to Monitoring

```
TEST_ID: QA-ISS-012
MODULE: ComplianceConnect Issues
FEATURE: QA Review Routing
PRIORITY: P1
PRECONDITIONS: Issue is in "QA Review" status, user has QA Reviewer role
STEPS:
1. Navigate to issue detail page
2. Review all action steps and evidence
3. Click "Approve, Complete & Route to Monitoring"
4. Select monitoring department: "Risk"
5. Add routing notes
6. Confirm routing
EXPECTED_RESULT: Issue status changes to "Completed", monitoring routing record created for Risk department, audit log updated with routing decision
TEST_DATA: {"issueId": "ISS-001", "monitoringDept": "Risk"}
```

## A3. Issue Detail Page

### A3.1 Tab Navigation

```
TEST_ID: QA-ISS-020
MODULE: ComplianceConnect Issues
FEATURE: Issue Detail Page
PRIORITY: P1
PRECONDITIONS: Issue exists with attachments across multiple stages
STEPS:
1. Navigate to issue detail page
2. Click "Work" tab
3. Verify current stage actions and upload capability displayed
4. Click "Stage Details" tab
5. Verify historical stage information displayed with actors, dates, activities
6. Click "Files" tab
7. Verify all attachments from all stages are aggregated
EXPECTED_RESULT: Each tab displays correct content as specified, tab switching is smooth
TEST_DATA: {"issueId": "ISS-001"}
```

### A3.2 Connections Panel

```
TEST_ID: QA-ISS-021
MODULE: ComplianceConnect Issues
FEATURE: Connections Panel
PRIORITY: P1
PRECONDITIONS: Issue exists without linked records
STEPS:
1. Navigate to issue detail page
2. Locate Connections Panel in right rail
3. Click "Link Citation"
4. Search and select a citation
5. Confirm link
6. Click "Link CAPA"
7. Search and select a CAPA
8. Confirm link
9. Verify both links appear in Connections Panel
EXPECTED_RESULT: Issue successfully linked to Citation and CAPA, connections display in panel, audit log entries created for each link
TEST_DATA: {"issueId": "ISS-001", "citationId": "CIT-001", "capaId": "CAPA-001"}
```

---

# Module B: Citations Library

## B1. Citation Creation

### B1.1 Create Citation - Full Flow

```
TEST_ID: QA-CIT-001
MODULE: Citations Library
FEATURE: Citation Creation Wizard
PRIORITY: P0
PRECONDITIONS: User has Admin or Compliance Head role
STEPS:
1. Navigate to /citations
2. Click "Create Citation"
3. Step 1 - Enter citation code: "F689"
4. Step 1 - Enter title: "Free of Accident Hazards"
5. Step 1 - Select source: "CMS"
6. Step 1 - Select jurisdiction: "Federal"
7. Step 1 - Select facility type: "Skilled Nursing Facility"
8. Click "Next"
9. Step 2 - Enter full citation text (regulatory language)
10. Step 2 - Select risk domain: "Safety"
11. Click "Next"
12. Step 3 - Add evidence expectation: "Fall risk assessment documentation"
13. Step 3 - Add evidence expectation: "Environmental hazard checklist"
14. Step 3 - Add reference URL
15. Click "Next"
16. Step 4 - Assign reviewer (select "Myself")
17. Step 4 - Select department
18. Step 4 - Set status: "Draft"
19. Click "Submit"
EXPECTED_RESULT: Citation created with status "Draft", all fields saved, user redirected to citation detail page
TEST_DATA: {"code": "F689", "title": "Free of Accident Hazards", "source": "CMS", "riskDomain": "Safety"}
```

### B1.2 Mandatory Reviewer Assignment

```
TEST_ID: QA-CIT-002
MODULE: Citations Library
FEATURE: Citation Creation - Reviewer Assignment
PRIORITY: P0
PRECONDITIONS: User is on Step 4 of citation creation
STEPS:
1. Leave reviewer field empty
2. Leave department field empty
3. Attempt to submit citation
EXPECTED_RESULT: Validation error displayed, submission blocked until reviewer and department are assigned
TEST_DATA: {}
```

## B2. Citation Detail CRUD

### B2.1 Add Evidence Expectation

```
TEST_ID: QA-CIT-010
MODULE: Citations Library
FEATURE: Citation Detail - Evidence Expectations
PRIORITY: P1
PRECONDITIONS: Citation exists in Active status
STEPS:
1. Navigate to citation detail page
2. Click "Evidence Expectations" tab
3. Click "Add Evidence Expectation"
4. Enter expectation: "Quarterly environmental rounds documentation"
5. Select evidence type: "Documentation"
6. Click "Save"
EXPECTED_RESULT: Evidence expectation added, displays in list, audit log entry created
TEST_DATA: {"citationId": "CIT-001", "expectation": "Quarterly environmental rounds documentation"}
```

### B2.2 Add Remediation Step

```
TEST_ID: QA-CIT-011
MODULE: Citations Library
FEATURE: Citation Detail - Remediation Steps
PRIORITY: P1
PRECONDITIONS: Citation exists
STEPS:
1. Navigate to citation detail page
2. Click "Remediation Steps" tab
3. Click "Add Remediation Step"
4. Enter step description: "Implement daily environmental safety rounds"
5. Enter source URL: "https://cms.gov/guidance/f689"
6. Click "Save"
EXPECTED_RESULT: Remediation step added with source URL visible, displays in list
TEST_DATA: {"citationId": "CIT-001", "stepDescription": "Implement daily environmental safety rounds"}
```

### B2.3 Citation Status Lifecycle

```
TEST_ID: QA-CIT-012
MODULE: Citations Library
FEATURE: Citation Status Management
PRIORITY: P0
PRECONDITIONS: Citation exists in Draft status
STEPS:
1. Navigate to citation detail page
2. Click "Activate" action
3. Confirm activation
4. Verify status changes to "Active"
5. Click "Deprecate" action
6. Confirm deprecation
7. Verify status changes to "Deprecated"
8. Click "Reactivate" action
9. Confirm reactivation
10. Verify status changes to "Active"
EXPECTED_RESULT: Citation transitions through all lifecycle states correctly, audit log entries created for each transition
TEST_DATA: {"citationId": "CIT-001"}
```

## B3. Citation Library Filters

### B3.1 Combined Filter Application

```
TEST_ID: QA-CIT-020
MODULE: Citations Library
FEATURE: Citation List Filtering
PRIORITY: P1
PRECONDITIONS: Citations exist with various statuses and quality indicators
STEPS:
1. Navigate to /citations
2. Click "Active" status filter chip
3. Verify list shows only Active citations
4. Additionally click "Unmapped" quality filter chip
5. Verify list shows only Active AND Unmapped citations
6. Additionally click "Missing Evidence" quality filter chip
7. Verify list shows Active citations that are either Unmapped OR Missing Evidence
EXPECTED_RESULT: Filters combine correctly, showing intersection of status filter and union of quality indicator filters
TEST_DATA: {}
```

---

# Module C: Citation Cases

## C1. Citation Case Creation

### C1.1 Create Citation Case - CMS Survey Mode

```
TEST_ID: QA-CASE-001
MODULE: Citation Cases
FEATURE: Citation Case Creation Wizard
PRIORITY: P0
PRECONDITIONS: User has Compliance Head or Department Head role, citations exist in library
STEPS:
1. Navigate to /citations/cases
2. Click "Report Citation Case"
3. Step 1 - Enter title: "F689 Deficiency - Fall Prevention"
4. Step 1 - Enter description: "CMS survey finding regarding fall prevention protocols"
5. Step 1 - Select origin type: "CMS/State Survey"
6. Step 1 - Select facility: "Main Campus"
7. Step 1 - Select department: "Nursing"
8. Click "Next"
9. Step 2 - Search and select citation "F689"
10. Step 2 - Verify evidence expectations display from selected citation
11. Click "Next"
12. Step 3 - Enter findings summary
13. Step 3 - Select severity: "High"
14. Step 3 - Select priority: "Critical"
15. Step 3 - Verify NO attachment upload available on this step
16. Click "Next"
17. Step 4 - Upload evidence with sensitivity tag
18. Step 4 - Assign owner
19. Step 4 - Enter cms2567_received_date
20. Step 4 - Verify poc_due_date auto-calculated (received_date + 10 days)
21. Click "Submit"
EXPECTED_RESULT: Citation case created with status "Reported", PoC due date correctly calculated, Clock Card displays countdown
TEST_DATA: {"title": "F689 Deficiency - Fall Prevention", "authorityType": "CMS/State Survey", "citationCode": "F689", "cms2567ReceivedDate": "2024-12-01"}
```

### C1.2 Step 3 Attachment Restriction

```
TEST_ID: QA-CASE-002
MODULE: Citation Cases
FEATURE: Citation Case Wizard - Finding Details
PRIORITY: P0
PRECONDITIONS: User is on Step 3 of citation case creation
STEPS:
1. Navigate to Step 3 (Finding Details)
2. Scan entire step UI for any file upload controls
3. Verify no attachment functionality exists
EXPECTED_RESULT: No file upload or attachment controls present on Step 3. Attachments only allowed in Step 4.
TEST_DATA: {}
```

## C2. Citation Case Triage

### C2.1 Mandatory Triage Completion

```
TEST_ID: QA-CASE-010
MODULE: Citation Cases
FEATURE: Citation Case Triage
PRIORITY: P0
PRECONDITIONS: Citation case exists with status "Reported", user has Compliance Head role
STEPS:
1. Navigate to citation case detail page
2. Verify status is "Reported"
3. Click "Begin Triage"
4. Confirm/adjust citation selection
5. Set severity with rationale
6. For CMS mode: skip SAFER fields
7. Assign owner and QA reviewer
8. Set due dates
9. Select remediation path: "Create CAPA"
10. Review auto-generated recommended actions from citation
11. Select/customize actions
12. Click "Complete Triage"
EXPECTED_RESULT: Status changes to "Remediation In Progress", Clock Card displays PoC countdown, CAPA creation initiated if selected
TEST_DATA: {"caseId": "CASE-001", "remediationPath": "Create CAPA"}
```

### C2.2 CAPA Requirement for Pattern/Widespread Scope

```
TEST_ID: QA-CASE-011
MODULE: Citation Cases
FEATURE: Citation Case Triage - CAPA Requirement
PRIORITY: P0
PRECONDITIONS: Citation case in Triage phase
STEPS:
1. Navigate to triage panel
2. Set scope_prevalence to "Pattern" or "Widespread"
3. Attempt to select remediation path: "Quick Fix"
4. Verify system requires CAPA linkage
5. Attempt to proceed without CAPA
6. Verify Compliance Manager override option with justification required
EXPECTED_RESULT: System blocks Quick Fix path for Pattern/Widespread scope unless Compliance Manager provides documented override with justification
TEST_DATA: {"caseId": "CASE-001", "scopePrevalence": "Pattern"}
```

## C3. Citation Case Clocks

### C3.1 CMS PoC Clock Display

```
TEST_ID: QA-CASE-020
MODULE: Citation Cases
FEATURE: Clock Card - CMS PoC Mode
PRIORITY: P0
PRECONDITIONS: Citation case with authority_type = "CMS/State Survey" and cms2567_received_date set
STEPS:
1. Navigate to citation case detail page
2. Locate Clock Card component
3. Verify clock shows "PoC Due" label
4. Verify due date = cms2567_received_date + 10 calendar days
5. Verify countdown displays remaining days/hours
6. Set system date to 2 days before due date
7. Verify warning alert styling
8. Set system date to past due date
9. Verify overdue alert styling
EXPECTED_RESULT: Clock Card correctly calculates and displays PoC due date with appropriate visual alerts for approaching/overdue status
TEST_DATA: {"caseId": "CASE-001", "cms2567ReceivedDate": "2024-12-01", "expectedPocDue": "2024-12-11"}
```

### C3.2 Joint Commission ESC Clock Display

```
TEST_ID: QA-CASE-021
MODULE: Citation Cases
FEATURE: Clock Card - Joint Commission ESC Mode
PRIORITY: P0
PRECONDITIONS: Citation case with authority_type = "Joint Commission" and authority_report_posted_date set
STEPS:
1. Navigate to citation case detail page
2. Locate Clock Card component
3. Verify clock shows "ESC Due" label
4. Verify due date = authority_report_posted_date + 60 days
5. Verify countdown displays remaining days
EXPECTED_RESULT: Clock Card correctly calculates ESC due date (report_posted_date + 60 days)
TEST_DATA: {"caseId": "CASE-002", "authorityReportPostedDate": "2024-12-01", "expectedEscDue": "2025-01-30"}
```

## C4. Citation Case QA Verification

### C4.1 Evidence Expectations Checklist

```
TEST_ID: QA-CASE-030
MODULE: Citation Cases
FEATURE: QA Verification Checklist
PRIORITY: P0
PRECONDITIONS: Citation case in "QA Verification" phase, linked citation has evidence expectations
STEPS:
1. Navigate to citation case detail page
2. Access QA Verification section
3. Verify auto-generated checklist based on citation's evidence expectations
4. For each expectation, select outcome: "Met", "Not Met", or "N/A"
5. Add notes for each evaluation
6. Link evidence to relevant expectations
7. Click "Pass" (after all required met)
EXPECTED_RESULT: QA verification checklist populated from citation evidence expectations, outcomes recorded, case unblocked for closure upon Pass
TEST_DATA: {"caseId": "CASE-001"}
```

---

# Module D: ActionGuard (CAPA)

## D1. CAPA Creation

### D1.1 Create CAPA - CMS Survey Deficiency Origin

```
TEST_ID: QA-CAPA-001
MODULE: ActionGuard (CAPA)
FEATURE: CAPA Creation Wizard
PRIORITY: P0
PRECONDITIONS: User has Staff role or higher
STEPS:
1. Navigate to /capas
2. Click "Create CAPA"
3. Step 1 - Enter title: "Fall Prevention System Improvement"
4. Step 1 - Select origin type: "CMS/State Survey Deficiency (CMS-2567)"
5. Step 1 - Enter cms2567_received_date
6. Step 1 - Verify poc_due_date auto-calculated
7. Step 1 - Select facility and department
8. Step 1 - Select severity: "High"
9. Step 1 - Select template: "CMS PoC Template"
10. Click "Next"
11. Step 2 - Enter containment actions
12. Click "Next"
13. Step 3 - Select RCA method: "5 Whys"
14. Step 3 - Enter root cause analysis
15. Step 3 - Identify at least 1 root cause
16. Click "Next"
17. Step 4 - Add corrective action with healthcare action type
18. Step 4 - Add preventive action
19. Click "Next"
20. Step 5 - Define monitoring plan
21. Step 5 - Set effectiveness criteria with measurable KPIs
22. Click "Next"
23. Step 6 - Review all sections
24. Click "Submit"
EXPECTED_RESULT: CAPA created with status "Submitted", PoC clock displays, all CMS PoC required fields present
TEST_DATA: {"title": "Fall Prevention System Improvement", "originType": "CMS/State Survey Deficiency", "cms2567ReceivedDate": "2024-12-01"}
```

### D1.2 CAPA From Issue - Prefill Verification

```
TEST_ID: QA-CAPA-002
MODULE: ActionGuard (CAPA)
FEATURE: CAPA Creation from Issue
PRIORITY: P1
PRECONDITIONS: Issue exists with action steps and linked citations
STEPS:
1. Navigate to issue detail page
2. Click "Create CAPA" from action rail
3. Verify CAPA wizard opens with prefilled data:
   - Problem statement from issue description
   - Department from issue department
   - Severity from issue severity
   - Linked citations from issue citations
4. Verify option to copy issue action steps to CAPA actions
5. Select to copy actions
6. Proceed through wizard
7. Submit CAPA
EXPECTED_RESULT: CAPA created with prefilled data from issue, issue automatically linked to new CAPA
TEST_DATA: {"issueId": "ISS-001"}
```

## D2. CAPA Status Lifecycle

### D2.1 Draft to Submitted Validation

```
TEST_ID: QA-CAPA-010
MODULE: ActionGuard (CAPA)
FEATURE: CAPA Status Transitions
PRIORITY: P0
PRECONDITIONS: CAPA exists in Draft status with incomplete required fields
STEPS:
1. Navigate to CAPA detail page
2. Verify CAPA has missing required fields (no root cause, no actions)
3. Attempt to click "Submit for Review"
4. Verify validation error displayed
5. Add required root cause
6. Add required action
7. Click "Submit for Review"
8. Confirm in dialog
EXPECTED_RESULT: Submission blocked until required fields complete, successful submission after requirements met, status changes to "Submitted"
TEST_DATA: {"capaId": "CAPA-001"}
```

### D2.2 Approval Workflow

```
TEST_ID: QA-CAPA-011
MODULE: ActionGuard (CAPA)
FEATURE: CAPA Approval Workflow
PRIORITY: P0
PRECONDITIONS: CAPA in "In Review" status, user has Compliance Head role
STEPS:
1. Navigate to /approvals
2. Verify CAPA appears in NEW bucket (In Review status)
3. Click on CAPA to open detail
4. Click "Approve"
5. Verify dialog shows only comments field
6. Verify alert reminds to use Ownership section for reassignment
7. Add approval comments
8. Confirm approval
EXPECTED_RESULT: CAPA status changes to "Approved", then immediately to "In Progress", audit log updated
TEST_DATA: {"capaId": "CAPA-001"}
```

### D2.3 Request Changes Flow

```
TEST_ID: QA-CAPA-012
MODULE: ActionGuard (CAPA)
FEATURE: CAPA Request Changes
PRIORITY: P1
PRECONDITIONS: CAPA in "In Review" status
STEPS:
1. Navigate to CAPA detail page
2. Click "Request Changes"
3. Enter required comments explaining changes needed
4. Confirm
EXPECTED_RESULT: CAPA status returns to "Draft", comments saved, audit log shows request changes with comments
TEST_DATA: {"capaId": "CAPA-001", "comments": "Please add more detail to root cause analysis"}
```

## D3. CAPA Actions and Verification

### D3.1 Action Completion with Evidence

```
TEST_ID: QA-CAPA-020
MODULE: ActionGuard (CAPA)
FEATURE: CAPA Action Management
PRIORITY: P0
PRECONDITIONS: CAPA in "In Progress" status with actions defined
STEPS:
1. Navigate to CAPA detail page
2. Click "Actions" tab
3. Select an action
4. Change status from "Not Started" to "In Progress"
5. Upload evidence for action
6. Change status to "Done"
7. Verify evidence_required flag is satisfied
EXPECTED_RESULT: Action status updated, evidence attached to action, progress reflected in CAPA overview
TEST_DATA: {"capaId": "CAPA-001", "actionId": "ACT-001"}
```

### D3.2 Move to Verification Gate

```
TEST_ID: QA-CAPA-021
MODULE: ActionGuard (CAPA)
FEATURE: CAPA Phase Transition - Verification
PRIORITY: P0
PRECONDITIONS: CAPA in "In Progress" status, some actions not complete
STEPS:
1. Navigate to CAPA detail page
2. Attempt to click "Move to Verification"
3. Verify system blocks transition (not all required actions Done)
4. Complete all required actions
5. Click "Move to Verification"
6. Confirm in dialog
EXPECTED_RESULT: Transition blocked until all required actions complete (or Compliance Head override), successful transition after completion
TEST_DATA: {"capaId": "CAPA-001"}
```

## D4. CAPA Effectiveness and Closure

### D4.1 Effectiveness Monitoring Pass

```
TEST_ID: QA-CAPA-030
MODULE: ActionGuard (CAPA)
FEATURE: CAPA Effectiveness Monitoring
PRIORITY: P0
PRECONDITIONS: CAPA in "Effectiveness Monitoring" status with defined KPIs
STEPS:
1. Navigate to CAPA detail page
2. Click "Effectiveness" tab
3. Add monitoring entry with date, metric value, notes, evidence
4. Verify metric against target KPI
5. Set effectiveness_result to "Pass"
6. Attempt to close CAPA
EXPECTED_RESULT: Monitoring entry recorded, effectiveness result set, closure workflow unblocked
TEST_DATA: {"capaId": "CAPA-001", "metricValue": 95, "targetValue": 90}
```

### D4.2 Management Review Requirement

```
TEST_ID: QA-CAPA-031
MODULE: ActionGuard (CAPA)
FEATURE: CAPA Closure - Management Review
PRIORITY: P0
PRECONDITIONS: CAPA in "Effectiveness Monitoring" with effectiveness_result = Pass, severity = High
STEPS:
1. Navigate to CAPA detail page
2. Click "Close CAPA"
3. Verify Management Review sign-off section displayed
4. Attempt to close without Management Review
5. Verify closure blocked
6. Complete Management Review (signed_by, signed_date, signoff_notes)
7. Click "Close CAPA" again
8. Confirm closure
EXPECTED_RESULT: Closure blocked until Management Review complete for High/Critical severity CAPAs, successful closure after sign-off
TEST_DATA: {"capaId": "CAPA-001", "severity": "High"}
```

### D4.3 CMS PoC Closure Requirement

```
TEST_ID: QA-CAPA-032
MODULE: ActionGuard (CAPA)
FEATURE: CAPA Closure - CMS PoC Requirement
PRIORITY: P0
PRECONDITIONS: CAPA with origin_type = "CMS/State Survey Deficiency", effectiveness passed
STEPS:
1. Navigate to CAPA detail page
2. Verify PoC section exists with 5 required elements
3. Attempt to close with incomplete PoC
4. Verify closure blocked
5. Complete all 5 PoC elements:
   - Corrective action for affected residents
   - Identification of others affected
   - Systemic changes
   - Monitoring plan
   - Completion dates
6. Set poc_submission_date
7. Close CAPA
EXPECTED_RESULT: Closure blocked until PoC section complete, successful closure after PoC submitted
TEST_DATA: {"capaId": "CAPA-001", "originType": "CMS/State Survey Deficiency"}
```

## D5. CAPA Bucket UI

### D5.1 Bucket Segmentation Display

```
TEST_ID: QA-CAPA-040
MODULE: ActionGuard (CAPA)
FEATURE: CAPA List - Bucket UI
PRIORITY: P1
PRECONDITIONS: CAPAs exist in various statuses
STEPS:
1. Navigate to /capas
2. Verify segmented control shows: NEW, OPEN, CLOSED tabs
3. Click NEW tab
4. Verify shows Draft, Submitted, In Review statuses
5. Click OPEN tab
6. Verify shows Approved, In Progress, Verification, Effectiveness Monitoring, Reopened
7. Click CLOSED tab
8. Verify shows only Closed status
9. Verify count badges on each tab
EXPECTED_RESULT: CAPAs correctly grouped by bucket, counts accurate
TEST_DATA: {}
```

---

# Module E: Enterprise Reporting

## E1. Report Catalog

### E1.1 Report Catalog Navigation

```
TEST_ID: QA-RPT-001
MODULE: Enterprise Reporting
FEATURE: Report Catalog
PRIORITY: P1
PRECONDITIONS: User has access to reports
STEPS:
1. Navigate to /reports
2. Verify report catalog displays
3. Verify reports grouped by domain (Issues, CAPA, Citations)
4. Click on a report card
5. Verify navigation to report detail page
EXPECTED_RESULT: Report catalog displays all available reports with proper grouping, navigation works
TEST_DATA: {}
```

### E1.2 CSV Export

```
TEST_ID: QA-RPT-010
MODULE: Enterprise Reporting
FEATURE: CSV Export
PRIORITY: P0
PRECONDITIONS: User viewing report with filters applied
STEPS:
1. Navigate to a report detail page
2. Apply date range filter
3. Apply facility filter
4. Apply status filter
5. Click "Export CSV"
6. Verify download initiates
7. Open CSV file
8. Verify data matches applied filters
9. Verify all visible columns included
10. Verify export metadata (report name, timestamp, user, filters)
EXPECTED_RESULT: CSV exports all rows matching filters (not paginated), includes metadata, respects column selection
TEST_DATA: {}
```

---

# Module F: Admin Configuration

## F1. Recommended Actions Configuration

### F1.1 Add Recommended Action with Rules

```
TEST_ID: QA-ADM-001
MODULE: Admin Configuration
FEATURE: Recommended Actions Manager
PRIORITY: P0
PRECONDITIONS: User has Admin role
STEPS:
1. Navigate to /admin-configuration
2. Expand "Recommended Actions" section
3. Click "Add Action"
4. Enter action text: "Review and update fall prevention policy"
5. Enter source URL: "https://cms.gov/guidance"
6. Set rule: Issue Type = "Safety", Category = "Falls"
7. Set default owner role: "Department Head"
8. Set default due days: 14
9. Toggle evidence required: ON
10. Toggle active: ON
11. Click "Save"
EXPECTED_RESULT: Recommended action saved with display rules, appears when matching type/category selected in issue creation
TEST_DATA: {"actionText": "Review and update fall prevention policy", "issueType": "Safety", "category": "Falls"}
```

---

# Cross-Module Tests

## X1. Connections and Linking

### X1.1 Issue-Citation-CAPA Triangle

```
TEST_ID: QA-XMD-001
MODULE: Cross-Module
FEATURE: Record Linking
PRIORITY: P0
PRECONDITIONS: Issue, Citation, and CAPA exist unlinked
STEPS:
1. Navigate to Issue detail page
2. Link to Citation via Connections Panel
3. Link to CAPA via Connections Panel
4. Navigate to Citation detail page
5. Verify Issue appears in "Linked Work" section
6. Navigate to CAPA detail page
7. Verify Issue appears as linked
8. Verify Citation appears as linked
EXPECTED_RESULT: All three record types show bidirectional links, audit log entries created for each link
TEST_DATA: {"issueId": "ISS-001", "citationId": "CIT-001", "capaId": "CAPA-001"}
```

## X2. Role-Based Access

### X2.1 Staff Cannot Close CAPA

```
TEST_ID: QA-XMD-010
MODULE: Cross-Module
FEATURE: Role-Based Access Control
PRIORITY: P0
PRECONDITIONS: CAPA ready for closure, user logged in as Staff role
STEPS:
1. Navigate to CAPA detail page
2. Attempt to locate "Close CAPA" action
3. Verify action is not available or disabled
4. Attempt direct API call to close (if possible)
5. Verify rejection
EXPECTED_RESULT: Staff users cannot close CAPAs, action hidden or disabled, API rejects unauthorized attempts
TEST_DATA: {"capaId": "CAPA-001", "userRole": "Staff"}
```

---

# Accessibility Tests

## ACC1. Keyboard Navigation

### ACC1.1 Full Keyboard Navigation

```
TEST_ID: QA-ACC-001
MODULE: Accessibility
FEATURE: Keyboard Navigation
PRIORITY: P0
PRECONDITIONS: Any page loaded
STEPS:
1. Press Tab to navigate through all interactive elements
2. Verify visible focus indicator on each element
3. Press Enter/Space to activate buttons
4. Use arrow keys in dropdowns/menus
5. Press Escape to close modals/dialogs
6. Verify skip-to-content link at page start
EXPECTED_RESULT: All interactive elements reachable via keyboard, focus indicators visible, standard keyboard patterns work
TEST_DATA: {}
```

### ACC1.2 Screen Reader Compatibility

```
TEST_ID: QA-ACC-002
MODULE: Accessibility
FEATURE: ARIA Labels
PRIORITY: P0
PRECONDITIONS: Screen reader enabled
STEPS:
1. Navigate through page with screen reader
2. Verify all buttons have accessible names
3. Verify form fields have associated labels
4. Verify images have alt text
5. Verify headings follow semantic hierarchy (h1, h2, h3...)
6. Verify ARIA-live regions announce dynamic content
EXPECTED_RESULT: All content accessible via screen reader, proper ARIA labels throughout
TEST_DATA: {}
```

---

# Performance Tests

## PERF1. Load Times

### PERF1.1 List Page Load

```
TEST_ID: QA-PERF-001
MODULE: Performance
FEATURE: Page Load Time
PRIORITY: P1
PRECONDITIONS: 100+ issues in database
STEPS:
1. Clear browser cache
2. Navigate to /issues
3. Measure time to first contentful paint
4. Measure time to full interactive
5. Verify list loads within 3 seconds
EXPECTED_RESULT: First contentful paint < 1.5s, fully interactive < 3s
TEST_DATA: {}
```

---

*End of QA Test Cases Document*
