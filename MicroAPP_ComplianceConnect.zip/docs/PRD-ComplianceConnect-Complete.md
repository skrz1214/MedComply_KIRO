# ComplianceConnect Platform - Complete Product Requirements Document (PRD)

**Version:** 2.0  
**Last Updated:** December 2024  
**Product:** ComplianceConnect (MedComply Suite)  
**Target Users:** Healthcare Compliance Teams (LTC, SNF, Hospitals, Clinics)

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Platform Overview](#2-platform-overview)
3. [User Roles & Permissions](#3-user-roles--permissions)
4. [Module A: ComplianceConnect Issues](#4-module-a-complianceconnect-issues)
5. [Module B: Citations Library](#5-module-b-citations-library)
6. [Module C: Citation Cases](#6-module-c-citation-cases)
7. [Module D: ActionGuard (CAPA)](#7-module-d-actionguard-capa)
8. [Module E: Enterprise Reporting & Analytics](#8-module-e-enterprise-reporting--analytics)
9. [Module F: Admin Configuration](#9-module-f-admin-configuration)
10. [Cross-Module Features](#10-cross-module-features)
11. [Technical Requirements](#11-technical-requirements)
12. [Appendix](#12-appendix)

---

## 1. Executive Summary

### 1.1 Purpose
ComplianceConnect is a comprehensive healthcare compliance management platform designed for Long-Term Care (LTC) providers, Skilled Nursing Facilities (SNFs), hospitals, and clinics. The platform manages the complete lifecycle of compliance issues, regulatory citations, and corrective/preventive actions (CAPA) with full audit trail and regulatory submission support.

### 1.2 Key Objectives
- Streamline compliance issue reporting and resolution workflows
- Maintain a centralized citation/standards library with evidence expectations
- Manage regulatory citation cases with PoC/ESC clock tracking
- Implement healthcare-grade CAPA workflows aligned with CMS, Joint Commission, and FDA requirements
- Provide enterprise-wide reporting and analytics
- Ensure WCAG 2.1 AA accessibility compliance
- Support PHI-safe handling with appropriate warnings and controls

### 1.3 Target Regulatory Frameworks
- CMS (Centers for Medicare & Medicaid Services) - CMS-2567 Plan of Correction
- Joint Commission - Evidence of Standards Compliance (ESC)
- State Department of Health (DOH) surveys
- HIPAA privacy and security requirements
- OSHA workplace safety
- 21 CFR 820.100 (CAPA requirements)

---

## 2. Platform Overview

### 2.1 Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    ComplianceConnect Platform                    │
├─────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Compliance   │  │  Citations   │  │    ActionGuard       │  │
│  │   Issues     │◄─┤   Library    │◄─┤      (CAPA)          │  │
│  │              │  │              │  │                      │  │
│  └──────┬───────┘  └──────┬───────┘  └──────────┬───────────┘  │
│         │                 │                      │              │
│         │    ┌────────────┴────────────┐        │              │
│         │    │     Citation Cases      │        │              │
│         │    │  (PoC/ESC Management)   │────────┘              │
│         │    └─────────────────────────┘                       │
│         │                                                       │
│  ┌──────┴───────────────────────────────────────────────────┐  │
│  │              Cross-Module Connections Panel               │  │
│  │     (Issues ↔ Citations ↔ CAPAs ↔ External Microapps)    │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────┐  ┌──────────────────────────────────┐ │
│  │  Enterprise Reports  │  │      Admin Configuration         │ │
│  └──────────────────────┘  └──────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Navigation Structure

**Primary Left Navigation:**
- Dashboard
- Issues (ComplianceConnect)
- Citations
  - Library
  - Cases
- ActionGuard (CAPA)
  - Dashboard
  - CAPAs
  - Approvals
  - My Work
- Reports
- Admin Configuration

### 2.3 Routes

| Route | Description |
|-------|-------------|
| `/` | Dashboard |
| `/issues` | Issues list |
| `/issues/new` | Report new issue (4-step wizard) |
| `/issues/:id` | Issue detail with tabs |
| `/citations` | Citations library list |
| `/citations/new` | Create new citation |
| `/citations/:id` | Citation detail with tabs |
| `/citations/cases` | Citation cases list |
| `/citations/cases/new` | Report citation case (4-step wizard) |
| `/citations/cases/:id` | Citation case detail |
| `/capas` | CAPA list with bucket tabs |
| `/capas/new` | Create CAPA (6-step wizard) |
| `/capas/:id` | CAPA detail with tabs |
| `/approvals` | CAPA approval queue |
| `/my-work` | Personal to-do list |
| `/reports` | Report catalog |
| `/reports/:reportId` | Report detail view |
| `/reports/exports` | Export history |
| `/admin` | Admin configuration |

---

## 3. User Roles & Permissions

### 3.1 Role Definitions

| Role | Scope | Description |
|------|-------|-------------|
| **Admin** | System-wide | Full system control including configuration management |
| **Compliance Head** | Organization-wide | Org-wide oversight, approvals, closures, override authority |
| **Department Head** | Department-scoped | Department management, assignments, approvals within scope |
| **Staff** | Personal | Work assigned items, upload evidence, create drafts |

### 3.2 Permission Matrix

| Permission | Admin | Compliance Head | Dept Head | Staff |
|------------|-------|-----------------|-----------|-------|
| Edit Admin Configuration | ✓ | Read-only | ✗ | ✗ |
| View All Records | ✓ | ✓ | Dept only | Own only |
| Create Issues | ✓ | ✓ | ✓ | ✓ |
| Assign Issues | ✓ | ✓ | ✓ | ✗ |
| Close Issues | ✓ | ✓ | ✓ | ✗ |
| Create CAPAs | ✓ | ✓ | ✓ | Draft only |
| Approve CAPAs | ✓ | ✓ | ✗ | ✗ |
| Close/Reopen CAPAs | ✓ | ✓ | ✗ | ✗ |
| Management Review Sign-off | ✓ | ✓ | ✗ | ✗ |
| Override Gates | ✓ | ✓ (with justification) | ✗ | ✗ |
| Export Reports | ✓ | ✓ | ✓ | Configurable |
| Upload Evidence | ✓ | ✓ | ✓ | ✓ |

### 3.3 Audit Logging Requirements
- Every create/update/delete/status change must be logged
- Log entries include: user, timestamp, action, old value, new value
- Link/unlink operations between records must be logged
- File uploads must be logged with metadata
- Export operations must be logged

---

## 4. Module A: ComplianceConnect Issues

### 4.1 Overview
Workflow-driven compliance issue management with structured multi-stage lifecycle from reporting through closure.

### 4.2 Issue Lifecycle Stages

```
┌──────────┐    ┌────────────┐    ┌─────────────┐    ┌───────────┐    ┌──────────┐
│ Reported │───►│ Initiation │───►│ In Progress │───►│ QA Review │───►│ Completed│
└──────────┘    └────────────┘    └─────────────┘    └───────────┘    └──────────┘
                                         ▲                  │
                                         └──────────────────┘
                                          (Return for revision)
                                                   │
                                                   ▼
                                          ┌────────────┐
                                          │ Monitoring │
                                          │  (Optional)│
                                          └────────────┘
```

### 4.3 Issue Reporting Wizard (4 Steps)

**Step 1: Basic Information**
- Title (required)
- Description (required)
- Reporter name (auto-filled)
- Department (required)
- Facility/Location (required)
- Date discovered

**Step 2: Classification**
- Issue Type (required) - dropdown from Admin Config
- Issue Category (required) - filtered by selected type
- Priority (required)
- Severity (optional)
- Tags (optional)

**Step 3: Action Steps**
- Display recommended actions ONLY after BOTH type AND category selected
- Show source URLs for each recommendation
- Allow selection/deselection of recommended actions
- Allow adding custom action steps (description only)
- **CONSTRAINT:** No attachments allowed at this step

**Step 4: Assignment & Evidence**
- Assign to user (required)
- Set due date (required)
- Upload attachments with sensitivity tagging
- Cross-microapp linking (RiskGuard, AuditPro, FeedbackHub, EnforcementPoint)
- Review & Submit

### 4.4 Issue Data Model

```typescript
interface ComplianceIssue {
  id: string;
  title: string;
  description: string;
  
  // Classification
  issueType: string;
  issueCategory: string;
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  severity?: string;
  tags: string[];
  
  // Organization context
  organizationId: string;
  facilityId: string;
  departmentId: string;
  
  // Workflow
  status: 'Reported' | 'Initiation' | 'In Progress' | 'QA Review' | 'Completed';
  stage: WorkflowStage;
  
  // People
  reporterId: string;
  reporterName: string;
  assigneeId: string;
  assigneeName: string;
  qaReviewerId?: string;
  
  // Dates
  createdAt: string;
  updatedAt: string;
  dueDate: string;
  completedAt?: string;
  
  // Action steps
  actionSteps: ActionStep[];
  
  // Attachments by stage
  attachments: StageAttachments;
  
  // Connections
  linkedCitationIds: string[];
  linkedCapaIds: string[];
  linkedCitationCaseIds: string[];
  crossReferences: CrossReference[];
  
  // Monitoring
  monitoringDestination?: 'Risk' | 'Enforcement' | 'Audit' | 'Compliance';
  
  // Audit
  auditLog: AuditLogEntry[];
}

interface ActionStep {
  id: string;
  description: string;
  status: 'Not Started' | 'In Progress' | 'Complete' | 'Rejected' | 'Deferred';
  dueDate: string;
  assigneeId?: string;
  assigneeName?: string;
  evidenceRequired: boolean;
  evidence: Attachment[];
  notes: string;
  sourceUrl?: string;
  completedAt?: string;
  completedBy?: string;
}

interface StageAttachments {
  reported: Attachment[];
  initiation: Attachment[];
  inProgress: Attachment[];
  qaReview: Attachment[];
  completed: Attachment[];
}
```

### 4.5 Issue Detail Page

**Tabbed Interface:**
- **Work** - Current stage action steps, attachment uploads
- **Stage Details** - History of each workflow stage with actors, dates, activities
- **Files** - Aggregated view of all attachments across stages
- **Connections** - Linked Citations, CAPAs, external references
- **History** - Audit log timeline

**Right Action Rail:**
- Status badge
- Current assignee
- Due date
- Priority indicator
- Quick actions (based on stage)
- Links to related items

### 4.6 QA Review Options
1. **Approve & Complete** - Issue moves to Completed
2. **Return for Revision** - Returns to In Progress with comments
3. **Approve, Complete & Route to Monitoring** - Opens dialog to select monitoring destination (Risk/Enforcement/Audit/Compliance)

---

## 5. Module B: Citations Library

### 5.1 Overview
Central repository of regulatory citations and standards with mappings to internal controls and evidence expectations.

### 5.2 Citation Data Model

```typescript
interface Citation {
  id: string;
  
  // Identity
  code: string;           // e.g., "F689", "IC.02.01.01"
  title: string;
  fullText: string;
  
  // Source & Context
  source: 'CMS' | 'Joint Commission' | 'State DOH' | 'HIPAA' | 'OSHA' | 'Internal Policy' | 'Other';
  jurisdiction?: string;  // Federal, State name, Local
  facilityTypes: string[]; // SNF, ALF, Hospital, Clinic
  riskDomain: string;
  
  // Status & Version
  status: 'Draft' | 'Active' | 'Deprecated' | 'Superseded';
  version: number;
  previousVersionId?: string;
  effectiveDate: string;
  
  // Assignment
  reviewerId: string;
  reviewerName: string;
  departmentId: string;
  
  // Evidence Expectations
  evidenceExpectations: EvidenceExpectation[];
  
  // Mappings
  mappings: CitationMapping[];
  
  // Remediation
  remediationSteps: RemediationStep[];
  
  // References
  referenceUrls: string[];
  
  // Quality indicators (orthogonal to status)
  hasMappings: boolean;
  hasEvidenceExpectations: boolean;
  
  // Metadata
  tags: string[];
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  
  // Connections
  linkedIssueIds: string[];
  linkedCapaIds: string[];
  linkedCaseIds: string[];
  
  auditLog: AuditLogEntry[];
}

interface EvidenceExpectation {
  id: string;
  type: string;           // Policy, Procedure, Training Record, etc.
  description: string;
  required: boolean;
}

interface CitationMapping {
  id: string;
  type: 'Policy' | 'Control' | 'Training' | 'Checklist';
  targetId: string;
  targetName: string;
  description?: string;
}

interface RemediationStep {
  id: string;
  description: string;
  sourceUrl?: string;
  order: number;
}
```

### 5.3 Citation Creation Wizard

**Step 1: Basic Information**
- Code (required)
- Title (required)
- Source (required)
- Jurisdiction
- Facility types (multi-select)
- Risk domain

**Step 2: Citation Text**
- Full regulatory text (rich text editor)
- Effective date
- References/URLs

**Step 3: Evidence & Mappings**
- Evidence expectations (add multiple)
- Control mappings
- Policy mappings
- Training mappings

**Step 4: Assignment & Review**
- Assign reviewer (required, "Myself" option available)
- Department assignment
- Tags
- Status (Draft/Active)

### 5.4 Citation Detail Page

**Tabs:**
- **Overview** - Summary, metadata, quality indicators
- **Citation Text** - Full regulatory text
- **Evidence Expectations** - CRUD for evidence requirements
- **Mappings** - CRUD for policy/control/training mappings
- **Remediation Steps** - CRUD for recommended actions with source URLs
- **Linked Work** - Issues and CAPAs linked to this citation
- **Files** - Attached reference documents
- **History** - Audit trail

**Right Action Rail:**
- Status badge
- Version number
- Quality indicators (Unmapped, Missing Evidence badges)
- Actions: Edit, Duplicate, Deprecate, Supersede, Export, Assign for Review

### 5.5 Citation Library KPI Strip

| Metric | Description |
|--------|-------------|
| Total Active | Count of Active citations |
| Unmapped | Active citations without control/policy mappings |
| Missing Evidence | Active citations without evidence expectations |
| Draft | Citations pending review/activation |
| Deprecated | Superseded/retired citations |

### 5.6 Citation Versioning
- Duplicate creates independent copy with new ID
- Supersede links new version to old version
- Version chain maintained for audit trail
- Old versions marked Deprecated or Superseded
- Configurable: auto-supersede on new version publish

---

## 6. Module C: Citation Cases

### 6.1 Overview
Operational management of actual regulatory deficiencies or findings tied to specific facilities and events.

### 6.2 Authority Types & Modes

| Authority Type | Default Mode | Clock Calculation |
|---------------|--------------|-------------------|
| CMS/State Survey | PoC | cms2567_received_date + 10 calendar days |
| Joint Commission | ESC | authority_report_posted_date + 60 days |
| Internal Audit | General | Organization SLA defaults |
| Other | General | Organization SLA defaults |

### 6.3 Citation Case Lifecycle

```
┌────────┐    ┌──────────┐    ┌────────────────────┐    ┌─────────────┐
│ Draft  │───►│ Reported │───►│       Triage       │───►│ Remediation │
└────────┘    └──────────┘    │ (Mandatory Phase)  │    │ In Progress │
                              └────────────────────┘    └──────┬──────┘
                                                               │
                    ┌──────────┐    ┌───────────────┐          │
                    │ Closed   │◄───│ QA Verification│◄─────────┘
                    └────┬─────┘    └───────────────┘
                         │
                         ▼
                   ┌────────────┐
                   │ Monitoring │ (Optional)
                   └────────────┘
```

### 6.4 Citation Case Data Model

```typescript
interface CitationCase {
  id: string;
  title: string;
  
  // Citation reference
  citationId: string;
  citationCode: string;
  citationVersion: number;
  
  // Authority & Mode
  authorityType: 'CMS/State Survey' | 'Joint Commission' | 'Internal Audit' | 'Other';
  mode: 'PoC' | 'ESC' | 'General';
  
  // Origin & Context
  originType: 'Survey/Inspection' | 'Internal Audit' | 'Complaint' | 'Incident';
  organizationId: string;
  facilityId: string;
  departmentId: string;
  
  // SAFER-like fields (TJC mode)
  patientImpactLikelihood?: 'Low' | 'Medium' | 'High';
  scopePrevalence?: 'Isolated' | 'Pattern' | 'Widespread';
  
  // Status & Workflow
  status: 'Draft' | 'Reported' | 'Triage' | 'Remediation In Progress' | 'QA Verification' | 'Closed' | 'Monitoring' | 'Reopened';
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  
  // Dates & Clocks
  reportedDate: string;
  cms2567ReceivedDate?: string;      // PoC mode
  authorityReportPostedDate?: string; // ESC mode
  pocDueDate?: string;
  escDueDate?: string;
  triageDueDate: string;
  remediationDueDate: string;
  
  // People
  reporterId: string;
  ownerId: string;
  ownerName: string;
  qaReviewerId?: string;
  
  // Findings
  findingsSummary: string;
  
  // Triage decisions
  triageDecision?: {
    decidedBy: string;
    decidedAt: string;
    severityRationale: string;
    remediationPath: 'Link Issue' | 'Create Issue' | 'Link CAPA' | 'Create CAPA' | 'Quick Fix';
    quickFixJustification?: string;
  };
  
  // PoC-specific fields (CMS/State mode)
  poc?: {
    ftag?: string;
    scopeSeverity?: string; // A-L grid
    correctiveAction: string;
    othersAffectedAction: string;
    systemicChanges: string;
    monitoringPlan: {
      what: string;
      frequency: string;
      whoReviews: string;
      escalationRules: string;
    };
    completionDates: string;
    submissionDate?: string;
    acceptanceStatus?: 'Pending' | 'Accepted' | 'Returned';
  };
  
  // ESC-specific fields (Joint Commission mode)
  esc?: {
    rfiReferences: string[];
    correctiveActions: { action: string; date: string }[];
    evidenceMappings: { expectationId: string; evidenceId: string }[];
    sustainmentPlan: string;
    completionDate: string;
    submissionDate?: string;
  };
  
  // Containment actions
  containmentActions: ContainmentAction[];
  
  // Verification
  verificationChecklist: VerificationChecklistItem[];
  verificationOutcome?: 'Pass' | 'Fail' | 'Escalate';
  verificationNotes?: string;
  
  // Closure
  closureReason?: 'Verified Fixed' | 'Not Applicable' | 'Duplicate' | 'Accepted Risk' | 'Referred Out';
  closureJustification?: string;
  closedBy?: string;
  closedAt?: string;
  
  // Monitoring
  monitoringPlan?: MonitoringPlan;
  
  // Connections
  linkedIssueIds: string[];
  linkedCapaIds: string[];
  crossReferences: CrossReference[];
  
  // Evidence
  evidence: Attachment[];
  
  // Audit
  auditLog: AuditLogEntry[];
  comments: CaseComment[];
}

interface VerificationChecklistItem {
  id: string;
  evidenceExpectationId: string;
  description: string;
  outcome: 'Met' | 'Not Met' | 'Not Applicable' | null;
  notes: string;
  linkedEvidenceIds: string[];
}
```

### 6.5 Citation Case Reporting Wizard (4 Steps)

**Step 1: Basic Information**
- Title (required)
- Description
- Origin type (required)
- Facility (required)
- Department (required)
- Reporter name (auto-filled)

**Step 2: Select Citation**
- Citation picker with search/filter
- Quick view showing evidence expectations
- Version selection

**Step 3: Finding Details**
- Findings summary (required)
- Severity/Priority
- Tags
- **CONSTRAINT:** No attachments at this step

**Step 4: Evidence & Assignment**
- Evidence upload with sensitivity tagging
- Assign owner (required)
- Set triage due date
- Set remediation due date
- Cross-microapp linking

### 6.6 Triage Phase (Mandatory)

**Triage Decision Panel:**
1. Confirm/adjust citation selection and version
2. Set severity/priority with rationale
3. For TJC mode: Set SAFER-like fields (impact likelihood, scope prevalence)
4. Assign owner and QA reviewer
5. Set due dates
6. Choose remediation path:
   - Link existing Issue
   - Create new Issue
   - Link existing CAPA
   - Create new CAPA
   - Quick Fix (requires justification)

**Auto-escalation Rules:**
- If severity = High/Critical OR scope = Pattern/Widespread:
  - CAPA linkage required
  - OR Compliance Head override with documented justification

**On Triage Completion:**
- Status → "Remediation In Progress"
- Clock Card displayed showing countdown to due date

### 6.7 Clock Card Display

**PoC Mode (CMS/State):**
```
┌─────────────────────────────┐
│     📅 PoC Due: 5 DAYS      │
│   2567 Received: 12/10/24   │
│   Submission Due: 12/20/24  │
└─────────────────────────────┘
```

**ESC Mode (Joint Commission):**
```
┌─────────────────────────────┐
│    📅 ESC Due: 45 DAYS      │
│   Posted: 11/01/24          │
│   Submission Due: 12/31/24  │
└─────────────────────────────┘
```

**Warning Thresholds:**
- PoC: 7, 3, 1 days
- ESC: 14, 7, 3 days

### 6.8 QA Verification

**Auto-generated Checklist:**
- Based on linked Citation's evidence expectations
- Each item: Met / Not Met / Not Applicable
- Notes field per item
- Link evidence to each checklist item

**Verification Outcomes:**
1. **Pass** - Unblocks closure workflow
2. **Fail** - Returns to Remediation In Progress with required comments
3. **Escalate** - Requires CAPA creation/linkage if systemic issue discovered

### 6.9 Closure Requirements

- QA Verification must pass
- For PoC mode: PoC section completed and submitted
- For ESC mode: ESC package completed and submitted
- OR: Closure reason with documented override (Compliance Head/Admin only)

---

## 7. Module D: ActionGuard (CAPA)

### 7.1 Overview
Healthcare-grade Corrective and Preventive Action management aligned with CMS Plan of Correction, Joint Commission ESC, and 21 CFR 820.100 requirements.

### 7.2 CAPA Status Lifecycle

```
┌───────┐    ┌───────────┐    ┌───────────┐    ┌──────────┐
│ Draft │───►│ Submitted │───►│ In Review │───►│ Approved │
└───────┘    └───────────┘    └─────┬─────┘    └────┬─────┘
                                    │               │
                    ┌───────────────┘               │
                    ▼                               ▼
            ┌───────────────┐              ┌─────────────┐
            │Request Changes│              │ In Progress │
            │ (→ Draft)     │              └──────┬──────┘
            └───────────────┘                     │
                                                  ▼
┌──────────┐    ┌─────────────────────┐    ┌──────────────┐
│  Closed  │◄───│Effectiveness Monitor│◄───│ Verification │
└────┬─────┘    └─────────────────────┘    └──────────────┘
     │
     ▼
┌──────────┐
│ Reopened │ (if effectiveness fails or recurrence detected)
└──────────┘
```

### 7.3 CAPA Bucket Groupings

| Bucket | Statuses | Sort Order |
|--------|----------|------------|
| **NEW** | Draft, Submitted, In Review | Newest first, then review SLA due soon |
| **OPEN** | Approved, In Progress, Verification, Effectiveness Monitoring, Reopened | Overdue first, then due soon, then severity |
| **CLOSED** | Closed | Recently closed first |

### 7.4 CAPA Origin Types (LTC-Specific)

1. CMS/State Survey Deficiency (CMS-2567)
2. Internal Audit/Mock Survey Finding
3. Resident Incident/Near Miss
4. Abuse/Neglect Allegation (internal)
5. Complaint/Grievance
6. Infection Prevention/Outbreak
7. Medication Error/Pharmacy
8. Dietary/Kitchen
9. Life Safety/Environment of Care
10. Staffing/Competency
11. Documentation/Records
12. Policy/Procedure Gap
13. Other

### 7.5 CAPA Data Model

```typescript
interface Capa {
  id: string;
  title: string;
  
  // Template & Origin
  templateId: string;
  originType: CapaOriginType;
  
  // Problem Statement
  problemStatement: string;
  
  // Organization context
  organizationId: string;
  facilityId: string;
  departmentId: string;
  
  // Status & Workflow
  status: 'Draft' | 'Submitted' | 'In Review' | 'Approved' | 'In Progress' | 'Verification' | 'Effectiveness Monitoring' | 'Closed' | 'Reopened';
  bucket: 'NEW' | 'OPEN' | 'CLOSED';
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  
  // People
  ownerId: string;
  ownerName: string;
  createdBy: string;
  
  // Dates
  createdAt: string;
  updatedAt: string;
  dueDate: string;
  approvedAt?: string;
  closedAt?: string;
  
  // CMS/State Survey specific (PoC mode)
  cms2567ReceivedDate?: string;
  pocDueDate?: string;  // calculated: received + 10 days
  ftag?: string;
  scopeSeverity?: string; // A-L
  pocSubmissionDate?: string;
  pocAcceptedStatus?: 'Pending' | 'Accepted' | 'Returned';
  
  // PoC Required Elements (CMS/State origin)
  pocElements?: {
    correctiveActionForAffected: string;
    identifyAndCorrectOthers: string;
    systemicChangesToPrevent: string;
    monitoringPlan: {
      what: string;
      frequency: string;
      whoReviews: string;
      escalationRules: string;
    };
    completionDates: string;
  };
  
  // Containment/Immediate Correction
  containmentActions: ContainmentAction[];
  
  // Root Cause Analysis
  rca: RootCauseAnalysis;
  
  // Actions
  correctiveActions: CapaAction[];
  preventiveActions: CapaAction[];
  
  // Verification
  verificationEntries: VerificationEntry[];
  
  // Effectiveness Monitoring
  effectivenessMonitoring: {
    kpiId: string;
    kpiName: string;
    baselineValue: number;
    targetValue: number;
    monitoringDurationDays: number;
    monitoringFrequency: string;
    entries: MonitoringEntry[];
    result?: 'Pass' | 'Fail';
  };
  
  // Management Review
  managementReview?: {
    signedBy: string;
    signedDate: string;
    signoffNotes: string;
  };
  
  // Closure
  closureReason?: string;
  closureJustification?: string;
  
  // Connections
  linkedIssueIds: string[];
  linkedCitationIds: string[];
  linkedCitationCaseIds: string[];
  
  // Audit
  auditLog: AuditLogEntry[];
  comments: CapaComment[];
}

interface ContainmentAction {
  id: string;
  description: string;
  completedAt?: string;
  completedBy?: string;
  evidence: Attachment[];
}

interface RootCauseAnalysis {
  method: '5 Whys' | 'Fishbone' | 'Pareto' | 'Fault Tree' | 'FMEA';
  contributingFactors: {
    category: 'People' | 'Process' | 'Technology' | 'Environment' | 'Policy';
    factor: string;
    description: string;
  }[];
  rootCauses: {
    id: string;
    description: string;
    isPrimary: boolean;
  }[];
  analysisNotes: string;
  evidence: Attachment[];
}

interface CapaAction {
  id: string;
  actionType: CapaActionType;
  title: string;
  description: string;
  ownerId: string;
  ownerName: string;
  dueDate: string;
  dependsOn?: string; // action id
  status: 'Not Started' | 'In Progress' | 'Blocked' | 'Done' | 'Cancelled';
  evidenceRequired: boolean;
  evidenceType?: string;
  verificationMethod?: 'Verification' | 'Validation' | 'Both';
  evidence: Attachment[];
  verificationEvidence: Attachment[];
  completedAt?: string;
  completedBy?: string;
}

interface MonitoringEntry {
  id: string;
  date: string;
  metricValue: number;
  notes: string;
  evidence: Attachment[];
}
```

### 7.6 CAPA Action Types (LTC-Specific)

1. Policy/Procedure Update
2. Training/Competency Validation
3. Workflow/Process Change
4. Technology/System Change
5. Staffing/Role Clarification
6. Audit/Monitoring Implementation
7. Environment/Safety Fix
8. Infection Prevention Control Change
9. Medication Management Change
10. Dietary/Resident Nutrition Change
11. Documentation/Charting Change
12. Resident/Family Communication
13. Other

### 7.7 CAPA Creation Wizard (6 Steps)

**Step 1: Basics & Template**
- Title (required)
- Origin type (required)
- Facility/Department
- Severity
- Template selection:
  - CMS/State Survey Deficiency (PoC-aligned)
  - Joint Commission ESC
  - General CAPA

**Step 2: Containment/Immediate Correction**
- Add containment actions
- Mark completed with evidence
- Optional for non-survey origins

**Step 3: Root Cause Analysis**
- Select RCA method
- Document contributing factors by category
- Identify root causes (mark primary)
- Analysis notes
- Upload supporting evidence

**Step 4: Action Plan**
- Add corrective actions
- Add preventive actions
- For each action:
  - Type, title, description
  - Owner, due date
  - Dependencies
  - Evidence required toggle
  - Verification method

**Step 5: Monitoring & Effectiveness**
- Select effectiveness KPI
- Set baseline and target values
- Define monitoring duration and frequency
- For CMS/State origin: Complete PoC elements

**Step 6: Review & Submit**
- Summary view
- Validation checks
- Submit for review

### 7.8 CAPA Detail Page

**Tabs (with full CRUD):**
- **Overview** - Summary, status, key dates, mode banner
- **Containment** - Immediate actions taken
- **RCA** - Root cause analysis with method and factors
- **Actions** - Corrective and preventive actions list
- **Verification** - Action verification evidence
- **Effectiveness** - KPI monitoring entries and trend
- **QAPI** - Quality assurance review (if applicable)
- **History** - Audit trail (read-only)
- **Files** - Evidence repository (read-only)

**Right Action Rail:**
- Status badge with bucket indicator
- Owner
- Due date with clock (if PoC mode)
- Severity
- Quick actions based on status
- Phase transition buttons

### 7.9 CAPA Status Transitions

| From | To | Requirements | Gate |
|------|-----|--------------|------|
| Draft | Submitted | Title, problem statement, dept, severity, owner, due date, ≥1 root cause, ≥1 action | Auto |
| Submitted | In Review | Auto-transition | Auto |
| In Review | Approved | Approver decision | Dept Head+ |
| In Review | Draft (Request Changes) | Comments required | Dept Head+ |
| Approved | In Progress | Auto-transition | Auto |
| In Progress | Verification | All required actions Done OR Compliance Head override | Gate |
| Verification | Effectiveness Monitoring | Verification evidence complete OR override | Gate |
| Effectiveness Monitoring | Closed | effectiveness_result = Pass AND Management Review sign-off AND (if CMS/State) PoC submitted | Gate |
| Any post-Approved | Reopened | Effectiveness fails or recurrence detected | Compliance Head+ |

### 7.10 Management Review Requirement

**Required for:**
- All CAPAs with High or Critical severity
- All CAPAs with origin_type = CMS/State Survey Deficiency

**Sign-off Fields:**
- Signed by (Compliance Head)
- Signed date
- Sign-off notes

**Override:**
- Admin or Compliance Head can override with:
  - Documented patient risk rationale
  - Ongoing monitoring plan

### 7.11 Phase Transition Dialogs

Each transition uses a confirmation dialog with:
- Confirmation message describing the transition
- Optional comments field
- Reminder to use Ownership section for reassignment
- Confirm/Cancel buttons

---

## 8. Module E: Enterprise Reporting & Analytics

### 8.1 Overview
Cross-module reporting covering Issues, CAPAs, and Citations with interactive filters and CSV export.

### 8.2 Report Catalog Structure

**Executive / Cross-Suite:**
- R0: Executive Compliance Overview

**Compliance Items (Issues):**
- R1: Issues Inventory Report
- R2: Issues Aging & Bottlenecks
- R3: QA Review Outcomes

**CAPA (ActionGuard):**
- R4: CAPA Workload (NEW/OPEN/CLOSED)
- R5: Overdue CAPA Actions
- R6: CAPA Cycle Time & SLA
- R7: Verification & Effectiveness Outcomes

**Citations (Library + Cases):**
- R8: Citation Library Coverage
- R9: Citation Cases Operational Report
- R10: PoC/ESC Compliance Timeliness

**Cross-Module / Evidence:**
- R11: Evidence Coverage & Gaps
- R12: Repeat Findings / Trend Report

### 8.3 Report Detail Template

```
┌─────────────────────────────────────────────────────────────────────┐
│ [Filters Panel]  │                  Report Title                    │
│  Date Range      │  ┌─────────────────────────────────────────────┐ │
│  Facility        │  │            KPI Summary Cards                 │ │
│  Department      │  │  [Metric 1] [Metric 2] [Metric 3] [Metric 4]│ │
│  Owner           │  └─────────────────────────────────────────────┘ │
│  Status          │  ┌─────────────────────────────────────────────┐ │
│  Severity        │  │              Results Table                   │ │
│  Overdue Only    │  │  [Search] [Filter Chips] [Column Chooser]   │ │
│  [Apply Filters] │  │  ├──────┬──────┬──────┬──────┬──────┤       │ │
│                  │  │  │ Col1 │ Col2 │ Col3 │ Col4 │ Col5 │       │ │
│                  │  │  ├──────┼──────┼──────┼──────┼──────┤       │ │
│                  │  │  │ ...  │ ...  │ ...  │ ...  │ ...  │       │ │
│                  │  │  └──────┴──────┴──────┴──────┴──────┘       │ │
│                  │  │  [Pagination]              [Download CSV]   │ │
│                  │  └─────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────┘
```

### 8.4 Standard Filters

**Global (most reports):**
- Date range type: Created | Updated | Closed
- Facility/Location
- Department
- Owner/Assignee
- Status (multi-select)
- Severity/Priority (multi-select)
- Tags
- Overdue only (toggle)

**Domain-specific:**

| Domain | Additional Filters |
|--------|-------------------|
| Issues | Issue type, category, stage, monitoring destination, QA outcome |
| CAPA | Origin type, bucket, verification status, effectiveness result, PoC due overdue |
| Citations | Source, status, version, mapped/unmapped, missing evidence |
| Citation Cases | Mode (PoC/ESC/General), authority type, clock overdue, verification outcome |

### 8.5 CSV Export Requirements

**Export Contents:**
- Respects current filters, search, sort, selected columns
- Exports ALL rows (not just current page)
- Includes linked IDs (configurable)

**Export Metadata:**
```csv
# Report: Issues Inventory Report
# Exported: 2024-12-17T14:30:00Z
# User Role: Compliance Head
# Organization: Main Healthcare System
# Facility: All
# Filters: Status=In Progress, Priority=High
```

**File Naming:**
```
ComplianceConnect_<ReportName>_<YYYY-MM-DD>_<HHmm>.csv
```

### 8.6 Report Permissions

| Role | Access |
|------|--------|
| Admin | Org-wide, all reports |
| Compliance Head | Org-wide, all reports |
| Department Head | Department scope default, can filter within |
| Staff | Own items only (issues created/assigned, CAPAs owned, cases owned) |

### 8.7 Data Grid Standard

All report tables include:
- Search within results
- Filter chips
- Saved views (per role)
- Column chooser
- Sorting (click headers)
- Pagination (UI)
- Quick preview side panel (row click)
- Bulk export CSV

---

## 9. Module F: Admin Configuration

### 9.1 Overview
Centralized configuration management for all modules with draft/publish workflow and audit logging.

### 9.2 Admin Configuration Sections

| Section | Subsections |
|---------|-------------|
| **Compliance Issues** | Issue Types, Categories, Priorities, Workflow Settings, Recommended Actions, Monitoring Destinations |
| **CAPA (ActionGuard)** | Origin Types, Severity & SLAs, Templates, Action Types, RCA Methods, Verification, Effectiveness KPIs, Closure Rules |
| **Citations** | Sources, Jurisdictions, Facility Types, Evidence Types, Risk Domains, Versioning Rules |
| **Citation Cases** | Authority Mode Mappings, Timeliness Rules, Closure Reasons, Auto-escalation Rules |
| **Evidence & Attachments** | File Types, Sensitivity Tags, Requirements, Retention Labels |
| **Notifications** | Templates, Rules, Escalation Chains |
| **Reporting Settings** | Role Access, SLA Thresholds, Saved Views Retention |
| **Integrations** | EHR, HR Training, Document Repository (Coming Soon) |

### 9.3 Configuration UI Pattern

Each section includes:
- CRUD tables with Add/Edit/Delete
- Reorder capability where relevant
- Search within lists
- Inline validation
- Confirmation modals for destructive actions

### 9.4 Version Control

**Draft vs Published:**
- Changes saved as draft until published
- "Publish Changes" creates new config version
- Audit log entry for each publish

**Audit Log Fields:**
- Who changed
- What changed (section, item)
- When
- Old value → New value

### 9.5 Recommended Actions Configuration

**Rule Configuration:**
When adding/editing a recommended action, configure:
1. **Issue Type** (required) - When to show
2. **Category Rule** - All categories OR specific category
3. **Priority Condition** - Any priority OR specific priorities
4. **Default Owner Role** - Staff, Dept Head, Compliance Head, Admin
5. **Default Due Days** - Number of days
6. **Evidence Required** - Toggle
7. **Source URL** - Reference link
8. **Status** - Active/Inactive

### 9.6 CAPA Templates Configuration

Each template defines:
- Template name and description
- Required sections toggles:
  - Containment
  - RCA
  - Preventive Actions
  - Verification
  - Effectiveness Monitoring
  - Management Review
- Default action types
- Monitoring duration/frequency
- LTC indicator

**Pre-configured Templates:**
1. CMS/State Survey Deficiency (PoC-aligned) - All sections required
2. Joint Commission ESC - All sections required
3. General CAPA - Minimal requirements

---

## 10. Cross-Module Features

### 10.1 Connections Panel

Appears on all record detail pages (Issues, Citations, CAPAs, Citation Cases).

**Features:**
- Shows linked records from other modules
- Add/remove connections
- Navigate to linked records
- Audit log for link changes

**Connection Types:**
- Issue ↔ Citation(s)
- Issue ↔ CAPA(s)
- CAPA ↔ Citation(s)
- Citation ↔ Citation Case(s)
- Issue ↔ Citation Case(s)
- CAPA ↔ Citation Case(s)

### 10.2 Cross-Microapp References

External connections to MedComply platform modules:
- RiskGuard (risk items)
- AuditPro (audit findings)
- FeedbackHub (feedback items)
- EnforcementPoint (enforcement actions)

### 10.3 Evidence Manager (Shared)

Reusable component across all modules:
- Upload with metadata capture
- Sensitivity tagging (PHI, PII, Internal Only, Public)
- Link evidence to specific actions/expectations
- Redaction notes (mock implementation)
- Source/upload date/uploader tracking

### 10.4 PHI-Safe UX Defaults

**Warnings displayed near:**
- Free text fields
- Attachment uploads
- Evidence sections

**Warning text:**
```
⚠️ Do not include PHI/PII in this field. If sensitive information 
must be included, ensure proper authorization and mark attachments 
with appropriate sensitivity tags.
```

### 10.5 Multi-Tenant Context

All records include:
- Organization ID
- Facility ID
- Department ID

This enables:
- Data isolation
- Role-scoped visibility
- Facility/department filtering

---

## 11. Technical Requirements

### 11.1 Accessibility (WCAG 2.1 AA)

**Mandatory:**
- Keyboard navigation for all interactive elements
- Focus states clearly visible
- ARIA labels on all controls
- Semantic HTML headings (single H1 per page)
- Skip-to-content links
- Color contrast ≥ 4.5:1 for text
- Form labels and error messages

### 11.2 Responsive Design

- Desktop-first design
- Tablet support (1024px+)
- Mobile support (768px+) for critical functions
- Collapsible sidebar

### 11.3 Performance

- Initial page load < 3s
- Navigation between views < 500ms
- Table pagination for large datasets
- Lazy loading for images/attachments

### 11.4 Security

**Authentication:**
- Role-based access control (RBAC)
- Session management
- Audit logging of all actions

**Data Protection:**
- PHI/PII handling warnings
- Sensitivity tagging
- Export logging

**Authorization:**
- Server-side permission checks
- Row-level security where applicable

### 11.5 Data Validation

**Client-side:**
- Required field validation
- Format validation (email, dates)
- Length limits

**Server-side:**
- Input sanitization
- Schema validation
- Business rule enforcement

---

## 12. Appendix

### 12.1 Glossary

| Term | Definition |
|------|------------|
| CAPA | Corrective and Preventive Action |
| CMS | Centers for Medicare & Medicaid Services |
| CMS-2567 | Statement of Deficiencies form used in surveys |
| DOH | Department of Health |
| ESC | Evidence of Standards Compliance (Joint Commission) |
| LTC | Long-Term Care |
| PoC | Plan of Correction |
| RCA | Root Cause Analysis |
| RLS | Row-Level Security |
| SAFER | Safety and functional evaluation with risks (Joint Commission) |
| SLA | Service Level Agreement |
| SNF | Skilled Nursing Facility |
| TJC | The Joint Commission |

### 12.2 Status Enumerations

**Issue Status:**
`Reported` → `Initiation` → `In Progress` → `QA Review` → `Completed`

**Citation Status:**
`Draft` → `Active` → `Deprecated` | `Superseded`

**Citation Case Status:**
`Draft` → `Reported` → `Triage` → `Remediation In Progress` → `QA Verification` → `Closed` → `Monitoring` | `Reopened`

**CAPA Status:**
`Draft` → `Submitted` → `In Review` → `Approved` → `In Progress` → `Verification` → `Effectiveness Monitoring` → `Closed` | `Reopened`

### 12.3 Color Coding Standards

| Severity/Priority | Color |
|-------------------|-------|
| Critical | Red (destructive) |
| High | Orange |
| Medium | Yellow |
| Low | Green |

| Status Type | Color |
|-------------|-------|
| Draft | Gray (secondary) |
| Active/Open | Blue (primary) |
| In Progress | Yellow |
| Complete/Closed | Green |
| Overdue | Red (destructive) |

### 12.4 Date Calculations

**PoC Due Date:**
```
poc_due_date = cms2567_received_date + 10 calendar days
```

**ESC Due Date:**
```
esc_due_date = authority_report_posted_date + 60 calendar days
```

**Warning Thresholds:**
- PoC: 7, 3, 1 days before due
- ESC: 14, 7, 3 days before due

### 12.5 Audit Log Entry Structure

```typescript
interface AuditLogEntry {
  id: string;
  recordType: 'Issue' | 'Citation' | 'CitationCase' | 'Capa' | 'Config';
  recordId: string;
  action: 'create' | 'update' | 'delete' | 'status_change' | 'link' | 'unlink' | 'upload' | 'export' | 'publish';
  field?: string;
  oldValue?: string;
  newValue?: string;
  performedBy: string;
  performedByName: string;
  performedAt: string;
  ipAddress?: string;
  userAgent?: string;
}
```

---

**Document Control:**
- Version: 2.0
- Author: ComplianceConnect Product Team
- Status: Approved
- Last Review: December 2024
- Next Review: March 2025
