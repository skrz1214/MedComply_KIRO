import { 
  ActionItem, 
  ReviewItem, 
  QuickStat, 
  KPIItem, 
  Alert, 
  MicroApp,
  OrgMember,
  Policy,
  KPIDefinition,
  KPIProposal,
  KPIAlert,
  KPIUpdate,
  GovernanceRule
} from '@/types/qa-dashboard';

export const mockActionItems: ActionItem[] = [
  {
    id: 'ACT-001',
    title: 'Review compliance documentation for Q2 2025',
    description: 'Complete review of all compliance documentation for Q2 audit preparation',
    type: 'compliance',
    priority: 'high',
    status: 'not-started',
    dueDate: '2025-01-15',
    owner: 'Sarah Chen',
    department: 'Quality Assurance',
    oversightBody: ['accreditation', 'cms'],
    domain: ['accreditation-readiness'],
    createdAt: '2025-01-01',
    updatedAt: '2025-01-01'
  },
  {
    id: 'ACT-002',
    title: 'Update risk assessment report',
    description: 'Quarterly risk assessment update for patient safety protocols',
    type: 'risk',
    priority: 'medium',
    status: 'in-progress',
    dueDate: '2025-01-16',
    owner: 'Sarah Chen',
    department: 'Quality Assurance',
    oversightBody: ['state-survey'],
    domain: ['patient-safety'],
    createdAt: '2024-12-20',
    updatedAt: '2025-01-10'
  },
  {
    id: 'ACT-003',
    title: 'Complete infection control audit findings',
    description: 'Review and document findings from infection control audit',
    type: 'audit',
    priority: 'high',
    status: 'pending-review',
    dueDate: '2025-01-12',
    owner: 'Michael Chen',
    department: 'Infection Control',
    oversightBody: ['cdc', 'state-survey'],
    domain: ['quality-improvement'],
    createdAt: '2024-12-15',
    updatedAt: '2025-01-08'
  },
  {
    id: 'ACT-004',
    title: 'Submit CAPA for medication errors',
    description: 'Develop and submit corrective action plan for medication administration errors',
    type: 'capa',
    priority: 'high',
    status: 'overdue',
    dueDate: '2025-01-05',
    owner: 'Emily Davis',
    department: 'Pharmacy',
    oversightBody: ['accreditation'],
    domain: ['patient-safety', 'quality-improvement'],
    createdAt: '2024-12-01',
    updatedAt: '2025-01-05'
  },
  {
    id: 'ACT-005',
    title: 'Review patient complaint trends',
    description: 'Analyze Q4 patient complaint data and identify improvement areas',
    type: 'feedback',
    priority: 'medium',
    status: 'in-progress',
    dueDate: '2025-01-20',
    owner: 'Robert Wilson',
    department: 'Patient Experience',
    oversightBody: ['cms'],
    domain: ['complaint-oversight'],
    createdAt: '2024-12-28',
    updatedAt: '2025-01-10'
  },
];

export const mockReviewItems: ReviewItem[] = [
  {
    id: 'REV-001',
    title: 'New policy draft – Patient Data Protection',
    type: 'policy',
    owner: 'Sarah Johnson',
    updatedDate: '2024-12-10',
    status: 'pending-review',
    department: 'Privacy & Security'
  },
  {
    id: 'REV-002',
    title: 'Quarterly Audit Results',
    type: 'audit',
    owner: 'Michael Chen',
    updatedDate: '2024-12-09',
    status: 'in-progress',
    department: 'Quality Assurance'
  },
  {
    id: 'REV-003',
    title: 'Staff Training Compliance Report',
    type: 'compliance',
    owner: 'Emily Davis',
    updatedDate: '2024-12-08',
    status: 'pending-review',
    department: 'Human Resources'
  },
  {
    id: 'REV-004',
    title: 'Annual Billing Compliance Assessment',
    type: 'compliance',
    owner: 'Robert Wilson',
    updatedDate: '2024-12-07',
    status: 'pending-review',
    department: 'Finance'
  },
  {
    id: 'REV-005',
    title: 'Infection Control Risk Mitigation Plan',
    type: 'risk',
    owner: 'Dr. Patricia Lee',
    updatedDate: '2024-12-06',
    status: 'pending-review',
    department: 'Infection Control'
  },
];

export const mockQuickStats: QuickStat[] = [
  { label: 'Total Open', value: 24, change: 3, trend: 'up' },
  { label: 'Pending Review', value: 12, change: -2, trend: 'down' },
  { label: 'Completed', value: 156, change: 8, trend: 'up' },
  { label: 'Overdue', value: 4, change: 1, trend: 'up' },
];

export const mockKPIs: KPIItem[] = [
  {
    id: 'KPI-001',
    name: 'Accreditation Readiness Score',
    value: 94,
    target: 95,
    unit: '%',
    formula: '(Met Standards / Total Standards) × 100',
    trend: 'up',
    status: 'at-risk'
  },
  {
    id: 'KPI-002',
    name: 'KPI Reporting Compliance',
    value: 88,
    target: 90,
    unit: '%',
    formula: '(Updated KPIs / Total KPIs) × 100',
    trend: 'up',
    status: 'at-risk'
  },
  {
    id: 'KPI-003',
    name: 'CAPA Closure Rate',
    value: 97,
    target: 100,
    unit: '%',
    formula: '(Closed on Time / Total CAPAs) × 100',
    trend: 'up',
    status: 'on-track'
  },
  {
    id: 'KPI-004',
    name: 'Audit SLA Compliance',
    value: 92,
    target: 95,
    unit: '%',
    formula: '(Audits Closed in SLA / Total Audits) × 100',
    trend: 'down',
    status: 'at-risk'
  },
  {
    id: 'KPI-005',
    name: 'Repeat Findings Rate',
    value: 2,
    target: 0,
    unit: '%',
    formula: '(Repeat Findings / Total Findings) × 100',
    trend: 'down',
    status: 'off-track'
  },
  {
    id: 'KPI-006',
    name: 'Survey Readiness Checklist',
    value: 89,
    target: 100,
    unit: '%',
    formula: '(Completed Items / Total Items) × 100',
    trend: 'up',
    status: 'at-risk'
  },
];

export const mockAlerts: Alert[] = [
  {
    id: 'ALT-001',
    title: 'Upcoming State Survey Window',
    type: 'warning',
    dueDate: '2025-02-15',
    description: 'State survey expected in 45 days'
  },
  {
    id: 'ALT-002',
    title: 'High-Severity CAPAs Overdue',
    type: 'danger',
    dueDate: '2025-01-10',
    description: '2 high-severity CAPAs past deadline'
  },
  {
    id: 'ALT-003',
    title: 'Citations Awaiting Response',
    type: 'warning',
    dueDate: '2025-01-20',
    description: '3 citations require POC submission'
  },
  {
    id: 'ALT-004',
    title: 'Repeated Audit Findings Cluster',
    type: 'info',
    description: 'Documentation deficiencies identified in 3+ audits'
  },
];

export const mockMicroApps: MicroApp[] = [
  {
    id: 'compliance-connect',
    name: 'ComplianceConnect',
    description: 'Compliance tracking & issues',
    icon: 'ClipboardCheck',
    route: '/complianceconnect',
    itemCount: 12
  },
  {
    id: 'feedback-hub',
    name: 'FeedbackHub',
    description: 'Feedback management',
    icon: 'MessageSquare',
    route: '/feedbackhub',
    itemCount: 8
  },
  {
    id: 'risk-guard',
    name: 'RiskGuard',
    description: 'Risk management',
    icon: 'Shield',
    route: '/riskguard',
    itemCount: 15
  },
  {
    id: 'audit-pro',
    name: 'AuditPro',
    description: 'Audit management',
    icon: 'FileSearch',
    route: '/auditpro',
    itemCount: 6
  },
  {
    id: 'enforce-point',
    name: 'EnforcePoint',
    description: 'Enforcement management',
    icon: 'Gavel',
    route: '/enforcepoint',
    itemCount: 4
  },
  {
    id: 'cita-pro',
    name: 'CitaPro',
    description: 'Citation management',
    icon: 'AlertTriangle',
    route: '/citapro',
    itemCount: 3
  },
];

export const mockOrgMembers: OrgMember[] = [
  {
    id: 'ORG-001',
    name: 'Dr. Patricia Lee',
    role: 'Chief Quality Officer',
    department: 'Quality Assurance',
    email: 'patricia.lee@healthcare.org',
    phone: '(555) 123-4567',
    status: 'active'
  },
  {
    id: 'ORG-002',
    name: 'Sarah Chen',
    role: 'QA Director',
    department: 'Quality Assurance',
    email: 'sarah.chen@healthcare.org',
    phone: '(555) 123-4568',
    status: 'active',
    reportsTo: 'ORG-001'
  },
  {
    id: 'ORG-003',
    name: 'Michael Chen',
    role: 'Senior QA Analyst',
    department: 'Quality Assurance',
    email: 'michael.chen@healthcare.org',
    status: 'active',
    reportsTo: 'ORG-002'
  },
  {
    id: 'ORG-004',
    name: 'Emily Davis',
    role: 'Compliance Specialist',
    department: 'Quality Assurance',
    email: 'emily.davis@healthcare.org',
    status: 'active',
    reportsTo: 'ORG-002'
  },
  {
    id: 'ORG-005',
    name: 'Robert Wilson',
    role: 'QA Analyst',
    department: 'Quality Assurance',
    email: 'robert.wilson@healthcare.org',
    status: 'active',
    reportsTo: 'ORG-003'
  },
];

export const mockPolicies: Policy[] = [
  {
    id: 'POL-001',
    name: 'Quality Management System Policy',
    category: 'Quality Assurance',
    lastUpdate: '2024-10-15',
    status: 'current',
    nextReviewDate: '2025-10-15',
    owner: 'Dr. Patricia Lee',
    department: 'Quality Assurance'
  },
  {
    id: 'POL-002',
    name: 'Patient Safety Event Reporting',
    category: 'Patient Safety',
    lastUpdate: '2024-08-20',
    status: 'current',
    nextReviewDate: '2025-08-20',
    owner: 'Sarah Chen',
    department: 'Quality Assurance'
  },
  {
    id: 'POL-003',
    name: 'Internal Audit Procedures',
    category: 'Audit',
    lastUpdate: '2024-06-01',
    status: 'under-review',
    nextReviewDate: '2025-01-01',
    owner: 'Michael Chen',
    department: 'Quality Assurance'
  },
  {
    id: 'POL-004',
    name: 'Corrective Action Guidelines',
    category: 'CAPA',
    lastUpdate: '2024-11-10',
    status: 'current',
    nextReviewDate: '2025-11-10',
    owner: 'Emily Davis',
    department: 'Quality Assurance'
  },
  {
    id: 'POL-005',
    name: 'Complaint Handling Procedure',
    category: 'Feedback',
    lastUpdate: '2024-03-15',
    status: 'expired',
    nextReviewDate: '2024-09-15',
    owner: 'Robert Wilson',
    department: 'Quality Assurance'
  },
];

export const mockKPIDefinitions: KPIDefinition[] = [
  {
    id: 'KPIDEF-001',
    name: 'Patient Satisfaction Score',
    description: 'Overall patient satisfaction rating from surveys',
    owner: 'Sarah Chen',
    department: 'Patient Care',
    category: 'Patient Experience',
    oversightBody: ['cms', 'accreditation'],
    standardFamily: ['patient-safety', 'clinical-measures'],
    metricType: 'percent',
    numerator: 'Satisfied Responses',
    denominator: 'Total Responses',
    formula: '(Satisfied Responses / Total Responses) × 100',
    dataSource: 'manual',
    target: 95,
    thresholds: { green: 90, yellow: 80, red: 70 },
    reportingCadence: 'monthly',
    scope: 'org-wide',
    evidenceRequired: true,
    status: 'published',
    currentValue: 92,
    lastUpdated: '2025-01-10',
    lastReviewDate: '2024-10-15',
    nextReviewDate: '2025-04-15',
    createdAt: '2024-01-01',
    updatedAt: '2025-01-10'
  },
  {
    id: 'KPIDEF-002',
    name: 'Staff Training Completion Rate',
    description: 'Percentage of required training completed by staff',
    owner: 'Emily Davis',
    department: 'Human Resources',
    category: 'Training & Development',
    oversightBody: ['accreditation', 'state-survey'],
    standardFamily: ['accreditation-standards', 'governance'],
    metricType: 'percent',
    numerator: 'Completed Training',
    denominator: 'Required Training',
    formula: '(Completed Training / Required Training) × 100',
    dataSource: 'integration',
    target: 100,
    thresholds: { green: 95, yellow: 85, red: 75 },
    reportingCadence: 'weekly',
    scope: 'org-wide',
    evidenceRequired: true,
    status: 'published',
    currentValue: 88,
    lastUpdated: '2025-01-12',
    lastReviewDate: '2024-11-01',
    nextReviewDate: '2025-05-01',
    createdAt: '2024-02-15',
    updatedAt: '2025-01-12'
  },
  {
    id: 'KPIDEF-003',
    name: 'Medication Error Rate',
    description: 'Rate of medication errors per 1000 patient days',
    owner: 'Dr. Patricia Lee',
    department: 'Patient Care',
    category: 'Patient Safety',
    oversightBody: ['accreditation', 'cms'],
    standardFamily: ['patient-safety', 'clinical-measures'],
    metricType: 'count',
    numerator: 'Medication Errors',
    denominator: '1000 Patient Days',
    formula: '(Medication Errors / Patient Days) × 1000',
    dataSource: 'manual',
    target: 0,
    thresholds: { green: 1, yellow: 3, red: 5 },
    reportingCadence: 'monthly',
    scope: 'org-wide',
    evidenceRequired: true,
    status: 'published',
    currentValue: 2,
    lastUpdated: '2025-01-08',
    createdAt: '2024-01-15',
    updatedAt: '2025-01-08'
  },
  {
    id: 'KPIDEF-004',
    name: 'Hand Hygiene Compliance',
    description: 'Percentage of hand hygiene protocol compliance observed',
    owner: 'Michael Chen',
    department: 'Infection Control',
    category: 'Infection Prevention',
    oversightBody: ['cdc', 'accreditation'],
    standardFamily: ['patient-safety'],
    metricType: 'percent',
    numerator: 'Compliant Observations',
    denominator: 'Total Observations',
    formula: '(Compliant / Total Observations) × 100',
    dataSource: 'manual',
    target: 95,
    thresholds: { green: 90, yellow: 80, red: 70 },
    reportingCadence: 'weekly',
    scope: 'department',
    evidenceRequired: false,
    status: 'published',
    currentValue: 94,
    lastUpdated: '2025-01-11',
    createdAt: '2024-03-01',
    updatedAt: '2025-01-11'
  },
  {
    id: 'KPIDEF-005',
    name: 'Budget Variance',
    description: 'Variance between actual and budgeted expenses',
    owner: 'Robert Wilson',
    department: 'Finance',
    category: 'Financial Performance',
    oversightBody: ['other'],
    standardFamily: ['governance'],
    metricType: 'percent',
    numerator: 'Actual Expenses - Budget',
    denominator: 'Budget',
    formula: '((Actual - Budget) / Budget) × 100',
    dataSource: 'integration',
    target: 0,
    thresholds: { green: 5, yellow: 10, red: 15 },
    reportingCadence: 'monthly',
    scope: 'org-wide',
    evidenceRequired: true,
    status: 'draft',
    createdAt: '2025-01-05',
    updatedAt: '2025-01-05'
  },
  {
    id: 'KPIDEF-006',
    name: 'Fall Rate per 1000 Patient Days',
    description: 'Number of patient falls per 1000 patient days',
    owner: 'Dr. Patricia Lee',
    department: 'Patient Care',
    category: 'Patient Safety',
    oversightBody: ['accreditation', 'cms'],
    standardFamily: ['patient-safety'],
    metricType: 'count',
    numerator: 'Total Falls',
    denominator: '1000 Patient Days',
    formula: '(Falls / Patient Days) × 1000',
    dataSource: 'manual',
    target: 0,
    thresholds: { green: 2, yellow: 4, red: 6 },
    reportingCadence: 'monthly',
    scope: 'org-wide',
    evidenceRequired: true,
    status: 'published',
    currentValue: 3,
    lastUpdated: '2025-01-10',
    createdAt: '2024-01-20',
    updatedAt: '2025-01-10'
  },
];

export const mockKPIProposals: KPIProposal[] = [
  {
    id: 'PROP-001',
    kpiName: 'Emergency Room Wait Time',
    department: 'Patient Care',
    category: 'Patient Experience',
    metricType: 'days',
    cadence: 'daily',
    target: 30,
    thresholds: { green: 30, yellow: 45, red: 60 },
    owner: 'Dr. Patricia Lee',
    evidenceRequired: false,
    rationale: 'Critical metric for patient satisfaction and accreditation requirements',
    dataSource: 'integration',
    oversightBody: ['accreditation', 'cms'],
    standardFamily: ['patient-safety', 'clinical-measures'],
    status: 'submitted',
    requestedBy: 'Sarah Chen',
    submittedDate: '2025-01-10',
    createdAt: '2025-01-08',
    updatedAt: '2025-01-10'
  },
  {
    id: 'PROP-002',
    kpiName: 'Employee Turnover Rate',
    department: 'Human Resources',
    category: 'Workforce Management',
    metricType: 'percent',
    cadence: 'quarterly',
    target: 10,
    thresholds: { green: 10, yellow: 15, red: 20 },
    owner: 'Emily Davis',
    evidenceRequired: true,
    rationale: 'Track workforce stability and identify retention issues',
    dataSource: 'integration',
    oversightBody: ['other'],
    standardFamily: ['governance'],
    status: 'under-review',
    requestedBy: 'Emily Davis',
    submittedDate: '2025-01-05',
    reviewer: 'Dr. Patricia Lee',
    createdAt: '2025-01-02',
    updatedAt: '2025-01-08'
  },
  {
    id: 'PROP-003',
    kpiName: 'Safety Drill Completion Rate',
    department: 'Health Safety & Life Safety',
    category: 'Safety Compliance',
    metricType: 'percent',
    cadence: 'monthly',
    target: 100,
    thresholds: { green: 95, yellow: 85, red: 75 },
    owner: 'Michael Chen',
    evidenceRequired: true,
    rationale: 'Required for accreditation and regulatory compliance',
    dataSource: 'manual',
    oversightBody: ['accreditation', 'state-survey'],
    standardFamily: ['accreditation-standards'],
    status: 'draft',
    requestedBy: 'Michael Chen',
    createdAt: '2025-01-12',
    updatedAt: '2025-01-12'
  },
];

export const mockKPIAlerts: KPIAlert[] = [
  {
    id: 'ALERT-001',
    type: 'breach',
    kpiId: 'KPIDEF-002',
    kpiName: 'Staff Training Completion Rate',
    department: 'Human Resources',
    severity: 'high',
    triggerDate: '2025-01-12',
    owner: 'Emily Davis',
    status: 'open',
    description: 'Current value 88% is below red threshold of 75%'
  },
  {
    id: 'ALERT-002',
    type: 'trending',
    kpiId: 'KPIDEF-006',
    kpiName: 'Fall Rate per 1000 Patient Days',
    department: 'Patient Care',
    severity: 'medium',
    triggerDate: '2025-01-11',
    owner: 'Dr. Patricia Lee',
    status: 'acknowledged',
    description: 'Trending toward yellow threshold over last 3 periods'
  },
  {
    id: 'ALERT-003',
    type: 'overdue-update',
    kpiId: 'KPIDEF-003',
    kpiName: 'Medication Error Rate',
    department: 'Patient Care',
    severity: 'medium',
    triggerDate: '2025-01-10',
    owner: 'Dr. Patricia Lee',
    status: 'open',
    description: 'KPI update overdue by 5 days'
  },
  {
    id: 'ALERT-004',
    type: 'missing-evidence',
    kpiId: 'KPIDEF-001',
    kpiName: 'Patient Satisfaction Score',
    department: 'Patient Care',
    severity: 'low',
    triggerDate: '2025-01-09',
    owner: 'Sarah Chen',
    status: 'open',
    description: 'Evidence pack incomplete for January reporting period'
  },
];

export const mockKPIUpdates: KPIUpdate[] = [
  {
    id: 'UPD-001',
    kpiId: 'KPIDEF-001',
    period: '2025-01',
    value: 92,
    submittedBy: 'Sarah Chen',
    submittedDate: '2025-01-10',
    evidenceStatus: 'incomplete',
    notes: 'Survey data from patient feedback system',
    thresholdResult: 'green'
  },
  {
    id: 'UPD-002',
    kpiId: 'KPIDEF-001',
    period: '2024-12',
    value: 91,
    submittedBy: 'Sarah Chen',
    submittedDate: '2024-12-10',
    evidenceStatus: 'complete',
    thresholdResult: 'green'
  },
  {
    id: 'UPD-003',
    kpiId: 'KPIDEF-002',
    period: '2025-01',
    value: 88,
    submittedBy: 'Emily Davis',
    submittedDate: '2025-01-12',
    evidenceStatus: 'complete',
    notes: 'New hire training pending',
    thresholdResult: 'yellow'
  },
];

export const mockGovernanceRules: GovernanceRule[] = [
  {
    id: 'GOV-001',
    name: 'Auto-create compliance issue on Red breach',
    description: 'When a KPI breaches the red threshold, automatically suggest creating a ComplianceConnect issue',
    enabled: true,
    category: 'auto-action'
  },
  {
    id: 'GOV-002',
    name: 'Create risk on repeat breach',
    description: 'If a KPI breaches threshold for 3+ consecutive periods, suggest creating a RiskGuard risk',
    enabled: true,
    category: 'auto-action'
  },
  {
    id: 'GOV-003',
    name: 'Evidence required for Patient Safety KPIs',
    description: 'All KPIs in Patient Safety category require evidence pack',
    enabled: true,
    category: 'requirement'
  },
  {
    id: 'GOV-004',
    name: 'Monthly KPI review cycle',
    description: 'All KPI definitions must be reviewed at least quarterly',
    enabled: false,
    category: 'requirement'
  },
];

export const kpiDepartments = [
  { id: 'org', name: 'Org-Level Quality Management', route: '/dashboards/department/qa/kpi-oversight/org' },
  { id: 'leadership', name: 'Leadership Quality Management', route: '/dashboards/department/qa/kpi-oversight/leadership' },
  { id: 'hr', name: 'Human Resource Quality Management', route: '/dashboards/department/qa/kpi-oversight/hr' },
  { id: 'marketing', name: 'Marketing Quality Management', route: '/dashboards/department/qa/kpi-oversight/marketing' },
  { id: 'finance', name: 'Finance Quality Management', route: '/dashboards/department/qa/kpi-oversight/finance' },
  { id: 'hsls', name: 'Health Safety & Life Safety Quality Management', route: '/dashboards/department/qa/kpi-oversight/hsls' },
  { id: 'patient-care', name: 'Patient Care Quality Management', route: '/dashboards/department/qa/kpi-oversight/patient-care' },
];

// Tab configurations for each section
export const riskTabs = [
  { id: 'all', label: 'All QA' },
  { id: 'accreditation', label: 'Accreditation Readiness', domain: 'accreditation-readiness' as const },
  { id: 'qi', label: 'Quality Improvement', domain: 'quality-improvement' as const },
  { id: 'cqm', label: 'Clinical Quality Measures', domain: 'clinical-quality-measures' as const },
  { id: 'policy', label: 'Policy Adherence', domain: 'policy-adherence' as const },
  { id: 'survey', label: 'Survey Readiness', domain: 'survey-readiness' as const },
  { id: 'safety', label: 'Patient Safety', domain: 'patient-safety' as const },
];

export const auditTabs = [
  { id: 'all', label: 'All QA' },
  { id: 'accreditation', label: 'Accreditation Audits', domain: 'accreditation-readiness' as const },
  { id: 'kpi', label: 'KPI Validation Audits', domain: 'kpi-governance' as const },
  { id: 'policy', label: 'Policy Adherence Audits', domain: 'policy-adherence' as const },
  { id: 'survey', label: 'Survey Readiness Audits', domain: 'survey-readiness' as const },
  { id: 'safety', label: 'Patient Safety Audits', domain: 'patient-safety' as const },
];

export const complianceTabs = [
  { id: 'all', label: 'All QA' },
  { id: 'accreditation', label: 'Accreditation Findings', domain: 'accreditation-readiness' as const },
  { id: 'qi', label: 'QI/PI Actions', domain: 'quality-improvement' as const },
  { id: 'policy', label: 'Policy Issues', domain: 'policy-adherence' as const },
  { id: 'survey', label: 'Survey Issues', domain: 'survey-readiness' as const },
  { id: 'kpi', label: 'KPI Exceptions', domain: 'kpi-governance' as const },
];

export const feedbackTabs = [
  { id: 'all', label: 'All QA' },
  { id: 'complaints', label: 'Patient Complaints', domain: 'complaint-oversight' as const },
  { id: 'concerns', label: 'Staff Concerns' },
  { id: 'suggestions', label: 'QI Suggestions', domain: 'quality-improvement' as const },
];

export const enforcementTabs = [
  { id: 'all', label: 'All QA' },
  { id: 'accreditation', label: 'Accreditation Enforcement', domain: 'accreditation-readiness' as const },
  { id: 'survey', label: 'Survey Enforcement', domain: 'survey-readiness' as const },
  { id: 'capa', label: 'CAPA Deadlines' },
];
