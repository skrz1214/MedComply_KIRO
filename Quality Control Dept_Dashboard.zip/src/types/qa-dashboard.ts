// QA Dashboard Types

export type Priority = 'high' | 'medium' | 'low';
export type Status = 'not-started' | 'in-progress' | 'pending-review' | 'completed' | 'overdue';

export type QADomain = 
  | 'accreditation-readiness'
  | 'quality-improvement'
  | 'patient-safety'
  | 'clinical-quality-measures'
  | 'policy-adherence'
  | 'survey-readiness'
  | 'quality-benchmarking'
  | 'kpi-governance'
  | 'complaint-oversight';

export type OversightBody = 
  | 'accreditation'
  | 'cms'
  | 'state-survey'
  | 'ocr'
  | 'cdc'
  | 'other';

export type StandardFamily = 
  | 'accreditation-standards'
  | 'qapi'
  | 'patient-safety'
  | 'clinical-measures'
  | 'governance'
  | 'environment-of-care'
  | 'patient-rights';

export type ItemType = 'risk' | 'audit' | 'compliance' | 'feedback' | 'enforcement' | 'capa' | 'citation' | 'policy';

export interface ActionItem {
  id: string;
  title: string;
  description?: string;
  type: ItemType;
  priority: Priority;
  status: Status;
  dueDate: string;
  owner: string;
  department: string;
  oversightBody?: OversightBody[];
  domain?: QADomain[];
  createdAt: string;
  updatedAt: string;
}

export interface ReviewItem {
  id: string;
  title: string;
  type: ItemType;
  owner: string;
  updatedDate: string;
  status: Status;
  department: string;
}

export interface QuickStat {
  label: string;
  value: number;
  change?: number;
  trend?: 'up' | 'down' | 'neutral';
}

export interface KPIItem {
  id: string;
  name: string;
  value: number;
  target: number;
  unit: '%' | 'days' | 'count' | 'score';
  formula: string;
  trend: 'up' | 'down' | 'neutral';
  status: 'on-track' | 'at-risk' | 'off-track';
}

export interface Alert {
  id: string;
  title: string;
  type: 'warning' | 'danger' | 'info';
  dueDate?: string;
  description?: string;
}

export interface MicroApp {
  id: string;
  name: string;
  description: string;
  icon: string;
  route: string;
  itemCount?: number;
}

export interface OrgMember {
  id: string;
  name: string;
  role: string;
  department: string;
  email: string;
  phone?: string;
  avatar?: string;
  status: 'active' | 'inactive';
  reportsTo?: string;
}

export interface Policy {
  id: string;
  name: string;
  category: string;
  lastUpdate: string;
  status: 'current' | 'under-review' | 'expired' | 'draft';
  nextReviewDate: string;
  owner: string;
  department: string;
}

export type KPIStatus = 'draft' | 'submitted' | 'under-review' | 'approved' | 'published' | 'retired';
export type ThresholdStatus = 'green' | 'yellow' | 'red';
export type KPIAlertType = 'breach' | 'trending' | 'overdue-update' | 'missing-evidence' | 'definition-review';
export type ProposalStatus = 'draft' | 'submitted' | 'under-review' | 'approved' | 'rejected' | 'published';

export interface KPIDefinition {
  id: string;
  name: string;
  description: string;
  owner: string;
  backupOwner?: string;
  department: string;
  category: string;
  oversightBody: OversightBody[];
  standardFamily: StandardFamily[];
  metricType: 'count' | 'percent' | 'days' | 'score';
  numerator?: string;
  denominator?: string;
  formula: string;
  dataSource: 'manual' | 'csv-upload' | 'integration';
  reportingCadence: 'daily' | 'weekly' | 'monthly' | 'quarterly';
  collectionDueRule?: string;
  target: number;
  thresholds: {
    green: number;
    yellow: number;
    red: number;
  };
  scope: 'org-wide' | 'facility' | 'department';
  evidenceRequired: boolean;
  evidenceTypes?: string[];
  status: KPIStatus;
  currentValue?: number;
  lastUpdated?: string;
  lastReviewDate?: string;
  nextReviewDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface KPIUpdate {
  id: string;
  kpiId: string;
  period: string;
  value: number;
  submittedBy: string;
  submittedDate: string;
  evidenceStatus: 'complete' | 'incomplete' | 'not-required';
  notes?: string;
  thresholdResult: ThresholdStatus;
}

export interface KPIProposal {
  id: string;
  kpiName: string;
  department: string;
  category: string;
  metricType: 'count' | 'percent' | 'days' | 'score';
  cadence: 'daily' | 'weekly' | 'monthly' | 'quarterly';
  target: number;
  thresholds: {
    green: number;
    yellow: number;
    red: number;
  };
  owner: string;
  backupOwner?: string;
  evidenceRequired: boolean;
  rationale: string;
  dataSource: 'manual' | 'csv-upload' | 'integration';
  oversightBody: OversightBody[];
  standardFamily: StandardFamily[];
  status: ProposalStatus;
  requestedBy: string;
  submittedDate?: string;
  reviewer?: string;
  reviewComments?: string;
  createdAt: string;
  updatedAt: string;
}

export interface KPIAlert {
  id: string;
  type: KPIAlertType;
  kpiId: string;
  kpiName: string;
  department: string;
  severity: 'high' | 'medium' | 'low';
  triggerDate: string;
  owner: string;
  status: 'open' | 'acknowledged' | 'resolved' | 'snoozed';
  description?: string;
}

export interface GovernanceRule {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  category: 'auto-action' | 'requirement' | 'threshold-template';
}

export interface TabConfig {
  id: string;
  label: string;
  domain?: QADomain;
}

export interface BreadcrumbItem {
  label: string;
  href?: string;
}
