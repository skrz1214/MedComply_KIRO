import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
        secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
        destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
        outline: "text-foreground",
        // Status variants for compliance dashboard
        high: "border-transparent bg-destructive text-destructive-foreground",
        medium: "border-transparent bg-warning text-warning-foreground",
        low: "border-transparent bg-success text-success-foreground",
        pending: "border-warning/30 bg-warning-muted text-warning",
        inProgress: "border-info/30 bg-info-muted text-info",
        completed: "border-success/30 bg-success-muted text-success",
        overdue: "border-destructive/30 bg-destructive-muted text-destructive",
        // Type badges
        policy: "border-transparent bg-info text-info-foreground",
        audit: "border-transparent bg-primary text-primary-foreground",
        compliance: "border-transparent bg-success text-success-foreground",
        training: "border-transparent bg-accent text-accent-foreground",
        risk: "border-transparent bg-warning text-warning-foreground",
        enforcement: "border-transparent bg-destructive text-destructive-foreground",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
