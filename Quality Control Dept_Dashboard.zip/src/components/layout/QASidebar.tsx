import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Shield, 
  FileSearch, 
  ClipboardCheck, 
  MessageSquare, 
  Gavel,
  Users,
  BarChart3,
  ChevronRight,
  Building2,
  Lock,
  FileText
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useRole } from '@/contexts/RoleContext';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface NavItem {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
  requiredPermission?: 'canViewAudits' | 'canViewCompliance' | 'canViewAllDepartments' | 'canViewOrgChart' | 'canViewAlerts';
}

const navItems: NavItem[] = [
  { label: 'Dashboard', href: '/dashboards/department/qa', icon: LayoutDashboard },
  { label: 'Org Chart', href: '/dashboards/department/qa/org-chart', icon: Users, requiredPermission: 'canViewOrgChart' },
  { label: 'KPI Oversight', href: '/dashboards/department/qa/kpi-oversight', icon: BarChart3 },
  { label: 'Risk Management', href: '/dashboards/department/qa/risks', icon: Shield },
  { label: 'Audit Management', href: '/dashboards/department/qa/audits', icon: FileSearch, requiredPermission: 'canViewAudits' },
  { label: 'Compliance Tracking', href: '/dashboards/department/qa/compliance', icon: ClipboardCheck, requiredPermission: 'canViewCompliance' },
  { label: 'Feedback Management', href: '/dashboards/department/qa/feedback', icon: MessageSquare },
  { label: 'Enforcement Management', href: '/dashboards/department/qa/enforcements', icon: Gavel, requiredPermission: 'canViewCompliance' },
  { label: 'Documents', href: '/dashboards/department/qa/documents', icon: FileText },
];

export function QASidebar() {
  const location = useLocation();
  const currentPath = location.pathname;
  const { permissions, roleLabel } = useRole();

  const isActive = (href: string) => {
    if (href === '/dashboards/department/qa') {
      return currentPath === href;
    }
    return currentPath.startsWith(href);
  };

  const hasPermission = (item: NavItem) => {
    if (!item.requiredPermission) return true;
    return permissions[item.requiredPermission];
  };

  return (
    <aside className="w-64 min-h-screen bg-sidebar border-r border-sidebar-border flex flex-col">
      {/* Logo/Brand Section */}
      <div className="p-4 border-b border-sidebar-border">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-sidebar-primary flex items-center justify-center">
            <Building2 className="h-5 w-5 text-sidebar-primary-foreground" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-sidebar-foreground">QA Compliance</span>
            <span className="text-xs text-sidebar-muted">Department Dashboard</span>
          </div>
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const active = isActive(item.href);
          const permitted = hasPermission(item);
          
          if (!permitted) {
            return (
              <Tooltip key={item.href}>
                <TooltipTrigger asChild>
                  <div
                    className={cn(
                      'nav-item opacity-50 cursor-not-allowed',
                      'text-sidebar-muted'
                    )}
                  >
                    <item.icon className="h-5 w-5 flex-shrink-0 text-sidebar-muted" />
                    <span className="flex-1 truncate">{item.label}</span>
                    <Lock className="h-3 w-3 text-sidebar-muted" />
                  </div>
                </TooltipTrigger>
                <TooltipContent side="right">
                  <p>Requires elevated permissions</p>
                </TooltipContent>
              </Tooltip>
            );
          }
          
          return (
            <Link
              key={item.href}
              to={item.href}
              className={cn(
                'nav-item group',
                active ? 'nav-item-active' : 'nav-item-default'
              )}
            >
              <item.icon className={cn(
                'h-5 w-5 flex-shrink-0',
                active ? 'text-sidebar-primary' : 'text-sidebar-muted group-hover:text-sidebar-foreground'
              )} />
              <span className="flex-1 truncate">{item.label}</span>
              {item.badge && (
                <span className="ml-auto bg-sidebar-primary text-sidebar-primary-foreground text-xs px-2 py-0.5 rounded-full">
                  {item.badge}
                </span>
              )}
              {active && (
                <ChevronRight className="h-4 w-4 text-sidebar-primary opacity-60" />
              )}
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-sidebar-accent flex items-center justify-center">
            <span className="text-sm font-medium text-sidebar-foreground">SC</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-sidebar-foreground truncate">Sarah Chen</p>
            <p className="text-xs text-sidebar-muted truncate">{roleLabel}</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
