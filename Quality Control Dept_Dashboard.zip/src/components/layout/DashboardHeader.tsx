import { useState } from 'react';
import { Search, Bell, Building2, ChevronDown } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { RoleImpersonator } from './RoleImpersonator';
import { useRole } from '@/contexts/RoleContext';

export function DashboardHeader() {
  const [facility, setFacility] = useState('All Facilities');
  const { roleLabel } = useRole();

  return (
    <header className="h-14 border-b border-border bg-card px-6 flex items-center justify-between gap-4">
      {/* Search */}
      <div className="flex-1 max-w-md">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            type="search" 
            placeholder="Search tasks, items, policies..." 
            className="pl-9 bg-background"
          />
        </div>
      </div>

      {/* Right side controls */}
      <div className="flex items-center gap-3">
        {/* Role Impersonator */}
        <RoleImpersonator />

        {/* Facility Selector */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="gap-2">
              <Building2 className="h-4 w-4" />
              {facility}
              <ChevronDown className="h-3 w-3 opacity-50" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => setFacility('All Facilities')}>
              All Facilities
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setFacility('Main Campus')}>
              Main Campus
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setFacility('North Clinic')}>
              North Clinic
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setFacility('South Clinic')}>
              South Clinic
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Notifications */}
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full" />
        </Button>

        {/* User Avatar */}
        <div className="flex items-center gap-2 pl-3 border-l border-border">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
            <span className="text-sm font-medium text-primary-foreground">SC</span>
          </div>
          <div className="hidden lg:block">
            <p className="text-sm font-medium">Sarah Chen</p>
            <p className="text-xs text-muted-foreground">{roleLabel}</p>
          </div>
        </div>
      </div>
    </header>
  );
}
