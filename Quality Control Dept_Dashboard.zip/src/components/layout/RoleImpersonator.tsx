import { UserCog, Shield, Building2, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { useRole, UserRole } from '@/contexts/RoleContext';
import { cn } from '@/lib/utils';

const roleIcons: Record<UserRole, typeof Shield> = {
  'admin': Shield,
  'department-head': Building2,
  'staff': User,
};

const roleColors: Record<UserRole, string> = {
  'admin': 'bg-primary/10 text-primary border-primary/20',
  'department-head': 'bg-warning/10 text-warning border-warning/20',
  'staff': 'bg-muted text-muted-foreground border-border',
};

export function RoleImpersonator() {
  const { currentRole, setCurrentRole, roleLabel, allRoles, getRoleLabel, assignedDepartment } = useRole();
  const CurrentIcon = roleIcons[currentRole];

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <UserCog className="h-4 w-4" />
          <span className="hidden sm:inline">Viewing as:</span>
          <Badge variant="outline" className={cn("font-medium", roleColors[currentRole])}>
            <CurrentIcon className="h-3 w-3 mr-1" />
            {roleLabel}
          </Badge>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        <DropdownMenuLabel className="flex items-center gap-2">
          <UserCog className="h-4 w-4" />
          Role Impersonation
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <p className="px-2 py-1.5 text-xs text-muted-foreground">
          Switch roles to preview different access levels
        </p>
        <DropdownMenuSeparator />
        {allRoles.map((role) => {
          const Icon = roleIcons[role];
          const isActive = currentRole === role;
          return (
            <DropdownMenuItem
              key={role}
              onClick={() => setCurrentRole(role)}
              className={cn(
                "flex items-center gap-3 cursor-pointer",
                isActive && "bg-muted"
              )}
            >
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center",
                roleColors[role]
              )}>
                <Icon className="h-4 w-4" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-sm">{getRoleLabel(role)}</p>
                <p className="text-xs text-muted-foreground">
                  {role === 'admin' && 'Full system access'}
                  {role === 'department-head' && 'QA Department management'}
                  {role === 'staff' && 'Limited view access'}
                </p>
              </div>
              {isActive && (
                <Badge variant="secondary" className="text-xs">Active</Badge>
              )}
            </DropdownMenuItem>
          );
        })}
        {assignedDepartment && currentRole !== 'admin' && (
          <>
            <DropdownMenuSeparator />
            <div className="px-2 py-2 text-xs text-muted-foreground">
              <span className="font-medium">Assigned Department:</span>{' '}
              <Badge variant="outline" className="ml-1">QA Department</Badge>
            </div>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
