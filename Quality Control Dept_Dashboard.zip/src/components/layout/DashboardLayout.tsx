import { Outlet } from 'react-router-dom';
import { QASidebar } from './QASidebar';
import { DashboardHeader } from './DashboardHeader';
import { Breadcrumbs } from './Breadcrumbs';
import { BreadcrumbItem } from '@/types/qa-dashboard';

interface DashboardLayoutProps {
  children?: React.ReactNode;
  breadcrumbs?: BreadcrumbItem[];
}

export function DashboardLayout({ children, breadcrumbs }: DashboardLayoutProps) {
  return (
    <div className="min-h-screen flex w-full bg-background">
      <QASidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <DashboardHeader />
        <div className="px-6 py-3 border-b border-border bg-card">
          <Breadcrumbs items={breadcrumbs} />
        </div>
        <main className="flex-1 p-6 overflow-auto">
          {children || <Outlet />}
        </main>
      </div>
    </div>
  );
}
