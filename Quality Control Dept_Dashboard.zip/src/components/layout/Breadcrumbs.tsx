import { Link, useLocation } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';
import { BreadcrumbItem } from '@/types/qa-dashboard';

interface BreadcrumbsProps {
  items?: BreadcrumbItem[];
}

const defaultBreadcrumbs: BreadcrumbItem[] = [
  { label: 'Home', href: '/' },
  { label: 'Dashboards', href: '/dashboards' },
  { label: 'Department', href: '/dashboards/department' },
  { label: 'Quality Assurance' }
];

export function Breadcrumbs({ items = defaultBreadcrumbs }: BreadcrumbsProps) {
  return (
    <nav className="flex items-center gap-1 text-sm" aria-label="Breadcrumb">
      <Link to="/" className="breadcrumb-link flex items-center gap-1 hover:text-primary transition-colors">
        <Home className="h-4 w-4" />
      </Link>
      {items.slice(1).map((item, index) => (
        <div key={index} className="flex items-center gap-1">
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
          {item.href ? (
            <Link to={item.href} className="breadcrumb-link hover:text-primary transition-colors">
              {item.label}
            </Link>
          ) : (
            <span className="breadcrumb-current">{item.label}</span>
          )}
        </div>
      ))}
    </nav>
  );
}
