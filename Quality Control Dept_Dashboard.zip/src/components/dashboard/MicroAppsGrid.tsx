import { Link } from 'react-router-dom';
import { 
  ClipboardCheck, 
  MessageSquare, 
  Shield, 
  FileSearch, 
  Gavel, 
  AlertTriangle,
  ChevronRight
} from 'lucide-react';
import { MicroApp } from '@/types/qa-dashboard';
import { mockMicroApps } from '@/data/mock-data';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  'ClipboardCheck': ClipboardCheck,
  'MessageSquare': MessageSquare,
  'Shield': Shield,
  'FileSearch': FileSearch,
  'Gavel': Gavel,
  'AlertTriangle': AlertTriangle,
};

export function MicroAppsGrid() {
  return (
    <div className="dashboard-card">
      <div className="p-4 border-b border-border">
        <h2 className="text-lg font-semibold">Quick Access</h2>
        <p className="text-sm text-muted-foreground mt-1">Jump to microapps</p>
      </div>
      <div className="p-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {mockMicroApps.map((app) => (
          <MicroAppTile key={app.id} app={app} />
        ))}
      </div>
    </div>
  );
}

function MicroAppTile({ app }: { app: MicroApp }) {
  const Icon = iconMap[app.icon] || ClipboardCheck;
  
  return (
    <Link 
      to={`${app.route}?from=qa-dashboard&dept=qa`}
      className="microapp-tile group"
    >
      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
        <Icon className="h-6 w-6 text-primary" />
      </div>
      <div className="text-center">
        <h3 className="text-sm font-medium text-foreground">{app.name}</h3>
        <p className="text-xs text-muted-foreground">{app.description}</p>
      </div>
      {app.itemCount !== undefined && (
        <span className="absolute top-2 right-2 flex items-center justify-center h-5 min-w-5 px-1.5 rounded-full bg-primary text-primary-foreground text-xs font-medium">
          {app.itemCount}
        </span>
      )}
    </Link>
  );
}
