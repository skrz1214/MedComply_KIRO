import { TrendingUp, TrendingDown, Minus, AlertTriangle } from 'lucide-react';
import { QuickStat } from '@/types/qa-dashboard';
import { mockQuickStats } from '@/data/mock-data';
import { cn } from '@/lib/utils';

export function QuickStats() {
  return (
    <div className="dashboard-card p-4">
      <h2 className="text-lg font-semibold mb-4">Quick Stats</h2>
      <div className="space-y-3">
        {mockQuickStats.map((stat, index) => (
          <StatCard key={index} stat={stat} />
        ))}
      </div>
    </div>
  );
}

function StatCard({ stat }: { stat: QuickStat }) {
  const isOverdue = stat.label === 'Overdue';
  
  return (
    <div className={cn(
      'stat-card flex items-center justify-between',
      isOverdue && stat.value > 0 && 'border-destructive/30 bg-destructive-muted'
    )}>
      <div className="flex items-center gap-3">
        {isOverdue && stat.value > 0 && (
          <AlertTriangle className="h-4 w-4 text-destructive" />
        )}
        <span className="text-sm text-muted-foreground">{stat.label}</span>
      </div>
      <div className="flex items-center gap-2">
        <span className={cn(
          'text-xl font-bold',
          isOverdue && stat.value > 0 ? 'text-destructive' : 'text-foreground'
        )}>
          {stat.value}
        </span>
        {stat.change !== undefined && stat.change !== 0 && (
          <span className={cn(
            'flex items-center text-xs font-medium',
            stat.trend === 'up' && !isOverdue && 'text-success',
            stat.trend === 'down' && !isOverdue && 'text-destructive',
            stat.trend === 'up' && isOverdue && 'text-destructive',
            stat.trend === 'down' && isOverdue && 'text-success'
          )}>
            {stat.trend === 'up' ? (
              <TrendingUp className="h-3 w-3 mr-0.5" />
            ) : stat.trend === 'down' ? (
              <TrendingDown className="h-3 w-3 mr-0.5" />
            ) : (
              <Minus className="h-3 w-3 mr-0.5" />
            )}
            {stat.change > 0 ? '+' : ''}{stat.change}
          </span>
        )}
      </div>
    </div>
  );
}
