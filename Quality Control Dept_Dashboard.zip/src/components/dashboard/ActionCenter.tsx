import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Clock, User, ChevronRight, ClipboardCheck, MessageSquare, Shield, FileSearch, Gavel, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ActionItem } from '@/types/qa-dashboard';
import { mockActionItems, mockMicroApps } from '@/data/mock-data';
import { cn } from '@/lib/utils';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  'ClipboardCheck': ClipboardCheck,
  'MessageSquare': MessageSquare,
  'Shield': Shield,
  'FileSearch': FileSearch,
  'Gavel': Gavel,
  'AlertTriangle': AlertTriangle,
};
const tabs = [
  { id: 'today', label: 'Today' },
  { id: 'week', label: 'This Week' },
  { id: 'overdue', label: 'Overdue' },
];

const typeFilters = [
  { id: 'all', label: 'All Types' },
  { id: 'risk', label: 'Risk' },
  { id: 'audit', label: 'Audit' },
  { id: 'compliance', label: 'Compliance' },
  { id: 'feedback', label: 'Feedback' },
  { id: 'enforcement', label: 'Enforcement' },
];

function getPriorityVariant(priority: string) {
  switch (priority) {
    case 'high': return 'high';
    case 'medium': return 'medium';
    case 'low': return 'low';
    default: return 'secondary';
  }
}

function getStatusVariant(status: string) {
  switch (status) {
    case 'not-started': return 'secondary';
    case 'in-progress': return 'inProgress';
    case 'pending-review': return 'pending';
    case 'completed': return 'completed';
    case 'overdue': return 'overdue';
    default: return 'secondary';
  }
}

function formatStatus(status: string) {
  return status.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

function formatDueDate(date: string) {
  const dueDate = new Date(date);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  if (dueDate.toDateString() === today.toDateString()) return 'Due Today';
  if (dueDate.toDateString() === tomorrow.toDateString()) return 'Due Tomorrow';
  if (dueDate < today) return 'Overdue';
  
  return `Due ${dueDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`;
}

export function ActionCenter() {
  const [activeTab, setActiveTab] = useState('today');
  const [showMeOnly, setShowMeOnly] = useState(true);
  const [typeFilter, setTypeFilter] = useState('all');

  // Filter items based on selections
  const filteredItems = mockActionItems.filter(item => {
    if (typeFilter !== 'all' && item.type !== typeFilter) return false;
    return true;
  });

  return (
    <div className="dashboard-card">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Action Center</h2>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-2">
                <Plus className="h-4 w-4" />
                Add Action Item
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Add Action Item</DialogTitle>
              </DialogHeader>
              <p className="text-sm text-muted-foreground mb-4">
                Select a microapp to create a new action item:
              </p>
              <div className="grid grid-cols-2 gap-3">
                {mockMicroApps.map((app) => {
                  const Icon = iconMap[app.icon] || ClipboardCheck;
                  return (
                    <Link
                      key={app.id}
                      to={`${app.route}/new?from=qa-dashboard&dept=qa`}
                      className="flex items-center gap-3 p-3 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-colors group"
                    >
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="text-sm font-medium text-foreground">{app.name}</h3>
                        <p className="text-xs text-muted-foreground truncate">{app.description}</p>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters Row */}
        <div className="flex items-center gap-3">
          {/* Me/All Toggle */}
          <div className="flex rounded-full bg-muted p-0.5">
            <button
              onClick={() => setShowMeOnly(true)}
              className={cn(
                'dashboard-tab',
                showMeOnly ? 'dashboard-tab-active' : 'dashboard-tab-default'
              )}
            >
              Me
            </button>
            <button
              onClick={() => setShowMeOnly(false)}
              className={cn(
                'dashboard-tab',
                !showMeOnly ? 'dashboard-tab-active' : 'dashboard-tab-default'
              )}
            >
              All
            </button>
          </div>

          {/* Type Filter */}
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="h-9 px-3 rounded-md border border-input bg-background text-sm"
          >
            {typeFilters.map(filter => (
              <option key={filter.id} value={filter.id}>{filter.label}</option>
            ))}
          </select>

          {/* Search */}
          <input
            type="text"
            placeholder="Search tasks"
            className="flex-1 h-9 px-3 rounded-md border border-input bg-background text-sm"
          />
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4 pt-3 flex gap-2 border-b border-border">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              'px-4 py-2 text-sm font-medium border-b-2 -mb-px transition-colors',
              activeTab === tab.id
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Action Items List */}
      <div className="p-4 space-y-3 stagger-children">
        {filteredItems.map((item) => (
          <ActionItemCard key={item.id} item={item} />
        ))}
      </div>
    </div>
  );
}

function ActionItemCard({ item }: { item: ActionItem }) {
  return (
    <Link 
      to={`/dashboards/department/qa/${item.type}s/${item.id}`}
      className="action-item block group"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <h3 className="font-medium text-foreground group-hover:text-primary transition-colors mb-1.5">
            {item.title}
          </h3>
          <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              {formatDueDate(item.dueDate)}
            </span>
            <span className="flex items-center gap-1">
              <User className="h-3.5 w-3.5" />
              {item.owner}
            </span>
            <Badge variant={getPriorityVariant(item.priority) as any} className="capitalize">
              {item.priority}
            </Badge>
            <Badge variant={getStatusVariant(item.status) as any}>
              {formatStatus(item.status)}
            </Badge>
          </div>
        </div>
        <ChevronRight className="h-5 w-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
      </div>
    </Link>
  );
}
