import { useState } from 'react';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { kpiDepartments } from '@/data/mock-data';
import { toast } from 'sonner';

interface KPIFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  departmentContext?: string;
}

const categories = [
  'Quality Improvement',
  'Patient Safety',
  'Clinical Outcomes',
  'Operational Efficiency',
  'Staff Performance',
  'Compliance',
  'Financial',
];

const oversightTags = [
  'Accreditation',
  'CMS',
  'State Survey/DOH',
  'OCR',
  'CDC',
  'Other',
];

const standardFamilyTags = [
  'Quality Improvement',
  'Patient Safety',
  'Measures',
  'Governance',
  'Other',
];

export function KPIForm({ open, onOpenChange, departmentContext }: KPIFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    department: departmentContext || '',
    category: '',
    metricType: 'percent',
    numeratorDefinition: '',
    denominatorDefinition: '',
    formulaText: '',
    dataSource: 'manual',
    reportingCadence: 'monthly',
    collectionDueDateRule: '',
    owner: '',
    backupOwner: '',
    targetValue: '',
    greenThreshold: '',
    yellowThreshold: '',
    redThreshold: '',
    scope: 'department',
    evidenceRequired: false,
    oversightTags: [] as string[],
    standardFamilyTags: [] as string[],
    rationale: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('KPI created successfully');
    onOpenChange(false);
  };

  const handleTagToggle = (tag: string, type: 'oversight' | 'standardFamily') => {
    const key = type === 'oversight' ? 'oversightTags' : 'standardFamilyTags';
    setFormData(prev => ({
      ...prev,
      [key]: prev[key].includes(tag)
        ? prev[key].filter(t => t !== tag)
        : [...prev[key], tag]
    }));
  };

  const updateFormulaText = (numerator: string, denominator: string) => {
    if (numerator && denominator) {
      setFormData(prev => ({
        ...prev,
        formulaText: `(${numerator} / ${denominator}) × 100`
      }));
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Create New KPI</SheetTitle>
          <SheetDescription>
            Define a new Key Performance Indicator with targets and thresholds
          </SheetDescription>
          {departmentContext && (
            <div className="flex items-center gap-2 mt-2">
              <Badge variant="secondary" className="text-xs">Department Context</Badge>
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                {kpiDepartments.find(d => d.id === departmentContext)?.name || departmentContext}
              </Badge>
            </div>
          )}
        </SheetHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Basic Information</h3>
            
            <div className="space-y-2">
              <Label htmlFor="name">KPI Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="e.g., Patient Satisfaction Score"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description / Intent</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Describe the purpose and intent of this KPI..."
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="department">Department *</Label>
                <Select 
                  value={formData.department} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, department: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    {kpiDepartments.map(dept => (
                      <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Category *</Label>
                <Select 
                  value={formData.category} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Metric Definition & Formula */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Metric Definition & Formula</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="metricType">Metric Type *</Label>
                <Select 
                  value={formData.metricType} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, metricType: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="count">Count</SelectItem>
                    <SelectItem value="percent">Percent (%)</SelectItem>
                    <SelectItem value="days">Days</SelectItem>
                    <SelectItem value="score">Score</SelectItem>
                    <SelectItem value="ratio">Ratio</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="dataSource">Data Source</Label>
                <Select 
                  value={formData.dataSource} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, dataSource: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="manual">Manual Entry</SelectItem>
                    <SelectItem value="csv">Upload CSV</SelectItem>
                    <SelectItem value="integration">System Integration</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="numerator">Numerator Definition</Label>
              <Input
                id="numerator"
                value={formData.numeratorDefinition}
                onChange={(e) => {
                  setFormData(prev => ({ ...prev, numeratorDefinition: e.target.value }));
                  updateFormulaText(e.target.value, formData.denominatorDefinition);
                }}
                placeholder="e.g., Number of satisfied patients"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="denominator">Denominator Definition</Label>
              <Input
                id="denominator"
                value={formData.denominatorDefinition}
                onChange={(e) => {
                  setFormData(prev => ({ ...prev, denominatorDefinition: e.target.value }));
                  updateFormulaText(formData.numeratorDefinition, e.target.value);
                }}
                placeholder="e.g., Total patients surveyed"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="formula">Formula (Human Readable)</Label>
              <Input
                id="formula"
                value={formData.formulaText}
                onChange={(e) => setFormData(prev => ({ ...prev, formulaText: e.target.value }))}
                placeholder="e.g., (Satisfied Patients / Total Surveyed) × 100"
              />
              <p className="text-xs text-muted-foreground">Auto-generated from numerator/denominator or enter custom formula</p>
            </div>
          </div>

          {/* Reporting & Ownership */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Reporting & Ownership</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="cadence">Reporting Cadence *</Label>
                <Select 
                  value={formData.reportingCadence} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, reportingCadence: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                    <SelectItem value="annually">Annually</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="scope">Scope</Label>
                <Select 
                  value={formData.scope} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, scope: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="org-wide">Org-Wide</SelectItem>
                    <SelectItem value="facility">Facility</SelectItem>
                    <SelectItem value="department">Department</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="dueRule">Collection Due Date Rule</Label>
              <Input
                id="dueRule"
                value={formData.collectionDueDateRule}
                onChange={(e) => setFormData(prev => ({ ...prev, collectionDueDateRule: e.target.value }))}
                placeholder="e.g., 5 business days after period end"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="owner">Owner *</Label>
                <Input
                  id="owner"
                  value={formData.owner}
                  onChange={(e) => setFormData(prev => ({ ...prev, owner: e.target.value }))}
                  placeholder="Primary owner name"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="backupOwner">Backup Owner</Label>
                <Input
                  id="backupOwner"
                  value={formData.backupOwner}
                  onChange={(e) => setFormData(prev => ({ ...prev, backupOwner: e.target.value }))}
                  placeholder="Backup owner name"
                />
              </div>
            </div>
          </div>

          {/* Targets & Thresholds */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Targets & Thresholds</h3>
            
            <div className="grid grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="target">Target Value *</Label>
                <Input
                  id="target"
                  type="number"
                  value={formData.targetValue}
                  onChange={(e) => setFormData(prev => ({ ...prev, targetValue: e.target.value }))}
                  placeholder="e.g., 95"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="green" className="text-success">Green (On Track)</Label>
                <Input
                  id="green"
                  type="number"
                  value={formData.greenThreshold}
                  onChange={(e) => setFormData(prev => ({ ...prev, greenThreshold: e.target.value }))}
                  placeholder="≥ 90"
                  className="border-success/50 focus:border-success"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="yellow" className="text-warning">Yellow (At Risk)</Label>
                <Input
                  id="yellow"
                  type="number"
                  value={formData.yellowThreshold}
                  onChange={(e) => setFormData(prev => ({ ...prev, yellowThreshold: e.target.value }))}
                  placeholder="≥ 80"
                  className="border-warning/50 focus:border-warning"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="red" className="text-destructive">Red (Breach)</Label>
                <Input
                  id="red"
                  type="number"
                  value={formData.redThreshold}
                  onChange={(e) => setFormData(prev => ({ ...prev, redThreshold: e.target.value }))}
                  placeholder="< 80"
                  className="border-destructive/50 focus:border-destructive"
                />
              </div>
            </div>
          </div>

          {/* Tags & Classification */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Tags & Classification</h3>
            
            <div className="space-y-2">
              <Label>Oversight Tags</Label>
              <div className="flex flex-wrap gap-2">
                {oversightTags.map(tag => (
                  <Badge
                    key={tag}
                    variant={formData.oversightTags.includes(tag) ? 'default' : 'outline'}
                    className="cursor-pointer"
                    onClick={() => handleTagToggle(tag, 'oversight')}
                  >
                    {tag}
                    {formData.oversightTags.includes(tag) && <X className="h-3 w-3 ml-1" />}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Standard Family Tags</Label>
              <div className="flex flex-wrap gap-2">
                {standardFamilyTags.map(tag => (
                  <Badge
                    key={tag}
                    variant={formData.standardFamilyTags.includes(tag) ? 'default' : 'outline'}
                    className="cursor-pointer"
                    onClick={() => handleTagToggle(tag, 'standardFamily')}
                  >
                    {tag}
                    {formData.standardFamilyTags.includes(tag) && <X className="h-3 w-3 ml-1" />}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          {/* Evidence Requirements */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Evidence Requirements</h3>
            
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="evidenceRequired">Evidence Pack Required</Label>
                <p className="text-xs text-muted-foreground">Require attachments to justify KPI value</p>
              </div>
              <Switch
                id="evidenceRequired"
                checked={formData.evidenceRequired}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, evidenceRequired: checked }))}
              />
            </div>
          </div>

          {/* Rationale */}
          <div className="space-y-2">
            <Label htmlFor="rationale">Rationale (Why This KPI Matters)</Label>
            <Textarea
              id="rationale"
              value={formData.rationale}
              onChange={(e) => setFormData(prev => ({ ...prev, rationale: e.target.value }))}
              placeholder="Explain why this KPI is important for the organization..."
              rows={3}
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4 border-t border-border">
            <Button type="button" variant="outline" className="flex-1" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="button" variant="secondary" className="flex-1">
              Save Draft
            </Button>
            <Button type="submit" className="flex-1">
              Create KPI
            </Button>
          </div>
        </form>
      </SheetContent>
    </Sheet>
  );
}
