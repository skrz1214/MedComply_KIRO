import { Link } from 'react-router-dom';
import { AlertTriangle, Clock, TrendingDown, ChevronRight, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { mockKPIDefinitions, mockKPIAlerts } from '@/data/mock-data';
import { cn } from '@/lib/utils';

export function KPIOversightSummary() {
  const atRiskKPIs = mockKPIDefinitions.filter(k => {
    if (!k.currentValue) return false;
    return k.currentValue < k.thresholds.yellow;
  });
  
  const overdueAlerts = mockKPIAlerts.filter(a => a.type === 'overdue-update' && a.status === 'open');
  const breachAlerts = mockKPIAlerts.filter(a => a.type === 'breach' && a.status === 'open');
  
  const summaryStats = [
    { 
      label: 'At Risk', 
      value: atRiskKPIs.length, 
      icon: TrendingDown, 
      variant: atRiskKPIs.length > 0 ? 'danger' : 'success' 
    },
    { 
      label: 'Overdue', 
      value: overdueAlerts.length, 
      icon: Clock, 
      variant: overdueAlerts.length > 0 ? 'warning' : 'success' 
    },
    { 
      label: 'Breaches', 
      value: breachAlerts.length, 
      icon: AlertTriangle, 
      variant: breachAlerts.length > 0 ? 'danger' : 'success' 
    },
  ];

  return (
    <div className="dashboard-card">
      <div className="p-4 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BarChart3 className="h-4 w-4 text-primary" />
          <h2 className="text-lg font-semibold">KPI Oversight</h2>
        </div>
        <Button variant="ghost" size="sm" asChild>
          <Link to="/dashboards/department/qa/kpi-oversight">
            View All <ChevronRight className="h-4 w-4 ml-1" />
          </Link>
        </Button>
      </div>
      
      <div className="p-4">
        {/* Summary Stats */}
        <div className="grid grid-cols-3 gap-3 mb-4">
          {summaryStats.map((stat) => (
            <div 
              key={stat.label}
              className={cn(
                "text-center p-3 rounded-lg border",
                stat.variant === 'danger' && 'bg-destructive/10 border-destructive/20',
                stat.variant === 'warning' && 'bg-warning/10 border-warning/20',
                stat.variant === 'success' && 'bg-muted/50 border-border'
              )}
            >
              <stat.icon className={cn(
                "h-4 w-4 mx-auto mb-1",
                stat.variant === 'danger' && 'text-destructive',
                stat.variant === 'warning' && 'text-warning',
                stat.variant === 'success' && 'text-muted-foreground'
              )} />
              <p className="text-xl font-bold">{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Recent Alerts */}
        {(breachAlerts.length > 0 || overdueAlerts.length > 0) && (
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Recent Alerts</p>
            {[...breachAlerts, ...overdueAlerts].slice(0, 3).map((alert) => (
              <Link 
                key={alert.id}
                to="/dashboards/department/qa/kpi-oversight?tab=alerts"
                className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors group"
              >
                <AlertTriangle className={cn(
                  "h-4 w-4 shrink-0",
                  alert.type === 'breach' ? 'text-destructive' : 'text-warning'
                )} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate group-hover:text-primary transition-colors">
                    {alert.kpiName}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">{alert.department}</p>
                </div>
                <Badge variant={alert.type === 'breach' ? 'overdue' : 'pending'} className="text-xs shrink-0">
                  {alert.type === 'breach' ? 'Breach' : 'Overdue'}
                </Badge>
              </Link>
            ))}
          </div>
        )}

        {breachAlerts.length === 0 && overdueAlerts.length === 0 && (
          <div className="text-center py-4 text-muted-foreground">
            <p className="text-sm">All KPIs on track</p>
          </div>
        )}
      </div>
    </div>
  );
}
