import { AlertTriangle, AlertCircle, Info, Calendar } from 'lucide-react';
import { Alert as AlertType } from '@/types/qa-dashboard';
import { mockAlerts } from '@/data/mock-data';
import { cn } from '@/lib/utils';

export function AlertsPanel() {
  return (
    <div className="dashboard-card p-4">
      <h2 className="text-lg font-semibold mb-4">Alerts</h2>
      <div className="space-y-3 stagger-children">
        {mockAlerts.map((alert) => (
          <AlertCard key={alert.id} alert={alert} />
        ))}
      </div>
    </div>
  );
}

function AlertCard({ alert }: { alert: AlertType }) {
  const Icon = alert.type === 'danger' ? AlertCircle : alert.type === 'warning' ? AlertTriangle : Info;
  
  return (
    <div className={cn(
      'p-3 rounded-lg border',
      alert.type === 'danger' && 'border-destructive/30 bg-destructive-muted',
      alert.type === 'warning' && 'border-warning/30 bg-warning-muted',
      alert.type === 'info' && 'border-info/30 bg-info-muted'
    )}>
      <div className="flex items-start gap-3">
        <Icon className={cn(
          'h-4 w-4 mt-0.5 flex-shrink-0',
          alert.type === 'danger' && 'text-destructive',
          alert.type === 'warning' && 'text-warning',
          alert.type === 'info' && 'text-info'
        )} />
        <div className="flex-1 min-w-0">
          <h3 className={cn(
            'text-sm font-medium',
            alert.type === 'danger' && 'text-destructive',
            alert.type === 'warning' && 'text-warning',
            alert.type === 'info' && 'text-info'
          )}>
            {alert.title}
          </h3>
          {alert.description && (
            <p className="text-xs text-muted-foreground mt-1">{alert.description}</p>
          )}
          {alert.dueDate && (
            <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {new Date(alert.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
