import { Link } from 'react-router-dom';
import { FileText, Calendar, User, ChevronRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { ReviewItem, ItemType } from '@/types/qa-dashboard';
import { mockReviewItems } from '@/data/mock-data';

function getTypeIcon(type: ItemType) {
  return FileText;
}

function getTypeVariant(type: ItemType) {
  switch (type) {
    case 'policy': return 'policy';
    case 'audit': return 'audit';
    case 'compliance': return 'compliance';
    case 'risk': return 'risk';
    case 'enforcement': return 'enforcement';
    default: return 'secondary';
  }
}

function getStatusVariant(status: string) {
  switch (status) {
    case 'pending-review': return 'pending';
    case 'in-progress': return 'inProgress';
    case 'completed': return 'completed';
    default: return 'secondary';
  }
}

function formatStatus(status: string) {
  return status.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

export function ReviewQueue() {
  const pendingCount = mockReviewItems.filter(item => item.status === 'pending-review').length;

  return (
    <div className="dashboard-card">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center gap-3">
          <h2 className="text-lg font-semibold">Review Queue</h2>
          <span className="flex items-center justify-center h-6 min-w-6 px-2 rounded-full bg-success text-success-foreground text-xs font-medium">
            {pendingCount}
          </span>
        </div>
        <p className="text-sm text-muted-foreground mt-1">Pending reviews & sign-offs</p>
      </div>

      {/* Review Items List */}
      <div className="divide-y divide-border stagger-children">
        {mockReviewItems.map((item) => (
          <ReviewItemCard key={item.id} item={item} />
        ))}
      </div>
    </div>
  );
}

function ReviewItemCard({ item }: { item: ReviewItem }) {
  const Icon = getTypeIcon(item.type);
  
  return (
    <Link 
      to={`/dashboards/department/qa/${item.type}s/${item.id}`}
      className="review-item group"
    >
      {/* Icon */}
      <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
        <Icon className="h-5 w-5 text-muted-foreground" />
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <h3 className="font-medium text-foreground group-hover:text-primary transition-colors mb-1.5">
          {item.title}
        </h3>
        <div className="flex flex-wrap items-center gap-2 text-sm">
          <Badge variant={getTypeVariant(item.type) as any} className="capitalize">
            {item.type}
          </Badge>
          <span className="flex items-center gap-1 text-muted-foreground">
            <User className="h-3.5 w-3.5" />
            {item.owner}
          </span>
          <span className="flex items-center gap-1 text-muted-foreground">
            <Calendar className="h-3.5 w-3.5" />
            {new Date(item.updatedDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
          </span>
          <Badge variant={getStatusVariant(item.status) as any}>
            {formatStatus(item.status)}
          </Badge>
        </div>
      </div>

      {/* Arrow */}
      <ChevronRight className="h-5 w-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
    </Link>
  );
}
