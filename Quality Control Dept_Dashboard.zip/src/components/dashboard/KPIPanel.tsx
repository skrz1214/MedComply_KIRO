import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, TrendingUp, TrendingDown, Minus, Pencil, Trash2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { KPIItem } from '@/types/qa-dashboard';
import { mockKPIs } from '@/data/mock-data';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

type KPIFormData = {
  name: string;
  numerator: string;
  denominator: string;
  target: string;
  unit: '%' | 'days' | 'count' | 'score';
  trend: 'up' | 'down' | 'neutral';
};

const emptyForm: KPIFormData = {
  name: '',
  numerator: '',
  denominator: '',
  target: '',
  unit: '%',
  trend: 'neutral',
};

function parseFormula(formula: string): { numerator: string; denominator: string } {
  // Try to parse formula like "(Numerator / Denominator) × 100"
  const match = formula.match(/\(([^/]+)\s*\/\s*([^)]+)\)/);
  if (match) {
    return { numerator: match[1].trim(), denominator: match[2].trim() };
  }
  return { numerator: formula, denominator: '' };
}

function buildFormula(numerator: string, denominator: string): string {
  if (!denominator) return numerator;
  return `(${numerator} / ${denominator}) × 100`;
}

export function KPIPanel() {
  const [kpis, setKpis] = useState<KPIItem[]>(mockKPIs);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingKpi, setEditingKpi] = useState<KPIItem | null>(null);
  const [formData, setFormData] = useState<KPIFormData>(emptyForm);

  const handleOpenAdd = () => {
    setEditingKpi(null);
    setFormData(emptyForm);
    setIsDialogOpen(true);
  };

  const handleOpenEdit = (kpi: KPIItem, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const parsed = parseFormula(kpi.formula);
    setEditingKpi(kpi);
    setFormData({
      name: kpi.name,
      numerator: parsed.numerator,
      denominator: parsed.denominator,
      target: String(kpi.target),
      unit: kpi.unit,
      trend: kpi.trend,
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (kpiId: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setKpis(prev => prev.filter(k => k.id !== kpiId));
    toast.success('KPI deleted successfully');
  };

  const handleSubmit = () => {
    if (!formData.name.trim() || !formData.numerator.trim() || !formData.target.trim()) {
      toast.error('Please fill in all required fields');
      return;
    }

    const formula = buildFormula(formData.numerator, formData.denominator);
    const targetValue = parseFloat(formData.target);

    if (editingKpi) {
      // Update existing KPI
      setKpis(prev => prev.map(k => 
        k.id === editingKpi.id 
          ? { 
              ...k, 
              name: formData.name.trim(),
              formula,
              target: targetValue,
              unit: formData.unit,
              trend: formData.trend,
            }
          : k
      ));
      toast.success('KPI updated successfully');
    } else {
      // Add new KPI
      const newKpi: KPIItem = {
        id: `KPI-${Date.now()}`,
        name: formData.name.trim(),
        value: 0,
        target: targetValue,
        unit: formData.unit,
        formula,
        trend: formData.trend,
        status: 'at-risk',
      };
      setKpis(prev => [...prev, newKpi]);
      toast.success('KPI added successfully');
    }

    setIsDialogOpen(false);
    setFormData(emptyForm);
    setEditingKpi(null);
  };

  return (
    <div className="dashboard-card">
      <div className="p-4 border-b border-border flex items-center justify-between">
        <h2 className="text-lg font-semibold">Quality KPIs</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleOpenAdd}>
              <Plus className="h-4 w-4" />
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>{editingKpi ? 'Edit KPI' : 'Add New KPI'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">KPI Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="e.g., Accreditation Readiness Score"
                />
              </div>

              <div className="p-3 rounded-lg bg-muted/50 space-y-3">
                <p className="text-sm font-medium">Formula Definition</p>
                <div className="space-y-2">
                  <Label htmlFor="numerator">Numerator *</Label>
                  <Input
                    id="numerator"
                    value={formData.numerator}
                    onChange={(e) => setFormData(prev => ({ ...prev, numerator: e.target.value }))}
                    placeholder="e.g., Met Standards"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="denominator">Denominator</Label>
                  <Input
                    id="denominator"
                    value={formData.denominator}
                    onChange={(e) => setFormData(prev => ({ ...prev, denominator: e.target.value }))}
                    placeholder="e.g., Total Standards"
                  />
                </div>
                <div className="text-xs text-muted-foreground p-2 bg-background rounded border border-border">
                  <span className="font-mono">
                    {formData.numerator && formData.denominator 
                      ? buildFormula(formData.numerator, formData.denominator)
                      : formData.numerator || 'Formula preview...'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="target">Target Value *</Label>
                  <Input
                    id="target"
                    type="number"
                    value={formData.target}
                    onChange={(e) => setFormData(prev => ({ ...prev, target: e.target.value }))}
                    placeholder="e.g., 95"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="unit">Unit</Label>
                  <Select 
                    value={formData.unit} 
                    onValueChange={(val) => setFormData(prev => ({ ...prev, unit: val as any }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="%">Percent (%)</SelectItem>
                      <SelectItem value="days">Days</SelectItem>
                      <SelectItem value="count">Count</SelectItem>
                      <SelectItem value="score">Score</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="trend">Current Trend</Label>
                <Select 
                  value={formData.trend} 
                  onValueChange={(val) => setFormData(prev => ({ ...prev, trend: val as any }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="up">Trending Up</SelectItem>
                    <SelectItem value="down">Trending Down</SelectItem>
                    <SelectItem value="neutral">Neutral</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSubmit}>
                {editingKpi ? 'Save Changes' : 'Add KPI'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      <div className="p-4 space-y-4 stagger-children">
        {kpis.map((kpi) => (
          <KPICard 
            key={kpi.id} 
            kpi={kpi} 
            onEdit={handleOpenEdit}
            onDelete={handleDelete}
          />
        ))}
        {kpis.length === 0 && (
          <p className="text-center text-muted-foreground py-8">
            No KPIs defined. Click + to add one.
          </p>
        )}
      </div>
    </div>
  );
}

interface KPICardProps {
  kpi: KPIItem;
  onEdit: (kpi: KPIItem, e: React.MouseEvent) => void;
  onDelete: (id: string, e: React.MouseEvent) => void;
}

function KPICard({ kpi, onEdit, onDelete }: KPICardProps) {
  const percentage = (kpi.value / kpi.target) * 100;
  const isInverted = kpi.name.toLowerCase().includes('violation') || kpi.name.toLowerCase().includes('repeat');
  
  let barStatus: 'success' | 'warning' | 'danger';
  if (isInverted) {
    barStatus = kpi.value <= kpi.target ? 'success' : kpi.value <= kpi.target * 2 ? 'warning' : 'danger';
  } else {
    barStatus = percentage >= 95 ? 'success' : percentage >= 80 ? 'warning' : 'danger';
  }

  return (
    <div className="block group relative">
      <Link 
        to={`/dashboards/department/qa/kpi-oversight/${kpi.id}`}
        className="block"
      >
        <div className="flex items-start justify-between mb-2">
          <h3 className="text-sm font-medium text-foreground group-hover:text-primary transition-colors pr-16">
            {kpi.name}
          </h3>
          {kpi.trend === 'up' ? (
            <TrendingUp className={cn(
              'h-4 w-4',
              isInverted ? 'text-destructive' : 'text-success'
            )} />
          ) : kpi.trend === 'down' ? (
            <TrendingDown className={cn(
              'h-4 w-4',
              isInverted ? 'text-success' : 'text-destructive'
            )} />
          ) : (
            <Minus className="h-4 w-4 text-muted-foreground" />
          )}
        </div>
        
        <div className="flex items-baseline gap-2 mb-2">
          <span className="text-2xl font-bold text-foreground">{kpi.value}</span>
          <span className="text-sm text-muted-foreground">{kpi.unit}</span>
          <span className="ml-auto text-xs text-muted-foreground">Target: {kpi.target}{kpi.unit}</span>
        </div>

        <div className="kpi-bar mb-2">
          <div 
            className={cn(
              'kpi-bar-fill',
              barStatus === 'success' && 'kpi-bar-success',
              barStatus === 'warning' && 'kpi-bar-warning',
              barStatus === 'danger' && 'kpi-bar-danger'
            )}
            style={{ width: `${Math.min(isInverted ? 100 : percentage, 100)}%` }}
          />
        </div>

        <p className="text-xs text-muted-foreground flex items-center gap-1">
          <span className="inline-flex items-center justify-center w-4 h-4 rounded bg-muted text-[10px]">ƒ</span>
          {kpi.formula}
        </p>
      </Link>

      {/* Action buttons */}
      <div className="absolute top-0 right-6 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-7 w-7"
          onClick={(e) => onEdit(kpi, e)}
        >
          <Pencil className="h-3.5 w-3.5" />
        </Button>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-7 w-7 text-destructive hover:text-destructive"
              onClick={(e) => e.stopPropagation()}
            >
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent onClick={(e) => e.stopPropagation()}>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete KPI</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete "{kpi.name}"? This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction 
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                onClick={(e) => onDelete(kpi.id, e)}
              >
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}