import { ReactNode, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Download, Filter, ChevronRight, Calendar, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { TabConfig, BreadcrumbItem } from '@/types/qa-dashboard';
import { cn } from '@/lib/utils';

interface BucketPageLayoutProps {
  title: string;
  description: string;
  breadcrumbs: BreadcrumbItem[];
  tabs: TabConfig[];
  activeTab: string;
  onTabChange: (tab: string) => void;
  metrics: { label: string; value: number; variant?: 'default' | 'success' | 'warning' | 'danger' }[];
  addRoute: string;
  addLabel: string;
  children: ReactNode;
}

export function BucketPageLayout({
  title,
  description,
  breadcrumbs,
  tabs,
  activeTab,
  onTabChange,
  metrics,
  addRoute,
  addLabel,
  children
}: BucketPageLayoutProps) {
  return (
    <DashboardLayout breadcrumbs={breadcrumbs}>
      <div className="space-y-6 animate-fade-in">
        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">{title}</h1>
            <p className="text-muted-foreground mt-1">{description}</p>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
            <Link to={addRoute}>
              <Button size="sm" className="gap-2">
                <Plus className="h-4 w-4" />
                {addLabel}
              </Button>
            </Link>
          </div>
        </div>

        {/* Metric Tiles */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {metrics.map((metric, index) => (
            <button
              key={index}
              onClick={() => {}}
              className={cn(
                'dashboard-card p-4 text-left hover:border-primary/30 transition-colors',
                metric.variant === 'danger' && 'border-destructive/30 bg-destructive-muted'
              )}
            >
              <p className="text-sm text-muted-foreground">{metric.label}</p>
              <p className={cn(
                'text-2xl font-bold mt-1',
                metric.variant === 'danger' ? 'text-destructive' : 'text-foreground'
              )}>
                {metric.value}
              </p>
            </button>
          ))}
        </div>

        {/* Tabs */}
        <div className="dashboard-card">
          <div className="border-b border-border overflow-x-auto">
            <div className="flex p-1 gap-1 min-w-max">
              {tabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  className={cn(
                    'px-4 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap',
                    activeTab === tab.id
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  )}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Content */}
          {children}
        </div>

        {/* Return Link */}
        <div className="flex justify-center">
          <Link 
            to="/dashboards/department/qa"
            className="text-sm text-muted-foreground hover:text-primary transition-colors flex items-center gap-1"
          >
            ← Return to QA Dashboard
          </Link>
        </div>
      </div>
    </DashboardLayout>
  );
}

// Generic list item component for bucket pages
interface ListItemProps {
  id: string;
  title: string;
  description?: string;
  status: string;
  priority?: string;
  dueDate?: string;
  owner: string;
  department: string;
  type: string;
  route: string;
}

export function ListItem({ id, title, status, priority, dueDate, owner, department, type, route }: ListItemProps) {
  return (
    <Link 
      to={route}
      className="block p-4 border-b border-border last:border-0 hover:bg-muted/50 transition-colors group"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs text-muted-foreground font-mono">{id}</span>
          </div>
          <h3 className="font-medium text-foreground group-hover:text-primary transition-colors mb-2">
            {title}
          </h3>
          <div className="flex flex-wrap items-center gap-2 text-sm">
            {priority && (
              <Badge variant={priority === 'high' ? 'high' : priority === 'medium' ? 'medium' : 'low'} className="capitalize">
                {priority}
              </Badge>
            )}
            <Badge variant={
              status === 'completed' ? 'completed' :
              status === 'in-progress' ? 'inProgress' :
              status === 'overdue' ? 'overdue' :
              'pending'
            }>
              {status.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
            </Badge>
            {dueDate && (
              <span className="flex items-center gap-1 text-muted-foreground">
                <Calendar className="h-3.5 w-3.5" />
                {new Date(dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
              </span>
            )}
            <span className="flex items-center gap-1 text-muted-foreground">
              <User className="h-3.5 w-3.5" />
              {owner}
            </span>
            <span className="text-muted-foreground">{department}</span>
          </div>
        </div>
        <ChevronRight className="h-5 w-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 mt-2" />
      </div>
    </Link>
  );
}
