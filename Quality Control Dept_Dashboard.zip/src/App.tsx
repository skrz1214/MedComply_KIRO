import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { RoleProvider } from "@/contexts/RoleContext";
import NotFound from "./pages/NotFound";

// QA Dashboard Pages
import QADashboard from "./pages/dashboards/department/qa/QADashboard";
import RiskManagement from "./pages/dashboards/department/qa/RiskManagement";
import AuditManagement from "./pages/dashboards/department/qa/AuditManagement";
import ComplianceTracking from "./pages/dashboards/department/qa/ComplianceTracking";
import FeedbackManagement from "./pages/dashboards/department/qa/FeedbackManagement";
import EnforcementManagement from "./pages/dashboards/department/qa/EnforcementManagement";
import OrgChart from "./pages/dashboards/department/qa/OrgChart";
import KPIOversight from "./pages/dashboards/department/qa/KPIOversight";
import Documents from "./pages/dashboards/department/qa/Documents";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <RoleProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {/* Redirect root to QA Dashboard */}
            <Route path="/" element={<Navigate to="/dashboards/department/qa" replace />} />
            
            {/* QA Department Dashboard Routes */}
            <Route path="/dashboards/department/qa" element={<QADashboard />} />
            <Route path="/dashboards/department/qa/risks" element={<RiskManagement />} />
            <Route path="/dashboards/department/qa/audits" element={<AuditManagement />} />
            <Route path="/dashboards/department/qa/compliance" element={<ComplianceTracking />} />
            <Route path="/dashboards/department/qa/feedback" element={<FeedbackManagement />} />
            <Route path="/dashboards/department/qa/enforcements" element={<EnforcementManagement />} />
            <Route path="/dashboards/department/qa/org-chart" element={<OrgChart />} />
            <Route path="/dashboards/department/qa/policies" element={<Navigate to="/dashboards/department/qa/risks" replace />} />
            <Route path="/dashboards/department/qa/kpi-oversight" element={<KPIOversight />} />
            <Route path="/dashboards/department/qa/kpi-oversight/departments/:department" element={<KPIOversight />} />
            <Route path="/dashboards/department/qa/kpi-oversight/:department" element={<KPIOversight />} />
            <Route path="/dashboards/department/qa/microapps" element={<QADashboard />} />
            <Route path="/dashboards/department/qa/documents" element={<Documents />} />
            
            {/* Catch-all */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </RoleProvider>
  </QueryClientProvider>
);

export default App;
