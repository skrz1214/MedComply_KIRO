import { useState } from 'react';
import { Link } from 'react-router-dom';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { ListItem } from '@/components/dashboard/BucketPageLayout';
import { riskTabs, mockActionItems, mockPolicies } from '@/data/mock-data';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Plus, Download, Calendar, User, FileText, Shield } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';

const breadcrumbs = [
  { label: 'Home', href: '/' },
  { label: 'Dashboards', href: '/dashboards' },
  { label: 'Department', href: '/dashboards/department' },
  { label: 'Quality Assurance', href: '/dashboards/department/qa' },
  { label: 'Risk Management' }
];

export default function RiskManagement() {
  const [mainTab, setMainTab] = useState('risks');
  const [riskSubTab, setRiskSubTab] = useState('all');
  
  const riskItems = mockActionItems.filter(item => item.type === 'risk');
  
  const riskMetrics = [
    { label: 'Total Risks', value: 15 },
    { label: 'Open', value: 8, variant: 'warning' as const },
    { label: 'Mitigated', value: 5, variant: 'success' as const },
    { label: 'Overdue', value: 2, variant: 'danger' as const },
  ];

  const policyMetrics = [
    { label: 'Total Policies', value: mockPolicies.length },
    { label: 'Current', value: mockPolicies.filter(p => p.status === 'current').length, variant: 'success' as const },
    { label: 'Under Review', value: mockPolicies.filter(p => p.status === 'under-review').length, variant: 'warning' as const },
    { label: 'Expired', value: mockPolicies.filter(p => p.status === 'expired').length, variant: 'danger' as const },
  ];

  return (
    <DashboardLayout breadcrumbs={breadcrumbs}>
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Risk Management</h1>
            <p className="text-muted-foreground mt-1">RiskGuard QA View - Manage quality-related risks and policies</p>
          </div>
        </div>

        {/* Main Tabs: Risks | Policies & Procedures */}
        <Tabs value={mainTab} onValueChange={setMainTab} className="w-full">
          <TabsList className="bg-muted/50 p-1">
            <TabsTrigger value="risks" className="gap-2">
              <Shield className="h-4 w-4" />
              Risks
            </TabsTrigger>
            <TabsTrigger value="policies" className="gap-2">
              <FileText className="h-4 w-4" />
              Policies & Procedures
            </TabsTrigger>
          </TabsList>

          {/* Risks Tab Content */}
          <TabsContent value="risks" className="mt-6 space-y-6">
            {/* Risk Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {riskMetrics.map((metric) => (
                <div 
                  key={metric.label}
                  className={cn(
                    "dashboard-card p-4 cursor-pointer hover:shadow-md transition-shadow",
                    metric.variant === 'warning' && 'border-l-4 border-l-warning',
                    metric.variant === 'success' && 'border-l-4 border-l-success',
                    metric.variant === 'danger' && 'border-l-4 border-l-destructive'
                  )}
                >
                  <p className="text-sm text-muted-foreground">{metric.label}</p>
                  <p className="text-2xl font-bold">{metric.value}</p>
                </div>
              ))}
            </div>

            {/* Risk Sub-tabs */}
            <div className="flex flex-wrap gap-2 border-b border-border pb-2">
              {riskTabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setRiskSubTab(tab.id)}
                  className={cn(
                    "px-3 py-1.5 text-sm rounded-md transition-colors",
                    riskSubTab === tab.id
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted"
                  )}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Add Risk Button */}
            <div className="flex justify-end">
              <Button asChild>
                <Link to="/riskguard/risks/new?dept=qa">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Risk
                </Link>
              </Button>
            </div>

            {/* Risk Items List */}
            <div className="dashboard-card divide-y divide-border">
              {riskItems.length > 0 ? (
                riskItems.map((item) => (
                  <ListItem
                    key={item.id}
                    id={item.id}
                    title={item.title}
                    status={item.status}
                    priority={item.priority}
                    dueDate={item.dueDate}
                    owner={item.owner}
                    department={item.department}
                    type="risk"
                    route={`/riskguard/risks/${item.id}?from=qa-dashboard&dept=qa`}
                  />
                ))
              ) : null}
              <ListItem
                id="RISK-001"
                title="Patient Fall Risk Assessment Gap"
                status="in-progress"
                priority="high"
                dueDate="2025-01-20"
                owner="Dr. Patricia Lee"
                department="Patient Care"
                type="risk"
                route="/riskguard/risks/RISK-001?from=qa-dashboard&dept=qa"
              />
              <ListItem
                id="RISK-002"
                title="Medication Dispensing Error Potential"
                status="pending-review"
                priority="high"
                dueDate="2025-01-18"
                owner="Emily Davis"
                department="Pharmacy"
                type="risk"
                route="/riskguard/risks/RISK-002?from=qa-dashboard&dept=qa"
              />
              <ListItem
                id="RISK-003"
                title="Infection Control Protocol Gaps"
                status="not-started"
                priority="medium"
                dueDate="2025-01-25"
                owner="Michael Chen"
                department="Infection Control"
                type="risk"
                route="/riskguard/risks/RISK-003?from=qa-dashboard&dept=qa"
              />
            </div>
          </TabsContent>

          {/* Policies Tab Content */}
          <TabsContent value="policies" className="mt-6 space-y-6">
            {/* Policy Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {policyMetrics.map((metric) => (
                <div 
                  key={metric.label}
                  className={cn(
                    "dashboard-card p-4 cursor-pointer hover:shadow-md transition-shadow",
                    metric.variant === 'warning' && 'border-l-4 border-l-warning',
                    metric.variant === 'success' && 'border-l-4 border-l-success',
                    metric.variant === 'danger' && 'border-l-4 border-l-destructive'
                  )}
                >
                  <p className="text-sm text-muted-foreground">{metric.label}</p>
                  <p className="text-2xl font-bold">{metric.value}</p>
                </div>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Policy
              </Button>
            </div>

            {/* Policies List */}
            <div className="dashboard-card divide-y divide-border">
              {mockPolicies.map(policy => (
                <Link 
                  key={policy.id} 
                  to={`/documents/${policy.id}`} 
                  className="block p-4 hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <FileText className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-medium hover:text-primary">{policy.name}</h3>
                          <p className="text-sm text-muted-foreground">{policy.category}</p>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-3 mt-3 text-sm text-muted-foreground ml-11">
                        <Badge variant={
                          policy.status === 'current' ? 'completed' : 
                          policy.status === 'expired' ? 'overdue' : 'pending'
                        }>
                          {policy.status}
                        </Badge>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3.5 w-3.5" />
                          Updated: {policy.lastUpdate}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3.5 w-3.5" />
                          Next Review: {policy.nextReviewDate}
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="h-3.5 w-3.5" />
                          {policy.owner}
                        </span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-center">
          <Link to="/dashboards/department/qa" className="text-sm text-muted-foreground hover:text-primary">
            ← Return to QA Dashboard
          </Link>
        </div>
      </div>
    </DashboardLayout>
  );
}
