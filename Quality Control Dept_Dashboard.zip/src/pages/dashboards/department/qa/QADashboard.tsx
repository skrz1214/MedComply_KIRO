import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { ActionCenter } from '@/components/dashboard/ActionCenter';
import { ReviewQueue } from '@/components/dashboard/ReviewQueue';
import { QuickStats } from '@/components/dashboard/QuickStats';
import { KPIPanel } from '@/components/dashboard/KPIPanel';
import { AlertsPanel } from '@/components/dashboard/AlertsPanel';
import { MicroAppsGrid } from '@/components/dashboard/MicroAppsGrid';
import { KPIOversightSummary } from '@/components/dashboard/KPIOversightSummary';

export default function QADashboard() {
  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Page Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground">Quality Assurance Compliance Dashboard</h1>
          <p className="text-muted-foreground mt-1">Unified QA oversight for accreditation, audits, and regulatory compliance</p>
        </div>

        {/* Main Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Wide */}
          <div className="lg:col-span-2 space-y-6">
            <ActionCenter />
            <ReviewQueue />
          </div>

          {/* Right Column - Narrow */}
          <div className="space-y-6">
            <QuickStats />
            <KPIOversightSummary />
            <KPIPanel />
            <AlertsPanel />
          </div>
        </div>

        {/* Microapps Quick Access */}
        <MicroAppsGrid />
      </div>
    </DashboardLayout>
  );
}
