import { useState } from 'react';
import { Link } from 'react-router-dom';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { mockOrgMembers } from '@/data/mock-data';
import { OrgMember } from '@/types/qa-dashboard';
import { 
  Mail, 
  Phone, 
  User, 
  Plus, 
  Pencil, 
  Trash2, 
  MoreHorizontal,
  ChevronDown,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const breadcrumbs = [
  { label: 'Home', href: '/' },
  { label: 'Dashboards', href: '/dashboards' },
  { label: 'Department', href: '/dashboards/department' },
  { label: 'Quality Assurance', href: '/dashboards/department/qa' },
  { label: 'Org Chart' }
];

interface OrgFormData {
  name: string;
  role: string;
  department: string;
  email: string;
  phone: string;
  reportsTo: string;
}

const initialFormData: OrgFormData = {
  name: '',
  role: '',
  department: 'Quality Assurance',
  email: '',
  phone: '',
  reportsTo: 'none',
};

// Hierarchical chart node component
function OrgChartNode({ 
  member, 
  members, 
  onEdit, 
  onDelete,
  expandedNodes,
  toggleNode 
}: { 
  member: OrgMember; 
  members: OrgMember[];
  onEdit: (member: OrgMember) => void;
  onDelete: (member: OrgMember) => void;
  expandedNodes: Set<string>;
  toggleNode: (id: string) => void;
}) {
  const directReports = members.filter(m => m.reportsTo === member.id && m.status === 'active');
  const hasReports = directReports.length > 0;
  const isExpanded = expandedNodes.has(member.id);

  return (
    <div className="flex flex-col items-center">
      {/* Node Card */}
      <div className={cn(
        "relative bg-card border border-border rounded-lg p-4 min-w-[200px] shadow-sm",
        member.status === 'inactive' && "opacity-60"
      )}>
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
            <User className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <h4 className="font-medium text-sm truncate">{member.name}</h4>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-6 w-6">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onEdit(member)}>
                    <Pencil className="h-4 w-4 mr-2" /> Edit
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => onDelete(member)}
                    className="text-destructive"
                  >
                    <Trash2 className="h-4 w-4 mr-2" /> Deactivate
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <p className="text-xs text-muted-foreground truncate">{member.role}</p>
            <p className="text-xs text-muted-foreground truncate">{member.email}</p>
          </div>
        </div>
        {member.status === 'inactive' && (
          <Badge variant="outline" className="absolute -top-2 -right-2 text-xs">
            Inactive
          </Badge>
        )}
        
        {/* Expand/Collapse button */}
        {hasReports && (
          <button 
            onClick={() => toggleNode(member.id)}
            className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-6 h-6 bg-muted border border-border rounded-full flex items-center justify-center hover:bg-accent transition-colors"
          >
            {isExpanded ? (
              <ChevronDown className="h-3 w-3" />
            ) : (
              <ChevronRight className="h-3 w-3" />
            )}
          </button>
        )}
      </div>

      {/* Children */}
      {hasReports && isExpanded && (
        <div className="mt-8 relative">
          {/* Vertical line from parent */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-4 bg-border -mt-4" />
          
          {/* Horizontal connector line */}
          {directReports.length > 1 && (
            <div className="absolute top-0 left-0 right-0 h-px bg-border" 
              style={{ 
                left: `${100 / (directReports.length * 2)}%`,
                right: `${100 / (directReports.length * 2)}%`
              }} 
            />
          )}
          
          <div className="flex gap-6 justify-center">
            {directReports.map((report) => (
              <div key={report.id} className="relative">
                {/* Vertical line to child */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-4 bg-border -mt-4" />
                <OrgChartNode 
                  member={report} 
                  members={members}
                  onEdit={onEdit}
                  onDelete={onDelete}
                  expandedNodes={expandedNodes}
                  toggleNode={toggleNode}
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default function OrgChart() {
  const [members, setMembers] = useState<OrgMember[]>(mockOrgMembers);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<OrgMember | null>(null);
  const [deletingMember, setDeletingMember] = useState<OrgMember | null>(null);
  const [formData, setFormData] = useState<OrgFormData>(initialFormData);
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set(members.map(m => m.id)));

  const toggleNode = (id: string) => {
    setExpandedNodes(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const activeMembers = members.filter(m => m.status === 'active');
  const rootMembers = activeMembers.filter(m => !m.reportsTo);

  const handleAdd = () => {
    setEditingMember(null);
    setFormData(initialFormData);
    setIsFormOpen(true);
  };

  const handleEdit = (member: OrgMember) => {
    setEditingMember(member);
    setFormData({
      name: member.name,
      role: member.role,
      department: member.department,
      email: member.email,
      phone: member.phone || '',
      reportsTo: member.reportsTo || 'none',
    });
    setIsFormOpen(true);
  };

  const handleDelete = (member: OrgMember) => {
    setDeletingMember(member);
    setIsDeleteOpen(true);
  };

  const handleSave = () => {
    const reportsToValue = formData.reportsTo === 'none' ? undefined : formData.reportsTo || undefined;
    
    if (editingMember) {
      setMembers(prev => prev.map(m => 
        m.id === editingMember.id 
          ? { 
              ...m, 
              ...formData,
              reportsTo: reportsToValue
            } 
          : m
      ));
    } else {
      const newMember: OrgMember = {
        id: `ORG-${String(members.length + 1).padStart(3, '0')}`,
        name: formData.name,
        role: formData.role,
        department: formData.department,
        email: formData.email,
        phone: formData.phone || undefined,
        reportsTo: reportsToValue,
        status: 'active'
      };
      setMembers(prev => [...prev, newMember]);
      setExpandedNodes(prev => new Set([...prev, newMember.id]));
    }
    setIsFormOpen(false);
    setFormData(initialFormData);
  };

  const handleConfirmDelete = () => {
    if (deletingMember) {
      // Deactivate instead of delete
      setMembers(prev => prev.map(m => 
        m.id === deletingMember.id 
          ? { ...m, status: 'inactive' as const } 
          : m
      ));
    }
    setIsDeleteOpen(false);
    setDeletingMember(null);
  };

  const getMemberName = (id: string) => {
    const member = members.find(m => m.id === id);
    return member?.name || '';
  };

  return (
    <DashboardLayout breadcrumbs={breadcrumbs}>
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Org Chart</h1>
            <p className="text-muted-foreground mt-1">QA team structure and contacts</p>
          </div>
          <Button onClick={handleAdd} className="gap-2">
            <Plus className="h-4 w-4" /> Add Member
          </Button>
        </div>

        {/* Chart View */}
        <div className="dashboard-card p-6">
          <h2 className="text-lg font-semibold mb-6">Organization Chart</h2>
          <div className="overflow-x-auto pb-4">
            <div className="flex justify-center gap-8 min-w-max">
              {rootMembers.map(member => (
                <OrgChartNode 
                  key={member.id} 
                  member={member} 
                  members={members}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                  expandedNodes={expandedNodes}
                  toggleNode={toggleNode}
                />
              ))}
            </div>
          </div>
        </div>

        {/* List View */}
        <div className="dashboard-card">
          <div className="p-4 border-b border-border">
            <h2 className="text-lg font-semibold">Team Members List</h2>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Reports To</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {members.map(member => (
                <TableRow key={member.id} className={member.status === 'inactive' ? 'opacity-60' : ''}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                        <User className="h-4 w-4 text-primary" />
                      </div>
                      <span className="font-medium">{member.name}</span>
                    </div>
                  </TableCell>
                  <TableCell>{member.role}</TableCell>
                  <TableCell>{member.department}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Mail className="h-3 w-3" />
                      <span className="text-sm">{member.email}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    {member.phone ? (
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Phone className="h-3 w-3" />
                        <span className="text-sm">{member.phone}</span>
                      </div>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {member.reportsTo ? getMemberName(member.reportsTo) : '—'}
                  </TableCell>
                  <TableCell>
                    <Badge variant={member.status === 'active' ? 'completed' : 'secondary'}>
                      {member.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleEdit(member)}>
                          <Pencil className="h-4 w-4 mr-2" /> Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleDelete(member)}
                          className="text-destructive"
                        >
                          <Trash2 className="h-4 w-4 mr-2" /> Deactivate
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <div className="flex justify-center">
          <Link to="/dashboards/department/qa" className="text-sm text-muted-foreground hover:text-primary">
            ← Return to QA Dashboard
          </Link>
        </div>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>
              {editingMember ? 'Edit Team Member' : 'Add New Team Member'}
            </DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Enter full name"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="role">Role / Title *</Label>
              <Input
                id="role"
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                placeholder="Enter role or job title"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="department">Department *</Label>
              <Input
                id="department"
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                placeholder="Enter department"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="Enter email address"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="Enter phone number"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="reportsTo">Reports To</Label>
              <Select 
                value={formData.reportsTo} 
                onValueChange={(value) => setFormData({ ...formData, reportsTo: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select manager (optional)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None (Top Level)</SelectItem>
                  {members
                    .filter(m => m.status === 'active' && m.id !== editingMember?.id)
                    .map(m => (
                      <SelectItem key={m.id} value={m.id}>
                        {m.name} - {m.role}
                      </SelectItem>
                    ))
                  }
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsFormOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleSave}
              disabled={!formData.name || !formData.role || !formData.email}
            >
              {editingMember ? 'Save Changes' : 'Add Member'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Deactivate Team Member</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to deactivate <strong>{deletingMember?.name}</strong>? 
              This member will be marked as inactive but their records will be preserved for audit purposes.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Deactivate
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
}
