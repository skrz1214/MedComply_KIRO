import { useState } from 'react';
import { BucketPageLayout, ListItem } from '@/components/dashboard/BucketPageLayout';
import { enforcementTabs } from '@/data/mock-data';
import { AlertCircle } from 'lucide-react';

const breadcrumbs = [
  { label: 'Home', href: '/' },
  { label: 'Dashboards', href: '/dashboards' },
  { label: 'Department', href: '/dashboards/department' },
  { label: 'Quality Assurance', href: '/dashboards/department/qa' },
  { label: 'Enforcement Management' }
];

export default function EnforcementManagement() {
  const [activeTab, setActiveTab] = useState('all');
  
  const metrics = [
    { label: 'Total Cases', value: 8 },
    { label: 'Active', value: 4, variant: 'warning' as const },
    { label: 'Resolved', value: 3, variant: 'success' as const },
    { label: 'Critical', value: 1, variant: 'danger' as const },
  ];

  return (
    <BucketPageLayout
      title="Enforcement Management"
      description="EnforcePoint QA View - Regulatory enforcement actions and deadlines"
      breadcrumbs={breadcrumbs}
      tabs={enforcementTabs}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      metrics={metrics}
      addRoute="/enforcepoint/cases/new?dept=qa"
      addLabel="Add Case"
    >
      {/* Critical Alert */}
      <div className="p-4 border-b border-border bg-destructive-muted">
        <div className="flex items-center gap-3">
          <AlertCircle className="h-5 w-5 text-destructive" />
          <div>
            <p className="text-sm font-medium text-destructive">Critical Deadline</p>
            <p className="text-xs text-muted-foreground">CMS enforcement response due in 3 days</p>
          </div>
        </div>
      </div>

      <div className="divide-y divide-border">
        <ListItem
          id="ENF-001"
          title="CMS Enforcement Action - Quality Measures"
          status="in-progress"
          priority="high"
          dueDate="2025-01-18"
          owner="Dr. Patricia Lee"
          department="Quality Assurance"
          type="enforcement"
          route="/enforcepoint/cases/ENF-001?from=qa-dashboard&dept=qa"
        />
        <ListItem
          id="ENF-002"
          title="State Survey Corrective Action Plan"
          status="pending-review"
          priority="high"
          dueDate="2025-01-25"
          owner="Sarah Chen"
          department="Quality Assurance"
          type="enforcement"
          route="/enforcepoint/cases/ENF-002?from=qa-dashboard&dept=qa"
        />
        <ListItem
          id="ENF-003"
          title="Accreditation Conditional Status Follow-up"
          status="in-progress"
          priority="medium"
          dueDate="2025-02-01"
          owner="Michael Chen"
          department="Quality Assurance"
          type="enforcement"
          route="/enforcepoint/cases/ENF-003?from=qa-dashboard&dept=qa"
        />
        <ListItem
          id="ENF-004"
          title="OCR Privacy Violation Investigation"
          status="completed"
          priority="high"
          dueDate="2024-12-15"
          owner="Emily Davis"
          department="Privacy & Security"
          type="enforcement"
          route="/enforcepoint/cases/ENF-004?from=qa-dashboard&dept=qa"
        />
      </div>
    </BucketPageLayout>
  );
}
