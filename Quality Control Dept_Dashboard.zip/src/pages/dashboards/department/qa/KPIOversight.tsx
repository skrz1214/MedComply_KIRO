import { useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { KPIForm } from '@/components/dashboard/KPIForm';
import { useRole } from '@/contexts/RoleContext';
import { 
  kpiDepartments, 
  mockKPIDefinitions, 
  mockKPIProposals, 
  mockKPIAlerts,
  mockGovernanceRules
} from '@/data/mock-data';
import { 
  BarChart3, 
  ChevronRight, 
  Plus, 
  Download, 
  Search,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
  TrendingDown,
  Eye,
  Pencil,
  Copy,
  Archive,
  Send,
  FileCheck,
  Bell,
  Settings,
  Filter,
  MessageSquarePlus,
  Lock
} from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Switch } from '@/components/ui/switch';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { ThresholdStatus, KPIStatus, ProposalStatus, KPIAlertType } from '@/types/qa-dashboard';

const breadcrumbs = [
  { label: 'Home', href: '/' },
  { label: 'Quality Assurance', href: '/dashboards/department/qa' },
  { label: 'KPI Oversight' }
];

function getThresholdBadge(value: number | undefined, thresholds: { green: number; yellow: number; red: number }, isLowerBetter = false) {
  if (value === undefined) return <Badge variant="secondary">No Data</Badge>;
  
  let status: ThresholdStatus;
  if (isLowerBetter) {
    if (value <= thresholds.green) status = 'green';
    else if (value <= thresholds.yellow) status = 'yellow';
    else status = 'red';
  } else {
    if (value >= thresholds.green) status = 'green';
    else if (value >= thresholds.yellow) status = 'yellow';
    else status = 'red';
  }
  
  return (
    <Badge variant={status === 'green' ? 'completed' : status === 'yellow' ? 'pending' : 'overdue'}>
      {status === 'green' ? 'On Track' : status === 'yellow' ? 'At Risk' : 'Breach'}
    </Badge>
  );
}

function getStatusBadge(status: KPIStatus) {
  const variants: Record<KPIStatus, 'completed' | 'pending' | 'secondary' | 'overdue'> = {
    'published': 'completed',
    'approved': 'completed',
    'draft': 'secondary',
    'submitted': 'pending',
    'under-review': 'pending',
    'retired': 'overdue'
  };
  return <Badge variant={variants[status] || 'secondary'}>{status}</Badge>;
}

function getProposalStatusBadge(status: ProposalStatus) {
  const variants: Record<ProposalStatus, 'completed' | 'pending' | 'secondary' | 'overdue'> = {
    'published': 'completed',
    'approved': 'completed',
    'draft': 'secondary',
    'submitted': 'pending',
    'under-review': 'pending',
    'rejected': 'overdue'
  };
  return <Badge variant={variants[status] || 'secondary'}>{status}</Badge>;
}

function getAlertTypeBadge(type: KPIAlertType) {
  const labels: Record<KPIAlertType, string> = {
    'breach': 'Breach',
    'trending': 'Trending',
    'overdue-update': 'Overdue Update',
    'missing-evidence': 'Missing Evidence',
    'definition-review': 'Review Due'
  };
  const variants: Record<KPIAlertType, 'overdue' | 'pending' | 'secondary'> = {
    'breach': 'overdue',
    'trending': 'pending',
    'overdue-update': 'pending',
    'missing-evidence': 'secondary',
    'definition-review': 'secondary'
  };
  return <Badge variant={variants[type]}>{labels[type]}</Badge>;
}

// Overview Tab Component
function OverviewTab() {
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  
  const publishedKPIs = mockKPIDefinitions.filter(k => k.status === 'published');
  const draftKPIs = mockKPIDefinitions.filter(k => k.status === 'draft');
  const atRiskKPIs = publishedKPIs.filter(k => {
    if (!k.currentValue) return false;
    return k.currentValue < k.thresholds.yellow;
  });
  
  const coverageTiles = [
    { label: 'Total KPIs', value: mockKPIDefinitions.length, icon: BarChart3 },
    { label: 'Published', value: publishedKPIs.length, icon: CheckCircle, variant: 'success' as const },
    { label: 'Draft', value: draftKPIs.length, icon: Clock, variant: 'warning' as const },
    { label: 'Needs Review', value: 2, icon: Eye },
    { label: 'Overdue Update', value: mockKPIAlerts.filter(a => a.type === 'overdue-update').length, icon: AlertTriangle, variant: 'danger' as const },
    { label: 'Out of Threshold', value: atRiskKPIs.length, icon: TrendingDown, variant: 'danger' as const },
  ];

  return (
    <div className="space-y-6">
      {/* Filter Bar */}
      <div className="flex flex-wrap gap-4 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search KPIs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Department" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Departments</SelectItem>
            {kpiDepartments.map(d => (
              <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="published">Published</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="retired">Retired</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="icon">
          <Filter className="h-4 w-4" />
        </Button>
      </div>

      {/* Coverage Tiles */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {coverageTiles.map((tile) => (
          <div 
            key={tile.label}
            className={cn(
              "dashboard-card p-4 cursor-pointer hover:shadow-md transition-shadow",
              tile.variant === 'success' && 'border-l-4 border-l-success',
              tile.variant === 'warning' && 'border-l-4 border-l-warning',
              tile.variant === 'danger' && 'border-l-4 border-l-destructive'
            )}
          >
            <div className="flex items-center gap-2 mb-2">
              <tile.icon className="h-4 w-4 text-muted-foreground" />
              <p className="text-xs text-muted-foreground">{tile.label}</p>
            </div>
            <p className="text-2xl font-bold">{tile.value}</p>
          </div>
        ))}
      </div>

      {/* At Risk KPIs Table */}
      <div className="dashboard-card">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h3 className="font-semibold">At Risk KPIs</h3>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" /> Export CSV
          </Button>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>KPI Name</TableHead>
              <TableHead>Department</TableHead>
              <TableHead>Current Value</TableHead>
              <TableHead>Target</TableHead>
              <TableHead>Threshold Status</TableHead>
              <TableHead>Last Updated</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {publishedKPIs.slice(0, 5).map((kpi) => (
              <TableRow key={kpi.id}>
                <TableCell className="font-medium">{kpi.name}</TableCell>
                <TableCell>{kpi.department}</TableCell>
                <TableCell>{kpi.currentValue}{kpi.metricType === 'percent' ? '%' : ''}</TableCell>
                <TableCell>{kpi.target}{kpi.metricType === 'percent' ? '%' : ''}</TableCell>
                <TableCell>{getThresholdBadge(kpi.currentValue, kpi.thresholds)}</TableCell>
                <TableCell>{kpi.lastUpdated || '—'}</TableCell>
                <TableCell>{kpi.owner}</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm" asChild>
                    <Link to={`/dashboards/department/qa/kpi-oversight/kpi/${kpi.id}`}>
                      <Eye className="h-4 w-4" />
                    </Link>
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Governance Work Queue */}
      <div className="dashboard-card">
        <div className="p-4 border-b border-border">
          <h3 className="font-semibold">KPI Governance Work Queue</h3>
        </div>
        <div className="divide-y divide-border">
          {mockKPIProposals.filter(p => p.status !== 'published').slice(0, 3).map((proposal) => (
            <div key={proposal.id} className="p-4 flex items-center justify-between hover:bg-muted/50">
              <div className="flex items-center gap-3">
                <FileCheck className="h-5 w-5 text-primary" />
                <div>
                  <p className="font-medium">{proposal.kpiName}</p>
                  <p className="text-sm text-muted-foreground">Proposal awaiting {proposal.status}</p>
                </div>
              </div>
              {getProposalStatusBadge(proposal.status)}
            </div>
          ))}
          {mockKPIAlerts.filter(a => a.status === 'open').slice(0, 2).map((alert) => (
            <div key={alert.id} className="p-4 flex items-center justify-between hover:bg-muted/50">
              <div className="flex items-center gap-3">
                <AlertTriangle className="h-5 w-5 text-warning" />
                <div>
                  <p className="font-medium">{alert.kpiName}</p>
                  <p className="text-sm text-muted-foreground">{alert.description}</p>
                </div>
              </div>
              {getAlertTypeBadge(alert.type)}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Departments Tab Component
function DepartmentsTab() {
  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {kpiDepartments.map(dept => {
          const deptKPIs = mockKPIDefinitions.filter(k => 
            k.department.toLowerCase().includes(dept.id) || 
            dept.name.toLowerCase().includes(k.department.toLowerCase())
          );
          const published = deptKPIs.filter(k => k.status === 'published').length;
          
          return (
            <Link 
              key={dept.id} 
              to={`/dashboards/department/qa/kpi-oversight/departments/${dept.id}`} 
              className="dashboard-card p-6 hover:border-primary/30 group"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20">
                  <BarChart3 className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium group-hover:text-primary">{dept.name}</h3>
                  <p className="text-sm text-muted-foreground">{published} Published KPIs</p>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground opacity-0 group-hover:opacity-100" />
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}

// KPI Library Tab Component
function KPILibraryTab() {
  const [searchTerm, setSearchTerm] = useState('');
  
  const filteredKPIs = mockKPIDefinitions.filter(kpi =>
    kpi.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    kpi.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-4 items-center justify-between">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search KPI library..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" /> Export CSV
          </Button>
          <Button size="sm" asChild>
            <Link to="/dashboards/department/qa/kpi-oversight/proposals/new">
              <Plus className="h-4 w-4 mr-2" /> Create KPI
            </Link>
          </Button>
        </div>
      </div>

      <div className="dashboard-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>KPI Name</TableHead>
              <TableHead>Department</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Metric Type</TableHead>
              <TableHead>Cadence</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Last Review</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredKPIs.map((kpi) => (
              <TableRow key={kpi.id}>
                <TableCell className="font-medium">{kpi.name}</TableCell>
                <TableCell>{kpi.department}</TableCell>
                <TableCell>{kpi.category}</TableCell>
                <TableCell className="capitalize">{kpi.metricType}</TableCell>
                <TableCell className="capitalize">{kpi.reportingCadence}</TableCell>
                <TableCell>{kpi.owner}</TableCell>
                <TableCell>{getStatusBadge(kpi.status)}</TableCell>
                <TableCell>{kpi.lastReviewDate || '—'}</TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">Actions</Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem asChild>
                        <Link to={`/dashboards/department/qa/kpi-oversight/kpi/${kpi.id}`}>
                          <Eye className="h-4 w-4 mr-2" /> View
                        </Link>
                      </DropdownMenuItem>
                      {kpi.status === 'draft' && (
                        <DropdownMenuItem>
                          <Pencil className="h-4 w-4 mr-2" /> Edit
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuItem>
                        <Copy className="h-4 w-4 mr-2" /> Duplicate
                      </DropdownMenuItem>
                      {kpi.status === 'draft' && (
                        <DropdownMenuItem>
                          <Send className="h-4 w-4 mr-2" /> Publish
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuItem className="text-destructive">
                        <Archive className="h-4 w-4 mr-2" /> Retire
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

// Proposals Tab Component
function ProposalsTab() {
  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <Button size="sm" asChild>
          <Link to="/dashboards/department/qa/kpi-oversight/proposals/new">
            <Plus className="h-4 w-4 mr-2" /> Create KPI Proposal
          </Link>
        </Button>
      </div>

      <div className="dashboard-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Proposal ID</TableHead>
              <TableHead>KPI Name</TableHead>
              <TableHead>Department</TableHead>
              <TableHead>Requested By</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Submitted Date</TableHead>
              <TableHead>Reviewer</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mockKPIProposals.map((proposal) => (
              <TableRow key={proposal.id}>
                <TableCell className="font-mono text-sm">{proposal.id}</TableCell>
                <TableCell className="font-medium">{proposal.kpiName}</TableCell>
                <TableCell>{proposal.department}</TableCell>
                <TableCell>{proposal.requestedBy}</TableCell>
                <TableCell>{getProposalStatusBadge(proposal.status)}</TableCell>
                <TableCell>{proposal.submittedDate || '—'}</TableCell>
                <TableCell>{proposal.reviewer || '—'}</TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">Actions</Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Eye className="h-4 w-4 mr-2" /> View
                      </DropdownMenuItem>
                      {proposal.status === 'draft' && (
                        <>
                          <DropdownMenuItem>
                            <Pencil className="h-4 w-4 mr-2" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Send className="h-4 w-4 mr-2" /> Submit for Review
                          </DropdownMenuItem>
                        </>
                      )}
                      {proposal.status === 'under-review' && (
                        <>
                          <DropdownMenuItem className="text-success">
                            <CheckCircle className="h-4 w-4 mr-2" /> Approve
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">
                            <AlertTriangle className="h-4 w-4 mr-2" /> Reject
                          </DropdownMenuItem>
                        </>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

// Alerts Tab Component
function AlertsTab() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Open Alerts', value: mockKPIAlerts.filter(a => a.status === 'open').length, variant: 'danger' as const },
          { label: 'Acknowledged', value: mockKPIAlerts.filter(a => a.status === 'acknowledged').length, variant: 'warning' as const },
          { label: 'Resolved', value: mockKPIAlerts.filter(a => a.status === 'resolved').length, variant: 'success' as const },
          { label: 'Snoozed', value: mockKPIAlerts.filter(a => a.status === 'snoozed').length },
        ].map((stat) => (
          <div 
            key={stat.label}
            className={cn(
              "dashboard-card p-4",
              stat.variant === 'success' && 'border-l-4 border-l-success',
              stat.variant === 'warning' && 'border-l-4 border-l-warning',
              stat.variant === 'danger' && 'border-l-4 border-l-destructive'
            )}
          >
            <p className="text-sm text-muted-foreground">{stat.label}</p>
            <p className="text-2xl font-bold">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="dashboard-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Alert Type</TableHead>
              <TableHead>KPI</TableHead>
              <TableHead>Department</TableHead>
              <TableHead>Severity</TableHead>
              <TableHead>Trigger Date</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mockKPIAlerts.map((alert) => (
              <TableRow key={alert.id}>
                <TableCell>{getAlertTypeBadge(alert.type)}</TableCell>
                <TableCell className="font-medium">{alert.kpiName}</TableCell>
                <TableCell>{alert.department}</TableCell>
                <TableCell>
                  <Badge variant={alert.severity === 'high' ? 'high' : alert.severity === 'medium' ? 'medium' : 'low'}>
                    {alert.severity}
                  </Badge>
                </TableCell>
                <TableCell>{alert.triggerDate}</TableCell>
                <TableCell>{alert.owner}</TableCell>
                <TableCell>
                  <Badge variant={
                    alert.status === 'open' ? 'overdue' : 
                    alert.status === 'acknowledged' ? 'pending' : 
                    alert.status === 'resolved' ? 'completed' : 'secondary'
                  }>
                    {alert.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">Actions</Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <CheckCircle className="h-4 w-4 mr-2" /> Acknowledge
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Send className="h-4 w-4 mr-2" /> Assign
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Clock className="h-4 w-4 mr-2" /> Snooze
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

// Governance Tab Component
function GovernanceTab() {
  const [rules, setRules] = useState(mockGovernanceRules);

  const toggleRule = (ruleId: string) => {
    setRules(prev => prev.map(r => 
      r.id === ruleId ? { ...r, enabled: !r.enabled } : r
    ));
  };

  return (
    <div className="space-y-6">
      <div className="dashboard-card">
        <div className="p-4 border-b border-border">
          <h3 className="font-semibold">Governance Rules</h3>
          <p className="text-sm text-muted-foreground mt-1">Configure KPI oversight automation and requirements</p>
        </div>
        <div className="divide-y divide-border">
          {rules.map((rule) => (
            <div key={rule.id} className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Settings className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">{rule.name}</p>
                  <p className="text-sm text-muted-foreground">{rule.description}</p>
                  <Badge variant="secondary" className="mt-1">{rule.category}</Badge>
                </div>
              </div>
              <Switch 
                checked={rule.enabled} 
                onCheckedChange={() => toggleRule(rule.id)}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function KPIOversight() {
  const { department } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [kpiFormOpen, setKpiFormOpen] = useState(false);
  const { permissions, currentRole } = useRole();
  
  // If viewing a specific department
  if (department) {
    const dept = kpiDepartments.find(d => d.id === department);
    const deptBreadcrumbs = [
      ...breadcrumbs,
      { label: dept?.name || department }
    ];
    
    return (
      <DashboardLayout breadcrumbs={deptBreadcrumbs}>
        <div className="space-y-6 animate-fade-in">
          {/* Department Context Header */}
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="secondary" className="text-xs">
              Department Context
            </Badge>
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
              {dept?.name || department}
            </Badge>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">{dept?.name || department} KPIs</h1>
              <p className="text-muted-foreground mt-1">Viewing KPI scoreboard and administration for <span className="font-medium text-foreground">{dept?.name || department}</span></p>
            </div>
            <div className="flex gap-2">
              {permissions.canExportData && (
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" /> Export CSV
                </Button>
              )}
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => navigate('/dashboards/department/qa/feedback?action=new&from=kpi-oversight')}
              >
                <MessageSquarePlus className="h-4 w-4 mr-2" /> Propose New KPI
              </Button>
              {permissions.canCreateKPI ? (
                <Button size="sm" onClick={() => setKpiFormOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" /> Create KPI
                </Button>
              ) : (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button size="sm" variant="outline" disabled className="opacity-50">
                      <Lock className="h-4 w-4 mr-2" /> Create KPI
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Requires Admin or Department Head role</p>
                  </TooltipContent>
                </Tooltip>
              )}
            </div>
          </div>

          <KPIForm 
            open={kpiFormOpen} 
            onOpenChange={setKpiFormOpen} 
            departmentContext={department}
          />

          {/* Department KPI Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {[
              { label: 'Total', value: 8 },
              { label: 'Published', value: 6, variant: 'success' as const },
              { label: 'Draft', value: 2, variant: 'warning' as const },
              { label: 'Out of Threshold', value: 1, variant: 'danger' as const },
              { label: 'Overdue Update', value: 0 },
            ].map((stat) => (
              <div 
                key={stat.label}
                className={cn(
                  "dashboard-card p-4",
                  stat.variant === 'success' && 'border-l-4 border-l-success',
                  stat.variant === 'warning' && 'border-l-4 border-l-warning',
                  stat.variant === 'danger' && 'border-l-4 border-l-destructive'
                )}
              >
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
              </div>
            ))}
          </div>

          {/* Department KPI Table */}
          <div className="dashboard-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>KPI Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Current Value</TableHead>
                  <TableHead>Target</TableHead>
                  <TableHead>Threshold Status</TableHead>
                  <TableHead>Cadence</TableHead>
                  <TableHead>Last Updated</TableHead>
                  <TableHead>Owner</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockKPIDefinitions.slice(0, 4).map((kpi) => (
                  <TableRow key={kpi.id}>
                    <TableCell className="font-medium">{kpi.name}</TableCell>
                    <TableCell>{kpi.category}</TableCell>
                    <TableCell>{kpi.currentValue}{kpi.metricType === 'percent' ? '%' : ''}</TableCell>
                    <TableCell>{kpi.target}{kpi.metricType === 'percent' ? '%' : ''}</TableCell>
                    <TableCell>{getThresholdBadge(kpi.currentValue, kpi.thresholds)}</TableCell>
                    <TableCell className="capitalize">{kpi.reportingCadence}</TableCell>
                    <TableCell>{kpi.lastUpdated || '—'}</TableCell>
                    <TableCell>{kpi.owner}</TableCell>
                    <TableCell>{getStatusBadge(kpi.status)}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" asChild>
                        <Link to={`/dashboards/department/qa/kpi-oversight/kpi/${kpi.id}`}>
                          <Eye className="h-4 w-4" />
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="flex justify-center">
            <Link to="/dashboards/department/qa/kpi-oversight" className="text-sm text-muted-foreground hover:text-primary">
              ← Back to KPI Oversight
            </Link>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout breadcrumbs={breadcrumbs}>
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">KPI Oversight Hub</h1>
            <p className="text-muted-foreground mt-1">Centralized KPI monitoring and governance</p>
          </div>
          <div className="flex gap-2">
            {permissions.canExportData && (
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" /> Export CSV
              </Button>
            )}
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => navigate('/dashboards/department/qa/feedback?action=new&from=kpi-oversight')}
            >
              <MessageSquarePlus className="h-4 w-4 mr-2" /> Propose New KPI
            </Button>
            {permissions.canCreateKPI ? (
              <Button size="sm" onClick={() => setKpiFormOpen(true)}>
                <Plus className="h-4 w-4 mr-2" /> Create KPI
              </Button>
            ) : (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="sm" variant="outline" disabled className="opacity-50">
                    <Lock className="h-4 w-4 mr-2" /> Create KPI
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Requires Admin or Department Head role</p>
                </TooltipContent>
              </Tooltip>
            )}
          </div>
        </div>

        <KPIForm open={kpiFormOpen} onOpenChange={setKpiFormOpen} />

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="bg-muted/50 p-1">
            <TabsTrigger value="overview" className="gap-2">
              <BarChart3 className="h-4 w-4" />
              Overview
            </TabsTrigger>
            {permissions.canViewAllDepartments && (
              <TabsTrigger value="departments" className="gap-2">
                <TrendingUp className="h-4 w-4" />
                Departments
              </TabsTrigger>
            )}
            <TabsTrigger value="library" className="gap-2">
              <FileCheck className="h-4 w-4" />
              KPI Library
            </TabsTrigger>
            {permissions.canApproveProposals && (
              <TabsTrigger value="proposals" className="gap-2">
                <Send className="h-4 w-4" />
                Proposals & Approvals
              </TabsTrigger>
            )}
            {permissions.canViewAlerts && (
              <TabsTrigger value="alerts" className="gap-2">
                <Bell className="h-4 w-4" />
                Alerts
              </TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <OverviewTab />
          </TabsContent>

          {permissions.canViewAllDepartments && (
            <TabsContent value="departments" className="mt-6">
              <DepartmentsTab />
            </TabsContent>
          )}

          <TabsContent value="library" className="mt-6">
            <KPILibraryTab />
          </TabsContent>

          {permissions.canApproveProposals && (
            <TabsContent value="proposals" className="mt-6">
              <ProposalsTab />
            </TabsContent>
          )}

          {permissions.canViewAlerts && (
            <TabsContent value="alerts" className="mt-6">
              <AlertsTab />
            </TabsContent>
          )}
        </Tabs>

        <div className="flex justify-center">
          <Link to="/dashboards/department/qa" className="text-sm text-muted-foreground hover:text-primary">
            ← Return to QA Dashboard
          </Link>
        </div>
      </div>
    </DashboardLayout>
  );
}
