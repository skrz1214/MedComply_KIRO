import { useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Download, FileText, TestTube, ClipboardCheck, Code, Sparkles } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

const breadcrumbs = [
  { label: 'Home', href: '/' },
  { label: 'Quality Assurance', href: '/dashboards/department/qa' },
  { label: 'Documents' }
];

function handlePrint(documentId: string) {
  const content = document.getElementById(documentId);
  if (!content) return;
  
  const printWindow = window.open('', '_blank');
  if (!printWindow) return;
  
  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>QA Dashboard Documentation</title>
      <style>
        body { font-family: system-ui, -apple-system, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; line-height: 1.6; }
        h1 { font-size: 24px; border-bottom: 2px solid #0ea5e9; padding-bottom: 8px; }
        h2 { font-size: 20px; margin-top: 24px; color: #0369a1; }
        h3 { font-size: 16px; margin-top: 16px; }
        table { width: 100%; border-collapse: collapse; margin: 16px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 13px; }
        th { background: #f1f5f9; }
        code { background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-size: 13px; }
        pre { background: #f1f5f9; padding: 16px; border-radius: 8px; overflow-x: auto; font-size: 12px; }
        ul, ol { margin: 8px 0; padding-left: 24px; }
        li { margin: 4px 0; }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 12px; background: #e0f2fe; color: #0369a1; }
        @media print { body { padding: 20px; } }
      </style>
    </head>
    <body>${content.innerHTML}</body>
    </html>
  `);
  printWindow.document.close();
  printWindow.print();
}

// PRD Document Component
function PRDDocument() {
  return (
    <div id="prd-document" className="prose prose-sm max-w-none">
      <h1>Product Requirements Document (PRD)</h1>
      <p><strong>Project:</strong> QA Compliance Department Dashboard</p>
      <p><strong>Version:</strong> 1.0</p>
      <p><strong>Last Updated:</strong> December 2024</p>
      
      <Separator className="my-4" />
      
      <h2>1. Executive Summary</h2>
      <p>The QA Compliance Department Dashboard is a comprehensive web-based platform designed to centralize quality assurance monitoring, KPI management, and regulatory compliance tracking for healthcare organizations. The system provides role-based access control, real-time KPI monitoring, and governance workflows for quality management.</p>
      
      <h2>2. Product Vision</h2>
      <p>To create a unified QA oversight platform that enables healthcare compliance teams to monitor, manage, and improve quality metrics across all departments while maintaining regulatory compliance.</p>
      
      <h2>3. Target Users</h2>
      <ul>
        <li><strong>Admin / Compliance Head:</strong> Full system access, organizational oversight</li>
        <li><strong>QA Department Head:</strong> Department-level management and KPI administration</li>
        <li><strong>QA Staff:</strong> Limited view access for daily operations</li>
      </ul>
      
      <h2>4. Core Features</h2>
      
      <h3>4.1 Main Dashboard</h3>
      <ul>
        <li>Action Center with priority tasks</li>
        <li>Review Queue for pending items</li>
        <li>Quick Stats summary metrics</li>
        <li>KPI Oversight Summary widget</li>
        <li>Quality KPIs Panel with CRUD operations</li>
        <li>Alerts Panel for real-time notifications</li>
      </ul>
      
      <h3>4.2 KPI Oversight Hub</h3>
      <ul>
        <li>Overview Tab: Coverage tiles, at-risk KPIs, governance work queue</li>
        <li>Departments Tab: Department-specific KPI monitoring</li>
        <li>KPI Library Tab: Catalog of KPI definitions</li>
        <li>Proposals & Approvals Tab: Workflow management</li>
        <li>Alerts Tab: Exception monitoring</li>
      </ul>
      
      <h3>4.3 KPI Creation & Management</h3>
      <ul>
        <li>Formula builder with numerator/denominator</li>
        <li>Threshold configuration (Green/Yellow/Red)</li>
        <li>Evidence requirements</li>
        <li>Oversight and standard family tagging</li>
      </ul>
      
      <h3>4.4 Role-Based Access Control</h3>
      <table>
        <thead>
          <tr>
            <th>Feature</th>
            <th>Admin</th>
            <th>Dept Head</th>
            <th>Staff</th>
          </tr>
        </thead>
        <tbody>
          <tr><td>View All Departments</td><td>✓</td><td>✗</td><td>✗</td></tr>
          <tr><td>Create KPI</td><td>✓</td><td>✓</td><td>✗</td></tr>
          <tr><td>Approve Proposals</td><td>✓</td><td>✓</td><td>✗</td></tr>
          <tr><td>Export Data</td><td>✓</td><td>✓</td><td>✗</td></tr>
          <tr><td>View Alerts</td><td>✓</td><td>✓</td><td>✗</td></tr>
          <tr><td>View Audits</td><td>✓</td><td>✓</td><td>✗</td></tr>
          <tr><td>View Compliance</td><td>✓</td><td>✓</td><td>✗</td></tr>
          <tr><td>View Org Chart</td><td>✓</td><td>✓</td><td>✓</td></tr>
        </tbody>
      </table>
      
      <h2>5. Technical Requirements</h2>
      <ul>
        <li>React 18+ with TypeScript</li>
        <li>Vite build system</li>
        <li>Tailwind CSS for styling</li>
        <li>shadcn/ui component library</li>
        <li>React Router for navigation</li>
        <li>Responsive design (mobile-first)</li>
      </ul>
      
      <h2>6. Success Metrics</h2>
      <ul>
        <li>100% feature completion per requirements</li>
        <li>Role-based access working correctly</li>
        <li>All CRUD operations functional</li>
        <li>Responsive across devices</li>
      </ul>
    </div>
  );
}

// TDD Document Component
function TDDDocument() {
  return (
    <div id="tdd-document" className="prose prose-sm max-w-none">
      <h1>Technical Design Document (TDD)</h1>
      <p><strong>Project:</strong> QA Compliance Department Dashboard</p>
      <p><strong>Version:</strong> 1.0</p>
      
      <Separator className="my-4" />
      
      <h2>1. Architecture Overview</h2>
      <pre>{`
src/
├── components/
│   ├── dashboard/
│   │   ├── ActionCenter.tsx
│   │   ├── AlertsPanel.tsx
│   │   ├── KPIForm.tsx
│   │   ├── KPIOversightSummary.tsx
│   │   ├── KPIPanel.tsx
│   │   ├── MicroAppsGrid.tsx
│   │   ├── QuickStats.tsx
│   │   └── ReviewQueue.tsx
│   ├── layout/
│   │   ├── Breadcrumbs.tsx
│   │   ├── DashboardHeader.tsx
│   │   ├── DashboardLayout.tsx
│   │   ├── QASidebar.tsx
│   │   └── RoleImpersonator.tsx
│   └── ui/ (shadcn components)
├── contexts/
│   └── RoleContext.tsx
├── data/
│   └── mock-data.ts
├── pages/
│   └── dashboards/department/qa/
│       ├── QADashboard.tsx
│       ├── KPIOversight.tsx
│       ├── RiskManagement.tsx
│       ├── AuditManagement.tsx
│       ├── ComplianceTracking.tsx
│       ├── FeedbackManagement.tsx
│       ├── EnforcementManagement.tsx
│       ├── OrgChart.tsx
│       └── Documents.tsx
├── types/
│   └── qa-dashboard.ts
└── App.tsx
      `}</pre>
      
      <h2>2. Component Design</h2>
      
      <h3>2.1 RoleContext</h3>
      <p>Central state management for role-based access control.</p>
      <pre>{`
interface RoleContextType {
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  permissions: RolePermissions;
  roleLabel: string;
  assignedDepartment: string | null;
}

type UserRole = 'admin' | 'department-head' | 'staff';
      `}</pre>
      
      <h3>2.2 KPIOversight Component</h3>
      <p>Main hub component with tabbed interface.</p>
      <ul>
        <li>Uses React Router useParams for department routing</li>
        <li>Conditional tab rendering based on permissions</li>
        <li>Integration with KPIForm sheet component</li>
      </ul>
      
      <h3>2.3 KPIForm Component</h3>
      <p>Sheet-based form for KPI creation with sections:</p>
      <ul>
        <li>Basic Information</li>
        <li>Metric Definition & Formula</li>
        <li>Reporting & Ownership</li>
        <li>Targets & Thresholds</li>
        <li>Tags & Classification</li>
        <li>Evidence Requirements</li>
      </ul>
      
      <h2>3. Data Models</h2>
      
      <h3>3.1 KPIDefinition</h3>
      <pre>{`
interface KPIDefinition {
  id: string;
  name: string;
  description: string;
  department: string;
  category: string;
  metricType: 'count' | 'percent' | 'days' | 'score';
  numeratorDefinition?: string;
  denominatorDefinition?: string;
  formulaText: string;
  target: number;
  thresholds: {
    green: number;
    yellow: number;
    red: number;
  };
  reportingCadence: 'monthly' | 'quarterly';
  owner: string;
  status: KPIStatus;
  currentValue?: number;
}
      `}</pre>
      
      <h2>4. Routing Structure</h2>
      <table>
        <thead>
          <tr><th>Route</th><th>Component</th><th>Description</th></tr>
        </thead>
        <tbody>
          <tr><td>/dashboards/department/qa</td><td>QADashboard</td><td>Main dashboard</td></tr>
          <tr><td>/dashboards/department/qa/kpi-oversight</td><td>KPIOversight</td><td>KPI Hub</td></tr>
          <tr><td>/dashboards/department/qa/kpi-oversight/departments/:dept</td><td>KPIOversight</td><td>Department KPIs</td></tr>
          <tr><td>/dashboards/department/qa/risks</td><td>RiskManagement</td><td>Risk management</td></tr>
          <tr><td>/dashboards/department/qa/audits</td><td>AuditManagement</td><td>Audit management</td></tr>
          <tr><td>/dashboards/department/qa/documents</td><td>Documents</td><td>Documentation</td></tr>
        </tbody>
      </table>
      
      <h2>5. Design System</h2>
      <ul>
        <li>Primary: HSL(199, 89%, 48%) - Healthcare blue</li>
        <li>Success: HSL(142, 76%, 36%) - Green</li>
        <li>Warning: HSL(38, 92%, 50%) - Amber</li>
        <li>Destructive: HSL(0, 84%, 60%) - Red</li>
        <li>Typography: System font stack</li>
        <li>Spacing: 4px base unit</li>
      </ul>
    </div>
  );
}

// QA Test Cases Document
function QATestCasesDocument() {
  return (
    <div id="qa-test-document" className="prose prose-sm max-w-none">
      <h1>QA Test Cases</h1>
      <p><strong>Project:</strong> QA Compliance Department Dashboard</p>
      <p><strong>Version:</strong> 1.0</p>
      
      <Separator className="my-4" />
      
      <h2>1. Navigation Tests</h2>
      <table>
        <thead>
          <tr><th>TC ID</th><th>Test Case</th><th>Steps</th><th>Expected Result</th></tr>
        </thead>
        <tbody>
          <tr>
            <td>NAV-001</td>
            <td>Sidebar navigation works</td>
            <td>Click each sidebar menu item</td>
            <td>Correct page loads, active state highlighted</td>
          </tr>
          <tr>
            <td>NAV-002</td>
            <td>Breadcrumbs display correctly</td>
            <td>Navigate to nested pages</td>
            <td>Breadcrumb trail shows correct hierarchy</td>
          </tr>
          <tr>
            <td>NAV-003</td>
            <td>Locked nav items for Staff role</td>
            <td>Switch to Staff role, check sidebar</td>
            <td>Audit, Compliance, Enforcement show lock icons</td>
          </tr>
        </tbody>
      </table>
      
      <h2>2. Role Impersonation Tests</h2>
      <table>
        <thead>
          <tr><th>TC ID</th><th>Test Case</th><th>Steps</th><th>Expected Result</th></tr>
        </thead>
        <tbody>
          <tr>
            <td>ROLE-001</td>
            <td>Role switcher displays</td>
            <td>Check header for role dropdown</td>
            <td>Dropdown shows current role with badge</td>
          </tr>
          <tr>
            <td>ROLE-002</td>
            <td>Admin has full access</td>
            <td>Select Admin role, check all features</td>
            <td>All tabs, buttons, and nav items accessible</td>
          </tr>
          <tr>
            <td>ROLE-003</td>
            <td>Staff has limited access</td>
            <td>Select Staff role, check features</td>
            <td>Create KPI disabled, Alerts tab hidden</td>
          </tr>
          <tr>
            <td>ROLE-004</td>
            <td>Role persists across navigation</td>
            <td>Switch role, navigate pages</td>
            <td>Selected role maintained</td>
          </tr>
        </tbody>
      </table>
      
      <h2>3. KPI Oversight Hub Tests</h2>
      <table>
        <thead>
          <tr><th>TC ID</th><th>Test Case</th><th>Steps</th><th>Expected Result</th></tr>
        </thead>
        <tbody>
          <tr>
            <td>KPI-001</td>
            <td>Overview tab loads</td>
            <td>Navigate to KPI Oversight</td>
            <td>Coverage tiles and tables display</td>
          </tr>
          <tr>
            <td>KPI-002</td>
            <td>Department tiles link correctly</td>
            <td>Click department tile</td>
            <td>Routes to department-specific view with context badge</td>
          </tr>
          <tr>
            <td>KPI-003</td>
            <td>KPI Library search works</td>
            <td>Enter search term in library tab</td>
            <td>Table filters to matching KPIs</td>
          </tr>
          <tr>
            <td>KPI-004</td>
            <td>Create KPI form opens</td>
            <td>Click "Create KPI" button</td>
            <td>Sheet slides in with all form sections</td>
          </tr>
          <tr>
            <td>KPI-005</td>
            <td>Formula auto-generates</td>
            <td>Enter numerator and denominator</td>
            <td>Formula field auto-populates</td>
          </tr>
        </tbody>
      </table>
      
      <h2>4. Dashboard Widget Tests</h2>
      <table>
        <thead>
          <tr><th>TC ID</th><th>Test Case</th><th>Steps</th><th>Expected Result</th></tr>
        </thead>
        <tbody>
          <tr>
            <td>DASH-001</td>
            <td>KPI Oversight Summary displays</td>
            <td>View main dashboard</td>
            <td>Shows at-risk, overdue, breach counts</td>
          </tr>
          <tr>
            <td>DASH-002</td>
            <td>Summary links to hub</td>
            <td>Click "View All" on summary</td>
            <td>Navigates to KPI Oversight Hub</td>
          </tr>
          <tr>
            <td>DASH-003</td>
            <td>KPI Panel CRUD works</td>
            <td>Add, edit, delete a KPI</td>
            <td>Operations complete with toast notifications</td>
          </tr>
        </tbody>
      </table>
      
      <h2>5. Responsive Design Tests</h2>
      <table>
        <thead>
          <tr><th>TC ID</th><th>Test Case</th><th>Steps</th><th>Expected Result</th></tr>
        </thead>
        <tbody>
          <tr>
            <td>RESP-001</td>
            <td>Dashboard responsive on tablet</td>
            <td>View at 768px width</td>
            <td>Grid adjusts, no horizontal scroll</td>
          </tr>
          <tr>
            <td>RESP-002</td>
            <td>Tables scroll horizontally on mobile</td>
            <td>View tables on mobile</td>
            <td>Tables have horizontal scroll container</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

// UAT Test Cases Document
function UATTestCasesDocument() {
  return (
    <div id="uat-test-document" className="prose prose-sm max-w-none">
      <h1>User Acceptance Test Cases (UAT)</h1>
      <p><strong>Project:</strong> QA Compliance Department Dashboard</p>
      <p><strong>Version:</strong> 1.0</p>
      
      <Separator className="my-4" />
      
      <h2>1. Compliance Head User Journey</h2>
      
      <h3>UAT-001: Daily Monitoring Workflow</h3>
      <p><strong>Persona:</strong> Sarah Chen, Compliance Head</p>
      <p><strong>Objective:</strong> Review daily compliance status</p>
      <table>
        <thead>
          <tr><th>Step</th><th>Action</th><th>Expected Outcome</th><th>Pass/Fail</th></tr>
        </thead>
        <tbody>
          <tr><td>1</td><td>Login and view dashboard</td><td>Dashboard loads with all widgets</td><td></td></tr>
          <tr><td>2</td><td>Review KPI Oversight Summary</td><td>Can see at-risk and overdue counts</td><td></td></tr>
          <tr><td>3</td><td>Click "View All" to access hub</td><td>KPI Oversight Hub opens</td><td></td></tr>
          <tr><td>4</td><td>Review At Risk KPIs table</td><td>Can identify which KPIs need attention</td><td></td></tr>
          <tr><td>5</td><td>Export data for report</td><td>CSV downloads successfully</td><td></td></tr>
        </tbody>
      </table>
      
      <h3>UAT-002: KPI Creation Workflow</h3>
      <p><strong>Persona:</strong> Sarah Chen, Compliance Head</p>
      <p><strong>Objective:</strong> Create a new quality KPI</p>
      <table>
        <thead>
          <tr><th>Step</th><th>Action</th><th>Expected Outcome</th><th>Pass/Fail</th></tr>
        </thead>
        <tbody>
          <tr><td>1</td><td>Navigate to KPI Oversight Hub</td><td>Hub page loads</td><td></td></tr>
          <tr><td>2</td><td>Click "Create KPI" button</td><td>KPI form sheet opens</td><td></td></tr>
          <tr><td>3</td><td>Fill in basic information</td><td>Fields accept input correctly</td><td></td></tr>
          <tr><td>4</td><td>Define formula with numerator/denominator</td><td>Formula auto-generates</td><td></td></tr>
          <tr><td>5</td><td>Set thresholds (Green/Yellow/Red)</td><td>Threshold inputs work</td><td></td></tr>
          <tr><td>6</td><td>Select oversight tags</td><td>Tags toggle on/off</td><td></td></tr>
          <tr><td>7</td><td>Submit form</td><td>Success toast appears, form closes</td><td></td></tr>
        </tbody>
      </table>
      
      <h2>2. Department Head User Journey</h2>
      
      <h3>UAT-003: Department KPI Review</h3>
      <p><strong>Persona:</strong> Michael Torres, QA Department Head</p>
      <p><strong>Objective:</strong> Review department-specific KPIs</p>
      <table>
        <thead>
          <tr><th>Step</th><th>Action</th><th>Expected Outcome</th><th>Pass/Fail</th></tr>
        </thead>
        <tbody>
          <tr><td>1</td><td>Switch role to "QA Department Head"</td><td>Role updates in header</td><td></td></tr>
          <tr><td>2</td><td>Navigate to KPI Oversight</td><td>Departments tab not visible</td><td></td></tr>
          <tr><td>3</td><td>View KPI Library</td><td>Can see all KPIs</td><td></td></tr>
          <tr><td>4</td><td>Try to create KPI</td><td>Create KPI button works</td><td></td></tr>
          <tr><td>5</td><td>View Alerts tab</td><td>Can see and acknowledge alerts</td><td></td></tr>
        </tbody>
      </table>
      
      <h2>3. Staff User Journey</h2>
      
      <h3>UAT-004: Limited Access Verification</h3>
      <p><strong>Persona:</strong> Junior QA Analyst</p>
      <p><strong>Objective:</strong> Verify restricted access</p>
      <table>
        <thead>
          <tr><th>Step</th><th>Action</th><th>Expected Outcome</th><th>Pass/Fail</th></tr>
        </thead>
        <tbody>
          <tr><td>1</td><td>Switch role to "QA Staff"</td><td>Role updates, shows "QA Department"</td><td></td></tr>
          <tr><td>2</td><td>Check sidebar navigation</td><td>Audit, Compliance items show lock</td><td></td></tr>
          <tr><td>3</td><td>Navigate to KPI Oversight</td><td>Only Overview and Library tabs visible</td><td></td></tr>
          <tr><td>4</td><td>Try to click "Create KPI"</td><td>Button disabled with tooltip</td><td></td></tr>
          <tr><td>5</td><td>View KPI Library</td><td>Can view but not edit KPIs</td><td></td></tr>
        </tbody>
      </table>
      
      <h2>4. Sign-Off</h2>
      <table>
        <thead>
          <tr><th>Role</th><th>Name</th><th>Date</th><th>Signature</th></tr>
        </thead>
        <tbody>
          <tr><td>Product Owner</td><td></td><td></td><td></td></tr>
          <tr><td>QA Lead</td><td></td><td></td><td></td></tr>
          <tr><td>Business Analyst</td><td></td><td></td><td></td></tr>
          <tr><td>End User Representative</td><td></td><td></td><td></td></tr>
        </tbody>
      </table>
    </div>
  );
}

// Prompt Document
function PromptDocument() {
  return (
    <div id="prompt-document" className="prose prose-sm max-w-none">
      <h1>AI Prompt Document</h1>
      <p><strong>Purpose:</strong> Recreate QA Compliance Dashboard</p>
      <p><strong>Version:</strong> 1.0</p>
      
      <Separator className="my-4" />
      
      <h2>Complete Build Prompt</h2>
      
      <pre className="whitespace-pre-wrap text-xs">{`
Build a QA Compliance Department Dashboard with the following specifications:

## A) CORE STRUCTURE
- Technology: React + Vite + TypeScript + Tailwind CSS + shadcn/ui
- Layout: Fixed left sidebar (264px) + Header (56px) + Main content area
- Design: Healthcare-compliant theme with semantic color tokens

## B) NAVIGATION & LAYOUT

**Left Sidebar (QASidebar):**
- Dashboard (home)
- Org Chart
- KPI Oversight
- Risk Management
- Audit Management (role-restricted)
- Compliance Tracking (role-restricted)
- Feedback Management
- Enforcement Management (role-restricted)
- Documents

**Header (DashboardHeader):**
- Global search bar
- Role Impersonator dropdown
- Facility selector
- Notifications bell
- User avatar with role label

## C) ROLE IMPERSONATION SYSTEM

**Three roles:**
1. Admin / Compliance Head - Full system access
2. QA Department Head - Department management, no org-wide views
3. QA Staff - Limited view access only

**Permissions Matrix:**
| Permission | Admin | Dept Head | Staff |
|------------|-------|-----------|-------|
| View All Departments | ✓ | ✗ | ✗ |
| Create KPI | ✓ | ✓ | ✗ |
| Approve Proposals | ✓ | ✓ | ✗ |
| Export Data | ✓ | ✓ | ✗ |
| View Alerts | ✓ | ✓ | ✗ |
| View Audits | ✓ | ✓ | ✗ |
| View Compliance | ✓ | ✓ | ✗ |
| View Org Chart | ✓ | ✓ | ✓ |

## D) MAIN QA DASHBOARD

**Widgets:**
1. Action Center - Priority tasks
2. Review Queue - Pending items
3. Quick Stats - Summary metrics
4. KPI Oversight Summary - At-risk/overdue/breach with link to hub
5. Quality KPIs Panel - CRUD operations
6. Alerts Panel

## E) KPI OVERSIGHT HUB

**Route:** /dashboards/department/qa/kpi-oversight

**Tabs (role-dependent):**
1. Overview - Coverage tiles, at-risk table, governance queue
2. Departments (Admin only) - 7 department tiles
3. KPI Library - Searchable catalog
4. Proposals & Approvals (Admin/DeptHead) - Workflow management
5. Alerts (Admin/DeptHead) - Exception monitoring

**Actions:**
- Export CSV (role-restricted)
- Propose New KPI → Routes to FeedbackHub
- Create KPI → Opens form sheet (role-restricted)

## F) KPI CREATION FORM

**Sections:**
1. Basic: Name, Description, Department, Category
2. Formula: Metric Type, Numerator, Denominator, Formula (auto-generate)
3. Reporting: Cadence, Scope, Due Date Rule, Owner
4. Thresholds: Target, Green, Yellow, Red values
5. Tags: Oversight tags, Standard family tags
6. Evidence: Toggle for required pack

## G) DEPARTMENT KPI VIEW

**Route:** /dashboards/department/qa/kpi-oversight/departments/:dept
- Context badges showing department
- Summary tiles
- KPI scoreboard table
- Same actions as main hub

## H) DOCUMENTS PAGE

**Route:** /dashboards/department/qa/documents
- PRD, TDD, QA Test Cases, UAT Test Cases, Prompt
- Download as PDF functionality
      `}</pre>
    </div>
  );
}

export default function Documents() {
  const [activeTab, setActiveTab] = useState('prd');

  const documents = [
    { id: 'prd', label: 'PRD', icon: FileText, description: 'Product Requirements Document' },
    { id: 'tdd', label: 'TDD', icon: Code, description: 'Technical Design Document' },
    { id: 'qa-tests', label: 'QA Tests', icon: TestTube, description: 'QA Test Cases' },
    { id: 'uat-tests', label: 'UAT Tests', icon: ClipboardCheck, description: 'User Acceptance Tests' },
    { id: 'prompt', label: 'Prompt', icon: Sparkles, description: 'AI Build Prompt' },
  ];

  return (
    <DashboardLayout breadcrumbs={breadcrumbs}>
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Documentation</h1>
            <p className="text-muted-foreground mt-1">Project documentation and test cases</p>
          </div>
        </div>

        <div className="grid md:grid-cols-5 gap-4">
          {documents.map((doc) => (
            <Card 
              key={doc.id}
              className={`cursor-pointer transition-all hover:border-primary/50 ${activeTab === doc.id ? 'border-primary bg-primary/5' : ''}`}
              onClick={() => setActiveTab(doc.id)}
            >
              <CardHeader className="p-4">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${activeTab === doc.id ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                    <doc.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-sm">{doc.label}</CardTitle>
                    <CardDescription className="text-xs">{doc.description}</CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
          ))}
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>{documents.find(d => d.id === activeTab)?.description}</CardTitle>
              <CardDescription>Click download to save as PDF</CardDescription>
            </div>
            <Button onClick={() => handlePrint(`${activeTab}-document`)}>
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
          </CardHeader>
          <CardContent className="max-h-[600px] overflow-y-auto">
            {activeTab === 'prd' && <PRDDocument />}
            {activeTab === 'tdd' && <TDDDocument />}
            {activeTab === 'qa-tests' && <QATestCasesDocument />}
            {activeTab === 'uat-tests' && <UATTestCasesDocument />}
            {activeTab === 'prompt' && <PromptDocument />}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
