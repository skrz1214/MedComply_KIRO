import { useState } from 'react';
import { BucketPageLayout, ListItem } from '@/components/dashboard/BucketPageLayout';
import { feedbackTabs } from '@/data/mock-data';

const breadcrumbs = [
  { label: 'Home', href: '/' },
  { label: 'Dashboards', href: '/dashboards' },
  { label: 'Department', href: '/dashboards/department' },
  { label: 'Quality Assurance', href: '/dashboards/department/qa' },
  { label: 'Feedback Management' }
];

export default function FeedbackManagement() {
  const [activeTab, setActiveTab] = useState('all');
  
  const metrics = [
    { label: 'Total Feedback', value: 45 },
    { label: 'Open', value: 12, variant: 'warning' as const },
    { label: 'Resolved', value: 30, variant: 'success' as const },
    { label: 'SLA Breach', value: 3, variant: 'danger' as const },
  ];

  return (
    <BucketPageLayout
      title="Feedback Management"
      description="FeedbackHub QA View - Patient and staff feedback oversight"
      breadcrumbs={breadcrumbs}
      tabs={feedbackTabs}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      metrics={metrics}
      addRoute="/feedbackhub/new?dept=qa"
      addLabel="Add Feedback"
    >
      <div className="divide-y divide-border">
        <ListItem
          id="FB-001"
          title="Patient Complaint - Wait Times in ED"
          status="in-progress"
          priority="high"
          dueDate="2025-01-16"
          owner="Robert Wilson"
          department="Emergency"
          type="feedback"
          route="/feedbackhub/FB-001?from=qa-dashboard&dept=qa"
        />
        <ListItem
          id="FB-002"
          title="Staff Safety Concern - Hazardous Spill Protocol"
          status="pending-review"
          priority="medium"
          dueDate="2025-01-18"
          owner="Michael Chen"
          department="Safety"
          type="feedback"
          route="/feedbackhub/FB-002?from=qa-dashboard&dept=qa"
        />
        <ListItem
          id="FB-003"
          title="Quality Improvement Suggestion - Discharge Process"
          status="not-started"
          priority="low"
          dueDate="2025-01-25"
          owner="Sarah Chen"
          department="Patient Care"
          type="feedback"
          route="/feedbackhub/FB-003?from=qa-dashboard&dept=qa"
        />
        <ListItem
          id="FB-004"
          title="Patient Grievance - Communication Issues"
          status="overdue"
          priority="high"
          dueDate="2025-01-08"
          owner="Emily Davis"
          department="Patient Experience"
          type="feedback"
          route="/feedbackhub/FB-004?from=qa-dashboard&dept=qa"
        />
        <ListItem
          id="FB-005"
          title="Staff Feedback - Equipment Maintenance"
          status="completed"
          priority="medium"
          dueDate="2025-01-05"
          owner="Dr. Patricia Lee"
          department="Facilities"
          type="feedback"
          route="/feedbackhub/FB-005?from=qa-dashboard&dept=qa"
        />
      </div>
    </BucketPageLayout>
  );
}
