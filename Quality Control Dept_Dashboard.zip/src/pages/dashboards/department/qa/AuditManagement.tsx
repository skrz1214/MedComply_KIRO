import { useState } from 'react';
import { BucketPageLayout, ListItem } from '@/components/dashboard/BucketPageLayout';
import { auditTabs } from '@/data/mock-data';
import { Calendar, AlertCircle } from 'lucide-react';

const breadcrumbs = [
  { label: 'Home', href: '/' },
  { label: 'Dashboards', href: '/dashboards' },
  { label: 'Department', href: '/dashboards/department' },
  { label: 'Quality Assurance', href: '/dashboards/department/qa' },
  { label: 'Audit Management' }
];

export default function AuditManagement() {
  const [activeTab, setActiveTab] = useState('all');
  
  const metrics = [
    { label: 'Total Audits', value: 24 },
    { label: 'Pending Review', value: 6, variant: 'warning' as const },
    { label: 'Completed', value: 16, variant: 'success' as const },
    { label: 'Overdue', value: 2, variant: 'danger' as const },
  ];

  return (
    <BucketPageLayout
      title="Audit Management"
      description="AuditPro QA View - Internal and external audits for quality assurance"
      breadcrumbs={breadcrumbs}
      tabs={auditTabs}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      metrics={metrics}
      addRoute="/auditpro/audits/new?dept=qa"
      addLabel="Add Audit"
    >
      {/* Upcoming Deadlines Alert */}
      <div className="p-4 border-b border-border bg-warning-muted">
        <div className="flex items-center gap-3">
          <Calendar className="h-5 w-5 text-warning" />
          <div>
            <p className="text-sm font-medium text-warning">Upcoming Deadline</p>
            <p className="text-xs text-muted-foreground">Annual Accreditation Audit due in 5 days</p>
          </div>
        </div>
      </div>

      <div className="divide-y divide-border">
        <ListItem
          id="AUD-001"
          title="Annual Accreditation Readiness Audit"
          status="in-progress"
          priority="high"
          dueDate="2025-01-20"
          owner="Sarah Chen"
          department="Quality Assurance"
          type="audit"
          route="/auditpro/audits/AUD-001?from=qa-dashboard&dept=qa"
        />
        <ListItem
          id="AUD-002"
          title="Quarterly Infection Control Audit"
          status="pending-review"
          priority="medium"
          dueDate="2025-01-22"
          owner="Michael Chen"
          department="Infection Control"
          type="audit"
          route="/auditpro/audits/AUD-002?from=qa-dashboard&dept=qa"
        />
        <ListItem
          id="AUD-003"
          title="Patient Safety Protocol Validation"
          status="completed"
          priority="high"
          dueDate="2025-01-10"
          owner="Dr. Patricia Lee"
          department="Patient Care"
          type="audit"
          route="/auditpro/audits/AUD-003?from=qa-dashboard&dept=qa"
        />
        <ListItem
          id="AUD-004"
          title="Medication Administration Audit"
          status="not-started"
          priority="medium"
          dueDate="2025-02-01"
          owner="Emily Davis"
          department="Pharmacy"
          type="audit"
          route="/auditpro/audits/AUD-004?from=qa-dashboard&dept=qa"
        />
        <ListItem
          id="AUD-005"
          title="KPI Validation - Q4 2024"
          status="overdue"
          priority="high"
          dueDate="2025-01-05"
          owner="Robert Wilson"
          department="Quality Assurance"
          type="audit"
          route="/auditpro/audits/AUD-005?from=qa-dashboard&dept=qa"
        />
      </div>
    </BucketPageLayout>
  );
}
