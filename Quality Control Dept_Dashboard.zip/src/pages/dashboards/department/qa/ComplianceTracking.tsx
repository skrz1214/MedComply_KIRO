import { useState } from 'react';
import { Link } from 'react-router-dom';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { BucketPageLayout, ListItem } from '@/components/dashboard/BucketPageLayout';
import { complianceTabs } from '@/data/mock-data';
import { cn } from '@/lib/utils';

const breadcrumbs = [
  { label: 'Home', href: '/' },
  { label: 'Dashboards', href: '/dashboards' },
  { label: 'Department', href: '/dashboards/department' },
  { label: 'Quality Assurance', href: '/dashboards/department/qa' },
  { label: 'Compliance Tracking' }
];

const subTabs = [
  { id: 'items', label: 'Compliance Items' },
  { id: 'capa', label: 'CAPA' },
  { id: 'citations', label: 'Citations' },
  { id: 'policies', label: 'Policies/Docs' },
];

export default function ComplianceTracking() {
  const [activeTab, setActiveTab] = useState('all');
  const [activeSubTab, setActiveSubTab] = useState('items');
  
  const metrics = [
    { label: 'Total Items', value: 32 },
    { label: 'Open', value: 14, variant: 'warning' as const },
    { label: 'Resolved', value: 15, variant: 'success' as const },
    { label: 'Overdue', value: 3, variant: 'danger' as const },
  ];

  return (
    <DashboardLayout breadcrumbs={breadcrumbs}>
      <div className="space-y-6 animate-fade-in">
        {/* Page Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground">Compliance Tracking</h1>
          <p className="text-muted-foreground mt-1">ComplianceConnect + CAPA + Citations + Documents</p>
        </div>

        {/* Sub-tabs Navigation */}
        <div className="flex gap-1 p-1 bg-muted rounded-lg w-fit">
          {subTabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id)}
              className={cn(
                'px-4 py-2 text-sm font-medium rounded-md transition-colors',
                activeSubTab === tab.id
                  ? 'bg-card text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Metric Tiles */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {metrics.map((metric, index) => (
            <div
              key={index}
              className={cn(
                'dashboard-card p-4',
                metric.variant === 'danger' && 'border-destructive/30 bg-destructive-muted'
              )}
            >
              <p className="text-sm text-muted-foreground">{metric.label}</p>
              <p className={cn(
                'text-2xl font-bold mt-1',
                metric.variant === 'danger' ? 'text-destructive' : 'text-foreground'
              )}>
                {metric.value}
              </p>
            </div>
          ))}
        </div>

        {/* Content Card with Domain Tabs */}
        <div className="dashboard-card">
          {/* Domain Tabs */}
          <div className="border-b border-border overflow-x-auto">
            <div className="flex p-1 gap-1 min-w-max">
              {complianceTabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    'px-4 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap',
                    activeTab === tab.id
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  )}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Content based on sub-tab */}
          <div className="divide-y divide-border">
            {activeSubTab === 'items' && (
              <>
                <ListItem
                  id="COMP-001"
                  title="Patient Rights Documentation Gap"
                  status="in-progress"
                  priority="high"
                  dueDate="2025-01-18"
                  owner="Sarah Chen"
                  department="Quality Assurance"
                  type="compliance"
                  route="/complianceconnect/issues/COMP-001?from=qa-dashboard&dept=qa"
                />
                <ListItem
                  id="COMP-002"
                  title="Staff Competency Records Update"
                  status="pending-review"
                  priority="medium"
                  dueDate="2025-01-25"
                  owner="Emily Davis"
                  department="Human Resources"
                  type="compliance"
                  route="/complianceconnect/issues/COMP-002?from=qa-dashboard&dept=qa"
                />
                <ListItem
                  id="COMP-003"
                  title="Emergency Preparedness Plan Review"
                  status="not-started"
                  priority="medium"
                  dueDate="2025-02-01"
                  owner="Michael Chen"
                  department="Safety"
                  type="compliance"
                  route="/complianceconnect/issues/COMP-003?from=qa-dashboard&dept=qa"
                />
              </>
            )}
            {activeSubTab === 'capa' && (
              <>
                <ListItem
                  id="CAPA-001"
                  title="Medication Error Root Cause Analysis"
                  status="in-progress"
                  priority="high"
                  dueDate="2025-01-15"
                  owner="Dr. Patricia Lee"
                  department="Pharmacy"
                  type="capa"
                  route="/actionguard/capas/CAPA-001?from=qa-dashboard&dept=qa"
                />
                <ListItem
                  id="CAPA-002"
                  title="Patient Fall Prevention Protocol Update"
                  status="pending-review"
                  priority="high"
                  dueDate="2025-01-20"
                  owner="Sarah Chen"
                  department="Patient Care"
                  type="capa"
                  route="/actionguard/capas/CAPA-002?from=qa-dashboard&dept=qa"
                />
              </>
            )}
            {activeSubTab === 'citations' && (
              <>
                <ListItem
                  id="CIT-001"
                  title="Survey Finding - Infection Control"
                  status="in-progress"
                  priority="high"
                  dueDate="2025-01-22"
                  owner="Michael Chen"
                  department="Infection Control"
                  type="citation"
                  route="/citapro/citations/CIT-001?from=qa-dashboard&dept=qa"
                />
                <ListItem
                  id="CIT-002"
                  title="State Survey - Documentation Deficiency"
                  status="pending-review"
                  priority="medium"
                  dueDate="2025-01-28"
                  owner="Emily Davis"
                  department="Quality Assurance"
                  type="citation"
                  route="/citapro/citations/CIT-002?from=qa-dashboard&dept=qa"
                />
              </>
            )}
            {activeSubTab === 'policies' && (
              <>
                <ListItem
                  id="POL-001"
                  title="Quality Management System Policy"
                  status="completed"
                  owner="Dr. Patricia Lee"
                  department="Quality Assurance"
                  type="policy"
                  route="/documents/POL-001?from=qa-dashboard&dept=qa"
                />
                <ListItem
                  id="POL-002"
                  title="Patient Safety Event Reporting Policy"
                  status="completed"
                  owner="Sarah Chen"
                  department="Quality Assurance"
                  type="policy"
                  route="/documents/POL-002?from=qa-dashboard&dept=qa"
                />
                <ListItem
                  id="POL-003"
                  title="Internal Audit Procedures"
                  status="pending-review"
                  owner="Michael Chen"
                  department="Quality Assurance"
                  type="policy"
                  route="/documents/POL-003?from=qa-dashboard&dept=qa"
                />
              </>
            )}
          </div>
        </div>

        {/* Return Link */}
        <div className="flex justify-center">
          <Link 
            to="/dashboards/department/qa"
            className="text-sm text-muted-foreground hover:text-primary transition-colors flex items-center gap-1"
          >
            ← Return to QA Dashboard
          </Link>
        </div>
      </div>
    </DashboardLayout>
  );
}
