import { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'admin' | 'department-head' | 'staff';

export interface RolePermissions {
  canViewAllDepartments: boolean;
  canCreateKPI: boolean;
  canApproveProposals: boolean;
  canEditGovernance: boolean;
  canExportData: boolean;
  canViewAlerts: boolean;
  canManageUsers: boolean;
  canViewOrgChart: boolean;
  canViewAudits: boolean;
  canViewCompliance: boolean;
}

const rolePermissions: Record<UserRole, RolePermissions> = {
  'admin': {
    canViewAllDepartments: true,
    canCreateKPI: true,
    canApproveProposals: true,
    canEditGovernance: true,
    canExportData: true,
    canViewAlerts: true,
    canManageUsers: true,
    canViewOrgChart: true,
    canViewAudits: true,
    canViewCompliance: true,
  },
  'department-head': {
    canViewAllDepartments: false,
    canCreateKPI: true,
    canApproveProposals: true,
    canEditGovernance: false,
    canExportData: true,
    canViewAlerts: true,
    canManageUsers: false,
    canViewOrgChart: true,
    canViewAudits: true,
    canViewCompliance: true,
  },
  'staff': {
    canViewAllDepartments: false,
    canCreateKPI: false,
    canApproveProposals: false,
    canEditGovernance: false,
    canExportData: false,
    canViewAlerts: false,
    canManageUsers: false,
    canViewOrgChart: true,
    canViewAudits: false,
    canViewCompliance: false,
  },
};

const roleLabels: Record<UserRole, string> = {
  'admin': 'Admin / Compliance Head',
  'department-head': 'QA Department Head',
  'staff': 'QA Staff',
};

const roleDepartments: Record<UserRole, string | null> = {
  'admin': null, // Can see all
  'department-head': 'qa', // QA Department
  'staff': 'qa', // QA Department
};

interface RoleContextType {
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  permissions: RolePermissions;
  roleLabel: string;
  assignedDepartment: string | null;
  allRoles: UserRole[];
  getRoleLabel: (role: UserRole) => string;
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export function RoleProvider({ children }: { children: ReactNode }) {
  const [currentRole, setCurrentRole] = useState<UserRole>('admin');

  const value: RoleContextType = {
    currentRole,
    setCurrentRole,
    permissions: rolePermissions[currentRole],
    roleLabel: roleLabels[currentRole],
    assignedDepartment: roleDepartments[currentRole],
    allRoles: ['admin', 'department-head', 'staff'],
    getRoleLabel: (role: UserRole) => roleLabels[role],
  };

  return (
    <RoleContext.Provider value={value}>
      {children}
    </RoleContext.Provider>
  );
}

export function useRole() {
  const context = useContext(RoleContext);
  if (context === undefined) {
    throw new Error('useRole must be used within a RoleProvider');
  }
  return context;
}
