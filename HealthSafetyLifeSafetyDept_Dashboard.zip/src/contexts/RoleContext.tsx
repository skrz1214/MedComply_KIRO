import { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'admin' | 'department_head' | 'staff';

interface RoleContextType {
  currentRole: UserRole;
  setRole: (role: UserRole) => void;
  roleLabel: string;
}

const roleLabels: Record<UserRole, string> = {
  admin: 'Admin / Compliance Head',
  department_head: 'Department Head',
  staff: 'Staff',
};

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export const RoleProvider = ({ children }: { children: ReactNode }) => {
  const [currentRole, setCurrentRole] = useState<UserRole>('admin');

  const setRole = (role: UserRole) => {
    setCurrentRole(role);
  };

  return (
    <RoleContext.Provider
      value={{
        currentRole,
        setRole,
        roleLabel: roleLabels[currentRole],
      }}
    >
      {children}
    </RoleContext.Provider>
  );
};

export const useRole = () => {
  const context = useContext(RoleContext);
  if (!context) {
    throw new Error('useRole must be used within a RoleProvider');
  }
  return context;
};
