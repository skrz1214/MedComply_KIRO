import { useState } from 'react';
import { Plus, Download, ArrowLeft, FileText, Search, Filter } from 'lucide-react';
import { Link } from 'react-router-dom';
import DashboardLayout from '@/components/layout/DashboardLayout';
import DataTable, { Column } from '@/components/shared/DataTable';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { mockPolicies } from '@/data/mockData';

const policyColumns: Column<typeof mockPolicies[0]>[] = [
  { key: 'id', header: 'Doc ID' },
  {
    key: 'name',
    header: 'Name',
    className: 'max-w-md',
    render: (item) => (
      <div className="flex items-center gap-2">
        <FileText className="w-4 h-4 text-primary" />
        <span className="font-medium">{item.name}</span>
      </div>
    ),
  },
  { key: 'category', header: 'Category' },
  { key: 'lastUpdate', header: 'Last Update' },
  { key: 'status', header: 'Status' },
  { key: 'nextReviewDate', header: 'Next Review' },
  { key: 'owner', header: 'Owner' },
];

const Documentation = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'Dashboards', path: '/dashboards' },
    { label: 'Department', path: '/dashboards/department' },
    { label: 'HSLS', path: '/dashboards/department/hsls' },
    { label: 'Documentation' },
  ];

  const categories = [...new Set(mockPolicies.map((p) => p.category))];

  return (
    <DashboardLayout
      title="HSLS Documentation"
      subtitle="Policies & Procedures"
      breadcrumbs={breadcrumbs}
    >
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/dashboards/department/hsls"
          className="flex items-center gap-2 text-sm text-primary hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to HSLS Dashboard
        </Link>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          <Button size="sm" className="bg-primary hover:bg-primary/90">
            <Plus className="w-4 h-4 mr-2" />
            Add Document
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="stat-card bg-primary-light">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Total Policies</p>
          <p className="text-2xl font-bold mt-1 text-primary">{mockPolicies.length}</p>
        </div>
        <div className="stat-card bg-success-light">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Active</p>
          <p className="text-2xl font-bold mt-1 text-success">
            {mockPolicies.filter((p) => p.status === 'active').length}
          </p>
        </div>
        <div className="stat-card bg-warning-light">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Under Review</p>
          <p className="text-2xl font-bold mt-1 text-warning">
            {mockPolicies.filter((p) => p.status === 'under_review').length}
          </p>
        </div>
        <div className="stat-card bg-info-light">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Review Due Soon</p>
          <p className="text-2xl font-bold mt-1 text-info">2</p>
        </div>
      </div>

      {/* Filters */}
      <div className="dashboard-card p-4 mb-6">
        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search documents..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-48">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>
                  {cat}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="under_review">Under Review</SelectItem>
              <SelectItem value="archived">Archived</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="dashboard-card">
        <DataTable
          columns={policyColumns}
          data={mockPolicies}
          onRowClick={(item) => console.log('Navigate to:', `/documents/${item.id}`)}
          actions={[
            { label: 'View', onClick: (item) => console.log('View', item.id) },
            { label: 'Edit', onClick: (item) => console.log('Edit', item.id) },
            { label: 'Download', onClick: (item) => console.log('Download', item.id) },
            { label: 'Archive', onClick: (item) => console.log('Archive', item.id) },
          ]}
        />
      </div>
    </DashboardLayout>
  );
};

export default Documentation;
