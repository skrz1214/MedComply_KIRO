import DashboardLayout from '@/components/layout/DashboardLayout';
import ActionCenter from '@/components/dashboard/ActionCenter';
import ReviewQueue from '@/components/dashboard/ReviewQueue';
import QuickStats from '@/components/dashboard/QuickStats';
import QualityKPIs from '@/components/dashboard/QualityKPIs';
import AlertsPanel from '@/components/dashboard/AlertsPanel';
import QuickAccess from '@/components/dashboard/QuickAccess';

const HSLSDashboard = () => {
  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'Dashboards', path: '/dashboards' },
    { label: 'Department', path: '/dashboards/department' },
    { label: 'HSLS' },
  ];

  return (
    <DashboardLayout
      title="Health Safety & Life Safety Dashboard"
      subtitle="HSLS Compliance Dashboard"
      breadcrumbs={breadcrumbs}
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Main Content */}
        <div className="lg:col-span-2 space-y-6">
          <ActionCenter />
          <ReviewQueue />
        </div>

        {/* Right Column - Stats & KPIs */}
        <div className="space-y-6">
          <QuickStats />
          <QualityKPIs />
          <AlertsPanel />
        </div>
      </div>

      {/* Quick Access Tiles */}
      <QuickAccess />
    </DashboardLayout>
  );
};

export default HSLSDashboard;
