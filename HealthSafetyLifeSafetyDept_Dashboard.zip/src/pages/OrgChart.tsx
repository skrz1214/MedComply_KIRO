import { useState } from 'react';
import { Plus, Mail, ArrowLeft, Users, Building, Pencil, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { mockOrgMembers } from '@/data/mockData';
import { toast } from '@/hooks/use-toast';

interface OrgMember {
  id: string;
  name: string;
  role: string;
  department: string;
  email: string;
  status: 'active' | 'inactive';
  reportsTo?: string;
}

const defaultMember: Omit<OrgMember, 'id'> = {
  name: '',
  role: '',
  department: 'HSLS',
  email: '',
  status: 'active',
  reportsTo: '',
};

const OrgChart = () => {
  const [members, setMembers] = useState<OrgMember[]>(mockOrgMembers as OrgMember[]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<OrgMember | null>(null);
  const [deleteMemberId, setDeleteMemberId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Omit<OrgMember, 'id'>>(defaultMember);

  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'Dashboards', path: '/dashboards' },
    { label: 'Department', path: '/dashboards/department' },
    { label: 'HSLS', path: '/dashboards/department/hsls' },
    { label: 'Org Chart' },
  ];

  const chiefOfficer = members[0];
  const teamMembers = members.slice(1);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase();
  };

  const handleOpenAdd = () => {
    setEditingMember(null);
    setFormData(defaultMember);
    setDialogOpen(true);
  };

  const handleOpenEdit = (member: OrgMember) => {
    setEditingMember(member);
    setFormData({
      name: member.name,
      role: member.role,
      department: member.department,
      email: member.email,
      status: member.status,
      reportsTo: member.reportsTo || '',
    });
    setDialogOpen(true);
  };

  const handleOpenDelete = (id: string) => {
    setDeleteMemberId(id);
    setDeleteDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.name.trim()) {
      toast({ title: 'Error', description: 'Name is required', variant: 'destructive' });
      return;
    }
    if (!formData.role.trim()) {
      toast({ title: 'Error', description: 'Role is required', variant: 'destructive' });
      return;
    }
    if (!formData.email.trim()) {
      toast({ title: 'Error', description: 'Email is required', variant: 'destructive' });
      return;
    }

    if (editingMember) {
      setMembers(prev =>
        prev.map(m =>
          m.id === editingMember.id ? { ...m, ...formData } : m
        )
      );
      toast({ title: 'Success', description: 'Member updated successfully' });
    } else {
      const newMember: OrgMember = {
        id: `ORG-${Date.now()}`,
        ...formData,
      };
      setMembers(prev => [...prev, newMember]);
      toast({ title: 'Success', description: 'Member added successfully' });
    }

    setDialogOpen(false);
    setFormData(defaultMember);
    setEditingMember(null);
  };

  const handleDelete = () => {
    if (deleteMemberId) {
      setMembers(prev => prev.filter(m => m.id !== deleteMemberId));
      toast({ title: 'Success', description: 'Member deactivated successfully' });
    }
    setDeleteDialogOpen(false);
    setDeleteMemberId(null);
  };

  const handleSendMessage = (email: string) => {
    window.location.href = `mailto:${email}`;
  };

  const renderOrgCard = (member: OrgMember, isChief = false) => (
    <div
      className={cn(
        'dashboard-card p-4 text-center transition-all hover:shadow-card-hover group',
        isChief && 'border-primary/50'
      )}
    >
      <div className="relative inline-block">
        <Avatar className={cn('mx-auto', isChief ? 'w-16 h-16' : 'w-12 h-12')}>
          <AvatarFallback className="bg-primary/10 text-primary font-medium">
            {getInitials(member.name)}
          </AvatarFallback>
        </Avatar>
        {member.status === 'active' && (
          <div className="absolute bottom-0 right-0 w-3 h-3 bg-success rounded-full border-2 border-card" />
        )}
      </div>
      <h3 className={cn('font-medium mt-3', isChief ? 'text-lg' : 'text-sm')}>
        {member.name}
      </h3>
      <p className="text-xs text-muted-foreground mt-1">{member.role}</p>
      <Badge variant="secondary" className="mt-2 text-xs">
        {member.department}
      </Badge>
      <div className="flex items-center justify-center gap-2 mt-3">
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          title="Send Message"
          onClick={() => handleSendMessage(member.email)}
        >
          <Mail className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={() => handleOpenEdit(member)}
        >
          <Pencil className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive"
          onClick={() => handleOpenDelete(member.id)}
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );

  return (
    <DashboardLayout
      title="HSLS Governing Body"
      subtitle="Organization Chart"
      breadcrumbs={breadcrumbs}
    >
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/dashboards/department/hsls"
          className="flex items-center gap-2 text-sm text-primary hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to HSLS Dashboard
        </Link>

        <Button size="sm" className="bg-primary hover:bg-primary/90" onClick={handleOpenAdd}>
          <Plus className="w-4 h-4 mr-2" />
          Add Member
        </Button>
      </div>

      {/* Chart View */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <Building className="w-5 h-5" />
          Organization Chart
        </h3>
        <div className="flex flex-col items-center">
          {/* Chief Officer */}
          {chiefOfficer && (
            <div className="mb-8">
              {renderOrgCard(chiefOfficer, true)}
            </div>
          )}

          {/* Connector Line */}
          {teamMembers.length > 0 && (
            <>
              <div className="w-0.5 h-8 bg-border" />
              <div className="w-3/4 h-0.5 bg-border" />
            </>
          )}

          {/* Team Members */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8 w-full max-w-4xl">
            {teamMembers.map((member) => (
              <div key={member.id} className="flex flex-col items-center">
                <div className="w-0.5 h-8 bg-border" />
                {renderOrgCard(member)}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* List View */}
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <Users className="w-5 h-5" />
          Members List
        </h3>
        <div className="dashboard-card">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase">
                  Name
                </th>
                <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase">
                  Role
                </th>
                <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase">
                  Department
                </th>
                <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase">
                  Email
                </th>
                <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase">
                  Status
                </th>
                <th className="w-16"></th>
              </tr>
            </thead>
            <tbody>
              {members.map((member) => (
                <tr key={member.id} className="border-b border-border hover:bg-muted/30 group">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-primary/10 text-primary text-xs">
                          {getInitials(member.name)}
                        </AvatarFallback>
                      </Avatar>
                      <span className="font-medium">{member.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-sm">{member.role}</td>
                  <td className="py-3 px-4">
                    <Badge variant="secondary">{member.department}</Badge>
                  </td>
                  <td className="py-3 px-4 text-sm text-muted-foreground">{member.email}</td>
                  <td className="py-3 px-4">
                    <Badge
                      variant="outline"
                      className={cn(
                        member.status === 'active'
                          ? 'bg-success/10 text-success border-success/20'
                          : 'bg-muted text-muted-foreground'
                      )}
                    >
                      {member.status}
                    </Badge>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleSendMessage(member.email)}
                      >
                        <Mail className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => handleOpenEdit(member)}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive"
                        onClick={() => handleOpenDelete(member.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingMember ? 'Edit Member' : 'Add New Member'}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="member-name">Full Name</Label>
              <Input
                id="member-name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="e.g., John Smith"
                maxLength={100}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="member-role">Role / Title</Label>
              <Input
                id="member-role"
                value={formData.role}
                onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value }))}
                placeholder="e.g., Safety Director"
                maxLength={100}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="member-email">Email</Label>
              <Input
                id="member-email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                placeholder="e.g., john.smith@healthcare.org"
                maxLength={255}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="member-department">Department</Label>
                <Input
                  id="member-department"
                  value={formData.department}
                  onChange={(e) => setFormData(prev => ({ ...prev, department: e.target.value }))}
                  placeholder="e.g., HSLS"
                  maxLength={50}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="member-status">Status</Label>
                <Select
                  value={formData.status}
                  onValueChange={(val: 'active' | 'inactive') => setFormData(prev => ({ ...prev, status: val }))}
                >
                  <SelectTrigger id="member-status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="member-reports-to">Reports To (Optional)</Label>
              <Select
                value={formData.reportsTo || ''}
                onValueChange={(val) => setFormData(prev => ({ ...prev, reportsTo: val }))}
              >
                <SelectTrigger id="member-reports-to">
                  <SelectValue placeholder="Select supervisor" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">None</SelectItem>
                  {members
                    .filter(m => m.id !== editingMember?.id)
                    .map(m => (
                      <SelectItem key={m.id} value={m.id}>
                        {m.name} - {m.role}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave}>
              {editingMember ? 'Update' : 'Add'} Member
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Deactivate Member</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to deactivate this member? They will be removed from the org chart.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Deactivate
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
};

export default OrgChart;
