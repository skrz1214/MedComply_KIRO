import { useState } from 'react';
import { Plus, Download, ArrowLeft, Calendar } from 'lucide-react';
import { Link } from 'react-router-dom';
import DashboardLayout from '@/components/layout/DashboardLayout';
import MetricTiles from '@/components/shared/MetricTiles';
import DomainTabs from '@/components/shared/DomainTabs';
import DataTable, { Column } from '@/components/shared/DataTable';
import { Button } from '@/components/ui/button';

const domainTabs = [
  { id: 'all', label: 'All HSLS', count: 2 },
  { id: 'survey', label: 'Survey/Inspection Enforcement', count: 1 },
  { id: 'life-safety', label: 'Life Safety Code Enforcement', count: 1 },
  { id: 'workplace-safety', label: 'Workplace Safety / OSHA Enforcement', count: 0 },
  { id: 'emergency-prep', label: 'Emergency Preparedness Enforcement', count: 0 },
];

const mockEnforcementItems = [
  {
    id: 'ENF-001',
    title: 'CMS Immediate Jeopardy - Fire Safety',
    status: 'open',
    dueDate: '2024-12-28',
    owner: 'Compliance Director',
    priority: 'critical',
    hslsDomains: ['life-safety'],
  },
  {
    id: 'ENF-002',
    title: 'State Survey Deficiency Response',
    status: 'in_progress',
    dueDate: '2025-01-05',
    owner: 'Quality Manager',
    priority: 'high',
    hslsDomains: ['survey-readiness'],
  },
];

const enforcementColumns: Column<typeof mockEnforcementItems[0]>[] = [
  { key: 'id', header: 'Enforcement ID' },
  { key: 'title', header: 'Title', className: 'max-w-md' },
  { key: 'status', header: 'Status' },
  { key: 'dueDate', header: 'Due Date' },
  { key: 'owner', header: 'Owner' },
  { key: 'priority', header: 'Priority' },
  { key: 'hslsDomains', header: 'HSLS Domains' },
];

const upcomingDeadlines = [
  { id: 'ENF-001', title: 'CMS IJ Response Due', deadline: 'Dec 28, 2024', daysLeft: 4 },
  { id: 'ENF-002', title: 'State Deficiency Response', deadline: 'Jan 5, 2025', daysLeft: 12 },
];

const EnforcementManagement = () => {
  const [activeTab, setActiveTab] = useState('all');
  const [metricFilter, setMetricFilter] = useState<string | undefined>();

  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'Dashboards', path: '/dashboards' },
    { label: 'Department', path: '/dashboards/department' },
    { label: 'HSLS', path: '/dashboards/department/hsls' },
    { label: 'Enforcement Management' },
  ];

  const metrics = {
    total: mockEnforcementItems.length,
    pendingReview: mockEnforcementItems.filter((e) => e.status === 'pending_review').length,
    completed: mockEnforcementItems.filter((e) => e.status === 'completed').length,
    overdue: mockEnforcementItems.filter((e) => e.status === 'overdue').length,
  };

  return (
    <DashboardLayout
      title="Enforcement Management"
      subtitle="EnforcePoint HSLS View"
      breadcrumbs={breadcrumbs}
    >
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/dashboards/department/hsls"
          className="flex items-center gap-2 text-sm text-primary hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to HSLS Dashboard
        </Link>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          <Button size="sm" className="bg-primary hover:bg-primary/90">
            <Plus className="w-4 h-4 mr-2" />
            Add Enforcement Case
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
        <div className="lg:col-span-3">
          <MetricTiles
            {...metrics}
            activeFilter={metricFilter}
            onTileClick={setMetricFilter}
          />
        </div>

        <div className="dashboard-card p-4">
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="w-4 h-4 text-critical" />
            <h3 className="font-medium text-sm">Critical Deadlines</h3>
          </div>
          <div className="space-y-3">
            {upcomingDeadlines.map((item) => (
              <div
                key={item.id}
                className="p-2 bg-critical-light rounded-lg cursor-pointer hover:opacity-80"
              >
                <p className="text-sm font-medium text-foreground truncate">{item.title}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {item.deadline} ({item.daysLeft} days left)
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <DomainTabs
        tabs={domainTabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      <div className="dashboard-card">
        <DataTable
          columns={enforcementColumns}
          data={mockEnforcementItems}
          onRowClick={(item) => console.log('Navigate to:', `/enforcepoint/cases/${item.id}`)}
          actions={[
            { label: 'View Details', onClick: (item) => console.log('View', item.id) },
            { label: 'Edit', onClick: (item) => console.log('Edit', item.id) },
            { label: 'Submit Response', onClick: (item) => console.log('Submit', item.id) },
          ]}
        />
      </div>
    </DashboardLayout>
  );
};

export default EnforcementManagement;
