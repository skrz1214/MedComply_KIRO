import { useState } from 'react';
import { Plus, Download, ArrowLeft, Calendar } from 'lucide-react';
import { Link } from 'react-router-dom';
import DashboardLayout from '@/components/layout/DashboardLayout';
import MetricTiles from '@/components/shared/MetricTiles';
import DomainTabs from '@/components/shared/DomainTabs';
import DataTable, { Column } from '@/components/shared/DataTable';
import { Button } from '@/components/ui/button';
import { mockAuditItems } from '@/data/mockData';

const domainTabs = [
  { id: 'all', label: 'All HSLS', count: mockAuditItems.length },
  { id: 'life-safety', label: 'Life Safety Rounds / Inspections', count: 1 },
  { id: 'emergency-prep', label: 'Emergency Preparedness Drills', count: 1 },
  { id: 'environment-care', label: 'Environment of Care Audits', count: 1 },
  { id: 'equipment-safety', label: 'Equipment Safety Audits', count: 0 },
  { id: 'survey-readiness', label: 'Survey Readiness Audits', count: 0 },
  { id: 'checklist', label: 'Checklist Audits', count: 0 },
];

const auditColumns: Column<typeof mockAuditItems[0]>[] = [
  { key: 'id', header: 'Audit ID' },
  { key: 'title', header: 'Title', className: 'max-w-md' },
  { key: 'status', header: 'Status' },
  { key: 'deadline', header: 'Deadline' },
  { key: 'owner', header: 'Owner' },
  { key: 'priority', header: 'Priority' },
  { key: 'hslsDomains', header: 'HSLS Domains' },
];

const upcomingDeadlines = [
  { id: 'AUD-001', title: 'Monthly Fire Safety Rounds', deadline: 'Dec 31, 2024', daysLeft: 7 },
  { id: 'AUD-003', title: 'Environment of Care Walkthrough', deadline: 'Dec 28, 2024', daysLeft: 4 },
];

const AuditManagement = () => {
  const [activeTab, setActiveTab] = useState('all');
  const [metricFilter, setMetricFilter] = useState<string | undefined>();

  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'Dashboards', path: '/dashboards' },
    { label: 'Department', path: '/dashboards/department' },
    { label: 'HSLS', path: '/dashboards/department/hsls' },
    { label: 'Audit Management' },
  ];

  const metrics = {
    total: mockAuditItems.length,
    pendingReview: mockAuditItems.filter((a) => a.status === 'pending_review').length,
    completed: mockAuditItems.filter((a) => a.status === 'completed').length,
    overdue: mockAuditItems.filter((a) => a.status === 'overdue').length,
  };

  return (
    <DashboardLayout
      title="Audit Management"
      subtitle="AuditPro HSLS View"
      breadcrumbs={breadcrumbs}
    >
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/dashboards/department/hsls"
          className="flex items-center gap-2 text-sm text-primary hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to HSLS Dashboard
        </Link>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          <Button size="sm" className="bg-primary hover:bg-primary/90">
            <Plus className="w-4 h-4 mr-2" />
            Add Audit
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
        <div className="lg:col-span-3">
          <MetricTiles
            {...metrics}
            activeFilter={metricFilter}
            onTileClick={setMetricFilter}
          />
        </div>

        <div className="dashboard-card p-4">
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="w-4 h-4 text-primary" />
            <h3 className="font-medium text-sm">Upcoming Deadlines</h3>
          </div>
          <div className="space-y-3">
            {upcomingDeadlines.map((item) => (
              <div
                key={item.id}
                className="p-2 bg-warning-light rounded-lg cursor-pointer hover:opacity-80"
              >
                <p className="text-sm font-medium text-foreground truncate">{item.title}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {item.deadline} ({item.daysLeft} days left)
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <DomainTabs
        tabs={domainTabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      <div className="dashboard-card">
        <DataTable
          columns={auditColumns}
          data={mockAuditItems}
          onRowClick={(item) => console.log('Navigate to:', `/auditpro/audits/${item.id}`)}
          actions={[
            { label: 'View Details', onClick: (item) => console.log('View', item.id) },
            { label: 'Edit', onClick: (item) => console.log('Edit', item.id) },
            { label: 'Complete Audit', onClick: (item) => console.log('Complete', item.id) },
          ]}
        />
      </div>
    </DashboardLayout>
  );
};

export default AuditManagement;
