import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';

const Index = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect to HSLS Dashboard
    navigate('/dashboards/department/hsls');
  }, [navigate]);

  return null;
};

export default Index;
