import { useState } from 'react';
import { Plus, Download, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import DashboardLayout from '@/components/layout/DashboardLayout';
import MetricTiles from '@/components/shared/MetricTiles';
import DomainTabs from '@/components/shared/DomainTabs';
import DataTable, { Column } from '@/components/shared/DataTable';
import { Button } from '@/components/ui/button';

const domainTabs = [
  { id: 'all', label: 'All HSLS', count: 3 },
  { id: 'safety-concerns', label: 'Safety Concerns / Near Miss', count: 1 },
  { id: 'incident-reports', label: 'Incident / Accident Reports', count: 1 },
  { id: 'employee-violations', label: 'Employee Violations', count: 1 },
  { id: 'equipment-safety', label: 'Equipment Safety Concerns', count: 0 },
];

const mockFeedbackItems = [
  {
    id: 'FB-001',
    type: 'Near Miss',
    category: 'Safety Concern',
    status: 'open',
    owner: 'Safety Officer',
    slaDue: '2024-12-26',
    hslsDomains: ['workplace-safety'],
  },
  {
    id: 'FB-002',
    type: 'Incident Report',
    category: 'Employee Injury',
    status: 'in_progress',
    owner: 'HR Manager',
    slaDue: '2024-12-28',
    hslsDomains: ['incident-review'],
  },
  {
    id: 'FB-003',
    type: 'Violation Report',
    category: 'PPE Non-Compliance',
    status: 'pending_review',
    owner: 'Department Head',
    slaDue: '2024-12-30',
    hslsDomains: ['employee-violations'],
  },
];

const feedbackColumns: Column<typeof mockFeedbackItems[0]>[] = [
  { key: 'id', header: 'Feedback ID' },
  { key: 'type', header: 'Type' },
  { key: 'category', header: 'Category' },
  { key: 'status', header: 'Status' },
  { key: 'owner', header: 'Owner' },
  { key: 'slaDue', header: 'SLA Due' },
  { key: 'hslsDomains', header: 'HSLS Domains' },
];

const FeedbackManagement = () => {
  const [activeTab, setActiveTab] = useState('all');
  const [metricFilter, setMetricFilter] = useState<string | undefined>();

  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'Dashboards', path: '/dashboards' },
    { label: 'Department', path: '/dashboards/department' },
    { label: 'HSLS', path: '/dashboards/department/hsls' },
    { label: 'Feedback Management' },
  ];

  const metrics = {
    total: mockFeedbackItems.length,
    pendingReview: mockFeedbackItems.filter((f) => f.status === 'pending_review').length,
    completed: mockFeedbackItems.filter((f) => f.status === 'completed').length,
    overdue: mockFeedbackItems.filter((f) => f.status === 'overdue').length,
  };

  return (
    <DashboardLayout
      title="Feedback Management"
      subtitle="FeedbackHub HSLS View"
      breadcrumbs={breadcrumbs}
    >
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/dashboards/department/hsls"
          className="flex items-center gap-2 text-sm text-primary hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to HSLS Dashboard
        </Link>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          <Button size="sm" className="bg-primary hover:bg-primary/90">
            <Plus className="w-4 h-4 mr-2" />
            Add Feedback
          </Button>
        </div>
      </div>

      <MetricTiles
        {...metrics}
        activeFilter={metricFilter}
        onTileClick={setMetricFilter}
      />

      <DomainTabs
        tabs={domainTabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      <div className="dashboard-card">
        <DataTable
          columns={feedbackColumns}
          data={mockFeedbackItems}
          onRowClick={(item) => console.log('Navigate to:', `/feedbackhub/items/${item.id}`)}
          actions={[
            { label: 'View Details', onClick: (item) => console.log('View', item.id) },
            { label: 'Edit', onClick: (item) => console.log('Edit', item.id) },
            { label: 'Escalate to Compliance', onClick: (item) => console.log('Escalate', item.id) },
          ]}
        />
      </div>
    </DashboardLayout>
  );
};

export default FeedbackManagement;
