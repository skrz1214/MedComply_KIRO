import { useRef } from 'react';
import { Download, ArrowLeft, TestTube, CheckCircle, XCircle, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import jsPDF from 'jspdf';

const testCases = [
  { id: 'TC-001', module: 'Dashboard', title: 'Verify dashboard loads correctly', priority: 'High', status: 'Pass' },
  { id: 'TC-002', module: 'Dashboard', title: 'Verify KPI tiles display accurate data', priority: 'High', status: 'Pass' },
  { id: 'TC-003', module: 'Risk Management', title: 'Verify risk list pagination works', priority: 'Medium', status: 'Pass' },
  { id: 'TC-004', module: 'Risk Management', title: 'Verify risk severity filters', priority: 'High', status: 'Pass' },
  { id: 'TC-005', module: 'Audit Management', title: 'Verify audit creation workflow', priority: 'High', status: 'Pending' },
  { id: 'TC-006', module: 'Audit Management', title: 'Verify audit status updates', priority: 'Medium', status: 'Pass' },
  { id: 'TC-007', module: 'Compliance', title: 'Verify compliance chart rendering', priority: 'Medium', status: 'Pass' },
  { id: 'TC-008', module: 'Compliance', title: 'Verify compliance trend calculations', priority: 'High', status: 'Pass' },
  { id: 'TC-009', module: 'Enforcement', title: 'Verify enforcement action creation', priority: 'High', status: 'Pending' },
  { id: 'TC-010', module: 'Feedback', title: 'Verify feedback submission form', priority: 'Medium', status: 'Pass' },
  { id: 'TC-011', module: 'Navigation', title: 'Verify sidebar navigation links', priority: 'High', status: 'Pass' },
  { id: 'TC-012', module: 'Navigation', title: 'Verify breadcrumb navigation', priority: 'Low', status: 'Pass' },
  { id: 'TC-013', module: 'Role Switcher', title: 'Verify role switching functionality', priority: 'High', status: 'Pass' },
  { id: 'TC-014', module: 'Responsive', title: 'Verify mobile responsive layout', priority: 'High', status: 'Pass' },
  { id: 'TC-015', module: 'PDF Export', title: 'Verify PDF download functionality', priority: 'Medium', status: 'Pass' },
];

const QATestCases = () => {
  const contentRef = useRef<HTMLDivElement>(null);

  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'HSLS', path: '/dashboards/department/hsls' },
    { label: 'QA Test Cases' },
  ];

  const downloadPDF = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    let yPos = 20;

    // Title
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text('QA Test Cases Document', pageWidth / 2, yPos, { align: 'center' });
    yPos += 10;

    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text('HSLS Safety Management System', pageWidth / 2, yPos, { align: 'center' });
    yPos += 15;

    // Document Info
    doc.setFontSize(10);
    doc.text(`Version: 1.0`, 20, yPos);
    yPos += 6;
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 20, yPos);
    yPos += 6;
    doc.text(`Total Test Cases: ${testCases.length}`, 20, yPos);
    yPos += 6;
    doc.text(`Pass: ${testCases.filter(t => t.status === 'Pass').length} | Pending: ${testCases.filter(t => t.status === 'Pending').length}`, 20, yPos);
    yPos += 15;

    // Test Cases Table Header
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('ID', 20, yPos);
    doc.text('Module', 45, yPos);
    doc.text('Test Case Title', 85, yPos);
    doc.text('Priority', 155, yPos);
    doc.text('Status', 180, yPos);
    yPos += 8;

    // Draw line
    doc.line(20, yPos - 3, pageWidth - 20, yPos - 3);

    // Test Cases
    doc.setFont('helvetica', 'normal');
    testCases.forEach((tc) => {
      if (yPos > 270) {
        doc.addPage();
        yPos = 20;
      }
      doc.text(tc.id, 20, yPos);
      doc.text(tc.module, 45, yPos);
      const titleLines = doc.splitTextToSize(tc.title, 65);
      doc.text(titleLines[0], 85, yPos);
      doc.text(tc.priority, 155, yPos);
      doc.text(tc.status, 180, yPos);
      yPos += 8;
    });

    doc.save('HSLS_QA_Test_Cases.pdf');
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Pass':
        return <CheckCircle className="w-4 h-4 text-success" />;
      case 'Fail':
        return <XCircle className="w-4 h-4 text-destructive" />;
      default:
        return <Clock className="w-4 h-4 text-warning" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Pass':
        return <Badge className="bg-success/10 text-success border-success/20">Pass</Badge>;
      case 'Fail':
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">Fail</Badge>;
      default:
        return <Badge className="bg-warning/10 text-warning border-warning/20">Pending</Badge>;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'High':
        return <Badge variant="destructive">High</Badge>;
      case 'Medium':
        return <Badge variant="secondary">Medium</Badge>;
      default:
        return <Badge variant="outline">Low</Badge>;
    }
  };

  return (
    <DashboardLayout
      title="QA Test Cases"
      subtitle="Quality Assurance Testing"
      breadcrumbs={breadcrumbs}
    >
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/dashboards/department/hsls"
          className="flex items-center gap-2 text-sm text-primary hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to HSLS Dashboard
        </Link>

        <Button onClick={downloadPDF} className="bg-primary hover:bg-primary/90">
          <Download className="w-4 h-4 mr-2" />
          Download PDF
        </Button>
      </div>

      <div ref={contentRef} className="dashboard-card p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-lg bg-success/10 flex items-center justify-center">
            <TestTube className="w-6 h-6 text-success" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-foreground">QA Test Cases</h2>
            <p className="text-muted-foreground">HSLS Safety Management System</p>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-4 mb-8">
          <div className="p-4 bg-muted/50 rounded-lg text-center">
            <p className="text-2xl font-bold text-foreground">{testCases.length}</p>
            <p className="text-sm text-muted-foreground">Total Cases</p>
          </div>
          <div className="p-4 bg-success/10 rounded-lg text-center">
            <p className="text-2xl font-bold text-success">{testCases.filter(t => t.status === 'Pass').length}</p>
            <p className="text-sm text-muted-foreground">Passed</p>
          </div>
          <div className="p-4 bg-warning/10 rounded-lg text-center">
            <p className="text-2xl font-bold text-warning">{testCases.filter(t => t.status === 'Pending').length}</p>
            <p className="text-sm text-muted-foreground">Pending</p>
          </div>
          <div className="p-4 bg-destructive/10 rounded-lg text-center">
            <p className="text-2xl font-bold text-destructive">{testCases.filter(t => t.status === 'Fail').length}</p>
            <p className="text-sm text-muted-foreground">Failed</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">ID</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Module</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Test Case</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Priority</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Status</th>
              </tr>
            </thead>
            <tbody>
              {testCases.map((tc) => (
                <tr key={tc.id} className="border-b border-border/50 hover:bg-muted/30">
                  <td className="py-3 px-4 text-sm font-mono text-foreground">{tc.id}</td>
                  <td className="py-3 px-4 text-sm text-foreground">{tc.module}</td>
                  <td className="py-3 px-4 text-sm text-foreground">{tc.title}</td>
                  <td className="py-3 px-4">{getPriorityBadge(tc.priority)}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(tc.status)}
                      {getStatusBadge(tc.status)}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default QATestCases;