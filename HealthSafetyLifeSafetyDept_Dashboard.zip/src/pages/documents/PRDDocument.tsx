import { useRef } from 'react';
import { Download, ArrowLeft, FileText } from 'lucide-react';
import { Link } from 'react-router-dom';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import jsPDF from 'jspdf';

const PRDDocument = () => {
  const contentRef = useRef<HTMLDivElement>(null);

  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'HSLS', path: '/dashboards/department/hsls' },
    { label: 'PRD Document' },
  ];

  const downloadPDF = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    let yPos = 20;

    // Title
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text('Product Requirements Document (PRD)', pageWidth / 2, yPos, { align: 'center' });
    yPos += 10;

    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text('HSLS Safety Management System', pageWidth / 2, yPos, { align: 'center' });
    yPos += 15;

    // Document Info
    doc.setFontSize(10);
    doc.text(`Version: 1.0`, 20, yPos);
    yPos += 6;
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 20, yPos);
    yPos += 6;
    doc.text('Status: Approved', 20, yPos);
    yPos += 15;

    // Section 1
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('1. Executive Summary', 20, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    const summary = 'The HSLS Safety Management System is a comprehensive platform designed to streamline health, safety, and laboratory security operations. This system enables real-time risk monitoring, audit management, compliance tracking, and incident reporting across all facilities.';
    const summaryLines = doc.splitTextToSize(summary, pageWidth - 40);
    doc.text(summaryLines, 20, yPos);
    yPos += summaryLines.length * 5 + 10;

    // Section 2
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('2. Product Overview', 20, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    const overview = 'The system provides a centralized dashboard for safety officers, department heads, and compliance teams to monitor and manage safety-related activities. Key modules include Risk Management, Audit Management, Enforcement Management, Compliance Tracking, and Feedback Management.';
    const overviewLines = doc.splitTextToSize(overview, pageWidth - 40);
    doc.text(overviewLines, 20, yPos);
    yPos += overviewLines.length * 5 + 10;

    // Section 3
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('3. Key Features', 20, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    const features = [
      '• Real-time risk monitoring with severity classification',
      '• Automated audit scheduling and tracking',
      '• Compliance status dashboard with trend analysis',
      '• Incident reporting and escalation workflows',
      '• Role-based access control (Admin, Department Head, Staff)',
      '• Customizable reporting and analytics',
      '• Mobile-responsive interface',
    ];
    features.forEach((feature) => {
      doc.text(feature, 25, yPos);
      yPos += 6;
    });
    yPos += 10;

    // Section 4
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('4. User Roles', 20, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    const roles = [
      '• Admin/Compliance Head: Full system access, policy management, reporting',
      '• Department Head: Department-level oversight, approvals, team management',
      '• Staff: Task execution, incident reporting, compliance activities',
    ];
    roles.forEach((role) => {
      const roleLines = doc.splitTextToSize(role, pageWidth - 45);
      doc.text(roleLines, 25, yPos);
      yPos += roleLines.length * 5 + 2;
    });
    yPos += 10;

    // Section 5
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('5. Success Metrics', 20, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    const metrics = [
      '• 95% compliance rate across all facilities',
      '• 50% reduction in incident response time',
      '• 100% audit completion within scheduled timeframes',
      '• 90% user satisfaction score',
    ];
    metrics.forEach((metric) => {
      doc.text(metric, 25, yPos);
      yPos += 6;
    });

    doc.save('HSLS_PRD_Document.pdf');
  };

  return (
    <DashboardLayout
      title="PRD Document"
      subtitle="Product Requirements Document"
      breadcrumbs={breadcrumbs}
    >
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/dashboards/department/hsls"
          className="flex items-center gap-2 text-sm text-primary hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to HSLS Dashboard
        </Link>

        <Button onClick={downloadPDF} className="bg-primary hover:bg-primary/90">
          <Download className="w-4 h-4 mr-2" />
          Download PDF
        </Button>
      </div>

      <div ref={contentRef} className="dashboard-card p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
            <FileText className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-foreground">Product Requirements Document (PRD)</h2>
            <p className="text-muted-foreground">HSLS Safety Management System</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-8 p-4 bg-muted/50 rounded-lg">
          <div>
            <p className="text-xs text-muted-foreground uppercase">Version</p>
            <p className="font-semibold">1.0</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase">Date</p>
            <p className="font-semibold">{new Date().toLocaleDateString()}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase">Status</p>
            <p className="font-semibold text-success">Approved</p>
          </div>
        </div>

        <div className="space-y-8">
          <section>
            <h3 className="text-lg font-semibold text-foreground mb-3">1. Executive Summary</h3>
            <p className="text-muted-foreground leading-relaxed">
              The HSLS Safety Management System is a comprehensive platform designed to streamline health, safety, and laboratory security operations. This system enables real-time risk monitoring, audit management, compliance tracking, and incident reporting across all facilities.
            </p>
          </section>

          <section>
            <h3 className="text-lg font-semibold text-foreground mb-3">2. Product Overview</h3>
            <p className="text-muted-foreground leading-relaxed">
              The system provides a centralized dashboard for safety officers, department heads, and compliance teams to monitor and manage safety-related activities. Key modules include Risk Management, Audit Management, Enforcement Management, Compliance Tracking, and Feedback Management.
            </p>
          </section>

          <section>
            <h3 className="text-lg font-semibold text-foreground mb-3">3. Key Features</h3>
            <ul className="list-disc list-inside text-muted-foreground space-y-2">
              <li>Real-time risk monitoring with severity classification</li>
              <li>Automated audit scheduling and tracking</li>
              <li>Compliance status dashboard with trend analysis</li>
              <li>Incident reporting and escalation workflows</li>
              <li>Role-based access control (Admin, Department Head, Staff)</li>
              <li>Customizable reporting and analytics</li>
              <li>Mobile-responsive interface</li>
            </ul>
          </section>

          <section>
            <h3 className="text-lg font-semibold text-foreground mb-3">4. User Roles</h3>
            <div className="space-y-3">
              <div className="p-3 bg-primary/5 rounded-lg">
                <p className="font-medium text-foreground">Admin/Compliance Head</p>
                <p className="text-sm text-muted-foreground">Full system access, policy management, reporting</p>
              </div>
              <div className="p-3 bg-secondary/50 rounded-lg">
                <p className="font-medium text-foreground">Department Head</p>
                <p className="text-sm text-muted-foreground">Department-level oversight, approvals, team management</p>
              </div>
              <div className="p-3 bg-muted rounded-lg">
                <p className="font-medium text-foreground">Staff</p>
                <p className="text-sm text-muted-foreground">Task execution, incident reporting, compliance activities</p>
              </div>
            </div>
          </section>

          <section>
            <h3 className="text-lg font-semibold text-foreground mb-3">5. Success Metrics</h3>
            <ul className="list-disc list-inside text-muted-foreground space-y-2">
              <li>95% compliance rate across all facilities</li>
              <li>50% reduction in incident response time</li>
              <li>100% audit completion within scheduled timeframes</li>
              <li>90% user satisfaction score</li>
            </ul>
          </section>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default PRDDocument;