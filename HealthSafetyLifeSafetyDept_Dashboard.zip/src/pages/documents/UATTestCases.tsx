import { useRef } from 'react';
import { Download, ArrowLeft, Users, CheckCircle, XCircle, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import jsPDF from 'jspdf';

const uatTestCases = [
  { id: 'UAT-001', scenario: 'User Login', description: 'Verify user can login with valid credentials', acceptanceCriteria: 'User is redirected to dashboard after successful login', status: 'Pass', tester: 'John Doe' },
  { id: 'UAT-002', scenario: 'Dashboard Overview', description: 'Verify dashboard displays all KPIs correctly', acceptanceCriteria: 'All KPI tiles show accurate real-time data', status: 'Pass', tester: 'Jane Smith' },
  { id: 'UAT-003', scenario: 'Risk Creation', description: 'Verify user can create a new risk entry', acceptanceCriteria: 'Risk is saved and appears in the risk list', status: 'Pass', tester: 'John Doe' },
  { id: 'UAT-004', scenario: 'Risk Filtering', description: 'Verify user can filter risks by severity', acceptanceCriteria: 'Only risks matching the filter are displayed', status: 'Pass', tester: 'Jane Smith' },
  { id: 'UAT-005', scenario: 'Audit Scheduling', description: 'Verify user can schedule a new audit', acceptanceCriteria: 'Audit appears in calendar and list view', status: 'Pending', tester: 'Mike Johnson' },
  { id: 'UAT-006', scenario: 'Compliance Report', description: 'Verify compliance report generation', acceptanceCriteria: 'Report is generated with accurate data', status: 'Pass', tester: 'John Doe' },
  { id: 'UAT-007', scenario: 'Role Switching', description: 'Verify user can switch between roles', acceptanceCriteria: 'UI updates to reflect selected role', status: 'Pass', tester: 'Jane Smith' },
  { id: 'UAT-008', scenario: 'Feedback Submission', description: 'Verify user can submit feedback', acceptanceCriteria: 'Feedback is saved and confirmation shown', status: 'Pass', tester: 'Mike Johnson' },
  { id: 'UAT-009', scenario: 'Mobile Navigation', description: 'Verify navigation works on mobile devices', acceptanceCriteria: 'All menu items are accessible on mobile', status: 'Pass', tester: 'John Doe' },
  { id: 'UAT-010', scenario: 'PDF Download', description: 'Verify documents can be downloaded as PDF', acceptanceCriteria: 'PDF is downloaded with correct content', status: 'Pass', tester: 'Jane Smith' },
  { id: 'UAT-011', scenario: 'Data Export', description: 'Verify user can export data to CSV', acceptanceCriteria: 'CSV file contains all visible data', status: 'Pending', tester: 'Mike Johnson' },
  { id: 'UAT-012', scenario: 'Notification Display', description: 'Verify notifications are displayed correctly', acceptanceCriteria: 'Notification badge shows unread count', status: 'Pass', tester: 'John Doe' },
];

const UATTestCases = () => {
  const contentRef = useRef<HTMLDivElement>(null);

  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'HSLS', path: '/dashboards/department/hsls' },
    { label: 'UAT Test Cases' },
  ];

  const downloadPDF = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    let yPos = 20;

    // Title
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text('UAT Test Cases Document', pageWidth / 2, yPos, { align: 'center' });
    yPos += 10;

    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text('HSLS Safety Management System', pageWidth / 2, yPos, { align: 'center' });
    yPos += 15;

    // Document Info
    doc.setFontSize(10);
    doc.text(`Version: 1.0`, 20, yPos);
    yPos += 6;
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 20, yPos);
    yPos += 6;
    doc.text(`Total Test Scenarios: ${uatTestCases.length}`, 20, yPos);
    yPos += 6;
    doc.text(`Pass: ${uatTestCases.filter(t => t.status === 'Pass').length} | Pending: ${uatTestCases.filter(t => t.status === 'Pending').length}`, 20, yPos);
    yPos += 15;

    // Test Cases
    uatTestCases.forEach((tc, index) => {
      if (yPos > 250) {
        doc.addPage();
        yPos = 20;
      }

      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text(`${tc.id}: ${tc.scenario}`, 20, yPos);
      yPos += 7;

      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      
      doc.text('Description:', 20, yPos);
      const descLines = doc.splitTextToSize(tc.description, pageWidth - 60);
      doc.text(descLines, 55, yPos);
      yPos += descLines.length * 5 + 3;

      doc.text('Acceptance:', 20, yPos);
      const accLines = doc.splitTextToSize(tc.acceptanceCriteria, pageWidth - 60);
      doc.text(accLines, 55, yPos);
      yPos += accLines.length * 5 + 3;

      doc.text(`Status: ${tc.status}`, 20, yPos);
      doc.text(`Tester: ${tc.tester}`, 80, yPos);
      yPos += 12;
    });

    doc.save('HSLS_UAT_Test_Cases.pdf');
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Pass':
        return <CheckCircle className="w-4 h-4 text-success" />;
      case 'Fail':
        return <XCircle className="w-4 h-4 text-destructive" />;
      default:
        return <Clock className="w-4 h-4 text-warning" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Pass':
        return <Badge className="bg-success/10 text-success border-success/20">Pass</Badge>;
      case 'Fail':
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">Fail</Badge>;
      default:
        return <Badge className="bg-warning/10 text-warning border-warning/20">Pending</Badge>;
    }
  };

  return (
    <DashboardLayout
      title="UAT Test Cases"
      subtitle="User Acceptance Testing"
      breadcrumbs={breadcrumbs}
    >
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/dashboards/department/hsls"
          className="flex items-center gap-2 text-sm text-primary hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to HSLS Dashboard
        </Link>

        <Button onClick={downloadPDF} className="bg-primary hover:bg-primary/90">
          <Download className="w-4 h-4 mr-2" />
          Download PDF
        </Button>
      </div>

      <div ref={contentRef} className="dashboard-card p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
            <Users className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-foreground">UAT Test Cases</h2>
            <p className="text-muted-foreground">User Acceptance Testing - HSLS Safety Management System</p>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-4 mb-8">
          <div className="p-4 bg-muted/50 rounded-lg text-center">
            <p className="text-2xl font-bold text-foreground">{uatTestCases.length}</p>
            <p className="text-sm text-muted-foreground">Total Scenarios</p>
          </div>
          <div className="p-4 bg-success/10 rounded-lg text-center">
            <p className="text-2xl font-bold text-success">{uatTestCases.filter(t => t.status === 'Pass').length}</p>
            <p className="text-sm text-muted-foreground">Passed</p>
          </div>
          <div className="p-4 bg-warning/10 rounded-lg text-center">
            <p className="text-2xl font-bold text-warning">{uatTestCases.filter(t => t.status === 'Pending').length}</p>
            <p className="text-sm text-muted-foreground">Pending</p>
          </div>
          <div className="p-4 bg-destructive/10 rounded-lg text-center">
            <p className="text-2xl font-bold text-destructive">{uatTestCases.filter(t => t.status === 'Fail').length}</p>
            <p className="text-sm text-muted-foreground">Failed</p>
          </div>
        </div>

        <div className="space-y-4">
          {uatTestCases.map((tc) => (
            <div key={tc.id} className="p-4 border border-border rounded-lg hover:bg-muted/30 transition-colors">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-sm text-primary font-medium">{tc.id}</span>
                  <h4 className="font-semibold text-foreground">{tc.scenario}</h4>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusIcon(tc.status)}
                  {getStatusBadge(tc.status)}
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground mb-1">Description</p>
                  <p className="text-foreground">{tc.description}</p>
                </div>
                <div>
                  <p className="text-muted-foreground mb-1">Acceptance Criteria</p>
                  <p className="text-foreground">{tc.acceptanceCriteria}</p>
                </div>
              </div>
              
              <div className="mt-3 pt-3 border-t border-border/50">
                <span className="text-xs text-muted-foreground">Tested by: </span>
                <span className="text-xs font-medium text-foreground">{tc.tester}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
};

export default UATTestCases;