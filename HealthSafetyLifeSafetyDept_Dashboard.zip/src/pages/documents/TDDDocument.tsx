import { useRef } from 'react';
import { Download, ArrowLeft, Code } from 'lucide-react';
import { Link } from 'react-router-dom';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import jsPDF from 'jspdf';

const TDDDocument = () => {
  const contentRef = useRef<HTMLDivElement>(null);

  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'HSLS', path: '/dashboards/department/hsls' },
    { label: 'TDD Document' },
  ];

  const downloadPDF = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    let yPos = 20;

    // Title
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text('Technical Design Document (TDD)', pageWidth / 2, yPos, { align: 'center' });
    yPos += 10;

    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text('HSLS Safety Management System', pageWidth / 2, yPos, { align: 'center' });
    yPos += 15;

    // Document Info
    doc.setFontSize(10);
    doc.text(`Version: 1.0`, 20, yPos);
    yPos += 6;
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 20, yPos);
    yPos += 6;
    doc.text('Status: Approved', 20, yPos);
    yPos += 15;

    // Section 1
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('1. System Architecture', 20, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    const arch = 'The HSLS Safety Management System is built using a modern React-based architecture with TypeScript for type safety. The frontend utilizes Vite as the build tool, Tailwind CSS for styling, and shadcn/ui for component library.';
    const archLines = doc.splitTextToSize(arch, pageWidth - 40);
    doc.text(archLines, 20, yPos);
    yPos += archLines.length * 5 + 10;

    // Section 2
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('2. Technology Stack', 20, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    const stack = [
      '• Frontend: React 18, TypeScript, Vite',
      '• Styling: Tailwind CSS, shadcn/ui components',
      '• State Management: React Context, TanStack Query',
      '• Routing: React Router DOM v6',
      '• Charts: Recharts',
      '• Form Handling: React Hook Form, Zod validation',
      '• PDF Generation: jsPDF',
    ];
    stack.forEach((item) => {
      doc.text(item, 25, yPos);
      yPos += 6;
    });
    yPos += 10;

    // Section 3
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('3. Component Architecture', 20, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    const components = 'The application follows a modular component architecture with reusable UI components, layout components, and page-specific components. Key patterns include compound components, render props, and custom hooks for shared logic.';
    const compLines = doc.splitTextToSize(components, pageWidth - 40);
    doc.text(compLines, 20, yPos);
    yPos += compLines.length * 5 + 10;

    // Section 4
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('4. Data Flow', 20, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    const dataFlow = [
      '• Role Context: Manages user role state globally',
      '• Mock Data: Simulated data for development',
      '• TanStack Query: Server state management',
      '• Local State: Component-level state with useState',
    ];
    dataFlow.forEach((item) => {
      doc.text(item, 25, yPos);
      yPos += 6;
    });
    yPos += 10;

    // Section 5
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('5. Security Considerations', 20, yPos);
    yPos += 8;

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    const security = [
      '• Role-based access control (RBAC)',
      '• Input validation and sanitization',
      '• Secure authentication flow (future)',
      '• HTTPS enforcement in production',
    ];
    security.forEach((item) => {
      doc.text(item, 25, yPos);
      yPos += 6;
    });

    doc.save('HSLS_TDD_Document.pdf');
  };

  return (
    <DashboardLayout
      title="TDD Document"
      subtitle="Technical Design Document"
      breadcrumbs={breadcrumbs}
    >
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/dashboards/department/hsls"
          className="flex items-center gap-2 text-sm text-primary hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to HSLS Dashboard
        </Link>

        <Button onClick={downloadPDF} className="bg-primary hover:bg-primary/90">
          <Download className="w-4 h-4 mr-2" />
          Download PDF
        </Button>
      </div>

      <div ref={contentRef} className="dashboard-card p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-lg bg-info/10 flex items-center justify-center">
            <Code className="w-6 h-6 text-info" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-foreground">Technical Design Document (TDD)</h2>
            <p className="text-muted-foreground">HSLS Safety Management System</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-8 p-4 bg-muted/50 rounded-lg">
          <div>
            <p className="text-xs text-muted-foreground uppercase">Version</p>
            <p className="font-semibold">1.0</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase">Date</p>
            <p className="font-semibold">{new Date().toLocaleDateString()}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase">Status</p>
            <p className="font-semibold text-success">Approved</p>
          </div>
        </div>

        <div className="space-y-8">
          <section>
            <h3 className="text-lg font-semibold text-foreground mb-3">1. System Architecture</h3>
            <p className="text-muted-foreground leading-relaxed">
              The HSLS Safety Management System is built using a modern React-based architecture with TypeScript for type safety. The frontend utilizes Vite as the build tool, Tailwind CSS for styling, and shadcn/ui for component library.
            </p>
          </section>

          <section>
            <h3 className="text-lg font-semibold text-foreground mb-3">2. Technology Stack</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="font-medium text-foreground mb-2">Frontend</p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• React 18</li>
                  <li>• TypeScript</li>
                  <li>• Vite</li>
                </ul>
              </div>
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="font-medium text-foreground mb-2">Styling</p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Tailwind CSS</li>
                  <li>• shadcn/ui</li>
                  <li>• CSS Variables</li>
                </ul>
              </div>
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="font-medium text-foreground mb-2">State Management</p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• React Context</li>
                  <li>• TanStack Query</li>
                  <li>• Local State</li>
                </ul>
              </div>
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="font-medium text-foreground mb-2">Utilities</p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• React Router v6</li>
                  <li>• Recharts</li>
                  <li>• jsPDF</li>
                </ul>
              </div>
            </div>
          </section>

          <section>
            <h3 className="text-lg font-semibold text-foreground mb-3">3. Component Architecture</h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              The application follows a modular component architecture with reusable UI components, layout components, and page-specific components.
            </p>
            <div className="p-4 bg-muted/30 rounded-lg font-mono text-sm">
              <pre className="text-muted-foreground">{`src/
├── components/
│   ├── ui/          # Reusable UI components
│   ├── layout/      # Layout components
│   ├── dashboard/   # Dashboard widgets
│   └── shared/      # Shared components
├── pages/           # Page components
├── contexts/        # React contexts
├── hooks/           # Custom hooks
└── lib/             # Utilities`}</pre>
            </div>
          </section>

          <section>
            <h3 className="text-lg font-semibold text-foreground mb-3">4. Data Flow</h3>
            <ul className="list-disc list-inside text-muted-foreground space-y-2">
              <li>Role Context: Manages user role state globally</li>
              <li>Mock Data: Simulated data for development</li>
              <li>TanStack Query: Server state management</li>
              <li>Local State: Component-level state with useState</li>
            </ul>
          </section>

          <section>
            <h3 className="text-lg font-semibold text-foreground mb-3">5. Security Considerations</h3>
            <ul className="list-disc list-inside text-muted-foreground space-y-2">
              <li>Role-based access control (RBAC)</li>
              <li>Input validation and sanitization</li>
              <li>Secure authentication flow (future)</li>
              <li>HTTPS enforcement in production</li>
            </ul>
          </section>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default TDDDocument;