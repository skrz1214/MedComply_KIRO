import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Download, FileText, Bot, Target, Shield, Users } from 'lucide-react';
import DashboardLayout from '@/components/layout/DashboardLayout';
import jsPDF from 'jspdf';

const SystemPromptDocument = () => {
  const downloadPDF = () => {
    const doc = new jsPDF();
    let yPos = 20;
    const lineHeight = 7;
    const pageHeight = 280;
    const margin = 20;
    const maxWidth = 170;

    const addText = (text: string, fontSize: number = 12, isBold: boolean = false) => {
      doc.setFontSize(fontSize);
      doc.setFont('helvetica', isBold ? 'bold' : 'normal');
      const lines = doc.splitTextToSize(text, maxWidth);
      lines.forEach((line: string) => {
        if (yPos > pageHeight) {
          doc.addPage();
          yPos = 20;
        }
        doc.text(line, margin, yPos);
        yPos += lineHeight;
      });
    };

    const addSection = (title: string, content: string[]) => {
      if (yPos > pageHeight - 30) {
        doc.addPage();
        yPos = 20;
      }
      yPos += 5;
      addText(title, 14, true);
      yPos += 3;
      content.forEach((item) => {
        addText(`• ${item}`, 11);
      });
    };

    // Title
    doc.setFontSize(24);
    doc.setFont('helvetica', 'bold');
    doc.text('HSLS SafetyHub', margin, yPos);
    yPos += 10;
    doc.setFontSize(18);
    doc.text('System Prompt Document', margin, yPos);
    yPos += 15;

    // Document Info
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Version: 1.0.0`, margin, yPos);
    yPos += 5;
    doc.text(`Date: ${new Date().toLocaleDateString()}`, margin, yPos);
    yPos += 5;
    doc.text('Classification: Internal Use Only', margin, yPos);
    yPos += 15;

    // System Overview
    addText('1. SYSTEM OVERVIEW', 16, true);
    yPos += 5;
    addText('The HSLS SafetyHub is an integrated Health, Safety, Licensing, and Security management platform designed to streamline regulatory compliance, risk management, and operational safety across organizational departments.');
    yPos += 10;

    // Core Identity
    addSection('2. CORE IDENTITY & PURPOSE', [
      'Primary Function: Centralized safety and compliance management dashboard',
      'Target Users: Admin, Department Heads, Staff members',
      'Domain Focus: Health, Safety, Licensing, Security (HSLS)',
      'Operational Scope: Multi-facility, multi-department oversight'
    ]);

    // Functional Capabilities
    addSection('3. FUNCTIONAL CAPABILITIES', [
      'Risk Management: Track, assess, and mitigate organizational risks',
      'Audit Management: Schedule, conduct, and report on compliance audits',
      'Enforcement Management: Handle violations, corrective actions, penalties',
      'Compliance Tracking: Monitor regulatory requirements and deadlines',
      'Feedback Management: Collect and process safety-related feedback',
      'Document Management: Maintain PRD, TDD, QA, UAT documentation'
    ]);

    // User Roles
    addSection('4. USER ROLES & PERMISSIONS', [
      'Admin: Full system access, configuration, user management',
      'Department Head: Department-level oversight, approvals, reporting',
      'Staff: Task execution, data entry, limited read access'
    ]);

    // Data Domains
    addSection('5. DATA DOMAINS', [
      'Health: Occupational health, wellness programs, medical compliance',
      'Safety: Incident tracking, hazard identification, safety protocols',
      'Licensing: Permit management, certification tracking, renewals',
      'Security: Access control, threat assessment, security protocols'
    ]);

    // Key Metrics
    addSection('6. KEY PERFORMANCE INDICATORS', [
      'Total Active Risks: Real-time risk count across all domains',
      'Audit Completion Rate: Percentage of scheduled audits completed',
      'Compliance Score: Overall regulatory compliance percentage',
      'Open Violations: Count of unresolved enforcement actions',
      'Resolution Time: Average time to close items',
      'Feedback Response Rate: Percentage of feedback addressed'
    ]);

    // Behavioral Guidelines
    doc.addPage();
    yPos = 20;
    addSection('7. BEHAVIORAL GUIDELINES', [
      'Prioritize safety-critical information visibility',
      'Maintain audit trail for all actions',
      'Enforce role-based access control strictly',
      'Provide clear, actionable insights',
      'Support data-driven decision making',
      'Ensure regulatory compliance at all times'
    ]);

    // Integration Points
    addSection('8. INTEGRATION POINTS', [
      'External regulatory databases for compliance updates',
      'Incident reporting systems for real-time alerts',
      'Document management for policy distribution',
      'Notification services for deadline reminders',
      'Analytics engines for trend analysis'
    ]);

    // Response Protocols
    addSection('9. RESPONSE PROTOCOLS', [
      'Critical Risk Alert: Immediate notification to Admin and Department Head',
      'Audit Finding: Generate corrective action within 24 hours',
      'Compliance Deadline: 30-day advance warning notifications',
      'Violation Detected: Initiate enforcement workflow automatically',
      'Feedback Received: Acknowledge within 2 business days'
    ]);

    // Security Requirements
    addSection('10. SECURITY REQUIREMENTS', [
      'All data transmission encrypted (TLS 1.3)',
      'Session timeout after 30 minutes of inactivity',
      'Multi-factor authentication for Admin accounts',
      'Audit logging for all data modifications',
      'Regular backup schedule (daily incremental, weekly full)',
      'Role-based access control enforcement'
    ]);

    // Constraints
    addSection('11. OPERATIONAL CONSTRAINTS', [
      'System availability target: 99.9% uptime',
      'Maximum response time: 3 seconds for dashboard loads',
      'Data retention: 7 years for compliance records',
      'Concurrent users supported: 500+',
      'Mobile responsive design required'
    ]);

    // Footer
    doc.setFontSize(10);
    doc.setFont('helvetica', 'italic');
    const pageCount = doc.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.text(`HSLS SafetyHub - System Prompt Document - Page ${i} of ${pageCount}`, margin, 290);
    }

    doc.save('HSLS_System_Prompt.pdf');
  };

  return (
    <DashboardLayout
      title="System Prompt Document"
      subtitle="AI System Configuration & Behavioral Guidelines"
      breadcrumbs={[
        { label: 'HSLS', path: '/dashboards/department/hsls' },
        { label: 'Documents', path: '/dashboards/department/hsls/docs' },
        { label: 'System Prompt' },
      ]}
    >
      <div className="space-y-6">
        {/* Header Actions */}
        <div className="flex justify-end">
          <Button onClick={downloadPDF} className="gap-2">
            <Download className="w-4 h-4" />
            Download PDF
          </Button>
        </div>

        {/* Document Content */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Bot className="w-6 h-6 text-primary" />
              </div>
              <div>
                <CardTitle>HSLS SafetyHub - System Prompt</CardTitle>
                <p className="text-sm text-muted-foreground">Version 1.0.0 | Last Updated: {new Date().toLocaleDateString()}</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-8">
            {/* System Overview */}
            <section>
              <h2 className="text-xl font-semibold mb-3 flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                1. System Overview
              </h2>
              <p className="text-muted-foreground leading-relaxed">
                The HSLS SafetyHub is an integrated Health, Safety, Licensing, and Security management platform 
                designed to streamline regulatory compliance, risk management, and operational safety across 
                organizational departments. The system provides real-time visibility into safety metrics, 
                automates compliance workflows, and enables data-driven decision making for safety professionals.
              </p>
            </section>

            {/* Core Identity */}
            <section>
              <h2 className="text-xl font-semibold mb-3 flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                2. Core Identity & Purpose
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-muted/50 rounded-lg">
                  <h4 className="font-medium mb-2">Primary Function</h4>
                  <p className="text-sm text-muted-foreground">Centralized safety and compliance management dashboard</p>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <h4 className="font-medium mb-2">Target Users</h4>
                  <p className="text-sm text-muted-foreground">Admin, Department Heads, Staff members</p>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <h4 className="font-medium mb-2">Domain Focus</h4>
                  <p className="text-sm text-muted-foreground">Health, Safety, Licensing, Security (HSLS)</p>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <h4 className="font-medium mb-2">Operational Scope</h4>
                  <p className="text-sm text-muted-foreground">Multi-facility, multi-department oversight</p>
                </div>
              </div>
            </section>

            {/* User Roles */}
            <section>
              <h2 className="text-xl font-semibold mb-3 flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                3. User Roles & Permissions
              </h2>
              <div className="space-y-3">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium text-primary">Admin</h4>
                  <p className="text-sm text-muted-foreground">Full system access, configuration, user management, audit oversight</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium text-primary">Department Head</h4>
                  <p className="text-sm text-muted-foreground">Department-level oversight, approvals, reporting, team management</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium text-primary">Staff</h4>
                  <p className="text-sm text-muted-foreground">Task execution, data entry, limited read access, feedback submission</p>
                </div>
              </div>
            </section>

            {/* Functional Capabilities */}
            <section>
              <h2 className="text-xl font-semibold mb-3 flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                4. Functional Capabilities
              </h2>
              <div className="grid md:grid-cols-2 gap-3">
                {[
                  { title: 'Risk Management', desc: 'Track, assess, and mitigate organizational risks' },
                  { title: 'Audit Management', desc: 'Schedule, conduct, and report on compliance audits' },
                  { title: 'Enforcement Management', desc: 'Handle violations, corrective actions, penalties' },
                  { title: 'Compliance Tracking', desc: 'Monitor regulatory requirements and deadlines' },
                  { title: 'Feedback Management', desc: 'Collect and process safety-related feedback' },
                  { title: 'Document Management', desc: 'Maintain PRD, TDD, QA, UAT documentation' },
                ].map((item, index) => (
                  <div key={index} className="p-3 bg-muted/30 rounded-lg">
                    <h4 className="font-medium text-sm">{item.title}</h4>
                    <p className="text-xs text-muted-foreground">{item.desc}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* Response Protocols */}
            <section>
              <h2 className="text-xl font-semibold mb-3">5. Response Protocols</h2>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-destructive rounded-full mt-1.5 flex-shrink-0" />
                  <span><strong>Critical Risk Alert:</strong> Immediate notification to Admin and Department Head</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-warning rounded-full mt-1.5 flex-shrink-0" />
                  <span><strong>Audit Finding:</strong> Generate corrective action within 24 hours</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-primary rounded-full mt-1.5 flex-shrink-0" />
                  <span><strong>Compliance Deadline:</strong> 30-day advance warning notifications</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-destructive rounded-full mt-1.5 flex-shrink-0" />
                  <span><strong>Violation Detected:</strong> Initiate enforcement workflow automatically</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-muted-foreground rounded-full mt-1.5 flex-shrink-0" />
                  <span><strong>Feedback Received:</strong> Acknowledge within 2 business days</span>
                </li>
              </ul>
            </section>

            {/* Security Requirements */}
            <section>
              <h2 className="text-xl font-semibold mb-3">6. Security Requirements</h2>
              <div className="grid md:grid-cols-3 gap-3">
                {[
                  'TLS 1.3 encryption',
                  '30-min session timeout',
                  'MFA for Admin accounts',
                  'Full audit logging',
                  'Daily backups',
                  'RBAC enforcement',
                ].map((item, index) => (
                  <div key={index} className="p-3 bg-muted/30 rounded-lg text-center">
                    <p className="text-sm font-medium">{item}</p>
                  </div>
                ))}
              </div>
            </section>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default SystemPromptDocument;
