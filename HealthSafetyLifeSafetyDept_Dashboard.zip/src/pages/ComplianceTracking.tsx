import { useState } from 'react';
import { Plus, Download, ArrowLeft, FileText, AlertTriangle, Shield, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import DashboardLayout from '@/components/layout/DashboardLayout';
import MetricTiles from '@/components/shared/MetricTiles';
import DomainTabs from '@/components/shared/DomainTabs';
import DataTable, { Column } from '@/components/shared/DataTable';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { mockComplianceItems, mockPolicies } from '@/data/mockData';

const complianceTabs = [
  { id: 'all', label: 'All HSLS', count: mockComplianceItems.length },
  { id: 'safety-code', label: 'Safety Code Issues', count: 1 },
  { id: 'employee-violations', label: 'Employee Violations', count: 1 },
  { id: 'poc', label: 'Plan of Correction (POC)', count: 1 },
  { id: 'survey-readiness', label: 'Survey/Inspection Readiness', count: 0 },
  { id: 'workplace-safety', label: 'Workplace Safety', count: 0 },
  { id: 'environment-care', label: 'Environment of Care', count: 0 },
  { id: 'emergency-prep', label: 'Emergency Preparedness', count: 0 },
];

const capaTabs = [
  { id: 'all', label: 'All HSLS', count: 2 },
  { id: 'safety-code', label: 'Safety Code Issues', count: 1 },
  { id: 'poc', label: 'Plan of Correction (POC)', count: 1 },
  { id: 'employee-violations', label: 'Employee Violations', count: 0 },
  { id: 'emergency-prep', label: 'Emergency Preparedness', count: 0 },
];

const citationTabs = [
  { id: 'all', label: 'All HSLS', count: 1 },
  { id: 'life-safety', label: 'Life Safety Code', count: 1 },
  { id: 'safety-code', label: 'Safety Code Issues', count: 0 },
  { id: 'survey-findings', label: 'Survey Findings', count: 0 },
];

const complianceColumns: Column<typeof mockComplianceItems[0]>[] = [
  { key: 'id', header: 'Compliance ID' },
  { key: 'description', header: 'Description', className: 'max-w-md' },
  { key: 'status', header: 'Status' },
  { key: 'owner', header: 'Owner' },
  { key: 'dueDate', header: 'Due Date' },
  { key: 'hslsDomains', header: 'HSLS Domains' },
];

const mockCapaItems = [
  {
    id: 'CAPA-001',
    title: 'Fire Safety Exit Signage Correction',
    status: 'in_progress',
    owner: 'Facilities Manager',
    dueDate: '2024-12-30',
    linkedCompliance: 'COMP-001',
  },
  {
    id: 'CAPA-002',
    title: 'PPE Compliance Training Program',
    status: 'pending_review',
    owner: 'HR Director',
    dueDate: '2025-01-15',
    linkedCompliance: 'COMP-002',
  },
];

const mockCitations = [
  {
    id: 'CIT-001',
    authority: 'State Survey/DOH',
    status: 'open',
    dueDate: '2025-01-10',
    pocStatus: 'in_progress',
    owner: 'Compliance Officer',
  },
];

const mockSurveyHistory = [
  {
    id: 'SURV-001',
    date: '2024-11-15',
    authority: 'State Survey/DOH',
    scope: 'Annual Recertification',
    outcomes: '2 citations, 1 IJ',
    linkedCitations: ['CIT-001'],
  },
  {
    id: 'SURV-002',
    date: '2024-06-20',
    authority: 'Fire Marshal/AHJ',
    scope: 'Life Safety Code Inspection',
    outcomes: 'No deficiencies',
    linkedCitations: [],
  },
];

const ComplianceTracking = () => {
  const [mainTab, setMainTab] = useState('compliance');
  const [activeTab, setActiveTab] = useState('all');
  const [metricFilter, setMetricFilter] = useState<string | undefined>();

  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'Dashboards', path: '/dashboards' },
    { label: 'Department', path: '/dashboards/department' },
    { label: 'HSLS', path: '/dashboards/department/hsls' },
    { label: 'Compliance Tracking' },
  ];

  const metrics = {
    total: mockComplianceItems.length,
    pendingReview: mockComplianceItems.filter((c) => c.status === 'pending_review').length,
    completed: mockComplianceItems.filter((c) => c.status === 'completed').length,
    overdue: mockComplianceItems.filter((c) => c.status === 'overdue').length,
  };

  const getCurrentTabs = () => {
    switch (mainTab) {
      case 'capa': return capaTabs;
      case 'citations': return citationTabs;
      default: return complianceTabs;
    }
  };

  return (
    <DashboardLayout
      title="Compliance Tracking"
      subtitle="ComplianceConnect HSLS View"
      breadcrumbs={breadcrumbs}
    >
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/dashboards/department/hsls"
          className="flex items-center gap-2 text-sm text-primary hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to HSLS Dashboard
        </Link>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          <Button size="sm" className="bg-primary hover:bg-primary/90">
            <Plus className="w-4 h-4 mr-2" />
            Add Issue
          </Button>
        </div>
      </div>

      <Tabs value={mainTab} onValueChange={setMainTab} className="mb-6">
        <TabsList className="bg-muted">
          <TabsTrigger value="compliance" className="flex items-center gap-1">
            <Shield className="w-4 h-4" />
            Compliance Items
          </TabsTrigger>
          <TabsTrigger value="capa" className="flex items-center gap-1">
            <AlertTriangle className="w-4 h-4" />
            CAPA
          </TabsTrigger>
          <TabsTrigger value="citations" className="flex items-center gap-1">
            <FileText className="w-4 h-4" />
            Citations
          </TabsTrigger>
          <TabsTrigger value="survey" className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            Survey History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="compliance" className="mt-6">
          <MetricTiles
            {...metrics}
            activeFilter={metricFilter}
            onTileClick={setMetricFilter}
          />
          <DomainTabs
            tabs={complianceTabs}
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />
          <div className="dashboard-card">
            <DataTable
              columns={complianceColumns}
              data={mockComplianceItems}
              onRowClick={(item) => console.log('Navigate to:', `/complianceconnect/issues/${item.id}`)}
              actions={[
                { label: 'View Details', onClick: (item) => console.log('View', item.id) },
                { label: 'Edit', onClick: (item) => console.log('Edit', item.id) },
                { label: 'Link CAPA', onClick: (item) => console.log('Link CAPA', item.id) },
              ]}
            />
          </div>
        </TabsContent>

        <TabsContent value="capa" className="mt-6">
          <DomainTabs
            tabs={capaTabs}
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />
          <div className="dashboard-card">
            <DataTable
              columns={[
                { key: 'id', header: 'CAPA ID' },
                { key: 'title', header: 'Title', className: 'max-w-md' },
                { key: 'status', header: 'Status' },
                { key: 'owner', header: 'Owner' },
                { key: 'dueDate', header: 'Due Date' },
                { key: 'linkedCompliance', header: 'Linked Compliance' },
              ]}
              data={mockCapaItems}
              actions={[
                { label: 'View Details', onClick: (item) => console.log('View', item.id) },
                { label: 'Edit', onClick: (item) => console.log('Edit', item.id) },
              ]}
            />
          </div>
        </TabsContent>

        <TabsContent value="citations" className="mt-6">
          <DomainTabs
            tabs={citationTabs}
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />
          <div className="dashboard-card">
            <DataTable
              columns={[
                { key: 'id', header: 'Citation ID' },
                { key: 'authority', header: 'Authority' },
                { key: 'status', header: 'Status' },
                { key: 'dueDate', header: 'Due Date' },
                { key: 'pocStatus', header: 'POC Status' },
                { key: 'owner', header: 'Owner' },
              ]}
              data={mockCitations}
              actions={[
                { label: 'View Details', onClick: (item) => console.log('View', item.id) },
                { label: 'Submit POC', onClick: (item) => console.log('Submit POC', item.id) },
              ]}
            />
          </div>
        </TabsContent>

        <TabsContent value="survey" className="mt-6">
          <div className="dashboard-card p-6">
            <h3 className="font-semibold mb-4">Survey / Inspection Timeline</h3>
            <div className="space-y-4">
              {mockSurveyHistory.map((survey) => (
                <div
                  key={survey.id}
                  className="flex items-start gap-4 p-4 bg-muted/30 rounded-lg"
                >
                  <div className="w-3 h-3 mt-1.5 rounded-full bg-primary" />
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">{survey.scope}</h4>
                      <span className="text-sm text-muted-foreground">{survey.date}</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      Authority: {survey.authority}
                    </p>
                    <p className="text-sm mt-1">Outcomes: {survey.outcomes}</p>
                    {survey.linkedCitations.length > 0 && (
                      <div className="mt-2 flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">Linked:</span>
                        {survey.linkedCitations.map((cit) => (
                          <Button key={cit} variant="link" size="sm" className="h-auto p-0 text-xs">
                            {cit}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
            <Button variant="outline" className="mt-4">
              <Plus className="w-4 h-4 mr-2" />
              Upload Survey Documents
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  );
};

export default ComplianceTracking;
