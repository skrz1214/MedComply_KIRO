import { useState } from 'react';
import { Plus, Download, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import DashboardLayout from '@/components/layout/DashboardLayout';
import MetricTiles from '@/components/shared/MetricTiles';
import DomainTabs from '@/components/shared/DomainTabs';
import DataTable, { Column } from '@/components/shared/DataTable';
import { Button } from '@/components/ui/button';
import { mockRiskItems, mockPolicies } from '@/data/mockData';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const domainTabs = [
  { id: 'all', label: 'All HSLS', count: mockRiskItems.length },
  { id: 'life-safety', label: 'Life Safety / Fire Safety', count: 1 },
  { id: 'emergency-prep', label: 'Emergency Preparedness', count: 1 },
  { id: 'environment-care', label: 'Environment of Care', count: 0 },
  { id: 'hazmat', label: 'Hazardous Materials & Waste', count: 1 },
  { id: 'workplace-safety', label: 'Workplace Safety / OSHA', count: 0 },
  { id: 'equipment-safety', label: 'Equipment Safety / Maintenance', count: 1 },
  { id: 'survey-readiness', label: 'Survey/Inspection Readiness', count: 0 },
  { id: 'safety-code', label: 'Safety Code Issues', count: 0 },
];

const riskColumns: Column<typeof mockRiskItems[0]>[] = [
  { key: 'id', header: 'Risk ID' },
  { key: 'description', header: 'Description', className: 'max-w-md' },
  { key: 'riskLevel', header: 'Risk Level' },
  { key: 'status', header: 'Status' },
  { key: 'owner', header: 'Owner' },
  { key: 'dueDate', header: 'Due Date' },
  { key: 'hslsDomains', header: 'HSLS Domains' },
];

const policyColumns: Column<typeof mockPolicies[0]>[] = [
  { key: 'id', header: 'Policy ID' },
  { key: 'name', header: 'Name', className: 'max-w-md' },
  { key: 'category', header: 'Category' },
  { key: 'lastUpdate', header: 'Last Update' },
  { key: 'status', header: 'Status' },
  { key: 'nextReviewDate', header: 'Next Review' },
  { key: 'owner', header: 'Owner' },
];

const RiskManagement = () => {
  const [activeTab, setActiveTab] = useState('all');
  const [metricFilter, setMetricFilter] = useState<string | undefined>();
  const [mainTab, setMainTab] = useState('risks');

  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'Dashboards', path: '/dashboards' },
    { label: 'Department', path: '/dashboards/department' },
    { label: 'HSLS', path: '/dashboards/department/hsls' },
    { label: 'Risk Management' },
  ];

  const metrics = {
    total: mockRiskItems.length,
    pendingReview: mockRiskItems.filter((r) => r.status === 'pending_review').length,
    completed: mockRiskItems.filter((r) => r.status === 'completed').length,
    overdue: mockRiskItems.filter((r) => r.status === 'overdue').length,
  };

  return (
    <DashboardLayout
      title="Risk Management"
      subtitle="RiskGuard HSLS View"
      breadcrumbs={breadcrumbs}
    >
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/dashboards/department/hsls"
          className="flex items-center gap-2 text-sm text-primary hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to HSLS Dashboard
        </Link>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          <Button size="sm" className="bg-primary hover:bg-primary/90">
            <Plus className="w-4 h-4 mr-2" />
            Add Risk
          </Button>
        </div>
      </div>

      <Tabs value={mainTab} onValueChange={setMainTab} className="mb-6">
        <TabsList>
          <TabsTrigger value="risks">Risks</TabsTrigger>
          <TabsTrigger value="policies">Policies & Procedures</TabsTrigger>
        </TabsList>

        <TabsContent value="risks" className="mt-6">
          <MetricTiles
            {...metrics}
            activeFilter={metricFilter}
            onTileClick={setMetricFilter}
          />

          <DomainTabs
            tabs={domainTabs}
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />

          <div className="dashboard-card">
            <DataTable
              columns={riskColumns}
              data={mockRiskItems}
              onRowClick={(item) => console.log('Navigate to:', `/riskguard/risks/${item.id}`)}
              actions={[
                { label: 'View Details', onClick: (item) => console.log('View', item.id) },
                { label: 'Edit', onClick: (item) => console.log('Edit', item.id) },
                { label: 'Link CAPA', onClick: (item) => console.log('Link CAPA', item.id) },
              ]}
            />
          </div>
        </TabsContent>

        <TabsContent value="policies" className="mt-6">
          <div className="flex items-center justify-end gap-2 mb-6">
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
            <Button size="sm" className="bg-primary hover:bg-primary/90">
              <Plus className="w-4 h-4 mr-2" />
              Add Policy
            </Button>
          </div>

          <div className="dashboard-card">
            <DataTable
              columns={policyColumns}
              data={mockPolicies}
              onRowClick={(item) => console.log('Navigate to:', `/documents/${item.id}`)}
              actions={[
                { label: 'View', onClick: (item) => console.log('View', item.id) },
                { label: 'Edit', onClick: (item) => console.log('Edit', item.id) },
                { label: 'Archive', onClick: (item) => console.log('Archive', item.id) },
              ]}
            />
          </div>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  );
};

export default RiskManagement;
