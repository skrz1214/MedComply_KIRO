import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import HSLSDashboard from "./pages/HSLSDashboard";
import RiskManagement from "./pages/RiskManagement";
import AuditManagement from "./pages/AuditManagement";
import ComplianceTracking from "./pages/ComplianceTracking";
import FeedbackManagement from "./pages/FeedbackManagement";
import EnforcementManagement from "./pages/EnforcementManagement";
import OrgChart from "./pages/OrgChart";
import Documentation from "./pages/Documentation";
import PRDDocument from "./pages/documents/PRDDocument";
import TDDDocument from "./pages/documents/TDDDocument";
import QATestCases from "./pages/documents/QATestCases";
import UATTestCases from "./pages/documents/UATTestCases";
import SystemPromptDocument from "./pages/documents/SystemPromptDocument";
import { RoleProvider } from "./contexts/RoleContext";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <RoleProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/dashboards/department/hsls" element={<HSLSDashboard />} />
            <Route path="/dashboards/department/hsls/risks" element={<RiskManagement />} />
            <Route path="/dashboards/department/hsls/audits" element={<AuditManagement />} />
            <Route path="/dashboards/department/hsls/compliance" element={<ComplianceTracking />} />
            <Route path="/dashboards/department/hsls/feedback" element={<FeedbackManagement />} />
            <Route path="/dashboards/department/hsls/enforcements" element={<EnforcementManagement />} />
            <Route path="/dashboards/department/hsls/org-chart" element={<OrgChart />} />
            <Route path="/dashboards/department/hsls/documentation" element={<Documentation />} />
            <Route path="/dashboards/department/hsls/policies" element={<RiskManagement />} />
            <Route path="/dashboards/department/hsls/docs/system-prompt" element={<SystemPromptDocument />} />
            <Route path="/dashboards/department/hsls/docs/prd" element={<PRDDocument />} />
            <Route path="/dashboards/department/hsls/docs/tdd" element={<TDDDocument />} />
            <Route path="/dashboards/department/hsls/docs/qa" element={<QATestCases />} />
            <Route path="/dashboards/department/hsls/docs/uat" element={<UATTestCases />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </RoleProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
