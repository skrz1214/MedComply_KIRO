import { ChevronRight, MoreHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

export interface Column<T> {
  key: keyof T | string;
  header: string;
  render?: (item: T) => React.ReactNode;
  className?: string;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  onRowClick?: (item: T) => void;
  actions?: { label: string; onClick: (item: T) => void }[];
}

const statusColors: Record<string, string> = {
  open: 'bg-info/10 text-info border-info/20',
  in_progress: 'bg-warning/10 text-warning border-warning/20',
  pending_review: 'bg-warning/10 text-warning border-warning/20',
  completed: 'bg-success/10 text-success border-success/20',
  overdue: 'bg-critical/10 text-critical border-critical/20',
  active: 'bg-success/10 text-success border-success/20',
  under_review: 'bg-warning/10 text-warning border-warning/20',
  critical: 'bg-critical text-critical-foreground',
  high: 'bg-warning text-warning-foreground',
  medium: 'bg-info text-info-foreground',
  low: 'bg-muted text-muted-foreground',
};

function DataTable<T extends { id: string }>({
  columns,
  data,
  onRowClick,
  actions,
}: DataTableProps<T>) {
  const renderCell = (item: T, column: Column<T>) => {
    if (column.render) {
      return column.render(item);
    }

    const value = (item as any)[column.key];

    // Handle status and priority badges
    if (column.key === 'status' || column.key === 'riskLevel' || column.key === 'priority') {
      const colorClass = statusColors[value] || 'bg-muted text-muted-foreground';
      return (
        <Badge variant="outline" className={cn('text-xs capitalize', colorClass)}>
          {String(value).replace(/_/g, ' ')}
        </Badge>
      );
    }

    // Handle arrays (like hslsDomains)
    if (Array.isArray(value)) {
      return (
        <div className="flex flex-wrap gap-1">
          {value.slice(0, 2).map((v, i) => (
            <Badge key={i} variant="secondary" className="text-xs">
              {v}
            </Badge>
          ))}
          {value.length > 2 && (
            <Badge variant="secondary" className="text-xs">
              +{value.length - 2}
            </Badge>
          )}
        </div>
      );
    }

    return <span className="text-sm">{String(value)}</span>;
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-border">
            {columns.map((column) => (
              <th
                key={String(column.key)}
                className={cn(
                  'text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider',
                  column.className
                )}
              >
                {column.header}
              </th>
            ))}
            {actions && <th className="w-16"></th>}
          </tr>
        </thead>
        <tbody>
          {data.map((item) => (
            <tr
              key={item.id}
              className={cn(
                'border-b border-border hover:bg-muted/30 transition-colors',
                onRowClick && 'cursor-pointer'
              )}
              onClick={() => onRowClick?.(item)}
            >
              {columns.map((column) => (
                <td key={String(column.key)} className={cn('py-3 px-4', column.className)}>
                  {renderCell(item, column)}
                </td>
              ))}
              {actions && (
                <td className="py-3 px-4">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      {actions.map((action) => (
                        <DropdownMenuItem
                          key={action.label}
                          onClick={(e) => {
                            e.stopPropagation();
                            action.onClick(item);
                          }}
                        >
                          {action.label}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>

      {data.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          No items found
        </div>
      )}
    </div>
  );
}

export default DataTable;
