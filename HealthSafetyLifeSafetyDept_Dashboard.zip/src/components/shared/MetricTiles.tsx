import { cn } from '@/lib/utils';
import { FileStack, CheckCircle2, Clock, AlertTriangle } from 'lucide-react';

interface MetricTilesProps {
  total: number;
  pendingReview: number;
  completed: number;
  overdue: number;
  onTileClick?: (filter: string) => void;
  activeFilter?: string;
}

const MetricTiles = ({
  total,
  pendingReview,
  completed,
  overdue,
  onTileClick,
  activeFilter,
}: MetricTilesProps) => {
  const tiles = [
    {
      key: 'total',
      label: 'Total',
      value: total,
      icon: FileStack,
      className: 'text-foreground',
      bgClass: 'bg-muted/50',
    },
    {
      key: 'pending',
      label: 'Pending Review',
      value: pendingReview,
      icon: Clock,
      className: 'text-warning',
      bgClass: 'bg-warning-light',
    },
    {
      key: 'completed',
      label: 'Completed',
      value: completed,
      icon: CheckCircle2,
      className: 'text-success',
      bgClass: 'bg-success-light',
    },
    {
      key: 'overdue',
      label: 'Overdue',
      value: overdue,
      icon: AlertTriangle,
      className: 'text-critical',
      bgClass: 'bg-critical-light',
    },
  ];

  return (
    <div className="grid grid-cols-4 gap-4 mb-6">
      {tiles.map((tile) => (
        <div
          key={tile.key}
          onClick={() => onTileClick?.(tile.key)}
          className={cn(
            'stat-card cursor-pointer transition-all',
            activeFilter === tile.key && 'ring-2 ring-primary ring-offset-2',
            tile.bgClass
          )}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider">
                {tile.label}
              </p>
              <p className={cn('text-2xl font-bold mt-1', tile.className)}>
                {tile.value}
              </p>
            </div>
            <tile.icon className={cn('w-8 h-8 opacity-50', tile.className)} />
          </div>
        </div>
      ))}
    </div>
  );
};

export default MetricTiles;
