import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface Tab {
  id: string;
  label: string;
  count?: number;
}

interface DomainTabsProps {
  tabs: Tab[];
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const DomainTabs = ({ tabs, activeTab, onTabChange }: DomainTabsProps) => {
  return (
    <div className="mb-6 overflow-x-auto">
      <Tabs value={activeTab} onValueChange={onTabChange}>
        <TabsList className="bg-muted/50 h-auto p-1 flex-wrap justify-start">
          {tabs.map((tab) => (
            <TabsTrigger
              key={tab.id}
              value={tab.id}
              className={cn(
                'text-xs px-3 py-1.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground'
              )}
            >
              {tab.label}
              {tab.count !== undefined && (
                <Badge
                  variant="secondary"
                  className="ml-1.5 h-4 px-1.5 text-xs bg-background/50"
                >
                  {tab.count}
                </Badge>
              )}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {activeTab !== 'all' && (
        <div className="flex items-center gap-2 mt-3">
          <span className="text-xs text-muted-foreground">Active filters:</span>
          <Badge variant="outline" className="text-xs">
            Dept = HSLS
          </Badge>
          <Badge variant="outline" className="text-xs">
            Domain = {tabs.find((t) => t.id === activeTab)?.label}
          </Badge>
        </div>
      )}
    </div>
  );
};

export default DomainTabs;
