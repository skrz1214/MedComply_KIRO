import { NavLink, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  AlertTriangle,
  ClipboardCheck,
  Shield,
  MessageSquare,
  Gavel,
  Users,
  FileText,
  ChevronLeft,
  ChevronRight,
  FileCode,
  TestTube,
  UserCheck,
} from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

const navItems = [
  { name: 'Dashboard', path: '/dashboards/department/hsls', icon: LayoutDashboard },
  { name: 'Org Chart', path: '/dashboards/department/hsls/org-chart', icon: Users },
  { name: 'Risk Management', path: '/dashboards/department/hsls/risks', icon: AlertTriangle },
  { name: 'Audit Management', path: '/dashboards/department/hsls/audits', icon: ClipboardCheck },
  { name: 'Enforcement Management', path: '/dashboards/department/hsls/enforcements', icon: Gavel },
  { name: 'Compliance Tracking', path: '/dashboards/department/hsls/compliance', icon: Shield },
  { name: 'Feedback Management', path: '/dashboards/department/hsls/feedback', icon: MessageSquare },
];

const documentItems = [
  { name: 'System Prompt', path: '/dashboards/department/hsls/docs/system-prompt', icon: FileText },
  { name: 'PRD Document', path: '/dashboards/department/hsls/docs/prd', icon: FileText },
  { name: 'TDD Document', path: '/dashboards/department/hsls/docs/tdd', icon: FileCode },
  { name: 'QA Test Cases', path: '/dashboards/department/hsls/docs/qa', icon: TestTube },
  { name: 'UAT Test Cases', path: '/dashboards/department/hsls/docs/uat', icon: UserCheck },
];

const Sidebar = () => {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  return (
    <aside
      className={cn(
        'fixed left-0 top-0 h-screen bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300 z-40',
        collapsed ? 'w-16' : 'w-60'
      )}
    >
      {/* Logo */}
      <div className="h-14 flex items-center px-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center flex-shrink-0">
            <Shield className="w-5 h-5 text-primary-foreground" />
          </div>
          {!collapsed && (
            <div className="animate-fade-in">
              <h1 className="font-semibold text-sm text-sidebar-foreground">SafetyHub</h1>
              <p className="text-xs text-muted-foreground">HSLS Division</p>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 px-3 overflow-y-auto">
        <div className="space-y-1">
          {!collapsed && (
            <p className="px-3 mb-2 text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Management Hub
            </p>
          )}
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={cn(
                  'nav-item',
                  isActive && 'nav-item-active',
                  collapsed && 'justify-center px-2'
                )}
                title={collapsed ? item.name : undefined}
              >
                <item.icon className="w-5 h-5 flex-shrink-0" />
                {!collapsed && <span className="text-sm">{item.name}</span>}
              </NavLink>
            );
          })}
        </div>

        {/* Documents Section */}
        <div className="mt-6 space-y-1">
          {!collapsed && (
            <p className="px-3 mb-2 text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Documents
            </p>
          )}
          {documentItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={cn(
                  'nav-item',
                  isActive && 'nav-item-active',
                  collapsed && 'justify-center px-2'
                )}
                title={collapsed ? item.name : undefined}
              >
                <item.icon className="w-5 h-5 flex-shrink-0" />
                {!collapsed && <span className="text-sm">{item.name}</span>}
              </NavLink>
            );
          })}
        </div>
      </nav>

      {/* Collapse Toggle */}
      <div className="p-3 border-t border-sidebar-border">
        <Button
          variant="ghost"
          size="sm"
          className={cn('w-full', collapsed ? 'px-2' : 'justify-start')}
          onClick={() => setCollapsed(!collapsed)}
        >
          {collapsed ? (
            <ChevronRight className="w-4 h-4" />
          ) : (
            <>
              <ChevronLeft className="w-4 h-4 mr-2" />
              <span>Collapse</span>
            </>
          )}
        </Button>
      </div>
    </aside>
  );
};

export default Sidebar;
