import { Search, Bell, Settings, User, ChevronDown, Home, Shield, Building2, UserCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Link } from 'react-router-dom';
import { useRole, UserRole } from '@/contexts/RoleContext';
import { Badge } from '@/components/ui/badge';

interface HeaderProps {
  title: string;
  subtitle?: string;
}

const roleConfig: Record<UserRole, { label: string; icon: React.ElementType; color: string }> = {
  admin: { label: 'Admin / Compliance Head', icon: Shield, color: 'bg-primary text-primary-foreground' },
  department_head: { label: 'Department Head', icon: Building2, color: 'bg-secondary text-secondary-foreground' },
  staff: { label: 'Staff', icon: UserCircle, color: 'bg-muted text-muted-foreground' },
};

const Header = ({ title, subtitle }: HeaderProps) => {
  const { currentRole, setRole, roleLabel } = useRole();
  const RoleIcon = roleConfig[currentRole].icon;

  return (
    <header className="h-14 bg-card border-b border-border flex items-center justify-between px-3 sm:px-6">
      <div className="flex items-center gap-2 sm:gap-4">
        <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
          <Home className="w-5 h-5" />
        </Link>
        <div className="min-w-0">
          <h1 className="text-sm sm:text-lg font-semibold text-foreground truncate">{title}</h1>
          {subtitle && <p className="text-xs text-muted-foreground hidden sm:block">{subtitle}</p>}
        </div>
      </div>

      <div className="flex items-center gap-1 sm:gap-4">
        {/* Role Switcher */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="flex items-center gap-1 sm:gap-2 h-8 sm:h-9 px-2 sm:px-4">
              <RoleIcon className="w-4 h-4" />
              <span className="text-sm hidden md:inline">{roleLabel}</span>
              <Badge variant="secondary" className="hidden lg:inline-flex ml-1 text-xs">
                Impersonating
              </Badge>
              <ChevronDown className="w-3 h-3 sm:w-4 sm:h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Switch Role</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {(Object.keys(roleConfig) as UserRole[]).map((role) => {
              const config = roleConfig[role];
              const Icon = config.icon;
              return (
                <DropdownMenuItem
                  key={role}
                  onClick={() => setRole(role)}
                  className={currentRole === role ? 'bg-accent' : ''}
                >
                  <Icon className="w-4 h-4 mr-2" />
                  {config.label}
                  {currentRole === role && (
                    <Badge variant="outline" className="ml-auto text-xs">
                      Active
                    </Badge>
                  )}
                </DropdownMenuItem>
              );
            })}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Facility Selector - Hidden on mobile */}
        <Select defaultValue="all">
          <SelectTrigger className="w-24 sm:w-40 h-8 sm:h-9 text-xs sm:text-sm hidden sm:flex">
            <SelectValue placeholder="Facility" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Facilities</SelectItem>
            <SelectItem value="main">Main Campus</SelectItem>
            <SelectItem value="north">North Wing</SelectItem>
            <SelectItem value="south">South Pavilion</SelectItem>
          </SelectContent>
        </Select>

        {/* Date Range - Hidden on mobile */}
        <Select defaultValue="30">
          <SelectTrigger className="w-24 sm:w-32 h-8 sm:h-9 text-xs sm:text-sm hidden md:flex">
            <SelectValue placeholder="Date Range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">Last 7 days</SelectItem>
            <SelectItem value="30">Last 30 days</SelectItem>
            <SelectItem value="90">Last 90 days</SelectItem>
            <SelectItem value="ytd">Year to Date</SelectItem>
          </SelectContent>
        </Select>

        {/* Search - Hidden on mobile */}
        <div className="relative hidden lg:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search..."
            className="pl-9 w-48 xl:w-64 h-9"
          />
        </div>

        {/* Search Icon for mobile */}
        <Button variant="ghost" size="icon" className="h-8 w-8 lg:hidden">
          <Search className="w-4 h-4" />
        </Button>

        {/* Notifications */}
        <Button variant="ghost" size="icon" className="relative h-8 w-8 sm:h-9 sm:w-9">
          <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-critical rounded-full" />
        </Button>

        {/* Settings - Hidden on mobile */}
        <Button variant="ghost" size="icon" className="hidden sm:flex h-8 w-8 sm:h-9 sm:w-9">
          <Settings className="w-4 h-4 sm:w-5 sm:h-5" />
        </Button>

        {/* User Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="flex items-center gap-1 sm:gap-2 h-8 sm:h-9 px-1 sm:px-2">
              <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-primary/10 flex items-center justify-center">
                <User className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
              </div>
              <span className="text-sm hidden sm:inline">John Doe</span>
              <ChevronDown className="w-3 h-3 sm:w-4 sm:h-4 hidden sm:block" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuItem>Profile</DropdownMenuItem>
            <DropdownMenuItem>Settings</DropdownMenuItem>
            <DropdownMenuItem>Sign out</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};

export default Header;
