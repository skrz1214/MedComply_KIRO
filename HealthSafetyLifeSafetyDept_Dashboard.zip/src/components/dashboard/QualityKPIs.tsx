import { useState } from 'react';
import { Plus, TrendingUp, TrendingDown, Minus, Info, Pencil, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { mockKPIs } from '@/data/mockData';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { KPI } from '@/types/hsls';
import { toast } from '@/hooks/use-toast';

const trendConfig = {
  up: { icon: TrendingUp, className: 'text-success' },
  down: { icon: TrendingDown, className: 'text-critical' },
  stable: { icon: Minus, className: 'text-muted-foreground' },
};

const defaultKPI: Omit<KPI, 'id'> = {
  name: '',
  value: 0,
  target: 0,
  unit: '%',
  trend: 'stable',
  numerator: { description: '', value: 0 },
  denominator: { description: '', value: 0 },
};

const QualityKPIs = () => {
  const [kpis, setKpis] = useState<KPI[]>(mockKPIs);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingKPI, setEditingKPI] = useState<KPI | null>(null);
  const [deleteKPIId, setDeleteKPIId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Omit<KPI, 'id'>>(defaultKPI);

  const calculateValue = (numerator: number, denominator: number): number => {
    if (denominator === 0) return 0;
    return Math.round((numerator / denominator) * 100 * 10) / 10;
  };

  const handleOpenAdd = () => {
    setEditingKPI(null);
    setFormData(defaultKPI);
    setDialogOpen(true);
  };

  const handleOpenEdit = (kpi: KPI) => {
    setEditingKPI(kpi);
    setFormData({
      name: kpi.name,
      value: kpi.value,
      target: kpi.target,
      unit: kpi.unit,
      formula: kpi.formula,
      trend: kpi.trend,
      numerator: kpi.numerator || { description: '', value: 0 },
      denominator: kpi.denominator || { description: '', value: 0 },
    });
    setDialogOpen(true);
  };

  const handleOpenDelete = (id: string) => {
    setDeleteKPIId(id);
    setDeleteDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.name.trim()) {
      toast({ title: 'Error', description: 'KPI name is required', variant: 'destructive' });
      return;
    }

    const calculatedValue = formData.numerator && formData.denominator
      ? calculateValue(formData.numerator.value, formData.denominator.value)
      : formData.value;

    const formula = formData.numerator?.description && formData.denominator?.description
      ? `(${formData.numerator.description}) / (${formData.denominator.description}) × 100`
      : formData.formula;

    if (editingKPI) {
      setKpis(prev =>
        prev.map(kpi =>
          kpi.id === editingKPI.id
            ? { ...kpi, ...formData, value: calculatedValue, formula }
            : kpi
        )
      );
      toast({ title: 'Success', description: 'KPI updated successfully' });
    } else {
      const newKPI: KPI = {
        id: `kpi-${Date.now()}`,
        ...formData,
        value: calculatedValue,
        formula,
      };
      setKpis(prev => [...prev, newKPI]);
      toast({ title: 'Success', description: 'KPI created successfully' });
    }

    setDialogOpen(false);
    setFormData(defaultKPI);
    setEditingKPI(null);
  };

  const handleDelete = () => {
    if (deleteKPIId) {
      setKpis(prev => prev.filter(kpi => kpi.id !== deleteKPIId));
      toast({ title: 'Success', description: 'KPI deleted successfully' });
    }
    setDeleteDialogOpen(false);
    setDeleteKPIId(null);
  };

  const updateNumerator = (field: 'description' | 'value', val: string | number) => {
    setFormData(prev => ({
      ...prev,
      numerator: {
        ...prev.numerator!,
        [field]: field === 'value' ? Number(val) : val,
      },
    }));
  };

  const updateDenominator = (field: 'description' | 'value', val: string | number) => {
    setFormData(prev => ({
      ...prev,
      denominator: {
        ...prev.denominator!,
        [field]: field === 'value' ? Number(val) : val,
      },
    }));
  };

  return (
    <div className="dashboard-card p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-semibold text-foreground">Quality KPIs</h2>
        <Button variant="ghost" size="icon" className="w-6 h-6" onClick={handleOpenAdd}>
          <Plus className="w-4 h-4" />
        </Button>
      </div>

      <div className="space-y-5">
        {kpis.map((kpi) => {
          const TrendIcon = trendConfig[kpi.trend].icon;
          const progressPercent = kpi.unit === '%' 
            ? kpi.value 
            : Math.min((1 - kpi.value / Math.max(kpi.target, 1)) * 100, 100);
          
          const isOnTarget = kpi.unit === '%' 
            ? kpi.value >= kpi.target 
            : kpi.value <= kpi.target;

          return (
            <div key={kpi.id} className="group">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium text-foreground">{kpi.name}</span>
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => handleOpenEdit(kpi)}
                  >
                    <Pencil className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive"
                    onClick={() => handleOpenDelete(kpi.id)}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                  <TrendIcon className={cn('w-4 h-4', trendConfig[kpi.trend].className)} />
                </div>
              </div>

              <div className="flex items-baseline gap-2 mb-2">
                <span className="text-2xl font-bold text-foreground">
                  {kpi.value}{kpi.unit === '%' && '%'}
                </span>
                <span className="text-xs text-muted-foreground">
                  Target: {kpi.target}{kpi.unit === '%' && '%'}
                </span>
              </div>

              <div className="progress-bar mb-2">
                <div
                  className={cn(
                    'progress-fill',
                    isOnTarget ? 'bg-success' : 'bg-warning'
                  )}
                  style={{ width: `${Math.min(progressPercent, 100)}%` }}
                />
              </div>

              {kpi.formula && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground cursor-help">
                      <Info className="w-3 h-3" />
                      <span className="truncate">{kpi.formula}</span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>{kpi.formula}</p>
                  </TooltipContent>
                </Tooltip>
              )}
            </div>
          );
        })}
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingKPI ? 'Edit KPI' : 'Add New KPI'}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="kpi-name">KPI Name</Label>
              <Input
                id="kpi-name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="e.g., Safety Compliance Rate"
                maxLength={100}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="kpi-target">Target</Label>
                <Input
                  id="kpi-target"
                  type="number"
                  value={formData.target}
                  onChange={(e) => setFormData(prev => ({ ...prev, target: Number(e.target.value) }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="kpi-unit">Unit</Label>
                <Select
                  value={formData.unit}
                  onValueChange={(val: '%' | 'count' | 'days') => setFormData(prev => ({ ...prev, unit: val }))}
                >
                  <SelectTrigger id="kpi-unit">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="%">Percentage (%)</SelectItem>
                    <SelectItem value="count">Count</SelectItem>
                    <SelectItem value="days">Days</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="kpi-trend">Trend</Label>
              <Select
                value={formData.trend}
                onValueChange={(val: 'up' | 'down' | 'stable') => setFormData(prev => ({ ...prev, trend: val }))}
              >
                <SelectTrigger id="kpi-trend">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="up">Trending Up</SelectItem>
                  <SelectItem value="down">Trending Down</SelectItem>
                  <SelectItem value="stable">Stable</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="border-t border-border pt-4">
              <h4 className="text-sm font-medium text-foreground mb-3">Numerator</h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="num-desc">Description</Label>
                  <Input
                    id="num-desc"
                    value={formData.numerator?.description || ''}
                    onChange={(e) => updateNumerator('description', e.target.value)}
                    placeholder="e.g., Compliant Items"
                    maxLength={100}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="num-value">Value</Label>
                  <Input
                    id="num-value"
                    type="number"
                    value={formData.numerator?.value || 0}
                    onChange={(e) => updateNumerator('value', e.target.value)}
                  />
                </div>
              </div>
            </div>

            <div className="border-t border-border pt-4">
              <h4 className="text-sm font-medium text-foreground mb-3">Denominator</h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="denom-desc">Description</Label>
                  <Input
                    id="denom-desc"
                    value={formData.denominator?.description || ''}
                    onChange={(e) => updateDenominator('description', e.target.value)}
                    placeholder="e.g., Total Items"
                    maxLength={100}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="denom-value">Value</Label>
                  <Input
                    id="denom-value"
                    type="number"
                    value={formData.denominator?.value || 0}
                    onChange={(e) => updateDenominator('value', e.target.value)}
                  />
                </div>
              </div>
            </div>

            {formData.numerator?.value && formData.denominator?.value ? (
              <div className="bg-muted/50 rounded-lg p-3">
                <p className="text-sm text-muted-foreground">
                  Calculated Value:{' '}
                  <span className="font-semibold text-foreground">
                    {calculateValue(formData.numerator.value, formData.denominator.value)}%
                  </span>
                </p>
              </div>
            ) : null}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave}>
              {editingKPI ? 'Update' : 'Create'} KPI
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete KPI</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this KPI? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default QualityKPIs;
