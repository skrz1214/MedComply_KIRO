import { FileStack, CheckCircle2, Clock, AlertTriangle, TrendingUp, TrendingDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { mockQuickStats } from '@/data/mockData';

const stats = [
  {
    label: 'Total',
    value: mockQuickStats.total,
    change: mockQuickStats.totalChange,
    icon: FileStack,
    iconClassName: 'text-muted-foreground',
  },
  {
    label: 'Completed',
    value: mockQuickStats.completed,
    change: mockQuickStats.completedChange,
    icon: CheckCircle2,
    iconClassName: 'text-success',
    valueClassName: 'text-success',
  },
  {
    label: 'Pending',
    value: mockQuickStats.pending,
    change: mockQuickStats.pendingChange,
    icon: Clock,
    iconClassName: 'text-warning',
    valueClassName: 'text-warning',
  },
  {
    label: 'Overdue',
    value: mockQuickStats.overdue,
    change: mockQuickStats.overdueChange,
    icon: AlertTriangle,
    iconClassName: 'text-critical',
    valueClassName: 'text-critical',
  },
];

const QuickStats = () => {
  return (
    <div className="dashboard-card p-4">
      <h2 className="font-semibold text-foreground mb-4">Quick Stats</h2>

      <div className="space-y-4">
        {stats.map((stat) => (
          <div key={stat.label} className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <stat.icon className={cn('w-5 h-5', stat.iconClassName)} />
              <span className="text-sm text-muted-foreground">{stat.label}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={cn('text-xl font-bold', stat.valueClassName)}>
                {stat.value}
              </span>
              {stat.change !== 0 && (
                <span
                  className={cn(
                    'text-xs flex items-center gap-0.5',
                    stat.change > 0 ? 'text-success' : 'text-critical'
                  )}
                >
                  {stat.change > 0 ? (
                    <TrendingUp className="w-3 h-3" />
                  ) : (
                    <TrendingDown className="w-3 h-3" />
                  )}
                  {stat.change > 0 ? '+' : ''}{stat.change}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default QuickStats;
