import { FileText, ClipboardCheck, GraduationCap, Shield, AlertTriangle, Gavel, ChevronRight, Calendar, User } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { mockReviewItems } from '@/data/mockData';
import { ReviewItem } from '@/types/hsls';

const typeConfig = {
  policy: { label: 'Policy', icon: FileText, className: 'bg-primary/10 text-primary' },
  audit: { label: 'Audit', icon: ClipboardCheck, className: 'bg-warning/10 text-warning' },
  training: { label: 'Training', icon: GraduationCap, className: 'bg-success/10 text-success' },
  capa: { label: 'CAPA', icon: Shield, className: 'bg-info/10 text-info' },
  citation: { label: 'Citation', icon: AlertTriangle, className: 'bg-critical/10 text-critical' },
  enforcement: { label: 'Enforcement', icon: Gavel, className: 'bg-muted text-muted-foreground' },
};

const statusConfig = {
  pending_review: { label: 'Pending Review', className: 'bg-warning/10 text-warning border-warning/20' },
  in_progress: { label: 'In Progress', className: 'bg-success/10 text-success border-success/20' },
  approved: { label: 'Approved', className: 'bg-primary/10 text-primary border-primary/20' },
  rejected: { label: 'Rejected', className: 'bg-critical/10 text-critical border-critical/20' },
};

const ReviewQueue = () => {
  const renderReviewItem = (item: ReviewItem) => {
    const typeInfo = typeConfig[item.type];
    const statusInfo = statusConfig[item.status];
    const TypeIcon = typeInfo.icon;

    return (
      <div
        key={item.id}
        className="flex items-center gap-4 p-4 hover:bg-muted/30 transition-colors cursor-pointer group border-b border-border last:border-0"
      >
        <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center', typeInfo.className)}>
          <TypeIcon className="w-5 h-5" />
        </div>

        <div className="flex-1 min-w-0">
          <h4 className="font-medium text-foreground group-hover:text-primary transition-colors truncate">
            {item.title}
          </h4>
          <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
            <Badge variant="outline" className={cn('text-xs font-normal', typeInfo.className)}>
              {typeInfo.label}
            </Badge>
            <span className="flex items-center gap-1">
              <User className="w-3 h-3" />
              {item.owner}
            </span>
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {item.date}
            </span>
            <Badge variant="outline" className={cn('text-xs font-normal', statusInfo.className)}>
              {statusInfo.label}
            </Badge>
          </div>
        </div>

        <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
      </div>
    );
  };

  return (
    <div className="dashboard-card">
      <div className="flex items-center gap-2 p-4 border-b border-border">
        <h2 className="font-semibold text-foreground">Review Queue</h2>
        <Badge variant="secondary" className="bg-warning/10 text-warning">
          {mockReviewItems.length}
        </Badge>
      </div>

      <p className="px-4 pt-3 text-sm text-muted-foreground">
        Pending reviews & sign-offs
      </p>

      <div className="mt-2">
        {mockReviewItems.map(renderReviewItem)}
      </div>
    </div>
  );
};

export default ReviewQueue;
