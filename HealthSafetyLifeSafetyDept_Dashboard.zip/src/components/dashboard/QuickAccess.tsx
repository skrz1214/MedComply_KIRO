import { Link } from 'react-router-dom';
import { 
  ShieldCheck, 
  MessageSquare, 
  AlertTriangle, 
  ClipboardCheck, 
  Gavel,
  FileWarning,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { MICRO_APPS } from '@/types/hsls';

const iconMap = {
  'shield-check': ShieldCheck,
  'message-square': MessageSquare,
  'triangle-alert': AlertTriangle,
  'clipboard-check': ClipboardCheck,
  'gavel': Gavel,
  'file-warning': FileWarning,
};

const colorMap = {
  primary: 'bg-primary text-primary-foreground',
  warning: 'bg-warning text-warning-foreground',
  critical: 'bg-critical text-critical-foreground',
  success: 'bg-success text-success-foreground',
  info: 'bg-info text-info-foreground',
  destructive: 'bg-destructive text-destructive-foreground',
};

const QuickAccess = () => {
  return (
    <div id="quick-access" className="mt-8">
      <h2 className="font-semibold text-foreground mb-4">Quick Access</h2>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {MICRO_APPS.map((app) => {
          const Icon = iconMap[app.icon as keyof typeof iconMap] || ShieldCheck;
          const colorClass = colorMap[app.color as keyof typeof colorMap] || colorMap.primary;

          return (
            <Link
              key={app.id}
              to={`${app.route}?from=hsls-dashboard&dept=hsls`}
              className="dashboard-card p-4 hover:shadow-card-hover transition-all group cursor-pointer"
            >
              <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center mb-3', colorClass)}>
                <Icon className="w-5 h-5" />
              </div>
              <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                {app.name}
              </h3>
              <p className="text-xs text-muted-foreground mt-1">{app.description}</p>
            </Link>
          );
        })}
      </div>
    </div>
  );
};

export default QuickAccess;
