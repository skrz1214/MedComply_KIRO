import { AlertTriangle, Calendar, Flame, Bell } from 'lucide-react';
import { cn } from '@/lib/utils';

const alerts = [
  {
    id: 1,
    title: 'State Survey Scheduled',
    description: 'Annual survey window opens in 14 days',
    icon: Calendar,
    type: 'warning',
    date: 'Jan 7, 2025',
  },
  {
    id: 2,
    title: 'Fire Drill Overdue',
    description: 'Building C quarterly fire drill is 3 days overdue',
    icon: Flame,
    type: 'critical',
    date: 'Dec 21, 2024',
  },
  {
    id: 3,
    title: 'Critical Risk Open',
    description: '2 high-priority safety code issues pending',
    icon: AlertTriangle,
    type: 'critical',
    date: 'Dec 20, 2024',
  },
];

const typeConfig = {
  warning: {
    bgClass: 'bg-warning-light',
    iconClass: 'text-warning',
    borderClass: 'border-l-warning',
  },
  critical: {
    bgClass: 'bg-critical-light',
    iconClass: 'text-critical',
    borderClass: 'border-l-critical',
  },
  info: {
    bgClass: 'bg-info-light',
    iconClass: 'text-info',
    borderClass: 'border-l-info',
  },
};

const AlertsPanel = () => {
  return (
    <div className="dashboard-card p-4">
      <div className="flex items-center gap-2 mb-4">
        <Bell className="w-5 h-5 text-muted-foreground" />
        <h2 className="font-semibold text-foreground">Alerts</h2>
      </div>

      <div className="space-y-3">
        {alerts.map((alert) => {
          const config = typeConfig[alert.type as keyof typeof typeConfig];
          const Icon = alert.icon;

          return (
            <div
              key={alert.id}
              className={cn(
                'p-3 rounded-lg border-l-4 cursor-pointer hover:opacity-80 transition-opacity',
                config.bgClass,
                config.borderClass
              )}
            >
              <div className="flex items-start gap-3">
                <Icon className={cn('w-5 h-5 mt-0.5 flex-shrink-0', config.iconClass)} />
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-foreground text-sm">{alert.title}</h4>
                  <p className="text-xs text-muted-foreground mt-0.5">{alert.description}</p>
                  <span className="text-xs text-muted-foreground mt-1 block">{alert.date}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AlertsPanel;
