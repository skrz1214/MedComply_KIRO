import { useState } from 'react';
import { Plus, ChevronRight, Clock, User, AlertCircle, Calendar, ShieldCheck, MessageSquare, AlertTriangle, ClipboardCheck, Gavel, FileWarning } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { mockActionItems } from '@/data/mockData';
import { ActionItem, MICRO_APPS } from '@/types/hsls';

const priorityConfig = {
  critical: { label: 'Critical', className: 'bg-critical text-critical-foreground' },
  high: { label: 'High', className: 'bg-warning text-warning-foreground' },
  medium: { label: 'Med', className: 'bg-info text-info-foreground' },
  low: { label: 'Low', className: 'bg-muted text-muted-foreground' },
};

const statusConfig = {
  not_started: { label: 'Not started', className: 'text-muted-foreground' },
  in_progress: { label: 'In progress', className: 'text-info' },
  pending_review: { label: 'Pending Review', className: 'text-warning' },
  completed: { label: 'Completed', className: 'text-success' },
  overdue: { label: 'Overdue', className: 'text-critical' },
};

const iconMap = {
  'shield-check': ShieldCheck,
  'message-square': MessageSquare,
  'triangle-alert': AlertTriangle,
  'clipboard-check': ClipboardCheck,
  'gavel': Gavel,
  'file-warning': FileWarning,
};

const colorMap = {
  primary: 'bg-primary text-primary-foreground',
  warning: 'bg-warning text-warning-foreground',
  critical: 'bg-critical text-critical-foreground',
  success: 'bg-success text-success-foreground',
  info: 'bg-info text-info-foreground',
  destructive: 'bg-destructive text-destructive-foreground',
};

const ActionCenter = () => {
  const [filter, setFilter] = useState<'me' | 'all'>('me');
  const [typeFilter, setTypeFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);

  const today = new Date().toISOString().split('T')[0];
  const todayItems = mockActionItems.filter(item => item.dueDate === today);
  const overdueItems = mockActionItems.filter(item => item.status === 'overdue');
  const thisWeekItems = mockActionItems.filter(item => {
    const dueDate = new Date(item.dueDate);
    const now = new Date();
    const weekFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    return dueDate > now && dueDate <= weekFromNow;
  });

  const getProgress = () => {
    const completed = mockActionItems.filter(i => i.status === 'completed').length;
    return { completed, total: todayItems.length || 2 };
  };

  const progress = getProgress();

  const renderActionItem = (item: ActionItem) => (
    <div
      key={item.id}
      className="p-4 bg-card rounded-lg border border-border hover:shadow-card-hover transition-all cursor-pointer group"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <h4 className="font-medium text-foreground group-hover:text-primary transition-colors">
            {item.title}
          </h4>
          <div className="flex items-center gap-3 mt-2 text-sm">
            <span className="flex items-center gap-1 text-muted-foreground">
              <Calendar className="w-3.5 h-3.5" />
              Due {item.dueDate === today ? 'Today' : item.dueDate}
            </span>
            <span className="flex items-center gap-1 text-muted-foreground">
              <User className="w-3.5 h-3.5" />
              {item.owner}
            </span>
            <Badge className={cn('text-xs', priorityConfig[item.priority].className)}>
              {priorityConfig[item.priority].label}
            </Badge>
            <span className={cn('text-xs', statusConfig[item.status].className)}>
              {statusConfig[item.status].label}
            </span>
          </div>
        </div>
        <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
      </div>
    </div>
  );

  return (
    <div className="dashboard-card">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <h2 className="font-semibold text-foreground">Action Center</h2>
          <Badge variant="secondary" className="bg-primary text-primary-foreground">
            {mockActionItems.length}
          </Badge>
        </div>
        
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Plus className="w-4 h-4 mr-1" />
              Add Action Item
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Select Micro App</DialogTitle>
            </DialogHeader>
            <p className="text-sm text-muted-foreground mb-4">
              Choose a micro app to create a new action item
            </p>
            <div className="grid grid-cols-2 gap-3">
              {MICRO_APPS.map((app) => {
                const Icon = iconMap[app.icon as keyof typeof iconMap] || ShieldCheck;
                const colorClass = colorMap[app.color as keyof typeof colorMap] || colorMap.primary;

                return (
                  <Link
                    key={app.id}
                    to={`${app.route}/new?from=hsls-dashboard&dept=hsls`}
                    onClick={() => setDialogOpen(false)}
                    className="p-4 rounded-lg border border-border hover:border-primary hover:shadow-card-hover transition-all group cursor-pointer bg-card"
                  >
                    <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center mb-3', colorClass)}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                      {app.name}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{app.description}</p>
                  </Link>
                );
              })}
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Subheader */}
      <div className="p-4 border-b border-border">
        <p className="text-sm text-muted-foreground mb-3">Executive compliance tasks</p>

        {/* Progress Bar */}
        <div className="mb-4">
          <div className="flex items-center justify-between text-sm mb-1">
            <span className="text-muted-foreground">Today's Progress</span>
            <span className="text-muted-foreground flex items-center gap-1">
              {progress.completed} of {progress.total} completed
              <Clock className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="progress-bar">
            <div
              className="progress-fill bg-warning"
              style={{ width: `${(progress.completed / progress.total) * 100}%` }}
            />
          </div>
        </div>

        {/* Tabs & Filters */}
        <Tabs defaultValue="today" className="w-full">
          <div className="flex items-center justify-between mb-3">
            <TabsList className="bg-muted/50">
              <TabsTrigger value="today" className="text-xs">
                Today <span className="ml-1 text-muted-foreground">{todayItems.length}</span>
              </TabsTrigger>
              <TabsTrigger value="week" className="text-xs">
                This Week <span className="ml-1 text-muted-foreground">{thisWeekItems.length}</span>
              </TabsTrigger>
              <TabsTrigger value="overdue" className="text-xs">
                Overdue <span className="ml-1 text-critical">{overdueItems.length}</span>
              </TabsTrigger>
            </TabsList>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center bg-muted rounded-lg p-0.5">
              <Button
                variant={filter === 'me' ? 'default' : 'ghost'}
                size="sm"
                className={cn(
                  'h-7 px-3 text-xs',
                  filter === 'me' && 'bg-primary text-primary-foreground'
                )}
                onClick={() => setFilter('me')}
              >
                Me
              </Button>
              <Button
                variant={filter === 'all' ? 'default' : 'ghost'}
                size="sm"
                className={cn(
                  'h-7 px-3 text-xs',
                  filter === 'all' && 'bg-primary text-primary-foreground'
                )}
                onClick={() => setFilter('all')}
              >
                All
              </Button>
            </div>

            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-28 h-8 text-xs">
                <SelectValue placeholder="All Types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="risk">Risk</SelectItem>
                <SelectItem value="audit">Audit</SelectItem>
                <SelectItem value="compliance">Compliance</SelectItem>
                <SelectItem value="feedback">Feedback</SelectItem>
                <SelectItem value="enforcement">Enforcement</SelectItem>
              </SelectContent>
            </Select>

            <Input
              placeholder="Search tasks"
              className="flex-1 h-8 text-sm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <TabsContent value="today" className="mt-4 space-y-3">
            {mockActionItems.slice(0, 2).map(renderActionItem)}
          </TabsContent>

          <TabsContent value="week" className="mt-4 space-y-3">
            {mockActionItems.slice(0, 3).map(renderActionItem)}
          </TabsContent>

          <TabsContent value="overdue" className="mt-4 space-y-3">
            {overdueItems.length > 0 ? (
              overdueItems.map(renderActionItem)
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <AlertCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>No overdue items</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ActionCenter;
