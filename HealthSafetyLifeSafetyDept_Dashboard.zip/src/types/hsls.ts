export type Priority = 'critical' | 'high' | 'medium' | 'low';
export type Status = 'not_started' | 'in_progress' | 'pending_review' | 'completed' | 'overdue';

export interface ActionItem {
  id: string;
  title: string;
  description?: string;
  priority: Priority;
  status: Status;
  dueDate: string;
  owner: string;
  type: 'risk' | 'audit' | 'compliance' | 'feedback' | 'enforcement';
  hslsDomains: string[];
  evidencePackRequired: boolean;
}

export interface ReviewItem {
  id: string;
  title: string;
  type: 'policy' | 'audit' | 'training' | 'capa' | 'citation' | 'enforcement';
  owner: string;
  date: string;
  status: 'pending_review' | 'in_progress' | 'approved' | 'rejected';
}

export interface QuickStat {
  label: string;
  value: number;
  change?: number;
  trend?: 'up' | 'down' | 'stable';
  icon?: string;
}

export interface KPI {
  id: string;
  name: string;
  value: number;
  target: number;
  unit: '%' | 'count' | 'days';
  formula?: string;
  trend: 'up' | 'down' | 'stable';
  numerator?: {
    description: string;
    value: number;
  };
  denominator?: {
    description: string;
    value: number;
  };
}

export interface MicroApp {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  route: string;
}

export interface HSLSDomain {
  id: string;
  name: string;
  description?: string;
}

export const HSLS_DOMAINS: HSLSDomain[] = [
  { id: 'life-safety', name: 'Life Safety / Fire Safety' },
  { id: 'emergency-prep', name: 'Emergency Preparedness' },
  { id: 'environment-care', name: 'Environment of Care' },
  { id: 'infection-prevention', name: 'Infection Prevention & Control' },
  { id: 'hazmat', name: 'Hazardous Materials & Waste' },
  { id: 'workplace-safety', name: 'Workplace Safety / OSHA' },
  { id: 'equipment-safety', name: 'Equipment Safety / Maintenance' },
  { id: 'security', name: 'Security / Violence Prevention' },
  { id: 'incident-review', name: 'Incident / Accident Safety Review' },
  { id: 'survey-readiness', name: 'Survey/Inspection Readiness' },
  { id: 'employee-violations', name: 'Employee Violations' },
  { id: 'safety-code', name: 'Safety Code Issues' },
  { id: 'poc', name: 'Plan of Correction (POC)' },
];

export const OVERSIGHT_BODIES = [
  'CMS',
  'State Survey/DOH',
  'OSHA',
  'Local Fire Marshal/AHJ',
  'Accreditor',
  'EPA',
  'Other',
];

export const MICRO_APPS: MicroApp[] = [
  {
    id: 'compliance-connect',
    name: 'ComplianceConnect',
    description: 'Compliance management hub',
    icon: 'shield-check',
    color: 'primary',
    route: '/complianceconnect',
  },
  {
    id: 'feedback-hub',
    name: 'FeedbackHub',
    description: 'Stakeholder feedback system',
    icon: 'message-square',
    color: 'warning',
    route: '/feedbackhub',
  },
  {
    id: 'risk-guard',
    name: 'RiskGuard',
    description: 'Risk assessment platform',
    icon: 'triangle-alert',
    color: 'critical',
    route: '/riskguard',
  },
  {
    id: 'audit-pro',
    name: 'AuditPro',
    description: 'Audit management system',
    icon: 'clipboard-check',
    color: 'success',
    route: '/auditpro',
  },
  {
    id: 'enforce-point',
    name: 'EnforcePoint',
    description: 'Enforcement tracking',
    icon: 'gavel',
    color: 'info',
    route: '/enforcepoint',
  },
  {
    id: 'cita-pro',
    name: 'CitaPro',
    description: 'Citation management',
    icon: 'file-warning',
    color: 'destructive',
    route: '/citapro',
  },
];
