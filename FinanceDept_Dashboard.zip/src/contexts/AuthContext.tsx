import { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'admin' | 'department_head' | 'staff';
export type ViewMode = 'department' | 'individual';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  department: string;
}

interface AuthContextType {
  user: User | null;
  viewMode: ViewMode;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<{ error: string | null }>;
  logout: () => void;
  setViewMode: (mode: ViewMode) => void;
  canToggleView: boolean;
  impersonateAs: (role: UserRole) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for demonstration
const mockUsers: Record<string, { password: string; user: User }> = {
  'admin@financehub.com': {
    password: 'admin123',
    user: {
      id: '1',
      email: 'admin@financehub.com',
      name: 'Jane Smith',
      role: 'admin',
      department: 'Finance',
    },
  },
  'head@financehub.com': {
    password: 'head123',
    user: {
      id: '2',
      email: 'head@financehub.com',
      name: 'Michael Torres',
      role: 'department_head',
      department: 'Finance',
    },
  },
  'staff@financehub.com': {
    password: 'staff123',
    user: {
      id: '3',
      email: 'staff@financehub.com',
      name: 'Sarah Chen',
      role: 'staff',
      department: 'Finance',
    },
  },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    const stored = localStorage.getItem('auth_user');
    return stored ? JSON.parse(stored) : null;
  });
  const [viewMode, setViewModeState] = useState<ViewMode>(() => {
    const stored = localStorage.getItem('view_mode');
    return (stored as ViewMode) || 'department';
  });

  const isAuthenticated = user !== null;
  const canToggleView = user?.role === 'admin' || user?.role === 'department_head';

  const login = async (email: string, password: string): Promise<{ error: string | null }> => {
    const mockUser = mockUsers[email.toLowerCase()];
    
    if (!mockUser) {
      return { error: 'User not found. Try admin@financehub.com, head@financehub.com, or staff@financehub.com' };
    }
    
    if (mockUser.password !== password) {
      return { error: 'Invalid password' };
    }

    setUser(mockUser.user);
    localStorage.setItem('auth_user', JSON.stringify(mockUser.user));
    
    // Set default view mode based on role
    const defaultViewMode = mockUser.user.role === 'staff' ? 'individual' : 'department';
    setViewModeState(defaultViewMode);
    localStorage.setItem('view_mode', defaultViewMode);
    
    return { error: null };
  };

  const logout = () => {
    setUser(null);
    setViewModeState('department');
    localStorage.removeItem('auth_user');
    localStorage.removeItem('view_mode');
  };

  const setViewMode = (mode: ViewMode) => {
    if (canToggleView) {
      setViewModeState(mode);
      localStorage.setItem('view_mode', mode);
    }
  };

  const impersonateAs = (role: UserRole) => {
    if (user?.role === 'admin') {
      const newUser = { ...user, role };
      setUser(newUser);
      localStorage.setItem('auth_user', JSON.stringify(newUser));
      
      // Reset view mode when impersonating
      const defaultViewMode = role === 'staff' ? 'individual' : 'department';
      setViewModeState(defaultViewMode);
      localStorage.setItem('view_mode', defaultViewMode);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        viewMode,
        isAuthenticated,
        login,
        logout,
        setViewMode,
        canToggleView,
        impersonateAs,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
