import { Calendar, ChevronRight, AlertCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface DeadlineItem {
  id: string;
  title: string;
  dueDate: string;
  daysLeft: number;
  priority: 'High' | 'Medium' | 'Low';
  type: string;
}

const deadlines: DeadlineItem[] = [
  {
    id: 'DL-001',
    title: 'Q4 Financial Audit Report',
    dueDate: 'Dec 28, 2024',
    daysLeft: 4,
    priority: 'High',
    type: 'Audit',
  },
  {
    id: 'DL-002',
    title: 'Billing Compliance Review',
    dueDate: 'Dec 30, 2024',
    daysLeft: 6,
    priority: 'High',
    type: 'Compliance',
  },
  {
    id: 'DL-003',
    title: 'Risk Assessment Update',
    dueDate: 'Jan 2, 2025',
    daysLeft: 9,
    priority: 'Medium',
    type: 'Risk',
  },
  {
    id: 'DL-004',
    title: 'Service Contract Renewal Review',
    dueDate: 'Jan 5, 2025',
    daysLeft: 12,
    priority: 'Medium',
    type: 'Contract',
  },
  {
    id: 'DL-005',
    title: 'Internal Control Documentation',
    dueDate: 'Jan 10, 2025',
    daysLeft: 17,
    priority: 'Low',
    type: 'Documentation',
  },
];

export function UpcomingDeadlines() {
  const getDaysLeftColor = (days: number) => {
    if (days <= 3) return 'text-destructive';
    if (days <= 7) return 'text-warning';
    return 'text-muted-foreground';
  };

  return (
    <div className="bg-card rounded-xl border border-border p-6 animate-fade-in">
      <div className="flex items-center gap-3 mb-4">
        <Calendar className="w-5 h-5 text-primary" />
        <h2 className="text-lg font-semibold text-foreground">Upcoming Deadlines</h2>
      </div>

      <div className="space-y-3">
        {deadlines.map((item) => (
          <div
            key={item.id}
            className="action-card flex items-center justify-between group"
          >
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-mono text-xs text-muted-foreground">{item.id}</span>
                <Badge variant={item.priority === 'High' ? 'high' : item.priority === 'Medium' ? 'medium' : 'low'}>
                  {item.priority}
                </Badge>
              </div>
              <h3 className="text-sm font-medium text-foreground truncate">{item.title}</h3>
              <div className="flex items-center gap-3 mt-1 text-xs">
                <span className="text-muted-foreground">{item.dueDate}</span>
                <span className={getDaysLeftColor(item.daysLeft)}>
                  {item.daysLeft <= 3 && <AlertCircle className="w-3 h-3 inline mr-1" />}
                  {item.daysLeft} days left
                </span>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
          </div>
        ))}
      </div>

      <button className="w-full mt-4 text-sm text-primary hover:text-primary/80 font-medium transition-colors">
        View all deadlines →
      </button>
    </div>
  );
}
