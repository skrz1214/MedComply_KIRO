import { useNavigate } from 'react-router-dom';
import { Link2, MessageSquare, AlertTriangle, ClipboardCheck, Shield } from 'lucide-react';

interface MicroApp {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  route: string;
}

const microApps: MicroApp[] = [
  {
    id: 'compliance-connect',
    name: 'ComplianceConnect',
    description: 'Compliance management hub',
    icon: Link2,
    color: 'text-primary',
    bgColor: 'bg-primary/10',
    route: '/compliance-connect',
  },
  {
    id: 'feedback-hub',
    name: 'FeedbackHub',
    description: 'Stakeholder feedback system',
    icon: MessageSquare,
    color: 'text-info',
    bgColor: 'bg-info/10',
    route: '/feedback-hub',
  },
  {
    id: 'risk-guard',
    name: 'RiskGuard',
    description: 'Risk assessment platform',
    icon: AlertTriangle,
    color: 'text-warning',
    bgColor: 'bg-warning/10',
    route: '/risk-guard',
  },
  {
    id: 'audit-pro',
    name: 'AuditPro',
    description: 'Audit management system',
    icon: ClipboardCheck,
    color: 'text-foreground',
    bgColor: 'bg-muted',
    route: '/audit-pro',
  },
  {
    id: 'enforce-point',
    name: 'EnforcePoint',
    description: 'Enforcement tracking',
    icon: Shield,
    color: 'text-destructive',
    bgColor: 'bg-destructive/10',
    route: '/enforce-point',
  },
];

export function MicroApps() {
  const navigate = useNavigate();

  return (
    <div className="animate-fade-in" style={{ animationDelay: '0.3s' }}>
      <h2 className="text-lg font-semibold text-foreground mb-4">Quick Access</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {microApps.map((app) => {
          const Icon = app.icon;
          return (
            <button
              key={app.id}
              onClick={() => navigate(app.route)}
              className="micro-app-card text-left"
            >
              <div className={`w-10 h-10 rounded-lg ${app.bgColor} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                <Icon className={`w-5 h-5 ${app.color}`} />
              </div>
              <h3 className="text-sm font-semibold text-foreground mb-1">{app.name}</h3>
              <p className="text-xs text-muted-foreground">{app.description}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
}
