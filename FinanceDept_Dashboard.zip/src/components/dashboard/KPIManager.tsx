import { useState } from 'react';
import { Plus, TrendingUp, TrendingDown, FileText, Pencil, Trash2, MoreVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';

export interface KPIItem {
  id: string;
  label: string;
  value: number;
  target: number;
  numerator: string;
  denominator: string;
  multiplier: string;
  formulaDescription: string;
  trend: 'up' | 'down';
  color: string;
  unit: string;
}

const initialKPIs: KPIItem[] = [
  {
    id: 'content-compliance',
    label: 'Content Compliance Rate',
    value: 94,
    target: 95,
    numerator: 'Compliant Content',
    denominator: 'Total Content Reviewed',
    multiplier: '100',
    formulaDescription: 'Measures the percentage of content that meets compliance standards',
    trend: 'up',
    color: 'bg-success',
    unit: '%',
  },
  {
    id: 'approval-rate',
    label: 'Campaign Approval Rate',
    value: 88,
    target: 90,
    numerator: 'First-Time Approvals',
    denominator: 'Total Submissions',
    multiplier: '100',
    formulaDescription: 'Tracks the rate of campaigns approved on first submission',
    trend: 'up',
    color: 'bg-warning',
    unit: '%',
  },
  {
    id: 'disclosure-compliance',
    label: 'Disclosure Compliance Rate',
    value: 97,
    target: 100,
    numerator: 'Content with Proper Disclosures',
    denominator: 'Content Requiring Disclosures',
    multiplier: '100',
    formulaDescription: 'Monitors proper disclosure inclusion in regulated content',
    trend: 'up',
    color: 'bg-primary',
    unit: '%',
  },
  {
    id: 'violation-rate',
    label: 'Regulatory Violation Rate',
    value: 2,
    target: 0,
    numerator: 'Violations Found',
    denominator: 'Total Content Audited',
    multiplier: '100',
    formulaDescription: 'Tracks the percentage of audited content with violations',
    trend: 'down',
    color: 'bg-destructive',
    unit: '%',
  },
];

const getFormulaDisplay = (kpi: KPIItem) => {
  if (kpi.multiplier && kpi.multiplier !== '1') {
    return `(${kpi.numerator} / ${kpi.denominator}) × ${kpi.multiplier}`;
  }
  return `${kpi.numerator} / ${kpi.denominator}`;
};

const colorOptions = [
  { value: 'bg-success', label: 'Green' },
  { value: 'bg-warning', label: 'Yellow' },
  { value: 'bg-primary', label: 'Blue' },
  { value: 'bg-destructive', label: 'Red' },
  { value: 'bg-secondary', label: 'Gray' },
];

interface KPIFormData {
  label: string;
  value: string;
  target: string;
  numerator: string;
  denominator: string;
  multiplier: string;
  formulaDescription: string;
  trend: 'up' | 'down';
  color: string;
  unit: string;
}

const emptyFormData: KPIFormData = {
  label: '',
  value: '',
  target: '',
  numerator: '',
  denominator: '',
  multiplier: '100',
  formulaDescription: '',
  trend: 'up',
  color: 'bg-primary',
  unit: '%',
};

export function KPIManager() {
  const [kpis, setKpis] = useState<KPIItem[]>(initialKPIs);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedKPI, setSelectedKPI] = useState<KPIItem | null>(null);
  const [formData, setFormData] = useState<KPIFormData>(emptyFormData);
  const { toast } = useToast();

  const resetForm = () => {
    setFormData(emptyFormData);
    setSelectedKPI(null);
  };

  const handleAddClick = () => {
    resetForm();
    setIsAddDialogOpen(true);
  };

  const handleEditClick = (kpi: KPIItem) => {
    setSelectedKPI(kpi);
    setFormData({
      label: kpi.label,
      value: kpi.value.toString(),
      target: kpi.target.toString(),
      numerator: kpi.numerator,
      denominator: kpi.denominator,
      multiplier: kpi.multiplier,
      formulaDescription: kpi.formulaDescription,
      trend: kpi.trend,
      color: kpi.color,
      unit: kpi.unit,
    });
    setIsEditDialogOpen(true);
  };

  const handleDeleteClick = (kpi: KPIItem) => {
    setSelectedKPI(kpi);
    setIsDeleteDialogOpen(true);
  };

  const handleAddSubmit = () => {
    if (!formData.label || !formData.value || !formData.target || !formData.numerator || !formData.denominator) {
      toast({
        title: 'Validation Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    const newKPI: KPIItem = {
      id: `kpi-${Date.now()}`,
      label: formData.label,
      value: parseFloat(formData.value),
      target: parseFloat(formData.target),
      numerator: formData.numerator,
      denominator: formData.denominator,
      multiplier: formData.multiplier || '1',
      formulaDescription: formData.formulaDescription,
      trend: formData.trend,
      color: formData.color,
      unit: formData.unit,
    };

    setKpis([...kpis, newKPI]);
    setIsAddDialogOpen(false);
    resetForm();
    toast({
      title: 'KPI Added',
      description: `${newKPI.label} has been added successfully`,
    });
  };

  const handleEditSubmit = () => {
    if (!selectedKPI) return;

    if (!formData.label || !formData.value || !formData.target || !formData.numerator || !formData.denominator) {
      toast({
        title: 'Validation Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    const updatedKPIs = kpis.map((kpi) =>
      kpi.id === selectedKPI.id
        ? {
            ...kpi,
            label: formData.label,
            value: parseFloat(formData.value),
            target: parseFloat(formData.target),
            numerator: formData.numerator,
            denominator: formData.denominator,
            multiplier: formData.multiplier || '1',
            formulaDescription: formData.formulaDescription,
            trend: formData.trend,
            color: formData.color,
            unit: formData.unit,
          }
        : kpi
    );

    setKpis(updatedKPIs);
    setIsEditDialogOpen(false);
    resetForm();
    toast({
      title: 'KPI Updated',
      description: `${formData.label} has been updated successfully`,
    });
  };

  const handleDeleteConfirm = () => {
    if (!selectedKPI) return;

    setKpis(kpis.filter((kpi) => kpi.id !== selectedKPI.id));
    setIsDeleteDialogOpen(false);
    toast({
      title: 'KPI Deleted',
      description: `${selectedKPI.label} has been deleted`,
    });
    resetForm();
  };

  const KPIFormFields = () => (
    <div className="grid gap-4 py-4">
      <div className="grid gap-2">
        <Label htmlFor="label">KPI Name *</Label>
        <Input
          id="label"
          value={formData.label}
          onChange={(e) => setFormData({ ...formData, label: e.target.value })}
          placeholder="e.g., Content Compliance Rate"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="grid gap-2">
          <Label htmlFor="value">Current Value *</Label>
          <Input
            id="value"
            type="number"
            value={formData.value}
            onChange={(e) => setFormData({ ...formData, value: e.target.value })}
            placeholder="e.g., 94"
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="target">Target Value *</Label>
          <Input
            id="target"
            type="number"
            value={formData.target}
            onChange={(e) => setFormData({ ...formData, target: e.target.value })}
            placeholder="e.g., 95"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="grid gap-2">
          <Label htmlFor="unit">Unit</Label>
          <Input
            id="unit"
            value={formData.unit}
            onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
            placeholder="e.g., %, $, days"
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="trend">Trend</Label>
          <Select
            value={formData.trend}
            onValueChange={(value: 'up' | 'down') => setFormData({ ...formData, trend: value })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="up">Trending Up</SelectItem>
              <SelectItem value="down">Trending Down</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid gap-2">
        <Label htmlFor="color">Color</Label>
        <Select
          value={formData.color}
          onValueChange={(value) => setFormData({ ...formData, color: value })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {colorOptions.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                <div className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full ${option.value}`} />
                  {option.label}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-2">
        <Label>Formula *</Label>
        <div className="space-y-3">
          <div className="grid gap-2">
            <Label htmlFor="numerator" className="text-xs text-muted-foreground">Numerator</Label>
            <Input
              id="numerator"
              value={formData.numerator}
              onChange={(e) => setFormData({ ...formData, numerator: e.target.value })}
              placeholder="e.g., Compliant Content"
            />
          </div>
          <div className="flex items-center justify-center">
            <div className="w-full h-px bg-border" />
            <span className="px-2 text-muted-foreground text-sm">÷</span>
            <div className="w-full h-px bg-border" />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="denominator" className="text-xs text-muted-foreground">Denominator</Label>
            <Input
              id="denominator"
              value={formData.denominator}
              onChange={(e) => setFormData({ ...formData, denominator: e.target.value })}
              placeholder="e.g., Total Content Reviewed"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="multiplier" className="text-xs text-muted-foreground">Multiplier (optional)</Label>
            <Input
              id="multiplier"
              value={formData.multiplier}
              onChange={(e) => setFormData({ ...formData, multiplier: e.target.value })}
              placeholder="e.g., 100 for percentage"
            />
          </div>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          Formula: ({formData.numerator || 'Numerator'} / {formData.denominator || 'Denominator'}){formData.multiplier && formData.multiplier !== '1' ? ` × ${formData.multiplier}` : ''}
        </p>
      </div>

      <div className="grid gap-2">
        <Label htmlFor="formulaDescription">Formula Description</Label>
        <Textarea
          id="formulaDescription"
          value={formData.formulaDescription}
          onChange={(e) => setFormData({ ...formData, formulaDescription: e.target.value })}
          placeholder="Describe what this formula measures and how it should be interpreted..."
          rows={3}
        />
      </div>
    </div>
  );

  return (
    <div className="bg-card rounded-xl border border-border p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-foreground">Quality KPIs</h3>
        <Button
          variant="ghost"
          size="icon"
          className="w-6 h-6 rounded-full"
          onClick={handleAddClick}
        >
          <Plus className="w-4 h-4" />
        </Button>
      </div>

      <div className="space-y-5">
        {kpis.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No KPIs defined yet</p>
            <Button variant="link" size="sm" onClick={handleAddClick}>
              Add your first KPI
            </Button>
          </div>
        ) : (
          kpis.map((kpi) => (
            <div key={kpi.id} className="group">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-foreground">{kpi.label}</span>
                <div className="flex items-center gap-1">
                  {kpi.trend === 'up' ? (
                    <TrendingUp className="w-4 h-4 text-success" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-destructive" />
                  )}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleEditClick(kpi)}>
                        <Pencil className="w-4 h-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => handleDeleteClick(kpi)}
                        className="text-destructive focus:text-destructive"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
              <div className="flex items-baseline gap-2 mb-2">
                <span className="text-2xl font-bold text-foreground">{kpi.value}</span>
                <span className="text-lg text-muted-foreground">{kpi.unit}</span>
                <span className="text-xs text-muted-foreground ml-auto">
                  Target: {kpi.target}
                  {kpi.unit}
                </span>
              </div>
              <div className="progress-indicator mb-1">
                <div
                  className={`h-full rounded-full ${kpi.color}`}
                  style={{ width: `${Math.min((kpi.value / kpi.target) * 100, 100)}%` }}
                />
              </div>
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <FileText className="w-3 h-3 shrink-0" />
                <span className="truncate">{getFormulaDisplay(kpi)}</span>
              </p>
            </div>
          ))
        )}
      </div>

      {/* Add KPI Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add New KPI</DialogTitle>
            <DialogDescription>
              Define a new Key Performance Indicator with its calculation formula.
            </DialogDescription>
          </DialogHeader>
          <KPIFormFields />
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddSubmit}>Add KPI</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit KPI Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit KPI</DialogTitle>
            <DialogDescription>
              Update the KPI details and calculation formula.
            </DialogDescription>
          </DialogHeader>
          <KPIFormFields />
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleEditSubmit}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete KPI</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{selectedKPI?.label}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
