import { FileText, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface MetricTile {
  id: string;
  label: string;
  value: number;
  icon: React.ElementType;
  variant: 'default' | 'success' | 'warning' | 'danger';
}

const metrics: MetricTile[] = [
  { id: 'total', label: 'Total Audits', value: 48, icon: FileText, variant: 'default' },
  { id: 'pending', label: 'Pending Review', value: 12, icon: Clock, variant: 'warning' },
  { id: 'completed', label: 'Completed', value: 32, icon: CheckCircle, variant: 'success' },
  { id: 'overdue', label: 'Overdue', value: 4, icon: AlertTriangle, variant: 'danger' },
];

interface MetricTilesProps {
  onFilterClick?: (filterId: string) => void;
  activeFilter?: string;
}

export function MetricTiles({ onFilterClick, activeFilter }: MetricTilesProps) {
  const getVariantStyles = (variant: MetricTile['variant']) => {
    switch (variant) {
      case 'success':
        return 'hover:border-success/50 hover:bg-success/5';
      case 'warning':
        return 'hover:border-warning/50 hover:bg-warning/5';
      case 'danger':
        return 'hover:border-destructive/50 hover:bg-destructive/5';
      default:
        return 'hover:border-primary/50 hover:bg-primary/5';
    }
  };

  const getIconColor = (variant: MetricTile['variant']) => {
    switch (variant) {
      case 'success':
        return 'text-success';
      case 'warning':
        return 'text-warning';
      case 'danger':
        return 'text-destructive';
      default:
        return 'text-muted-foreground';
    }
  };

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 animate-fade-in">
      {metrics.map((metric) => {
        const Icon = metric.icon;
        const isActive = activeFilter === metric.id;
        return (
          <button
            key={metric.id}
            onClick={() => onFilterClick?.(metric.id)}
            className={cn(
              'metric-tile flex-col items-start text-left',
              getVariantStyles(metric.variant),
              isActive && 'border-primary bg-primary/5'
            )}
          >
            <div className="flex items-center justify-between w-full mb-2">
              <Icon className={cn('w-5 h-5', getIconColor(metric.variant))} />
              <span className="text-2xl font-bold text-foreground">{metric.value}</span>
            </div>
            <span className="text-sm text-muted-foreground">{metric.label}</span>
          </button>
        );
      })}
    </div>
  );
}
