import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, ChevronRight, Clock, User, Link2, MessageSquare, AlertTriangle, ClipboardCheck, Shield, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';

interface ActionItem {
  id: string;
  title: string;
  dueDate: string;
  owner: string;
  priority: 'High' | 'Med' | 'Low';
  status: 'Not started' | 'In progress' | 'Completed';
  assignedTo: string;
}

interface MicroApp {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  route: string;
}

const microApps: MicroApp[] = [
  {
    id: 'compliance-connect',
    name: 'ComplianceConnect',
    description: 'Compliance management hub',
    icon: Link2,
    color: 'text-primary',
    bgColor: 'bg-primary/10',
    route: '/complianceconnect',
  },
  {
    id: 'feedback-hub',
    name: 'FeedbackHub',
    description: 'Stakeholder feedback system',
    icon: MessageSquare,
    color: 'text-info',
    bgColor: 'bg-info/10',
    route: '/feedbackhub',
  },
  {
    id: 'risk-guard',
    name: 'RiskGuard',
    description: 'Risk assessment platform',
    icon: AlertTriangle,
    color: 'text-warning',
    bgColor: 'bg-warning/10',
    route: '/riskguard',
  },
  {
    id: 'audit-pro',
    name: 'AuditPro',
    description: 'Audit management system',
    icon: ClipboardCheck,
    color: 'text-foreground',
    bgColor: 'bg-muted',
    route: '/auditpro',
  },
  {
    id: 'enforce-point',
    name: 'EnforcePoint',
    description: 'Enforcement tracking',
    icon: Shield,
    color: 'text-destructive',
    bgColor: 'bg-destructive/10',
    route: '/enforcepoint',
  },
  {
    id: 'cita-pro',
    name: 'CitaPro',
    description: 'Citation management',
    icon: Calendar,
    color: 'text-success',
    bgColor: 'bg-success/10',
    route: '/citapro',
  },
];

const allActionItems: ActionItem[] = [
  {
    id: '1',
    title: 'Review compliance documentation for Q2 2025',
    dueDate: 'Due Today',
    owner: 'Me',
    priority: 'High',
    status: 'Not started',
    assignedTo: 'Sarah Chen',
  },
  {
    id: '2',
    title: 'Update risk assessment report',
    dueDate: 'Due Tomorrow',
    owner: 'Me',
    priority: 'Med',
    status: 'In progress',
    assignedTo: 'Sarah Chen',
  },
  {
    id: '3',
    title: 'Audit internal billing procedures',
    dueDate: 'Due in 3 days',
    owner: 'Michael Torres',
    priority: 'Med',
    status: 'Not started',
    assignedTo: 'Michael Torres',
  },
  {
    id: '4',
    title: 'Review Q1 financial statements compliance',
    dueDate: 'Due in 5 days',
    owner: 'Jennifer Adams',
    priority: 'Low',
    status: 'Not started',
    assignedTo: 'Jennifer Adams',
  },
  {
    id: '5',
    title: 'Submit quarterly enforcement report',
    dueDate: 'Due in 7 days',
    owner: 'David Kim',
    priority: 'High',
    status: 'In progress',
    assignedTo: 'David Kim',
  },
];

export function ActionCenter() {
  const [filter, setFilter] = useState<'me' | 'all'>('me');
  const [typeFilter, setTypeFilter] = useState('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const navigate = useNavigate();
  const { user, viewMode } = useAuth();

  // Filter items based on view mode
  const actionItems = viewMode === 'individual' 
    ? allActionItems.filter(item => item.assignedTo === user?.name)
    : allActionItems;

  const completedToday = actionItems.filter(i => i.status === 'Completed').length;
  const totalToday = actionItems.filter(i => i.dueDate === 'Due Today').length || 2;
  const thisWeek = actionItems.filter(i => i.dueDate.includes('days')).length;
  const overdue = 2;

  const handleMicroAppClick = (route: string) => {
    setIsAddDialogOpen(false);
    navigate(route);
  };

  return (
    <div className="bg-card rounded-xl border border-border p-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <h2 className="text-lg font-semibold text-foreground">Action Center</h2>
          <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-medium flex items-center justify-center">
            {actionItems.length}
          </span>
          {viewMode === 'individual' && (
            <Badge variant="outline" className="text-xs bg-info/10 text-info border-info/30">
              My Items Only
            </Badge>
          )}
        </div>
        <Button size="sm" className="gap-2" onClick={() => setIsAddDialogOpen(true)}>
          <Plus className="w-4 h-4" />
          Add Action Item
        </Button>
      </div>

      <p className="text-sm text-muted-foreground mb-4">
        {viewMode === 'department' ? 'Executive compliance tasks' : 'Your assigned tasks'}
      </p>

      {/* Progress Bar */}
      <div className="mb-4">
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-muted-foreground">Today's Progress</span>
          <div className="flex items-center gap-2">
            <span className="text-foreground">{completedToday} of {totalToday} completed</span>
            <button className="text-muted-foreground hover:text-foreground">
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M1 4v6h6M23 20v-6h-6M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15" />
              </svg>
            </button>
          </div>
        </div>
        <div className="progress-indicator">
          <div
            className="progress-fill"
            style={{ width: `${(completedToday / totalToday) * 100}%` }}
          />
        </div>
      </div>

      {/* Stats Row */}
      <div className="flex items-center gap-4 text-sm mb-4">
        <span className="text-foreground font-medium">Today {totalToday}</span>
        <span className="text-muted-foreground">This Week {thisWeek}</span>
        <span className="text-destructive font-medium">Overdue {overdue}</span>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 mb-4">
        {viewMode === 'department' && (
          <div className="flex rounded-lg bg-secondary p-1">
            <button
              onClick={() => setFilter('me')}
              className={cn(
                'px-3 py-1.5 text-sm rounded-md transition-all',
                filter === 'me' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
              )}
            >
              Me
            </button>
            <button
              onClick={() => setFilter('all')}
              className={cn(
                'px-3 py-1.5 text-sm rounded-md transition-all',
                filter === 'all' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
              )}
            >
              All
            </button>
          </div>
        )}
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="h-9 px-3 rounded-lg bg-secondary border-0 text-sm text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
        >
          <option value="all">All Types</option>
          <option value="audit">Audit</option>
          <option value="compliance">Compliance</option>
          <option value="risk">Risk</option>
        </select>
        <input
          type="text"
          placeholder="Search tasks"
          className="h-9 px-3 rounded-lg bg-secondary border-0 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary flex-1"
        />
      </div>

      {/* Action Items */}
      <div className="space-y-3">
        {actionItems.slice(0, viewMode === 'individual' ? 4 : 2).map((item) => (
          <div
            key={item.id}
            className="action-card flex items-center justify-between group"
          >
            <div className="flex-1">
              <h3 className="text-sm font-medium text-foreground mb-1">{item.title}</h3>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {item.dueDate}
                </span>
                <span className="flex items-center gap-1">
                  <User className="w-3 h-3" />
                  {viewMode === 'department' ? item.assignedTo : 'Me'}
                </span>
                <Badge variant={item.priority === 'High' ? 'high' : item.priority === 'Med' ? 'medium' : 'low'}>
                  {item.priority}
                </Badge>
                <span className={cn(
                  'text-xs',
                  item.status === 'In progress' ? 'text-info' : 'text-muted-foreground'
                )}>
                  {item.status}
                </span>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        ))}
      </div>

      {/* Add Action Item Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Add Action Item</DialogTitle>
            <DialogDescription>
              Select a microapp to create a new action item
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 py-4">
            {microApps.map((app) => {
              const Icon = app.icon;
              return (
                <button
                  key={app.id}
                  onClick={() => handleMicroAppClick(app.route)}
                  className="flex flex-col items-center p-4 rounded-xl border border-border bg-card hover:bg-accent hover:border-primary/50 transition-all group text-center"
                >
                  <div className={`w-12 h-12 rounded-xl ${app.bgColor} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                    <Icon className={`w-6 h-6 ${app.color}`} />
                  </div>
                  <h3 className="text-sm font-semibold text-foreground mb-1">{app.name}</h3>
                  <p className="text-xs text-muted-foreground">{app.description}</p>
                </button>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
