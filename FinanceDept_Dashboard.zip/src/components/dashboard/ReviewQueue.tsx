import { FileText, ChevronRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';

interface ReviewItem {
  id: string;
  title: string;
  type: 'Policy' | 'Audit' | 'Training' | 'Compliance';
  owner: string;
  date: string;
  status: 'Pending Review' | 'In Progress' | 'Approved';
  assignedTo: string;
}

const allReviewItems: ReviewItem[] = [
  {
    id: '1',
    title: 'New policy draft – Patient Data Protection',
    type: 'Policy',
    owner: 'Sarah Johnson',
    date: 'Dec 10, 2024',
    status: 'Pending Review',
    assignedTo: 'Sarah Chen',
  },
  {
    id: '2',
    title: 'Quarterly Audit Results',
    type: 'Audit',
    owner: 'Michael Chen',
    date: 'Dec 9, 2024',
    status: 'In Progress',
    assignedTo: 'Michael Torres',
  },
  {
    id: '3',
    title: 'Staff Training Compliance Report',
    type: 'Training',
    owner: 'Emily Davis',
    date: 'Dec 8, 2024',
    status: 'Pending Review',
    assignedTo: 'Sarah Chen',
  },
  {
    id: '4',
    title: 'Annual Billing Compliance Assessment',
    type: 'Compliance',
    owner: 'Robert Wilson',
    date: 'Dec 7, 2024',
    status: 'Pending Review',
    assignedTo: 'Jennifer Adams',
  },
];

export function ReviewQueue() {
  const { user, viewMode } = useAuth();

  // Filter items based on view mode
  const reviewItems = viewMode === 'individual'
    ? allReviewItems.filter(item => item.assignedTo === user?.name)
    : allReviewItems;

  return (
    <div className="bg-card rounded-xl border border-border p-6 animate-fade-in" style={{ animationDelay: '0.1s' }}>
      {/* Header */}
      <div className="flex items-center gap-3 mb-2">
        <h2 className="text-lg font-semibold text-foreground">Review Queue</h2>
        <span className="w-6 h-6 rounded-full bg-warning text-warning-foreground text-xs font-medium flex items-center justify-center">
          {reviewItems.length}
        </span>
        {viewMode === 'individual' && (
          <Badge variant="outline" className="text-xs bg-info/10 text-info border-info/30">
            My Reviews Only
          </Badge>
        )}
      </div>

      <p className="text-sm text-muted-foreground mb-4">
        {viewMode === 'department' ? 'Pending reviews & sign-offs' : 'Your pending reviews'}
      </p>

      {/* Review Items */}
      <div className="space-y-3">
        {reviewItems.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No reviews assigned to you</p>
          </div>
        ) : (
          reviewItems.map((item) => (
            <div
              key={item.id}
              className="action-card flex items-start gap-3 group"
            >
              <div className="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center shrink-0">
                <FileText className="w-5 h-5 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-medium text-foreground mb-1 truncate">{item.title}</h3>
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge
                    variant={
                      item.type === 'Policy' ? 'policy' :
                      item.type === 'Audit' ? 'audit' :
                      item.type === 'Training' ? 'training' : 'default'
                    }
                  >
                    {item.type}
                  </Badge>
                  <span className="text-xs text-muted-foreground">👤 {item.owner}</span>
                  <span className="text-xs text-muted-foreground">📅 {item.date}</span>
                  <Badge
                    variant={
                      item.status === 'In Progress' ? 'in-progress' :
                      item.status === 'Pending Review' ? 'pending' : 'completed'
                    }
                  >
                    {item.status}
                  </Badge>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
            </div>
          ))
        )}
      </div>
    </div>
  );
}
