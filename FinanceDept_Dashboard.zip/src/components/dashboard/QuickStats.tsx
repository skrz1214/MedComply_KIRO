import { FileText, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import { KPIManager } from './KPIManager';
import { useAuth } from '@/contexts/AuthContext';

interface StatItem {
  id: string;
  label: string;
  departmentValue: number;
  individualValue: number;
  change: number;
  icon: React.ElementType;
  iconColor: string;
}

const stats: StatItem[] = [
  { id: 'total', label: 'Total', departmentValue: 42, individualValue: 8, change: 3, icon: FileText, iconColor: 'text-muted-foreground' },
  { id: 'completed', label: 'Completed', departmentValue: 25, individualValue: 5, change: 5, icon: CheckCircle, iconColor: 'text-success' },
  { id: 'pending', label: 'Pending', departmentValue: 13, individualValue: 2, change: -2, icon: Clock, iconColor: 'text-warning' },
  { id: 'overdue', label: 'Overdue', departmentValue: 4, individualValue: 1, change: 1, icon: AlertTriangle, iconColor: 'text-destructive' },
];

export function QuickStats() {
  const { viewMode } = useAuth();

  return (
    <div className="space-y-6 animate-fade-in" style={{ animationDelay: '0.2s' }}>
      {/* Quick Stats */}
      <div className="bg-card rounded-xl border border-border p-5">
        <h3 className="text-sm font-semibold text-foreground mb-4">
          Quick Stats {viewMode === 'individual' && <span className="text-muted-foreground font-normal">(Your Items)</span>}
        </h3>
        <div className="space-y-4">
          {stats.map((stat) => {
            const Icon = stat.icon;
            const value = viewMode === 'individual' ? stat.individualValue : stat.departmentValue;
            return (
              <div key={stat.id} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${stat.iconColor}`} />
                  <span className="text-sm text-muted-foreground">{stat.label}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-semibold text-foreground">{value}</span>
                  <span className={`text-xs font-medium ${stat.change > 0 ? 'text-success' : 'text-destructive'}`}>
                    {stat.change > 0 ? '+' : ''}{stat.change}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Quality KPIs with CRUD */}
      <KPIManager />
    </div>
  );
}
