import { useNavigate, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  Users,
  AlertTriangle,
  ClipboardCheck,
  CheckSquare,
  MessageSquare,
  Shield,
  Settings,
  DollarSign,
  FileText,
} from 'lucide-react';

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  href: string;
  children?: NavItem[];
}

const financeNavItems: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, href: '/' },
  { id: 'org-chart', label: 'Org Chart', icon: Users, href: '/org-chart' },
  { id: 'risk', label: 'Risk Management', icon: AlertTriangle, href: '/finance/risks' },
  { id: 'audit', label: 'Audit Management', icon: ClipboardCheck, href: '/finance/audits' },
  { id: 'compliance', label: 'Compliance Tracking', icon: CheckSquare, href: '/finance/compliance' },
  { id: 'feedback', label: 'Feedback Management', icon: MessageSquare, href: '/finance/feedback' },
  { id: 'enforcement', label: 'Enforcement Management', icon: Shield, href: '/finance/enforcements' },
  { id: 'documentation', label: 'Documentation', icon: FileText, href: '/documentation' },
];

interface SidebarProps {
  activeItem?: string;
  onNavigate?: (id: string) => void;
}

export function Sidebar({ activeItem, onNavigate }: SidebarProps) {
  const navigate = useNavigate();
  const location = useLocation();

  const handleNavClick = (item: NavItem) => {
    if (item.href.startsWith('#')) {
      const element = document.getElementById(item.href.slice(1));
      element?.scrollIntoView({ behavior: 'smooth' });
    } else {
      navigate(item.href);
    }
    onNavigate?.(item.id);
  };

  const isActive = (item: NavItem) => {
    if (activeItem) return activeItem === item.id;
    if (item.children) {
      return location.pathname === item.href || item.children.some(child => location.pathname === child.href);
    }
    return location.pathname === item.href;
  };

  const isChildActive = (item: NavItem) => {
    return location.pathname === item.href || activeItem === item.id;
  };

  return (
    <aside className="w-64 bg-sidebar flex flex-col h-screen fixed left-0 top-0 z-40">
      {/* Logo */}
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
            <DollarSign className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-sidebar-foreground font-semibold text-sm">FinanceHub</h1>
            <p className="text-sidebar-muted text-xs">Finance Division</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto scrollbar-thin py-4 px-3">
        {/* Finance Dashboard Section */}
        <div className="mb-6">
          <p className="text-sidebar-muted text-xs font-medium uppercase tracking-wider px-3 mb-2">
            Finance Dashboard
          </p>
          <ul className="space-y-1">
            {financeNavItems.map((item) => {
              const Icon = item.icon;
              const active = isActive(item);
              return (
                <li key={item.id}>
                  <button
                    onClick={() => handleNavClick(item)}
                    className={cn('nav-item w-full', active && 'nav-item-active')}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="text-sm">{item.label}</span>
                  </button>
                  {item.children && (
                    <ul className="ml-6 mt-1 space-y-1 border-l border-sidebar-border pl-2">
                      {item.children.map((child) => {
                        const ChildIcon = child.icon;
                        const childActive = isChildActive(child);
                        return (
                          <li key={child.id}>
                            <button
                              onClick={() => handleNavClick(child)}
                              className={cn('nav-item w-full text-xs', childActive && 'nav-item-active')}
                            >
                              <ChildIcon className="w-3.5 h-3.5" />
                              <span>{child.label}</span>
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </li>
              );
            })}
          </ul>
        </div>
      </nav>

      {/* Settings Footer */}
      <div className="p-3 border-t border-sidebar-border">
        <button className="nav-item w-full">
          <Settings className="w-4 h-4" />
          <span className="text-sm">Settings</span>
        </button>
      </div>
    </aside>
  );
}
