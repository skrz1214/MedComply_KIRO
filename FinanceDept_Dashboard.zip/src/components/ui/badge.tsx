import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
        secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
        destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
        outline: "text-foreground",
        success: "border-success/30 bg-success/15 text-success",
        warning: "border-warning/30 bg-warning/15 text-warning",
        info: "border-info/30 bg-info/15 text-info",
        high: "border-destructive/30 bg-destructive/15 text-destructive",
        medium: "border-warning/30 bg-warning/15 text-warning",
        low: "border-success/30 bg-success/15 text-success",
        pending: "border-warning/30 bg-warning/15 text-warning",
        completed: "border-success/30 bg-success/15 text-success",
        overdue: "border-destructive/30 bg-destructive/15 text-destructive",
        "in-progress": "border-info/30 bg-info/15 text-info",
        policy: "border-primary/30 bg-primary/15 text-primary",
        audit: "border-info/30 bg-info/15 text-info",
        training: "border-success/30 bg-success/15 text-success",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
