import { useAuth, ViewMode, UserRole } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  User, 
  LogOut, 
  Building2, 
  UserCircle,
  Shield,
  Users,
  Briefcase,
  ChevronDown,
} from 'lucide-react';

export function UserMenu() {
  const { user, viewMode, setViewMode, canToggleView, logout, impersonateAs } = useAuth();

  if (!user) return null;

  const getRoleBadge = (role: UserRole) => {
    const roleConfig: Record<UserRole, { label: string; variant: string; icon: React.ElementType }> = {
      admin: { label: 'Admin', variant: 'bg-destructive text-destructive-foreground', icon: Shield },
      department_head: { label: 'Dept Head', variant: 'bg-primary text-primary-foreground', icon: Briefcase },
      staff: { label: 'Staff', variant: 'bg-secondary text-secondary-foreground', icon: Users },
    };
    
    const config = roleConfig[role];
    const Icon = config.icon;
    
    return (
      <Badge className={config.variant}>
        <Icon className="w-3 h-3 mr-1" />
        {config.label}
      </Badge>
    );
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="flex items-center gap-3">
      {/* View Mode Toggle */}
      {canToggleView && (
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-muted/50 border border-border">
          <Building2 className={`w-4 h-4 ${viewMode === 'department' ? 'text-primary' : 'text-muted-foreground'}`} />
          <Switch
            id="view-mode"
            checked={viewMode === 'individual'}
            onCheckedChange={(checked) => setViewMode(checked ? 'individual' : 'department')}
          />
          <UserCircle className={`w-4 h-4 ${viewMode === 'individual' ? 'text-primary' : 'text-muted-foreground'}`} />
          <Label htmlFor="view-mode" className="text-xs text-muted-foreground cursor-pointer">
            {viewMode === 'department' ? 'Department' : 'Individual'}
          </Label>
        </div>
      )}

      {/* User Dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="gap-2 px-2">
            <Avatar className="w-8 h-8">
              <AvatarFallback className="text-xs">{getInitials(user.name)}</AvatarFallback>
            </Avatar>
            <div className="flex flex-col items-start text-left">
              <span className="text-sm font-medium">{user.name}</span>
              <span className="text-xs text-muted-foreground">{user.department}</span>
            </div>
            <ChevronDown className="w-4 h-4 text-muted-foreground" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-64">
          <DropdownMenuLabel className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>Account</span>
            </div>
            {getRoleBadge(user.role)}
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          
          <div className="px-2 py-1.5">
            <p className="text-sm font-medium">{user.name}</p>
            <p className="text-xs text-muted-foreground">{user.email}</p>
          </div>
          
          <DropdownMenuSeparator />

          {/* Impersonation for Admin */}
          {user.role === 'admin' && (
            <>
              <DropdownMenuLabel className="text-xs text-muted-foreground">
                Impersonate Role
              </DropdownMenuLabel>
              <DropdownMenuItem onClick={() => impersonateAs('admin')}>
                <Shield className="w-4 h-4 mr-2" />
                Admin / Compliance Head
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => impersonateAs('department_head')}>
                <Briefcase className="w-4 h-4 mr-2" />
                Department Head
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => impersonateAs('staff')}>
                <Users className="w-4 h-4 mr-2" />
                Staff
              </DropdownMenuItem>
              <DropdownMenuSeparator />
            </>
          )}

          {/* View Mode Info */}
          {canToggleView && (
            <>
              <div className="px-2 py-1.5">
                <p className="text-xs text-muted-foreground mb-2">Current View</p>
                <div className="flex items-center gap-2">
                  {viewMode === 'department' ? (
                    <>
                      <Building2 className="w-4 h-4 text-primary" />
                      <span className="text-sm">Department View</span>
                    </>
                  ) : (
                    <>
                      <UserCircle className="w-4 h-4 text-primary" />
                      <span className="text-sm">Individual View</span>
                    </>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {viewMode === 'department' 
                    ? 'Viewing all department items'
                    : 'Viewing only your assigned items'}
                </p>
              </div>
              <DropdownMenuSeparator />
            </>
          )}
          
          <DropdownMenuItem onClick={logout} className="text-destructive">
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
