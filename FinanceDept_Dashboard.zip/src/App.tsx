import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import LoginPage from "./pages/LoginPage";
import ComplianceConnect from "./pages/microapps/ComplianceConnect";
import FeedbackHub from "./pages/microapps/FeedbackHub";
import RiskGuard from "./pages/microapps/RiskGuard";
import AuditPro from "./pages/microapps/AuditPro";
import EnforcePoint from "./pages/microapps/EnforcePoint";
import OrgChart from "./pages/OrgChart";
import FinanceRisks from "./pages/finance/FinanceRisks";
import FinanceAudits from "./pages/finance/FinanceAudits";
import FinanceCompliance from "./pages/finance/FinanceCompliance";
import FinanceFeedback from "./pages/finance/FinanceFeedback";
import FinanceEnforcements from "./pages/finance/FinanceEnforcements";
import Documentation from "./pages/Documentation";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {/* Public Routes */}
            <Route path="/login" element={<LoginPage />} />
            
            {/* Protected Routes */}
            <Route path="/" element={<ProtectedRoute><Index /></ProtectedRoute>} />
            <Route path="/org-chart" element={<ProtectedRoute><OrgChart /></ProtectedRoute>} />
            
            {/* Finance Dashboard Bucket Views */}
            <Route path="/finance/risks" element={<ProtectedRoute><FinanceRisks /></ProtectedRoute>} />
            <Route path="/finance/audits" element={<ProtectedRoute><FinanceAudits /></ProtectedRoute>} />
            <Route path="/finance/compliance" element={<ProtectedRoute><FinanceCompliance /></ProtectedRoute>} />
            <Route path="/finance/feedback" element={<ProtectedRoute><FinanceFeedback /></ProtectedRoute>} />
            <Route path="/finance/enforcements" element={<ProtectedRoute><FinanceEnforcements /></ProtectedRoute>} />
            <Route path="/documentation" element={<ProtectedRoute><Documentation /></ProtectedRoute>} />
            
            {/* Microapps */}
            <Route path="/complianceconnect" element={<ProtectedRoute><ComplianceConnect /></ProtectedRoute>} />
            <Route path="/feedbackhub" element={<ProtectedRoute><FeedbackHub /></ProtectedRoute>} />
            <Route path="/riskguard" element={<ProtectedRoute><RiskGuard /></ProtectedRoute>} />
            <Route path="/auditpro" element={<ProtectedRoute><AuditPro /></ProtectedRoute>} />
            <Route path="/enforcepoint" element={<ProtectedRoute><EnforcePoint /></ProtectedRoute>} />
            
            {/* Legacy routes - redirect compatible */}
            <Route path="/compliance-connect" element={<ProtectedRoute><ComplianceConnect /></ProtectedRoute>} />
            <Route path="/feedback-hub" element={<ProtectedRoute><FeedbackHub /></ProtectedRoute>} />
            <Route path="/risk-guard" element={<ProtectedRoute><RiskGuard /></ProtectedRoute>} />
            <Route path="/audit-pro" element={<ProtectedRoute><AuditPro /></ProtectedRoute>} />
            <Route path="/enforce-point" element={<ProtectedRoute><EnforcePoint /></ProtectedRoute>} />
            
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
