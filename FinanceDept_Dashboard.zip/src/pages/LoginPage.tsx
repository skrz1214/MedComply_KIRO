import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { DollarSign, AlertCircle } from 'lucide-react';

export default function LoginPage() {
  const navigate = useNavigate();
  const { login, isAuthenticated } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Redirect if already authenticated
  if (isAuthenticated) {
    navigate('/');
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    const result = await login(email, password);
    
    if (result.error) {
      setError(result.error);
    } else {
      navigate('/');
    }
    
    setIsLoading(false);
  };

  const handleQuickLogin = async (email: string, password: string) => {
    setEmail(email);
    setPassword(password);
    setError(null);
    setIsLoading(true);

    const result = await login(email, password);
    
    if (result.error) {
      setError(result.error);
    } else {
      navigate('/');
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Logo */}
        <div className="flex flex-col items-center gap-2">
          <div className="w-14 h-14 rounded-xl bg-primary flex items-center justify-center">
            <DollarSign className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">FinanceHub</h1>
          <p className="text-muted-foreground">Finance Compliance Dashboard</p>
        </div>

        {/* Login Form */}
        <Card>
          <CardHeader>
            <CardTitle>Sign In</CardTitle>
            <CardDescription>Enter your credentials to access the dashboard</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="admin@financehub.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? 'Signing in...' : 'Sign In'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Demo Accounts */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Demo Accounts</CardTitle>
            <CardDescription className="text-xs">Click to quick login</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button
              variant="outline"
              className="w-full justify-between text-left"
              onClick={() => handleQuickLogin('admin@financehub.com', 'admin123')}
              disabled={isLoading}
            >
              <div>
                <p className="font-medium">Admin / Compliance Head</p>
                <p className="text-xs text-muted-foreground">Full access + view toggle</p>
              </div>
              <span className="text-xs text-muted-foreground">admin@financehub.com</span>
            </Button>
            
            <Button
              variant="outline"
              className="w-full justify-between text-left"
              onClick={() => handleQuickLogin('head@financehub.com', 'head123')}
              disabled={isLoading}
            >
              <div>
                <p className="font-medium">Department Head</p>
                <p className="text-xs text-muted-foreground">Department access + view toggle</p>
              </div>
              <span className="text-xs text-muted-foreground">head@financehub.com</span>
            </Button>
            
            <Button
              variant="outline"
              className="w-full justify-between text-left"
              onClick={() => handleQuickLogin('staff@financehub.com', 'staff123')}
              disabled={isLoading}
            >
              <div>
                <p className="font-medium">Staff</p>
                <p className="text-xs text-muted-foreground">Individual view only</p>
              </div>
              <span className="text-xs text-muted-foreground">staff@financehub.com</span>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
