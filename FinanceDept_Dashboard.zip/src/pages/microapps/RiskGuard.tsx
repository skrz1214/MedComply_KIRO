import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Plus,
  Search,
  Filter,
  AlertTriangle,
  Edit,
  Trash2,
  Eye,
  ArrowLeft,
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface Risk {
  id: string;
  description: string;
  level: 'High' | 'Medium' | 'Low';
  status: 'Open' | 'In Review' | 'Mitigated' | 'Closed';
  owner: string;
  dueDate: string;
  financeDomain: string[];
  preventiveControls: string;
  detectiveControls: string;
}

const financeDomains = [
  'Billing Compliance',
  'Service Contracts',
  'Internal Reporting',
  'External Reporting',
  'Financial Statements',
  'Accounts Receivable',
  'Budget vs Actual',
  'Balance Sheet',
  'Business Continuity',
  'Financial Hardship',
  'General Finance Governance',
];

const initialRisks: Risk[] = [
  {
    id: 'RSK-001',
    description: 'Revenue cycle billing errors exceeding threshold',
    level: 'High',
    status: 'Open',
    owner: 'Sarah Chen',
    dueDate: '2024-02-15',
    financeDomain: ['Billing Compliance', 'Accounts Receivable'],
    preventiveControls: 'Automated claim scrubbing, staff training',
    detectiveControls: 'Weekly billing audits, variance analysis',
  },
  {
    id: 'RSK-002',
    description: 'Contract renewal compliance gap',
    level: 'Medium',
    status: 'In Review',
    owner: 'Michael Torres',
    dueDate: '2024-02-20',
    financeDomain: ['Service Contracts'],
    preventiveControls: 'Contract management system alerts',
    detectiveControls: 'Monthly contract review meetings',
  },
  {
    id: 'RSK-003',
    description: 'External reporting deadline risk',
    level: 'Low',
    status: 'Mitigated',
    owner: 'Jennifer Adams',
    dueDate: '2024-03-01',
    financeDomain: ['External Reporting'],
    preventiveControls: 'Automated calendar reminders',
    detectiveControls: 'Weekly status tracking',
  },
];

export default function RiskGuard() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const fromFinance = searchParams.get('from') === 'finance-dashboard';
  const mode = searchParams.get('mode');
  const riskId = searchParams.get('id');

  const [risks, setRisks] = useState<Risk[]>(initialRisks);
  const [searchQuery, setSearchQuery] = useState('');
  const [levelFilter, setLevelFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [activeMetric, setActiveMetric] = useState<string | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(mode === 'new' || mode === 'edit');
  const [isDetailOpen, setIsDetailOpen] = useState(mode === 'view');
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [selectedRisk, setSelectedRisk] = useState<Risk | null>(
    riskId ? risks.find(r => r.id === riskId) || null : null
  );
  const [formData, setFormData] = useState<Partial<Risk>>(
    mode === 'edit' && selectedRisk ? selectedRisk : {
      description: '',
      level: 'Medium',
      status: 'Open',
      owner: '',
      dueDate: '',
      financeDomain: [],
      preventiveControls: '',
      detectiveControls: '',
    }
  );

  const breadcrumbs = fromFinance
    ? [
        { label: 'Master Compliance', href: '/master' },
        { label: 'Finance Dashboard', href: '/' },
        { label: 'Risk Management', href: '/finance/risks' },
        { label: 'RiskGuard' },
      ]
    : [
        { label: 'Master Compliance', href: '/master' },
        { label: 'Finance Compliance Dashboard', href: '/' },
        { label: 'RiskGuard' },
      ];

  const metrics = [
    { id: 'total', label: 'Total Risks', value: risks.length, color: 'bg-info' },
    { id: 'pending', label: 'Pending Review', value: risks.filter(r => r.status === 'In Review').length, color: 'bg-warning' },
    { id: 'completed', label: 'Mitigated', value: risks.filter(r => r.status === 'Mitigated' || r.status === 'Closed').length, color: 'bg-success' },
    { id: 'overdue', label: 'Overdue', value: risks.filter(r => new Date(r.dueDate) < new Date() && r.status === 'Open').length, color: 'bg-destructive' },
  ];

  const filteredRisks = risks.filter(risk => {
    const matchesSearch = risk.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      risk.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesLevel = levelFilter === 'all' || risk.level === levelFilter;
    const matchesStatus = statusFilter === 'all' || risk.status === statusFilter;
    const matchesMetric = !activeMetric || 
      (activeMetric === 'total') ||
      (activeMetric === 'pending' && risk.status === 'In Review') ||
      (activeMetric === 'completed' && (risk.status === 'Mitigated' || risk.status === 'Closed')) ||
      (activeMetric === 'overdue' && new Date(risk.dueDate) < new Date() && risk.status === 'Open');
    return matchesSearch && matchesLevel && matchesStatus && matchesMetric;
  });

  const handleAdd = () => {
    setSelectedRisk(null);
    setFormData({
      description: '',
      level: 'Medium',
      status: 'Open',
      owner: '',
      dueDate: '',
      financeDomain: [],
      preventiveControls: '',
      detectiveControls: '',
    });
    setIsDialogOpen(true);
  };

  const handleEdit = (risk: Risk) => {
    setSelectedRisk(risk);
    setFormData(risk);
    setIsDialogOpen(true);
  };

  const handleView = (risk: Risk) => {
    setSelectedRisk(risk);
    setIsDetailOpen(true);
  };

  const handleDelete = (risk: Risk) => {
    setSelectedRisk(risk);
    setIsDeleteOpen(true);
  };

  const confirmDelete = () => {
    if (selectedRisk) {
      setRisks(risks.filter(r => r.id !== selectedRisk.id));
      toast({ title: 'Risk deleted', description: `${selectedRisk.id} has been archived.` });
    }
    setIsDeleteOpen(false);
  };

  const handleSave = () => {
    if (selectedRisk) {
      setRisks(risks.map(r => r.id === selectedRisk.id ? { ...r, ...formData } as Risk : r));
      toast({ title: 'Risk updated', description: 'Changes saved successfully.' });
    } else {
      const newRisk: Risk = {
        id: `RSK-${String(risks.length + 1).padStart(3, '0')}`,
        description: formData.description || '',
        level: (formData.level as Risk['level']) || 'Medium',
        status: (formData.status as Risk['status']) || 'Open',
        owner: formData.owner || '',
        dueDate: formData.dueDate || '',
        financeDomain: formData.financeDomain || [],
        preventiveControls: formData.preventiveControls || '',
        detectiveControls: formData.detectiveControls || '',
      };
      setRisks([...risks, newRisk]);
      toast({ title: 'Risk created', description: `${newRisk.id} has been added.` });
    }
    setIsDialogOpen(false);
    
    // If came from finance dashboard, navigate back after save
    if (fromFinance) {
      navigate('/finance/risks');
    }
  };

  const handleBack = () => {
    if (fromFinance) {
      navigate('/finance/risks');
    } else {
      navigate('/');
    }
  };

  const getLevelBadge = (level: string) => {
    const variants: Record<string, string> = {
      High: 'bg-destructive text-destructive-foreground',
      Medium: 'bg-warning text-warning-foreground',
      Low: 'bg-success text-success-foreground',
    };
    return <Badge className={variants[level]}>{level}</Badge>;
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      Open: 'bg-info/10 text-info border-info/30',
      'In Review': 'bg-warning/10 text-warning border-warning/30',
      Mitigated: 'bg-success/10 text-success border-success/30',
      Closed: 'bg-muted text-muted-foreground',
    };
    return <Badge variant="outline" className={variants[status]}>{status}</Badge>;
  };

  return (
    <div className="min-h-screen bg-background">
      <Sidebar activeItem="risk" onNavigate={() => {}} />
      <div className="ml-64">
        <Header breadcrumbs={breadcrumbs} />
        <main className="p-6">
          {/* Page Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={handleBack}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-warning/10 flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6 text-warning" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-foreground">RiskGuard</h1>
                  <p className="text-muted-foreground">Risk Assessment & Mitigation Platform</p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {fromFinance && (
                <Button variant="outline" onClick={() => navigate('/finance/risks')}>
                  Return to Finance Dashboard
                </Button>
              )}
              <Button onClick={handleAdd} className="gap-2">
                <Plus className="w-4 h-4" />
                New Risk Assessment
              </Button>
            </div>
          </div>

          {/* Metric Tiles */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            {metrics.map((metric) => (
              <Card
                key={metric.id}
                className={`p-4 cursor-pointer transition-all hover:shadow-md ${activeMetric === metric.id ? 'ring-2 ring-primary' : ''}`}
                onClick={() => setActiveMetric(activeMetric === metric.id ? null : metric.id)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{metric.label}</p>
                    <p className="text-2xl font-bold">{metric.value}</p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${metric.color}`} />
                </div>
              </Card>
            ))}
          </div>

          {/* Filters */}
          <div className="flex items-center gap-3 mb-6">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search risks..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={levelFilter} onValueChange={setLevelFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Risk Level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="High">High</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Low">Low</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Open">Open</SelectItem>
                <SelectItem value="In Review">In Review</SelectItem>
                <SelectItem value="Mitigated">Mitigated</SelectItem>
                <SelectItem value="Closed">Closed</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" className="gap-2">
              <Filter className="w-4 h-4" />
              More Filters
            </Button>
          </div>

          {/* Risks Table */}
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Risk ID</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Level</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Owner</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Finance Domain</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRisks.map((risk) => (
                  <TableRow key={risk.id}>
                    <TableCell className="font-medium">{risk.id}</TableCell>
                    <TableCell className="max-w-[200px] truncate">{risk.description}</TableCell>
                    <TableCell>{getLevelBadge(risk.level)}</TableCell>
                    <TableCell>{getStatusBadge(risk.status)}</TableCell>
                    <TableCell>{risk.owner}</TableCell>
                    <TableCell>{new Date(risk.dueDate).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <div className="flex gap-1 flex-wrap">
                        {risk.financeDomain.slice(0, 2).map((domain) => (
                          <Badge key={domain} variant="secondary" className="text-xs">{domain}</Badge>
                        ))}
                        {risk.financeDomain.length > 2 && (
                          <Badge variant="secondary" className="text-xs">+{risk.financeDomain.length - 2}</Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="icon" onClick={() => handleView(risk)}>
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleEdit(risk)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(risk)}>
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>

          {/* Add/Edit Dialog */}
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{selectedRisk ? 'Edit Risk' : 'New Risk Assessment'}</DialogTitle>
                <DialogDescription>
                  {selectedRisk ? 'Update risk details and mitigation strategy.' : 'Create a new finance risk assessment.'}
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label>Description</Label>
                  <Textarea
                    value={formData.description || ''}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe the risk..."
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label>Risk Level</Label>
                    <Select
                      value={formData.level || 'Medium'}
                      onValueChange={(value) => setFormData({ ...formData, level: value as Risk['level'] })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="High">High</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="Low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label>Status</Label>
                    <Select
                      value={formData.status || 'Open'}
                      onValueChange={(value) => setFormData({ ...formData, status: value as Risk['status'] })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Open">Open</SelectItem>
                        <SelectItem value="In Review">In Review</SelectItem>
                        <SelectItem value="Mitigated">Mitigated</SelectItem>
                        <SelectItem value="Closed">Closed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label>Owner</Label>
                    <Input
                      value={formData.owner || ''}
                      onChange={(e) => setFormData({ ...formData, owner: e.target.value })}
                      placeholder="Risk owner name"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label>Due Date</Label>
                    <Input
                      type="date"
                      value={formData.dueDate || ''}
                      onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                    />
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label>Finance Domain</Label>
                  <div className="flex flex-wrap gap-2 p-2 border rounded-md">
                    {financeDomains.map((domain) => (
                      <Badge
                        key={domain}
                        variant={formData.financeDomain?.includes(domain) ? 'default' : 'outline'}
                        className="cursor-pointer"
                        onClick={() => {
                          const current = formData.financeDomain || [];
                          setFormData({
                            ...formData,
                            financeDomain: current.includes(domain)
                              ? current.filter(d => d !== domain)
                              : [...current, domain]
                          });
                        }}
                      >
                        {domain}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label>Preventive Controls</Label>
                  <Textarea
                    value={formData.preventiveControls || ''}
                    onChange={(e) => setFormData({ ...formData, preventiveControls: e.target.value })}
                    placeholder="Describe preventive controls..."
                  />
                </div>
                <div className="grid gap-2">
                  <Label>Detective Controls</Label>
                  <Textarea
                    value={formData.detectiveControls || ''}
                    onChange={(e) => setFormData({ ...formData, detectiveControls: e.target.value })}
                    placeholder="Describe detective controls..."
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleSave}>{selectedRisk ? 'Save Changes' : 'Create Risk'}</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* View Detail Dialog */}
          <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Risk Details: {selectedRisk?.id}</DialogTitle>
              </DialogHeader>
              {selectedRisk && (
                <div className="grid gap-4 py-4">
                  <div className="flex items-center gap-4">
                    {getLevelBadge(selectedRisk.level)}
                    {getStatusBadge(selectedRisk.status)}
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Description</p>
                    <p className="font-medium">{selectedRisk.description}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Owner</p>
                      <p className="font-medium">{selectedRisk.owner}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Due Date</p>
                      <p className="font-medium">{new Date(selectedRisk.dueDate).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Finance Domains</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedRisk.financeDomain.map((domain) => (
                        <Badge key={domain} variant="secondary">{domain}</Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Preventive Controls</p>
                    <p className="font-medium">{selectedRisk.preventiveControls}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Detective Controls</p>
                    <p className="font-medium">{selectedRisk.detectiveControls}</p>
                  </div>
                </div>
              )}
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDetailOpen(false)}>Close</Button>
                <Button onClick={() => { setIsDetailOpen(false); handleEdit(selectedRisk!); }}>Edit Risk</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Delete Confirmation */}
          <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Archive Risk?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will archive {selectedRisk?.id}. The risk will be moved to archived items and can be restored later.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  Archive
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </main>
      </div>
    </div>
  );
}
