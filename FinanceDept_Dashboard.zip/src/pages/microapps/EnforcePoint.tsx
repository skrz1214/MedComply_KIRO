import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { Shield, Plus, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function EnforcePoint() {
  const breadcrumbs = [
    { label: 'Master Compliance', href: '/master' },
    { label: 'Finance Compliance Dashboard', href: '/' },
    { label: 'EnforcePoint' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Sidebar activeItem="enforce-point" onNavigate={() => {}} />
      <div className="ml-64">
        <Header breadcrumbs={breadcrumbs} />
        <main className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 rounded-xl bg-destructive/10 flex items-center justify-center">
              <Shield className="w-6 h-6 text-destructive" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">EnforcePoint</h1>
              <p className="text-muted-foreground">Enforcement tracking</p>
            </div>
          </div>

          <div className="flex items-center gap-3 mb-6">
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              New Enforcement
            </Button>
            <Button variant="outline" className="gap-2">
              <Filter className="w-4 h-4" />
              Filter
            </Button>
          </div>

          <div className="bg-card rounded-xl border border-border p-8 text-center">
            <Shield className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-lg font-semibold text-foreground mb-2">Welcome to EnforcePoint</h2>
            <p className="text-muted-foreground max-w-md mx-auto">
              Track and manage enforcement actions, penalties, and remediation efforts across your organization.
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}
