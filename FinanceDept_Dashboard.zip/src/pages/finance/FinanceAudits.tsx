import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Plus,
  Search,
  Filter,
  ClipboardCheck,
  ExternalLink,
  ArrowLeft,
  Calendar,
  X,
} from 'lucide-react';

interface Audit {
  id: string;
  title: string;
  type: string;
  status: 'Scheduled' | 'In Progress' | 'Pending Review' | 'Completed' | 'Overdue';
  priority: 'High' | 'Medium' | 'Low';
  owner: string;
  deadline: string;
  financeDomain: string[];
  findings: number;
}

// Domain tabs for Audit Management
const domainTabs = [
  { id: 'all', label: 'All Finance' },
  { id: 'business-continuity', label: 'Business Continuity', domain: 'Business Continuity' },
  { id: 'financial-statements', label: 'Financial Statements', domain: 'Financial Statements' },
  { id: 'accounts-receivable', label: 'Accounts Receivable', domain: 'Accounts Receivable' },
  { id: 'billing-compliance', label: 'Billing Compliance', domain: 'Billing Compliance' },
  { id: 'external-reporting', label: 'External Reporting', domain: 'External Reporting' },
  { id: 'internal-reporting', label: 'Internal Reporting', domain: 'Internal Reporting' },
  { id: 'billing-checklist', label: 'Billing Checklist', domain: 'Billing Checklist' },
  { id: 'budget-vs-actual', label: 'Budget vs Actual', domain: 'Budget vs Actual' },
  { id: 'balance-sheet', label: 'Balance Sheet', domain: 'Balance Sheet' },
];

const initialAudits: Audit[] = [
  {
    id: 'AUD-001',
    title: 'Q1 Revenue Cycle Compliance Audit',
    type: 'Revenue Cycle Audit',
    status: 'In Progress',
    priority: 'High',
    owner: 'David Kim',
    deadline: '2024-02-28',
    financeDomain: ['Billing Compliance', 'Accounts Receivable'],
    findings: 3,
  },
  {
    id: 'AUD-002',
    title: 'Annual Financial Statement Review',
    type: 'Financial Statement Review',
    status: 'Scheduled',
    priority: 'High',
    owner: 'Emily Watson',
    deadline: '2024-03-15',
    financeDomain: ['Financial Statements', 'External Reporting'],
    findings: 0,
  },
  {
    id: 'AUD-003',
    title: 'Vendor Contract Compliance Review',
    type: 'Contract Review',
    status: 'Pending Review',
    priority: 'Medium',
    owner: 'Robert Chen',
    deadline: '2024-02-20',
    financeDomain: ['Service Contracts'],
    findings: 5,
  },
  {
    id: 'AUD-004',
    title: 'Monthly Billing Checklist Audit',
    type: 'Billing Audit',
    status: 'Completed',
    priority: 'Low',
    owner: 'Lisa Park',
    deadline: '2024-02-10',
    financeDomain: ['Billing Compliance', 'Billing Checklist'],
    findings: 1,
  },
  {
    id: 'AUD-005',
    title: 'BCP Test Audit - Finance Operations',
    type: 'BCP Test Audit',
    status: 'Scheduled',
    priority: 'High',
    owner: 'Michael Torres',
    deadline: '2024-03-20',
    financeDomain: ['Business Continuity'],
    findings: 0,
  },
  {
    id: 'AUD-006',
    title: 'Q1 Budget Variance Review',
    type: 'Budget Variance Audit',
    status: 'In Progress',
    priority: 'Medium',
    owner: 'Jennifer Adams',
    deadline: '2024-03-01',
    financeDomain: ['Budget vs Actual'],
    findings: 2,
  },
  {
    id: 'AUD-007',
    title: 'Balance Sheet Reconciliation Audit',
    type: 'Balance Sheet Review',
    status: 'Pending Review',
    priority: 'High',
    owner: 'Sarah Chen',
    deadline: '2024-02-25',
    financeDomain: ['Balance Sheet', 'Financial Statements'],
    findings: 4,
  },
];

export default function FinanceAudits() {
  const navigate = useNavigate();
  const [audits] = useState<Audit[]>(initialAudits);
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [activeMetric, setActiveMetric] = useState<string | null>(null);

  const breadcrumbs = [
    { label: 'Master Compliance', href: '/master' },
    { label: 'Finance Dashboard', href: '/' },
    { label: 'Audit Management' },
  ];

  // Get current domain filter from active tab
  const currentDomainFilter = domainTabs.find(t => t.id === activeTab)?.domain;

  // Filter audits by domain tab first
  const domainFilteredAudits = currentDomainFilter
    ? audits.filter(a => a.financeDomain.includes(currentDomainFilter))
    : audits;

  const metrics = [
    { id: 'total', label: 'Total Audits', value: domainFilteredAudits.length, color: 'bg-info' },
    { id: 'pending', label: 'Pending Review', value: domainFilteredAudits.filter(a => a.status === 'Pending Review').length, color: 'bg-warning' },
    { id: 'completed', label: 'Completed', value: domainFilteredAudits.filter(a => a.status === 'Completed').length, color: 'bg-success' },
    { id: 'overdue', label: 'Overdue', value: domainFilteredAudits.filter(a => new Date(a.deadline) < new Date() && a.status !== 'Completed').length, color: 'bg-destructive' },
  ];

  const upcomingDeadlines = domainFilteredAudits
    .filter(a => a.status !== 'Completed' && new Date(a.deadline) >= new Date())
    .sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime())
    .slice(0, 3);

  const filteredAudits = domainFilteredAudits.filter(audit => {
    const matchesSearch = audit.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      audit.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || audit.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || audit.priority === priorityFilter;
    const matchesMetric = !activeMetric ||
      (activeMetric === 'total') ||
      (activeMetric === 'pending' && audit.status === 'Pending Review') ||
      (activeMetric === 'completed' && audit.status === 'Completed') ||
      (activeMetric === 'overdue' && new Date(audit.deadline) < new Date() && audit.status !== 'Completed');
    return matchesSearch && matchesStatus && matchesPriority && matchesMetric;
  });

  const handleOpenInAuditPro = (auditId?: string, mode: 'view' | 'edit' | 'new' = 'view') => {
    const params = new URLSearchParams({ from: 'finance-dashboard', dept: 'finance' });
    if (auditId) {
      params.set('id', auditId);
      params.set('mode', mode);
    } else {
      params.set('mode', 'new');
    }
    navigate(`/auditpro?${params.toString()}`);
  };

  const getPriorityBadge = (priority: string) => {
    const variants: Record<string, string> = {
      High: 'bg-destructive text-destructive-foreground',
      Medium: 'bg-warning text-warning-foreground',
      Low: 'bg-success text-success-foreground',
    };
    return <Badge className={variants[priority]}>{priority}</Badge>;
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      Scheduled: 'bg-info/10 text-info border-info/30',
      'In Progress': 'bg-primary/10 text-primary border-primary/30',
      'Pending Review': 'bg-warning/10 text-warning border-warning/30',
      Completed: 'bg-success/10 text-success border-success/30',
      Overdue: 'bg-destructive/10 text-destructive border-destructive/30',
    };
    return <Badge variant="outline" className={variants[status]}>{status}</Badge>;
  };

  return (
    <div className="min-h-screen bg-background">
      <Sidebar activeItem="audit" onNavigate={() => {}} />
      <div className="ml-64">
        <Header breadcrumbs={breadcrumbs} />
        <main className="p-6">
          {/* Page Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <ClipboardCheck className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-foreground">Audit Management</h1>
                  <p className="text-muted-foreground">Finance Audit Tracking & Review</p>
                </div>
              </div>
            </div>
            <Button onClick={() => handleOpenInAuditPro(undefined, 'new')} className="gap-2">
              <Plus className="w-4 h-4" />
              New Audit
            </Button>
          </div>

          {/* Domain Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="h-auto flex-wrap gap-1 bg-muted/50 p-1">
              {domainTabs.map((tab) => (
                <TabsTrigger 
                  key={tab.id} 
                  value={tab.id}
                  className="data-[state=active]:bg-background text-xs"
                >
                  {tab.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>

          {/* Tab Filter Summary */}
          {currentDomainFilter && (
            <div className="flex items-center gap-2 mb-4">
              <span className="text-sm text-muted-foreground">Active Filters:</span>
              <Badge variant="secondary" className="gap-1">
                Dept=Finance
              </Badge>
              <Badge variant="secondary" className="gap-1">
                Domain={currentDomainFilter}
                <button onClick={() => setActiveTab('all')} className="ml-1 hover:text-foreground">
                  <X className="w-3 h-3" />
                </button>
              </Badge>
              <Badge variant="secondary">Type=Audit</Badge>
            </div>
          )}

          <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-6">
            <div className="space-y-6">
              {/* Metric Tiles */}
              <div className="grid grid-cols-4 gap-4">
                {metrics.map((metric) => (
                  <Card
                    key={metric.id}
                    className={`p-4 cursor-pointer transition-all hover:shadow-md ${activeMetric === metric.id ? 'ring-2 ring-primary' : ''}`}
                    onClick={() => setActiveMetric(activeMetric === metric.id ? null : metric.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">{metric.label}</p>
                        <p className="text-2xl font-bold">{metric.value}</p>
                      </div>
                      <div className={`w-3 h-3 rounded-full ${metric.color}`} />
                    </div>
                  </Card>
                ))}
              </div>

              {/* Filters */}
              <div className="flex items-center gap-3">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search audits..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="Scheduled">Scheduled</SelectItem>
                    <SelectItem value="In Progress">In Progress</SelectItem>
                    <SelectItem value="Pending Review">Pending Review</SelectItem>
                    <SelectItem value="Completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priority</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Low">Low</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" className="gap-2">
                  <Filter className="w-4 h-4" />
                  More Filters
                </Button>
              </div>

              {/* Audits Table */}
              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Audit ID</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Owner</TableHead>
                      <TableHead>Deadline</TableHead>
                      <TableHead>Finance Domain</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAudits.map((audit) => (
                      <TableRow key={audit.id} className="cursor-pointer hover:bg-muted/50" onClick={() => handleOpenInAuditPro(audit.id, 'view')}>
                        <TableCell className="font-medium">{audit.id}</TableCell>
                        <TableCell className="max-w-[180px] truncate">{audit.title}</TableCell>
                        <TableCell>{getStatusBadge(audit.status)}</TableCell>
                        <TableCell>{getPriorityBadge(audit.priority)}</TableCell>
                        <TableCell>{audit.owner}</TableCell>
                        <TableCell>{new Date(audit.deadline).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex gap-1 flex-wrap">
                            {audit.financeDomain.slice(0, 2).map((domain) => (
                              <Badge key={domain} variant="secondary" className="text-xs">{domain}</Badge>
                            ))}
                            {audit.financeDomain.length > 2 && (
                              <Badge variant="secondary" className="text-xs">+{audit.financeDomain.length - 2}</Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="gap-2"
                            onClick={(e) => { e.stopPropagation(); handleOpenInAuditPro(audit.id, 'view'); }}
                          >
                            <ExternalLink className="w-4 h-4" />
                            Open in AuditPro
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            </div>

            {/* Right Sidebar - Upcoming Deadlines */}
            <div className="space-y-6">
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-4">
                  <Calendar className="w-5 h-5 text-primary" />
                  <h3 className="font-semibold">Upcoming Deadlines</h3>
                </div>
                <div className="space-y-3">
                  {upcomingDeadlines.map((audit) => (
                    <div
                      key={audit.id}
                      className="p-3 rounded-lg bg-muted/50 cursor-pointer hover:bg-muted transition-colors"
                      onClick={() => handleOpenInAuditPro(audit.id, 'view')}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">{audit.id}</span>
                        {getPriorityBadge(audit.priority)}
                      </div>
                      <p className="text-sm text-muted-foreground truncate">{audit.title}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Due: {new Date(audit.deadline).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
