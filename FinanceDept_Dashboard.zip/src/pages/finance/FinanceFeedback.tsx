import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Plus,
  Search,
  Filter,
  MessageSquare,
  ExternalLink,
  ArrowLeft,
  X,
} from 'lucide-react';

interface FeedbackItem {
  id: string;
  type: 'Complaint' | 'Concern' | 'Suggestion' | 'Inquiry';
  category: string;
  description: string;
  status: 'New' | 'In Review' | 'Escalated' | 'Resolved' | 'Closed';
  owner: string;
  dueDate: string;
  financeDomain: string[];
  severity: 'High' | 'Medium' | 'Low';
  source: string;
}

// Domain tabs for Feedback Management
const domainTabs = [
  { id: 'all', label: 'All Finance' },
  { id: 'financial-hardship', label: 'Financial Hardship', domain: 'Financial Hardship' },
  { id: 'billing-management', label: 'Billing Management', domain: 'Billing Management' },
  { id: 'billing-compliance', label: 'Billing Compliance', domain: 'Billing Compliance' },
  { id: 'accounts-receivable', label: 'Accounts Receivable', domain: 'Accounts Receivable' },
];

const initialFeedback: FeedbackItem[] = [
  {
    id: 'FB-001',
    type: 'Complaint',
    category: 'Billing Complaint',
    description: 'Patient received incorrect billing statement for outpatient services',
    status: 'In Review',
    owner: 'Maria Santos',
    dueDate: '2024-02-18',
    financeDomain: ['Billing Compliance', 'Accounts Receivable'],
    severity: 'High',
    source: 'Patient Portal',
  },
  {
    id: 'FB-002',
    type: 'Concern',
    category: 'Financial Hardship',
    description: 'Request for payment plan due to financial difficulty',
    status: 'New',
    owner: 'James Wilson',
    dueDate: '2024-02-20',
    financeDomain: ['Financial Hardship'],
    severity: 'Medium',
    source: 'Phone Call',
  },
  {
    id: 'FB-003',
    type: 'Inquiry',
    category: 'Insurance Inquiry',
    description: 'Question about coverage for elective procedure',
    status: 'Resolved',
    owner: 'Linda Chen',
    dueDate: '2024-02-15',
    financeDomain: ['Billing Compliance'],
    severity: 'Low',
    source: 'Email',
  },
  {
    id: 'FB-004',
    type: 'Complaint',
    category: 'Vendor Concern',
    description: 'Delayed payment to medical supply vendor',
    status: 'Escalated',
    owner: 'Robert Kim',
    dueDate: '2024-02-16',
    financeDomain: ['Service Contracts', 'Accounts Receivable'],
    severity: 'High',
    source: 'Vendor',
  },
  {
    id: 'FB-005',
    type: 'Complaint',
    category: 'Billing Complaint',
    description: 'Duplicate charge on patient account',
    status: 'In Review',
    owner: 'Sarah Chen',
    dueDate: '2024-02-22',
    financeDomain: ['Billing Management'],
    severity: 'Medium',
    source: 'Patient Portal',
  },
];

export default function FinanceFeedback() {
  const navigate = useNavigate();
  const [feedback] = useState<FeedbackItem[]>(initialFeedback);
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [activeMetric, setActiveMetric] = useState<string | null>(null);

  const breadcrumbs = [
    { label: 'Master Compliance', href: '/master' },
    { label: 'Finance Dashboard', href: '/' },
    { label: 'Feedback Management' },
  ];

  // Get current domain filter from active tab
  const currentDomainFilter = domainTabs.find(t => t.id === activeTab)?.domain;

  // Filter feedback by domain tab first
  const domainFilteredFeedback = currentDomainFilter
    ? feedback.filter(f => f.financeDomain.includes(currentDomainFilter))
    : feedback;

  const metrics = [
    { id: 'total', label: 'Total Feedback', value: domainFilteredFeedback.length, color: 'bg-info' },
    { id: 'new', label: 'New', value: domainFilteredFeedback.filter(f => f.status === 'New').length, color: 'bg-primary' },
    { id: 'inReview', label: 'In Review', value: domainFilteredFeedback.filter(f => f.status === 'In Review' || f.status === 'Escalated').length, color: 'bg-warning' },
    { id: 'overdue', label: 'Overdue', value: domainFilteredFeedback.filter(f => new Date(f.dueDate) < new Date() && f.status !== 'Resolved' && f.status !== 'Closed').length, color: 'bg-destructive' },
  ];

  const filteredFeedback = domainFilteredFeedback.filter(item => {
    const matchesSearch = item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === 'all' || item.type === typeFilter;
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    const matchesMetric = !activeMetric ||
      (activeMetric === 'total') ||
      (activeMetric === 'new' && item.status === 'New') ||
      (activeMetric === 'inReview' && (item.status === 'In Review' || item.status === 'Escalated')) ||
      (activeMetric === 'overdue' && new Date(item.dueDate) < new Date() && item.status !== 'Resolved' && item.status !== 'Closed');
    return matchesSearch && matchesType && matchesStatus && matchesMetric;
  });

  const handleOpenInFeedbackHub = (feedbackId?: string, mode: 'view' | 'edit' | 'new' = 'view') => {
    const params = new URLSearchParams({ from: 'finance-dashboard', dept: 'finance' });
    if (feedbackId) {
      params.set('id', feedbackId);
      params.set('mode', mode);
    } else {
      params.set('mode', 'new');
    }
    navigate(`/feedbackhub?${params.toString()}`);
  };

  const getTypeBadge = (type: string) => {
    const variants: Record<string, string> = {
      Complaint: 'bg-destructive/10 text-destructive',
      Concern: 'bg-warning/10 text-warning',
      Suggestion: 'bg-success/10 text-success',
      Inquiry: 'bg-info/10 text-info',
    };
    return <Badge className={variants[type]}>{type}</Badge>;
  };

  const getSeverityBadge = (severity: string) => {
    const variants: Record<string, string> = {
      High: 'bg-destructive text-destructive-foreground',
      Medium: 'bg-warning text-warning-foreground',
      Low: 'bg-success text-success-foreground',
    };
    return <Badge className={variants[severity]}>{severity}</Badge>;
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      New: 'bg-info/10 text-info border-info/30',
      'In Review': 'bg-warning/10 text-warning border-warning/30',
      Escalated: 'bg-destructive/10 text-destructive border-destructive/30',
      Resolved: 'bg-success/10 text-success border-success/30',
      Closed: 'bg-muted text-muted-foreground',
    };
    return <Badge variant="outline" className={variants[status]}>{status}</Badge>;
  };

  return (
    <div className="min-h-screen bg-background">
      <Sidebar activeItem="feedback" onNavigate={() => {}} />
      <div className="ml-64">
        <Header breadcrumbs={breadcrumbs} />
        <main className="p-6">
          {/* Page Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-info/10 flex items-center justify-center">
                  <MessageSquare className="w-6 h-6 text-info" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-foreground">Feedback Management</h1>
                  <p className="text-muted-foreground">Finance Complaints, Concerns & Inquiries</p>
                </div>
              </div>
            </div>
            <Button onClick={() => handleOpenInFeedbackHub(undefined, 'new')} className="gap-2">
              <Plus className="w-4 h-4" />
              New Feedback
            </Button>
          </div>

          {/* Domain Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="h-auto flex-wrap gap-1 bg-muted/50 p-1">
              {domainTabs.map((tab) => (
                <TabsTrigger 
                  key={tab.id} 
                  value={tab.id}
                  className="data-[state=active]:bg-background"
                >
                  {tab.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>

          {/* Tab Filter Summary */}
          {currentDomainFilter && (
            <div className="flex items-center gap-2 mb-4">
              <span className="text-sm text-muted-foreground">Active Filters:</span>
              <Badge variant="secondary" className="gap-1">
                Dept=Finance
              </Badge>
              <Badge variant="secondary" className="gap-1">
                Domain={currentDomainFilter}
                <button onClick={() => setActiveTab('all')} className="ml-1 hover:text-foreground">
                  <X className="w-3 h-3" />
                </button>
              </Badge>
              <Badge variant="secondary">Type=Feedback</Badge>
            </div>
          )}

          {/* Metric Tiles */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            {metrics.map((metric) => (
              <Card
                key={metric.id}
                className={`p-4 cursor-pointer transition-all hover:shadow-md ${activeMetric === metric.id ? 'ring-2 ring-primary' : ''}`}
                onClick={() => setActiveMetric(activeMetric === metric.id ? null : metric.id)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{metric.label}</p>
                    <p className="text-2xl font-bold">{metric.value}</p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${metric.color}`} />
                </div>
              </Card>
            ))}
          </div>

          {/* Filters */}
          <div className="flex items-center gap-3 mb-6">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search feedback..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="Complaint">Complaint</SelectItem>
                <SelectItem value="Concern">Concern</SelectItem>
                <SelectItem value="Suggestion">Suggestion</SelectItem>
                <SelectItem value="Inquiry">Inquiry</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="New">New</SelectItem>
                <SelectItem value="In Review">In Review</SelectItem>
                <SelectItem value="Escalated">Escalated</SelectItem>
                <SelectItem value="Resolved">Resolved</SelectItem>
                <SelectItem value="Closed">Closed</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" className="gap-2">
              <Filter className="w-4 h-4" />
              More Filters
            </Button>
          </div>

          {/* Feedback Table */}
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Severity</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Owner</TableHead>
                  <TableHead>SLA Due</TableHead>
                  <TableHead>Finance Domain</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredFeedback.map((item) => (
                  <TableRow key={item.id} className="cursor-pointer hover:bg-muted/50" onClick={() => handleOpenInFeedbackHub(item.id, 'view')}>
                    <TableCell className="font-medium">{item.id}</TableCell>
                    <TableCell>{getTypeBadge(item.type)}</TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-xs">{item.category}</Badge>
                    </TableCell>
                    <TableCell className="max-w-[150px] truncate">{item.description}</TableCell>
                    <TableCell>{getSeverityBadge(item.severity)}</TableCell>
                    <TableCell>{getStatusBadge(item.status)}</TableCell>
                    <TableCell>{item.owner}</TableCell>
                    <TableCell>{new Date(item.dueDate).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <div className="flex gap-1 flex-wrap">
                        {item.financeDomain.slice(0, 1).map((domain) => (
                          <Badge key={domain} variant="secondary" className="text-xs">{domain}</Badge>
                        ))}
                        {item.financeDomain.length > 1 && (
                          <Badge variant="secondary" className="text-xs">+{item.financeDomain.length - 1}</Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="gap-2"
                        onClick={(e) => { e.stopPropagation(); handleOpenInFeedbackHub(item.id, 'view'); }}
                      >
                        <ExternalLink className="w-4 h-4" />
                        Open in FeedbackHub
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </main>
      </div>
    </div>
  );
}
