import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Plus,
  Search,
  Filter,
  AlertTriangle,
  ExternalLink,
  ArrowLeft,
  X,
  FileText,
  Download,
  Eye,
} from 'lucide-react';

interface Risk {
  id: string;
  description: string;
  level: 'High' | 'Medium' | 'Low';
  status: 'Open' | 'In Review' | 'Mitigated' | 'Closed';
  owner: string;
  dueDate: string;
  financeDomain: string[];
}

interface Policy {
  id: string;
  title: string;
  type: 'Policy' | 'Procedure' | 'Guideline';
  status: 'Active' | 'Under Review' | 'Draft' | 'Archived';
  version: string;
  owner: string;
  effectiveDate: string;
  reviewDate: string;
  category: string;
}

// Domain tabs for Risk Management
const domainTabs = [
  { id: 'all', label: 'All Finance' },
  { id: 'business-continuity', label: 'Business Continuity', domain: 'Business Continuity' },
  { id: 'accounts-receivable', label: 'Accounts Receivable', domain: 'Accounts Receivable' },
  { id: 'budget-vs-actual', label: 'Budget vs Actual', domain: 'Budget vs Actual' },
  { id: 'service-contracts', label: 'Service Contracts', domain: 'Service Contracts' },
];

const categoryTabs = [
  { id: 'all', label: 'All Documents' },
  { id: 'financial-controls', label: 'Financial Controls', category: 'Financial Controls' },
  { id: 'budget-management', label: 'Budget Management', category: 'Budget Management' },
  { id: 'accounts-payable', label: 'Accounts Payable', category: 'Accounts Payable' },
  { id: 'accounts-receivable', label: 'Accounts Receivable', category: 'Accounts Receivable' },
  { id: 'compliance', label: 'Compliance', category: 'Compliance' },
];

const initialRisks: Risk[] = [
  {
    id: 'RSK-001',
    description: 'Revenue cycle billing errors exceeding threshold',
    level: 'High',
    status: 'Open',
    owner: 'Sarah Chen',
    dueDate: '2024-02-15',
    financeDomain: ['Billing Compliance', 'Accounts Receivable'],
  },
  {
    id: 'RSK-002',
    description: 'Contract renewal compliance gap',
    level: 'Medium',
    status: 'In Review',
    owner: 'Michael Torres',
    dueDate: '2024-02-20',
    financeDomain: ['Service Contracts'],
  },
  {
    id: 'RSK-003',
    description: 'External reporting deadline risk',
    level: 'Low',
    status: 'Mitigated',
    owner: 'Jennifer Adams',
    dueDate: '2024-03-01',
    financeDomain: ['External Reporting'],
  },
  {
    id: 'RSK-004',
    description: 'Business continuity plan outdated for finance operations',
    level: 'High',
    status: 'Open',
    owner: 'David Kim',
    dueDate: '2024-02-25',
    financeDomain: ['Business Continuity'],
  },
  {
    id: 'RSK-005',
    description: 'Budget variance exceeding 10% threshold',
    level: 'Medium',
    status: 'In Review',
    owner: 'Emily Watson',
    dueDate: '2024-03-05',
    financeDomain: ['Budget vs Actual'],
  },
];

const initialPolicies: Policy[] = [
  {
    id: 'POL-001',
    title: 'Financial Controls Policy',
    type: 'Policy',
    status: 'Active',
    version: '3.2',
    owner: 'Sarah Chen',
    effectiveDate: '2024-01-01',
    reviewDate: '2025-01-01',
    category: 'Financial Controls',
  },
  {
    id: 'POL-002',
    title: 'Budget Approval Procedure',
    type: 'Procedure',
    status: 'Active',
    version: '2.1',
    owner: 'Michael Torres',
    effectiveDate: '2024-02-15',
    reviewDate: '2025-02-15',
    category: 'Budget Management',
  },
  {
    id: 'POL-003',
    title: 'Invoice Processing Guidelines',
    type: 'Guideline',
    status: 'Under Review',
    version: '1.5',
    owner: 'Jennifer Adams',
    effectiveDate: '2023-06-01',
    reviewDate: '2024-06-01',
    category: 'Accounts Payable',
  },
  {
    id: 'POL-004',
    title: 'Revenue Recognition Policy',
    type: 'Policy',
    status: 'Active',
    version: '4.0',
    owner: 'David Kim',
    effectiveDate: '2024-03-01',
    reviewDate: '2025-03-01',
    category: 'Accounts Receivable',
  },
  {
    id: 'POL-005',
    title: 'Expense Reimbursement Procedure',
    type: 'Procedure',
    status: 'Draft',
    version: '1.0',
    owner: 'Emily Watson',
    effectiveDate: '2024-04-01',
    reviewDate: '2025-04-01',
    category: 'Financial Controls',
  },
  {
    id: 'POL-006',
    title: 'SOX Compliance Guidelines',
    type: 'Guideline',
    status: 'Active',
    version: '2.3',
    owner: 'Sarah Chen',
    effectiveDate: '2024-01-15',
    reviewDate: '2025-01-15',
    category: 'Compliance',
  },
];

export default function FinanceRisks() {
  const navigate = useNavigate();
  const [mainTab, setMainTab] = useState('risks');
  
  // Risk state
  const [risks] = useState<Risk[]>(initialRisks);
  const [riskDomainTab, setRiskDomainTab] = useState('all');
  const [riskSearchQuery, setRiskSearchQuery] = useState('');
  const [riskLevelFilter, setRiskLevelFilter] = useState<string>('all');
  const [riskStatusFilter, setRiskStatusFilter] = useState<string>('all');
  const [activeRiskMetric, setActiveRiskMetric] = useState<string | null>(null);

  // Policy state
  const [policies] = useState<Policy[]>(initialPolicies);
  const [policyCategoryTab, setPolicyCategoryTab] = useState('all');
  const [policySearchQuery, setPolicySearchQuery] = useState('');
  const [policyTypeFilter, setPolicyTypeFilter] = useState<string>('all');
  const [policyStatusFilter, setPolicyStatusFilter] = useState<string>('all');
  const [activePolicyMetric, setActivePolicyMetric] = useState<string | null>(null);

  const breadcrumbs = [
    { label: 'Master Compliance', href: '/master' },
    { label: 'Finance Dashboard', href: '/' },
    { label: 'Risk Management' },
  ];

  // Risk filtering
  const currentDomainFilter = domainTabs.find(t => t.id === riskDomainTab)?.domain;
  const domainFilteredRisks = currentDomainFilter
    ? risks.filter(r => r.financeDomain.includes(currentDomainFilter))
    : risks;

  const riskMetrics = [
    { id: 'total', label: 'Total Risks', value: domainFilteredRisks.length, color: 'bg-info' },
    { id: 'pending', label: 'Pending Review', value: domainFilteredRisks.filter(r => r.status === 'In Review').length, color: 'bg-warning' },
    { id: 'completed', label: 'Mitigated', value: domainFilteredRisks.filter(r => r.status === 'Mitigated' || r.status === 'Closed').length, color: 'bg-success' },
    { id: 'overdue', label: 'Overdue', value: domainFilteredRisks.filter(r => new Date(r.dueDate) < new Date() && r.status === 'Open').length, color: 'bg-destructive' },
  ];

  const filteredRisks = domainFilteredRisks.filter(risk => {
    const matchesSearch = risk.description.toLowerCase().includes(riskSearchQuery.toLowerCase()) ||
      risk.id.toLowerCase().includes(riskSearchQuery.toLowerCase());
    const matchesLevel = riskLevelFilter === 'all' || risk.level === riskLevelFilter;
    const matchesStatus = riskStatusFilter === 'all' || risk.status === riskStatusFilter;
    const matchesMetric = !activeRiskMetric || 
      (activeRiskMetric === 'total') ||
      (activeRiskMetric === 'pending' && risk.status === 'In Review') ||
      (activeRiskMetric === 'completed' && (risk.status === 'Mitigated' || risk.status === 'Closed')) ||
      (activeRiskMetric === 'overdue' && new Date(risk.dueDate) < new Date() && risk.status === 'Open');
    return matchesSearch && matchesLevel && matchesStatus && matchesMetric;
  });

  // Policy filtering
  const currentCategoryFilter = categoryTabs.find(t => t.id === policyCategoryTab)?.category;
  const categoryFilteredPolicies = currentCategoryFilter
    ? policies.filter(p => p.category === currentCategoryFilter)
    : policies;

  const policyMetrics = [
    { id: 'total', label: 'Total Documents', value: categoryFilteredPolicies.length, color: 'bg-info' },
    { id: 'active', label: 'Active', value: categoryFilteredPolicies.filter(p => p.status === 'Active').length, color: 'bg-success' },
    { id: 'review', label: 'Under Review', value: categoryFilteredPolicies.filter(p => p.status === 'Under Review').length, color: 'bg-warning' },
    { id: 'draft', label: 'Draft', value: categoryFilteredPolicies.filter(p => p.status === 'Draft').length, color: 'bg-muted' },
  ];

  const filteredPolicies = categoryFilteredPolicies.filter(policy => {
    const matchesSearch = policy.title.toLowerCase().includes(policySearchQuery.toLowerCase()) ||
      policy.id.toLowerCase().includes(policySearchQuery.toLowerCase());
    const matchesType = policyTypeFilter === 'all' || policy.type === policyTypeFilter;
    const matchesStatus = policyStatusFilter === 'all' || policy.status === policyStatusFilter;
    const matchesMetric = !activePolicyMetric ||
      (activePolicyMetric === 'total') ||
      (activePolicyMetric === 'active' && policy.status === 'Active') ||
      (activePolicyMetric === 'review' && policy.status === 'Under Review') ||
      (activePolicyMetric === 'draft' && policy.status === 'Draft');
    return matchesSearch && matchesType && matchesStatus && matchesMetric;
  });

  const handleOpenInRiskGuard = (riskId?: string, mode: 'view' | 'edit' | 'new' = 'view') => {
    const params = new URLSearchParams({ from: 'finance-dashboard', dept: 'finance' });
    if (riskId) {
      params.set('id', riskId);
      params.set('mode', mode);
    } else {
      params.set('mode', 'new');
    }
    navigate(`/riskguard?${params.toString()}`);
  };

  const getRiskLevelBadge = (level: string) => {
    const variants: Record<string, string> = {
      High: 'bg-destructive text-destructive-foreground',
      Medium: 'bg-warning text-warning-foreground',
      Low: 'bg-success text-success-foreground',
    };
    return <Badge className={variants[level]}>{level}</Badge>;
  };

  const getRiskStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      Open: 'bg-info/10 text-info border-info/30',
      'In Review': 'bg-warning/10 text-warning border-warning/30',
      Mitigated: 'bg-success/10 text-success border-success/30',
      Closed: 'bg-muted text-muted-foreground',
    };
    return <Badge variant="outline" className={variants[status]}>{status}</Badge>;
  };

  const getPolicyTypeBadge = (type: string) => {
    const variants: Record<string, string> = {
      Policy: 'bg-primary text-primary-foreground',
      Procedure: 'bg-info text-info-foreground',
      Guideline: 'bg-secondary text-secondary-foreground',
    };
    return <Badge className={variants[type]}>{type}</Badge>;
  };

  const getPolicyStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      Active: 'bg-success/10 text-success border-success/30',
      'Under Review': 'bg-warning/10 text-warning border-warning/30',
      Draft: 'bg-muted text-muted-foreground',
      Archived: 'bg-muted/50 text-muted-foreground',
    };
    return <Badge variant="outline" className={variants[status]}>{status}</Badge>;
  };

  return (
    <div className="min-h-screen bg-background">
      <Sidebar activeItem="risk" onNavigate={() => {}} />
      <div className="ml-64">
        <Header breadcrumbs={breadcrumbs} />
        <main className="p-6">
          {/* Page Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-destructive/10 flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6 text-destructive" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-foreground">Risk Management</h1>
                  <p className="text-muted-foreground">Finance Risk Assessment & Mitigation</p>
                </div>
              </div>
            </div>
            {mainTab === 'risks' ? (
              <Button onClick={() => handleOpenInRiskGuard(undefined, 'new')} className="gap-2">
                <Plus className="w-4 h-4" />
                New Risk Assessment
              </Button>
            ) : (
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                New Document
              </Button>
            )}
          </div>

          {/* Main Tabs - Risks vs Policies */}
          <Tabs value={mainTab} onValueChange={setMainTab} className="mb-6">
            <TabsList className="bg-muted/50 p-1">
              <TabsTrigger value="risks" className="gap-2 data-[state=active]:bg-background">
                <AlertTriangle className="w-4 h-4" />
                Risks
              </TabsTrigger>
              <TabsTrigger value="policies" className="gap-2 data-[state=active]:bg-background">
                <FileText className="w-4 h-4" />
                Policies & Procedures
              </TabsTrigger>
            </TabsList>

            {/* Risks Tab Content */}
            <TabsContent value="risks" className="mt-6">
              {/* Domain Tabs */}
              <Tabs value={riskDomainTab} onValueChange={setRiskDomainTab} className="mb-6">
                <TabsList className="h-auto flex-wrap gap-1 bg-muted/50 p-1">
                  {domainTabs.map((tab) => (
                    <TabsTrigger 
                      key={tab.id} 
                      value={tab.id}
                      className="data-[state=active]:bg-background"
                    >
                      {tab.label}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>

              {/* Tab Filter Summary */}
              {currentDomainFilter && (
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-sm text-muted-foreground">Active Filters:</span>
                  <Badge variant="secondary" className="gap-1">
                    Dept=Finance
                  </Badge>
                  <Badge variant="secondary" className="gap-1">
                    Domain={currentDomainFilter}
                    <button onClick={() => setRiskDomainTab('all')} className="ml-1 hover:text-foreground">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                  <Badge variant="secondary">Type=Risk</Badge>
                </div>
              )}

              {/* Metric Tiles */}
              <div className="grid grid-cols-4 gap-4 mb-6">
                {riskMetrics.map((metric) => (
                  <Card
                    key={metric.id}
                    className={`p-4 cursor-pointer transition-all hover:shadow-md ${activeRiskMetric === metric.id ? 'ring-2 ring-primary' : ''}`}
                    onClick={() => setActiveRiskMetric(activeRiskMetric === metric.id ? null : metric.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">{metric.label}</p>
                        <p className="text-2xl font-bold">{metric.value}</p>
                      </div>
                      <div className={`w-3 h-3 rounded-full ${metric.color}`} />
                    </div>
                  </Card>
                ))}
              </div>

              {/* Filters */}
              <div className="flex items-center gap-3 mb-6">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search risks..."
                    value={riskSearchQuery}
                    onChange={(e) => setRiskSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={riskLevelFilter} onValueChange={setRiskLevelFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Risk Level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Levels</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Low">Low</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={riskStatusFilter} onValueChange={setRiskStatusFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="Open">Open</SelectItem>
                    <SelectItem value="In Review">In Review</SelectItem>
                    <SelectItem value="Mitigated">Mitigated</SelectItem>
                    <SelectItem value="Closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" className="gap-2">
                  <Filter className="w-4 h-4" />
                  More Filters
                </Button>
              </div>

              {/* Risks Table */}
              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Risk ID</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Level</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Owner</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Finance Domain</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRisks.map((risk) => (
                      <TableRow key={risk.id} className="cursor-pointer hover:bg-muted/50" onClick={() => handleOpenInRiskGuard(risk.id, 'view')}>
                        <TableCell className="font-medium">{risk.id}</TableCell>
                        <TableCell className="max-w-[200px] truncate">{risk.description}</TableCell>
                        <TableCell>{getRiskLevelBadge(risk.level)}</TableCell>
                        <TableCell>{getRiskStatusBadge(risk.status)}</TableCell>
                        <TableCell>{risk.owner}</TableCell>
                        <TableCell>{new Date(risk.dueDate).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex gap-1 flex-wrap">
                            {risk.financeDomain.slice(0, 2).map((domain) => (
                              <Badge key={domain} variant="secondary" className="text-xs">{domain}</Badge>
                            ))}
                            {risk.financeDomain.length > 2 && (
                              <Badge variant="secondary" className="text-xs">+{risk.financeDomain.length - 2}</Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="gap-2"
                            onClick={(e) => { e.stopPropagation(); handleOpenInRiskGuard(risk.id, 'view'); }}
                          >
                            <ExternalLink className="w-4 h-4" />
                            Open in RiskGuard
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            </TabsContent>

            {/* Policies Tab Content */}
            <TabsContent value="policies" className="mt-6">
              {/* Category Tabs */}
              <Tabs value={policyCategoryTab} onValueChange={setPolicyCategoryTab} className="mb-6">
                <TabsList className="h-auto flex-wrap gap-1 bg-muted/50 p-1">
                  {categoryTabs.map((tab) => (
                    <TabsTrigger
                      key={tab.id}
                      value={tab.id}
                      className="data-[state=active]:bg-background"
                    >
                      {tab.label}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>

              {/* Metric Tiles */}
              <div className="grid grid-cols-4 gap-4 mb-6">
                {policyMetrics.map((metric) => (
                  <Card
                    key={metric.id}
                    className={`p-4 cursor-pointer transition-all hover:shadow-md ${activePolicyMetric === metric.id ? 'ring-2 ring-primary' : ''}`}
                    onClick={() => setActivePolicyMetric(activePolicyMetric === metric.id ? null : metric.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">{metric.label}</p>
                        <p className="text-2xl font-bold">{metric.value}</p>
                      </div>
                      <div className={`w-3 h-3 rounded-full ${metric.color}`} />
                    </div>
                  </Card>
                ))}
              </div>

              {/* Filters */}
              <div className="flex items-center gap-3 mb-6">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search policies..."
                    value={policySearchQuery}
                    onChange={(e) => setPolicySearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={policyTypeFilter} onValueChange={setPolicyTypeFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Document Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="Policy">Policy</SelectItem>
                    <SelectItem value="Procedure">Procedure</SelectItem>
                    <SelectItem value="Guideline">Guideline</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={policyStatusFilter} onValueChange={setPolicyStatusFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Under Review">Under Review</SelectItem>
                    <SelectItem value="Draft">Draft</SelectItem>
                    <SelectItem value="Archived">Archived</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" className="gap-2">
                  <Filter className="w-4 h-4" />
                  More Filters
                </Button>
              </div>

              {/* Policies Table */}
              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Document ID</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Version</TableHead>
                      <TableHead>Owner</TableHead>
                      <TableHead>Effective Date</TableHead>
                      <TableHead>Review Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPolicies.map((policy) => (
                      <TableRow key={policy.id} className="cursor-pointer hover:bg-muted/50">
                        <TableCell className="font-medium">{policy.id}</TableCell>
                        <TableCell className="max-w-[200px] truncate">{policy.title}</TableCell>
                        <TableCell>{getPolicyTypeBadge(policy.type)}</TableCell>
                        <TableCell>{getPolicyStatusBadge(policy.status)}</TableCell>
                        <TableCell>v{policy.version}</TableCell>
                        <TableCell>{policy.owner}</TableCell>
                        <TableCell>{new Date(policy.effectiveDate).toLocaleDateString()}</TableCell>
                        <TableCell>{new Date(policy.reviewDate).toLocaleDateString()}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-1">
                            <Button variant="ghost" size="sm">
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Download className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <ExternalLink className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}
