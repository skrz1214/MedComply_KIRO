import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Plus,
  Search,
  Filter,
  CheckSquare,
  ExternalLink,
  ArrowLeft,
  FileText,
  AlertCircle,
  Calendar,
  X,
} from 'lucide-react';

// Compliance Items
interface ComplianceItem {
  id: string;
  description: string;
  status: 'Open' | 'In Review' | 'Pending Approval' | 'Closed';
  owner: string;
  dueDate: string;
  financeDomain: string[];
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  capaRequired: boolean;
}

// CAPA Items
interface CAPA {
  id: string;
  title: string;
  stage: 'Investigation' | 'Root Cause' | 'Action Plan' | 'Implementation' | 'Verification' | 'Closed';
  owner: string;
  dueDate: string;
  effectiveness: 'Not Evaluated' | 'Effective' | 'Partially Effective' | 'Not Effective';
  linkedItem: string;
  financeDomain: string[];
}

// Citations
interface Citation {
  id: string;
  authority: string;
  description: string;
  status: 'New' | 'POC Submitted' | 'Under Review' | 'Resolved';
  dueDate: string;
  pocStatus: 'Not Started' | 'In Progress' | 'Submitted' | 'Accepted';
  owner: string;
  financeDomain: string[];
}

// Domain tabs for Compliance Items
const complianceDomainTabs = [
  { id: 'all', label: 'All Finance' },
  { id: 'financial-statements', label: 'Financial Statements', domain: 'Financial Statements' },
  { id: 'accounts-receivable', label: 'Accounts Receivable', domain: 'Accounts Receivable' },
  { id: 'billing-compliance', label: 'Billing Compliance', domain: 'Billing Compliance' },
  { id: 'external-reporting', label: 'External Reporting', domain: 'External Reporting' },
  { id: 'internal-reporting', label: 'Internal Reporting', domain: 'Internal Reporting' },
  { id: 'billing-checklist', label: 'Billing Checklist', domain: 'Billing Checklist' },
  { id: 'balance-sheet', label: 'Balance Sheet', domain: 'Balance Sheet' },
  { id: 'billing-management', label: 'Billing Management', domain: 'Billing Management' },
  { id: 'service-contracts', label: 'Service Contracts', domain: 'Service Contracts' },
];

// Domain tabs for CAPA
const capaDomainTabs = [
  { id: 'all', label: 'All Finance' },
  { id: 'billing-compliance', label: 'Billing Compliance', domain: 'Billing Compliance' },
  { id: 'billing-management', label: 'Billing Management', domain: 'Billing Management' },
  { id: 'accounts-receivable', label: 'Accounts Receivable', domain: 'Accounts Receivable' },
  { id: 'service-contracts', label: 'Service Contracts', domain: 'Service Contracts' },
];

// Domain tabs for Citations
const citationDomainTabs = [
  { id: 'all', label: 'All Finance' },
  { id: 'billing-compliance', label: 'Billing Compliance', domain: 'Billing Compliance' },
  { id: 'external-reporting', label: 'External Reporting', domain: 'External Reporting' },
  { id: 'service-contracts', label: 'Service Contracts', domain: 'Service Contracts' },
];

const initialCompliance: ComplianceItem[] = [
  {
    id: 'CMP-001',
    description: 'Medicare billing code documentation gaps identified',
    status: 'Open',
    owner: 'Sarah Chen',
    dueDate: '2024-02-20',
    financeDomain: ['Billing Compliance'],
    severity: 'High',
    capaRequired: true,
  },
  {
    id: 'CMP-002',
    description: 'Cost report submission deadline compliance',
    status: 'In Review',
    owner: 'Michael Torres',
    dueDate: '2024-03-01',
    financeDomain: ['External Reporting'],
    severity: 'Critical',
    capaRequired: true,
  },
  {
    id: 'CMP-003',
    description: 'Accounts receivable aging threshold breach',
    status: 'Pending Approval',
    owner: 'Jennifer Adams',
    dueDate: '2024-02-25',
    financeDomain: ['Accounts Receivable'],
    severity: 'Medium',
    capaRequired: false,
  },
  {
    id: 'CMP-004',
    description: 'Balance sheet reconciliation discrepancy',
    status: 'Open',
    owner: 'David Kim',
    dueDate: '2024-02-28',
    financeDomain: ['Balance Sheet', 'Financial Statements'],
    severity: 'High',
    capaRequired: true,
  },
];

const initialCAPAs: CAPA[] = [
  {
    id: 'CAPA-001',
    title: 'Billing code documentation improvement',
    stage: 'Action Plan',
    owner: 'Sarah Chen',
    dueDate: '2024-03-15',
    effectiveness: 'Not Evaluated',
    linkedItem: 'CMP-001',
    financeDomain: ['Billing Compliance'],
  },
  {
    id: 'CAPA-002',
    title: 'Reporting workflow enhancement',
    stage: 'Implementation',
    owner: 'Michael Torres',
    dueDate: '2024-03-20',
    effectiveness: 'Not Evaluated',
    linkedItem: 'CMP-002',
    financeDomain: ['Billing Management'],
  },
  {
    id: 'CAPA-003',
    title: 'AR collection process optimization',
    stage: 'Verification',
    owner: 'Jennifer Adams',
    dueDate: '2024-03-10',
    effectiveness: 'Partially Effective',
    linkedItem: 'CMP-003',
    financeDomain: ['Accounts Receivable'],
  },
];

const initialCitations: Citation[] = [
  {
    id: 'CIT-001',
    authority: 'CMS',
    description: 'Documentation deficiency in Medicare claims',
    status: 'POC Submitted',
    dueDate: '2024-02-28',
    pocStatus: 'Submitted',
    owner: 'David Kim',
    financeDomain: ['Billing Compliance'],
  },
  {
    id: 'CIT-002',
    authority: 'State Medicaid',
    description: 'Timely filing requirement violation',
    status: 'New',
    dueDate: '2024-03-10',
    pocStatus: 'Not Started',
    owner: 'Emily Watson',
    financeDomain: ['External Reporting'],
  },
];

export default function FinanceCompliance() {
  const navigate = useNavigate();
  const [activeMainTab, setActiveMainTab] = useState('compliance');
  const [activeDomainTab, setActiveDomainTab] = useState('all');
  
  // Data
  const [complianceItems] = useState<ComplianceItem[]>(initialCompliance);
  const [capas] = useState<CAPA[]>(initialCAPAs);
  const [citations] = useState<Citation[]>(initialCitations);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [activeMetric, setActiveMetric] = useState<string | null>(null);

  const breadcrumbs = [
    { label: 'Master Compliance', href: '/master' },
    { label: 'Finance Dashboard', href: '/' },
    { label: 'Compliance Tracking' },
  ];

  // Get current domain tabs based on active main tab
  const getCurrentDomainTabs = () => {
    switch (activeMainTab) {
      case 'capa': return capaDomainTabs;
      case 'citations': return citationDomainTabs;
      default: return complianceDomainTabs;
    }
  };

  const currentDomainTabs = getCurrentDomainTabs();
  const currentDomainFilter = currentDomainTabs.find(t => t.id === activeDomainTab)?.domain;

  // Reset domain tab when main tab changes
  const handleMainTabChange = (tab: string) => {
    setActiveMainTab(tab);
    setActiveDomainTab('all');
    setActiveMetric(null);
  };

  // Filter data by domain
  const domainFilteredCompliance = currentDomainFilter
    ? complianceItems.filter(c => c.financeDomain.includes(currentDomainFilter))
    : complianceItems;

  const domainFilteredCAPAs = currentDomainFilter
    ? capas.filter(c => c.financeDomain.includes(currentDomainFilter))
    : capas;

  const domainFilteredCitations = currentDomainFilter
    ? citations.filter(c => c.financeDomain.includes(currentDomainFilter))
    : citations;

  const complianceMetrics = [
    { id: 'total', label: 'Total Items', value: domainFilteredCompliance.length, color: 'bg-info' },
    { id: 'pending', label: 'Pending Review', value: domainFilteredCompliance.filter(c => c.status === 'In Review' || c.status === 'Pending Approval').length, color: 'bg-warning' },
    { id: 'completed', label: 'Closed', value: domainFilteredCompliance.filter(c => c.status === 'Closed').length, color: 'bg-success' },
    { id: 'overdue', label: 'Overdue', value: domainFilteredCompliance.filter(c => new Date(c.dueDate) < new Date() && c.status !== 'Closed').length, color: 'bg-destructive' },
  ];

  const capaMetrics = [
    { id: 'total', label: 'Total CAPAs', value: domainFilteredCAPAs.length, color: 'bg-info' },
    { id: 'open', label: 'Open', value: domainFilteredCAPAs.filter(c => c.stage !== 'Closed').length, color: 'bg-warning' },
    { id: 'verification', label: 'In Verification', value: domainFilteredCAPAs.filter(c => c.stage === 'Verification').length, color: 'bg-primary' },
    { id: 'closed', label: 'Closed', value: domainFilteredCAPAs.filter(c => c.stage === 'Closed').length, color: 'bg-success' },
  ];

  const citationMetrics = [
    { id: 'total', label: 'Total Citations', value: domainFilteredCitations.length, color: 'bg-info' },
    { id: 'new', label: 'New', value: domainFilteredCitations.filter(c => c.status === 'New').length, color: 'bg-destructive' },
    { id: 'inProgress', label: 'In Progress', value: domainFilteredCitations.filter(c => c.status === 'POC Submitted' || c.status === 'Under Review').length, color: 'bg-warning' },
    { id: 'resolved', label: 'Resolved', value: domainFilteredCitations.filter(c => c.status === 'Resolved').length, color: 'bg-success' },
  ];

  const handleOpenInComplianceConnect = (itemId?: string, type: string = 'compliance', mode: 'view' | 'edit' | 'new' = 'view') => {
    const params = new URLSearchParams({ from: 'finance-dashboard', dept: 'finance', type });
    if (itemId) {
      params.set('id', itemId);
      params.set('mode', mode);
    } else {
      params.set('mode', 'new');
    }
    navigate(`/complianceconnect?${params.toString()}`);
  };

  const getSeverityBadge = (severity: string) => {
    const variants: Record<string, string> = {
      Critical: 'bg-destructive text-destructive-foreground',
      High: 'bg-destructive/80 text-destructive-foreground',
      Medium: 'bg-warning text-warning-foreground',
      Low: 'bg-success text-success-foreground',
    };
    return <Badge className={variants[severity]}>{severity}</Badge>;
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      Open: 'bg-info/10 text-info border-info/30',
      'In Review': 'bg-warning/10 text-warning border-warning/30',
      'Pending Approval': 'bg-primary/10 text-primary border-primary/30',
      Closed: 'bg-success/10 text-success border-success/30',
      New: 'bg-destructive/10 text-destructive border-destructive/30',
      'POC Submitted': 'bg-warning/10 text-warning border-warning/30',
      'Under Review': 'bg-primary/10 text-primary border-primary/30',
      Resolved: 'bg-success/10 text-success border-success/30',
    };
    return <Badge variant="outline" className={variants[status]}>{status}</Badge>;
  };

  const getStageBadge = (stage: string) => {
    const variants: Record<string, string> = {
      Investigation: 'bg-info/10 text-info',
      'Root Cause': 'bg-warning/10 text-warning',
      'Action Plan': 'bg-primary/10 text-primary',
      Implementation: 'bg-accent text-accent-foreground',
      Verification: 'bg-success/10 text-success',
      Closed: 'bg-muted text-muted-foreground',
    };
    return <Badge className={variants[stage]}>{stage}</Badge>;
  };

  const renderMetrics = () => {
    const metrics = activeMainTab === 'compliance' ? complianceMetrics : activeMainTab === 'capa' ? capaMetrics : citationMetrics;
    return (
      <div className="grid grid-cols-4 gap-4 mb-6">
        {metrics.map((metric) => (
          <Card
            key={metric.id}
            className={`p-4 cursor-pointer transition-all hover:shadow-md ${activeMetric === metric.id ? 'ring-2 ring-primary' : ''}`}
            onClick={() => setActiveMetric(activeMetric === metric.id ? null : metric.id)}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{metric.label}</p>
                <p className="text-2xl font-bold">{metric.value}</p>
              </div>
              <div className={`w-3 h-3 rounded-full ${metric.color}`} />
            </div>
          </Card>
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <Sidebar activeItem="compliance" onNavigate={() => {}} />
      <div className="ml-64">
        <Header breadcrumbs={breadcrumbs} />
        <main className="p-6">
          {/* Page Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-success/10 flex items-center justify-center">
                  <CheckSquare className="w-6 h-6 text-success" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-foreground">Compliance Tracking</h1>
                  <p className="text-muted-foreground">Finance Compliance Items, CAPA & Citations</p>
                </div>
              </div>
            </div>
            <Button onClick={() => handleOpenInComplianceConnect(undefined, activeMainTab, 'new')} className="gap-2">
              <Plus className="w-4 h-4" />
              {activeMainTab === 'compliance' ? 'New Compliance Item' : activeMainTab === 'capa' ? 'New CAPA' : activeMainTab === 'citations' ? 'New Citation' : 'New Document'}
            </Button>
          </div>

          {/* Main Tabs */}
          <Tabs value={activeMainTab} onValueChange={handleMainTabChange} className="space-y-6">
            <TabsList className="grid w-full max-w-md grid-cols-4">
              <TabsTrigger value="compliance" className="gap-2">
                <CheckSquare className="w-4 h-4" />
                Compliance
              </TabsTrigger>
              <TabsTrigger value="capa" className="gap-2">
                <AlertCircle className="w-4 h-4" />
                CAPA
              </TabsTrigger>
              <TabsTrigger value="citations" className="gap-2">
                <Calendar className="w-4 h-4" />
                Citations
              </TabsTrigger>
              <TabsTrigger value="policies" className="gap-2">
                <FileText className="w-4 h-4" />
                Policies
              </TabsTrigger>
            </TabsList>

            {/* Compliance Tab */}
            <TabsContent value="compliance" className="space-y-6">
              {/* Domain Tabs */}
              <Tabs value={activeDomainTab} onValueChange={setActiveDomainTab}>
                <TabsList className="h-auto flex-wrap gap-1 bg-muted/50 p-1">
                  {complianceDomainTabs.map((tab) => (
                    <TabsTrigger 
                      key={tab.id} 
                      value={tab.id}
                      className="data-[state=active]:bg-background text-xs"
                    >
                      {tab.label}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>

              {/* Tab Filter Summary */}
              {currentDomainFilter && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Active Filters:</span>
                  <Badge variant="secondary">Dept=Finance</Badge>
                  <Badge variant="secondary" className="gap-1">
                    Domain={currentDomainFilter}
                    <button onClick={() => setActiveDomainTab('all')} className="ml-1 hover:text-foreground">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                  <Badge variant="secondary">Type=Compliance Item</Badge>
                </div>
              )}

              {renderMetrics()}
              
              <div className="flex items-center gap-3 mb-4">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search compliance items..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="Open">Open</SelectItem>
                    <SelectItem value="In Review">In Review</SelectItem>
                    <SelectItem value="Pending Approval">Pending Approval</SelectItem>
                    <SelectItem value="Closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" className="gap-2">
                  <Filter className="w-4 h-4" />
                  More Filters
                </Button>
              </div>

              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Severity</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Owner</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Finance Domain</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {domainFilteredCompliance.map((item) => (
                      <TableRow key={item.id} className="cursor-pointer hover:bg-muted/50" onClick={() => handleOpenInComplianceConnect(item.id, 'compliance', 'view')}>
                        <TableCell className="font-medium">{item.id}</TableCell>
                        <TableCell className="max-w-[200px] truncate">{item.description}</TableCell>
                        <TableCell>{getSeverityBadge(item.severity)}</TableCell>
                        <TableCell>{getStatusBadge(item.status)}</TableCell>
                        <TableCell>{item.owner}</TableCell>
                        <TableCell>{new Date(item.dueDate).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex gap-1 flex-wrap">
                            {item.financeDomain.slice(0, 1).map((domain) => (
                              <Badge key={domain} variant="secondary" className="text-xs">{domain}</Badge>
                            ))}
                            {item.financeDomain.length > 1 && (
                              <Badge variant="secondary" className="text-xs">+{item.financeDomain.length - 1}</Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="gap-2"
                            onClick={(e) => { e.stopPropagation(); handleOpenInComplianceConnect(item.id, 'compliance', 'view'); }}
                          >
                            <ExternalLink className="w-4 h-4" />
                            Open in ComplianceConnect
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            </TabsContent>

            {/* CAPA Tab */}
            <TabsContent value="capa" className="space-y-6">
              {/* Domain Tabs */}
              <Tabs value={activeDomainTab} onValueChange={setActiveDomainTab}>
                <TabsList className="h-auto flex-wrap gap-1 bg-muted/50 p-1">
                  {capaDomainTabs.map((tab) => (
                    <TabsTrigger 
                      key={tab.id} 
                      value={tab.id}
                      className="data-[state=active]:bg-background text-xs"
                    >
                      {tab.label}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>

              {/* Tab Filter Summary */}
              {currentDomainFilter && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Active Filters:</span>
                  <Badge variant="secondary">Dept=Finance</Badge>
                  <Badge variant="secondary" className="gap-1">
                    Domain={currentDomainFilter}
                    <button onClick={() => setActiveDomainTab('all')} className="ml-1 hover:text-foreground">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                  <Badge variant="secondary">Type=CAPA</Badge>
                </div>
              )}

              {renderMetrics()}

              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>CAPA ID</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Stage</TableHead>
                      <TableHead>Owner</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Effectiveness</TableHead>
                      <TableHead>Finance Domain</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {domainFilteredCAPAs.map((item) => (
                      <TableRow key={item.id} className="cursor-pointer hover:bg-muted/50" onClick={() => handleOpenInComplianceConnect(item.id, 'capa', 'view')}>
                        <TableCell className="font-medium">{item.id}</TableCell>
                        <TableCell className="max-w-[200px] truncate">{item.title}</TableCell>
                        <TableCell>{getStageBadge(item.stage)}</TableCell>
                        <TableCell>{item.owner}</TableCell>
                        <TableCell>{new Date(item.dueDate).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{item.effectiveness}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1 flex-wrap">
                            {item.financeDomain.slice(0, 1).map((domain) => (
                              <Badge key={domain} variant="secondary" className="text-xs">{domain}</Badge>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="gap-2"
                            onClick={(e) => { e.stopPropagation(); handleOpenInComplianceConnect(item.id, 'capa', 'view'); }}
                          >
                            <ExternalLink className="w-4 h-4" />
                            Open in ActionGuard
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            </TabsContent>

            {/* Citations Tab */}
            <TabsContent value="citations" className="space-y-6">
              {/* Domain Tabs */}
              <Tabs value={activeDomainTab} onValueChange={setActiveDomainTab}>
                <TabsList className="h-auto flex-wrap gap-1 bg-muted/50 p-1">
                  {citationDomainTabs.map((tab) => (
                    <TabsTrigger 
                      key={tab.id} 
                      value={tab.id}
                      className="data-[state=active]:bg-background text-xs"
                    >
                      {tab.label}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>

              {/* Tab Filter Summary */}
              {currentDomainFilter && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Active Filters:</span>
                  <Badge variant="secondary">Dept=Finance</Badge>
                  <Badge variant="secondary" className="gap-1">
                    Domain={currentDomainFilter}
                    <button onClick={() => setActiveDomainTab('all')} className="ml-1 hover:text-foreground">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                  <Badge variant="secondary">Type=Citation</Badge>
                </div>
              )}

              {renderMetrics()}

              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Citation ID</TableHead>
                      <TableHead>Authority</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>POC Status</TableHead>
                      <TableHead>Owner</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Finance Domain</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {domainFilteredCitations.map((item) => (
                      <TableRow key={item.id} className="cursor-pointer hover:bg-muted/50" onClick={() => handleOpenInComplianceConnect(item.id, 'citations', 'view')}>
                        <TableCell className="font-medium">{item.id}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{item.authority}</Badge>
                        </TableCell>
                        <TableCell className="max-w-[200px] truncate">{item.description}</TableCell>
                        <TableCell>{getStatusBadge(item.status)}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{item.pocStatus}</Badge>
                        </TableCell>
                        <TableCell>{item.owner}</TableCell>
                        <TableCell>{new Date(item.dueDate).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex gap-1 flex-wrap">
                            {item.financeDomain.slice(0, 1).map((domain) => (
                              <Badge key={domain} variant="secondary" className="text-xs">{domain}</Badge>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="gap-2"
                            onClick={(e) => { e.stopPropagation(); handleOpenInComplianceConnect(item.id, 'citations', 'view'); }}
                          >
                            <ExternalLink className="w-4 h-4" />
                            Open in CitaPro
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            </TabsContent>

            {/* Policies Tab */}
            <TabsContent value="policies" className="space-y-6">
              <Card className="p-8 text-center">
                <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h2 className="text-lg font-semibold text-foreground mb-2">Finance Policies & Documents</h2>
                <p className="text-muted-foreground max-w-md mx-auto mb-4">
                  View and manage controlled documents filtered to the Finance department. Documents are managed in the central Documents module.
                </p>
                <Button onClick={() => navigate('/documents?dept=finance')} className="gap-2">
                  <ExternalLink className="w-4 h-4" />
                  Open Documents Module
                </Button>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}
