import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Plus,
  Search,
  Filter,
  Shield,
  ExternalLink,
  ArrowLeft,
  Calendar,
  X,
} from 'lucide-react';

interface EnforcementCase {
  id: string;
  title: string;
  authority: string;
  type: 'Investigation' | 'Audit Notice' | 'Subpoena' | 'Settlement' | 'Fine' | 'Other';
  status: 'New' | 'Under Investigation' | 'Response Submitted' | 'Pending Resolution' | 'Resolved' | 'Closed';
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  owner: string;
  dueDate: string;
  financeDomain: string[];
  monetaryImpact: number;
}

// Domain tabs for Enforcement Management
const domainTabs = [
  { id: 'all', label: 'All Finance' },
  { id: 'external-reporting', label: 'External Reporting', domain: 'External Reporting' },
  { id: 'billing-compliance', label: 'Billing Compliance', domain: 'Billing Compliance' },
  { id: 'service-contracts', label: 'Service Contracts', domain: 'Service Contracts' },
];

const initialCases: EnforcementCase[] = [
  {
    id: 'ENF-001',
    title: 'OIG Billing Practices Investigation',
    authority: 'OIG',
    type: 'Investigation',
    status: 'Under Investigation',
    priority: 'Critical',
    owner: 'Legal Counsel - Jane Smith',
    dueDate: '2024-03-30',
    financeDomain: ['Billing Compliance', 'Accounts Receivable'],
    monetaryImpact: 500000,
  },
  {
    id: 'ENF-002',
    title: 'State Medicaid Audit Response',
    authority: 'State Medicaid',
    type: 'Audit Notice',
    status: 'Response Submitted',
    priority: 'High',
    owner: 'Compliance Director - Michael Torres',
    dueDate: '2024-02-28',
    financeDomain: ['External Reporting', 'Billing Compliance'],
    monetaryImpact: 150000,
  },
  {
    id: 'ENF-003',
    title: 'Medicare Cost Report Settlement',
    authority: 'CMS',
    type: 'Settlement',
    status: 'Pending Resolution',
    priority: 'Medium',
    owner: 'CFO - David Kim',
    dueDate: '2024-04-15',
    financeDomain: ['External Reporting', 'Financial Statements'],
    monetaryImpact: 75000,
  },
  {
    id: 'ENF-004',
    title: 'Vendor Contract Dispute Resolution',
    authority: 'State Attorney General',
    type: 'Investigation',
    status: 'New',
    priority: 'High',
    owner: 'Legal Counsel - Jane Smith',
    dueDate: '2024-03-15',
    financeDomain: ['Service Contracts'],
    monetaryImpact: 200000,
  },
];

export default function FinanceEnforcements() {
  const navigate = useNavigate();
  const [cases] = useState<EnforcementCase[]>(initialCases);
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [activeMetric, setActiveMetric] = useState<string | null>(null);

  const breadcrumbs = [
    { label: 'Master Compliance', href: '/master' },
    { label: 'Finance Dashboard', href: '/' },
    { label: 'Enforcement Management' },
  ];

  // Get current domain filter from active tab
  const currentDomainFilter = domainTabs.find(t => t.id === activeTab)?.domain;

  // Filter cases by domain tab first
  const domainFilteredCases = currentDomainFilter
    ? cases.filter(c => c.financeDomain.includes(currentDomainFilter))
    : cases;

  const metrics = [
    { id: 'total', label: 'Total Cases', value: domainFilteredCases.length, color: 'bg-info' },
    { id: 'pending', label: 'Pending', value: domainFilteredCases.filter(c => c.status === 'Under Investigation' || c.status === 'Response Submitted' || c.status === 'Pending Resolution').length, color: 'bg-warning' },
    { id: 'completed', label: 'Resolved', value: domainFilteredCases.filter(c => c.status === 'Resolved' || c.status === 'Closed').length, color: 'bg-success' },
    { id: 'overdue', label: 'Overdue', value: domainFilteredCases.filter(c => new Date(c.dueDate) < new Date() && c.status !== 'Resolved' && c.status !== 'Closed').length, color: 'bg-destructive' },
  ];

  const upcomingDeadlines = domainFilteredCases
    .filter(c => c.status !== 'Resolved' && c.status !== 'Closed' && new Date(c.dueDate) >= new Date())
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    .slice(0, 3);

  const totalMonetaryImpact = domainFilteredCases
    .filter(c => c.status !== 'Resolved' && c.status !== 'Closed')
    .reduce((sum, c) => sum + c.monetaryImpact, 0);

  const filteredCases = domainFilteredCases.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || item.priority === priorityFilter;
    const matchesMetric = !activeMetric ||
      (activeMetric === 'total') ||
      (activeMetric === 'pending' && (item.status === 'Under Investigation' || item.status === 'Response Submitted' || item.status === 'Pending Resolution')) ||
      (activeMetric === 'completed' && (item.status === 'Resolved' || item.status === 'Closed')) ||
      (activeMetric === 'overdue' && new Date(item.dueDate) < new Date() && item.status !== 'Resolved' && item.status !== 'Closed');
    return matchesSearch && matchesStatus && matchesPriority && matchesMetric;
  });

  const handleOpenInEnforcePoint = (caseId?: string, mode: 'view' | 'edit' | 'new' = 'view') => {
    const params = new URLSearchParams({ from: 'finance-dashboard', dept: 'finance' });
    if (caseId) {
      params.set('id', caseId);
      params.set('mode', mode);
    } else {
      params.set('mode', 'new');
    }
    navigate(`/enforcepoint?${params.toString()}`);
  };

  const getPriorityBadge = (priority: string) => {
    const variants: Record<string, string> = {
      Critical: 'bg-destructive text-destructive-foreground',
      High: 'bg-destructive/80 text-destructive-foreground',
      Medium: 'bg-warning text-warning-foreground',
      Low: 'bg-success text-success-foreground',
    };
    return <Badge className={variants[priority]}>{priority}</Badge>;
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      New: 'bg-info/10 text-info border-info/30',
      'Under Investigation': 'bg-destructive/10 text-destructive border-destructive/30',
      'Response Submitted': 'bg-warning/10 text-warning border-warning/30',
      'Pending Resolution': 'bg-primary/10 text-primary border-primary/30',
      Resolved: 'bg-success/10 text-success border-success/30',
      Closed: 'bg-muted text-muted-foreground',
    };
    return <Badge variant="outline" className={variants[status]}>{status}</Badge>;
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };

  return (
    <div className="min-h-screen bg-background">
      <Sidebar activeItem="enforcement" onNavigate={() => {}} />
      <div className="ml-64">
        <Header breadcrumbs={breadcrumbs} />
        <main className="p-6">
          {/* Page Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Shield className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-foreground">Enforcement Management</h1>
                  <p className="text-muted-foreground">Finance Regulatory Enforcement Cases</p>
                </div>
              </div>
            </div>
            <Button onClick={() => handleOpenInEnforcePoint(undefined, 'new')} className="gap-2">
              <Plus className="w-4 h-4" />
              New Case
            </Button>
          </div>

          {/* Domain Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="h-auto flex-wrap gap-1 bg-muted/50 p-1">
              {domainTabs.map((tab) => (
                <TabsTrigger 
                  key={tab.id} 
                  value={tab.id}
                  className="data-[state=active]:bg-background"
                >
                  {tab.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>

          {/* Tab Filter Summary */}
          {currentDomainFilter && (
            <div className="flex items-center gap-2 mb-4">
              <span className="text-sm text-muted-foreground">Active Filters:</span>
              <Badge variant="secondary" className="gap-1">
                Dept=Finance
              </Badge>
              <Badge variant="secondary" className="gap-1">
                Domain={currentDomainFilter}
                <button onClick={() => setActiveTab('all')} className="ml-1 hover:text-foreground">
                  <X className="w-3 h-3" />
                </button>
              </Badge>
              <Badge variant="secondary">Type=Enforcement</Badge>
            </div>
          )}

          <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-6">
            <div className="space-y-6">
              {/* Metric Tiles */}
              <div className="grid grid-cols-4 gap-4">
                {metrics.map((metric) => (
                  <Card
                    key={metric.id}
                    className={`p-4 cursor-pointer transition-all hover:shadow-md ${activeMetric === metric.id ? 'ring-2 ring-primary' : ''}`}
                    onClick={() => setActiveMetric(activeMetric === metric.id ? null : metric.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">{metric.label}</p>
                        <p className="text-2xl font-bold">{metric.value}</p>
                      </div>
                      <div className={`w-3 h-3 rounded-full ${metric.color}`} />
                    </div>
                  </Card>
                ))}
              </div>

              {/* Filters */}
              <div className="flex items-center gap-3">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search cases..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="New">New</SelectItem>
                    <SelectItem value="Under Investigation">Under Investigation</SelectItem>
                    <SelectItem value="Response Submitted">Response Submitted</SelectItem>
                    <SelectItem value="Pending Resolution">Pending Resolution</SelectItem>
                    <SelectItem value="Resolved">Resolved</SelectItem>
                    <SelectItem value="Closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priority</SelectItem>
                    <SelectItem value="Critical">Critical</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Low">Low</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" className="gap-2">
                  <Filter className="w-4 h-4" />
                  More Filters
                </Button>
              </div>

              {/* Cases Table */}
              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Case ID</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Authority</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Owner</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Finance Domain</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCases.map((item) => (
                      <TableRow key={item.id} className="cursor-pointer hover:bg-muted/50" onClick={() => handleOpenInEnforcePoint(item.id, 'view')}>
                        <TableCell className="font-medium">{item.id}</TableCell>
                        <TableCell className="max-w-[150px] truncate">{item.title}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{item.authority}</Badge>
                        </TableCell>
                        <TableCell>{getPriorityBadge(item.priority)}</TableCell>
                        <TableCell>{getStatusBadge(item.status)}</TableCell>
                        <TableCell className="max-w-[120px] truncate">{item.owner}</TableCell>
                        <TableCell>{new Date(item.dueDate).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex gap-1 flex-wrap">
                            {item.financeDomain.slice(0, 1).map((domain) => (
                              <Badge key={domain} variant="secondary" className="text-xs">{domain}</Badge>
                            ))}
                            {item.financeDomain.length > 1 && (
                              <Badge variant="secondary" className="text-xs">+{item.financeDomain.length - 1}</Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="gap-2"
                            onClick={(e) => { e.stopPropagation(); handleOpenInEnforcePoint(item.id, 'view'); }}
                          >
                            <ExternalLink className="w-4 h-4" />
                            Open in EnforcePoint
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            </div>

            {/* Right Sidebar */}
            <div className="space-y-6">
              {/* Monetary Exposure */}
              <Card className="p-4">
                <h3 className="font-semibold mb-2">Total Monetary Exposure</h3>
                <p className="text-3xl font-bold text-destructive">{formatCurrency(totalMonetaryImpact)}</p>
                <p className="text-sm text-muted-foreground mt-1">Across active cases</p>
              </Card>

              {/* Upcoming Deadlines */}
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-4">
                  <Calendar className="w-5 h-5 text-primary" />
                  <h3 className="font-semibold">Upcoming Deadlines</h3>
                </div>
                <div className="space-y-3">
                  {upcomingDeadlines.map((item) => (
                    <div
                      key={item.id}
                      className="p-3 rounded-lg bg-muted/50 cursor-pointer hover:bg-muted transition-colors"
                      onClick={() => handleOpenInEnforcePoint(item.id, 'view')}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">{item.id}</span>
                        {getPriorityBadge(item.priority)}
                      </div>
                      <p className="text-sm text-muted-foreground truncate">{item.title}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Due: {new Date(item.dueDate).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
