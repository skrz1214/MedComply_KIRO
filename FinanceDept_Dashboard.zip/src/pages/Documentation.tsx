import { FileText, Download } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { jsPDF } from 'jspdf';

const prdContent = `
PRODUCT REQUIREMENTS DOCUMENT (PRD)
Finance Compliance Department Dashboard
Version 1.0 | Date: ${new Date().toLocaleDateString()}

================================================================================
1. EXECUTIVE SUMMARY
================================================================================

1.1 Purpose
The Finance Compliance Department Dashboard is a centralized management platform designed to provide the Finance department with comprehensive visibility and control over Risk, Audit, Compliance, Feedback, and Enforcement management activities.

1.2 Scope
This dashboard integrates with five core microapps (RiskGuard, AuditPro, ComplianceConnect, FeedbackHub, EnforcePoint) to deliver a unified view of all compliance-related activities specific to the Finance department.

1.3 Target Users
- Admin/Compliance Head: Full system access with department/individual view toggle
- Department Head: Department-level oversight with view toggle capability
- Staff: Individual task and assignment management

================================================================================
2. PRODUCT OVERVIEW
================================================================================

2.1 Product Vision
Create a single source of truth for Finance department compliance activities, reducing context-switching between microapps and improving operational efficiency.

2.2 Key Objectives
- Consolidate 5 microapp views into one cohesive dashboard
- Enable role-based access control with impersonation
- Provide finance-domain specific filtering (15+ domains)
- Support both department-wide and individual views
- Maintain deep-linking to source microapps

================================================================================
3. FUNCTIONAL REQUIREMENTS
================================================================================

3.1 Authentication & Authorization

FR-001: User Authentication
- System shall support email/password authentication
- System shall provide demo accounts for testing
- System shall maintain session state across page refreshes

FR-002: Role-Based Access Control
- Admin/Compliance Head: Full access to all features
- Department Head: Department-level access with toggle
- Staff: Individual view only, limited to assigned items

FR-003: View Mode Toggle
- Admin and Department Head shall have toggle between Department/Individual views
- Toggle state shall persist during session
- All dashboard widgets shall respect current view mode

FR-004: Role Impersonation (Admin Only)
- Admin shall be able to impersonate any role
- Impersonation shall update all permission checks
- Clear indicator of current impersonated role

3.2 Dashboard Home

FR-005: Quick Stats Widget
- Display 4 key metrics (Open Risks, Pending Audits, Compliance Rate, Active CAPA)
- Metrics shall update based on view mode filter
- Click on metric shall navigate to relevant section

FR-006: Action Center Widget
- Show prioritized action items requiring attention
- Filter by assignment in Individual view
- Show department-wide items in Department view

FR-007: Review Queue Widget
- Display items awaiting review/approval
- Support filtering by type and priority
- Enable quick actions (approve, reject, review)

FR-008: Upcoming Deadlines Widget
- Show deadline calendar for next 30 days
- Color-code by urgency (overdue, due soon, upcoming)
- Filter based on view mode

3.3 Risk Management Section

FR-009: Risk List View
- Display all Finance department risks in "Risks" tab
- Support domain tab filtering (Business Continuity, Accounts Receivable, Budget vs Actual, Service Contracts)
- Show filter summary chips

FR-010: Risk Detail Drawer
- Display full risk information
- Show related items (Audits, Compliance, CAPA)
- Deep link to RiskGuard microapp

FR-010.1: Policies & Procedures Tab
- Display all Finance department policies, procedures, and guidelines within Risk Management page
- Support category tab filtering (Financial Controls, Budget Management, Accounts Payable, Accounts Receivable, Compliance)
- Show document type, status, version, owner, effective date, and review date
- Provide view, download, and external link actions

3.4 Audit Management Section

FR-011: Audit List View
- Display all Finance department audits
- Support 10 domain tab filters
- Real-time metric updates per tab

FR-012: Audit Detail Drawer
- Display audit findings and status
- Show related compliance items
- Deep link to AuditPro microapp

3.5 Compliance Tracking Section

FR-013: Nested Tab Structure
- Primary tabs: Compliance Items, CAPA, Citations
- Secondary tabs: Finance domain filters per primary tab

FR-014: Cross-Module Linking
- Link compliance items to related audits and risks
- Support CAPA tracking and resolution
- Document management integration

3.6 Feedback Management Section

FR-015: Feedback Processing
- Display feedback items by domain
- Track SLA compliance
- Enable escalation workflows

3.7 Enforcement Management Section

FR-016: Enforcement Tracking
- Display enforcement actions and cases
- Track resolution status
- Link to related compliance findings

================================================================================
4. NON-FUNCTIONAL REQUIREMENTS
================================================================================

NFR-001: Performance
- Dashboard shall load within 2 seconds
- Tab switches shall complete within 500ms
- Metric calculations shall be real-time

NFR-002: Usability
- Responsive design for tablet and desktop
- Consistent navigation patterns
- Accessible keyboard navigation

NFR-003: Reliability
- 99.9% uptime target
- Graceful degradation on microapp unavailability
- Error boundary implementation

================================================================================
5. USER INTERFACE REQUIREMENTS
================================================================================

UI-001: Navigation
- Fixed left sidebar with section links
- Breadcrumb navigation
- "Return to Dashboard" links from detail views

UI-002: Theming
- Support light and dark modes
- Consistent color coding for status indicators
- Finance-specific branding elements

UI-003: Data Visualization
- Metric tiles with trend indicators
- Status badges with semantic colors
- Progress indicators for compliance rates

================================================================================
6. INTEGRATION REQUIREMENTS
================================================================================

INT-001: Microapp Integration
- RiskGuard: Risk data and controls
- AuditPro: Audit schedules and findings
- ComplianceConnect: Compliance items and CAPA
- FeedbackHub: Customer and internal feedback
- EnforcePoint: Enforcement actions

INT-002: Deep Linking
- Preserve context when navigating to microapps
- Support return navigation with state preservation
- Handle missing or unavailable records gracefully

================================================================================
7. DATA REQUIREMENTS
================================================================================

DATA-001: Finance Domains (Lookup Values)
- Business Continuity
- Financial Statements
- Accounts Receivable
- Billing Compliance
- External Reporting
- Internal Reporting
- Financial Hardship
- Billing Checklist
- Budget vs Actual
- Balance Sheet
- Billing Management
- Service Contracts

DATA-002: Record Types
- Risks: ID, Description, Level, Status, Owner, Due Date, Domain
- Audits: ID, Title, Status, Deadline, Owner, Priority, Domain
- Compliance Items: ID, Description, Status, Category, Owner, Domain
- Feedback: ID, Type, Category, Status, Owner, SLA Due, Domain
- Enforcement: ID, Title, Status, Due Date, Owner, Priority, Domain

================================================================================
8. ACCEPTANCE CRITERIA
================================================================================

AC-001: All 5 management sections accessible from sidebar
AC-002: Domain tabs functional in each section
AC-003: View mode toggle affects all widgets
AC-004: Role impersonation works correctly
AC-005: Deep links navigate to correct microapp records
AC-006: Metrics update in real-time with filter changes
AC-007: All demo accounts authenticate successfully

================================================================================
9. APPENDIX
================================================================================

A. Glossary
- CAPA: Corrective and Preventive Action
- RLS: Row Level Security
- SLA: Service Level Agreement
- BCP: Business Continuity Plan

B. References
- RiskGuard User Guide
- AuditPro Administration Manual
- ComplianceConnect Integration Spec
- FeedbackHub API Documentation
- EnforcePoint Configuration Guide
`;

const tddContent = `
TECHNICAL DESIGN DOCUMENT (TDD)
Finance Compliance Department Dashboard
Version 1.0 | Date: ${new Date().toLocaleDateString()}

================================================================================
1. SYSTEM ARCHITECTURE
================================================================================

1.1 Technology Stack
- Frontend Framework: React 18.3.1
- Build Tool: Vite
- Styling: Tailwind CSS with custom design tokens
- Component Library: shadcn/ui (Radix primitives)
- Routing: React Router DOM 6.30
- State Management: React Context API
- Charts: Recharts 2.15
- Icons: Lucide React

1.2 Project Structure
\`\`\`
src/
├── components/
│   ├── auth/
│   │   ├── ProtectedRoute.tsx    # Route protection wrapper
│   │   └── UserMenu.tsx          # User menu with role switching
│   ├── dashboard/
│   │   ├── ActionCenter.tsx      # Priority action items
│   │   ├── DataTable.tsx         # Reusable data table
│   │   ├── KPIManager.tsx        # KPI management
│   │   ├── MetricTiles.tsx       # Dashboard metrics
│   │   ├── MicroApps.tsx         # Microapp quick access
│   │   ├── QuickStats.tsx        # Stats overview
│   │   ├── ReviewQueue.tsx       # Review queue widget
│   │   └── UpcomingDeadlines.tsx # Deadline calendar
│   ├── layout/
│   │   ├── Header.tsx            # Top navigation header
│   │   └── Sidebar.tsx           # Left navigation sidebar
│   └── ui/                       # shadcn/ui components
├── contexts/
│   └── AuthContext.tsx           # Authentication state
├── pages/
│   ├── finance/
│   │   ├── FinanceRisks.tsx      # Risk management (includes Policies & Procedures tab)
│   │   ├── FinanceAudits.tsx     # Audit management
│   │   ├── FinanceCompliance.tsx # Compliance tracking
│   │   ├── FinanceFeedback.tsx   # Feedback management
│   │   └── FinanceEnforcements.tsx # Enforcement management
│   ├── microapps/                # Microapp placeholders
│   ├── FinanceDashboard.tsx      # Main dashboard
│   ├── LoginPage.tsx             # Authentication page
│   └── Documentation.tsx         # Documentation page
└── index.css                     # Global styles & tokens
\`\`\`

================================================================================
2. AUTHENTICATION SYSTEM
================================================================================

2.1 AuthContext Implementation
\`\`\`typescript
interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'department_head' | 'staff';
  department: string;
  avatar?: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
  viewMode: 'department' | 'individual';
  setViewMode: (mode: 'department' | 'individual') => void;
  impersonateRole: (role: User['role']) => void;
}
\`\`\`

2.2 Mock User Data
\`\`\`typescript
const mockUsers = [
  {
    id: '1',
    email: 'admin@financehub.com',
    password: 'admin123',
    name: 'Sarah Chen',
    role: 'admin',
    department: 'Finance'
  },
  {
    id: '2',
    email: 'head@financehub.com',
    password: 'head123',
    name: 'Michael Torres',
    role: 'department_head',
    department: 'Finance'
  },
  {
    id: '3',
    email: 'staff@financehub.com',
    password: 'staff123',
    name: 'Emily Johnson',
    role: 'staff',
    department: 'Finance'
  }
];
\`\`\`

2.3 Protected Route Pattern
\`\`\`typescript
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated } = useAuth();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};
\`\`\`

================================================================================
3. COMPONENT ARCHITECTURE
================================================================================

3.1 View Mode Filtering Pattern
All dashboard components implement view mode awareness:
\`\`\`typescript
const { user, viewMode } = useAuth();

const filteredData = useMemo(() => {
  if (viewMode === 'individual') {
    return data.filter(item => item.assignedTo === user?.name);
  }
  return data; // Department view shows all
}, [data, viewMode, user]);
\`\`\`

3.2 Tab Navigation Pattern
Finance domain tabs use consistent structure:
\`\`\`typescript
const domainTabs = [
  { id: 'all', label: 'All Finance' },
  { id: 'business-continuity', label: 'Business Continuity' },
  { id: 'accounts-receivable', label: 'Accounts Receivable' },
  // ... additional domains
];

const [activeTab, setActiveTab] = useState('all');

const filteredItems = useMemo(() => {
  if (activeTab === 'all') return items;
  return items.filter(item => item.domain === activeTab);
}, [items, activeTab]);
\`\`\`

3.3 Deep Link Handler Pattern
\`\`\`typescript
const handleOpenInMicroapp = (id: string) => {
  toast({
    title: "Opening in MicroApp",
    description: \`Navigating to record \${id}\`
  });
  navigate(\`/microapp/\${id}?returnTo=/finance/section\`);
};
\`\`\`

================================================================================
4. DESIGN SYSTEM
================================================================================

4.1 CSS Custom Properties (index.css)
\`\`\`css
:root {
  --background: 0 0% 100%;
  --foreground: 222.2 84% 4.9%;
  --card: 0 0% 100%;
  --card-foreground: 222.2 84% 4.9%;
  --primary: 221.2 83.2% 53.3%;
  --primary-foreground: 210 40% 98%;
  --secondary: 210 40% 96.1%;
  --muted: 210 40% 96.1%;
  --accent: 210 40% 96.1%;
  --destructive: 0 84.2% 60.2%;
  --border: 214.3 31.8% 91.4%;
  --ring: 221.2 83.2% 53.3%;
  --sidebar: 222.2 47.4% 11.2%;
  --sidebar-foreground: 210 40% 98%;
}

.dark {
  --background: 222.2 84% 4.9%;
  --foreground: 210 40% 98%;
  /* ... dark mode tokens */
}
\`\`\`

4.2 Component Variants (button.tsx example)
\`\`\`typescript
const buttonVariants = cva(
  "inline-flex items-center justify-center ...",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground",
        outline: "border border-input bg-background hover:bg-accent",
        secondary: "bg-secondary text-secondary-foreground",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
        icon: "h-10 w-10",
      },
    },
  }
);
\`\`\`

================================================================================
5. ROUTING CONFIGURATION
================================================================================

5.1 Route Definitions (App.tsx)
\`\`\`typescript
const routes = [
  { path: "/login", element: <LoginPage /> },
  { path: "/", element: <ProtectedRoute><Index /></ProtectedRoute> },
  { path: "/org-chart", element: <ProtectedRoute><OrgChart /></ProtectedRoute> },
  { path: "/finance/risks", element: <ProtectedRoute><FinanceRisks /></ProtectedRoute> }, // Includes Policies & Procedures tab
  { path: "/finance/audits", element: <ProtectedRoute><FinanceAudits /></ProtectedRoute> },
  { path: "/finance/compliance", element: <ProtectedRoute><FinanceCompliance /></ProtectedRoute> },
  { path: "/finance/feedback", element: <ProtectedRoute><FinanceFeedback /></ProtectedRoute> },
  { path: "/finance/enforcements", element: <ProtectedRoute><FinanceEnforcements /></ProtectedRoute> },
  { path: "/documentation", element: <ProtectedRoute><Documentation /></ProtectedRoute> },
  // Microapp routes...
];
\`\`\`

================================================================================
6. DATA MODELS
================================================================================

6.1 Risk Item
\`\`\`typescript
interface RiskItem {
  id: string;
  description: string;
  level: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Open' | 'In Progress' | 'Mitigated' | 'Closed';
  owner: string;
  dueDate: string;
  domain: string;
  department: string;
}
\`\`\`

6.2 Audit Item
\`\`\`typescript
interface AuditItem {
  id: string;
  title: string;
  status: 'Scheduled' | 'In Progress' | 'Completed' | 'Cancelled';
  deadline: string;
  owner: string;
  priority: 'Low' | 'Medium' | 'High';
  domain: string;
  department: string;
}
\`\`\`

6.3 Compliance Item
\`\`\`typescript
interface ComplianceItem {
  id: string;
  description: string;
  status: 'Open' | 'In Progress' | 'Resolved' | 'Closed';
  category: string;
  owner: string;
  domain: string;
  department: string;
  relatedAuditId?: string;
  relatedRiskId?: string;
}
\`\`\`

================================================================================
7. PDF GENERATION
================================================================================

7.1 jsPDF Implementation
\`\`\`typescript
import { jsPDF } from 'jspdf';

const generatePDF = (title: string, content: string) => {
  const doc = new jsPDF();
  const lines = doc.splitTextToSize(content, 180);
  
  let y = 20;
  const pageHeight = doc.internal.pageSize.height;
  
  lines.forEach((line: string) => {
    if (y > pageHeight - 20) {
      doc.addPage();
      y = 20;
    }
    doc.text(line, 15, y);
    y += 7;
  });
  
  doc.save(\`\${title}.pdf\`);
};
\`\`\`

================================================================================
8. PERFORMANCE CONSIDERATIONS
================================================================================

8.1 Memoization
- Use useMemo for filtered data calculations
- Use useCallback for event handlers passed to children
- Implement React.memo for pure presentational components

8.2 Code Splitting
- Lazy load microapp pages
- Dynamic imports for documentation content

8.3 State Management
- Keep state as local as possible
- Lift state only when necessary for sharing
- Use Context for truly global state (auth, theme)

================================================================================
9. SECURITY CONSIDERATIONS
================================================================================

9.1 Client-Side Security
- Route protection via ProtectedRoute component
- Role-based UI rendering
- Input sanitization for search/filter inputs

9.2 Future Considerations (with Backend)
- JWT token management
- Row-level security in database
- API request authentication
- Session timeout handling
`;

const qaTestCasesContent = `
QA TEST CASES DOCUMENT
Finance Compliance Department Dashboard
Version 1.0 | Date: ${new Date().toLocaleDateString()}

================================================================================
TEST SUITE 1: AUTHENTICATION
================================================================================

TC-AUTH-001: Valid Admin Login
Priority: Critical
Preconditions: User is on login page
Steps:
1. Enter email: admin@financehub.com
2. Enter password: admin123
3. Click "Sign in" button
Expected Result: User is redirected to dashboard, sees "Sarah Chen" in header
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-AUTH-002: Valid Department Head Login
Priority: Critical
Preconditions: User is on login page
Steps:
1. Enter email: head@financehub.com
2. Enter password: head123
3. Click "Sign in" button
Expected Result: User is redirected to dashboard, sees "Michael Torres" in header
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-AUTH-003: Valid Staff Login
Priority: Critical
Preconditions: User is on login page
Steps:
1. Enter email: staff@financehub.com
2. Enter password: staff123
3. Click "Sign in" button
Expected Result: User is redirected to dashboard, sees "Emily Johnson" in header
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-AUTH-004: Invalid Credentials
Priority: High
Preconditions: User is on login page
Steps:
1. Enter email: invalid@test.com
2. Enter password: wrongpass
3. Click "Sign in" button
Expected Result: Error toast "Invalid email or password" appears
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-AUTH-005: Quick Login Buttons
Priority: Medium
Preconditions: User is on login page
Steps:
1. Click "Login as Admin" button
Expected Result: User is logged in as Admin without entering credentials
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-AUTH-006: Logout Functionality
Priority: Critical
Preconditions: User is logged in
Steps:
1. Click user avatar in header
2. Click "Log out" from dropdown
Expected Result: User is redirected to login page
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-AUTH-007: Protected Route Access
Priority: Critical
Preconditions: User is not logged in
Steps:
1. Navigate directly to /finance/risks
Expected Result: User is redirected to login page
Status: ☐ Pass ☐ Fail ☐ Blocked

================================================================================
TEST SUITE 2: VIEW MODE TOGGLE
================================================================================

TC-VIEW-001: Admin View Mode Toggle Visibility
Priority: High
Preconditions: User is logged in as Admin
Steps:
1. Observe user menu area
Expected Result: View mode toggle (Department/Individual) is visible
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-VIEW-002: Department Head View Mode Toggle
Priority: High
Preconditions: User is logged in as Department Head
Steps:
1. Observe user menu area
Expected Result: View mode toggle is visible
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-VIEW-003: Staff View Mode Toggle Hidden
Priority: High
Preconditions: User is logged in as Staff
Steps:
1. Observe user menu area
Expected Result: View mode toggle is NOT visible
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-VIEW-004: Toggle to Individual View
Priority: Critical
Preconditions: User is Admin, view mode is "Department"
Steps:
1. Click the view mode toggle switch
Expected Result: View mode changes to "Individual", badge updates
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-VIEW-005: Individual View Filtering - Action Center
Priority: Critical
Preconditions: User is Admin, view mode is "Individual"
Steps:
1. Navigate to dashboard
2. Observe Action Center widget
Expected Result: Only items assigned to current user are shown
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-VIEW-006: Individual View Filtering - Quick Stats
Priority: High
Preconditions: User is Admin, view mode is "Individual"
Steps:
1. Navigate to dashboard
2. Observe Quick Stats metrics
Expected Result: Metrics reflect only user's assigned items
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-VIEW-007: Individual View Filtering - Review Queue
Priority: High
Preconditions: User is Admin, view mode is "Individual"
Steps:
1. Navigate to dashboard
2. Observe Review Queue widget
Expected Result: Only items assigned to current user are shown
Status: ☐ Pass ☐ Fail ☐ Blocked

================================================================================
TEST SUITE 3: ROLE IMPERSONATION
================================================================================

TC-IMP-001: Admin Impersonation Menu Visibility
Priority: High
Preconditions: User is logged in as Admin
Steps:
1. Click user avatar dropdown
Expected Result: "Impersonate Role" submenu is visible
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-IMP-002: Non-Admin Impersonation Hidden
Priority: High
Preconditions: User is logged in as Department Head
Steps:
1. Click user avatar dropdown
Expected Result: "Impersonate Role" submenu is NOT visible
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-IMP-003: Impersonate Department Head
Priority: Critical
Preconditions: User is Admin
Steps:
1. Click user avatar dropdown
2. Hover over "Impersonate Role"
3. Click "Department Head"
Expected Result: Role badge changes, permissions update
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-IMP-004: Impersonate Staff
Priority: Critical
Preconditions: User is Admin
Steps:
1. Click user avatar dropdown
2. Hover over "Impersonate Role"
3. Click "Staff"
Expected Result: Role badge shows "Staff", view toggle hidden
Status: ☐ Pass ☐ Fail ☐ Blocked

================================================================================
TEST SUITE 4: NAVIGATION
================================================================================

TC-NAV-001: Sidebar Navigation - All Sections
Priority: Critical
Preconditions: User is logged in
Steps:
1. Click each sidebar navigation item in sequence
Expected Result: Each page loads correctly without errors
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-NAV-002: Active State Indication
Priority: Medium
Preconditions: User is logged in
Steps:
1. Click "Risk Management" in sidebar
Expected Result: Risk Management nav item shows active styling
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-NAV-003: Return to Dashboard Link
Priority: High
Preconditions: User is on Risk Management page
Steps:
1. Click "Back to Dashboard" link
Expected Result: User is navigated to main dashboard
Status: ☐ Pass ☐ Fail ☐ Blocked

================================================================================
TEST SUITE 5: FINANCE DOMAIN TABS
================================================================================

TC-TAB-001: Risk Management Main Tabs
Priority: High
Preconditions: User is on Risk Management page
Steps:
1. Verify main tabs: Risks, Policies & Procedures
Expected Result: Both main tabs are present and clickable
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-TAB-002: Risk Domain Sub-Tabs
Priority: High
Preconditions: User is on Risk Management page, Risks tab selected
Steps:
1. Verify domain tabs: All Finance, Business Continuity, Accounts Receivable, Budget vs Actual, Service Contracts
Expected Result: All 5 domain tabs are present and clickable
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-TAB-003: Tab Filtering
Priority: Critical
Preconditions: User is on Risk Management page, Risks tab selected
Steps:
1. Click "Business Continuity" tab
Expected Result: Only risks with domain "Business Continuity" are shown
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-TAB-004: Filter Summary Chips
Priority: Medium
Preconditions: User clicks "Accounts Receivable" tab
Steps:
1. Observe filter summary area
Expected Result: Chips show "Dept=Finance" and "Domain=Accounts Receivable"
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-TAB-005: Policies & Procedures Tab
Priority: High
Preconditions: User is on Risk Management page
Steps:
1. Click "Policies & Procedures" tab
2. Verify category tabs appear (All Documents, Financial Controls, Budget Management, etc.)
3. Verify policy list displays correctly
Expected Result: Policies tab shows documents with category filtering
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-TAB-006: Metric Update on Tab Change
Priority: Critical
Preconditions: User is on Audit Management page
Steps:
1. Note the metrics displayed
2. Click "Financial Statements" tab
3. Note the new metrics
Expected Result: Metrics update to reflect filtered data
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-TAB-007: Compliance Nested Tabs
Priority: High
Preconditions: User is on Compliance page
Steps:
1. Verify primary tabs (Compliance Items, CAPA, Citations)
2. Click "CAPA" primary tab
3. Verify domain tabs appear
Expected Result: Both tab levels function correctly
Status: ☐ Pass ☐ Fail ☐ Blocked

================================================================================
TEST SUITE 6: DATA DISPLAY
================================================================================

TC-DATA-001: Risk List Columns
Priority: High
Preconditions: User is on Risk Management page
Steps:
1. Observe the risk data table
Expected Result: Columns include ID, Description, Level, Status, Owner, Due Date, Domain, Actions
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-DATA-002: Status Badge Colors
Priority: Medium
Preconditions: Risk list is displayed
Steps:
1. Observe status badges
Expected Result: Colors match: Open=yellow, In Progress=blue, Mitigated=green
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-DATA-003: Priority Indicators
Priority: Medium
Preconditions: Audit list is displayed
Steps:
1. Observe priority column
Expected Result: High=red, Medium=yellow, Low=green indicators
Status: ☐ Pass ☐ Fail ☐ Blocked

================================================================================
TEST SUITE 7: DEEP LINKING
================================================================================

TC-LINK-001: Open in RiskGuard
Priority: High
Preconditions: User is on Risk Management page
Steps:
1. Click "Open in RiskGuard" for any risk
Expected Result: Toast confirms navigation, redirects to RiskGuard page
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-LINK-002: Open in AuditPro
Priority: High
Preconditions: User is on Audit Management page
Steps:
1. Click "Open in AuditPro" for any audit
Expected Result: Toast confirms navigation, redirects to AuditPro page
Status: ☐ Pass ☐ Fail ☐ Blocked

================================================================================
TEST SUITE 8: DOCUMENTATION
================================================================================

TC-DOC-001: Documentation Page Access
Priority: High
Preconditions: User is logged in
Steps:
1. Click "Documentation" in sidebar
Expected Result: Documentation page loads with all 4 documents
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-DOC-002: PRD Download
Priority: Critical
Preconditions: User is on Documentation page
Steps:
1. Click "Download PDF" on PRD card
Expected Result: PRD.pdf downloads successfully
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-DOC-003: TDD Download
Priority: Critical
Preconditions: User is on Documentation page
Steps:
1. Click "Download PDF" on TDD card
Expected Result: TDD.pdf downloads successfully
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-DOC-004: Document Tab Navigation
Priority: Medium
Preconditions: User is on Documentation page
Steps:
1. Click each document tab
Expected Result: Content switches for each tab without errors
Status: ☐ Pass ☐ Fail ☐ Blocked

================================================================================
TEST SUITE 9: RESPONSIVE DESIGN
================================================================================

TC-RESP-001: Tablet View
Priority: Medium
Preconditions: Browser width set to 768px
Steps:
1. Navigate through all pages
Expected Result: Layout adjusts appropriately, all content accessible
Status: ☐ Pass ☐ Fail ☐ Blocked

TC-RESP-002: Desktop View
Priority: High
Preconditions: Browser width set to 1920px
Steps:
1. Navigate through all pages
Expected Result: Full layout displays correctly with sidebar
Status: ☐ Pass ☐ Fail ☐ Blocked

================================================================================
DEFECT TRACKING
================================================================================

| Defect ID | Test Case | Severity | Description | Status |
|-----------|-----------|----------|-------------|--------|
|           |           |          |             |        |
|           |           |          |             |        |
|           |           |          |             |        |

================================================================================
TEST EXECUTION SUMMARY
================================================================================

Total Test Cases: 45
Passed: ___
Failed: ___
Blocked: ___
Not Executed: ___

Tested By: ________________
Date: ________________
Sign-off: ________________
`;

const uatTestCasesContent = `
USER ACCEPTANCE TEST CASES
Finance Compliance Department Dashboard
Version 1.0 | Date: ${new Date().toLocaleDateString()}

================================================================================
INTRODUCTION
================================================================================

Purpose: Validate that the Finance Compliance Department Dashboard meets business requirements and is ready for production deployment.

Test Environment: Staging/UAT Environment
Test Period: [To be filled]
UAT Lead: [To be filled]
Business Stakeholders: [To be filled]

================================================================================
UAT SCENARIO 1: ADMIN/COMPLIANCE HEAD WORKFLOW
================================================================================

Business Context: As the Compliance Head, I need to monitor all finance compliance activities across the department and be able to drill down into individual team member workloads.

---

UAT-1.1: Complete Admin Login and Dashboard Overview
User Story: As an Admin, I want to log in and see a complete overview of all Finance department activities.

Acceptance Criteria:
☐ Can log in with admin credentials
☐ Dashboard displays all departmental KPIs
☐ Can see all 5 management sections in navigation
☐ User name and role badge are displayed correctly

Test Steps:
1. Navigate to application URL
2. Enter admin credentials (admin@financehub.com / admin123)
3. Verify dashboard loads completely
4. Check all metrics are populated
5. Verify navigation sidebar shows all sections

Expected Outcome: Full dashboard visibility with department-wide data
Actual Outcome: _________________________________
Status: ☐ Pass ☐ Fail | Tested By: __________ | Date: __________

---

UAT-1.2: View Mode Toggle Functionality
User Story: As an Admin, I want to toggle between department and individual view to see either all work or just my assignments.

Acceptance Criteria:
☐ Toggle switch is visible and functional
☐ Department view shows all items
☐ Individual view filters to current user only
☐ All dashboard widgets respect the toggle

Test Steps:
1. Log in as Admin
2. Confirm default view is "Department"
3. Click the view mode toggle
4. Verify view changes to "Individual"
5. Check Action Center shows only user's items
6. Check Quick Stats reflect personal metrics
7. Check Review Queue is filtered

Expected Outcome: View mode affects all dashboard components
Actual Outcome: _________________________________
Status: ☐ Pass ☐ Fail | Tested By: __________ | Date: __________

---

UAT-1.3: Role Impersonation for Support
User Story: As an Admin, I want to impersonate other roles to troubleshoot issues or understand team member experiences.

Acceptance Criteria:
☐ Can access impersonation menu
☐ Can switch to Department Head role
☐ Can switch to Staff role
☐ Permissions update accordingly
☐ Can return to Admin role

Test Steps:
1. Log in as Admin
2. Click user menu dropdown
3. Select "Impersonate Role" > "Staff"
4. Verify role badge updates
5. Verify view toggle disappears (Staff doesn't have toggle)
6. Impersonate back to "Admin"
7. Verify full permissions restored

Expected Outcome: Seamless role switching with appropriate permission changes
Actual Outcome: _________________________________
Status: ☐ Pass ☐ Fail | Tested By: __________ | Date: __________

================================================================================
UAT SCENARIO 2: DEPARTMENT HEAD WORKFLOW
================================================================================

Business Context: As a Department Head, I manage my team's compliance activities and need visibility into both team performance and my own assignments.

---

UAT-2.1: Department Head Access and Permissions
User Story: As a Department Head, I want appropriate access to manage my team's work.

Acceptance Criteria:
☐ Can log in with department head credentials
☐ Can access all management sections
☐ View toggle is available
☐ Cannot access impersonation feature

Test Steps:
1. Navigate to login page
2. Enter department head credentials
3. Verify dashboard access
4. Confirm view toggle is present
5. Open user menu and verify no impersonation option

Expected Outcome: Appropriate department-level access
Actual Outcome: _________________________________
Status: ☐ Pass ☐ Fail | Tested By: __________ | Date: __________

---

UAT-2.2: Monitoring Team Risk Activities
User Story: As a Department Head, I want to review all team risks by finance domain.

Acceptance Criteria:
☐ Can access Risk Management section
☐ Can switch between Risks and Policies & Procedures tabs
☐ Can filter risks by finance domains (Business Continuity, Accounts Receivable, etc.)
☐ Can view risk details
☐ Can deep-link to RiskGuard

Test Steps:
1. Navigate to Risk Management
2. Verify "Risks" tab is selected by default
3. Review the "All Finance" domain tab
4. Click "Business Continuity" domain tab
5. Verify filter chips update
6. Click "Open in RiskGuard" on a risk item
7. Verify navigation works correctly
8. Click "Policies & Procedures" main tab
9. Verify policy documents are displayed

Expected Outcome: Complete risk visibility with domain filtering and integrated policies access
Actual Outcome: _________________________________
Status: ☐ Pass ☐ Fail | Tested By: __________ | Date: __________

---

UAT-2.3: Switching to Individual View
User Story: As a Department Head, I want to see only my personal assignments when needed.

Acceptance Criteria:
☐ Toggle works correctly
☐ Personal items are clearly identified
☐ Metrics update to reflect personal stats
☐ Can toggle back to department view

Test Steps:
1. Confirm department view is active
2. Toggle to individual view
3. Verify items filter to personal assignments
4. Check metrics reflect personal data
5. Toggle back to department view
6. Confirm full visibility returns

Expected Outcome: Smooth transition between views
Actual Outcome: _________________________________
Status: ☐ Pass ☐ Fail | Tested By: __________ | Date: __________

================================================================================
UAT SCENARIO 3: STAFF MEMBER WORKFLOW
================================================================================

Business Context: As a Staff member, I focus on my assigned tasks and need a clear view of my responsibilities.

---

UAT-3.1: Staff Login and Individual View
User Story: As a Staff member, I want to see only my assigned work.

Acceptance Criteria:
☐ Can log in with staff credentials
☐ Dashboard shows personal metrics only
☐ No view toggle visible
☐ All widgets show personal items

Test Steps:
1. Log in with staff credentials (staff@financehub.com / staff123)
2. Verify dashboard loads
3. Confirm no view toggle is visible
4. Verify Action Center shows personal assignments
5. Verify Quick Stats reflect personal metrics

Expected Outcome: Focused personal view without toggle option
Actual Outcome: _________________________________
Status: ☐ Pass ☐ Fail | Tested By: __________ | Date: __________

---

UAT-3.2: Working with Assigned Audits
User Story: As a Staff member, I want to manage my assigned audit tasks.

Acceptance Criteria:
☐ Can access Audit Management section
☐ See only assigned audits
☐ Can view audit details
☐ Can open in AuditPro

Test Steps:
1. Navigate to Audit Management
2. Verify only assigned audits are visible
3. Review audit list columns
4. Click on an audit for details
5. Click "Open in AuditPro"

Expected Outcome: Complete audit workflow for assigned items
Actual Outcome: _________________________________
Status: ☐ Pass ☐ Fail | Tested By: __________ | Date: __________

---

UAT-3.3: Compliance Item Navigation
User Story: As a Staff member, I want to track my compliance items across domains.

Acceptance Criteria:
☐ Can access Compliance Tracking
☐ See nested tabs (Compliance Items, CAPA, Citations)
☐ Domain filtering works
☐ Personal items correctly filtered

Test Steps:
1. Navigate to Compliance Tracking
2. Click through primary tabs
3. Select a domain filter
4. Verify items update
5. Navigate to CAPA tab
6. Verify domain tabs are available

Expected Outcome: Complete compliance visibility with filtering
Actual Outcome: _________________________________
Status: ☐ Pass ☐ Fail | Tested By: __________ | Date: __________

---

UAT-3.4: Policies & Procedures Access
User Story: As a Staff member, I want to access policies and procedures relevant to my work.

Acceptance Criteria:
☐ Can access Risk Management section
☐ Can click on "Policies & Procedures" tab
☐ Can filter by category (Financial Controls, Budget Management, etc.)
☐ Can view, download, and access policy documents

Test Steps:
1. Navigate to Risk Management
2. Click "Policies & Procedures" tab
3. Verify policy list is displayed
4. Click different category tabs
5. Verify policies filter correctly
6. Use view/download actions on a document

Expected Outcome: Complete access to policies within Risk Management
Actual Outcome: _________________________________
Status: ☐ Pass ☐ Fail | Tested By: __________ | Date: __________

================================================================================
UAT SCENARIO 4: CROSS-FUNCTIONAL WORKFLOWS
================================================================================

---

UAT-4.1: End-to-End Risk to Compliance Flow
User Story: As any user, I want to trace relationships between risks and compliance items.

Acceptance Criteria:
☐ Risks show related compliance items
☐ Can navigate between related items
☐ Context is preserved during navigation

Test Steps:
1. Navigate to Risk Management
2. Select a risk with related items
3. Click to view related compliance item
4. Navigate back to original risk
5. Verify context is maintained

Expected Outcome: Seamless cross-referencing between modules
Actual Outcome: _________________________________
Status: ☐ Pass ☐ Fail | Tested By: __________ | Date: __________

---

UAT-4.2: Dashboard Widget Interactions
User Story: As any user, I want dashboard widgets to help me prioritize work.

Acceptance Criteria:
☐ Action Center shows urgent items first
☐ Review Queue allows quick actions
☐ Upcoming Deadlines shows calendar view
☐ Clicking items navigates correctly

Test Steps:
1. Review Action Center priorities
2. Click on a high-priority action
3. Review Review Queue items
4. Click approve/reject on an item
5. Check Upcoming Deadlines display

Expected Outcome: Interactive dashboard enabling quick actions
Actual Outcome: _________________________________
Status: ☐ Pass ☐ Fail | Tested By: __________ | Date: __________

================================================================================
UAT SCENARIO 5: DOCUMENTATION ACCESS
================================================================================

---

UAT-5.1: Accessing Project Documentation
User Story: As any user, I want to access and download project documentation.

Acceptance Criteria:
☐ Documentation section is accessible from sidebar
☐ All 4 documents are available (PRD, TDD, QA, UAT)
☐ Can view document content in tabs
☐ Can download PDFs

Test Steps:
1. Click "Documentation" in sidebar
2. Verify all 4 document cards are visible
3. Click on "PRD" tab to view content
4. Click "Download PDF" button
5. Verify PDF downloads successfully
6. Repeat for other documents

Expected Outcome: Complete documentation available for download
Actual Outcome: _________________________________
Status: ☐ Pass ☐ Fail | Tested By: __________ | Date: __________

================================================================================
UAT SIGN-OFF
================================================================================

Test Completion Summary:
- Total Scenarios: 5
- Total Test Cases: 15
- Passed: ___
- Failed: ___
- Blocked: ___

Outstanding Defects:
| ID | Description | Severity | Status |
|----|-------------|----------|--------|
|    |             |          |        |

Business Acceptance:
☐ All critical functionality works as expected
☐ User experience meets business requirements
☐ No critical or high-severity defects outstanding
☐ Documentation is complete and accurate

Sign-off:

UAT Lead: _________________ Date: _________
Business Owner: _________________ Date: _________
IT Manager: _________________ Date: _________
Compliance Head: _________________ Date: _________

Comments:
_______________________________________________
_______________________________________________
_______________________________________________

APPROVED FOR PRODUCTION: ☐ Yes ☐ No

If No, list required changes:
_______________________________________________
_______________________________________________
`;

const systemPromptContent = `
SYSTEM PROMPT FOR AI GENERATION
Finance Compliance Department Dashboard
Version 1.0 | Date: ${new Date().toLocaleDateString()}

================================================================================
COMPLETE SYSTEM PROMPT FOR RECREATING THE APPLICATION
================================================================================

Use the following prompt to regenerate this Finance Compliance Department Dashboard application using Lovable AI or similar AI-powered development tools.

================================================================================
PROMPT START
================================================================================

Build a comprehensive Finance Compliance Department Dashboard using React, TypeScript, Tailwind CSS, and shadcn/ui components. The application should be a single-page application (SPA) with the following specifications:

---

1. TECHNOLOGY STACK

- React 18+ with TypeScript
- Vite for build tooling
- Tailwind CSS for styling with custom design tokens
- shadcn/ui component library (Radix primitives)
- React Router DOM for navigation
- React Context API for state management
- Recharts for data visualization
- Lucide React for icons
- jsPDF for PDF generation

---

2. APPLICATION STRUCTURE

Create the following file structure:
- src/components/auth/ - Authentication components (ProtectedRoute, UserMenu)
- src/components/dashboard/ - Dashboard widgets (ActionCenter, MetricTiles, QuickStats, ReviewQueue, UpcomingDeadlines, DataTable, MicroApps, KPIManager)
- src/components/layout/ - Layout components (Header, Sidebar)
- src/components/ui/ - shadcn/ui components
- src/contexts/ - React contexts (AuthContext)
- src/pages/ - Page components
- src/pages/finance/ - Finance management pages
- src/pages/microapps/ - Microapp placeholder pages

---

3. AUTHENTICATION SYSTEM

Implement a mock authentication system with:

Demo Accounts:
- Admin: admin@financehub.com / admin123
- Department Head: head@financehub.com / head123
- Staff: staff@financehub.com / staff123

Features:
- Email/password login
- Role-based access control (admin, department_head, staff)
- View mode toggle (Department/Individual) for Admin and Department Head
- Role impersonation for Admin only
- Protected routes that redirect to login if not authenticated
- Session persistence across page refreshes

AuthContext should provide:
- user object with id, email, name, role, department, avatar
- login/logout functions
- isAuthenticated boolean
- viewMode state (department/individual)
- setViewMode function
- impersonateRole function (admin only)

---

4. NAVIGATION & LAYOUT

Left Sidebar with:
- Dashboard Home link
- Org Chart link
- Finance Dashboard section header
- Finance management links:
  - Risk Management (links to /finance/risks with Risks and Policies & Procedures tabs)
  - Audit Management (links to /finance/audits)
  - Compliance Tracking (links to /finance/compliance)
  - Feedback Management (links to /finance/feedback)
  - Enforcement Management (links to /finance/enforcements)
- Documentation link
- Microapps section with links to: RiskGuard, AuditPro, ComplianceConnect, FeedbackHub, EnforcePoint, CitaPro

Header with:
- App title/logo
- View mode toggle (for Admin/Department Head)
- Role impersonation dropdown (for Admin)
- User menu with logout option

---

5. DASHBOARD HOME PAGE (/)

Create a main dashboard with the following widgets:

Quick Stats (4 metric cards):
- Open Risks (count with change indicator)
- Pending Audits (count with change indicator)
- Compliance Rate (percentage with change indicator)
- Active CAPA (count with change indicator)

Metric Tiles:
- Visual representation of key metrics with icons and progress indicators

Action Center:
- Priority action items requiring attention
- Filtered by assignment in Individual view
- Shows all department items in Department view

Review Queue:
- Items awaiting review/approval
- Quick action buttons (approve, reject, review)

Upcoming Deadlines:
- Deadline calendar for next 30 days
- Color-coded by urgency (overdue: red, due soon: yellow, upcoming: green)

---

6. FINANCE MANAGEMENT PAGES

6.1 Risk Management (/finance/risks)
Two main tabs:
- Risks Tab: Display finance risks with domain tabs (All Finance, Business Continuity, Accounts Receivable, Budget vs Actual, Service Contracts)
- Policies & Procedures Tab: Display policies, procedures, and guidelines with category tabs (All, Financial Controls, Budget Management, Accounts Payable, Accounts Receivable, Compliance)

Risk data fields: ID, Description, Risk Level (High/Medium/Low), Status, Owner, Due Date, Domain
Policy data fields: ID, Title, Type (Policy/Procedure/Guideline), Category, Status, Version, Owner, Effective Date, Review Date, Actions

6.2 Audit Management (/finance/audits)
- Display all Finance department audits
- 10 domain tab filters
- Audit data fields: ID, Title, Status, Deadline, Owner, Priority, Domain
- Link to AuditPro microapp

6.3 Compliance Tracking (/finance/compliance)
Nested tab structure:
- Primary tabs: Compliance Items, CAPA, Citations
- Secondary tabs: Finance domain filters per primary tab
- Cross-module linking to related audits and risks

6.4 Feedback Management (/finance/feedback)
- Display feedback items by domain
- Track SLA compliance
- Enable escalation workflows
- Link to FeedbackHub microapp

6.5 Enforcement Management (/finance/enforcements)
- Display enforcement actions and cases
- Track resolution status
- Link to related compliance findings
- Link to EnforcePoint microapp

---

7. FINANCE DOMAINS (Filter Options)

Implement the following finance domains as tab filters across all management pages:
- Business Continuity
- Financial Statements
- Accounts Receivable
- Billing Compliance
- External Reporting
- Internal Reporting
- Financial Hardship
- Billing Checklist
- Budget vs Actual
- Balance Sheet
- Billing Management
- Service Contracts

---

8. MICROAPP PLACEHOLDER PAGES

Create simple placeholder pages for each microapp:
- RiskGuard (/microapps/riskguard)
- AuditPro (/microapps/auditpro)
- ComplianceConnect (/microapps/complianceconnect)
- FeedbackHub (/microapps/feedbackhub)
- EnforcePoint (/microapps/enforcepoint)
- CitaPro (/microapps/citapro)

Each should show: app name, description, "Return to Dashboard" button

---

9. ORGANIZATION CHART (/org-chart)

Create an organization chart page showing:
- Company hierarchy visualization
- Department structure
- Employee cards with name, title, and avatar
- Interactive expand/collapse functionality

---

10. DOCUMENTATION PAGE (/documentation)

Create a documentation page with downloadable PDFs:
- Product Requirements Document (PRD)
- Technical Design Document (TDD)
- QA Test Cases
- UAT Test Cases
- System Prompt (this document)

Features:
- Card grid showing all documents
- Tab-based document preview
- PDF download functionality using jsPDF
- Version and last updated information

---

11. VIEW MODE FUNCTIONALITY

All dashboard widgets and data tables must respect the view mode:
- Department View: Shows all items in the Finance department
- Individual View: Shows only items assigned to the current user

The view mode toggle should be visible only for Admin and Department Head roles.

---

12. UI/UX REQUIREMENTS

- Responsive design for desktop and tablet
- Dark/light mode support using CSS custom properties
- Consistent color coding for status indicators:
  - High priority/risk: red/destructive
  - Medium priority: yellow/warning
  - Low priority: green/success
  - Pending: blue/primary
- Smooth transitions and hover effects
- Toast notifications for user actions
- Loading states for data fetching
- Empty states for no data scenarios

---

13. DATA TABLE COMPONENT

Create a reusable DataTable component with:
- Sortable columns
- Row click handlers
- Status badges with color coding
- Action buttons (view, edit, open in microapp)
- Responsive design
- Empty state handling

---

14. MOCK DATA

Generate realistic mock data for:
- 15-20 risks across different domains
- 15-20 audits with various statuses
- 20-25 compliance items
- 10-15 CAPA items
- 10-15 citations
- 15-20 feedback items
- 10-15 enforcement cases
- 15-20 policies and procedures

Each item should have:
- Unique ID
- Descriptive title/description
- Appropriate status
- Assigned owner (using demo user names)
- Relevant dates
- Domain/category assignment

---

15. DESIGN TOKENS

Define CSS custom properties in index.css for:
- Background colors
- Foreground/text colors
- Primary, secondary, accent colors
- Muted colors for disabled states
- Destructive colors for errors/warnings
- Border and ring colors
- Sidebar-specific colors
- Card backgrounds and shadows

Support both light and dark modes with appropriate color adjustments.

---

16. ROUTING STRUCTURE

/login - Login page (public)
/ - Dashboard home (protected)
/org-chart - Organization chart (protected)
/finance/risks - Risk Management (protected)
/finance/audits - Audit Management (protected)
/finance/compliance - Compliance Tracking (protected)
/finance/feedback - Feedback Management (protected)
/finance/enforcements - Enforcement Management (protected)
/documentation - Documentation (protected)
/microapps/[appname] - Microapp pages (protected)
/* - 404 Not Found page

---

17. COMPONENT PATTERNS

Follow these patterns throughout:
- Use shadcn/ui components for all UI elements
- Implement proper TypeScript interfaces for all data types
- Use useMemo for filtered data based on view mode
- Implement toast notifications for user feedback
- Add proper aria labels for accessibility
- Use semantic HTML elements
- Keep components focused and reusable

---

================================================================================
PROMPT END
================================================================================

NOTES FOR AI GENERATION:

1. Start by setting up the base project structure with Vite, React, and TypeScript.

2. Install and configure shadcn/ui components as needed.

3. Implement authentication first, then build out the navigation and layout.

4. Create reusable components before building page-specific features.

5. Use mock data that feels realistic and covers edge cases.

6. Ensure all view mode and role-based filtering works correctly.

7. Test the responsive design on different screen sizes.

8. Verify PDF generation works for all documents.

================================================================================
VERSION HISTORY
================================================================================

v1.0 - Initial release
- Complete dashboard with all management sections
- Authentication with role-based access
- View mode toggle functionality
- PDF documentation generation
- Policies & Procedures tab under Risk Management

================================================================================
`;

const documents = [
  {
    id: 'prd',
    title: 'Product Requirements Document (PRD)',
    description: 'Complete functional and non-functional requirements for the Finance Dashboard',
    content: prdContent,
    icon: FileText,
    version: '1.0',
    lastUpdated: new Date().toLocaleDateString(),
  },
  {
    id: 'tdd',
    title: 'Technical Design Document (TDD)',
    description: 'System architecture, component design, and implementation details',
    content: tddContent,
    icon: FileText,
    version: '1.0',
    lastUpdated: new Date().toLocaleDateString(),
  },
  {
    id: 'qa',
    title: 'QA Test Cases',
    description: 'Comprehensive quality assurance test cases for all features',
    content: qaTestCasesContent,
    icon: FileText,
    version: '1.0',
    lastUpdated: new Date().toLocaleDateString(),
  },
  {
    id: 'uat',
    title: 'UAT Test Cases',
    description: 'User acceptance testing scenarios for business validation',
    content: uatTestCasesContent,
    icon: FileText,
    version: '1.0',
    lastUpdated: new Date().toLocaleDateString(),
  },
  {
    id: 'prompt',
    title: 'System Prompt',
    description: 'Complete AI generation prompt to recreate this application',
    content: systemPromptContent,
    icon: FileText,
    version: '1.0',
    lastUpdated: new Date().toLocaleDateString(),
  },
];

const Documentation = () => {
  const generatePDF = (title: string, content: string) => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 15;
    const maxWidth = pageWidth - margin * 2;
    
    doc.setFontSize(10);
    doc.setFont('courier', 'normal');
    
    const lines = content.split('\n');
    let y = margin;
    
    lines.forEach((line) => {
      const wrappedLines = doc.splitTextToSize(line || ' ', maxWidth);
      
      wrappedLines.forEach((wrappedLine: string) => {
        if (y > pageHeight - margin) {
          doc.addPage();
          y = margin;
        }
        doc.text(wrappedLine, margin, y);
        y += 5;
      });
    });
    
    doc.save(`${title.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Documentation</h1>
            <p className="text-muted-foreground">Project documentation and test cases</p>
          </div>
          <Badge variant="outline">Finance Compliance Dashboard v1.0</Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {documents.map((doc) => (
            <Card key={doc.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <doc.icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{doc.title}</CardTitle>
                      <CardDescription className="text-sm mt-1">{doc.description}</CardDescription>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Badge variant="secondary" className="text-xs">v{doc.version}</Badge>
                    <span>Updated: {doc.lastUpdated}</span>
                  </div>
                  <Button 
                    size="sm" 
                    onClick={() => generatePDF(doc.title, doc.content)}
                    className="gap-2"
                  >
                    <Download className="h-4 w-4" />
                    Download PDF
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Document Preview</CardTitle>
            <CardDescription>View document contents before downloading</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="prd" className="w-full">
              <TabsList className="grid grid-cols-5 w-full max-w-xl">
                <TabsTrigger value="prd">PRD</TabsTrigger>
                <TabsTrigger value="tdd">TDD</TabsTrigger>
                <TabsTrigger value="qa">QA Tests</TabsTrigger>
                <TabsTrigger value="uat">UAT Tests</TabsTrigger>
                <TabsTrigger value="prompt">Prompt</TabsTrigger>
              </TabsList>
              {documents.map((doc) => (
                <TabsContent key={doc.id} value={doc.id} className="mt-4">
                  <ScrollArea className="h-[500px] w-full rounded-md border p-4">
                    <pre className="text-xs font-mono whitespace-pre-wrap text-foreground">
                      {doc.content}
                    </pre>
                  </ScrollArea>
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Documentation;
