import { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { Plus, MoreVertical, MessageSquare, Pencil, Trash2, ChevronDown, ChevronRight, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface TeamMember {
  id: string;
  name: string;
  title: string;
  email: string;
  initials: string;
  color: string;
  managerId: string | null;
  expanded?: boolean;
}

const colorOptions = [
  { value: 'bg-primary', label: 'Blue' },
  { value: 'bg-success', label: 'Green' },
  { value: 'bg-warning', label: 'Yellow' },
  { value: 'bg-destructive', label: 'Red' },
  { value: 'bg-info', label: 'Cyan' },
  { value: 'bg-secondary', label: 'Gray' },
];

const initialMembers: TeamMember[] = [
  { id: '1', name: 'Sarah Chen', title: 'Chief Compliance Officer', email: 'sarah.chen@company.com', initials: 'SC', color: 'bg-primary', managerId: null },
  { id: '2', name: 'Michael Torres', title: 'Senior Compliance Manager', email: 'michael.torres@company.com', initials: 'MT', color: 'bg-info', managerId: '1' },
  { id: '3', name: 'Emily Watson', title: 'HIPAA Compliance Lead', email: 'emily.watson@company.com', initials: 'EW', color: 'bg-success', managerId: '2' },
  { id: '4', name: 'David Kim', title: 'Digital Content Analyst', email: 'david.kim@company.com', initials: 'DK', color: 'bg-info', managerId: '2' },
  { id: '5', name: 'Jessica Brown', title: 'Policy Administrator', email: 'jessica.brown@company.com', initials: 'JB', color: 'bg-primary', managerId: '2' },
  { id: '6', name: 'Robert Garcia', title: 'Audit Coordinator', email: 'robert.garcia@company.com', initials: 'RG', color: 'bg-secondary', managerId: '2' },
  { id: '7', name: 'Amanda Lee', title: 'Risk Analyst', email: 'amanda.lee@company.com', initials: 'AL', color: 'bg-warning', managerId: '3' },
  { id: '8', name: 'James Wilson', title: 'Print Compliance Specialist', email: 'james.wilson@company.com', initials: 'JW', color: 'bg-info', managerId: '4' },
];

interface MemberFormData {
  name: string;
  title: string;
  email: string;
  managerId: string;
  color: string;
}

const emptyFormData: MemberFormData = {
  name: '',
  title: '',
  email: '',
  managerId: '',
  color: 'bg-primary',
};

function getInitials(name: string): string {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

export default function OrgChart() {
  const [members, setMembers] = useState<TeamMember[]>(initialMembers);
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set(['1', '2', '3', '4']));
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isMessageDialogOpen, setIsMessageDialogOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);
  const [formData, setFormData] = useState<MemberFormData>(emptyFormData);
  const [messageText, setMessageText] = useState('');
  const { toast } = useToast();

  const breadcrumbs = [
    { label: 'Master Compliance', href: '/master' },
    { label: 'Finance Compliance Dashboard', href: '/' },
    { label: 'Organization Chart' },
  ];

  const resetForm = () => {
    setFormData(emptyFormData);
    setSelectedMember(null);
  };

  const handleAddClick = () => {
    resetForm();
    setIsAddDialogOpen(true);
  };

  const handleEditClick = (member: TeamMember) => {
    setSelectedMember(member);
    setFormData({
      name: member.name,
      title: member.title,
      email: member.email,
      managerId: member.managerId || '',
      color: member.color,
    });
    setIsEditDialogOpen(true);
  };

  const handleDeleteClick = (member: TeamMember) => {
    setSelectedMember(member);
    setIsDeleteDialogOpen(true);
  };

  const handleMessageClick = (member: TeamMember) => {
    setSelectedMember(member);
    setMessageText('');
    setIsMessageDialogOpen(true);
  };

  const handleAddSubmit = () => {
    if (!formData.name || !formData.title || !formData.email) {
      toast({
        title: 'Validation Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    const newMember: TeamMember = {
      id: `member-${Date.now()}`,
      name: formData.name,
      title: formData.title,
      email: formData.email,
      initials: getInitials(formData.name),
      color: formData.color,
      managerId: formData.managerId || null,
    };

    setMembers([...members, newMember]);
    setIsAddDialogOpen(false);
    resetForm();
    toast({
      title: 'Member Added',
      description: `${newMember.name} has been added to the organization`,
    });
  };

  const handleEditSubmit = () => {
    if (!selectedMember) return;

    if (!formData.name || !formData.title || !formData.email) {
      toast({
        title: 'Validation Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    const updatedMembers = members.map((member) =>
      member.id === selectedMember.id
        ? {
            ...member,
            name: formData.name,
            title: formData.title,
            email: formData.email,
            initials: getInitials(formData.name),
            color: formData.color,
            managerId: formData.managerId || null,
          }
        : member
    );

    setMembers(updatedMembers);
    setIsEditDialogOpen(false);
    resetForm();
    toast({
      title: 'Member Updated',
      description: `${formData.name}'s profile has been updated`,
    });
  };

  const handleDeleteConfirm = () => {
    if (!selectedMember) return;

    // Also reassign children to parent or null
    const updatedMembers = members
      .filter((m) => m.id !== selectedMember.id)
      .map((m) =>
        m.managerId === selectedMember.id
          ? { ...m, managerId: selectedMember.managerId }
          : m
      );

    setMembers(updatedMembers);
    setIsDeleteDialogOpen(false);
    toast({
      title: 'Member Removed',
      description: `${selectedMember.name} has been removed from the organization`,
    });
    resetForm();
  };

  const handleSendMessage = () => {
    if (!selectedMember || !messageText.trim()) {
      toast({
        title: 'Validation Error',
        description: 'Please enter a message',
        variant: 'destructive',
      });
      return;
    }

    toast({
      title: 'Message Sent',
      description: `Your message has been sent to ${selectedMember.name}`,
    });
    setIsMessageDialogOpen(false);
    setMessageText('');
  };

  const toggleNode = (id: string) => {
    const newExpanded = new Set(expandedNodes);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedNodes(newExpanded);
  };

  const getChildren = (parentId: string | null) => {
    return members.filter((m) => m.managerId === parentId);
  };

  const renderOrgNode = (member: TeamMember) => {
    const children = getChildren(member.id);
    const hasChildren = children.length > 0;
    const isExpanded = expandedNodes.has(member.id);

    return (
      <div key={member.id} className="flex flex-col items-center">
        {/* Node Card */}
        <div className="relative bg-card border border-border rounded-xl p-4 min-w-[200px] shadow-sm">
          <div className="flex items-start gap-3">
            <div className={cn('w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium text-white shrink-0', member.color)}>
              {member.initials}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold text-foreground truncate">{member.name}</h3>
              <p className="text-xs text-muted-foreground truncate">{member.title}</p>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="w-6 h-6 shrink-0">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => handleMessageClick(member)}>
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Send Message
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleEditClick(member)}>
                  <Pencil className="w-4 h-4 mr-2" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => handleDeleteClick(member)}
                  className="text-destructive focus:text-destructive"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <p className="text-xs text-info mt-2 truncate">{member.email}</p>
          
          {/* Expand/Collapse button */}
          {hasChildren && (
            <button
              onClick={() => toggleNode(member.id)}
              className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-6 h-6 bg-card border border-border rounded-full flex items-center justify-center hover:bg-accent transition-colors"
            >
              {isExpanded ? (
                <ChevronDown className="w-4 h-4 text-muted-foreground" />
              ) : (
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              )}
            </button>
          )}
        </div>

        {/* Connector line */}
        {hasChildren && isExpanded && (
          <>
            <div className="w-px h-6 bg-border" />
            <div className="flex gap-8">
              {children.map((child, index) => (
                <div key={child.id} className="flex flex-col items-center">
                  {/* Horizontal connector */}
                  <div className="relative">
                    <div className="w-px h-4 bg-border" />
                    {children.length > 1 && (
                      <div
                        className={cn(
                          'absolute top-0 h-px bg-border',
                          index === 0 ? 'left-0 right-0 w-[calc(100%+2rem)]' : '',
                          index === children.length - 1 ? 'right-0 left-0 w-[calc(100%+2rem)] -translate-x-full' : '',
                          index > 0 && index < children.length - 1 ? 'left-1/2 right-1/2 w-[calc(200%+4rem)] -translate-x-1/2' : ''
                        )}
                      />
                    )}
                  </div>
                  {renderOrgNode(child)}
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    );
  };

  const rootMembers = getChildren(null);

  const MemberFormFields = () => (
    <div className="grid gap-4 py-4">
      <div className="grid gap-2">
        <Label htmlFor="name">Full Name *</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="e.g., John Smith"
        />
      </div>

      <div className="grid gap-2">
        <Label htmlFor="title">Job Title *</Label>
        <Input
          id="title"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          placeholder="e.g., Compliance Manager"
        />
      </div>

      <div className="grid gap-2">
        <Label htmlFor="email">Email *</Label>
        <Input
          id="email"
          type="email"
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          placeholder="e.g., john.smith@company.com"
        />
      </div>

      <div className="grid gap-2">
        <Label htmlFor="manager">Reports To</Label>
        <Select
          value={formData.managerId || 'none'}
          onValueChange={(value) => setFormData({ ...formData, managerId: value === 'none' ? '' : value })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select manager (optional)" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">No Manager (Top Level)</SelectItem>
            {members
              .filter((m) => m.id !== selectedMember?.id)
              .map((m) => (
                <SelectItem key={m.id} value={m.id}>
                  {m.name} - {m.title}
                </SelectItem>
              ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-2">
        <Label htmlFor="color">Avatar Color</Label>
        <Select
          value={formData.color}
          onValueChange={(value) => setFormData({ ...formData, color: value })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {colorOptions.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                <div className="flex items-center gap-2">
                  <div className={cn('w-4 h-4 rounded-full', option.value)} />
                  {option.label}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Sidebar activeItem="org-chart" onNavigate={() => {}} />
      <div className="ml-64">
        <Header breadcrumbs={breadcrumbs} />
        <main className="p-6">
          {/* Page Header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Organization Chart</h1>
              <p className="text-muted-foreground">Marketing Compliance Team Structure</p>
            </div>
            <Button onClick={handleAddClick} className="gap-2">
              <Plus className="w-4 h-4" />
              Add Member
            </Button>
          </div>

          {/* Org Chart */}
          <div className="bg-card rounded-xl border border-border p-8 mb-6 overflow-x-auto">
            <div className="flex justify-center min-w-max py-4">
              {rootMembers.map((member) => renderOrgNode(member))}
            </div>
          </div>

          {/* Team Directory */}
          <div className="bg-card rounded-xl border border-border p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-foreground">Team Directory</h2>
              <span className="text-sm text-muted-foreground">{members.length} members</span>
            </div>
            <div className="space-y-2">
              {members.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center justify-between p-3 rounded-lg hover:bg-accent/50 transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <div className={cn('w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium text-white', member.color)}>
                      {member.initials}
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-foreground">{member.name}</h3>
                      <p className="text-xs text-muted-foreground">{member.title}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-8 h-8"
                      onClick={() => handleMessageClick(member)}
                    >
                      <MessageSquare className="w-4 h-4 text-muted-foreground" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-8 h-8"
                      onClick={() => handleEditClick(member)}
                    >
                      <Pencil className="w-4 h-4 text-muted-foreground" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-8 h-8"
                      onClick={() => handleDeleteClick(member)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>

      {/* Add Member Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add Team Member</DialogTitle>
            <DialogDescription>
              Add a new member to the organization chart.
            </DialogDescription>
          </DialogHeader>
          <MemberFormFields />
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddSubmit}>Add Member</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Member Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Edit Team Member</DialogTitle>
            <DialogDescription>
              Update the member's information.
            </DialogDescription>
          </DialogHeader>
          <MemberFormFields />
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleEditSubmit}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Team Member</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove "{selectedMember?.name}" from the organization? 
              Their direct reports will be reassigned to their manager.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Send Message Dialog */}
      <Dialog open={isMessageDialogOpen} onOpenChange={setIsMessageDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Send Message</DialogTitle>
            <DialogDescription>
              Send a message to {selectedMember?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="flex items-center gap-3 p-3 bg-secondary/50 rounded-lg">
              <div className={cn('w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium text-white', selectedMember?.color)}>
                {selectedMember?.initials}
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">{selectedMember?.name}</p>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <Mail className="w-3 h-3" />
                  {selectedMember?.email}
                </p>
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="message">Message</Label>
              <textarea
                id="message"
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                placeholder="Type your message here..."
                className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsMessageDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSendMessage}>Send Message</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
