import { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { ActionCenter } from '@/components/dashboard/ActionCenter';
import { ReviewQueue } from '@/components/dashboard/ReviewQueue';
import { QuickStats } from '@/components/dashboard/QuickStats';
import { MicroApps } from '@/components/dashboard/MicroApps';
import { useAuth } from '@/contexts/AuthContext';
import { Badge } from '@/components/ui/badge';
import { Building2, UserCircle } from 'lucide-react';

export default function FinanceDashboard() {
  const [activeNav, setActiveNav] = useState('dashboard');
  const { user, viewMode } = useAuth();

  const breadcrumbs = [
    { label: 'Master Compliance', href: '/master' },
    { label: 'Finance Compliance Dashboard' },
  ];

  const getViewModeLabel = () => {
    if (viewMode === 'department') {
      return (
        <Badge variant="outline" className="gap-1 bg-primary/10 text-primary border-primary/30">
          <Building2 className="w-3 h-3" />
          Department View
        </Badge>
      );
    }
    return (
      <Badge variant="outline" className="gap-1 bg-info/10 text-info border-info/30">
        <UserCircle className="w-3 h-3" />
        Individual View - {user?.name}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <Sidebar activeItem={activeNav} onNavigate={setActiveNav} />

      {/* Main Content */}
      <div className="ml-64">
        {/* Header */}
        <Header breadcrumbs={breadcrumbs} />

        {/* Page Content */}
        <main className="p-6">
          {/* Page Title */}
          <div className="mb-6 flex items-start justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground mb-1">Finance Compliance Master Dashboard</h1>
              <p className="text-muted-foreground">Finance Compliance Dashboard</p>
            </div>
            {getViewModeLabel()}
          </div>

          {/* Main Grid Layout */}
          <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-6">
            {/* Left Column - Main Content */}
            <div className="space-y-6">
              {/* Action Center */}
              <ActionCenter />

              {/* Review Queue */}
              <ReviewQueue />

              {/* Micro Apps */}
              <MicroApps />
            </div>

            {/* Right Column - Stats Panel */}
            <div className="hidden xl:block">
              <QuickStats />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
