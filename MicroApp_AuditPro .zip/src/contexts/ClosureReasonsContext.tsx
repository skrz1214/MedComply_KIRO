import React, { createContext, useContext, useState, ReactNode } from 'react';
import { ClosureReason, ClosureReasonCategory, ClosureReasonAuditLog } from '@/types/cap';

interface ClosureReasonsContextType {
  reasons: ClosureReason[];
  auditLogs: ClosureReasonAuditLog[];
  addReason: (reason: Omit<ClosureReason, 'id' | 'createdAt' | 'updatedAt' | 'isSystemDefault'>) => void;
  updateReason: (id: string, updates: Partial<ClosureReason>) => void;
  deleteReason: (id: string) => void;
  toggleReasonActive: (id: string) => void;
  reorderReasons: (reasonIds: string[]) => void;
  getActiveReasons: () => ClosureReason[];
  getReasonsByCategory: (category: ClosureReasonCategory) => ClosureReason[];
}

const defaultReasons: ClosureReason[] = [
  // Not a finding
  {
    id: '1',
    name: 'Informational Note / Opportunity for Improvement (No Finding)',
    category: 'not_a_finding',
    requiresJustification: false,
    requiresEvidence: false,
    requiresApproval: false,
    isActive: true,
    sortOrder: 1,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '2',
    name: 'Best Practice Recommendation Only (Optional)',
    category: 'not_a_finding',
    requiresJustification: false,
    requiresEvidence: false,
    requiresApproval: false,
    isActive: true,
    sortOrder: 2,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  // Invalidated/false positive
  {
    id: '3',
    name: 'Finding Invalidated (False Positive)',
    category: 'invalidated_false_positive',
    requiresJustification: true,
    requiresEvidence: true,
    requiresApproval: false,
    isActive: true,
    sortOrder: 3,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '4',
    name: 'Compliance Evidence Found After Review (Control Effective)',
    category: 'invalidated_false_positive',
    requiresJustification: true,
    requiresEvidence: true,
    requiresApproval: false,
    isActive: true,
    sortOrder: 4,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  // Not applicable/out of scope
  {
    id: '5',
    name: 'Not Applicable to Site/Service Line',
    category: 'not_applicable_out_of_scope',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: false,
    isActive: true,
    sortOrder: 5,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '6',
    name: 'Out of Audit Scope (Wrong Area/Owner)',
    category: 'not_applicable_out_of_scope',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: false,
    isActive: true,
    sortOrder: 6,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '7',
    name: 'Outside Audit Period (Non-systemic)',
    category: 'not_applicable_out_of_scope',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: false,
    isActive: true,
    sortOrder: 7,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  // Duplicate/merged
  {
    id: '8',
    name: 'Duplicate of Existing Finding',
    category: 'duplicate_merged',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: false,
    isActive: true,
    sortOrder: 8,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '9',
    name: 'Merged Into Parent Finding (Covered Elsewhere)',
    category: 'duplicate_merged',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: false,
    isActive: true,
    sortOrder: 9,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '10',
    name: 'Superseded by New/Revised Finding',
    category: 'duplicate_merged',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: false,
    isActive: true,
    sortOrder: 10,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  // Already corrected
  {
    id: '11',
    name: 'Corrected Immediately During Audit (Spot Fix) — Verified',
    category: 'already_corrected',
    requiresJustification: true,
    requiresEvidence: true,
    requiresApproval: false,
    isActive: true,
    sortOrder: 11,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '12',
    name: 'Corrected Prior to Audit Item Creation — Verified',
    category: 'already_corrected',
    requiresJustification: true,
    requiresEvidence: true,
    requiresApproval: false,
    isActive: true,
    sortOrder: 12,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  // One-time anomaly
  {
    id: '13',
    name: 'Isolated One-Time Documentation Miss (No Process Gap)',
    category: 'one_time_anomaly',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: false,
    isActive: true,
    sortOrder: 13,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '14',
    name: 'Isolated Human Error (No Trend Identified)',
    category: 'one_time_anomaly',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: false,
    isActive: true,
    sortOrder: 14,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '15',
    name: 'Temporary Operational Disruption Resolved (No Ongoing Gap)',
    category: 'one_time_anomaly',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: false,
    isActive: true,
    sortOrder: 15,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  // Compensating controls
  {
    id: '16',
    name: 'Compensating Controls Sufficient (No Additional Action Required)',
    category: 'compensating_controls',
    requiresJustification: true,
    requiresEvidence: true,
    requiresApproval: true,
    approverRole: 'Compliance Officer / Quality Leader',
    isActive: true,
    sortOrder: 16,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  // Risk accepted
  {
    id: '17',
    name: 'Risk Accepted by Management (No Remediation Planned)',
    category: 'risk_accepted',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: true,
    approverRole: 'Compliance Officer + Executive Sponsor',
    isActive: true,
    sortOrder: 17,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '18',
    name: 'Risk Accepted — Patient Safety/Quality Impact Reviewed',
    category: 'risk_accepted',
    requiresJustification: true,
    requiresEvidence: true,
    requiresApproval: true,
    approverRole: 'Quality Director / Patient Safety Officer',
    isActive: true,
    sortOrder: 18,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '19',
    name: 'Risk Accepted — Privacy/Security Impact Reviewed',
    category: 'risk_accepted',
    requiresJustification: true,
    requiresEvidence: true,
    requiresApproval: true,
    approverRole: 'Privacy Officer / Security Officer',
    isActive: true,
    sortOrder: 19,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  // Vendor responsibility
  {
    id: '20',
    name: 'Transferred to Vendor / Third-Party Remediation Workflow',
    category: 'vendor_responsibility_transferred',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: true,
    approverRole: 'Vendor Risk Manager / Compliance',
    isActive: true,
    sortOrder: 20,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  // Reclassified
  {
    id: '21',
    name: 'Converted to IT Ticket / Incident / Problem Record',
    category: 'reclassified_to_other_workflow',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: false,
    isActive: true,
    sortOrder: 21,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '22',
    name: 'Converted to HR / Training / Competency Workflow',
    category: 'reclassified_to_other_workflow',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: false,
    isActive: true,
    sortOrder: 22,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '23',
    name: 'Converted to Patient Safety Event / Grievance Workflow',
    category: 'reclassified_to_other_workflow',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: false,
    isActive: true,
    sortOrder: 23,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  // Administrative closure
  {
    id: '24',
    name: 'Service Line Discontinued / Facility Closed (Administrative Closure)',
    category: 'administrative_closure',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: true,
    approverRole: 'Compliance Officer / Executive Sponsor',
    isActive: true,
    sortOrder: 24,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '25',
    name: 'Audit Withdrawn / Replaced by Another Review (Administrative Closure)',
    category: 'administrative_closure',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: true,
    approverRole: 'Audit Director / Compliance Officer',
    isActive: true,
    sortOrder: 25,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  // Other
  {
    id: '26',
    name: 'Other (User-Defined Reason)',
    category: 'other',
    requiresJustification: true,
    requiresEvidence: false,
    requiresApproval: true,
    approverRole: 'Compliance Officer',
    isActive: true,
    sortOrder: 26,
    isSystemDefault: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
];

const ClosureReasonsContext = createContext<ClosureReasonsContextType | undefined>(undefined);

export function ClosureReasonsProvider({ children }: { children: ReactNode }) {
  const [reasons, setReasons] = useState<ClosureReason[]>(defaultReasons);
  const [auditLogs, setAuditLogs] = useState<ClosureReasonAuditLog[]>([]);

  const addAuditLog = (
    reasonId: string, 
    action: ClosureReasonAuditLog['action'], 
    performedBy: string,
    changes?: Record<string, { from: unknown; to: unknown }>
  ) => {
    const log: ClosureReasonAuditLog = {
      id: Date.now().toString(),
      reasonId,
      action,
      performedBy,
      performedAt: new Date().toISOString(),
      changes,
    };
    setAuditLogs(prev => [...prev, log]);
  };

  const addReason = (reason: Omit<ClosureReason, 'id' | 'createdAt' | 'updatedAt' | 'isSystemDefault'>) => {
    const newReason: ClosureReason = {
      ...reason,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isSystemDefault: false,
    };
    setReasons(prev => [...prev, newReason]);
    addAuditLog(newReason.id, 'created', reason.createdBy || 'System');
  };

  const updateReason = (id: string, updates: Partial<ClosureReason>) => {
    const currentReason = reasons.find(r => r.id === id);
    if (!currentReason) return;

    const changes: Record<string, { from: unknown; to: unknown }> = {};
    Object.keys(updates).forEach(key => {
      const k = key as keyof ClosureReason;
      if (currentReason[k] !== updates[k]) {
        changes[key] = { from: currentReason[k], to: updates[k] };
      }
    });

    setReasons(prev => prev.map(r => 
      r.id === id 
        ? { ...r, ...updates, updatedAt: new Date().toISOString() } 
        : r
    ));
    
    if (Object.keys(changes).length > 0) {
      addAuditLog(id, 'updated', updates.updatedBy || 'System', changes);
    }
  };

  const deleteReason = (id: string) => {
    const reason = reasons.find(r => r.id === id);
    if (!reason || reason.isSystemDefault) return;
    
    setReasons(prev => prev.filter(r => r.id !== id));
    addAuditLog(id, 'deleted', 'System');
  };

  const toggleReasonActive = (id: string) => {
    const reason = reasons.find(r => r.id === id);
    if (!reason) return;

    const newActive = !reason.isActive;
    updateReason(id, { isActive: newActive });
    addAuditLog(id, newActive ? 'activated' : 'deactivated', 'System');
  };

  const reorderReasons = (reasonIds: string[]) => {
    setReasons(prev => {
      const reordered = [...prev];
      reasonIds.forEach((id, index) => {
        const reason = reordered.find(r => r.id === id);
        if (reason) {
          reason.sortOrder = index + 1;
        }
      });
      return reordered.sort((a, b) => a.sortOrder - b.sortOrder);
    });
  };

  const getActiveReasons = (): ClosureReason[] => {
    return reasons.filter(r => r.isActive).sort((a, b) => a.sortOrder - b.sortOrder);
  };

  const getReasonsByCategory = (category: ClosureReasonCategory): ClosureReason[] => {
    return reasons.filter(r => r.category === category && r.isActive)
      .sort((a, b) => a.sortOrder - b.sortOrder);
  };

  return (
    <ClosureReasonsContext.Provider value={{
      reasons,
      auditLogs,
      addReason,
      updateReason,
      deleteReason,
      toggleReasonActive,
      reorderReasons,
      getActiveReasons,
      getReasonsByCategory,
    }}>
      {children}
    </ClosureReasonsContext.Provider>
  );
}

export function useClosureReasons() {
  const context = useContext(ClosureReasonsContext);
  if (!context) {
    throw new Error('useClosureReasons must be used within a ClosureReasonsProvider');
  }
  return context;
}
