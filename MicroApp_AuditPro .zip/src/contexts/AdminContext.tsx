import React, { createContext, useContext, useState, ReactNode } from 'react';
import {
  AdminSettings,
  DepartmentConfig,
  StatusConfig,
  PhaseConfig,
  DefaultAssignee,
  ActionTemplate,
  EvidencePolicy,
  PeriodicRule,
  NotificationConfig,
  IntegrationConfig,
  PermissionMatrix,
  SettingsChangeLog,
  UserRoleV2,
  MetricsPolicy,
} from '@/types/admin';

interface AdminContextType {
  settings: AdminSettings;
  updateSettings: (updates: Partial<AdminSettings>) => void;
  logChange: (log: Omit<SettingsChangeLog, 'id' | 'timestamp' | 'userId' | 'userName'>) => void;
  updateDepartment: (id: string, updates: Partial<DepartmentConfig>) => void;
  addDepartment: (dept: Omit<DepartmentConfig, 'id' | 'createdAt' | 'updatedAt'>) => void;
  deleteDepartment: (id: string) => void;
  updateStatus: (id: string, updates: Partial<StatusConfig>) => void;
  updatePhase: (id: string, updates: Partial<PhaseConfig>) => void;
  updateDefaultAssignee: (phase: string, updates: Partial<Pick<DefaultAssignee, 'internalRole' | 'externalRole'>>) => void;
  updateActionTemplate: (id: string, updates: Partial<ActionTemplate>) => void;
  addActionTemplate: (template: Omit<ActionTemplate, 'id' | 'createdAt' | 'updatedAt'>) => void;
  deleteActionTemplate: (id: string) => void;
  updateEvidencePolicy: (updates: Partial<EvidencePolicy>) => void;
  updatePeriodicRule: (id: string, updates: Partial<PeriodicRule>) => void;
  updateNotification: (id: string, updates: Partial<NotificationConfig>) => void;
  updateIntegration: (id: string, updates: Partial<IntegrationConfig>) => void;
  updatePermission: (role: UserRoleV2, permissionId: string, isAllowed: boolean) => void;
  addChangeLog: (log: Omit<SettingsChangeLog, 'id' | 'timestamp'>) => void;
}

const initialDepartments: DepartmentConfig[] = [
  { id: '1', name: 'Nursing', code: 'NUR', isComplianceOwner: false, createdAt: '2024-01-01', updatedAt: '2024-01-01' },
  { id: '2', name: 'Quality Assurance', code: 'QA', isComplianceOwner: true, createdAt: '2024-01-01', updatedAt: '2024-01-01' },
  { id: '3', name: 'Administration', code: 'ADM', isComplianceOwner: false, createdAt: '2024-01-01', updatedAt: '2024-01-01' },
  { id: '4', name: 'Laboratory', code: 'LAB', isComplianceOwner: false, createdAt: '2024-01-01', updatedAt: '2024-01-01' },
  { id: '5', name: 'Pharmacy', code: 'PHR', isComplianceOwner: false, createdAt: '2024-01-01', updatedAt: '2024-01-01' },
  { id: '6', name: 'Radiology', code: 'RAD', isComplianceOwner: false, createdAt: '2024-01-01', updatedAt: '2024-01-01' },
];

const initialStatuses: StatusConfig[] = [
  { id: '1', code: 'draft', label: 'Draft', color: 'gray', isActive: true, sortOrder: 1, allowedTransitions: ['in_progress'] },
  { id: '2', code: 'in_progress', label: 'In Progress', color: 'blue', isActive: true, sortOrder: 2, allowedTransitions: ['pending_review'] },
  { id: '3', code: 'pending_review', label: 'Pending Review', color: 'yellow', isActive: true, sortOrder: 3, allowedTransitions: ['ready_for_audit', 'review_failed'] },
  { id: '4', code: 'review_failed', label: 'Review Failed', color: 'red', isActive: true, sortOrder: 4, allowedTransitions: ['pending_review'] },
  { id: '5', code: 'ready_for_audit', label: 'Ready for Audit', color: 'green', isActive: true, sortOrder: 5, allowedTransitions: ['qa_review', 'complete'] },
  { id: '6', code: 'qa_review', label: 'QA Review', color: 'purple', isActive: true, sortOrder: 6, allowedTransitions: ['complete', 'cap_required'] },
  { id: '7', code: 'cap_required', label: 'CAP Required', color: 'orange', isActive: true, sortOrder: 7, allowedTransitions: ['complete'] },
  { id: '8', code: 'complete', label: 'Complete', color: 'green', isActive: true, sortOrder: 8, allowedTransitions: [] },
];

const initialPhases: PhaseConfig[] = [
  { id: '1', code: 'draft', label: 'Draft', icon: 'FileEdit', requiredEvidence: false, requiredActions: false, gatingRules: [], isActive: true, sortOrder: 1 },
  { id: '2', code: 'pre_audit', label: 'Pre-Audit', icon: 'ClipboardCheck', requiredEvidence: false, requiredActions: false, gatingRules: [], isActive: true, sortOrder: 2 },
  { id: '3', code: 'pre_audit_review', label: 'Pre-Audit Review', icon: 'UserCheck', requiredEvidence: false, requiredActions: false, gatingRules: [], isActive: true, sortOrder: 3 },
  { id: '4', code: 'overview', label: 'Audit Overview', icon: 'ClipboardList', requiredEvidence: false, requiredActions: false, gatingRules: [], isActive: true, sortOrder: 4 },
  { id: '5', code: 'evidence_collection', label: 'Evidence Collection', icon: 'Search', requiredEvidence: true, requiredActions: false, gatingRules: [], isActive: true, sortOrder: 5 },
  { id: '6', code: 'evaluation', label: 'Evaluation', icon: 'FileCheck', requiredEvidence: false, requiredActions: true, gatingRules: [], isActive: true, sortOrder: 6 },
  { id: '7', code: 'internal_review', label: 'Internal Review', icon: 'UserCheck', requiredEvidence: false, requiredActions: false, gatingRules: [], isActive: true, sortOrder: 7 },
  { id: '8', code: 'remediation_required', label: 'Remediation Required', icon: 'AlertTriangle', requiredEvidence: false, requiredActions: true, gatingRules: [], isActive: true, sortOrder: 8 },
  { id: '9', code: 'closure_cap', label: 'Closure & CAP', icon: 'Shield', requiredEvidence: false, requiredActions: false, gatingRules: [], isActive: true, sortOrder: 9 },
  { id: '10', code: 'cap_active', label: 'CAP Active', icon: 'Activity', requiredEvidence: false, requiredActions: false, gatingRules: [], isActive: true, sortOrder: 10 },
  { id: '11', code: 'pending_verification', label: 'Pending Verification', icon: 'Clock', requiredEvidence: false, requiredActions: false, gatingRules: [], isActive: true, sortOrder: 11 },
  { id: '12', code: 'closed', label: 'Closed', icon: 'CheckCircle2', requiredEvidence: false, requiredActions: false, gatingRules: [], isActive: true, sortOrder: 12 },
];

// Default Assignees: one row per phase × (internal default, external default)
// These are SUGGESTIONS — users can freely override the assignee to anyone.
const initialDefaultAssignees: DefaultAssignee[] = [
  { phase: 'draft', internalRole: 'department_head', externalRole: 'department_head' },
  { phase: 'pre_audit', internalRole: 'department_head', externalRole: 'department_head' },
  { phase: 'pre_audit_review', internalRole: 'department_head', externalRole: 'compliance_head' },
  { phase: 'overview', internalRole: 'department_head', externalRole: 'department_head' },
  { phase: 'evidence_collection', internalRole: 'department_head', externalRole: 'department_head' },
  { phase: 'evaluation', internalRole: 'department_head', externalRole: 'department_head' },
  { phase: 'internal_review', internalRole: 'department_head', externalRole: 'department_head' },
  { phase: 'remediation_required', internalRole: 'department_head', externalRole: 'department_head' },
  { phase: 'closure_cap', internalRole: 'department_head', externalRole: 'compliance_head' },
  { phase: 'cap_active', internalRole: 'department_head', externalRole: 'compliance_head' },
  { phase: 'pending_verification', internalRole: 'department_head', externalRole: 'compliance_head' },
  { phase: 'closed', internalRole: 'department_head', externalRole: 'compliance_head' },
];

const initialActionTemplates: ActionTemplate[] = [
  {
    id: '1',
    name: 'Standard Internal Audit',
    description: 'Default action template for internal audits',
    auditType: 'internal',
    actions: [
      { id: '1', description: 'Review relevant documentation', isRequired: true, sortOrder: 1 },
      { id: '2', description: 'Conduct staff interviews', isRequired: false, sortOrder: 2 },
      { id: '3', description: 'Document findings', isRequired: true, sortOrder: 3 },
      { id: '4', description: 'Prepare summary report', isRequired: true, sortOrder: 4 },
    ],
    isActive: true,
    priority: 1,
    createdAt: '2024-01-01',
    updatedAt: '2024-01-01',
  },
  {
    id: '2',
    name: 'HIPAA Compliance Audit',
    description: 'Action template for HIPAA compliance audits',
    auditType: 'external',
    actions: [
      { id: '1', description: 'Verify staff training completion', isRequired: true, sortOrder: 1 },
      { id: '2', description: 'Review access control logs', isRequired: true, sortOrder: 2 },
      { id: '3', description: 'Audit PHI handling procedures', isRequired: true, sortOrder: 3 },
      { id: '4', description: 'Document compliance gaps', isRequired: true, sortOrder: 4 },
      { id: '5', description: 'Interview key personnel', isRequired: false, sortOrder: 5 },
    ],
    isActive: true,
    priority: 1,
    createdAt: '2024-01-01',
    updatedAt: '2024-01-01',
  },
];

const initialEvidencePolicy: EvidencePolicy = {
  id: '1',
  name: 'Default Evidence Policy',
  allowedFileTypes: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'png', 'jpg', 'jpeg'],
  maxFileSize: 25,
  maxFilesPerPhase: 20,
  requiredPhases: ['evidence_collection'],
  description: 'Standard evidence upload policy for all audits',
  isActive: true,
};

const initialPeriodicRules: PeriodicRule[] = [
  { id: '1', periodicity: 'daily', autoCreateNextInstance: true, advanceNoticeDays: 1, missedScheduleHandling: 'create_overdue', description: 'Daily audit scheduling', isActive: true },
  { id: '2', periodicity: 'weekly', autoCreateNextInstance: true, advanceNoticeDays: 3, missedScheduleHandling: 'create_overdue', description: 'Weekly audit scheduling', isActive: true },
  { id: '3', periodicity: 'monthly', autoCreateNextInstance: true, advanceNoticeDays: 7, missedScheduleHandling: 'notify_only', description: 'Monthly audit scheduling', isActive: true },
  { id: '4', periodicity: 'quarterly', autoCreateNextInstance: true, advanceNoticeDays: 14, missedScheduleHandling: 'notify_only', description: 'Quarterly audit scheduling', isActive: true },
  { id: '5', periodicity: 'annually', autoCreateNextInstance: true, advanceNoticeDays: 30, missedScheduleHandling: 'notify_only', description: 'Annual audit scheduling', isActive: true },
];

const initialNotifications: NotificationConfig[] = [
  { id: '1', trigger: 'audit_assigned', triggerLabel: 'New Audit Assigned', emailEnabled: true, inAppEnabled: true, targetRoles: ['staff', 'department_head'], template: 'You have been assigned a new audit: {{audit_title}}', isActive: true },
  { id: '2', trigger: 'phase_handoff', triggerLabel: 'Phase Handoff', emailEnabled: true, inAppEnabled: true, targetRoles: ['department_head', 'compliance_head'], template: 'Audit {{audit_title}} has been handed off to you for {{phase_name}}', isActive: true },
  { id: '3', trigger: 'review_submitted', triggerLabel: 'Submitted for Review', emailEnabled: true, inAppEnabled: true, targetRoles: ['department_head'], template: 'Audit {{audit_title}} has been submitted for internal review', isActive: true },
  { id: '4', trigger: 'review_rejected', triggerLabel: 'Review Rejected', emailEnabled: true, inAppEnabled: true, targetRoles: ['department_head', 'staff'], template: 'Audit {{audit_title}} has been rejected. Feedback: {{review_notes}}', isActive: true },
  { id: '5', trigger: 'external_routed', triggerLabel: 'External Audit Routed to Compliance', emailEnabled: true, inAppEnabled: true, targetRoles: ['compliance_head'], template: 'External audit {{audit_title}} requires your review and closure decision', isActive: true },
  { id: '6', trigger: 'cap_created', triggerLabel: 'CAP Created', emailEnabled: true, inAppEnabled: true, targetRoles: ['department_head', 'compliance_head'], template: 'A Corrective Action Plan has been created for audit {{audit_title}}', isActive: true },
  { id: '7', trigger: 'audit_completed', triggerLabel: 'Audit Completed', emailEnabled: true, inAppEnabled: true, targetRoles: ['department_head', 'compliance_head', 'admin'], template: 'Audit {{audit_title}} has been completed', isActive: true },
];

const initialIntegrations: IntegrationConfig[] = [
  {
    id: '1',
    name: 'ComplianceConnect CAP Integration',
    type: 'compliance_connect',
    isEnabled: true,
    apiEndpoint: '/api/compliance-connect/cap',
    fieldMappings: [
      { sourceField: 'audit.title', targetField: 'cap.title' },
      { sourceField: 'audit.description', targetField: 'cap.description' },
      { sourceField: 'audit.department', targetField: 'cap.department' },
      { sourceField: 'audit.priority', targetField: 'cap.priority' },
    ],
    retryPolicy: { maxRetries: 3, retryDelaySeconds: 30, exponentialBackoff: true },
    errorLogs: [],
  },
];

const initialPermissionMatrix: PermissionMatrix[] = [
  {
    role: 'staff',
    permissions: [
      { id: '1', resource: 'audit', action: 'view', isAllowed: true },
      { id: '2', resource: 'audit', action: 'create', isAllowed: false },
      { id: '3', resource: 'audit', action: 'edit', isAllowed: false },
      { id: '4', resource: 'evidence', action: 'view', isAllowed: true },
      { id: '5', resource: 'evidence', action: 'upload', isAllowed: false },
      { id: '6', resource: 'actions', action: 'view', isAllowed: true },
      { id: '7', resource: 'actions', action: 'edit', isAllowed: false },
      { id: '8', resource: 'review', action: 'approve', isAllowed: false },
      { id: '9', resource: 'review', action: 'reject', isAllowed: false },
      { id: '10', resource: 'settings', action: 'view', isAllowed: false },
    ],
  },
  {
    role: 'department_head',
    permissions: [
      { id: '1', resource: 'audit', action: 'view', isAllowed: true },
      { id: '2', resource: 'audit', action: 'create', isAllowed: true },
      { id: '3', resource: 'audit', action: 'edit', isAllowed: true },
      { id: '4', resource: 'evidence', action: 'view', isAllowed: true },
      { id: '5', resource: 'evidence', action: 'upload', isAllowed: true },
      { id: '6', resource: 'actions', action: 'view', isAllowed: true },
      { id: '7', resource: 'actions', action: 'edit', isAllowed: true },
      { id: '8', resource: 'review', action: 'approve', isAllowed: true },
      { id: '9', resource: 'review', action: 'reject', isAllowed: true },
      { id: '10', resource: 'settings', action: 'view', isAllowed: false },
    ],
  },
  {
    role: 'compliance_head',
    permissions: [
      { id: '1', resource: 'audit', action: 'view', isAllowed: true },
      { id: '2', resource: 'audit', action: 'create', isAllowed: true },
      { id: '3', resource: 'audit', action: 'edit', isAllowed: true },
      { id: '4', resource: 'evidence', action: 'view', isAllowed: true },
      { id: '5', resource: 'evidence', action: 'upload', isAllowed: true },
      { id: '6', resource: 'actions', action: 'view', isAllowed: true },
      { id: '7', resource: 'actions', action: 'edit', isAllowed: true },
      { id: '8', resource: 'review', action: 'approve', isAllowed: true },
      { id: '9', resource: 'review', action: 'reject', isAllowed: true },
      { id: '10', resource: 'settings', action: 'view', isAllowed: false },
    ],
  },
  {
    role: 'admin',
    permissions: [
      { id: '1', resource: 'audit', action: 'view', isAllowed: true },
      { id: '2', resource: 'audit', action: 'create', isAllowed: true },
      { id: '3', resource: 'audit', action: 'edit', isAllowed: true },
      { id: '4', resource: 'evidence', action: 'view', isAllowed: true },
      { id: '5', resource: 'evidence', action: 'upload', isAllowed: true },
      { id: '6', resource: 'actions', action: 'view', isAllowed: true },
      { id: '7', resource: 'actions', action: 'edit', isAllowed: true },
      { id: '8', resource: 'review', action: 'approve', isAllowed: true },
      { id: '9', resource: 'review', action: 'reject', isAllowed: true },
      { id: '10', resource: 'settings', action: 'view', isAllowed: true },
    ],
  },
];

const initialMetricsPolicy: MetricsPolicy = {
  overdueRateTarget: 10,
  cycleTimeTargetDays: 30,
  cycleTimeByPriority: {
    low: 45,
    medium: 30,
    high: 14,
    critical: 7,
  },
  onTimeCompletionTarget: 90,
  internalReviewTurnaroundDays: 3,
  capRequiredRateTarget: 15,
};

const initialSettings: AdminSettings = {
  departments: initialDepartments,
  statuses: initialStatuses,
  phases: initialPhases,
  defaultAssignees: initialDefaultAssignees,
  actionTemplates: initialActionTemplates,
  evidencePolicy: initialEvidencePolicy,
  periodicRules: initialPeriodicRules,
  notifications: initialNotifications,
  integrations: initialIntegrations,
  permissionMatrix: initialPermissionMatrix,
  changeLogs: [],
  metricsPolicy: initialMetricsPolicy,
};

const AdminContext = createContext<AdminContextType | undefined>(undefined);

export function AdminProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<AdminSettings>(initialSettings);

  const updateSettings = (updates: Partial<AdminSettings>) => {
    setSettings(prev => ({ ...prev, ...updates }));
  };

  const logChange = (log: Omit<SettingsChangeLog, 'id' | 'timestamp' | 'userId' | 'userName'>) => {
    const newLog: SettingsChangeLog = {
      ...log,
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      userId: 'current-user',
      userName: 'Admin User',
    };
    setSettings(prev => ({
      ...prev,
      changeLogs: [newLog, ...prev.changeLogs],
    }));
  };

  const addChangeLog = (log: Omit<SettingsChangeLog, 'id' | 'timestamp'>) => {
    const newLog: SettingsChangeLog = {
      ...log,
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
    };
    setSettings(prev => ({
      ...prev,
      changeLogs: [newLog, ...prev.changeLogs],
    }));
  };

  const updateDepartment = (id: string, updates: Partial<DepartmentConfig>) => {
    setSettings(prev => ({
      ...prev,
      departments: prev.departments.map(d => 
        d.id === id ? { ...d, ...updates, updatedAt: new Date().toISOString() } : d
      ),
    }));
  };

  const addDepartment = (dept: Omit<DepartmentConfig, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newDept: DepartmentConfig = {
      ...dept,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setSettings(prev => ({
      ...prev,
      departments: [...prev.departments, newDept],
    }));
  };

  const deleteDepartment = (id: string) => {
    setSettings(prev => ({
      ...prev,
      departments: prev.departments.filter(d => d.id !== id),
    }));
  };


  const updateStatus = (id: string, updates: Partial<StatusConfig>) => {
    setSettings(prev => ({
      ...prev,
      statuses: prev.statuses.map(s => 
        s.id === id ? { ...s, ...updates } : s
      ),
    }));
  };

  const updatePhase = (id: string, updates: Partial<PhaseConfig>) => {
    setSettings(prev => ({
      ...prev,
      phases: prev.phases.map(p => 
        p.id === id ? { ...p, ...updates } : p
      ),
    }));
  };

  const updateDefaultAssignee = (
    phase: string,
    updates: Partial<Pick<DefaultAssignee, 'internalRole' | 'externalRole'>>
  ) => {
    setSettings(prev => ({
      ...prev,
      defaultAssignees: prev.defaultAssignees.map(a =>
        a.phase === phase ? { ...a, ...updates } : a
      ),
    }));
  };

  const updateActionTemplate = (id: string, updates: Partial<ActionTemplate>) => {
    setSettings(prev => ({
      ...prev,
      actionTemplates: prev.actionTemplates.map(t => 
        t.id === id ? { ...t, ...updates, updatedAt: new Date().toISOString() } : t
      ),
    }));
  };

  const addActionTemplate = (template: Omit<ActionTemplate, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newTemplate: ActionTemplate = {
      ...template,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setSettings(prev => ({
      ...prev,
      actionTemplates: [...prev.actionTemplates, newTemplate],
    }));
  };

  const deleteActionTemplate = (id: string) => {
    setSettings(prev => ({
      ...prev,
      actionTemplates: prev.actionTemplates.filter(t => t.id !== id),
    }));
  };

  const updateEvidencePolicy = (updates: Partial<EvidencePolicy>) => {
    setSettings(prev => ({
      ...prev,
      evidencePolicy: { ...prev.evidencePolicy, ...updates },
    }));
  };

  const updatePeriodicRule = (id: string, updates: Partial<PeriodicRule>) => {
    setSettings(prev => ({
      ...prev,
      periodicRules: prev.periodicRules.map(r => 
        r.id === id ? { ...r, ...updates } : r
      ),
    }));
  };

  const updateNotification = (id: string, updates: Partial<NotificationConfig>) => {
    setSettings(prev => ({
      ...prev,
      notifications: prev.notifications.map(n => 
        n.id === id ? { ...n, ...updates } : n
      ),
    }));
  };

  const updateIntegration = (id: string, updates: Partial<IntegrationConfig>) => {
    setSettings(prev => ({
      ...prev,
      integrations: prev.integrations.map(i => 
        i.id === id ? { ...i, ...updates } : i
      ),
    }));
  };

  const updatePermission = (role: UserRoleV2, permissionId: string, isAllowed: boolean) => {
    setSettings(prev => ({
      ...prev,
      permissionMatrix: prev.permissionMatrix.map(pm => 
        pm.role === role 
          ? {
              ...pm,
              permissions: pm.permissions.map(p => 
                p.id === permissionId ? { ...p, isAllowed } : p
              ),
            }
          : pm
      ),
    }));
  };

  return (
    <AdminContext.Provider value={{
      settings,
      updateSettings,
      logChange,
      updateDepartment,
      addDepartment,
      deleteDepartment,
      updateStatus,
      updatePhase,
      updateDefaultAssignee,
      updateActionTemplate,
      addActionTemplate,
      deleteActionTemplate,
      updateEvidencePolicy,
      updatePeriodicRule,
      updateNotification,
      updateIntegration,
      updatePermission,
      addChangeLog,
    }}>
      {children}
    </AdminContext.Provider>
  );
}

export function useAdmin() {
  const context = useContext(AdminContext);
  if (context === undefined) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
}
