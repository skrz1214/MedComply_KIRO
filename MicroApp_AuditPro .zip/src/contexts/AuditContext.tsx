import React, { createContext, useContext, useState, ReactNode } from 'react';
import { AuditItem, User, UserRole, AuditStatus, AuditAction, AuditPhase, Evidence, PhaseAttachments, PhaseAssignees, AuditHistoryEntry, ClosureType, LinkedItem } from '@/types/audit';

interface AuditContextType {
  audits: AuditItem[];
  currentUser: User;
  users: User[];
  setCurrentUser: (user: User) => void;
  addAudit: (audit: Omit<AuditItem, 'id' | 'createdAt' | 'evidence' | 'phaseAttachments' | 'history'> & { actions?: AuditAction[] }) => void;
  updateAudit: (id: string, updates: Partial<AuditItem>) => void;
  deleteAudit: (id: string) => void;
  addActionItem: (auditId: string, description: string) => void;
  getToDoItems: () => AuditItem[];
  getToReviewItems: () => AuditItem[];
  getPreAuditItems: () => AuditItem[];
  getPreAuditReviewItems: () => AuditItem[];
  getDepartmentAudits: () => AuditItem[];
  getPersonalAudits: () => AuditItem[];
  getAuditHistory: () => AuditItem[];
  submitForReview: (id: string) => void;
  submitPreAuditForReview: (id: string) => void;
  approvePreAudit: (id: string) => void;
  rejectPreAudit: (id: string, notes: string) => void;
  approveAudit: (id: string) => void;
  rejectAudit: (id: string, notes: string) => void;
  closeAudit: (id: string, capRequired: boolean) => void;
  addHistoryEntry: (auditId: string, entry: Omit<AuditHistoryEntry, 'id' | 'performedAt'>) => void;
  addPhaseAttachment: (auditId: string, phase: AuditPhase, evidence: Evidence) => void;
  updatePhaseAssignee: (auditId: string, phase: AuditPhase, userId: string) => void;
  addLinkedItem: (auditId: string, item: Omit<LinkedItem, 'id' | 'linkedAt' | 'linkedBy'>) => void;
  removeLinkedItem: (auditId: string, linkedItemId: string) => void;
}

const mockUsers: User[] = [
  { id: '1', name: 'Sarah Johnson', email: 'sarah@medcomply.com', role: 'department_head', department: 'Nursing' },
  { id: '2', name: 'Michael Chen', email: 'michael@medcomply.com', role: 'staff', department: 'Nursing' },
  { id: '3', name: 'Emily Davis', email: 'emily@medcomply.com', role: 'compliance_head', department: 'Quality Assurance' },
  { id: '4', name: 'Robert Wilson', email: 'robert@medcomply.com', role: 'admin', department: 'Administration' },
];

const emptyPhaseAttachments: PhaseAttachments = {
  draft: [],
  pre_audit: [],
  pre_audit_review: [],
  overview: [],
  evidence_collection: [],
  evaluation: [],
  internal_review: [],
  remediation_required: [],
  closure_cap: [],
  cap_active: [],
  pending_verification: [],
  closed: [],
};

const defaultPhaseAssignees = (userId: string): PhaseAssignees => ({
  draft: userId,
  pre_audit: userId,
  pre_audit_review: userId,
  overview: userId,
  evidence_collection: userId,
  evaluation: userId,
  internal_review: userId,
  remediation_required: userId,
  closure_cap: userId,
  cap_active: userId,
  pending_verification: userId,
  closed: userId,
});

const initialAudits: AuditItem[] = [
  {
    id: '12',
    title: 'Hand Hygiene Compliance Assessment',
    description: 'Pre-audit preparation for quarterly hand hygiene compliance review across all nursing units',
    type: 'internal',
    status: 'pre_audit',
    department: 'Nursing',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2024-01-28',
    dueDate: '2024-03-01',
    priority: 'medium',
    phase: 'pre_audit',
    currentPhase: 'pre_audit',
    isPeriodic: true,
    periodicity: 'quarterly',
    nextScheduledDate: '2024-06-01',
    evidence: [],
    actions: [
      { id: 'pa1', description: 'Gather hand hygiene monitoring equipment list', completed: true, completedAt: '2024-01-29', completedBy: 'Michael Chen' },
      { id: 'pa2', description: 'Identify observation locations and schedule', completed: false },
      { id: 'pa3', description: 'Review previous audit findings and trends', completed: false },
      { id: 'pa4', description: 'Prepare staff notification memo', completed: false },
    ],
    phaseAttachments: {
      draft: [],
      pre_audit: [],
      pre_audit_review: [],
      overview: [],
      evidence_collection: [],
      evaluation: [],
      internal_review: [],
      remediation_required: [],
      closure_cap: [],
      cap_active: [],
      pending_verification: [],
      closed: [],
    },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'h22', action: 'Pre-audit item created', phase: 'pre_audit', performedBy: 'Sarah Johnson', performedAt: '2024-01-28T09:00:00Z' },
    ],
  },
  {
    id: '1',
    title: 'Medication Administration Compliance',
    description: 'Review of medication administration protocols and documentation accuracy',
    type: 'internal',
    status: 'evidence_collection',
    department: 'Nursing',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2024-01-15',
    dueDate: '2024-02-15',
    priority: 'high',
    phase: 'evidence_collection',
    currentPhase: 'evidence_collection',
    isPeriodic: true,
    periodicity: 'quarterly',
    nextScheduledDate: '2024-05-15',
    evidence: [
      { id: 'e1', name: 'MAR_Report_Jan.pdf', type: 'application/pdf', uploadedAt: '2024-01-20', uploadedBy: 'Michael Chen', url: '#' },
    ],
    actions: [
      { id: 'a1', description: 'Review medication administration records', completed: true, completedAt: '2024-01-18', completedBy: 'Michael Chen' },
      { id: 'a2', description: 'Document any discrepancies found', completed: true, completedAt: '2024-01-20', completedBy: 'Michael Chen' },
      { id: 'a3', description: 'Interview nursing staff on protocols', completed: false },
    ],
    phaseAttachments: {
      draft: [],
      pre_audit: [],
      pre_audit_review: [],
      overview: [],
      evidence_collection: [
        { id: 'e1', name: 'MAR_Report_Jan.pdf', type: 'application/pdf', uploadedAt: '2024-01-20', uploadedBy: 'Michael Chen', url: '#' },
      ],
      evaluation: [],
      internal_review: [],
      remediation_required: [],
      closure_cap: [],
      cap_active: [],
      pending_verification: [],
      closed: [],
    },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'h1', action: 'Audit created', phase: 'overview', performedBy: 'Sarah Johnson', performedAt: '2024-01-15T10:00:00Z' },
      { id: 'h2', action: 'Moved to Evidence Collection', phase: 'evidence_collection', performedBy: 'Michael Chen', performedAt: '2024-01-16T09:00:00Z' },
    ],
  },
  {
    id: '2',
    title: 'HIPAA Privacy Assessment',
    description: 'Annual HIPAA compliance assessment for patient data handling',
    type: 'external',
    status: 'internal_review',
    department: 'Nursing',
    assignedTo: '1',
    assignedToName: 'Sarah Johnson',
    createdBy: '4',
    createdAt: '2024-01-10',
    dueDate: '2024-02-28',
    priority: 'critical',
    phase: 'internal_review',
    currentPhase: 'internal_review',
    isPeriodic: true,
    periodicity: 'annually',
    nextScheduledDate: '2025-01-10',
    evidence: [
      { id: 'e2', name: 'Privacy_Training_Completion.xlsx', type: 'application/xlsx', uploadedAt: '2024-01-25', uploadedBy: 'Sarah Johnson', url: '#' },
      { id: 'e3', name: 'Access_Audit_Log.pdf', type: 'application/pdf', uploadedAt: '2024-01-26', uploadedBy: 'Sarah Johnson', url: '#' },
    ],
    actions: [
      { id: 'a4', description: 'Verify staff training completion', completed: true, completedAt: '2024-01-22', completedBy: 'Sarah Johnson' },
      { id: 'a5', description: 'Review access control logs', completed: true, completedAt: '2024-01-24', completedBy: 'Sarah Johnson' },
      { id: 'a6', description: 'Document compliance gaps', completed: true, completedAt: '2024-01-26', completedBy: 'Sarah Johnson' },
    ],
    phaseAttachments: {
      draft: [],
      pre_audit: [],
      pre_audit_review: [],
      overview: [],
      evidence_collection: [
        { id: 'e2', name: 'Privacy_Training_Completion.xlsx', type: 'application/xlsx', uploadedAt: '2024-01-25', uploadedBy: 'Sarah Johnson', url: '#' },
      ],
      evaluation: [
        { id: 'e3', name: 'Access_Audit_Log.pdf', type: 'application/pdf', uploadedAt: '2024-01-26', uploadedBy: 'Sarah Johnson', url: '#' },
      ],
      internal_review: [],
      remediation_required: [],
      closure_cap: [],
      cap_active: [],
      pending_verification: [],
      closed: [],
    },
    phaseAssignees: defaultPhaseAssignees('1'),
    history: [
      { id: 'h3', action: 'Audit created', phase: 'overview', performedBy: 'Robert Wilson', performedAt: '2024-01-10T08:00:00Z' },
      { id: 'h4', action: 'Submitted for review', phase: 'evaluation', performedBy: 'Sarah Johnson', performedAt: '2024-01-27T14:00:00Z' },
    ],
  },
  {
    id: '3',
    title: 'Infection Control Procedures',
    description: 'Quarterly review of infection control and prevention measures',
    type: 'internal',
    status: 'closure_cap',
    department: 'Quality Assurance',
    assignedTo: '3',
    assignedToName: 'Emily Davis',
    createdBy: '1',
    createdAt: '2024-01-05',
    dueDate: '2024-01-31',
    priority: 'medium',
    phase: 'closure_cap',
    currentPhase: 'closure_cap',
    isPeriodic: true,
    periodicity: 'quarterly',
    nextScheduledDate: '2024-04-05',
    evidence: [
      { id: 'e4', name: 'Infection_Rates_Q4.pdf', type: 'application/pdf', uploadedAt: '2024-01-15', uploadedBy: 'Michael Chen', url: '#' },
    ],
    actions: [
      { id: 'a7', description: 'Analyze infection rate trends', completed: true, completedAt: '2024-01-12', completedBy: 'Michael Chen' },
      { id: 'a8', description: 'Review hand hygiene compliance', completed: true, completedAt: '2024-01-14', completedBy: 'Michael Chen' },
    ],
    phaseAttachments: {
      draft: [],
      pre_audit: [],
      pre_audit_review: [],
      overview: [],
      evidence_collection: [
        { id: 'e4', name: 'Infection_Rates_Q4.pdf', type: 'application/pdf', uploadedAt: '2024-01-15', uploadedBy: 'Michael Chen', url: '#' },
      ],
      evaluation: [],
      internal_review: [],
      remediation_required: [],
      closure_cap: [],
      cap_active: [],
      pending_verification: [],
      closed: [],
    },
    phaseAssignees: defaultPhaseAssignees('3'),
    history: [
      { id: 'h5', action: 'Audit created', phase: 'overview', performedBy: 'Sarah Johnson', performedAt: '2024-01-05T11:00:00Z' },
      { id: 'h6', action: 'Approved and sent to QA', phase: 'closure_cap', performedBy: 'Sarah Johnson', performedAt: '2024-01-20T16:00:00Z' },
    ],
  },
  {
    id: '4',
    title: 'Equipment Maintenance Audit',
    description: 'Review of medical equipment maintenance schedules and records',
    type: 'internal',
    status: 'overview',
    department: 'Nursing',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2024-01-28',
    dueDate: '2024-03-15',
    priority: 'low',
    phase: 'overview',
    currentPhase: 'overview',
    isPeriodic: true,
    periodicity: 'quarterly',
    nextScheduledDate: '2024-06-15',
    evidence: [],
    actions: [
      { id: 'a9', description: 'Collect maintenance logs', completed: false },
      { id: 'a10', description: 'Verify calibration records', completed: false },
      { id: 'a11', description: 'Document any equipment issues', completed: false },
    ],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'h7', action: 'Audit created', phase: 'overview', performedBy: 'Sarah Johnson', performedAt: '2024-01-28T09:00:00Z' },
    ],
  },
  // Historical completed audit for "Equipment Maintenance Audit" periodic cycle
  {
    id: '10',
    title: 'Equipment Maintenance Audit',
    description: 'Review of medical equipment maintenance schedules and records',
    type: 'internal',
    status: 'closed',
    closureType: 'without_cap',
    closureReason: 'No findings requiring remediation',
    department: 'Nursing',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2023-10-01',
    dueDate: '2023-10-31',
    priority: 'low',
    phase: 'closed',
    currentPhase: 'closed',
    isPeriodic: true,
    periodicity: 'quarterly',
    evidence: [],
    actions: [
      { id: 'a24', description: 'Collect maintenance logs', completed: true, completedAt: '2023-10-15', completedBy: 'Michael Chen' },
      { id: 'a25', description: 'Verify calibration records', completed: true, completedAt: '2023-10-20', completedBy: 'Michael Chen' },
    ],
    phaseAttachments: {
      draft: [],
      pre_audit: [],
      pre_audit_review: [],
      overview: [],
      evidence_collection: [],
      evaluation: [],
      internal_review: [],
      remediation_required: [],
      closure_cap: [],
      cap_active: [],
      pending_verification: [],
      closed: [],
    },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'h18', action: 'Audit created', phase: 'overview', performedBy: 'Sarah Johnson', performedAt: '2023-10-01T10:00:00Z' },
      { id: 'h19', action: 'Audit completed', phase: 'closure_cap', performedBy: 'Sarah Johnson', performedAt: '2023-10-28T15:00:00Z' },
    ],
  },
  {
    id: '11',
    title: 'Equipment Maintenance Audit',
    description: 'Review of medical equipment maintenance schedules and records',
    type: 'internal',
    status: 'closed',
    closureType: 'without_cap',
    closureReason: 'All equipment within compliance parameters',
    department: 'Nursing',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2023-07-01',
    dueDate: '2023-07-31',
    priority: 'low',
    phase: 'closed',
    currentPhase: 'closed',
    isPeriodic: true,
    periodicity: 'quarterly',
    evidence: [],
    actions: [
      { id: 'a26', description: 'Collect maintenance logs', completed: true, completedAt: '2023-07-12', completedBy: 'Michael Chen' },
      { id: 'a27', description: 'Verify calibration records', completed: true, completedAt: '2023-07-18', completedBy: 'Michael Chen' },
    ],
    phaseAttachments: {
      draft: [],
      pre_audit: [],
      pre_audit_review: [],
      overview: [],
      evidence_collection: [],
      evaluation: [],
      internal_review: [],
      remediation_required: [],
      closure_cap: [],
      cap_active: [],
      pending_verification: [],
      closed: [],
    },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'h20', action: 'Audit created', phase: 'overview', performedBy: 'Sarah Johnson', performedAt: '2023-07-01T10:00:00Z' },
      { id: 'h21', action: 'Audit completed', phase: 'closure_cap', performedBy: 'Sarah Johnson', performedAt: '2023-07-25T15:00:00Z' },
    ],
  },
  {
    id: '5',
    title: 'Patient Safety Protocol Review',
    description: 'Completed audit of patient safety protocols and incident reporting',
    type: 'internal',
    status: 'closed',
    closureType: 'with_cap',
    department: 'Nursing',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2023-11-01',
    dueDate: '2023-12-15',
    priority: 'high',
    phase: 'closed',
    currentPhase: 'closed',
    isPeriodic: true,
    periodicity: 'monthly',
    evidence: [],
    actions: [
      { id: 'a12', description: 'Review incident reports', completed: true, completedAt: '2023-11-20', completedBy: 'Michael Chen' },
      { id: 'a13', description: 'Verify safety protocol compliance', completed: true, completedAt: '2023-11-25', completedBy: 'Michael Chen' },
    ],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'h8', action: 'Audit created', phase: 'overview', performedBy: 'Sarah Johnson', performedAt: '2023-11-01T10:00:00Z' },
      { id: 'h9', action: 'Audit completed', phase: 'closure_cap', performedBy: 'Emily Davis', performedAt: '2023-12-10T15:00:00Z' },
    ],
  },
  // Historical completed audit for "Medication Administration Compliance" periodic cycle
  {
    id: '6',
    title: 'Medication Administration Compliance',
    description: 'Review of medication administration protocols and documentation accuracy',
    type: 'internal',
    status: 'closed',
    closureType: 'risk_accepted',
    closureReason: 'Minor deviation accepted by management - low risk impact',
    department: 'Nursing',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2023-10-15',
    dueDate: '2023-11-15',
    priority: 'high',
    phase: 'closed',
    currentPhase: 'closed',
    isPeriodic: true,
    periodicity: 'quarterly',
    evidence: [],
    actions: [
      { id: 'a14', description: 'Review medication administration records', completed: true, completedAt: '2023-10-20', completedBy: 'Michael Chen' },
      { id: 'a15', description: 'Document any discrepancies found', completed: true, completedAt: '2023-10-25', completedBy: 'Michael Chen' },
      { id: 'a16', description: 'Interview nursing staff on protocols', completed: true, completedAt: '2023-11-01', completedBy: 'Michael Chen' },
    ],
    phaseAttachments: {
      draft: [],
      pre_audit: [],
      pre_audit_review: [],
      overview: [],
      evidence_collection: [
        { id: 'e5', name: 'MAR_Report_Q3.pdf', type: 'application/pdf', uploadedAt: '2023-10-22', uploadedBy: 'Michael Chen', url: '#' },
      ],
      evaluation: [
        { id: 'e6', name: 'Compliance_Summary_Q3.pdf', type: 'application/pdf', uploadedAt: '2023-10-28', uploadedBy: 'Michael Chen', url: '#' },
      ],
      internal_review: [],
      remediation_required: [],
      closure_cap: [
        { id: 'e7', name: 'Final_Report_Q3.pdf', type: 'application/pdf', uploadedAt: '2023-11-10', uploadedBy: 'Sarah Johnson', url: '#' },
      ],
      cap_active: [],
      pending_verification: [],
      closed: [],
    },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'h10', action: 'Audit created', phase: 'overview', performedBy: 'Sarah Johnson', performedAt: '2023-10-15T10:00:00Z' },
      { id: 'h11', action: 'Audit completed', phase: 'closure_cap', performedBy: 'Sarah Johnson', performedAt: '2023-11-12T15:00:00Z' },
    ],
  },
  // Another historical completed audit for "Medication Administration Compliance"
  {
    id: '7',
    title: 'Medication Administration Compliance',
    description: 'Review of medication administration protocols and documentation accuracy',
    type: 'internal',
    status: 'closed',
    closureType: 'without_cap',
    closureReason: 'All actions completed within tolerance',
    department: 'Nursing',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2023-07-15',
    dueDate: '2023-08-15',
    priority: 'high',
    phase: 'closed',
    currentPhase: 'closed',
    isPeriodic: true,
    periodicity: 'quarterly',
    evidence: [],
    actions: [
      { id: 'a17', description: 'Review medication administration records', completed: true, completedAt: '2023-07-20', completedBy: 'Michael Chen' },
      { id: 'a18', description: 'Document any discrepancies found', completed: true, completedAt: '2023-07-25', completedBy: 'Michael Chen' },
      { id: 'a19', description: 'Interview nursing staff on protocols', completed: true, completedAt: '2023-08-01', completedBy: 'Michael Chen' },
    ],
    phaseAttachments: {
      draft: [],
      pre_audit: [],
      pre_audit_review: [],
      overview: [],
      evidence_collection: [
        { id: 'e8', name: 'MAR_Report_Q2.pdf', type: 'application/pdf', uploadedAt: '2023-07-22', uploadedBy: 'Michael Chen', url: '#' },
      ],
      evaluation: [],
      internal_review: [],
      remediation_required: [],
      closure_cap: [],
      cap_active: [],
      pending_verification: [],
      closed: [],
    },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'h12', action: 'Audit created', phase: 'overview', performedBy: 'Sarah Johnson', performedAt: '2023-07-15T10:00:00Z' },
      { id: 'h13', action: 'Audit completed', phase: 'closure_cap', performedBy: 'Sarah Johnson', performedAt: '2023-08-10T15:00:00Z' },
    ],
  },
  // Historical completed audit for "Patient Safety Protocol Review" periodic cycle
  {
    id: '8',
    title: 'Patient Safety Protocol Review',
    description: 'Completed audit of patient safety protocols and incident reporting',
    type: 'internal',
    status: 'closed',
    closureType: 'with_cap',
    department: 'Nursing',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2023-10-01',
    dueDate: '2023-10-31',
    priority: 'high',
    phase: 'closed',
    currentPhase: 'closed',
    isPeriodic: true,
    periodicity: 'monthly',
    evidence: [],
    actions: [
      { id: 'a20', description: 'Review incident reports', completed: true, completedAt: '2023-10-15', completedBy: 'Michael Chen' },
      { id: 'a21', description: 'Verify safety protocol compliance', completed: true, completedAt: '2023-10-20', completedBy: 'Michael Chen' },
    ],
    phaseAttachments: {
      draft: [],
      pre_audit: [],
      pre_audit_review: [],
      overview: [],
      evidence_collection: [
        { id: 'e9', name: 'Incident_Report_Oct.pdf', type: 'application/pdf', uploadedAt: '2023-10-16', uploadedBy: 'Michael Chen', url: '#' },
      ],
      evaluation: [],
      internal_review: [],
      remediation_required: [],
      closure_cap: [],
      cap_active: [],
      pending_verification: [],
      closed: [],
    },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'h14', action: 'Audit created', phase: 'overview', performedBy: 'Sarah Johnson', performedAt: '2023-10-01T10:00:00Z' },
      { id: 'h15', action: 'Audit completed', phase: 'closure_cap', performedBy: 'Sarah Johnson', performedAt: '2023-10-28T15:00:00Z' },
    ],
  },
  {
    id: '9',
    title: 'Patient Safety Protocol Review',
    description: 'Completed audit of patient safety protocols and incident reporting',
    type: 'internal',
    status: 'closed',
    closureType: 'invalidated',
    closureReason: 'Finding was based on incorrect data - original issue did not exist',
    department: 'Nursing',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2023-09-01',
    dueDate: '2023-09-30',
    priority: 'high',
    phase: 'closed',
    currentPhase: 'closed',
    isPeriodic: true,
    periodicity: 'monthly',
    evidence: [],
    actions: [
      { id: 'a22', description: 'Review incident reports', completed: true, completedAt: '2023-09-12', completedBy: 'Michael Chen' },
      { id: 'a23', description: 'Verify safety protocol compliance', completed: true, completedAt: '2023-09-18', completedBy: 'Michael Chen' },
    ],
    phaseAttachments: {
      draft: [],
      pre_audit: [],
      pre_audit_review: [],
      overview: [],
      evidence_collection: [],
      evaluation: [
        { id: 'e10', name: 'Safety_Evaluation_Sep.pdf', type: 'application/pdf', uploadedAt: '2023-09-20', uploadedBy: 'Michael Chen', url: '#' },
      ],
      internal_review: [],
      remediation_required: [],
      closure_cap: [],
      cap_active: [],
      pending_verification: [],
      closed: [],
    },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'h16', action: 'Audit created', phase: 'overview', performedBy: 'Sarah Johnson', performedAt: '2023-09-01T10:00:00Z' },
      { id: 'h17', action: 'Audit completed', phase: 'closure_cap', performedBy: 'Sarah Johnson', performedAt: '2023-09-25T15:00:00Z' },
    ],
  },
  {
    id: '11',
    title: 'Medication Storage Compliance Review',
    description: 'Internal monthly check of medication storage temperatures, expiry tracking, and controlled-substance logs',
    type: 'internal',
    status: 'internal_review',
    department: 'Nursing',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2024-02-01',
    dueDate: '2024-02-20',
    priority: 'high',
    phase: 'internal_review',
    currentPhase: 'internal_review',
    isPeriodic: true,
    periodicity: 'monthly',
    nextScheduledDate: '2024-03-01',
    evidence: [
      { id: 'e20', name: 'Fridge_Temp_Log_Feb.xlsx', type: 'application/xlsx', uploadedAt: '2024-02-10', uploadedBy: 'Michael Chen', url: '#' },
      { id: 'e21', name: 'Controlled_Substance_Register.pdf', type: 'application/pdf', uploadedAt: '2024-02-12', uploadedBy: 'Michael Chen', url: '#' },
    ],
    actions: [
      { id: 'a20', description: 'Verify daily fridge temperature logs', completed: true, completedAt: '2024-02-10', completedBy: 'Michael Chen' },
      { id: 'a21', description: 'Reconcile controlled-substance counts', completed: true, completedAt: '2024-02-12', completedBy: 'Michael Chen' },
      { id: 'a22', description: 'Flag expired medications for disposal', completed: true, completedAt: '2024-02-14', completedBy: 'Michael Chen' },
    ],
    phaseAttachments: {
      draft: [],
      pre_audit: [],
      pre_audit_review: [],
      overview: [],
      evidence_collection: [
        { id: 'e20', name: 'Fridge_Temp_Log_Feb.xlsx', type: 'application/xlsx', uploadedAt: '2024-02-10', uploadedBy: 'Michael Chen', url: '#' },
      ],
      evaluation: [
        { id: 'e21', name: 'Controlled_Substance_Register.pdf', type: 'application/pdf', uploadedAt: '2024-02-12', uploadedBy: 'Michael Chen', url: '#' },
      ],
      internal_review: [],
      remediation_required: [],
      closure_cap: [],
      cap_active: [],
      pending_verification: [],
      closed: [],
    },
    phaseAssignees: defaultPhaseAssignees('1'),
    history: [
      { id: 'h20', action: 'Audit created', phase: 'overview', performedBy: 'Sarah Johnson', performedAt: '2024-02-01T09:00:00Z' },
      { id: 'h21', action: 'Moved to Evidence Collection', phase: 'evidence_collection', performedBy: 'Michael Chen', performedAt: '2024-02-05T10:00:00Z' },
      { id: 'h22', action: 'Moved to Evaluation', phase: 'evaluation', performedBy: 'Michael Chen', performedAt: '2024-02-12T14:00:00Z' },
      { id: 'h23', action: 'Submitted for Internal Review', phase: 'internal_review', performedBy: 'Michael Chen', performedAt: '2024-02-14T16:30:00Z' },
    ],
  },
  // ===== Phase coverage samples (one per missing phase) =====
  {
    id: '20',
    title: 'Annual Fire Safety Inspection (Draft)',
    description: 'Newly created annual fire safety inspection — still in draft, not yet submitted',
    type: 'internal',
    status: 'draft',
    department: 'Nursing',
    assignedTo: '1',
    assignedToName: 'Sarah Johnson',
    createdBy: '1',
    createdAt: '2024-02-25',
    dueDate: '2024-04-30',
    priority: 'low',
    phase: 'draft',
    currentPhase: 'draft',
    isPeriodic: false,
    evidence: [],
    actions: [
      { id: 'a100', description: 'Define inspection scope', completed: false },
      { id: 'a101', description: 'Identify inspection locations', completed: false },
    ],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('1'),
    history: [
      { id: 'h100', action: 'Audit created (draft)', phase: 'draft', performedBy: 'Sarah Johnson', performedAt: '2024-02-25T09:00:00Z' },
    ],
  },
  {
    id: '21',
    title: 'Q1 Sterilization Process Audit',
    description: 'Pre-audit checklist submitted, awaiting compliance head approval before kickoff',
    type: 'external',
    status: 'pre_audit_review',
    department: 'Quality Assurance',
    assignedTo: '3',
    assignedToName: 'Emily Davis',
    createdBy: '1',
    createdAt: '2024-02-10',
    dueDate: '2024-03-20',
    priority: 'high',
    phase: 'pre_audit_review',
    currentPhase: 'pre_audit_review',
    isPeriodic: true,
    periodicity: 'quarterly',
    nextScheduledDate: '2024-06-10',
    evidence: [],
    actions: [
      { id: 'a110', description: 'Pre-audit scope defined', completed: true, completedAt: '2024-02-12', completedBy: 'Sarah Johnson' },
      { id: 'a111', description: 'Pre-audit checklist completed', completed: true, completedAt: '2024-02-15', completedBy: 'Sarah Johnson' },
    ],
    phaseAttachments: {
      ...emptyPhaseAttachments,
      pre_audit: [
        { id: 'e100', name: 'Sterilization_PreAudit_Checklist.pdf', type: 'application/pdf', uploadedAt: '2024-02-15', uploadedBy: 'Sarah Johnson', url: '#' },
      ],
    },
    phaseAssignees: defaultPhaseAssignees('3'),
    history: [
      { id: 'h110', action: 'Pre-audit created', phase: 'pre_audit', performedBy: 'Sarah Johnson', performedAt: '2024-02-10T09:00:00Z' },
      { id: 'h111', action: 'Submitted for pre-audit review', phase: 'pre_audit_review', performedBy: 'Sarah Johnson', performedAt: '2024-02-15T15:00:00Z' },
    ],
  },
  {
    id: '22',
    title: 'Patient Consent Form Audit',
    description: 'Evidence collected — currently being evaluated for compliance findings',
    type: 'internal',
    status: 'evaluation',
    department: 'Nursing',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2024-02-05',
    dueDate: '2024-03-10',
    priority: 'medium',
    phase: 'evaluation',
    currentPhase: 'evaluation',
    isPeriodic: false,
    evidence: [
      { id: 'e120', name: 'Consent_Forms_Sample.pdf', type: 'application/pdf', uploadedAt: '2024-02-18', uploadedBy: 'Michael Chen', url: '#' },
    ],
    actions: [
      { id: 'a120', description: 'Pull random sample of 50 consent forms', completed: true, completedAt: '2024-02-15', completedBy: 'Michael Chen' },
      { id: 'a121', description: 'Verify signatures and dates', completed: true, completedAt: '2024-02-18', completedBy: 'Michael Chen' },
      { id: 'a122', description: 'Score completeness against checklist', completed: false },
    ],
    phaseAttachments: {
      ...emptyPhaseAttachments,
      evidence_collection: [
        { id: 'e120', name: 'Consent_Forms_Sample.pdf', type: 'application/pdf', uploadedAt: '2024-02-18', uploadedBy: 'Michael Chen', url: '#' },
      ],
    },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'h120', action: 'Audit created', phase: 'overview', performedBy: 'Sarah Johnson', performedAt: '2024-02-05T09:00:00Z' },
      { id: 'h121', action: 'Moved to Evidence Collection', phase: 'evidence_collection', performedBy: 'Michael Chen', performedAt: '2024-02-10T10:00:00Z' },
      { id: 'h122', action: 'Moved to Evaluation', phase: 'evaluation', performedBy: 'Michael Chen', performedAt: '2024-02-19T11:00:00Z' },
    ],
  },
  {
    id: '23',
    title: 'Radiology Documentation Review',
    description: 'Internal review identified gaps — sent back to assignee for remediation',
    type: 'internal',
    status: 'remediation_required',
    department: 'Nursing',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2024-01-20',
    dueDate: '2024-03-05',
    priority: 'high',
    phase: 'remediation_required',
    currentPhase: 'remediation_required',
    reviewNotes: 'Missing physician sign-off on 3 of 20 sampled records. Please re-collect and re-evaluate.',
    isPeriodic: false,
    evidence: [],
    actions: [
      { id: 'a130', description: 'Sample 20 radiology records', completed: true, completedAt: '2024-01-28', completedBy: 'Michael Chen' },
      { id: 'a131', description: 'Verify physician sign-off', completed: true, completedAt: '2024-02-02', completedBy: 'Michael Chen' },
      { id: 'a132', description: 'Address reviewer findings on missing sign-offs', completed: false },
    ],
    phaseAttachments: {
      ...emptyPhaseAttachments,
      internal_review: [
        { id: 'e130', name: 'Reviewer_Findings.pdf', type: 'application/pdf', uploadedAt: '2024-02-20', uploadedBy: 'Sarah Johnson', url: '#' },
      ],
    },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'h130', action: 'Audit created', phase: 'overview', performedBy: 'Sarah Johnson', performedAt: '2024-01-20T09:00:00Z' },
      { id: 'h131', action: 'Submitted for Internal Review', phase: 'internal_review', performedBy: 'Michael Chen', performedAt: '2024-02-15T14:00:00Z' },
      { id: 'h132', action: 'Sent back for remediation', phase: 'remediation_required', performedBy: 'Sarah Johnson', performedAt: '2024-02-20T16:00:00Z', notes: 'Missing physician sign-off on 3 of 20 sampled records' },
    ],
  },
  {
    id: '24',
    title: 'External Joint Commission Mock Survey',
    description: 'CAP active — corrective actions being executed in ComplianceConnect microapp',
    type: 'external',
    status: 'cap_active',
    department: 'Quality Assurance',
    assignedTo: '3',
    assignedToName: 'Emily Davis',
    createdBy: '4',
    createdAt: '2023-12-01',
    dueDate: '2024-04-15',
    priority: 'critical',
    phase: 'cap_active',
    currentPhase: 'cap_active',
    capRequired: true,
    isPeriodic: true,
    periodicity: 'annually',
    nextScheduledDate: '2024-12-01',
    evidence: [],
    actions: [
      { id: 'a140', description: 'Complete mock survey walkthrough', completed: true, completedAt: '2023-12-15', completedBy: 'Emily Davis' },
      { id: 'a141', description: 'Document findings and gaps', completed: true, completedAt: '2024-01-10', completedBy: 'Emily Davis' },
      { id: 'a142', description: 'Open CAP in ComplianceConnect', completed: true, completedAt: '2024-01-25', completedBy: 'Emily Davis' },
    ],
    phaseAttachments: {
      ...emptyPhaseAttachments,
      closure_cap: [
        { id: 'e140', name: 'CAP_Plan_v1.pdf', type: 'application/pdf', uploadedAt: '2024-01-25', uploadedBy: 'Emily Davis', url: '#' },
      ],
    },
    phaseAssignees: defaultPhaseAssignees('3'),
    linkedItems: [
      {
        id: 'l1',
        microApp: 'ComplianceConnect',
        itemId: 'CAP-2024-014',
        itemTitle: 'JC Mock Survey CAP — Documentation Gaps',
        itemType: 'CAP',
        status: 'In Progress',
        linkedAt: '2024-01-25T10:00:00Z',
        linkedBy: 'Emily Davis',
      },
    ],
    history: [
      { id: 'h140', action: 'Audit created', phase: 'overview', performedBy: 'Robert Wilson', performedAt: '2023-12-01T09:00:00Z' },
      { id: 'h141', action: 'Closed with CAP', phase: 'closure_cap', performedBy: 'Emily Davis', performedAt: '2024-01-25T15:00:00Z' },
      { id: 'h142', action: 'CAP activated externally', phase: 'cap_active', performedBy: 'Emily Davis', performedAt: '2024-01-26T09:00:00Z' },
    ],
  },
  {
    id: '25',
    title: 'Pharmacy Controlled Substance External Audit',
    description: 'CAP completed externally — awaiting QA verification before final closure',
    type: 'external',
    status: 'pending_verification',
    department: 'Quality Assurance',
    assignedTo: '3',
    assignedToName: 'Emily Davis',
    createdBy: '4',
    createdAt: '2023-11-10',
    dueDate: '2024-02-28',
    priority: 'high',
    phase: 'pending_verification',
    currentPhase: 'pending_verification',
    capRequired: true,
    isPeriodic: false,
    evidence: [],
    actions: [
      { id: 'a150', description: 'External audit walkthrough', completed: true, completedAt: '2023-11-20', completedBy: 'Emily Davis' },
      { id: 'a151', description: 'CAP plan agreed with auditor', completed: true, completedAt: '2023-12-15', completedBy: 'Emily Davis' },
      { id: 'a152', description: 'CAP execution complete (external)', completed: true, completedAt: '2024-02-20', completedBy: 'Emily Davis' },
    ],
    phaseAttachments: {
      ...emptyPhaseAttachments,
      cap_active: [
        { id: 'e150', name: 'CAP_Completion_Evidence.pdf', type: 'application/pdf', uploadedAt: '2024-02-20', uploadedBy: 'Emily Davis', url: '#' },
      ],
    },
    phaseAssignees: defaultPhaseAssignees('3'),
    linkedItems: [
      {
        id: 'l2',
        microApp: 'ComplianceConnect',
        itemId: 'CAP-2023-098',
        itemTitle: 'Pharmacy Controlled Substance CAP',
        itemType: 'CAP',
        status: 'Completed',
        linkedAt: '2023-12-15T10:00:00Z',
        linkedBy: 'Emily Davis',
      },
    ],
    history: [
      { id: 'h150', action: 'Audit created', phase: 'overview', performedBy: 'Robert Wilson', performedAt: '2023-11-10T09:00:00Z' },
      { id: 'h151', action: 'Closed with CAP', phase: 'closure_cap', performedBy: 'Emily Davis', performedAt: '2023-12-15T15:00:00Z' },
      { id: 'h152', action: 'CAP marked complete — pending verification', phase: 'pending_verification', performedBy: 'Emily Davis', performedAt: '2024-02-20T16:00:00Z' },
    ],
  },
  {
    id: '26',
    title: 'Annual OSHA Bloodborne Pathogens Audit',
    description: 'Fully closed external audit — verification complete, no further action required',
    type: 'external',
    status: 'closed',
    closureType: 'with_cap',
    closureReason: 'CAP completed and verified by QA — all findings resolved',
    department: 'Quality Assurance',
    assignedTo: '3',
    assignedToName: 'Emily Davis',
    createdBy: '4',
    createdAt: '2023-08-01',
    dueDate: '2023-11-30',
    priority: 'high',
    phase: 'closed',
    currentPhase: 'closed',
    capRequired: true,
    isPeriodic: true,
    periodicity: 'annually',
    nextScheduledDate: '2024-08-01',
    evidence: [],
    actions: [
      { id: 'a160', description: 'External walkthrough complete', completed: true, completedAt: '2023-08-20', completedBy: 'Emily Davis' },
      { id: 'a161', description: 'CAP executed', completed: true, completedAt: '2023-10-30', completedBy: 'Emily Davis' },
      { id: 'a162', description: 'QA verification complete', completed: true, completedAt: '2023-11-20', completedBy: 'Emily Davis' },
    ],
    phaseAttachments: {
      ...emptyPhaseAttachments,
      closed: [
        { id: 'e160', name: 'OSHA_Final_Closure_Report.pdf', type: 'application/pdf', uploadedAt: '2023-11-22', uploadedBy: 'Emily Davis', url: '#' },
      ],
    },
    phaseAssignees: defaultPhaseAssignees('3'),
    history: [
      { id: 'h160', action: 'Audit created', phase: 'overview', performedBy: 'Robert Wilson', performedAt: '2023-08-01T09:00:00Z' },
      { id: 'h161', action: 'Closed with CAP', phase: 'closure_cap', performedBy: 'Emily Davis', performedAt: '2023-09-15T15:00:00Z' },
      { id: 'h162', action: 'CAP completed — pending verification', phase: 'pending_verification', performedBy: 'Emily Davis', performedAt: '2023-10-30T16:00:00Z' },
      { id: 'h163', action: 'Audit fully closed', phase: 'closed', performedBy: 'Emily Davis', performedAt: '2023-11-22T10:00:00Z' },
    ],
  },
  // ────────────────────────────────────────────────────────────────────
  // STATUS SHOWCASE: one sample per phase. Each description is a one-liner
  // explaining what the status means + what the assignee should do next.
  // ────────────────────────────────────────────────────────────────────
  {
    id: 'demo-draft',
    title: '[Draft] Annual Infection Control Audit',
    description: 'DRAFT — Audit has been created but not yet started. Next: open the audit and submit it to begin pre-audit preparation.',
    type: 'internal',
    status: 'draft',
    department: 'Nursing',
    assignedTo: '1',
    assignedToName: 'Sarah Johnson',
    createdBy: '1',
    createdAt: '2026-04-20',
    dueDate: '2026-06-30',
    priority: 'medium',
    phase: 'draft',
    currentPhase: 'draft',
    isPeriodic: false,
    evidence: [],
    actions: [],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('1'),
    history: [
      { id: 'hd1', action: 'Audit created as draft', phase: 'draft', performedBy: 'Sarah Johnson', performedAt: '2026-04-20T09:00:00Z' },
    ],
  },
  {
    id: 'demo-pre-audit',
    title: '[Pre-Audit Preparation] Quarterly Pharmacy Review',
    description: 'PRE-AUDIT PREPARATION — Assignee is gathering scope, checklist, and resources. Next: complete prep tasks, then submit pre-audit for review.',
    type: 'internal',
    status: 'pre_audit',
    department: 'Pharmacy',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2026-04-15',
    dueDate: '2026-05-30',
    priority: 'medium',
    phase: 'pre_audit',
    currentPhase: 'pre_audit',
    isPeriodic: true,
    periodicity: 'quarterly',
    evidence: [],
    actions: [
      { id: 'demo-pa-1', description: 'Define scope and sampling plan', completed: true, completedAt: '2026-04-18', completedBy: 'Michael Chen' },
      { id: 'demo-pa-2', description: 'Prepare evidence checklist', completed: false },
    ],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'hp1', action: 'Pre-audit started', phase: 'pre_audit', performedBy: 'Michael Chen', performedAt: '2026-04-15T09:00:00Z' },
    ],
  },
  {
    id: 'demo-pre-audit-review',
    title: '[Pre-Audit Review] Lab Safety Inspection',
    description: 'PRE-AUDIT REVIEW — Pre-audit submitted, awaiting reviewer approval. Next: reviewer approves to start the audit, or returns it for corrections.',
    type: 'internal',
    status: 'pre_audit_review',
    department: 'Laboratory',
    assignedTo: '1',
    assignedToName: 'Sarah Johnson',
    createdBy: '2',
    createdAt: '2026-04-10',
    dueDate: '2026-05-25',
    priority: 'high',
    phase: 'pre_audit_review',
    currentPhase: 'pre_audit_review',
    isPeriodic: false,
    evidence: [],
    actions: [],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('1'),
    history: [
      { id: 'hpr1', action: 'Submitted pre-audit for review', phase: 'pre_audit_review', performedBy: 'Michael Chen', performedAt: '2026-04-22T10:00:00Z' },
    ],
  },
  {
    id: 'demo-overview',
    title: '[Audit Overview] Patient Records Audit',
    description: 'AUDIT OVERVIEW — Pre-audit approved; audit officially started. Next: review scope and proceed to evidence collection.',
    type: 'internal',
    status: 'overview',
    department: 'Administration',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2026-04-05',
    dueDate: '2026-05-20',
    priority: 'medium',
    phase: 'overview',
    currentPhase: 'overview',
    isPeriodic: false,
    evidence: [],
    actions: [
      { id: 'demo-ov-1', description: 'Confirm audit scope with stakeholders', completed: false },
    ],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'ho1', action: 'Pre-audit approved — audit started', phase: 'overview', performedBy: 'Sarah Johnson', performedAt: '2026-04-25T11:00:00Z' },
    ],
  },
  {
    id: 'demo-evidence',
    title: '[Evidence Collection] Radiology Compliance Check',
    description: 'EVIDENCE COLLECTION — Assignee is uploading required documents and observations. Next: complete evidence checklist, then move to evaluation.',
    type: 'internal',
    status: 'evidence_collection',
    department: 'Radiology',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2026-04-01',
    dueDate: '2026-05-15',
    priority: 'high',
    phase: 'evidence_collection',
    currentPhase: 'evidence_collection',
    isPeriodic: false,
    evidence: [],
    actions: [
      { id: 'demo-ec-1', description: 'Upload calibration logs', completed: true, completedAt: '2026-04-18', completedBy: 'Michael Chen' },
      { id: 'demo-ec-2', description: 'Attach staff training records', completed: false },
    ],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'hec1', action: 'Started evidence collection', phase: 'evidence_collection', performedBy: 'Michael Chen', performedAt: '2026-04-10T09:00:00Z' },
    ],
  },
  {
    id: 'demo-evaluation',
    title: '[Evaluation] Fire Safety Drill Audit',
    description: 'EVALUATION — Evidence is being reviewed for completeness and findings. Next: complete the evaluation and submit for internal review.',
    type: 'internal',
    status: 'evaluation',
    department: 'Administration',
    assignedTo: '1',
    assignedToName: 'Sarah Johnson',
    createdBy: '1',
    createdAt: '2026-03-25',
    dueDate: '2026-05-10',
    priority: 'medium',
    phase: 'evaluation',
    currentPhase: 'evaluation',
    isPeriodic: false,
    evidence: [],
    actions: [
      { id: 'demo-ev-1', description: 'Score evidence against criteria', completed: false },
    ],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('1'),
    history: [
      { id: 'hev1', action: 'Moved to evaluation', phase: 'evaluation', performedBy: 'Sarah Johnson', performedAt: '2026-04-15T13:00:00Z' },
    ],
  },
  {
    id: 'demo-internal-review',
    title: '[Internal Review] Discharge Process Audit',
    description: 'INTERNAL REVIEW — Audit submitted for reviewer approval. Next: reviewer approves to move to closure, or returns for remediation.',
    type: 'internal',
    status: 'internal_review',
    department: 'Nursing',
    assignedTo: '1',
    assignedToName: 'Sarah Johnson',
    createdBy: '2',
    createdAt: '2026-03-20',
    dueDate: '2026-05-05',
    priority: 'high',
    phase: 'internal_review',
    currentPhase: 'internal_review',
    isPeriodic: false,
    evidence: [],
    actions: [],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('1'),
    history: [
      { id: 'hir1', action: 'Submitted for internal review', phase: 'internal_review', performedBy: 'Michael Chen', performedAt: '2026-04-20T15:00:00Z' },
    ],
  },
  {
    id: 'demo-remediation',
    title: '[Remediation Required] Vendor Compliance Audit',
    description: 'REMEDIATION REQUIRED — Reviewer returned the audit with feedback. Next: address feedback notes and resubmit for review.',
    type: 'internal',
    status: 'remediation_required',
    department: 'Administration',
    assignedTo: '2',
    assignedToName: 'Michael Chen',
    createdBy: '1',
    createdAt: '2026-03-15',
    dueDate: '2026-05-01',
    priority: 'high',
    phase: 'remediation_required',
    currentPhase: 'remediation_required',
    isPeriodic: false,
    reviewNotes: 'Missing supporting evidence for sections 3 and 4.',
    evidence: [],
    actions: [
      { id: 'demo-rr-1', description: 'Add missing evidence for sections 3 & 4', completed: false },
    ],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('2'),
    history: [
      { id: 'hrr1', action: 'Returned for remediation', phase: 'remediation_required', performedBy: 'Sarah Johnson', performedAt: '2026-04-18T10:00:00Z', notes: 'Missing supporting evidence for sections 3 and 4.' },
    ],
  },
  {
    id: 'demo-closure-cap',
    title: '[Closure & CAP] Sterilization Process Audit',
    description: 'CLOSURE & CAP — Audit approved, awaiting closure decision. Next: choose to close with a CAP (corrective action plan) or close without CAP.',
    type: 'internal',
    status: 'closure_cap',
    department: 'Nursing',
    assignedTo: '3',
    assignedToName: 'Emily Davis',
    createdBy: '1',
    createdAt: '2026-03-10',
    dueDate: '2026-04-30',
    priority: 'high',
    phase: 'closure_cap',
    currentPhase: 'closure_cap',
    isPeriodic: false,
    evidence: [],
    actions: [],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('3'),
    history: [
      { id: 'hcc1', action: 'Approved — moved to closure', phase: 'closure_cap', performedBy: 'Sarah Johnson', performedAt: '2026-04-22T11:00:00Z' },
    ],
  },
  {
    id: 'demo-cap-active',
    title: '[CAP Active] Equipment Maintenance Audit',
    description: 'CAP ACTIVE — Corrective action plan is being executed externally (ComplianceConnect/CAPA). Next: monitor CAP progress until complete.',
    type: 'external',
    status: 'cap_active',
    department: 'Nursing',
    assignedTo: '3',
    assignedToName: 'Emily Davis',
    createdBy: '1',
    createdAt: '2026-03-01',
    dueDate: '2026-05-30',
    priority: 'high',
    phase: 'cap_active',
    currentPhase: 'cap_active',
    isPeriodic: false,
    capRequired: true,
    evidence: [],
    actions: [],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('3'),
    history: [
      { id: 'hca1', action: 'CAP opened in ComplianceConnect', phase: 'cap_active', performedBy: 'Emily Davis', performedAt: '2026-04-10T09:00:00Z' },
    ],
    linkedItems: [
      { id: 'li-cap-1', microApp: 'ComplianceConnect', itemId: 'CAP-2026-014', itemTitle: 'Equipment maintenance CAP', itemType: 'CAP', status: 'In Progress', linkedAt: '2026-04-10', linkedBy: 'Emily Davis' },
    ],
  },
  {
    id: 'demo-pending-verification',
    title: '[Pending Verification] Patient Safety Audit',
    description: 'PENDING VERIFICATION — CAP marked complete, awaiting QA verification of effectiveness. Next: QA verifies and closes the audit.',
    type: 'external',
    status: 'pending_verification',
    department: 'Nursing',
    assignedTo: '3',
    assignedToName: 'Emily Davis',
    createdBy: '1',
    createdAt: '2026-02-15',
    dueDate: '2026-04-30',
    priority: 'high',
    phase: 'pending_verification',
    currentPhase: 'pending_verification',
    isPeriodic: false,
    capRequired: true,
    evidence: [],
    actions: [
      { id: 'demo-pv-1', description: 'QA effectiveness verification', completed: false },
    ],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('3'),
    history: [
      { id: 'hpv1', action: 'CAP completed — pending verification', phase: 'pending_verification', performedBy: 'Emily Davis', performedAt: '2026-04-25T14:00:00Z' },
    ],
  },
  {
    id: 'demo-closed',
    title: '[Closed] Annual HIPAA Compliance Audit',
    description: 'CLOSED — Audit fully completed and archived. No further actions can be taken; view-only for reference and reporting.',
    type: 'external',
    status: 'closed',
    closureType: 'with_cap',
    closureReason: 'CAP completed and verified effective',
    department: 'Administration',
    assignedTo: '3',
    assignedToName: 'Emily Davis',
    createdBy: '1',
    createdAt: '2026-01-10',
    dueDate: '2026-03-31',
    priority: 'high',
    phase: 'closed',
    currentPhase: 'closed',
    isPeriodic: true,
    periodicity: 'annually',
    capRequired: true,
    evidence: [],
    actions: [],
    phaseAttachments: { ...emptyPhaseAttachments },
    phaseAssignees: defaultPhaseAssignees('3'),
    history: [
      { id: 'hcl1', action: 'Audit fully closed', phase: 'closed', performedBy: 'Emily Davis', performedAt: '2026-04-15T16:00:00Z' },
    ],
  },
];

const AuditContext = createContext<AuditContextType | undefined>(undefined);

export function AuditProvider({ children }: { children: ReactNode }) {
  const [audits, setAudits] = useState<AuditItem[]>(initialAudits);
  const [currentUser, setCurrentUser] = useState<User>(mockUsers[0]);

  const addAudit = (audit: Omit<AuditItem, 'id' | 'createdAt' | 'evidence' | 'phaseAttachments' | 'history'> & { actions?: AuditAction[] }) => {
    const newAudit: AuditItem = {
      ...audit,
      id: Date.now().toString(),
      createdAt: new Date().toISOString().split('T')[0],
      evidence: [],
      phaseAttachments: { ...emptyPhaseAttachments },
      history: [{
        id: Date.now().toString(),
        action: 'Audit created',
        phase: 'overview',
        performedBy: currentUser.name,
        performedAt: new Date().toISOString(),
      }],
      actions: audit.actions || [],
    };
    setAudits([...audits, newAudit]);
  };

  const updateAudit = (id: string, updates: Partial<AuditItem>) => {
    setAudits(prevAudits => prevAudits.map(audit => 
      audit.id === id ? { ...audit, ...updates } : audit
    ));
  };

  const addHistoryEntry = (auditId: string, entry: Omit<AuditHistoryEntry, 'id' | 'performedAt'>) => {
    setAudits(prevAudits => prevAudits.map(audit => {
      if (audit.id === auditId) {
        return {
          ...audit,
          history: [
            ...audit.history,
            {
              ...entry,
              id: Date.now().toString(),
              performedAt: new Date().toISOString(),
            },
          ],
        };
      }
      return audit;
    }));
  };

  const addPhaseAttachment = (auditId: string, phase: AuditPhase, evidence: Evidence) => {
    setAudits(audits.map(audit => {
      if (audit.id === auditId) {
        return {
          ...audit,
          evidence: [...audit.evidence, evidence],
          phaseAttachments: {
            ...audit.phaseAttachments,
            [phase]: [...(audit.phaseAttachments[phase] || []), evidence],
          },
        };
      }
      return audit;
    }));
  };

  const updatePhaseAssignee = (auditId: string, phase: AuditPhase, userId: string) => {
    const user = mockUsers.find(u => u.id === userId);
    if (!user) return;

    setAudits(prevAudits => prevAudits.map(audit => {
      if (audit.id === auditId) {
        return {
          ...audit,
          phaseAssignees: {
            ...(audit.phaseAssignees || defaultPhaseAssignees(audit.assignedTo)),
            [phase]: userId,
          },
        };
      }
      return audit;
    }));

    addHistoryEntry(auditId, {
      action: `Assigned ${user.name} to ${phase.replace('_', ' ')} phase`,
      phase: phase,
      performedBy: currentUser.name,
    });
  };

  const deleteAudit = (id: string) => {
    setAudits(prevAudits => prevAudits.filter(audit => audit.id !== id));
  };

  const addActionItem = (auditId: string, description: string) => {
    const newAction: AuditAction = {
      id: `action-${Date.now()}`,
      description: description.trim(),
      completed: false,
    };

    setAudits(prevAudits => prevAudits.map(audit => {
      if (audit.id === auditId) {
        return {
          ...audit,
          actions: [...audit.actions, newAction],
        };
      }
      return audit;
    }));

    addHistoryEntry(auditId, {
      action: `Added action item: "${description.trim()}"`,
      phase: audits.find(a => a.id === auditId)?.currentPhase || 'overview',
      performedBy: currentUser.name,
    });
  };
  const getDepartmentAudits = (): AuditItem[] => {
    if (currentUser.role === 'compliance_head') {
      return audits.filter(audit => audit.status === 'remediation_required' || audit.department === 'Quality Assurance');
    }
    return audits.filter(audit => audit.department === currentUser.department);
  };

  // Get all audits assigned to the current user
  const getPersonalAudits = (): AuditItem[] => {
    return audits.filter(audit => audit.assignedTo === currentUser.id);
  };

  // Get audit history (closed audits)
  const getAuditHistory = (): AuditItem[] => {
    if (currentUser.role === 'compliance_head') {
      return audits.filter(audit => 
        audit.status === 'closed' &&
        (audit.department === 'Quality Assurance' || audit.history.some(h => h.performedBy === currentUser.name))
      );
    }
    return audits.filter(audit => 
      audit.status === 'closed' &&
      (audit.department === currentUser.department || audit.assignedTo === currentUser.id || audit.createdBy === currentUser.id)
    );
  };

  const getToDoItems = (): AuditItem[] => {
    if (currentUser.role === 'department_head' || currentUser.role === 'admin') {
      return audits.filter(
        audit => audit.department === currentUser.department && 
        ['draft', 'overview', 'evaluation', 'remediation_required', 'cap_active', 'pending_verification'].includes(audit.status)
      );
    }
    if (currentUser.role === 'compliance_head') {
      return audits.filter(audit => audit.status === 'remediation_required');
    }
    // Staff - read-only, show assigned audits
    return audits.filter(
      audit => audit.assignedTo === currentUser.id && 
      ['draft', 'overview', 'evaluation', 'remediation_required', 'cap_active', 'pending_verification'].includes(audit.status)
    );
  };

  const getToReviewItems = (): AuditItem[] => {
    if (currentUser.role === 'department_head' || currentUser.role === 'admin') {
      return audits.filter(
        audit => audit.department === currentUser.department && 
        audit.status === 'internal_review'
      );
    }
    if (currentUser.role === 'compliance_head') {
      return audits.filter(audit => audit.status === 'internal_review' && audit.type === 'external');
    }
    // Staff - read-only, no review items
    return [];
  };

  const submitForReview = (id: string) => {
    updateAudit(id, { status: 'internal_review', currentPhase: 'internal_review', phase: 'internal_review' });
  };

  const submitPreAuditForReview = (id: string) => {
    updateAudit(id, { status: 'pre_audit_review', currentPhase: 'pre_audit_review', phase: 'pre_audit_review' });
    addHistoryEntry(id, {
      action: 'Submitted pre-audit for review',
      phase: 'pre_audit_review',
      performedBy: currentUser.name,
    });
  };

  const approvePreAudit = (id: string) => {
    updateAudit(id, { 
      status: 'overview', 
      currentPhase: 'overview',
      phase: 'overview'
    });
    addHistoryEntry(id, {
      action: 'Pre-audit approved - moved to audit lifecycle',
      phase: 'overview',
      performedBy: currentUser.name,
    });
  };

  const rejectPreAudit = (id: string, notes: string) => {
    updateAudit(id, { status: 'pre_audit', currentPhase: 'pre_audit', phase: 'pre_audit', reviewNotes: notes });
    addHistoryEntry(id, {
      action: `Pre-audit rejected: ${notes}`,
      phase: 'pre_audit',
      performedBy: currentUser.name,
    });
  };

  const approveAudit = (id: string) => {
    const audit = audits.find(a => a.id === id);
    if (!audit) return;

    // After internal review approval, move to closure phase
    updateAudit(id, { status: 'closure_cap', currentPhase: 'closure_cap', phase: 'closure_cap' });
  };

  const rejectAudit = (id: string, notes: string) => {
    // Rejection sends back to remediation for rework
    updateAudit(id, { status: 'remediation_required', currentPhase: 'remediation_required', phase: 'remediation_required', reviewNotes: notes });
  };

  const closeAudit = (id: string, capRequired: boolean) => {
    if (capRequired) {
      updateAudit(id, { status: 'cap_active', currentPhase: 'cap_active', phase: 'cap_active', capRequired: true });
    } else {
      updateAudit(id, { status: 'closed', currentPhase: 'closed', phase: 'closed', capRequired: false });
    }
  };

  // Get pre-audit items for preparation
  const getPreAuditItems = (): AuditItem[] => {
    if (currentUser.role === 'department_head' || currentUser.role === 'admin') {
      return audits.filter(
        audit => audit.department === currentUser.department && 
        audit.currentPhase === 'pre_audit'
      );
    }
    return audits.filter(
      audit => audit.assignedTo === currentUser.id && 
      audit.currentPhase === 'pre_audit'
    );
  };

  // Get pre-audit items pending review
  const getPreAuditReviewItems = (): AuditItem[] => {
    if (currentUser.role === 'department_head' || currentUser.role === 'compliance_head' || currentUser.role === 'admin') {
      return audits.filter(
        audit => audit.department === currentUser.department && 
        audit.status === 'pre_audit_review'
      );
    }
    return audits.filter(
      audit => audit.assignedTo === currentUser.id && 
      audit.status === 'pre_audit_review'
    );
  };

  const addLinkedItem = (auditId: string, item: Omit<LinkedItem, 'id' | 'linkedAt' | 'linkedBy'>) => {
    const newLinkedItem: LinkedItem = {
      ...item,
      id: `link-${Date.now()}`,
      linkedAt: new Date().toISOString(),
      linkedBy: currentUser.name,
    };
    
    setAudits(prev => prev.map(audit => {
      if (audit.id === auditId) {
        return {
          ...audit,
          linkedItems: [...(audit.linkedItems || []), newLinkedItem],
        };
      }
      return audit;
    }));

    addHistoryEntry(auditId, {
      action: `Linked ${item.microApp} item: ${item.itemTitle}`,
      phase: 'overview',
      performedBy: currentUser.name,
    });
  };

  const removeLinkedItem = (auditId: string, linkedItemId: string) => {
    const audit = audits.find(a => a.id === auditId);
    const linkedItem = audit?.linkedItems?.find(l => l.id === linkedItemId);
    
    setAudits(prev => prev.map(a => {
      if (a.id === auditId) {
        return {
          ...a,
          linkedItems: (a.linkedItems || []).filter(l => l.id !== linkedItemId),
        };
      }
      return a;
    }));

    if (linkedItem) {
      addHistoryEntry(auditId, {
        action: `Removed link to ${linkedItem.microApp} item: ${linkedItem.itemTitle}`,
        phase: 'overview',
        performedBy: currentUser.name,
      });
    }
  };

  return (
    <AuditContext.Provider value={{
      audits,
      currentUser,
      users: mockUsers,
      setCurrentUser,
      addAudit,
      updateAudit,
      deleteAudit,
      addActionItem,
      getToDoItems,
      getToReviewItems,
      getPreAuditItems,
      getPreAuditReviewItems,
      getDepartmentAudits,
      getPersonalAudits,
      getAuditHistory,
      submitForReview,
      submitPreAuditForReview,
      approvePreAudit,
      rejectPreAudit,
      approveAudit,
      rejectAudit,
      closeAudit,
      addHistoryEntry,
      addPhaseAttachment,
      updatePhaseAssignee,
      addLinkedItem,
      removeLinkedItem,
    }}>
      {children}
    </AuditContext.Provider>
  );
}

export function useAudit() {
  const context = useContext(AuditContext);
  if (!context) {
    throw new Error('useAudit must be used within an AuditProvider');
  }
  return context;
}

export { mockUsers };