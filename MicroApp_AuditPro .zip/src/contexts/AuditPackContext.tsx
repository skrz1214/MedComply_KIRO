import React, { createContext, useContext, useState, useCallback } from 'react';
import {
  AuditPackScope,
  AuditPackExport,
  PreviewData,
  HIPAAControl,
  Policy,
  EvidenceItem,
  TrainingRecord,
  RiskItem,
  CAPAItem,
  CrosswalkRow,
  ReadinessScore,
  ExportManifest,
  ShareLink,
  ScopeTemplate,
  FRESHNESS_DEFAULTS,
} from '@/types/auditPack';
import { format } from 'date-fns';

// Mock HIPAA Controls
const mockControls: HIPAAControl[] = [
  { id: 'c1', cite: '§164.502', title: 'Uses and Disclosures of PHI', rule: 'PRIVACY', requiredEvidenceTypes: ['policy', 'training'], description: 'Permitted uses and disclosures' },
  { id: 'c2', cite: '§164.520', title: 'Notice of Privacy Practices', rule: 'PRIVACY', requiredEvidenceTypes: ['policy', 'acknowledgment'], description: 'Notice requirements' },
  { id: 'c3', cite: '§164.308(a)(1)', title: 'Security Management Process', rule: 'SECURITY', safeguard: 'ADMINISTRATIVE', requiredEvidenceTypes: ['risk_analysis', 'policy'], description: 'Risk analysis and management' },
  { id: 'c4', cite: '§164.308(a)(3)', title: 'Workforce Security', rule: 'SECURITY', safeguard: 'ADMINISTRATIVE', requiredEvidenceTypes: ['access_review', 'training'], description: 'Authorization and supervision' },
  { id: 'c5', cite: '§164.308(a)(5)', title: 'Security Awareness Training', rule: 'SECURITY', safeguard: 'ADMINISTRATIVE', requiredEvidenceTypes: ['training'], description: 'Security awareness program' },
  { id: 'c6', cite: '§164.310(a)(1)', title: 'Facility Access Controls', rule: 'SECURITY', safeguard: 'PHYSICAL', requiredEvidenceTypes: ['policy', 'access_log'], description: 'Physical safeguards' },
  { id: 'c7', cite: '§164.310(d)(1)', title: 'Device and Media Controls', rule: 'SECURITY', safeguard: 'PHYSICAL', requiredEvidenceTypes: ['policy', 'inventory'], description: 'Hardware and electronic media' },
  { id: 'c8', cite: '§164.312(a)(1)', title: 'Access Control', rule: 'SECURITY', safeguard: 'TECHNICAL', requiredEvidenceTypes: ['access_review', 'policy'], description: 'Unique user identification' },
  { id: 'c9', cite: '§164.312(b)', title: 'Audit Controls', rule: 'SECURITY', safeguard: 'TECHNICAL', requiredEvidenceTypes: ['audit_log', 'policy'], description: 'Hardware, software, procedural mechanisms' },
  { id: 'c10', cite: '§164.312(e)(1)', title: 'Transmission Security', rule: 'SECURITY', safeguard: 'TECHNICAL', requiredEvidenceTypes: ['encryption_cert', 'policy'], description: 'Encryption and integrity controls' },
  { id: 'c11', cite: '§164.400', title: 'Breach Notification Requirements', rule: 'BREACH', requiredEvidenceTypes: ['policy', 'incident_response'], description: 'Notification to individuals and HHS' },
  { id: 'c12', cite: '§164.402', title: 'Breach Definition and Exceptions', rule: 'BREACH', requiredEvidenceTypes: ['policy', 'training'], description: 'What constitutes a breach' },
];

// Mock Policies
const mockPolicies: Policy[] = [
  { id: 'p1', title: 'Privacy Policy', version: '2.1', approvalDate: new Date('2024-01-15'), controlIds: ['c1', 'c2'] },
  { id: 'p2', title: 'Security Management Policy', version: '3.0', approvalDate: new Date('2024-02-01'), controlIds: ['c3', 'c4', 'c5'] },
  { id: 'p3', title: 'Physical Safeguards Policy', version: '1.5', approvalDate: new Date('2024-03-10'), controlIds: ['c6', 'c7'] },
  { id: 'p4', title: 'Technical Safeguards Policy', version: '2.0', approvalDate: new Date('2024-01-20'), controlIds: ['c8', 'c9', 'c10'] },
  { id: 'p5', title: 'Breach Notification Policy', version: '1.2', approvalDate: new Date('2024-02-15'), controlIds: ['c11', 'c12'] },
  { id: 'p6', title: 'Incident Response Plan', version: '2.3', approvalDate: new Date('2024-04-01'), controlIds: ['c11'] },
];

// Mock Evidence
const mockEvidence: EvidenceItem[] = [
  { id: 'e1', title: 'Annual Risk Assessment 2024', controlId: 'c3', policyId: 'p2', type: 'file', evidencePurpose: 'risk_analysis', owner: 'John Smith', collectedAt: new Date('2024-06-15'), expiresAt: new Date('2025-06-15'), containsPHI: false },
  { id: 'e2', title: 'Q1 Access Review Log', controlId: 'c4', policyId: 'p2', type: 'file', evidencePurpose: 'access_review', owner: 'Jane Doe', collectedAt: new Date('2024-03-31'), expiresAt: new Date('2024-06-30'), containsPHI: false },
  { id: 'e3', title: 'Security Training Completion Report', controlId: 'c5', type: 'file', evidencePurpose: 'training', owner: 'HR Dept', collectedAt: new Date('2024-05-01'), expiresAt: new Date('2025-05-01'), containsPHI: false },
  { id: 'e4', title: 'Facility Access Log - May 2024', controlId: 'c6', policyId: 'p3', type: 'file', evidencePurpose: 'access_log', owner: 'Security Team', collectedAt: new Date('2024-05-31'), expiresAt: new Date('2025-05-31'), containsPHI: false },
  { id: 'e5', title: 'Device Inventory Spreadsheet', controlId: 'c7', policyId: 'p3', type: 'file', evidencePurpose: 'inventory', owner: 'IT Dept', collectedAt: new Date('2024-04-15'), expiresAt: new Date('2025-04-15'), containsPHI: false },
  { id: 'e6', title: 'User Access Matrix', controlId: 'c8', policyId: 'p4', type: 'file', evidencePurpose: 'access_review', owner: 'IT Security', collectedAt: new Date('2024-01-15'), expiresAt: new Date('2024-04-15'), containsPHI: true },
  { id: 'e7', title: 'Audit Log Configuration', controlId: 'c9', policyId: 'p4', type: 'link', evidencePurpose: 'audit_log', owner: 'IT Dept', collectedAt: new Date('2024-02-01'), expiresAt: new Date('2025-02-01'), containsPHI: false, linkUrl: 'https://internal.audit-system.com' },
  { id: 'e8', title: 'TLS Certificate', controlId: 'c10', policyId: 'p4', type: 'file', evidencePurpose: 'encryption_cert', owner: 'IT Security', collectedAt: new Date('2024-03-01'), expiresAt: new Date('2025-03-01'), containsPHI: false },
  { id: 'e9', title: 'Breach Response Tabletop Exercise', controlId: 'c11', policyId: 'p6', type: 'file', evidencePurpose: 'incident_response', owner: 'Compliance Team', collectedAt: new Date('2024-04-20'), expiresAt: new Date('2025-04-20'), containsPHI: false },
];

// Mock Training Records
const mockTraining: TrainingRecord[] = [
  { id: 't1', userId: 'u1', userName: 'Alice Johnson', trainingTitle: 'HIPAA Privacy Fundamentals', controlId: 'c1', completedAt: new Date('2024-03-15'), dueDate: new Date('2024-03-31'), status: 'completed' },
  { id: 't2', userId: 'u2', userName: 'Bob Williams', trainingTitle: 'HIPAA Privacy Fundamentals', controlId: 'c1', completedAt: new Date('2024-03-20'), dueDate: new Date('2024-03-31'), status: 'completed' },
  { id: 't3', userId: 'u3', userName: 'Carol Davis', trainingTitle: 'HIPAA Privacy Fundamentals', controlId: 'c1', dueDate: new Date('2024-03-31'), status: 'overdue' },
  { id: 't4', userId: 'u1', userName: 'Alice Johnson', trainingTitle: 'Security Awareness Training', controlId: 'c5', completedAt: new Date('2024-05-01'), dueDate: new Date('2024-05-15'), status: 'completed' },
  { id: 't5', userId: 'u2', userName: 'Bob Williams', trainingTitle: 'Security Awareness Training', controlId: 'c5', completedAt: new Date('2024-05-10'), dueDate: new Date('2024-05-15'), status: 'completed' },
  { id: 't6', userId: 'u3', userName: 'Carol Davis', trainingTitle: 'Security Awareness Training', controlId: 'c5', dueDate: new Date('2024-05-15'), status: 'overdue' },
  { id: 't7', userId: 'u1', userName: 'Alice Johnson', trainingTitle: 'Breach Notification Procedures', controlId: 'c12', completedAt: new Date('2024-02-28'), dueDate: new Date('2024-03-15'), status: 'completed' },
  { id: 't8', userId: 'u2', userName: 'Bob Williams', trainingTitle: 'Breach Notification Procedures', controlId: 'c12', dueDate: new Date('2024-06-30'), status: 'pending' },
];

// Mock Risks
const mockRisks: RiskItem[] = [
  { id: 'r1', title: 'Unencrypted laptop storage', severity: 'high', status: 'mitigated', identifiedAt: new Date('2024-01-15'), controlId: 'c10' },
  { id: 'r2', title: 'Outdated access control lists', severity: 'medium', status: 'open', identifiedAt: new Date('2024-04-01'), controlId: 'c8' },
  { id: 'r3', title: 'Missing audit log retention', severity: 'low', status: 'closed', identifiedAt: new Date('2024-02-10'), controlId: 'c9' },
];

// Mock CAPAs
const mockCAPAs: CAPAItem[] = [
  { id: 'capa1', title: 'Implement full-disk encryption', status: 'completed', dueDate: new Date('2024-03-01'), completedAt: new Date('2024-02-28'), controlId: 'c10' },
  { id: 'capa2', title: 'Update access control procedures', status: 'in_progress', dueDate: new Date('2024-07-15'), controlId: 'c8' },
  { id: 'capa3', title: 'Extend audit log retention to 6 years', status: 'completed', dueDate: new Date('2024-03-15'), completedAt: new Date('2024-03-10'), controlId: 'c9' },
];

interface AuditPackContextType {
  controls: HIPAAControl[];
  policies: Policy[];
  evidence: EvidenceItem[];
  training: TrainingRecord[];
  risks: RiskItem[];
  capas: CAPAItem[];
  exports: AuditPackExport[];
  shareLinks: ShareLink[];
  scopeTemplates: ScopeTemplate[];
  currentScope: AuditPackScope | null;
  setCurrentScope: (scope: AuditPackScope | null) => void;
  generatePreview: (scope: AuditPackScope) => PreviewData;
  generateExport: (scope: AuditPackScope, userName: string) => Promise<AuditPackExport>;
  getExportHistory: () => AuditPackExport[];
  createShareLink: (exportId: string, userName: string) => ShareLink;
  revokeShareLink: (linkId: string) => void;
  getExportByShareToken: (token: string) => { export: AuditPackExport; link: ShareLink } | null;
  saveTemplate: (name: string, description: string, scope: Omit<AuditPackScope, 'dateRange'>, userName: string) => ScopeTemplate;
  deleteTemplate: (templateId: string) => void;
  departments: string[];
  locations: string[];
}

const AuditPackContext = createContext<AuditPackContextType | null>(null);

export function AuditPackProvider({ children }: { children: React.ReactNode }) {
  const [exports, setExports] = useState<AuditPackExport[]>([]);
  const [shareLinks, setShareLinks] = useState<ShareLink[]>([]);
  const [scopeTemplates, setScopeTemplates] = useState<ScopeTemplate[]>([
    {
      id: 'tpl-1',
      name: 'Annual HIPAA Review',
      description: 'Full scope audit for annual compliance review',
      scope: { includeLinks: true, includeEvidenceFiles: true, includePHI: false },
      createdAt: new Date('2024-01-01'),
      createdBy: 'System',
    },
    {
      id: 'tpl-2',
      name: 'Security Rule Focus',
      description: 'Security rule controls only with all safeguards',
      scope: { 
        controls: ['c3', 'c4', 'c5', 'c6', 'c7', 'c8', 'c9', 'c10'],
        includeLinks: true, 
        includeEvidenceFiles: true, 
        includePHI: false 
      },
      createdAt: new Date('2024-02-15'),
      createdBy: 'System',
    },
  ]);
  const [currentScope, setCurrentScope] = useState<AuditPackScope | null>(null);

  const departments = ['Compliance', 'IT', 'HR', 'Operations', 'Finance'];
  const locations = ['Main Campus', 'North Clinic', 'South Clinic', 'Remote'];

  const isEvidenceFresh = useCallback((evidence: EvidenceItem): boolean => {
    const now = new Date();
    return evidence.expiresAt > now;
  }, []);

  const generatePreview = useCallback((scope: AuditPackScope): PreviewData => {
    // Filter controls based on scope
    let filteredControls = [...mockControls];
    if (scope.controls && scope.controls.length > 0) {
      filteredControls = filteredControls.filter(c => scope.controls!.includes(c.id));
    }

    // Filter policies based on scope
    let filteredPolicies = [...mockPolicies];
    if (scope.policies && scope.policies.length > 0) {
      filteredPolicies = filteredPolicies.filter(p => scope.policies!.includes(p.id));
    }

    // Filter evidence by date range and controls
    const filteredEvidence = mockEvidence.filter(e => {
      const inDateRange = e.collectedAt >= scope.dateRange.start && e.collectedAt <= scope.dateRange.end;
      const inControls = filteredControls.some(c => c.id === e.controlId);
      return inDateRange && inControls;
    });

    // Calculate evidence summary
    const currentEvidence = filteredEvidence.filter(e => isEvidenceFresh(e));
    const staleEvidence = filteredEvidence.filter(e => !isEvidenceFresh(e));
    
    const missingByControl = filteredControls.map(control => {
      const controlEvidence = filteredEvidence.filter(e => e.controlId === control.id);
      const coveredTypes = controlEvidence.map(e => e.evidencePurpose);
      const missing = control.requiredEvidenceTypes.filter(t => !coveredTypes.includes(t));
      return { controlCite: control.cite, controlTitle: control.title, missing };
    }).filter(m => m.missing.length > 0);

    // Training summary
    const filteredTraining = mockTraining.filter(t => 
      filteredControls.some(c => c.id === t.controlId)
    );
    const completedTraining = filteredTraining.filter(t => t.status === 'completed');
    const overdueTraining = filteredTraining.filter(t => t.status === 'overdue');

    // Crosswalk
    const crosswalk: CrosswalkRow[] = filteredControls.map(control => {
      const controlPolicies = filteredPolicies.filter(p => p.controlIds.includes(control.id));
      const controlEvidence = filteredEvidence.filter(e => e.controlId === control.id);
      const controlTraining = filteredTraining.filter(t => t.controlId === control.id);
      const completedControlTraining = controlTraining.filter(t => t.status === 'completed');

      const gaps: string[] = [];
      if (controlPolicies.length === 0) gaps.push('No policy mapped');
      if (controlEvidence.length === 0) gaps.push('No evidence');
      const staleCount = controlEvidence.filter(e => !isEvidenceFresh(e)).length;
      if (staleCount > 0) gaps.push(`${staleCount} stale evidence`);
      const missingTypes = control.requiredEvidenceTypes.filter(
        t => !controlEvidence.some(e => e.evidencePurpose === t)
      );
      if (missingTypes.length > 0) gaps.push(`Missing: ${missingTypes.join(', ')}`);

      return {
        rule: control.rule,
        safeguard: control.safeguard,
        controlCite: control.cite,
        controlTitle: control.title,
        policies: controlPolicies.map(p => p.title),
        evidenceCount: controlEvidence.length,
        currentEvidenceCount: controlEvidence.filter(e => isEvidenceFresh(e)).length,
        staleEvidenceCount: staleCount,
        trainingCompletion: controlTraining.length > 0 
          ? Math.round((completedControlTraining.length / controlTraining.length) * 100) 
          : 100,
        gaps,
      };
    });

    // Readiness score calculation
    const policyCoverage = filteredControls.filter(c => 
      filteredPolicies.some(p => p.controlIds.includes(c.id))
    ).length / filteredControls.length;

    const trainingCompletion = filteredTraining.length > 0 
      ? completedTraining.length / filteredTraining.length 
      : 1;

    const evidenceCoverage = filteredControls.filter(c => 
      filteredEvidence.some(e => e.controlId === c.id)
    ).length / filteredControls.length;

    const staleCount = staleEvidence.length;
    const overdueCapas = mockCAPAs.filter(c => c.status === 'overdue').length;
    const penaltyScore = Math.max(0, 1 - (staleCount * 0.05 + overdueCapas * 0.1));

    const totalScore = Math.round(
      (policyCoverage * 30) + 
      (trainingCompletion * 25) + 
      (evidenceCoverage * 30) + 
      (penaltyScore * 15)
    );

    const nextActions: string[] = [];
    if (policyCoverage < 1) nextActions.push('Map policies to all controls');
    if (staleCount > 0) nextActions.push(`Refresh ${staleCount} stale evidence items`);
    if (missingByControl.length > 0) nextActions.push('Collect missing evidence for gaps');
    if (overdueTraining.length > 0) nextActions.push(`Complete ${overdueTraining.length} overdue training assignments`);

    return {
      policiesIncluded: filteredPolicies,
      evidenceSummary: {
        total: filteredEvidence.length,
        current: currentEvidence.length,
        stale: staleEvidence.length,
        missingByControl,
      },
      trainingSummary: {
        totalAssignments: filteredTraining.length,
        completedCount: completedTraining.length,
        overdueCount: overdueTraining.length,
        completionPercent: filteredTraining.length > 0 
          ? Math.round((completedTraining.length / filteredTraining.length) * 100)
          : 100,
      },
      risksSummary: {
        total: mockRisks.length,
        open: mockRisks.filter(r => r.status === 'open').length,
        critical: mockRisks.filter(r => r.severity === 'critical' || r.severity === 'high').length,
      },
      capasSummary: {
        total: mockCAPAs.length,
        overdue: mockCAPAs.filter(c => c.status === 'overdue').length,
        inProgress: mockCAPAs.filter(c => c.status === 'in_progress').length,
      },
      readinessScore: {
        total: totalScore,
        breakdown: {
          policyCoverage: Math.round(policyCoverage * 30),
          trainingCompletion: Math.round(trainingCompletion * 25),
          evidenceCoverage: Math.round(evidenceCoverage * 30),
          penalties: Math.round(penaltyScore * 15),
        },
        nextActions,
      },
      crosswalk,
    };
  }, [isEvidenceFresh]);

  const generateExport = useCallback(async (scope: AuditPackScope, userName: string): Promise<AuditPackExport> => {
    // Simulate async generation
    await new Promise(resolve => setTimeout(resolve, 2000));

    const preview = generatePreview(scope);
    const exportId = `EXP-${Date.now()}`;
    const scopeLabel = `${format(scope.dateRange.start, 'MMM d, yyyy')} - ${format(scope.dateRange.end, 'MMM d, yyyy')}`;
    
    // Generate a mock SHA-256 hash
    const mockHash = Array.from({ length: 64 }, () => 
      '0123456789abcdef'[Math.floor(Math.random() * 16)]
    ).join('');

    const newExport: AuditPackExport = {
      id: exportId,
      createdAt: new Date(),
      createdBy: userName,
      scope,
      scopeLabel,
      zipSha256: mockHash,
      readinessScore: preview.readinessScore.total,
      status: 'completed',
    };

    setExports(prev => [newExport, ...prev]);
    return newExport;
  }, [generatePreview]);

  const getExportHistory = useCallback(() => exports, [exports]);

  const createShareLink = useCallback((exportId: string, userName: string): ShareLink => {
    const link: ShareLink = {
      id: `SL-${Date.now()}`,
      exportId,
      token: Array.from({ length: 32 }, () => 
        'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'[Math.floor(Math.random() * 62)]
      ).join(''),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
      createdAt: new Date(),
      createdBy: userName,
      revoked: false,
    };
    setShareLinks(prev => [...prev, link]);
    return link;
  }, []);

  const revokeShareLink = useCallback((linkId: string) => {
    setShareLinks(prev => prev.map(l => 
      l.id === linkId ? { ...l, revoked: true } : l
    ));
  }, []);

  const getExportByShareToken = useCallback((token: string): { export: AuditPackExport; link: ShareLink } | null => {
    const link = shareLinks.find(l => l.token === token && !l.revoked);
    if (!link) return null;
    if (link.expiresAt < new Date()) return null;
    const exp = exports.find(e => e.id === link.exportId);
    if (!exp) return null;
    return { export: exp, link };
  }, [shareLinks, exports]);

  const saveTemplate = useCallback((
    name: string, 
    description: string, 
    scope: Omit<AuditPackScope, 'dateRange'>, 
    userName: string
  ): ScopeTemplate => {
    const template: ScopeTemplate = {
      id: `tpl-${Date.now()}`,
      name,
      description,
      scope,
      createdAt: new Date(),
      createdBy: userName,
    };
    setScopeTemplates(prev => [...prev, template]);
    return template;
  }, []);

  const deleteTemplate = useCallback((templateId: string) => {
    setScopeTemplates(prev => prev.filter(t => t.id !== templateId));
  }, []);

  return (
    <AuditPackContext.Provider value={{
      controls: mockControls,
      policies: mockPolicies,
      evidence: mockEvidence,
      training: mockTraining,
      risks: mockRisks,
      capas: mockCAPAs,
      exports,
      shareLinks,
      scopeTemplates,
      currentScope,
      setCurrentScope,
      generatePreview,
      generateExport,
      getExportHistory,
      createShareLink,
      revokeShareLink,
      getExportByShareToken,
      saveTemplate,
      deleteTemplate,
      departments,
      locations,
    }}>
      {children}
    </AuditPackContext.Provider>
  );
}

export function useAuditPack() {
  const context = useContext(AuditPackContext);
  if (!context) {
    throw new Error('useAuditPack must be used within an AuditPackProvider');
  }
  return context;
}
