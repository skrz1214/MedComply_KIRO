import React, { createContext, useContext, useState, ReactNode } from 'react';
import { CAP, CAPAction, CAPEvidence, CAPVerification, CAPStatus } from '@/types/cap';

interface CAPContextType {
  caps: CAP[];
  createCAP: (cap: Omit<CAP, 'id' | 'createdAt' | 'updatedAt' | 'actions' | 'evidence' | 'status'>) => CAP;
  updateCAP: (id: string, updates: Partial<CAP>) => void;
  deleteCAP: (id: string) => void;
  getCAPByAuditId: (auditId: string) => CAP | undefined;
  
  // Actions
  addCAPAction: (capId: string, action: Omit<CAPAction, 'id' | 'createdAt' | 'updatedAt' | 'evidence' | 'status'>) => void;
  updateCAPAction: (capId: string, actionId: string, updates: Partial<CAPAction>) => void;
  deleteCAPAction: (capId: string, actionId: string) => void;
  markActionComplete: (capId: string, actionId: string, completedBy: string) => void;
  
  // Evidence
  addCAPEvidence: (capId: string, evidence: Omit<CAPEvidence, 'id'>, actionId?: string) => void;
  removeCAPEvidence: (capId: string, evidenceId: string) => void;
  
  // Verification
  submitForVerification: (capId: string) => void;
  verifyCAPAndClose: (capId: string, verification: Omit<CAPVerification, 'id'>) => void;
}

const CAPContext = createContext<CAPContextType | undefined>(undefined);

export function CAPProvider({ children }: { children: ReactNode }) {
  const [caps, setCaps] = useState<CAP[]>([]);

  const createCAP = (capData: Omit<CAP, 'id' | 'createdAt' | 'updatedAt' | 'actions' | 'evidence' | 'status'>): CAP => {
    const newCAP: CAP = {
      ...capData,
      id: Date.now().toString(),
      status: 'not_started',
      actions: [],
      evidence: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setCaps(prev => [...prev, newCAP]);
    return newCAP;
  };

  const updateCAP = (id: string, updates: Partial<CAP>) => {
    setCaps(prev => prev.map(cap => 
      cap.id === id 
        ? { ...cap, ...updates, updatedAt: new Date().toISOString() } 
        : cap
    ));
  };

  const deleteCAP = (id: string) => {
    setCaps(prev => prev.filter(cap => cap.id !== id));
  };

  const getCAPByAuditId = (auditId: string): CAP | undefined => {
    return caps.find(cap => cap.auditId === auditId);
  };

  const addCAPAction = (
    capId: string, 
    action: Omit<CAPAction, 'id' | 'createdAt' | 'updatedAt' | 'evidence' | 'status'>
  ) => {
    const newAction: CAPAction = {
      ...action,
      id: Date.now().toString(),
      status: 'pending',
      evidence: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setCaps(prev => prev.map(cap => {
      if (cap.id === capId) {
        const newStatus: CAPStatus = cap.status === 'not_started' ? 'in_progress' : cap.status;
        return {
          ...cap,
          actions: [...cap.actions, newAction],
          status: newStatus,
          updatedAt: new Date().toISOString(),
        };
      }
      return cap;
    }));
  };

  const updateCAPAction = (capId: string, actionId: string, updates: Partial<CAPAction>) => {
    setCaps(prev => prev.map(cap => {
      if (cap.id === capId) {
        return {
          ...cap,
          actions: cap.actions.map(action => 
            action.id === actionId 
              ? { ...action, ...updates, updatedAt: new Date().toISOString() } 
              : action
          ),
          updatedAt: new Date().toISOString(),
        };
      }
      return cap;
    }));
  };

  const deleteCAPAction = (capId: string, actionId: string) => {
    setCaps(prev => prev.map(cap => {
      if (cap.id === capId) {
        return {
          ...cap,
          actions: cap.actions.filter(action => action.id !== actionId),
          updatedAt: new Date().toISOString(),
        };
      }
      return cap;
    }));
  };

  const markActionComplete = (capId: string, actionId: string, completedBy: string) => {
    updateCAPAction(capId, actionId, {
      status: 'completed',
      completedAt: new Date().toISOString(),
      completedBy,
    });
  };

  const addCAPEvidence = (
    capId: string, 
    evidence: Omit<CAPEvidence, 'id'>, 
    actionId?: string
  ) => {
    const newEvidence: CAPEvidence = {
      ...evidence,
      id: Date.now().toString(),
      actionId,
    };

    setCaps(prev => prev.map(cap => {
      if (cap.id === capId) {
        if (actionId) {
          // Add to specific action
          return {
            ...cap,
            actions: cap.actions.map(action => 
              action.id === actionId 
                ? { ...action, evidence: [...action.evidence, newEvidence], updatedAt: new Date().toISOString() } 
                : action
            ),
            updatedAt: new Date().toISOString(),
          };
        } else {
          // Add to CAP-level evidence
          return {
            ...cap,
            evidence: [...cap.evidence, newEvidence],
            updatedAt: new Date().toISOString(),
          };
        }
      }
      return cap;
    }));
  };

  const removeCAPEvidence = (capId: string, evidenceId: string) => {
    setCaps(prev => prev.map(cap => {
      if (cap.id === capId) {
        return {
          ...cap,
          evidence: cap.evidence.filter(e => e.id !== evidenceId),
          actions: cap.actions.map(action => ({
            ...action,
            evidence: action.evidence.filter(e => e.id !== evidenceId),
          })),
          updatedAt: new Date().toISOString(),
        };
      }
      return cap;
    }));
  };

  const submitForVerification = (capId: string) => {
    updateCAP(capId, { status: 'ready_for_verification' });
  };

  const verifyCAPAndClose = (capId: string, verification: Omit<CAPVerification, 'id'>) => {
    const verificationRecord: CAPVerification = {
      ...verification,
      id: Date.now().toString(),
    };

    setCaps(prev => prev.map(cap => {
      if (cap.id === capId) {
        return {
          ...cap,
          verification: verificationRecord,
          status: verification.outcome === 'pass' ? 'verified' : 'in_progress',
          updatedAt: new Date().toISOString(),
          closedAt: verification.outcome === 'pass' ? new Date().toISOString() : undefined,
          closedBy: verification.outcome === 'pass' ? verification.verifierName : undefined,
        };
      }
      return cap;
    }));
  };

  return (
    <CAPContext.Provider value={{
      caps,
      createCAP,
      updateCAP,
      deleteCAP,
      getCAPByAuditId,
      addCAPAction,
      updateCAPAction,
      deleteCAPAction,
      markActionComplete,
      addCAPEvidence,
      removeCAPEvidence,
      submitForVerification,
      verifyCAPAndClose,
    }}>
      {children}
    </CAPContext.Provider>
  );
}

export function useCAP() {
  const context = useContext(CAPContext);
  if (!context) {
    throw new Error('useCAP must be used within a CAPProvider');
  }
  return context;
}
