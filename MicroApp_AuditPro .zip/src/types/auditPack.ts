// Audit Pack Types

export type HIPAARule = 'PRIVACY' | 'SECURITY' | 'BREACH';
export type SecuritySafeguard = 'ADMINISTRATIVE' | 'PHYSICAL' | 'TECHNICAL';

export interface AuditPackScope {
  dateRange: {
    start: Date;
    end: Date;
  };
  locations?: string[];
  departments?: string[];
  controls?: string[];
  policies?: string[];
  includeLinks: boolean;
  includeEvidenceFiles: boolean;
  includePHI: boolean;
}

export interface HIPAAControl {
  id: string;
  cite: string;
  title: string;
  rule: HIPAARule;
  safeguard?: SecuritySafeguard;
  requiredEvidenceTypes: string[];
  description: string;
}

export interface Policy {
  id: string;
  title: string;
  version: string;
  approvalDate: Date;
  expiresAt?: Date;
  fileReference?: string;
  controlIds: string[];
}

export interface EvidenceItem {
  id: string;
  title: string;
  controlId: string;
  policyId?: string;
  type: 'file' | 'link' | 'note';
  evidencePurpose: string;
  owner: string;
  collectedAt: Date;
  expiresAt: Date;
  containsPHI: boolean;
  fileReference?: string;
  linkUrl?: string;
  note?: string;
}

export interface TrainingRecord {
  id: string;
  userId: string;
  userName: string;
  trainingTitle: string;
  controlId: string;
  completedAt?: Date;
  dueDate: Date;
  status: 'completed' | 'pending' | 'overdue';
}

export interface RiskItem {
  id: string;
  title: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: 'open' | 'mitigated' | 'accepted' | 'closed';
  identifiedAt: Date;
  controlId?: string;
}

export interface CAPAItem {
  id: string;
  title: string;
  status: 'open' | 'in_progress' | 'completed' | 'overdue';
  dueDate: Date;
  completedAt?: Date;
  controlId?: string;
}

export interface EvidenceIndexRow {
  rule: HIPAARule;
  safeguard?: SecuritySafeguard;
  controlCite: string;
  controlTitle: string;
  policyTitle?: string;
  evidenceTitle: string;
  evidencePurpose: string;
  evidenceType: 'file' | 'link' | 'note';
  owner: string;
  collectedAt: Date;
  expiresAt: Date;
  freshness: 'CURRENT' | 'STALE';
  filePathInZip?: string;
  containsPHI: boolean;
}

export interface CrosswalkRow {
  rule: HIPAARule;
  safeguard?: SecuritySafeguard;
  controlCite: string;
  controlTitle: string;
  policies: string[];
  evidenceCount: number;
  currentEvidenceCount: number;
  staleEvidenceCount: number;
  trainingCompletion: number;
  gaps: string[];
}

export interface ReadinessScore {
  total: number;
  breakdown: {
    policyCoverage: number;
    trainingCompletion: number;
    evidenceCoverage: number;
    penalties: number;
  };
  nextActions: string[];
}

export interface PreviewData {
  policiesIncluded: Policy[];
  evidenceSummary: {
    total: number;
    current: number;
    stale: number;
    missingByControl: { controlCite: string; controlTitle: string; missing: string[] }[];
  };
  trainingSummary: {
    totalAssignments: number;
    completedCount: number;
    overdueCount: number;
    completionPercent: number;
  };
  risksSummary?: {
    total: number;
    open: number;
    critical: number;
  };
  capasSummary?: {
    total: number;
    overdue: number;
    inProgress: number;
  };
  readinessScore: ReadinessScore;
  crosswalk: CrosswalkRow[];
}

export interface AuditPackExport {
  id: string;
  createdAt: Date;
  createdBy: string;
  scope: AuditPackScope;
  scopeLabel: string;
  zipSha256: string;
  readinessScore: number;
  status: 'completed' | 'failed' | 'generating';
  readmePdfUrl?: string;
  zipUrl?: string;
  manifestUrl?: string;
}

export interface ShareLink {
  id: string;
  exportId: string;
  token: string;
  expiresAt: Date;
  createdAt: Date;
  createdBy: string;
  revoked: boolean;
}

export interface ScopeTemplate {
  id: string;
  name: string;
  description?: string;
  scope: Omit<AuditPackScope, 'dateRange'>;
  createdAt: Date;
  createdBy: string;
}

export interface ExportManifest {
  exportId: string;
  generatedAt: string;
  generatedBy: string;
  scope: AuditPackScope;
  readinessScore: ReadinessScore;
  counts: {
    policies: number;
    evidenceItems: number;
    trainingRecords: number;
    risks: number;
    capas: number;
  };
  zipSha256: string;
}

// Freshness configuration (in days)
export const FRESHNESS_DEFAULTS: Record<string, number> = {
  training: 365,
  risk_analysis: 365,
  access_review: 90,
  incident_response: 365,
  vendor_baa_review: 365,
  default: 365,
};
