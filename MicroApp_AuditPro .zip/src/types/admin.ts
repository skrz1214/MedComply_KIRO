// Admin Settings Types for AuditPro

// Updated Role System per PRD v1.0
export type UserRoleV2 = 'staff' | 'department_head' | 'compliance_head' | 'admin';

export const ROLE_LABELS: Record<UserRoleV2, string> = {
  staff: 'Staff (Read-only)',
  department_head: 'Department Head',
  compliance_head: 'Compliance Head',
  admin: 'Admin',
};

export const ROLE_DESCRIPTIONS: Record<UserRoleV2, string> = {
  staff: 'Can view audits they are assigned to or belong to their department. Read-only access.',
  department_head: 'Oversees department audits. Can assign, upload evidence, complete actions, and perform internal reviews.',
  compliance_head: 'QA/Compliance authority for external audit closures. Can perform final determinations and CAP decisions.',
  admin: 'Full system access. Can manage all settings, departments, routing rules, and configurations.',
};

// Department Configuration
export interface DepartmentConfig {
  id: string;
  name: string;
  code: string;
  isComplianceOwner: boolean;
  headUserId?: string;
  createdAt: string;
  updatedAt: string;
}

// Status Configuration
export interface StatusConfig {
  id: string;
  code: string;
  label: string;
  color: string;
  isActive: boolean;
  sortOrder: number;
  allowedTransitions: string[];
}

// Phase Configuration
export interface PhaseConfig {
  id: string;
  code: string;
  label: string;
  icon: string;
  requiredEvidence: boolean;
  requiredActions: boolean;
  gatingRules: PhaseGatingRule[];
  isActive: boolean;
  sortOrder: number;
}

export interface PhaseGatingRule {
  id: string;
  description: string;
  type: 'evidence_count' | 'action_completion' | 'approval_required' | 'custom';
  value: string | number;
  isRequired: boolean;
}

// Default Assignees per Phase
// One row per phase with separate defaults for internal vs external audits.
// These are SUGGESTIONS — users can override the assignee to anyone, anytime.
export interface DefaultAssignee {
  phase: string;
  internalRole: UserRoleV2;
  externalRole: UserRoleV2;
}

// Action Templates
export interface ActionTemplate {
  id: string;
  name: string;
  description: string;
  auditType: 'internal' | 'external' | 'both';
  department?: string;
  phase?: string;
  actions: ActionTemplateItem[];
  isActive: boolean;
  priority: number;
  createdAt: string;
  updatedAt: string;
}

export interface ActionTemplateItem {
  id: string;
  description: string;
  isRequired: boolean;
  sortOrder: number;
}

// Evidence & Attachment Policy
export interface EvidencePolicy {
  id: string;
  name: string;
  allowedFileTypes: string[];
  maxFileSize: number; // in MB
  maxFilesPerPhase: number;
  requiredPhases: string[];
  description: string;
  isActive: boolean;
}

// Periodic Audit Rules
export interface PeriodicRule {
  id: string;
  periodicity: string;
  autoCreateNextInstance: boolean;
  advanceNoticeDays: number;
  missedScheduleHandling: 'skip' | 'create_overdue' | 'notify_only';
  description: string;
  isActive: boolean;
}

// Notification Configuration
export interface NotificationConfig {
  id: string;
  trigger: string;
  triggerLabel: string;
  emailEnabled: boolean;
  inAppEnabled: boolean;
  targetRoles: UserRoleV2[];
  template: string;
  isActive: boolean;
}

// Integration Configuration
export interface IntegrationConfig {
  id: string;
  name: string;
  type: 'compliance_connect' | 'risk_guard' | 'feedback_hub' | 'enforce_point';
  isEnabled: boolean;
  apiEndpoint?: string;
  fieldMappings: FieldMapping[];
  retryPolicy: RetryPolicy;
  lastSyncAt?: string;
  errorLogs: IntegrationErrorLog[];
}

export interface FieldMapping {
  sourceField: string;
  targetField: string;
  transformRule?: string;
}

export interface RetryPolicy {
  maxRetries: number;
  retryDelaySeconds: number;
  exponentialBackoff: boolean;
}

export interface IntegrationErrorLog {
  id: string;
  timestamp: string;
  message: string;
  severity: 'info' | 'warning' | 'error';
}

// Permission Matrix
export interface PermissionMatrix {
  role: UserRoleV2;
  permissions: Permission[];
}

export interface Permission {
  id: string;
  resource: string;
  action: 'view' | 'create' | 'edit' | 'delete' | 'approve' | 'reject' | 'upload' | 'assign';
  isAllowed: boolean;
}

// Settings Change Log
export interface SettingsChangeLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  settingArea: string;
  changeType: 'create' | 'update' | 'delete';
  beforeValue: string;
  afterValue: string;
  description: string;
}

// Metrics Targets Configuration
export interface MetricsPolicy {
  overdueRateTarget: number; // percentage, e.g., 10 = 10%
  cycleTimeTargetDays: number; // days
  cycleTimeByPriority: {
    low: number;
    medium: number;
    high: number;
    critical: number;
  };
  onTimeCompletionTarget: number; // percentage, e.g., 90 = 90%
  internalReviewTurnaroundDays: number; // days
  capRequiredRateTarget: number; // percentage for external audits
}

// Admin Settings State
export interface AdminSettings {
  departments: DepartmentConfig[];
  statuses: StatusConfig[];
  phases: PhaseConfig[];
  defaultAssignees: DefaultAssignee[];
  actionTemplates: ActionTemplate[];
  evidencePolicy: EvidencePolicy;
  periodicRules: PeriodicRule[];
  notifications: NotificationConfig[];
  integrations: IntegrationConfig[];
  permissionMatrix: PermissionMatrix[];
  changeLogs: SettingsChangeLog[];
  metricsPolicy: MetricsPolicy;
}
