// AuditPro v2: Phase is the single source of truth for audit lifecycle position.
// Status has been removed from the UI. The 12 phases below cover every state
// previously expressed by status + phase combined.

export type AuditPhase =
  | 'draft'                  // Created but not yet submitted
  | 'pre_audit'              // Pre-audit preparation in progress
  | 'pre_audit_review'       // Pre-audit submitted, awaiting approval
  | 'overview'               // Approved, audit officially started
  | 'evidence_collection'    // Gathering evidence
  | 'evaluation'             // Reviewing collected evidence
  | 'internal_review'        // Submitted for internal review
  | 'remediation_required'   // Sent back for fixes
  | 'closure_cap'            // Closure & CAP decision
  | 'cap_active'             // CAP being executed externally
  | 'pending_verification'   // CAP done, awaiting QA verification
  | 'closed';                // Final state

// Deprecated: kept as an alias to AuditPhase so legacy code still compiles.
// Do NOT use AuditStatus in new code — use AuditPhase / currentPhase only.
export type AuditStatus = AuditPhase;

export type ClosureType =
  | 'with_cap'
  | 'without_cap'
  | 'risk_accepted'
  | 'duplicate_merged'
  | 'invalidated';

export const CLOSURE_TYPE_LABELS: Record<ClosureType, string> = {
  with_cap: 'Closed – With CAP',
  without_cap: 'Closed – Without CAP',
  risk_accepted: 'Closed – Risk Accepted',
  duplicate_merged: 'Closed – Duplicate/Merged',
  invalidated: 'Closed – Invalidated',
};

export type AuditType = 'internal' | 'external';

// Updated Role System per PRD v1.0
export type UserRole = 'staff' | 'department_head' | 'compliance_head' | 'admin';

export const USER_ROLE_LABELS: Record<UserRole, string> = {
  staff: 'Staff (Read-only)',
  department_head: 'Department Head',
  compliance_head: 'Compliance Head',
  admin: 'Admin',
};

export const USER_ROLE_DESCRIPTIONS: Record<UserRole, string> = {
  staff: 'Can view audits they are assigned to or belong to their department. Read-only access.',
  department_head: 'Oversees department audits. Can assign, upload evidence, complete actions, and perform internal reviews.',
  compliance_head: 'QA/Compliance authority for external audit closures. Can perform final determinations and CAP decisions.',
  admin: 'Full system access. Can manage all settings, departments, routing rules, and configurations.',
};

export type Periodicity =
  | 'one_time'
  | 'daily'
  | 'weekly'
  | 'monthly'
  | 'quarterly'
  | 'annually';

export type MicroApp = 'RiskGuard' | 'ComplianceConnect' | 'FeedbackHub' | 'EnforcePoint';

export interface LinkedItem {
  id: string;
  microApp: MicroApp;
  itemId: string;
  itemTitle: string;
  itemType: string;
  status: string; // status of the linked external item (not AuditPro state)
  linkedAt: string;
  linkedBy: string;
  url?: string;
}

export const MICROAPP_LABELS: Record<MicroApp, string> = {
  RiskGuard: 'RiskGuard',
  ComplianceConnect: 'Compliance Connect',
  FeedbackHub: 'Feedback Hub',
  EnforcePoint: 'EnforcePoint',
};

export const MICROAPP_COLORS: Record<MicroApp, string> = {
  RiskGuard: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
  ComplianceConnect: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  FeedbackHub: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  EnforcePoint: 'bg-red-500/10 text-red-600 border-red-500/20',
};

export interface AuditItem {
  id: string;
  title: string;
  description: string;
  type: AuditType;
  /**
   * @deprecated Use `currentPhase` instead. Kept as an internal alias for
   * legacy code paths. Always equals `currentPhase` in v2.
   */
  status: AuditPhase;
  closureType?: ClosureType;
  closureReason?: string;
  department: string;
  assignedTo: string;
  assignedToName: string;
  createdBy: string;
  createdAt: string;
  dueDate: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  /** @deprecated Use currentPhase. */
  phase: AuditPhase;
  currentPhase: AuditPhase;
  evidence: Evidence[];
  actions: AuditAction[];
  reviewNotes?: string;
  capRequired?: boolean;
  isPeriodic: boolean;
  periodicity?: Periodicity;
  nextScheduledDate?: string;
  phaseAttachments: PhaseAttachments;
  phaseAssignees?: PhaseAssignees;
  history: AuditHistoryEntry[];
  linkedItems?: LinkedItem[];
}

export interface PhaseAttachments {
  draft: Evidence[];
  pre_audit: Evidence[];
  pre_audit_review: Evidence[];
  overview: Evidence[];
  evidence_collection: Evidence[];
  evaluation: Evidence[];
  internal_review: Evidence[];
  remediation_required: Evidence[];
  closure_cap: Evidence[];
  cap_active: Evidence[];
  pending_verification: Evidence[];
  closed: Evidence[];
}

export interface PhaseAssignees {
  draft: string;
  pre_audit: string;
  pre_audit_review: string;
  overview: string;
  evidence_collection: string;
  evaluation: string;
  internal_review: string;
  remediation_required: string;
  closure_cap: string;
  cap_active: string;
  pending_verification: string;
  closed: string;
}

export interface AuditHistoryEntry {
  id: string;
  action: string;
  phase: AuditPhase | string;
  performedBy: string;
  performedAt: string;
  notes?: string;
}

export interface Evidence {
  id: string;
  name: string;
  type: string;
  uploadedAt: string;
  uploadedBy: string;
  url: string;
}

export interface AuditAction {
  id: string;
  description: string;
  completed: boolean;
  completedAt?: string;
  completedBy?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
}

export interface Department {
  id: string;
  name: string;
  code: string;
}

export const PHASE_LABELS: Record<AuditPhase, string> = {
  draft: 'Draft',
  pre_audit: 'Pre-Audit Preparation',
  pre_audit_review: 'Pre-Audit Review',
  overview: 'Audit Overview',
  evidence_collection: 'Evidence Collection',
  evaluation: 'Evaluation',
  internal_review: 'Internal Review',
  remediation_required: 'Remediation Required',
  closure_cap: 'Closure & CAP',
  cap_active: 'CAP Active',
  pending_verification: 'Pending Verification',
  closed: 'Closed',
};

/** Ordered phase list — drives stepper, navigation, and admin sort order. */
export const PHASE_ORDER: AuditPhase[] = [
  'draft',
  'pre_audit',
  'pre_audit_review',
  'overview',
  'evidence_collection',
  'evaluation',
  'internal_review',
  'remediation_required',
  'closure_cap',
  'cap_active',
  'pending_verification',
  'closed',
];

export const PERIODICITY_LABELS: Record<Periodicity, string> = {
  one_time: 'One Time',
  daily: 'Daily',
  weekly: 'Weekly',
  monthly: 'Monthly',
  quarterly: 'Quarterly',
  annually: 'Annually',
};
