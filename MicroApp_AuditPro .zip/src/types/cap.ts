// CAP (Corrective Action Plan) Types

export type CAPStatus = 
  | 'not_started'
  | 'in_progress'
  | 'blocked'
  | 'ready_for_verification'
  | 'verified'
  | 'closed';

export type CAPActionType = 'corrective' | 'preventive';

export interface CAPAction {
  id: string;
  title: string;
  description: string;
  type: CAPActionType;
  ownerId: string;
  ownerName: string;
  dueDate: string;
  status: 'pending' | 'in_progress' | 'completed' | 'blocked';
  completedAt?: string;
  completedBy?: string;
  evidence: CAPEvidence[];
  createdAt: string;
  updatedAt: string;
}

export interface CAPEvidence {
  id: string;
  name: string;
  type: string;
  uploadedAt: string;
  uploadedBy: string;
  url: string;
  actionId?: string; // Optional link to specific action
}

export interface CAPVerification {
  id: string;
  verifierId: string;
  verifierName: string;
  verifiedAt: string;
  outcome: 'pass' | 'fail';
  notes: string;
  evidence: CAPEvidence[];
}

export interface CAP {
  id: string;
  auditId: string;
  rootCause: string;
  status: CAPStatus;
  ownerId: string;
  ownerName: string;
  targetCompletionDate: string;
  actions: CAPAction[];
  evidence: CAPEvidence[];
  verification?: CAPVerification;
  createdAt: string;
  updatedAt: string;
  closedAt?: string;
  closedBy?: string;
}

// Closure Without CAP Types

export type ClosureReasonCategory = 
  | 'not_a_finding'
  | 'invalidated_false_positive'
  | 'not_applicable_out_of_scope'
  | 'duplicate_merged'
  | 'already_corrected'
  | 'one_time_anomaly'
  | 'compensating_controls'
  | 'risk_accepted'
  | 'vendor_responsibility_transferred'
  | 'reclassified_to_other_workflow'
  | 'administrative_closure'
  | 'other';

export const CLOSURE_REASON_CATEGORIES: Record<ClosureReasonCategory, string> = {
  not_a_finding: 'Not a finding',
  invalidated_false_positive: 'Invalidated/false positive',
  not_applicable_out_of_scope: 'Not applicable/out of scope',
  duplicate_merged: 'Duplicate/merged',
  already_corrected: 'Already corrected',
  one_time_anomaly: 'One-time anomaly',
  compensating_controls: 'Compensating controls sufficient',
  risk_accepted: 'Risk accepted',
  vendor_responsibility_transferred: 'Vendor responsibility transferred',
  reclassified_to_other_workflow: 'Reclassified to other workflow',
  administrative_closure: 'Administrative closure',
  other: 'Other',
};

export interface ClosureReason {
  id: string;
  name: string;
  category: ClosureReasonCategory;
  requiresJustification: boolean;
  requiresEvidence: boolean;
  requiresApproval: boolean;
  approverRole?: string;
  isActive: boolean;
  sortOrder: number;
  isSystemDefault: boolean;
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
  updatedBy?: string;
}

export interface ClosureReasonAuditLog {
  id: string;
  reasonId: string;
  action: 'created' | 'updated' | 'deleted' | 'activated' | 'deactivated';
  performedBy: string;
  performedAt: string;
  changes?: Record<string, { from: unknown; to: unknown }>;
}

// Closure Details (stored on audit when closed)
export interface AuditClosure {
  closureType: 'with_cap' | 'without_cap';
  closedBy: string;
  closedAt: string;
  closureSummary: string;
  
  // For closure without CAP
  reasonId?: string;
  reasonName?: string;
  justification?: string;
  closureEvidence?: CAPEvidence[];
  
  // Approval tracking
  requiresApproval?: boolean;
  approvalStatus?: 'pending' | 'approved' | 'rejected';
  approvedBy?: string;
  approvedAt?: string;
  approvalNotes?: string;
  
  // For closure with CAP
  capId?: string;
  capVerificationId?: string;
}

// CAP Status Labels
export const CAP_STATUS_LABELS: Record<CAPStatus, string> = {
  not_started: 'Not Started',
  in_progress: 'In Progress',
  blocked: 'Blocked',
  ready_for_verification: 'Ready for Verification',
  verified: 'Verified',
  closed: 'Closed',
};
