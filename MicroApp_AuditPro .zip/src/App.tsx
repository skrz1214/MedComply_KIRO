import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuditProvider } from "@/contexts/AuditContext";
import { CAPProvider } from "@/contexts/CAPContext";
import { ClosureReasonsProvider } from "@/contexts/ClosureReasonsContext";
import { AdminProvider } from "@/contexts/AdminContext";
import { AuditPackProvider } from "@/contexts/AuditPackContext";
import Dashboard from "./pages/Dashboard";
import NewAudit from "./pages/NewAudit";
import EditAudit from "./pages/EditAudit";
import AuditPhase from "./pages/AuditPhase";
import ScheduledReview from "./pages/ScheduledReview";
import ClosureCAP from "./pages/ClosureCAP";
import AuditItemDetails from "./pages/AuditItemDetails";
import AllAudits from "./pages/AllAudits";
import ScheduledAudits from "./pages/ScheduledAudits";
import Documentation from "./pages/Documentation";
import AdminSettings from "./pages/AdminSettings";
import AuditPack from "./pages/AuditPack";
import AuditPackWizard from "./pages/AuditPackWizard";
import AuditPackHistory from "./pages/AuditPackHistory";
import AuditPackShare from "./pages/AuditPackShare";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuditProvider>
        <CAPProvider>
          <ClosureReasonsProvider>
            <AdminProvider>
              <AuditPackProvider>
                <Toaster />
                <Sonner />
                <BrowserRouter>
                  <Routes>
                    <Route path="/" element={<Dashboard />} />
                    <Route path="/new-audit" element={<NewAudit />} />
                    <Route path="/edit-audit/:id" element={<EditAudit />} />
                    <Route path="/audit/:id" element={<AuditPhase />} />
                    <Route path="/audit/:id/phase/:phase" element={<AuditPhase />} />
                    <Route path="/audit/:id/details" element={<AuditItemDetails />} />
                    <Route path="/review/:id" element={<ScheduledReview />} />
                    <Route path="/closure/:id" element={<ClosureCAP />} />
                    <Route path="/audits" element={<AllAudits />} />
                    <Route path="/scheduled-audits" element={<ScheduledAudits />} />
                    <Route path="/audit-pack" element={<AuditPack />} />
                    <Route path="/audit-pack/new" element={<AuditPackWizard />} />
                    <Route path="/audit-pack/history" element={<AuditPackHistory />} />
                    <Route path="/audit-pack/share" element={<AuditPackShare />} />
                    <Route path="/docs" element={<Documentation />} />
                    <Route path="/admin" element={<AdminSettings />} />
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </BrowserRouter>
              </AuditPackProvider>
            </AdminProvider>
          </ClosureReasonsProvider>
        </CAPProvider>
      </AuditProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
