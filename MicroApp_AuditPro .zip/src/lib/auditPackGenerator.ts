import JSZip from 'jszip';
import jsPDF from 'jspdf';
import { format } from 'date-fns';
import { AuditPackScope, PreviewData, AuditPackExport, CrosswalkRow } from '@/types/auditPack';

export async function generateAuditPackZip(
  scope: AuditPackScope,
  preview: PreviewData,
  exportRecord: AuditPackExport
): Promise<void> {
  const zip = new JSZip();

  // 00_README_AUDIT_PACK.pdf - Generate as blob and add
  const readmePdf = await generateReadmePdfBlob(scope, preview, exportRecord);
  zip.file('00_README_AUDIT_PACK.pdf', readmePdf);

  // 00_EXPORT_MANIFEST.json
  const manifest = {
    exportId: exportRecord.id,
    generatedAt: exportRecord.createdAt.toISOString(),
    generatedBy: exportRecord.createdBy,
    scope: {
      dateRange: {
        start: scope.dateRange.start.toISOString(),
        end: scope.dateRange.end.toISOString(),
      },
      departments: scope.departments,
      locations: scope.locations,
      controls: scope.controls,
      policies: scope.policies,
      includeLinks: scope.includeLinks,
      includeEvidenceFiles: scope.includeEvidenceFiles,
      includePHI: scope.includePHI,
    },
    readinessScore: preview.readinessScore,
    counts: {
      policies: preview.policiesIncluded.length,
      evidenceItems: preview.evidenceSummary.total,
      trainingRecords: preview.trainingSummary.totalAssignments,
      risks: preview.risksSummary?.total || 0,
      capas: preview.capasSummary?.total || 0,
    },
    zipSha256: exportRecord.zipSha256,
  };
  zip.file('00_EXPORT_MANIFEST.json', JSON.stringify(manifest, null, 2));

  // 01_Policies folder
  const policiesFolder = zip.folder('01_Policies');
  if (policiesFolder && preview.policiesIncluded.length > 0) {
    const policySummary = preview.policiesIncluded.map(p => ({
      title: p.title,
      version: p.version,
      approvalDate: format(p.approvalDate, 'yyyy-MM-dd'),
      controlIds: p.controlIds.join(', '),
    }));
    policiesFolder.file('policy_summary.csv', generateCSV(policySummary, ['title', 'version', 'approvalDate', 'controlIds']));
  }

  // 02_Approvals_and_Versions folder
  const approvalsFolder = zip.folder('02_Approvals_and_Versions');
  if (approvalsFolder) {
    const approvalsLog = preview.policiesIncluded.map(p => ({
      policyTitle: p.title,
      version: p.version,
      approvalDate: format(p.approvalDate, 'yyyy-MM-dd'),
      status: 'Approved',
    }));
    approvalsFolder.file('approvals_log.csv', generateCSV(approvalsLog, ['policyTitle', 'version', 'approvalDate', 'status']));
  }

  // 03_Training_and_Attestations folder
  const trainingFolder = zip.folder('03_Training_and_Attestations');
  if (trainingFolder) {
    const trainingData = [
      { metric: 'Total Assignments', value: preview.trainingSummary.totalAssignments.toString() },
      { metric: 'Completed', value: preview.trainingSummary.completedCount.toString() },
      { metric: 'Overdue', value: preview.trainingSummary.overdueCount.toString() },
      { metric: 'Completion Rate', value: `${preview.trainingSummary.completionPercent}%` },
    ];
    trainingFolder.file('training_completion.csv', generateCSV(trainingData, ['metric', 'value']));
  }

  // 04_Evidence_Index folder
  const evidenceIndexFolder = zip.folder('04_Evidence_Index');
  if (evidenceIndexFolder) {
    const evidenceIndexData = preview.crosswalk.flatMap(row => {
      if (row.evidenceCount === 0) return [];
      return [{
        rule: row.rule,
        safeguard: row.safeguard || 'N/A',
        controlCite: row.controlCite,
        controlTitle: row.controlTitle,
        policies: row.policies.join('; '),
        evidenceCount: row.evidenceCount,
        currentEvidence: row.currentEvidenceCount,
        staleEvidence: row.staleEvidenceCount,
        trainingCompletion: `${row.trainingCompletion}%`,
        gaps: row.gaps.join('; '),
      }];
    });
    evidenceIndexFolder.file('evidence_index.csv', generateCSV(evidenceIndexData, [
      'rule', 'safeguard', 'controlCite', 'controlTitle', 'policies', 
      'evidenceCount', 'currentEvidence', 'staleEvidence', 'trainingCompletion', 'gaps'
    ]));
    
    // Generate evidence index PDF
    const evidenceIndexPdf = generateEvidenceIndexPdf(preview.crosswalk);
    evidenceIndexFolder.file('evidence_index.pdf', evidenceIndexPdf);
  }

  // 05_Evidence_Files folder (placeholder - in real app would include actual files)
  if (scope.includeEvidenceFiles) {
    const evidenceFilesFolder = zip.folder('05_Evidence_Files');
    if (evidenceFilesFolder) {
      evidenceFilesFolder.file('README.txt', 
        'This folder would contain the actual evidence files.\n' +
        'In this demo, file attachments are simulated.\n' +
        'PHI-containing files: ' + (scope.includePHI ? 'INCLUDED' : 'EXCLUDED')
      );
    }
  }

  // 06_Risk_Register folder
  if (preview.risksSummary && preview.risksSummary.total > 0) {
    const riskFolder = zip.folder('06_Risk_Register');
    if (riskFolder) {
      const riskData = [
        { metric: 'Total Risks', value: preview.risksSummary.total.toString() },
        { metric: 'Open Risks', value: preview.risksSummary.open.toString() },
        { metric: 'Critical/High', value: preview.risksSummary.critical.toString() },
      ];
      riskFolder.file('risk_register.csv', generateCSV(riskData, ['metric', 'value']));
    }
  }

  // 07_CAPA_and_Remediation folder
  if (preview.capasSummary && preview.capasSummary.total > 0) {
    const capaFolder = zip.folder('07_CAPA_and_Remediation');
    if (capaFolder) {
      const capaData = [
        { metric: 'Total CAPAs', value: preview.capasSummary.total.toString() },
        { metric: 'In Progress', value: preview.capasSummary.inProgress.toString() },
        { metric: 'Overdue', value: preview.capasSummary.overdue.toString() },
      ];
      capaFolder.file('capa_log.csv', generateCSV(capaData, ['metric', 'value']));
    }
  }

  // Generate and download
  const blob = await zip.generateAsync({ type: 'blob' });
  downloadBlob(blob, `${exportRecord.id}.zip`);
}

export async function generateReadmePdf(
  scope: AuditPackScope,
  preview: PreviewData,
  exportRecord: AuditPackExport
): Promise<void> {
  const blob = await generateReadmePdfBlob(scope, preview, exportRecord);
  downloadBlob(blob, `${exportRecord.id}_README.pdf`);
}

async function generateReadmePdfBlob(
  scope: AuditPackScope,
  preview: PreviewData,
  exportRecord: AuditPackExport
): Promise<Blob> {
  const pdf = new jsPDF();
  const pageWidth = pdf.internal.pageSize.getWidth();
  let y = 20;

  // Title
  pdf.setFontSize(24);
  pdf.setFont('helvetica', 'bold');
  pdf.text('HIPAA Audit Pack', pageWidth / 2, y, { align: 'center' });
  y += 15;

  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`Export ID: ${exportRecord.id}`, pageWidth / 2, y, { align: 'center' });
  y += 8;
  pdf.text(`Generated: ${format(exportRecord.createdAt, 'PPpp')}`, pageWidth / 2, y, { align: 'center' });
  y += 8;
  pdf.text(`Generated By: ${exportRecord.createdBy}`, pageWidth / 2, y, { align: 'center' });
  y += 15;

  // Scope
  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Scope', 20, y);
  y += 8;
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`Date Range: ${format(scope.dateRange.start, 'MMM d, yyyy')} - ${format(scope.dateRange.end, 'MMM d, yyyy')}`, 20, y);
  y += 6;
  if (scope.departments?.length) {
    pdf.text(`Departments: ${scope.departments.join(', ')}`, 20, y);
    y += 6;
  }
  if (scope.locations?.length) {
    pdf.text(`Locations: ${scope.locations.join(', ')}`, 20, y);
    y += 6;
  }
  y += 10;

  // Readiness Score
  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Readiness Score', 20, y);
  y += 10;
  
  pdf.setFontSize(28);
  const scoreColor = preview.readinessScore.total >= 80 ? [34, 197, 94] : 
                     preview.readinessScore.total >= 60 ? [234, 179, 8] : [239, 68, 68];
  pdf.setTextColor(scoreColor[0], scoreColor[1], scoreColor[2]);
  pdf.text(`${preview.readinessScore.total}/100`, 20, y);
  pdf.setTextColor(0, 0, 0);
  y += 15;

  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`Policy Coverage: ${preview.readinessScore.breakdown.policyCoverage}/30`, 25, y);
  y += 5;
  pdf.text(`Training Completion: ${preview.readinessScore.breakdown.trainingCompletion}/25`, 25, y);
  y += 5;
  pdf.text(`Evidence Coverage: ${preview.readinessScore.breakdown.evidenceCoverage}/30`, 25, y);
  y += 5;
  pdf.text(`Quality Score: ${preview.readinessScore.breakdown.penalties}/15`, 25, y);
  y += 10;

  // Next Actions
  if (preview.readinessScore.nextActions.length > 0) {
    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Recommended Actions:', 20, y);
    y += 6;
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    preview.readinessScore.nextActions.forEach(action => {
      pdf.text(`• ${action}`, 25, y);
      y += 5;
    });
    y += 10;
  }

  // Summary Stats
  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Summary', 20, y);
  y += 8;
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`Policies Included: ${preview.policiesIncluded.length}`, 25, y);
  y += 5;
  pdf.text(`Evidence Items: ${preview.evidenceSummary.total} (${preview.evidenceSummary.current} current, ${preview.evidenceSummary.stale} stale)`, 25, y);
  y += 5;
  pdf.text(`Training Completion: ${preview.trainingSummary.completionPercent}% (${preview.trainingSummary.overdueCount} overdue)`, 25, y);
  y += 5;
  if (preview.risksSummary) {
    pdf.text(`Risks: ${preview.risksSummary.total} total, ${preview.risksSummary.open} open`, 25, y);
    y += 5;
  }
  if (preview.capasSummary) {
    pdf.text(`CAPAs: ${preview.capasSummary.total} total, ${preview.capasSummary.inProgress} in progress`, 25, y);
    y += 5;
  }
  y += 15;

  // Check for page break
  if (y > 250) {
    pdf.addPage();
    y = 20;
  }

  // Export Metadata
  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Export Metadata', 20, y);
  y += 8;
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`Export ID: ${exportRecord.id}`, 25, y);
  y += 5;
  pdf.text(`ZIP SHA-256: ${exportRecord.zipSha256.substring(0, 32)}...`, 25, y);
  y += 5;
  pdf.text(`                  ${exportRecord.zipSha256.substring(32)}`, 25, y);

  return pdf.output('blob');
}

function generateEvidenceIndexPdf(crosswalk: CrosswalkRow[]): Blob {
  const pdf = new jsPDF('landscape');
  const pageWidth = pdf.internal.pageSize.getWidth();
  let y = 20;

  pdf.setFontSize(18);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Evidence Index', pageWidth / 2, y, { align: 'center' });
  y += 15;

  pdf.setFontSize(8);
  pdf.setFont('helvetica', 'bold');
  
  // Headers
  const cols = [15, 45, 75, 130, 165, 200, 225, 260];
  pdf.text('Rule', cols[0], y);
  pdf.text('Safeguard', cols[1], y);
  pdf.text('Control', cols[2], y);
  pdf.text('Policies', cols[3], y);
  pdf.text('Evidence', cols[4], y);
  pdf.text('Training', cols[5], y);
  pdf.text('Gaps', cols[6], y);
  y += 5;
  
  pdf.setDrawColor(200);
  pdf.line(10, y, pageWidth - 10, y);
  y += 5;

  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(7);

  crosswalk.forEach(row => {
    if (y > 190) {
      pdf.addPage();
      y = 20;
    }

    pdf.text(row.rule, cols[0], y);
    pdf.text(row.safeguard || '-', cols[1], y);
    pdf.text(`${row.controlCite}`, cols[2], y);
    pdf.text(row.policies.slice(0, 2).join(', ').substring(0, 30), cols[3], y);
    pdf.text(`${row.currentEvidenceCount}/${row.evidenceCount}`, cols[4], y);
    pdf.text(`${row.trainingCompletion}%`, cols[5], y);
    pdf.text(row.gaps.slice(0, 1).join(', ').substring(0, 30), cols[6], y);
    y += 6;
  });

  return pdf.output('blob');
}

function generateCSV(data: Record<string, any>[], columns: string[]): string {
  const header = columns.join(',');
  const rows = data.map(row => 
    columns.map(col => {
      const val = row[col];
      if (typeof val === 'string' && (val.includes(',') || val.includes('"') || val.includes('\n'))) {
        return `"${val.replace(/"/g, '""')}"`;
      }
      return val;
    }).join(',')
  );
  return [header, ...rows].join('\n');
}

function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function generateCrosswalkPdf(crosswalk: CrosswalkRow[]): void {
  const pdf = new jsPDF('landscape');
  const pageWidth = pdf.internal.pageSize.getWidth();
  let y = 20;

  pdf.setFontSize(18);
  pdf.setFont('helvetica', 'bold');
  pdf.text('HIPAA Crosswalk Report', pageWidth / 2, y, { align: 'center' });
  y += 8;
  
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`Generated: ${format(new Date(), 'PPpp')}`, pageWidth / 2, y, { align: 'center' });
  y += 15;

  pdf.setFontSize(8);
  pdf.setFont('helvetica', 'bold');
  
  // Headers
  const cols = [15, 45, 75, 130, 175, 205, 230];
  pdf.text('Rule', cols[0], y);
  pdf.text('Safeguard', cols[1], y);
  pdf.text('Control', cols[2], y);
  pdf.text('Policies', cols[3], y);
  pdf.text('Evidence', cols[4], y);
  pdf.text('Training', cols[5], y);
  pdf.text('Gaps', cols[6], y);
  y += 5;
  
  pdf.setDrawColor(200);
  pdf.line(10, y, pageWidth - 10, y);
  y += 5;

  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(7);

  crosswalk.forEach(row => {
    if (y > 190) {
      pdf.addPage();
      y = 20;
      // Re-add headers on new page
      pdf.setFontSize(8);
      pdf.setFont('helvetica', 'bold');
      pdf.text('Rule', cols[0], y);
      pdf.text('Safeguard', cols[1], y);
      pdf.text('Control', cols[2], y);
      pdf.text('Policies', cols[3], y);
      pdf.text('Evidence', cols[4], y);
      pdf.text('Training', cols[5], y);
      pdf.text('Gaps', cols[6], y);
      y += 5;
      pdf.setDrawColor(200);
      pdf.line(10, y, pageWidth - 10, y);
      y += 5;
      pdf.setFont('helvetica', 'normal');
      pdf.setFontSize(7);
    }

    pdf.text(row.rule, cols[0], y);
    pdf.text(row.safeguard || '-', cols[1], y);
    pdf.text(`${row.controlCite}`, cols[2], y);
    pdf.text(row.policies.slice(0, 2).join(', ').substring(0, 35), cols[3], y);
    pdf.text(`${row.currentEvidenceCount}/${row.evidenceCount}`, cols[4], y);
    pdf.text(`${row.trainingCompletion}%`, cols[5], y);
    pdf.text(row.gaps.slice(0, 1).join(', ').substring(0, 35), cols[6], y);
    y += 6;
  });

  // Summary at the end
  pdf.addPage();
  y = 20;
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Summary by HIPAA Rule', 20, y);
  y += 10;
  
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  
  const privacyRows = crosswalk.filter(r => r.rule === 'PRIVACY');
  const securityRows = crosswalk.filter(r => r.rule === 'SECURITY');
  const breachRows = crosswalk.filter(r => r.rule === 'BREACH');
  
  pdf.text(`Privacy Rule: ${privacyRows.length} controls`, 25, y);
  y += 6;
  pdf.text(`Security Rule: ${securityRows.length} controls`, 25, y);
  y += 6;
  pdf.text(`  - Administrative: ${securityRows.filter(r => r.safeguard === 'ADMINISTRATIVE').length}`, 30, y);
  y += 5;
  pdf.text(`  - Physical: ${securityRows.filter(r => r.safeguard === 'PHYSICAL').length}`, 30, y);
  y += 5;
  pdf.text(`  - Technical: ${securityRows.filter(r => r.safeguard === 'TECHNICAL').length}`, 30, y);
  y += 6;
  pdf.text(`Breach Notification: ${breachRows.length} controls`, 25, y);
  y += 12;
  
  const totalGaps = crosswalk.reduce((acc, r) => acc + r.gaps.length, 0);
  pdf.setFont('helvetica', 'bold');
  pdf.text(`Total Gap Items: ${totalGaps}`, 25, y);

  downloadBlob(pdf.output('blob'), 'HIPAA_Crosswalk.pdf');
}
