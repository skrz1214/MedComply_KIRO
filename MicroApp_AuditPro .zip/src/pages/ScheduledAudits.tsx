import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppLayout } from '@/components/layout/AppLayout';
import { useAudit } from '@/contexts/AuditContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { 
  Calendar, 
  Search, 
  ChevronDown, 
  ChevronRight, 
  History, 
  Clock, 
  FileText,
  Check,
  AlertCircle,
  Settings,
  Play,
  Plus
} from 'lucide-react';
import { AuditItem, PERIODICITY_LABELS, PHASE_LABELS } from '@/types/audit';
import { format } from 'date-fns';

export default function ScheduledAudits() {
  const navigate = useNavigate();
  const { audits } = useAudit();
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedAudits, setExpandedAudits] = useState<Set<string>>(new Set());

  // Filter only periodic audits
  const periodicAudits = audits.filter(audit => audit.isPeriodic);

  // Group periodic audits by their base name (removing date suffixes if any)
  const groupedAudits = periodicAudits.reduce((acc, audit) => {
    // Use the audit title as the group key
    const groupKey = audit.title;
    if (!acc[groupKey]) {
      acc[groupKey] = [];
    }
    acc[groupKey].push(audit);
    return acc;
  }, {} as Record<string, AuditItem[]>);

  // Filter based on search
  const filteredGroups = Object.entries(groupedAudits).filter(([title]) =>
    title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleExpanded = (auditId: string) => {
    setExpandedAudits(prev => {
      const next = new Set(prev);
      if (next.has(auditId)) {
        next.delete(auditId);
      } else {
        next.add(auditId);
      }
      return next;
    });
  };

  const getPhaseBadge = (phase: string) => {
    const label = PHASE_LABELS[phase as keyof typeof PHASE_LABELS] ?? phase;
    switch (phase) {
      case 'closed':
        return <Badge className="bg-status-success/10 text-status-success border-status-success/20">{label}</Badge>;
      case 'overview':
      case 'evidence_collection':
      case 'evaluation':
        return <Badge className="bg-status-info/10 text-status-info border-status-info/20">{label}</Badge>;
      case 'draft':
        return <Badge className="bg-muted text-muted-foreground border-border">{label}</Badge>;
      default:
        return <Badge variant="outline">{label}</Badge>;
    }
  };

  const getNextScheduledDate = (audit: AuditItem) => {
    if (audit.nextScheduledDate) {
      return format(new Date(audit.nextScheduledDate), 'MMM dd, yyyy');
    }
    return 'Not scheduled';
  };

  // Get past completed audits for a periodic audit (simulated by finding similar titled closed audits)
  const getPastAudits = (audit: AuditItem) => {
    return audits.filter(a =>
      a.id !== audit.id &&
      a.isPeriodic &&
      a.title === audit.title &&
      a.currentPhase === 'closed'
    );
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Scheduled Audits</h1>
            <p className="text-muted-foreground mt-1">
              Manage periodic audits and view audit history
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search scheduled audits..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Button onClick={() => navigate('/new-audit')} className="gap-2">
              <Plus className="h-4 w-4" />
              New Audit
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border-border/50">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Calendar className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{periodicAudits.length}</p>
                <p className="text-sm text-muted-foreground">Total Scheduled</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border/50">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-status-info/10 flex items-center justify-center">
                <Clock className="h-6 w-6 text-status-info" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {periodicAudits.filter(a => a.currentPhase !== 'closed').length}
                </p>
                <p className="text-sm text-muted-foreground">Active</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border/50">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-status-success/10 flex items-center justify-center">
                <Check className="h-6 w-6 text-status-success" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {periodicAudits.filter(a => a.currentPhase === 'closed').length}
                </p>
                <p className="text-sm text-muted-foreground">Completed</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Audits List */}
        <Card className="border-border/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              Periodic Audits
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredGroups.length === 0 ? (
              <div className="text-center py-12">
                <Calendar className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">No Scheduled Audits</h3>
                <p className="text-muted-foreground">
                  {searchQuery ? 'No audits match your search criteria.' : 'There are no periodic audits configured.'}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {periodicAudits.map((audit) => (
                  <Collapsible
                    key={audit.id}
                    open={expandedAudits.has(audit.id)}
                    onOpenChange={() => toggleExpanded(audit.id)}
                  >
                    <div className="border border-border/50 rounded-lg overflow-hidden">
                      <CollapsibleTrigger asChild>
                        <button className="w-full p-4 flex items-center justify-between hover:bg-muted/30 transition-colors text-left">
                          <div className="flex items-center gap-4">
                            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                              <FileText className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <h3 className="font-medium text-foreground">{audit.title}</h3>
                              <div className="flex items-center gap-3 mt-1">
                                <span className="text-xs text-muted-foreground">
                                  {audit.periodicity ? PERIODICITY_LABELS[audit.periodicity] : 'One-time'}
                                </span>
                                <span className="text-xs text-muted-foreground">•</span>
                                <span className="text-xs text-muted-foreground">
                                  {audit.department}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            {getPhaseBadge(audit.currentPhase)}
                            <div className="text-right">
                              <p className="text-sm text-muted-foreground">Next Scheduled</p>
                              <p className="text-sm font-medium text-foreground">
                                {getNextScheduledDate(audit)}
                              </p>
                            </div>
                            {expandedAudits.has(audit.id) ? (
                              <ChevronDown className="h-5 w-5 text-muted-foreground" />
                            ) : (
                              <ChevronRight className="h-5 w-5 text-muted-foreground" />
                            )}
                          </div>
                        </button>
                      </CollapsibleTrigger>
                      
                      <CollapsibleContent>
                        <div className="border-t border-border/50 p-4 bg-muted/20 space-y-4">
                          {/* Audit Details */}
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div>
                              <p className="text-xs text-muted-foreground">Current Status</p>
                              <p className="text-sm font-medium text-foreground">
                                {PHASE_LABELS[audit.currentPhase]}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Audit Type</p>
                              <p className="text-sm font-medium text-foreground capitalize">
                                {audit.type}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Created</p>
                              <p className="text-sm font-medium text-foreground">
                                {format(new Date(audit.createdAt), 'MMM dd, yyyy')}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Due Date</p>
                              <p className="text-sm font-medium text-foreground">
                                {audit.dueDate ? format(new Date(audit.dueDate), 'MMM dd, yyyy') : 'No due date'}
                              </p>
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              onClick={() => navigate(`/edit-audit/${audit.id}`)}
                            >
                              <Settings className="h-4 w-4 mr-2" />
                              Manage Audit
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => navigate(`/audit/${audit.id}/phase/${audit.currentPhase}?source=scheduled`)}
                            >
                              <Play className="h-4 w-4 mr-2" />
                              View Current Status
                            </Button>
                          </div>

                          {/* Audit History */}
                          <div className="border-t border-border/30 pt-4">
                            <div className="flex items-center gap-2 mb-3">
                              <History className="h-4 w-4 text-primary" />
                              <h4 className="font-medium text-foreground">Audit History & Trail</h4>
                            </div>
                            
                            {audit.history && audit.history.length > 0 ? (
                              <div className="rounded-lg border border-border/50 overflow-hidden">
                                <Table>
                                  <TableHeader>
                                    <TableRow className="bg-muted/30">
                                      <TableHead className="text-xs">Date</TableHead>
                                      <TableHead className="text-xs">Action</TableHead>
                                      <TableHead className="text-xs">Status</TableHead>
                                      <TableHead className="text-xs">Performed By</TableHead>
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody>
                                    {audit.history.slice().reverse().map((entry, index) => (
                                      <TableRow key={index} className="text-sm">
                                        <TableCell className="text-xs text-muted-foreground">
                                          {format(new Date(entry.performedAt), 'MMM dd, yyyy HH:mm')}
                                        </TableCell>
                                        <TableCell className="text-xs">{entry.action}</TableCell>
                                        <TableCell className="text-xs">
                                          {entry.phase ? PHASE_LABELS[entry.phase] : '-'}
                                        </TableCell>
                                        <TableCell className="text-xs">{entry.performedBy}</TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </Table>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/30 text-muted-foreground">
                                <AlertCircle className="h-4 w-4" />
                                <span className="text-sm">No history entries yet</span>
                              </div>
                            )}

                            {/* Past Completed Audits */}
                            {getPastAudits(audit).length > 0 && (
                              <div className="mt-4">
                                <h5 className="text-sm font-medium text-foreground mb-2">
                                  Previous Audit Cycles
                                </h5>
                                <div className="space-y-2">
                                  {getPastAudits(audit).map((pastAudit) => (
                                    <button
                                      key={pastAudit.id}
                                      onClick={() => navigate(`/audit/${pastAudit.id}/phase/overview?source=scheduled`)}
                                      className="w-full flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors text-left"
                                    >
                                      <div className="flex items-center gap-3">
                                        <div className="h-8 w-8 rounded-full bg-status-success/10 flex items-center justify-center">
                                          <Check className="h-4 w-4 text-status-success" />
                                        </div>
                                        <div>
                                          <p className="text-sm font-medium text-foreground">
                                            Completed {format(new Date(pastAudit.createdAt), 'MMM yyyy')}
                                          </p>
                                          <p className="text-xs text-muted-foreground">
                                            {pastAudit.actions.filter(a => a.completed).length}/{pastAudit.actions.length} actions
                                          </p>
                                        </div>
                                      </div>
                                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                                    </button>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </CollapsibleContent>
                    </div>
                  </Collapsible>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
