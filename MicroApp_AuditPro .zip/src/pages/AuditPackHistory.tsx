import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { Package, History, Plus, Download, FileText, Eye, RefreshCw, Link, Trash2 } from 'lucide-react';
import { AppLayout } from '@/components/layout/AppLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useAuditPack } from '@/contexts/AuditPackContext';
import { useAudit } from '@/contexts/AuditContext';
import { useToast } from '@/hooks/use-toast';
import { AuditPackExport } from '@/types/auditPack';
import { generateAuditPackZip, generateReadmePdf } from '@/lib/auditPackGenerator';
import { useState } from 'react';

export default function AuditPackHistory() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { currentUser } = useAudit();
  const { exports, shareLinks, createShareLink, revokeShareLink, generatePreview } = useAuditPack();
  const [selectedExport, setSelectedExport] = useState<AuditPackExport | null>(null);

  const canCreateShareLink = currentUser.role === 'admin' || currentUser.role === 'compliance_head';

  const handleCreateShareLink = (exportItem: AuditPackExport) => {
    const link = createShareLink(exportItem.id, currentUser.name);
    const shareUrl = `${window.location.origin}/audit-pack/share?token=${link.token}`;
    navigator.clipboard.writeText(shareUrl);
    toast({
      title: 'Share Link Created',
      description: 'Link copied to clipboard. Valid for 7 days.',
    });
  };

  const handleDownloadZip = async (exportItem: AuditPackExport) => {
    const preview = generatePreview(exportItem.scope);
    await generateAuditPackZip(exportItem.scope, preview, exportItem);
    toast({ title: 'ZIP Downloaded', description: `${exportItem.id}.zip` });
  };

  const handleDownloadReadme = async (exportItem: AuditPackExport) => {
    const preview = generatePreview(exportItem.scope);
    await generateReadmePdf(exportItem.scope, preview, exportItem);
    toast({ title: 'README Downloaded', description: `${exportItem.id}_README.pdf` });
  };

  const getExportShareLinks = (exportId: string) => 
    shareLinks.filter(l => l.exportId === exportId && !l.revoked);

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Export History</h1>
            <p className="text-muted-foreground mt-1">View and manage your audit pack exports</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => navigate('/audit-pack')}>
              Back to Audit Pack
            </Button>
            <Button onClick={() => navigate('/audit-pack/new')}>
              <Plus className="mr-2 h-4 w-4" />
              New Export
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <History className="h-5 w-5" />
              Export Records
            </CardTitle>
            <CardDescription>
              All audit pack exports with integrity hashes and download options
            </CardDescription>
          </CardHeader>
          <CardContent>
            {exports.length === 0 ? (
              <div className="text-center py-12">
                <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Exports Yet</h3>
                <p className="text-muted-foreground mb-4">
                  Create your first audit pack export to see it here
                </p>
                <Button onClick={() => navigate('/audit-pack/new')}>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Audit Pack
                </Button>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Export ID</TableHead>
                    <TableHead>Created At</TableHead>
                    <TableHead>Created By</TableHead>
                    <TableHead>Scope</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {exports.map((exp) => (
                    <TableRow key={exp.id}>
                      <TableCell className="font-mono text-sm">{exp.id}</TableCell>
                      <TableCell>{format(exp.createdAt, 'MMM d, yyyy HH:mm')}</TableCell>
                      <TableCell>{exp.createdBy}</TableCell>
                      <TableCell>
                        <span className="text-sm">{exp.scopeLabel}</span>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={exp.readinessScore >= 80 ? 'default' : exp.readinessScore >= 60 ? 'secondary' : 'destructive'}
                          className={exp.readinessScore >= 80 ? 'bg-green-600' : ''}
                        >
                          {exp.readinessScore}/100
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={exp.status === 'completed' ? 'default' : exp.status === 'generating' ? 'secondary' : 'destructive'}>
                          {exp.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            title="Download ZIP"
                            onClick={() => handleDownloadZip(exp)}
                          >
                            <Download className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            title="Download README"
                            onClick={() => handleDownloadReadme(exp)}
                          >
                            <FileText className="h-4 w-4" />
                          </Button>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                title="View Manifest"
                                onClick={() => setSelectedExport(exp)}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-2xl">
                              <DialogHeader>
                                <DialogTitle>Export Manifest</DialogTitle>
                                <DialogDescription>Details for {exp.id}</DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4 text-sm">
                                  <div>
                                    <span className="text-muted-foreground">Export ID:</span>
                                    <p className="font-mono">{exp.id}</p>
                                  </div>
                                  <div>
                                    <span className="text-muted-foreground">Created:</span>
                                    <p>{format(exp.createdAt, 'PPpp')}</p>
                                  </div>
                                  <div>
                                    <span className="text-muted-foreground">Created By:</span>
                                    <p>{exp.createdBy}</p>
                                  </div>
                                  <div>
                                    <span className="text-muted-foreground">Readiness Score:</span>
                                    <p>{exp.readinessScore}/100</p>
                                  </div>
                                </div>
                                <div>
                                  <span className="text-muted-foreground text-sm">Date Range:</span>
                                  <p>{exp.scopeLabel}</p>
                                </div>
                                <div>
                                  <span className="text-muted-foreground text-sm">ZIP SHA-256:</span>
                                  <p className="font-mono text-xs break-all bg-muted p-2 rounded mt-1">
                                    {exp.zipSha256}
                                  </p>
                                </div>
                                <div>
                                  <span className="text-muted-foreground text-sm">Scope Options:</span>
                                  <div className="flex gap-2 mt-1">
                                    {exp.scope.includeLinks && <Badge variant="outline">Links</Badge>}
                                    {exp.scope.includeEvidenceFiles && <Badge variant="outline">Files</Badge>}
                                    {exp.scope.includePHI && <Badge variant="destructive">PHI Included</Badge>}
                                  </div>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                          {canCreateShareLink && (
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              title="Create Share Link"
                              onClick={() => handleCreateShareLink(exp)}
                            >
                              <Link className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Share Links Section */}
        {canCreateShareLink && shareLinks.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Link className="h-5 w-5" />
                Active Share Links
              </CardTitle>
              <CardDescription>
                Time-limited, view-only links for auditors
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Export ID</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>Created By</TableHead>
                    <TableHead>Expires</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {shareLinks.filter(l => !l.revoked).map((link) => {
                    const isExpired = link.expiresAt < new Date();
                    return (
                      <TableRow key={link.id}>
                        <TableCell className="font-mono text-sm">{link.exportId}</TableCell>
                        <TableCell>{format(link.createdAt, 'MMM d, yyyy HH:mm')}</TableCell>
                        <TableCell>{link.createdBy}</TableCell>
                        <TableCell>{format(link.expiresAt, 'MMM d, yyyy HH:mm')}</TableCell>
                        <TableCell>
                          <Badge variant={isExpired ? 'destructive' : 'default'}>
                            {isExpired ? 'Expired' : 'Active'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              title="Copy Link"
                              onClick={() => {
                                navigator.clipboard.writeText(
                                  `${window.location.origin}/audit-pack/share?token=${link.token}`
                                );
                                toast({ title: 'Link Copied' });
                              }}
                            >
                              <Link className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              title="Revoke Link"
                              onClick={() => {
                                revokeShareLink(link.id);
                                toast({ title: 'Link Revoked' });
                              }}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </AppLayout>
  );
}
