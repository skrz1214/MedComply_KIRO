import { useState } from 'react';
import { AppLayout } from '@/components/layout/AppLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Settings, Building2, ListChecks, Users, Paperclip, Calendar, Bell, Link, History, Target, Package } from 'lucide-react';
import { AuditPackTab } from '@/components/admin/AuditPackTab';
import { GeneralTab } from '@/components/admin/GeneralTab';
import { DepartmentsTab } from '@/components/admin/DepartmentsTab';
import { StatusPhaseTab } from '@/components/admin/StatusPhaseTab';
import { DefaultAssigneesTab } from '@/components/admin/DefaultAssigneesTab';
import { EvidencePolicyTab } from '@/components/admin/EvidencePolicyTab';
import { PeriodicRulesTab } from '@/components/admin/PeriodicRulesTab';
import { NotificationsTab } from '@/components/admin/NotificationsTab';
import { IntegrationsTab } from '@/components/admin/IntegrationsTab';
import { MetricsTargetsTab } from '@/components/admin/MetricsTargetsTab';
import { ChangeLogTab } from '@/components/admin/ChangeLogTab';

const tabs = [
  { id: 'general', label: 'General', icon: Settings },
  { id: 'departments', label: 'Departments', icon: Building2 },
  { id: 'status-phase', label: 'Status Rules', icon: ListChecks },
  { id: 'phase-assignee', label: 'Default Assignees', icon: Users },
  { id: 'evidence-policy', label: 'Evidence & Attachments', icon: Paperclip },
  { id: 'periodic-rules', label: 'Periodic Audit Rules', icon: Calendar },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'integrations', label: 'Integrations', icon: Link },
  { id: 'metrics-targets', label: 'Metrics Targets', icon: Target },
  { id: 'audit-pack', label: 'Audit Pack', icon: Package },
  { id: 'change-log', label: 'Audit Settings Change Log', icon: History },
];

export default function AdminSettings() {
  const [activeTab, setActiveTab] = useState('general');

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
            <Settings className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Admin Settings</h1>
            <p className="text-muted-foreground">Configure AuditPro system settings and policies</p>
          </div>
          <Badge variant="outline" className="ml-auto">Admin Only</Badge>
        </div>

        {/* Tabs Navigation */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <Card className="border-border/50">
            <CardContent className="p-2">
              <TabsList className="flex flex-wrap h-auto gap-1 bg-transparent p-0">
                {tabs.map((tab) => (
                  <TabsTrigger
                    key={tab.id}
                    value={tab.id}
                    className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground flex items-center gap-2 px-3 py-2 text-sm"
                  >
                    <tab.icon className="h-4 w-4" />
                    <span className="hidden lg:inline">{tab.label}</span>
                  </TabsTrigger>
                ))}
              </TabsList>
            </CardContent>
          </Card>

          {/* Tab Contents */}
          <TabsContent value="general" className="mt-0">
            <GeneralTab />
          </TabsContent>

          <TabsContent value="departments" className="mt-0">
            <DepartmentsTab />
          </TabsContent>

          <TabsContent value="status-phase" className="mt-0">
            <StatusPhaseTab />
          </TabsContent>

          <TabsContent value="phase-assignee" className="mt-0">
            <DefaultAssigneesTab />
          </TabsContent>


          <TabsContent value="evidence-policy" className="mt-0">
            <EvidencePolicyTab />
          </TabsContent>

          <TabsContent value="periodic-rules" className="mt-0">
            <PeriodicRulesTab />
          </TabsContent>

          <TabsContent value="notifications" className="mt-0">
            <NotificationsTab />
          </TabsContent>

          <TabsContent value="integrations" className="mt-0">
            <IntegrationsTab />
          </TabsContent>

          <TabsContent value="metrics-targets" className="mt-0">
            <MetricsTargetsTab />
          </TabsContent>

          <TabsContent value="audit-pack" className="mt-0">
            <AuditPackTab />
          </TabsContent>

          <TabsContent value="change-log" className="mt-0">
            <ChangeLogTab />
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
