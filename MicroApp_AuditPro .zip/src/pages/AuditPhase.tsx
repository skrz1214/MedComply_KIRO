import { useState, useRef } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useAudit } from '@/contexts/AuditContext';
import { useCAP } from '@/contexts/CAPContext';
import { usePermissions } from '@/hooks/usePermissions';
import { AppLayout } from '@/components/layout/AppLayout';
import { StatusBadge } from '@/components/audit/StatusBadge';
import { PriorityBadge } from '@/components/audit/PriorityBadge';
import { LinkedItemsSection } from '@/components/audit/LinkedItemsSection';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AuditPhase as AuditPhaseType, PHASE_LABELS, PERIODICITY_LABELS } from '@/types/audit';
import { CloseWithoutCAPTab } from '@/components/closure/CloseWithoutCAPTab';
import { CAPClosureTab } from '@/components/closure/CAPClosureTab';
import { AuditHistorySection } from '@/components/audit/AuditHistorySection';
import { 
  ArrowLeft, 
  ArrowRight,
  Calendar, 
  User, 
  Building2, 
  Upload, 
  FileText, 
  Check,
  Clock,
  AlertTriangle,
  Send,
  ClipboardCheck,
  Search,
  FileCheck,
  Shield,
  Repeat,
  UserPlus,
  History as HistoryIcon,
  Eye,
  ClipboardList,
  FileWarning,
  Plus,
  X,
  Link2,
  Lock
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';

const phaseOrder: AuditPhaseType[] = ['draft', 'pre_audit', 'pre_audit_review', 'overview', 'evidence_collection', 'evaluation', 'internal_review', 'remediation_required', 'closure_cap', 'cap_active', 'pending_verification', 'closed'];

const phaseIcons: Record<AuditPhaseType, React.ElementType> = {
  draft: ClipboardCheck,
  pre_audit: ClipboardCheck,
  pre_audit_review: Eye,
  overview: ClipboardCheck,
  evidence_collection: Search,
  evaluation: FileCheck,
  internal_review: Send,
  remediation_required: AlertTriangle,
  closure_cap: Shield,
  cap_active: FileWarning,
  pending_verification: Eye,
  closed: Check,
};

export default function AuditPhase() {
  const { id, phase } = useParams<{ id: string; phase: string }>();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { audits, updateAudit, submitForReview, submitPreAuditForReview, approvePreAudit, rejectPreAudit, currentUser, users, addHistoryEntry, addPhaseAttachment, updatePhaseAssignee, addActionItem, addLinkedItem, removeLinkedItem } = useAudit();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const source = searchParams.get('source') || 'personal';
  const isReviewMode = searchParams.get('review') === 'true';
  const audit = audits.find(a => a.id === id);
  const permissions = usePermissions(audit);
  const [notes, setNotes] = useState('');
  const [newActionDescription, setNewActionDescription] = useState('');
  const [rejectNotes, setRejectNotes] = useState('');
  const [selectedCurrentPhaseAssignee, setSelectedCurrentPhaseAssignee] = useState<string | null>(null);
  const [selectedNextPhaseAssignee, setSelectedNextPhaseAssignee] = useState<string | null>(null);
  const currentPhase = (phase as AuditPhaseType) || audit?.currentPhase || 'pre_audit';

  const handleBack = () => {
    navigate(`/?view=${source}`);
  };

  if (!audit) {
    return (
      <AppLayout>
        <div className="p-8 flex items-center justify-center h-full">
          <div className="text-center">
            <h2 className="text-xl font-semibold mb-2">Audit Not Found</h2>
            <p className="text-muted-foreground mb-4">The audit item you're looking for doesn't exist.</p>
            <Button onClick={handleBack}>Return to Dashboard</Button>
          </div>
        </div>
      </AppLayout>
    );
  }

  const currentPhaseIndex = phaseOrder.indexOf(currentPhase);
  const completedActions = audit.actions.filter(a => a.completed).length;
  const totalActions = audit.actions.length;
  const progress = totalActions > 0 ? (completedActions / totalActions) * 100 : 0;
  const allActionsComplete = completedActions === totalActions && totalActions > 0;
  const PhaseIcon = phaseIcons[currentPhase];
  
  // Get current phase assignee
  const phaseAssignee = audit.phaseAssignees?.[currentPhase] || audit.assignedTo;
  const phaseAssigneeUser = users.find(u => u.id === phaseAssignee);
  
  // Track if user has changed the current phase assignee
  const displayedCurrentPhaseAssignee = selectedCurrentPhaseAssignee || phaseAssignee;
  const displayedCurrentPhaseAssigneeUser = users.find(u => u.id === displayedCurrentPhaseAssignee);
  const hasChangedCurrentPhaseAssignee = selectedCurrentPhaseAssignee && selectedCurrentPhaseAssignee !== phaseAssignee;
  
  // Check if current phase has a different assignee than current user (for handoff on same phase)
  const hasNewAssigneeForCurrentPhase = Boolean(phaseAssignee && phaseAssignee !== currentUser.id);
  
  // Check if next phase has a different assignee
  const nextPhase = currentPhaseIndex < phaseOrder.length - 1 ? phaseOrder[currentPhaseIndex + 1] : null;
  const nextPhaseAssignee = nextPhase ? (audit.phaseAssignees?.[nextPhase] || audit.assignedTo) : null;
  const displayedNextPhaseAssignee = selectedNextPhaseAssignee || nextPhaseAssignee;
  const displayedNextPhaseAssigneeUser = displayedNextPhaseAssignee ? users.find(u => u.id === displayedNextPhaseAssignee) : null;
  const nextPhaseAssigneeUser = nextPhaseAssignee ? users.find(u => u.id === nextPhaseAssignee) : null;
  const hasNewAssigneeForNextPhase = Boolean(nextPhase && nextPhaseAssignee && phaseAssignee && nextPhaseAssignee !== phaseAssignee);

  const handleToggleAction = (actionId: string) => {
    const updatedActions = audit.actions.map(action => {
      if (action.id === actionId) {
        return {
          ...action,
          completed: !action.completed,
          completedAt: !action.completed ? new Date().toISOString() : undefined,
          completedBy: !action.completed ? currentUser.name : undefined,
        };
      }
      return action;
    });

    updateAudit(audit.id, { 
      actions: updatedActions,
      status: 'overview',
    });

    addHistoryEntry(audit.id, {
      action: `Action item updated`,
      phase: currentPhase,
      performedBy: currentUser.name,
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const newEvidence = {
      id: Date.now().toString(),
      name: file.name,
      type: file.type,
      uploadedAt: new Date().toISOString().split('T')[0],
      uploadedBy: currentUser.name,
      url: '#',
    };

    addPhaseAttachment(audit.id, currentPhase, newEvidence);

    toast.success('Attachment uploaded', {
      description: `${file.name} has been attached to ${PHASE_LABELS[currentPhase]}.`,
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmitToCurrentPhaseAssignee = () => {
    if (!phaseAssigneeUser) return;
    
    addHistoryEntry(audit.id, {
      action: `Handed off ${PHASE_LABELS[currentPhase]} to ${phaseAssigneeUser.name}`,
      phase: currentPhase,
      performedBy: currentUser.name,
    });
    toast.success('Submitted to Assignee', {
      description: `${phaseAssigneeUser.name} will now handle ${PHASE_LABELS[currentPhase]}.`,
    });
    handleBack();
  };

  const handleSubmitForReview = () => {
    submitForReview(audit.id);
    addHistoryEntry(audit.id, {
      action: 'Submitted for internal review',
      phase: currentPhase,
      performedBy: currentUser.name,
    });
    toast.success('Submitted for Review', {
      description: 'The audit has been sent to the internal reviewer.',
    });
    handleBack();
  };

  const handleAssigneeChange = (userId: string) => {
    updatePhaseAssignee(audit.id, currentPhase, userId);
    const user = users.find(u => u.id === userId);
    toast.success('Assignee Updated', {
      description: `${user?.name} has been assigned to ${PHASE_LABELS[currentPhase]}.`,
    });
  };

  const handleNextPhaseAssigneeChange = (userId: string) => {
    if (!nextPhase) return;
    updatePhaseAssignee(audit.id, nextPhase, userId);
    const user = users.find(u => u.id === userId);
    toast.success('Next Status Assignee Updated', {
      description: `${user?.name} will handle ${PHASE_LABELS[nextPhase]}.`,
    });
  };

  const isOverdue = new Date(audit.dueDate) < new Date() && audit.status !== 'closed';
  const phaseAttachments = audit.phaseAttachments?.[currentPhase] || [];
  
  // Get past completed audits with the same title (for periodic audits)
  const pastAudits = audit.isPeriodic 
    ? audits.filter(a => 
        a.id !== audit.id && 
        a.title === audit.title && 
        a.status === 'closed'
      )
    : [];

  return (
    <AppLayout>
      <div className="p-6 lg:p-8 max-w-7xl mx-auto">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={handleBack}
          className="mb-6 gap-2 text-muted-foreground hover:text-foreground -ml-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to {source === 'department' ? 'Department' : 'My'} Dashboard
        </Button>

        {/* Header Card */}
        <Card className="mb-6 border-border/50 overflow-hidden">
          <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent p-6">
            <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2 mb-3">
                  <span className={cn(
                    'text-xs font-semibold uppercase tracking-wider px-2 py-1 rounded',
                    audit.type === 'external' ? 'bg-status-pending/10 text-status-pending' : 'bg-primary/10 text-primary'
                  )}>
                    {audit.type} Audit
                  </span>
                  <PriorityBadge priority={audit.priority} />
                  <StatusBadge status={audit.status} closureType={audit.closureType} />
                  {audit.isPeriodic && (
                    <span className="inline-flex items-center gap-1 px-2 py-1 rounded bg-secondary text-secondary-foreground text-xs font-medium">
                      <Repeat className="h-3 w-3" />
                      {PERIODICITY_LABELS[audit.periodicity!]}
                    </span>
                  )}
                </div>
                <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-2">{audit.title}</h1>
                <p className="text-muted-foreground max-w-2xl">{audit.description}</p>
              </div>
            </div>

            {/* Meta Info Row */}
            <div className="flex flex-wrap items-center gap-4 lg:gap-6 mt-6 pt-4 border-t border-border/30">
              <div className="flex items-center gap-2 text-sm">
                <User className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">Assigned:</span>
                <span className="font-medium text-foreground">{audit.assignedToName}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Building2 className="h-4 w-4 text-muted-foreground" />
                <span className="text-foreground">{audit.department}</span>
              </div>
              <div className={cn(
                'flex items-center gap-2 text-sm',
                isOverdue ? 'text-status-error' : 'text-muted-foreground'
              )}>
                <Calendar className="h-4 w-4" />
                <span>{isOverdue ? 'Overdue: ' : 'Due: '}{audit.dueDate}</span>
              </div>
            </div>
          </div>
        </Card>

        {/* Read-only Banner for Staff */}
        {permissions.isReadOnly && (
          <div className="mb-6 p-4 rounded-lg bg-amber-50 border border-amber-200 flex items-center gap-3">
            <Lock className="h-5 w-5 text-amber-600 shrink-0" />
            <div>
              <p className="font-medium text-amber-800">Read-only Access</p>
              <p className="text-sm text-amber-700">You can view this audit but cannot make changes. Contact your Department Head if you need to perform actions.</p>
            </div>
          </div>
        )}

        {/* Phase Stepper */}
        <Card className="mb-6 border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center overflow-x-auto">
              {phaseOrder.map((p, index) => {
                const Icon = phaseIcons[p];
                const isActive = p === currentPhase;
                const isCompleted = index < currentPhaseIndex;
                const isLast = index === phaseOrder.length - 1;
                
                return (
                  <div key={p} className="flex items-center flex-1 min-w-0">
                    <div
                      className={cn(
                        'flex items-center gap-1.5 px-2 py-1.5 rounded-lg transition-all shrink-0',
                        isActive && 'bg-primary text-primary-foreground',
                        isCompleted && !isActive && 'text-status-success',
                        !isActive && !isCompleted && 'text-muted-foreground'
                      )}
                    >
                      <div className={cn(
                        'h-6 w-6 rounded-full flex items-center justify-center text-xs font-medium shrink-0',
                        isActive && 'bg-primary-foreground/20',
                        isCompleted && !isActive && 'bg-status-success/10',
                        !isActive && !isCompleted && 'bg-muted'
                      )}>
                        {isCompleted && !isActive ? <Check className="h-3 w-3" /> : <Icon className="h-3 w-3" />}
                      </div>
                      <span className="hidden lg:inline text-xs font-medium whitespace-nowrap">{PHASE_LABELS[p]}</span>
                    </div>
                    {!isLast && (
                      <div className={cn(
                        'flex-1 h-0.5 mx-1 min-w-[8px]',
                        index < currentPhaseIndex ? 'bg-status-success' : 'bg-border'
                      )} />
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Rejection Notice */}
        {audit.reviewNotes && (audit.currentPhase === 'overview' || audit.currentPhase === 'pre_audit') && (
          <Card className="mb-6 border-status-error/30 bg-status-error/5">
            <CardContent className="p-4 flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-status-error shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-status-error mb-1">Review Feedback</h3>
                <p className="text-sm text-foreground">{audit.reviewNotes}</p>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main Content - Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Phase Content Card */}
            <Card className="border-border/50">
              <CardHeader className="border-b border-border/30">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
                      <PhaseIcon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{PHASE_LABELS[currentPhase]}</CardTitle>
                      <CardDescription>
                        {currentPhase === 'pre_audit' && 'Prepare and gather information before starting audit'}
                        {currentPhase === 'overview' && 'Review audit scope and objectives'}
                        {currentPhase === 'evidence_collection' && 'Gather and document evidence'}
                        {currentPhase === 'evaluation' && 'Evaluate findings and complete actions'}
                        {currentPhase === 'internal_review' && 'Submit for internal review and approval'}
                        {currentPhase === 'closure_cap' && 'Finalize audit and determine CAP needs'}
                      </CardDescription>
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Step {currentPhaseIndex + 1} of {phaseOrder.length}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                {/* Pre-Audit Phase */}
                {currentPhase === 'pre_audit' && (
                  <div className="space-y-6">
                    {/* Pre-Audit Details */}
                    <div className="p-4 rounded-lg bg-muted/50">
                      <h4 className="font-medium mb-3 text-foreground">Pre-Audit Information</h4>
                      <div className="grid gap-3 text-sm">
                        <div className="flex items-start gap-3">
                          <span className="text-muted-foreground w-24 shrink-0">Title:</span>
                          <span className="text-foreground font-medium">{audit.title}</span>
                        </div>
                        <div className="flex items-start gap-3">
                          <span className="text-muted-foreground w-24 shrink-0">Description:</span>
                          <span className="text-foreground">{audit.description}</span>
                        </div>
                        <div className="flex items-start gap-3">
                          <span className="text-muted-foreground w-24 shrink-0">Type:</span>
                          <span className="text-foreground capitalize">{audit.type} Audit</span>
                        </div>
                        <div className="flex items-start gap-3">
                          <span className="text-muted-foreground w-24 shrink-0">Created By:</span>
                          <span className="text-foreground">{users.find(u => u.id === audit.createdBy)?.name || 'Unknown'}</span>
                        </div>
                      </div>
                    </div>

                    {/* Editable Action Items / Checklist */}
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium text-foreground">Pre-Audit Checklist</h4>
                      </div>
                      {audit.actions.length > 0 ? (
                        <div className="space-y-2">
                          {audit.actions.map((action) => (
                            <div 
                              key={action.id}
                              className={cn(
                                'flex items-start gap-3 p-3 rounded-lg transition-colors group',
                                action.completed ? 'bg-status-success/5' : 'bg-muted/30'
                              )}
                            >
                              <Checkbox
                                checked={action.completed}
                                onCheckedChange={() => handleToggleAction(action.id)}
                              />
                              <div className="flex-1 min-w-0">
                                <p className={cn(
                                  'text-sm',
                                  action.completed && 'line-through text-muted-foreground'
                                )}>{action.description}</p>
                                {action.completed && action.completedBy && (
                                  <p className="text-xs text-muted-foreground mt-1">
                                    Completed by {action.completedBy}
                                  </p>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground p-3 bg-muted/30 rounded-lg">
                          No checklist items defined.
                        </p>
                      )}
                      
                      {/* Add New Action Item */}
                      <div className="flex gap-2">
                        <Input
                          placeholder="Add new checklist item..."
                          value={newActionDescription}
                          onChange={(e) => setNewActionDescription(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && newActionDescription.trim()) {
                              addActionItem(audit.id, newActionDescription.trim());
                              setNewActionDescription('');
                              toast.success('Checklist item added');
                            }
                          }}
                        />
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => {
                            if (newActionDescription.trim()) {
                              addActionItem(audit.id, newActionDescription.trim());
                              setNewActionDescription('');
                              toast.success('Checklist item added');
                            }
                          }}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    {/* Risks & Dependencies Section */}
                    <div className="space-y-3">
                      <h4 className="font-medium text-foreground">Risks & Dependencies</h4>
                      <Textarea
                        placeholder="Document any risks, dependencies, or potential blockers for this audit..."
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        rows={4}
                        className="resize-none"
                      />
                      <p className="text-xs text-muted-foreground">
                        Note any equipment needs, staff availability, regulatory requirements, or other factors that could impact the audit.
                      </p>
                    </div>
                  </div>
                )}

                {/* Overview Phase */}
                {currentPhase === 'overview' && (
                  <div className="space-y-4">
                    <div className="p-4 rounded-lg bg-muted/50">
                      <h4 className="font-medium mb-2 text-sm text-muted-foreground uppercase tracking-wider">Audit Scope</h4>
                      <p className="text-foreground">{audit.description}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 rounded-lg bg-muted/50">
                        <p className="text-sm text-muted-foreground mb-1">Audit Type</p>
                        <p className="font-semibold capitalize text-foreground">{audit.type}</p>
                      </div>
                      <div className="p-4 rounded-lg bg-muted/50">
                        <p className="text-sm text-muted-foreground mb-1">Priority</p>
                        <p className="font-semibold capitalize text-foreground">{audit.priority}</p>
                      </div>
                    </div>
                    
                    {/* Audit History for periodic audits */}
                    <AuditHistorySection audit={audit} pastAudits={pastAudits} source={source} />
                  </div>
                )}

                {currentPhase === 'internal_review' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 rounded-lg bg-status-success/5 border border-status-success/20">
                        <p className="text-sm text-muted-foreground mb-1">Actions Completed</p>
                        <p className="text-3xl font-bold text-status-success">{completedActions}/{totalActions}</p>
                      </div>
                      <div className="p-4 rounded-lg bg-muted/50">
                        <p className="text-sm text-muted-foreground mb-1">Total Evidence</p>
                        <p className="text-3xl font-bold text-foreground">
                          {Object.values(audit.phaseAttachments || {}).flat().length}
                        </p>
                      </div>
                    </div>
                    <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                      <div className="flex items-start gap-3">
                        <Eye className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                        <div>
                          <p className="font-medium text-primary">Ready for Internal Review</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            This audit is awaiting internal review. The reviewer will evaluate all evidence and actions before approving or returning for revisions.
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    {/* Audit History for periodic audits */}
                    <AuditHistorySection audit={audit} pastAudits={pastAudits} source={source} />
                  </div>
                )}

                {currentPhase === 'closure_cap' && (
                  <Tabs defaultValue="overview" className="w-full">
                    <TabsList className="grid w-full grid-cols-3 mb-6">
                      <TabsTrigger value="overview" className="gap-2">
                        <ClipboardList className="h-4 w-4" />
                        Overview
                      </TabsTrigger>
                      <TabsTrigger value="close-without-cap" className="gap-2">
                        <FileWarning className="h-4 w-4" />
                        Closure without CAP
                      </TabsTrigger>
                      <TabsTrigger value="cap" className="gap-2">
                        <Shield className="h-4 w-4" />
                        CAP
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview" className="space-y-6">
                      {/* Summary Stats */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 rounded-lg bg-status-success/5 border border-status-success/20">
                          <p className="text-sm text-muted-foreground mb-1">Actions Completed</p>
                          <p className="text-3xl font-bold text-status-success">{completedActions}/{totalActions}</p>
                        </div>
                        <div className="p-4 rounded-lg bg-muted/50">
                          <p className="text-sm text-muted-foreground mb-1">Total Evidence</p>
                          <p className="text-3xl font-bold text-foreground">
                            {Object.values(audit.phaseAttachments || {}).flat().length}
                          </p>
                        </div>
                      </div>

                      {/* Actions Taken Summary */}
                      <div className="space-y-3">
                        <h4 className="font-medium text-foreground flex items-center gap-2">
                          <ClipboardCheck className="h-4 w-4 text-primary" />
                          Actions Taken
                        </h4>
                        {audit.actions.length > 0 ? (
                          <div className="space-y-2">
                            {audit.actions.map((action, index) => (
                              <div 
                                key={action.id}
                                className={cn(
                                  'flex items-start gap-3 p-3 rounded-lg border',
                                  action.completed 
                                    ? 'bg-status-success/5 border-status-success/20' 
                                    : 'bg-status-pending/5 border-status-pending/20'
                                )}
                              >
                                <div className={cn(
                                  'h-5 w-5 rounded-full flex items-center justify-center shrink-0 mt-0.5',
                                  action.completed ? 'bg-status-success/20' : 'bg-status-pending/20'
                                )}>
                                  {action.completed ? (
                                    <Check className="h-3 w-3 text-status-success" />
                                  ) : (
                                    <Clock className="h-3 w-3 text-status-pending" />
                                  )}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className={cn(
                                    'text-sm font-medium',
                                    action.completed ? 'text-foreground' : 'text-muted-foreground'
                                  )}>
                                    {index + 1}. {action.description}
                                  </p>
                                  {action.completed && action.completedBy && (
                                    <p className="text-xs text-muted-foreground mt-1">
                                      Completed by {action.completedBy} {action.completedAt && `on ${new Date(action.completedAt).toLocaleDateString()}`}
                                    </p>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="text-sm text-muted-foreground p-3 bg-muted/30 rounded-lg">
                            No action items defined for this audit.
                          </p>
                        )}
                      </div>
                      
                      {/* Evidence Summary by Phase */}
                      <div className="space-y-3">
                        <h4 className="font-medium text-foreground flex items-center gap-2">
                          <FileText className="h-4 w-4 text-primary" />
                          Evidence & Attachments by Phase
                        </h4>
                        {Object.entries(audit.phaseAttachments || {}).filter(([_, attachments]) => attachments.length > 0).length > 0 ? (
                          Object.entries(audit.phaseAttachments || {}).map(([phase, attachments]) => (
                            attachments.length > 0 && (
                              <div key={phase} className="p-3 rounded-lg bg-muted/30 border border-border/30">
                                <p className="text-sm font-medium text-foreground mb-2 flex items-center gap-2">
                                  {PHASE_LABELS[phase as AuditPhaseType]}
                                  <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                                    {attachments.length} file{attachments.length !== 1 ? 's' : ''}
                                  </span>
                                </p>
                                <div className="space-y-2">
                                  {attachments.map((file) => (
                                    <div key={file.id} className="flex items-center gap-3 p-2 rounded bg-background/50">
                                      <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                                      <div className="flex-1 min-w-0">
                                        <p className="text-sm font-medium truncate text-foreground">{file.name}</p>
                                        <p className="text-xs text-muted-foreground">
                                          Uploaded by {file.uploadedBy} on {file.uploadedAt}
                                        </p>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )
                          ))
                        ) : (
                          <p className="text-sm text-muted-foreground p-3 bg-muted/30 rounded-lg">
                            No evidence or attachments have been uploaded yet.
                          </p>
                        )}
                      </div>

                      {/* Audit History for periodic audits */}
                      <AuditHistorySection audit={audit} pastAudits={pastAudits} source={source} />

                      {/* Audit Trail */}
                      {audit.history && audit.history.length > 0 && (
                        <div className="space-y-3">
                          <h4 className="font-medium text-foreground flex items-center gap-2">
                            <HistoryIcon className="h-4 w-4 text-primary" />
                            Audit Trail
                          </h4>
                          <div className="space-y-2 max-h-60 overflow-y-auto">
                            {audit.history.slice().reverse().map((entry, index) => (
                              <div key={index} className="flex items-start gap-3 p-2 rounded-lg bg-muted/20 text-sm">
                                <div className="h-2 w-2 rounded-full bg-primary/50 mt-1.5 shrink-0" />
                                <div className="flex-1 min-w-0">
                                  <p className="text-foreground">{entry.action}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {entry.performedBy} • {new Date(entry.performedAt).toLocaleString()}
                                  </p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </TabsContent>

                    <TabsContent value="close-without-cap">
                      <CloseWithoutCAPTab audit={audit} />
                    </TabsContent>

                    <TabsContent value="cap">
                      <CAPClosureTab audit={audit} />
                    </TabsContent>
                  </Tabs>
                )}

                {/* CAP Active Phase */}
                {currentPhase === 'cap_active' && (
                  <div className="space-y-6">
                    <div className="p-6 rounded-lg bg-status-warning-bg border border-status-warning/20">
                      <div className="flex items-start gap-4">
                        <div className="h-12 w-12 rounded-full bg-status-warning/20 flex items-center justify-center shrink-0">
                          <FileWarning className="h-6 w-6 text-status-warning" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-foreground mb-2">CAP In Progress</h3>
                          <p className="text-sm text-muted-foreground mb-4">
                            A Corrective Action Plan (CAP) has been initiated for this audit. The CAPA item is being actively worked on.
                          </p>
                          <div className="p-4 rounded-lg bg-background/50 border border-border/30 mb-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-sm font-medium text-foreground">CAPA Reference</p>
                                <p className="text-xs text-muted-foreground mt-1">CAPA-{audit.id}-001</p>
                              </div>
                              <Button variant="outline" className="gap-2" onClick={() => navigate('/capa')}>
                                <ArrowRight className="h-4 w-4" />
                                Go to CAPA
                              </Button>
                            </div>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            Once the CAPA is verified and closed, this audit will automatically move to the next stage.
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Completed Actions */}
                    {totalActions > 0 && (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-4 rounded-lg bg-status-success/10 border border-status-success/20">
                          <div className="flex items-center gap-3">
                            <Check className="h-5 w-5 text-status-success" />
                            <div>
                              <p className="text-lg font-bold text-foreground">{totalActions}/{totalActions}</p>
                              <p className="text-sm text-muted-foreground">All Actions Completed</p>
                            </div>
                          </div>
                        </div>
                        <div className="space-y-3">
                          {audit.actions.map((action, index) => (
                            <div 
                              key={action.id}
                              className="flex items-start gap-3 p-4 rounded-lg border bg-status-success/5 border-status-success/20"
                            >
                              <Check className="h-5 w-5 text-status-success mt-0.5 shrink-0" />
                              <div className="flex-1">
                                <p className="text-sm line-through text-muted-foreground">
                                  {index + 1}. {action.description}
                                </p>
                                <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                                  <Check className="h-3 w-3 text-status-success" />
                                  Completed by {action.completedBy || currentUser.name}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Pending Verification Phase */}
                {currentPhase === 'pending_verification' && (
                  <div className="space-y-6">
                    <div className="p-6 rounded-lg bg-status-info-bg border border-status-info/20">
                      <div className="flex items-start gap-4">
                        <div className="h-12 w-12 rounded-full bg-status-info/20 flex items-center justify-center shrink-0">
                          <Eye className="h-6 w-6 text-status-info" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-foreground mb-2">Pending Verification</h3>
                          <p className="text-sm text-muted-foreground mb-4">
                            The CAPA actions are complete and awaiting verification. A verifier will review and confirm the corrective actions.
                          </p>
                          <div className="p-4 rounded-lg bg-background/50 border border-border/30 mb-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-sm font-medium text-foreground">CAPA Reference</p>
                                <p className="text-xs text-muted-foreground mt-1">CAPA-{audit.id}-001</p>
                              </div>
                              <Button variant="outline" className="gap-2" onClick={() => navigate('/capa')}>
                                <ArrowRight className="h-4 w-4" />
                                View CAPA Details
                              </Button>
                            </div>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            This audit will close automatically once the CAPA verification is complete.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Closed Phase */}
                {currentPhase === 'closed' && (
                  <div className="space-y-6">
                    <div className="p-6 rounded-lg bg-status-success-bg border border-status-success/20">
                      <div className="flex items-start gap-4">
                        <div className="h-12 w-12 rounded-full bg-status-success/20 flex items-center justify-center shrink-0">
                          <Check className="h-6 w-6 text-status-success" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-foreground mb-2">Ready to Close</h3>
                          <p className="text-sm text-muted-foreground mb-4">
                            The CAPA has been verified and completed. This audit is now ready to be officially closed.
                          </p>
                          {audit.closureType === 'with_cap' && (
                            <div className="p-4 rounded-lg bg-background/50 border border-border/30 mb-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="text-sm font-medium text-foreground">CAPA Reference</p>
                                  <p className="text-xs text-muted-foreground mt-1">CAPA-{audit.id}-001</p>
                                </div>
                                <Button variant="outline" size="sm" className="gap-2" onClick={() => navigate('/capa')}>
                                  <ArrowRight className="h-4 w-4" />
                                  View CAPA
                                </Button>
                              </div>
                            </div>
                          )}
                          <Button 
                            className="w-full gap-2 bg-status-success hover:bg-status-success/90 text-white"
                            onClick={() => {
                              updateAudit(audit.id, { status: 'closed' });
                              addHistoryEntry(audit.id, {
                                action: 'Audit closed',
                                phase: 'closed',
                                performedBy: currentUser.name,
                              });
                              toast.success('Audit closed successfully');
                              navigate(`/?view=${source}`);
                            }}
                          >
                            <Check className="h-4 w-4" />
                            Close Audit
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Action Steps - shown at phases before closure_cap and not on CAP monitoring phases */}
                {!['closure_cap', 'cap_active', 'pending_verification', 'closed'].includes(currentPhase) && totalActions > 0 && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30">
                      <div>
                        <p className="text-3xl font-bold text-foreground">{completedActions}/{totalActions}</p>
                        <p className="text-sm text-muted-foreground">Actions Completed</p>
                      </div>
                    </div>
                    <div className="space-y-3">
                      {audit.actions.map((action, index) => (
                        <div 
                          key={action.id}
                          className={cn(
                            'flex items-start gap-3 p-4 rounded-lg border transition-all',
                            action.completed 
                              ? 'bg-status-success/5 border-status-success/20' 
                              : 'bg-card border-border/50 hover:border-primary/30'
                          )}
                        >
                          <Checkbox
                            id={action.id}
                            checked={action.completed}
                            onCheckedChange={() => handleToggleAction(action.id)}
                            className="mt-0.5"
                          />
                          <div className="flex-1">
                            <label 
                              htmlFor={action.id}
                              className={cn(
                                'text-sm cursor-pointer block',
                                action.completed && 'line-through text-muted-foreground'
                              )}
                            >
                              {index + 1}. {action.description}
                            </label>
                            {action.completed && action.completedBy && (
                              <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                                <Check className="h-3 w-3 text-status-success" />
                                Completed by {action.completedBy}
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Add Action Item */}
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add new action item..."
                        value={newActionDescription}
                        onChange={(e) => setNewActionDescription(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && newActionDescription.trim()) {
                            addActionItem(audit.id, newActionDescription);
                            setNewActionDescription('');
                            toast.success('Action item added');
                          }
                        }}
                        className="flex-1"
                      />
                      <Button
                        size="icon"
                        variant="outline"
                        onClick={() => {
                          if (newActionDescription.trim()) {
                            addActionItem(audit.id, newActionDescription);
                            setNewActionDescription('');
                            toast.success('Action item added');
                          }
                        }}
                        disabled={!newActionDescription.trim()}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    {/* Audit History for periodic audits - shown in evidence_collection and evaluation */}
                    {['evidence_collection', 'evaluation'].includes(currentPhase) && (
                      <AuditHistorySection audit={audit} pastAudits={pastAudits} source={source} />
                    )}
                  </div>
                )}

                {currentPhase === 'internal_review' && (
                  <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                    <p className="text-sm text-primary">
                      Complete all actions and submit for internal review. The reviewer will determine if CAP is required.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Notes Card */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Status Notes</CardTitle>
                <CardDescription>Document your findings for {PHASE_LABELS[currentPhase]}</CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  placeholder="Add notes about this status..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={4}
                  className="resize-none"
                />
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - Right Column */}
          <div className="space-y-6">
            {/* Navigation Card - At top for visibility */}
            <Card className="border-border/50">
              <CardContent className="p-4 space-y-3">
              </CardContent>
            </Card>

            {/* Phase Assignee Card - Now contains submit buttons */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <UserPlus className="h-4 w-4" />
                  Status Assignee
                </CardTitle>
                <CardDescription>Assign someone to this status</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Select 
                  value={displayedCurrentPhaseAssignee} 
                  onValueChange={(value) => setSelectedCurrentPhaseAssignee(value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select assignee" />
                  </SelectTrigger>
                  <SelectContent>
                    {users.map(user => (
                      <SelectItem key={user.id} value={user.id}>
                        {user.name} ({user.department})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                {displayedCurrentPhaseAssigneeUser && (
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-sm font-semibold text-primary">
                      {displayedCurrentPhaseAssigneeUser.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{displayedCurrentPhaseAssigneeUser.name}</p>
                      <p className="text-xs text-muted-foreground">{displayedCurrentPhaseAssigneeUser.department}</p>
                    </div>
                  </div>
                )}

                {/* Assign to New User button - shown when user selects a different assignee */}
                {hasChangedCurrentPhaseAssignee && (
                  <Button
                    className="w-full gap-2 bg-status-warning hover:bg-status-warning/90 text-white"
                    onClick={() => {
                      updatePhaseAssignee(audit.id, currentPhase, selectedCurrentPhaseAssignee);
                      const newUser = users.find(u => u.id === selectedCurrentPhaseAssignee);
                      addHistoryEntry(audit.id, {
                        action: `Assigned ${PHASE_LABELS[currentPhase]} to ${newUser?.name}`,
                        phase: currentPhase,
                        performedBy: currentUser.name,
                      });
                      toast.success('Assigned to New User', {
                        description: `${newUser?.name} is now assigned to ${PHASE_LABELS[currentPhase]}.`,
                      });
                      setSelectedCurrentPhaseAssignee(null);
                      handleBack();
                    }}
                  >
                    <UserPlus className="h-4 w-4" />
                    Assign to {displayedCurrentPhaseAssigneeUser?.name}
                  </Button>
                )}

                {/* Pre-Audit Phase Actions */}
                {currentPhase === 'pre_audit' && !hasChangedCurrentPhaseAssignee && (
                  <div className="space-y-2 pt-4 border-t border-border/30">
                    <Button
                      className="w-full gap-2 bg-status-success hover:bg-status-success/90 text-white"
                      onClick={() => {
                        if (audit.type === 'external') {
                          updateAudit(audit.id, { 
                            status: 'draft', 
                            currentPhase: 'overview',
                            phase: 'overview',
                            department: 'Quality Assurance'
                          });
                          addHistoryEntry(audit.id, {
                            action: 'Pre-audit marked ready for audit - routed to Quality Assurance department',
                            phase: 'overview',
                            performedBy: currentUser.name,
                          });
                          toast.success('Ready for Audit', {
                            description: 'Item has been routed to Quality Assurance department.',
                          });
                        } else {
                          updateAudit(audit.id, { 
                            status: 'draft', 
                            currentPhase: 'overview',
                            phase: 'overview'
                          });
                          addHistoryEntry(audit.id, {
                            action: 'Pre-audit marked ready for audit - routed to department To Do',
                            phase: 'overview',
                            performedBy: currentUser.name,
                          });
                          toast.success('Ready for Audit', {
                            description: "Item has been moved to your department's To Do list.",
                          });
                        }
                        navigate(`/?view=${source}`);
                      }}
                    >
                      <Check className="h-4 w-4" />
                      Submit for Audit
                    </Button>
                    
                    <Button
                      variant="destructive"
                      className="w-full gap-2"
                      onClick={() => {
                        const originalCreator = users.find(u => u.id === audit.createdBy);
                        updateAudit(audit.id, { 
                          status: 'pre_audit',
                          reviewNotes: rejectNotes || 'Review failed - needs additional preparation',
                          assignedTo: audit.createdBy,
                          assignedToName: originalCreator?.name || audit.assignedToName
                        });
                        addHistoryEntry(audit.id, {
                          action: `Review failed - returned to ${originalCreator?.name || 'original creator'}`,
                          phase: 'pre_audit',
                          performedBy: currentUser.name,
                          notes: rejectNotes,
                        });
                        toast.success('Review Failed', {
                          description: `Item has been returned to ${originalCreator?.name || 'the original creator'}.`,
                        });
                        navigate(`/?view=${source}`);
                      }}
                    >
                      <X className="h-4 w-4" />
                      Failed Review
                    </Button>
                  </div>
                )}

                {/* Submit buttons for other phases - shown below assignee selection */}
                {!['pre_audit', 'internal_review', 'cap_active', 'pending_verification', 'closed'].includes(currentPhase) && !hasChangedCurrentPhaseAssignee && (
                  <div className="space-y-2 pt-4 border-t border-border/30">
                    <Button
                      className="w-full gap-2"
                      onClick={handleSubmitToCurrentPhaseAssignee}
                    >
                      <Send className="h-4 w-4" />
                      Submit
                    </Button>
                  </div>
                )}
                
                {currentPhase === 'internal_review' && !hasChangedCurrentPhaseAssignee && (
                  <div className="space-y-2 pt-4 border-t border-border/30">
                    <Button
                      className="w-full gap-2"
                      disabled={!allActionsComplete}
                      onClick={handleSubmitForReview}
                    >
                      <Send className="h-4 w-4" />
                      Submit for Internal Review
                    </Button>
                    {!allActionsComplete && (
                      <p className="text-xs text-muted-foreground text-center">
                        Complete all action items to submit
                      </p>
                    )}
                  </div>
                )}

                {/* Next Phase Assignee Section */}
                {nextPhase && currentPhase !== 'closure_cap' && currentPhase !== 'pre_audit' && !hasChangedCurrentPhaseAssignee && (
                  <div className="pt-4 border-t border-border/30 space-y-3">
                    <div>
                      <p className="text-sm font-medium text-foreground mb-1">Next Status: {PHASE_LABELS[nextPhase]}</p>
                      <p className="text-xs text-muted-foreground mb-2">Select assignee and submit to next status</p>
                    </div>
                    <Select 
                      value={displayedNextPhaseAssignee || ''} 
                      onValueChange={(value) => setSelectedNextPhaseAssignee(value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select next status assignee" />
                      </SelectTrigger>
                      <SelectContent>
                        {users.map(user => (
                          <SelectItem key={user.id} value={user.id}>
                            {user.name} ({user.department})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    {displayedNextPhaseAssigneeUser && (
                      <div className="flex items-center gap-2 p-2 rounded-lg bg-primary/5 border border-primary/20">
                        <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-semibold text-primary">
                          {displayedNextPhaseAssigneeUser.name.charAt(0)}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-primary">{displayedNextPhaseAssigneeUser.name}</p>
                          <p className="text-xs text-muted-foreground">Will handle {PHASE_LABELS[nextPhase]}</p>
                        </div>
                      </div>
                    )}
                    
                    <Button
                      variant="outline"
                      className="w-full gap-2"
                      onClick={() => {
                        if (selectedNextPhaseAssignee) {
                          updatePhaseAssignee(audit.id, nextPhase, selectedNextPhaseAssignee);
                        }
                        updateAudit(audit.id, { currentPhase: nextPhase });
                        const assigneeUser = selectedNextPhaseAssignee 
                          ? users.find(u => u.id === selectedNextPhaseAssignee) 
                          : displayedNextPhaseAssigneeUser;
                        addHistoryEntry(audit.id, {
                          action: `Submitted to ${PHASE_LABELS[nextPhase]} - assigned to ${assigneeUser?.name}`,
                          phase: nextPhase,
                          performedBy: currentUser.name,
                        });
                        toast.success('Submitted to Next Status', {
                          description: `${assigneeUser?.name} will now handle ${PHASE_LABELS[nextPhase]}.`,
                        });
                        setSelectedNextPhaseAssignee(null);
                        handleBack();
                      }}
                    >
                      <Send className="h-4 w-4" />
                      Submit to Next Phase
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Attachments Card */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Attachments</CardTitle>
                <CardDescription>Files for {PHASE_LABELS[currentPhase]}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {phaseAttachments.length > 0 ? (
                  <div className="space-y-2">
                    {phaseAttachments.map((file) => (
                      <div 
                        key={file.id}
                        className="flex items-center gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                      >
                        <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate text-foreground">{file.name}</p>
                          <p className="text-xs text-muted-foreground">{file.uploadedAt}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No attachments yet
                  </p>
                )}

                <div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                  <Button
                    variant="outline"
                    className="w-full gap-2"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="h-4 w-4" />
                    Upload Attachment
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Cross-Microapp Links Card */}
            <LinkedItemsSection
              auditId={audit.id}
              linkedItems={audit.linkedItems || []}
              onAddLink={(item) => addLinkedItem(audit.id, item)}
              onRemoveLink={(itemId) => removeLinkedItem(audit.id, itemId)}
              readOnly={audit.status === 'closed'}
            />

            {/* Progress Card */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Clock className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{PHASE_LABELS[currentPhase]}</p>
                    <p className="text-xs text-muted-foreground">
                      Step {currentPhaseIndex + 1} of {phaseOrder.length}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
