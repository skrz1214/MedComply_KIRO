import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAudit, mockUsers } from '@/contexts/AuditContext';
import { usePermissions } from '@/hooks/usePermissions';
import { AppLayout } from '@/components/layout/AppLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import { AuditType, AuditAction, Periodicity, PERIODICITY_LABELS, LinkedItem, MicroApp, MICROAPP_LABELS, MICROAPP_COLORS } from '@/types/audit';
import { ArrowLeft, Plus, Trash2, FileText, Shield, Repeat, Calendar, AlertTriangle, Link2, ExternalLink, MessageSquare, Gavel, Lock } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const departments = [
  'Nursing',
  'Quality Assurance',
  'Administration',
  'Pharmacy',
  'Radiology',
  'Laboratory',
];

export default function NewAudit() {
  const navigate = useNavigate();
  const { addAudit, currentUser } = useAudit();
  const permissions = usePermissions();

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'internal' as AuditType,
    department: currentUser.department,
    assignedTo: '',
    dueDate: '',
    priority: 'medium' as 'low' | 'medium' | 'high' | 'critical',
    isPeriodic: false,
    periodicity: 'monthly' as Periodicity,
    risksAndDependencies: '',
  });

  const [actions, setActions] = useState<{ id: string; description: string }[]>([
    { id: '1', description: '' },
  ]);

  const [linkedItems, setLinkedItems] = useState<Omit<LinkedItem, 'id' | 'linkedAt' | 'linkedBy'>[]>([]);
  const [linkDialogOpen, setLinkDialogOpen] = useState(false);
  const [selectedMicroApp, setSelectedMicroApp] = useState<MicroApp | ''>('');
  const [selectedItemId, setSelectedItemId] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const MICROAPP_ICONS: Record<MicroApp, React.ReactNode> = {
    RiskGuard: <AlertTriangle className="h-4 w-4" />,
    ComplianceConnect: <Shield className="h-4 w-4" />,
    FeedbackHub: <MessageSquare className="h-4 w-4" />,
    EnforcePoint: <Gavel className="h-4 w-4" />,
  };

  // Redirect Staff users who cannot create audits - must be after all hooks
  if (!permissions.canCreateAudit) {
    return (
      <AppLayout>
        <div className="p-8 flex items-center justify-center h-full">
          <Card className="max-w-md w-full border-amber-200 bg-amber-50">
            <CardContent className="p-8 text-center">
              <Lock className="h-12 w-12 text-amber-600 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-amber-800 mb-2">Access Restricted</h2>
              <p className="text-amber-700 mb-4">
                You don't have permission to create new audits. Contact your Department Head if you need to create an audit.
              </p>
              <Button onClick={() => navigate('/')} variant="outline">
                Return to Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  const MOCK_ITEMS: Record<MicroApp, { id: string; title: string; type: string; status: string }[]> = {
    RiskGuard: [
      { id: 'RG-001', title: 'Data Breach Risk Assessment', type: 'Risk Assessment', status: 'Open' },
      { id: 'RG-002', title: 'Third Party Vendor Risk', type: 'Vendor Risk', status: 'In Progress' },
      { id: 'RG-003', title: 'System Vulnerability Analysis', type: 'IT Risk', status: 'Pending Review' },
    ],
    ComplianceConnect: [
      { id: 'CC-001', title: 'HIPAA Compliance Review', type: 'Regulatory', status: 'Active' },
      { id: 'CC-002', title: 'Annual Policy Update', type: 'Policy', status: 'Draft' },
      { id: 'CC-003', title: 'Training Completion Tracking', type: 'Training', status: 'In Progress' },
    ],
    FeedbackHub: [
      { id: 'FH-001', title: 'Patient Safety Concern Report', type: 'Safety Report', status: 'New' },
      { id: 'FH-002', title: 'Staff Feedback - Process Improvement', type: 'Feedback', status: 'Under Review' },
      { id: 'FH-003', title: 'Equipment Malfunction Report', type: 'Incident Report', status: 'Investigating' },
    ],
    EnforcePoint: [
      { id: 'EP-001', title: 'Policy Violation - Documentation', type: 'Enforcement', status: 'Pending Action' },
      { id: 'EP-002', title: 'Corrective Action Required', type: 'Corrective Action', status: 'In Progress' },
      { id: 'EP-003', title: 'Follow-up Inspection', type: 'Inspection', status: 'Scheduled' },
    ],
  };

  const availableItems = selectedMicroApp ? MOCK_ITEMS[selectedMicroApp] : [];
  const filteredItems = availableItems.filter(item => 
    item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.id.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const selectedItem = availableItems.find(item => item.id === selectedItemId);

  const handleAddLink = () => {
    if (!selectedMicroApp || !selectedItem) return;

    if (linkedItems.some(l => l.itemId === selectedItem.id && l.microApp === selectedMicroApp)) {
      toast.error('This item is already linked');
      return;
    }

    setLinkedItems([...linkedItems, {
      microApp: selectedMicroApp,
      itemId: selectedItem.id,
      itemTitle: selectedItem.title,
      itemType: selectedItem.type,
      status: selectedItem.status,
      url: `/${selectedMicroApp.toLowerCase()}/${selectedItem.id}`,
    }]);

    toast.success(`${selectedItem.title} linked`);
    setLinkDialogOpen(false);
    setSelectedMicroApp('');
    setSelectedItemId('');
    setSearchTerm('');
  };

  const handleRemoveLink = (itemId: string) => {
    setLinkedItems(linkedItems.filter(l => l.itemId !== itemId));
  };

  const addAction = () => {
    setActions([...actions, { id: Date.now().toString(), description: '' }]);
  };

  const removeAction = (id: string) => {
    if (actions.length > 1) {
      setActions(actions.filter(a => a.id !== id));
    }
  };

  const updateAction = (id: string, description: string) => {
    setActions(actions.map(a => a.id === id ? { ...a, description } : a));
  };

  const calculateNextScheduledDate = (dueDate: string, periodicity: Periodicity): string => {
    if (!dueDate) return '';
    const date = new Date(dueDate);
    switch (periodicity) {
      case 'daily':
        date.setDate(date.getDate() + 1);
        break;
      case 'weekly':
        date.setDate(date.getDate() + 7);
        break;
      case 'monthly':
        date.setMonth(date.getMonth() + 1);
        break;
      case 'quarterly':
        date.setMonth(date.getMonth() + 3);
        break;
      case 'annually':
        date.setFullYear(date.getFullYear() + 1);
        break;
    }
    return date.toISOString().split('T')[0];
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const assignedUser = mockUsers.find(u => u.id === formData.assignedTo);
    
    addAudit({
      title: formData.title,
      description: formData.description,
      type: formData.type,
      department: formData.department,
      assignedTo: formData.assignedTo,
      dueDate: formData.dueDate,
      priority: formData.priority,
      assignedToName: assignedUser?.name || '',
      createdBy: currentUser.id,
      status: 'pre_audit',
      phase: 'pre_audit',
      currentPhase: 'pre_audit',
      isPeriodic: formData.isPeriodic,
      periodicity: formData.isPeriodic ? formData.periodicity : undefined,
      nextScheduledDate: formData.isPeriodic 
        ? calculateNextScheduledDate(formData.dueDate, formData.periodicity) 
        : undefined,
      actions: actions.filter(a => a.description.trim()).map(a => ({
        id: a.id,
        description: a.description,
        completed: false,
      })) as AuditAction[],
    });

    toast.success('Pre-audit item created successfully', {
      description: 'The item has been created and assigned for pre-audit preparation.',
    });

    navigate('/');
  };

  return (
    <AppLayout>
      <div className="p-8 max-w-4xl">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate('/')}
            className="mb-4 gap-2 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
          
          <div className="flex items-center gap-4">
            <div className="h-14 w-14 rounded-2xl gradient-primary flex items-center justify-center">
              <FileText className="h-7 w-7 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">New Pre-Audit Item</h1>
              <p className="text-muted-foreground">Create a new item for pre-audit preparation before starting the audit lifecycle</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Basic Information</CardTitle>
              <CardDescription>Enter the audit details and classification</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Audit Title</Label>
                <Input
                  id="title"
                  placeholder="e.g., Medication Administration Compliance Review"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Provide a detailed description of the audit scope and objectives..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={4}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Audit Type</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value: AuditType) => setFormData({ ...formData, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="internal">Internal Audit</SelectItem>
                      <SelectItem value="external">External Audit</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Priority</Label>
                  <Select
                    value={formData.priority}
                    onValueChange={(value: 'low' | 'medium' | 'high' | 'critical') => 
                      setFormData({ ...formData, priority: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Scheduling */}
          <Card className="border-border/50">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-muted-foreground" />
                <div>
                  <CardTitle className="text-lg">Scheduling</CardTitle>
                  <CardDescription>Set the audit schedule and recurrence</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                <div className="flex items-center gap-3">
                  <Repeat className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Periodic Audit</p>
                    <p className="text-sm text-muted-foreground">Schedule this audit to repeat automatically</p>
                  </div>
                </div>
                <Switch
                  checked={formData.isPeriodic}
                  onCheckedChange={(checked) => setFormData({ ...formData, isPeriodic: checked })}
                />
              </div>

              {formData.isPeriodic && (
                <div className="space-y-2 animate-fade-in">
                  <Label>Periodicity</Label>
                  <Select
                    value={formData.periodicity}
                    onValueChange={(value: Periodicity) => setFormData({ ...formData, periodicity: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="annually">Annually</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    The audit will automatically be rescheduled after completion
                  </p>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="dueDate">Due Date</Label>
                <Input
                  id="dueDate"
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                  required
                />
                {formData.isPeriodic && formData.dueDate && (
                  <p className="text-xs text-primary">
                    Next scheduled: {calculateNextScheduledDate(formData.dueDate, formData.periodicity)}
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Assignment */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Assignment</CardTitle>
              <CardDescription>Assign the audit to a team member</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Department</Label>
                  <Select
                    value={formData.department}
                    onValueChange={(value) => setFormData({ ...formData, department: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {departments.map((dept) => (
                        <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Assign To</Label>
                  <Select
                    value={formData.assignedTo}
                    onValueChange={(value) => setFormData({ ...formData, assignedTo: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select team member" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockUsers.map((user) => (
                        <SelectItem key={user.id} value={user.id}>
                          {user.name} ({user.department})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Risks & Dependencies */}
          <Card className="border-border/50">
            <CardHeader>
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-muted-foreground" />
                <div>
                  <CardTitle className="text-lg">Risks & Dependencies</CardTitle>
                  <CardDescription>Document potential risks, blockers, or dependencies for this audit</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Document any risks, dependencies, or potential blockers for this audit. For example: equipment needs, staff availability, regulatory requirements, or other factors that could impact the audit..."
                value={formData.risksAndDependencies}
                onChange={(e) => setFormData({ ...formData, risksAndDependencies: e.target.value })}
                rows={4}
              />
            </CardContent>
          </Card>

          {/* Cross-Microapp Links */}
          <Card className="border-border/50">
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-2">
                <Link2 className="h-5 w-5 text-muted-foreground" />
                <div>
                  <CardTitle className="text-lg">Cross-Microapp Links</CardTitle>
                  <CardDescription>Link related items from other microapps</CardDescription>
                </div>
              </div>
              <Dialog open={linkDialogOpen} onOpenChange={setLinkDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-2">
                    <Plus className="h-4 w-4" />
                    Link Item
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-lg">
                  <DialogHeader>
                    <DialogTitle>Link External Item</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label>Select Microapp</Label>
                      <Select 
                        value={selectedMicroApp} 
                        onValueChange={(value) => {
                          setSelectedMicroApp(value as MicroApp);
                          setSelectedItemId('');
                          setSearchTerm('');
                        }}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Choose a microapp..." />
                        </SelectTrigger>
                        <SelectContent>
                          {(Object.keys(MICROAPP_LABELS) as MicroApp[]).map((app) => (
                            <SelectItem key={app} value={app}>
                              <div className="flex items-center gap-2">
                                {MICROAPP_ICONS[app]}
                                {MICROAPP_LABELS[app]}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {selectedMicroApp && (
                      <>
                        <div className="space-y-2">
                          <Label>Search Items</Label>
                          <Input
                            placeholder="Search by title or ID..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>Select Item</Label>
                          <div className="max-h-48 overflow-y-auto border rounded-md">
                            {filteredItems.length === 0 ? (
                              <p className="p-4 text-sm text-muted-foreground text-center">
                                No items found
                              </p>
                            ) : (
                              filteredItems.map((item) => (
                                <button
                                  type="button"
                                  key={item.id}
                                  onClick={() => setSelectedItemId(item.id)}
                                  className={cn(
                                    'w-full p-3 text-left border-b last:border-b-0 hover:bg-muted/50 transition-colors',
                                    selectedItemId === item.id && 'bg-primary/5 border-l-2 border-l-primary'
                                  )}
                                >
                                  <div className="flex items-start justify-between gap-2">
                                    <div>
                                      <p className="font-medium text-sm">{item.title}</p>
                                      <p className="text-xs text-muted-foreground">{item.id} • {item.type}</p>
                                    </div>
                                    <Badge variant="outline" className="text-xs shrink-0">
                                      {item.status}
                                    </Badge>
                                  </div>
                                </button>
                              ))
                            )}
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setLinkDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="button" onClick={handleAddLink} disabled={!selectedMicroApp || !selectedItemId}>
                      Link Item
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {linkedItems.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground">
                  <Link2 className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">No linked items</p>
                  <p className="text-xs mt-1">Link items from RiskGuard, ComplianceConnect, FeedbackHub, or EnforcePoint</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {linkedItems.map((item) => (
                    <div
                      key={item.itemId}
                      className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-muted/30 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className={cn('p-2 rounded-lg', MICROAPP_COLORS[item.microApp])}>
                          {MICROAPP_ICONS[item.microApp]}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-sm">{item.itemTitle}</p>
                            <Badge 
                              variant="outline" 
                              className={cn('text-xs', MICROAPP_COLORS[item.microApp])}
                            >
                              {MICROAPP_LABELS[item.microApp]}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {item.itemId} • {item.itemType} • {item.status}
                          </p>
                        </div>
                      </div>
                      <Button 
                        type="button"
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => handleRemoveLink(item.itemId)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Action Steps */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Action Steps</CardTitle>
              <CardDescription>Define the action items that need to be completed for this audit</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {actions.map((action, index) => (
                <div key={action.id} className="flex items-center gap-3">
                  <span className="text-sm text-muted-foreground w-6">{index + 1}.</span>
                  <Input
                    placeholder="Describe the action step..."
                    value={action.description}
                    onChange={(e) => updateAction(action.id, e.target.value)}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeAction(action.id)}
                    disabled={actions.length === 1}
                    className="text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}

              <Button
                type="button"
                variant="outline"
                onClick={addAction}
                className="w-full gap-2"
              >
                <Plus className="h-4 w-4" />
                Add Action Step
              </Button>
            </CardContent>
          </Card>

          {/* Submit */}
          <div className="flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={() => navigate('/')}>
              Cancel
            </Button>
            <Button type="submit" className="gradient-primary text-primary-foreground gap-2">
              <Shield className="h-4 w-4" />
              Create Pre-Audit Item
            </Button>
          </div>
        </form>
      </div>
    </AppLayout>
  );
}