import { useNavigate } from 'react-router-dom';
import { useMemo, useState } from 'react';
import {
  Package,
  Plus,
  History,
  FileText,
  Shield,
  CheckCircle2,
  AlertTriangle,
  ChevronDown,
  Download,
  Share2,
  Clock,
  ArrowUpRight,
  Activity,
} from 'lucide-react';
import { AppLayout } from '@/components/layout/AppLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { useAuditPack } from '@/contexts/AuditPackContext';
import { useAudit } from '@/contexts/AuditContext';
import { format, formatDistanceToNow } from 'date-fns';
import { ReadinessHero } from '@/components/auditPack/ReadinessHero';
import { cn } from '@/lib/utils';

const ROLE_LABEL: Record<string, string> = {
  staff: 'Staff',
  department_head: 'Department Head',
  compliance_head: 'Compliance Head',
  admin: 'Admin',
};

export default function AuditPack() {
  const navigate = useNavigate();
  const { currentUser } = useAudit();
  const { exports, controls, policies, evidence, training, generatePreview } = useAuditPack();
  const [hipaaOpen, setHipaaOpen] = useState(false);

  const canGenerate = ['admin', 'compliance_head', 'department_head'].includes(currentUser.role);
  const latestExport = exports[0];
  const previousExport = exports[1];

  // Quick stats
  const currentEvidence = evidence.filter((e) => e.expiresAt > new Date()).length;
  const staleEvidence = evidence.length - currentEvidence;
  const completedTraining = training.filter((t) => t.status === 'completed').length;
  const overdueTraining = training.filter((t) => t.status === 'overdue').length;
  const trainingPercent =
    training.length > 0 ? Math.round((completedTraining / training.length) * 100) : 100;

  // Live readiness preview against full scope
  const livePreview = useMemo(() => {
    const start = new Date();
    start.setFullYear(start.getFullYear() - 1);
    return generatePreview({
      dateRange: { start, end: new Date() },
      includeLinks: true,
      includeEvidenceFiles: true,
      includePHI: false,
    });
  }, [generatePreview]);

  return (
    <AppLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Audit Pack</h1>
            <p className="mt-1 text-muted-foreground">
              Compliance command center — generate HIPAA-aligned audit export packages
            </p>
          </div>
          {canGenerate && (
            <Button onClick={() => navigate('/audit-pack/new')} size="lg">
              <Plus className="mr-2 h-4 w-4" />
              Create Audit Pack
            </Button>
          )}
        </div>

        {/* Readiness Hero */}
        <ReadinessHero
          score={livePreview.readinessScore.total}
          previousScore={previousExport?.readinessScore}
          topGaps={livePreview.readinessScore.nextActions}
          breakdown={livePreview.readinessScore.breakdown}
          canGenerate={canGenerate}
        />

        {/* Clickable Stat Tiles */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatTile
            icon={<Shield className="h-4 w-4" />}
            label="HIPAA Controls"
            value={controls.length}
            sublabel="controls tracked"
            onClick={() => navigate('/audit-pack/new?step=scope')}
          />
          <StatTile
            icon={<FileText className="h-4 w-4" />}
            label="Policies"
            value={policies.length}
            sublabel="active policies"
            onClick={() => navigate('/audit-pack/new?step=scope')}
          />
          <StatTile
            icon={<CheckCircle2 className="h-4 w-4" />}
            label="Evidence"
            value={currentEvidence}
            sublabel="current items"
            tone={staleEvidence > 0 ? 'warning' : 'success'}
            badge={staleEvidence > 0 ? `${staleEvidence} stale` : 'All current'}
            onClick={() => navigate('/audit-pack/new?step=evidence')}
          />
          <StatTile
            icon={<Activity className="h-4 w-4" />}
            label="Training"
            value={`${trainingPercent}%`}
            sublabel="completion rate"
            tone={overdueTraining > 0 ? 'warning' : 'success'}
            badge={overdueTraining > 0 ? `${overdueTraining} overdue` : undefined}
            onClick={() => navigate('/audit-pack/new?step=evidence')}
          />
        </div>

        {/* Latest Export + Recent Activity */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Latest Export — richer */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5 text-primary" />
                  Latest Export
                </CardTitle>
                <CardDescription>Most recent audit pack generated</CardDescription>
              </div>
              {latestExport && (
                <Badge
                  className={cn(
                    'border-0',
                    latestExport.readinessScore >= 80
                      ? 'bg-status-success-bg text-status-success'
                      : latestExport.readinessScore >= 60
                      ? 'bg-status-warning-bg text-status-warning'
                      : 'bg-status-error-bg text-status-error',
                  )}
                >
                  Score {latestExport.readinessScore}/100
                </Badge>
              )}
            </CardHeader>
            <CardContent>
              {latestExport ? (
                <div className="space-y-4">
                  <div className="grid gap-3 sm:grid-cols-2">
                    <Detail label="Export ID" value={<span className="font-mono">{latestExport.id}</span>} />
                    <Detail
                      label="Created"
                      value={
                        <span title={format(latestExport.createdAt, 'PPpp')}>
                          {formatDistanceToNow(latestExport.createdAt, { addSuffix: true })}
                        </span>
                      }
                    />
                    <Detail label="Created by" value={latestExport.createdBy} />
                    <Detail label="Scope" value={latestExport.scopeLabel} />
                  </div>

                  <div className="rounded-lg border border-border bg-muted/40 p-3">
                    <p className="mb-1 text-xs font-medium text-muted-foreground">SHA-256 Integrity Hash</p>
                    <p className="break-all font-mono text-xs text-foreground">
                      {latestExport.zipSha256}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2 pt-1">
                    <Button
                      size="sm"
                      onClick={() => navigate(`/audit-pack/history?export=${latestExport.id}`)}
                    >
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => navigate(`/audit-pack/history?export=${latestExport.id}&action=share`)}
                    >
                      <Share2 className="mr-2 h-4 w-4" />
                      Share with Auditor
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => navigate('/audit-pack/history')}
                    >
                      View All ({exports.length})
                      <ArrowUpRight className="ml-1 h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border bg-muted/30 p-8 text-center">
                  <Package className="mb-3 h-10 w-10 text-muted-foreground" />
                  <p className="text-sm font-medium text-foreground">No exports yet</p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Generate your first audit pack to see it here
                  </p>
                  {canGenerate && (
                    <Button className="mt-4" size="sm" onClick={() => navigate('/audit-pack/new')}>
                      <Plus className="mr-2 h-4 w-4" />
                      Create First Export
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Activity Timeline */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5 text-primary" />
                Recent Activity
              </CardTitle>
              <CardDescription>Last 5 audit pack events</CardDescription>
            </CardHeader>
            <CardContent>
              {exports.length === 0 ? (
                <p className="py-6 text-center text-sm text-muted-foreground">
                  No activity yet
                </p>
              ) : (
                <ol className="relative space-y-4 border-l border-border pl-5">
                  {exports.slice(0, 5).map((exp) => (
                    <li key={exp.id} className="relative">
                      <span className="absolute -left-[27px] flex h-4 w-4 items-center justify-center rounded-full bg-primary/10 ring-4 ring-card">
                        <Package className="h-2.5 w-2.5 text-primary" />
                      </span>
                      <p className="text-sm font-medium text-foreground">
                        Export <span className="font-mono text-xs">{exp.id}</span>
                      </p>
                      <p className="mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        {formatDistanceToNow(exp.createdAt, { addSuffix: true })} • {exp.createdBy}
                      </p>
                      <Badge
                        variant="outline"
                        className={cn(
                          'mt-1 text-xs',
                          exp.readinessScore >= 80
                            ? 'border-status-success/30 text-status-success'
                            : exp.readinessScore >= 60
                            ? 'border-status-warning/30 text-status-warning'
                            : 'border-status-error/30 text-status-error',
                        )}
                      >
                        Score {exp.readinessScore}
                      </Badge>
                    </li>
                  ))}
                </ol>
              )}
            </CardContent>
          </Card>
        </div>

        {!canGenerate && (
          <Card className="border-status-info/30 bg-status-info-bg/30">
            <CardContent className="flex items-start gap-3 p-4">
              <AlertTriangle className="mt-0.5 h-5 w-5 flex-shrink-0 text-status-info" />
              <div>
                <p className="text-sm font-medium text-foreground">View-only access</p>
                <p className="mt-0.5 text-sm text-muted-foreground">
                  You're signed in as <strong>{ROLE_LABEL[currentUser.role] ?? currentUser.role}</strong>.
                  Department Head, Compliance Head, or Admin permissions are required to create audit packs.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* HIPAA Structure — Collapsible */}
        <Collapsible open={hipaaOpen} onOpenChange={setHipaaOpen}>
          <Card>
            <CollapsibleTrigger asChild>
              <CardHeader className="cursor-pointer transition-colors hover:bg-muted/40">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="h-5 w-5 text-primary" />
                      HIPAA Audit Organization
                    </CardTitle>
                    <CardDescription>
                      How exports are organized according to HIPAA regulatory structure
                    </CardDescription>
                  </div>
                  <ChevronDown
                    className={cn(
                      'h-5 w-5 text-muted-foreground transition-transform',
                      hipaaOpen && 'rotate-180',
                    )}
                  />
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-3">
                  <RuleBlock
                    label="Privacy Rule"
                    items={[
                      'Uses and Disclosures of PHI',
                      'Notice of Privacy Practices',
                      'Individual Rights',
                    ]}
                  />
                  <div>
                    <Badge className="mb-3">Security Rule</Badge>
                    <div className="space-y-3">
                      <SubRule
                        label="Administrative Safeguards"
                        desc="Risk analysis, workforce security, training"
                      />
                      <SubRule
                        label="Physical Safeguards"
                        desc="Facility access, device controls"
                      />
                      <SubRule
                        label="Technical Safeguards"
                        desc="Access control, audit controls, encryption"
                      />
                    </div>
                  </div>
                  <RuleBlock
                    label="Breach Notification"
                    items={[
                      'Breach definitions',
                      'Notification requirements',
                      'Incident response plans',
                    ]}
                  />
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>
      </div>
    </AppLayout>
  );
}

interface StatTileProps {
  icon: React.ReactNode;
  label: string;
  value: number | string;
  sublabel: string;
  tone?: 'success' | 'warning' | 'error' | 'default';
  badge?: string;
  onClick?: () => void;
}

function StatTile({ icon, label, value, sublabel, tone = 'default', badge, onClick }: StatTileProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'group relative overflow-hidden rounded-xl border border-border bg-card p-4 text-left shadow-card transition-all',
        'hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2',
      )}
    >
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
          {icon}
          {label}
        </span>
        <ArrowUpRight className="h-4 w-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
      </div>
      <div className="mt-2 flex items-baseline gap-2">
        <span
          className={cn(
            'text-3xl font-bold tabular-nums',
            tone === 'success' && 'text-status-success',
            tone === 'warning' && 'text-status-warning',
            tone === 'error' && 'text-status-error',
            tone === 'default' && 'text-foreground',
          )}
        >
          {value}
        </span>
        <span className="text-sm text-muted-foreground">{sublabel}</span>
      </div>
      {badge && (
        <Badge
          variant="outline"
          className={cn(
            'mt-2',
            tone === 'success' && 'border-status-success/30 text-status-success',
            tone === 'warning' && 'border-status-warning/30 text-status-warning',
            tone === 'error' && 'border-status-error/30 text-status-error',
          )}
        >
          {badge}
        </Badge>
      )}
    </button>
  );
}

function Detail({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <p className="text-xs font-medium text-muted-foreground">{label}</p>
      <p className="mt-0.5 text-sm text-foreground">{value}</p>
    </div>
  );
}

function RuleBlock({ label, items }: { label: string; items: string[] }) {
  return (
    <div>
      <Badge className="mb-3">{label}</Badge>
      <ul className="space-y-1.5 text-sm text-muted-foreground">
        {items.map((item) => (
          <li key={item} className="flex items-start gap-2">
            <span className="mt-1.5 inline-block h-1 w-1 flex-shrink-0 rounded-full bg-primary" />
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}

function SubRule({ label, desc }: { label: string; desc: string }) {
  return (
    <div>
      <p className="text-sm font-medium text-foreground">{label}</p>
      <p className="text-xs text-muted-foreground">{desc}</p>
    </div>
  );
}
