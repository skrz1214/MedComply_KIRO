import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAudit } from '@/contexts/AuditContext';
import { AppLayout } from '@/components/layout/AppLayout';
import { StatusBadge } from '@/components/audit/StatusBadge';
import { PriorityBadge } from '@/components/audit/PriorityBadge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { 
  ArrowLeft, 
  Calendar, 
  User, 
  Building2, 
  FileText, 
  Check,
  AlertTriangle,
  Shield,
  FileWarning,
  CheckCircle2,
  XCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function ClosureCAP() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { audits, closeAudit, updateAudit, currentUser } = useAudit();

  const audit = audits.find(a => a.id === id);
  const [decision, setDecision] = useState<'complete' | 'cap' | ''>('');
  const [capNotes, setCapNotes] = useState('');
  const [verifyDecision, setVerifyDecision] = useState<'verify' | 'reopen' | ''>('');
  const [verifyNotes, setVerifyNotes] = useState('');

  if (!audit) {
    return (
      <AppLayout>
        <div className="p-8 flex items-center justify-center h-full">
          <div className="text-center">
            <h2 className="text-xl font-semibold mb-2">Audit Not Found</h2>
            <p className="text-muted-foreground mb-4">The audit item you're looking for doesn't exist.</p>
            <Button onClick={() => navigate('/')}>Return to Dashboard</Button>
          </div>
        </div>
      </AppLayout>
    );
  }

  const handleSubmitClosure = () => {
    if (decision === 'cap' && !capNotes.trim()) {
      toast.error('Please provide CAP details', {
        description: 'You must describe the corrective action plan requirements.',
      });
      return;
    }

    closeAudit(audit.id, decision === 'cap');
    
    if (decision === 'cap') {
      toast.success('CAP Initiated', {
        description: 'A Corrective Action Plan has been created and routed to the responsible department.',
      });
    } else {
      toast.success('Audit Completed', {
        description: 'The audit has been marked as complete.',
      });
    }
    
    navigate('/');
  };

  const phase = audit.currentPhase;
  const isCapActive = phase === 'cap_active';
  const isPendingVerification = phase === 'pending_verification';
  const isClosed = phase === 'closed';

  const headerLabel = isPendingVerification
    ? 'QA Verification'
    : isCapActive
    ? 'CAP In Progress'
    : isClosed
    ? 'Audit Closed'
    : 'QA Review & Closure';

  const handleMarkCapComplete = () => {
    updateAudit(audit.id, {
      status: 'pending_verification',
      currentPhase: 'pending_verification',
      phase: 'pending_verification',
    });
    toast.success('CAP marked complete', {
      description: 'Audit moved to Pending Verification for QA effectiveness check.',
    });
    navigate('/');
  };

  const handleSubmitVerification = () => {
    if (!verifyDecision) return;
    if (verifyDecision === 'reopen' && !verifyNotes.trim()) {
      toast.error('Please describe why CAP is being reopened');
      return;
    }
    if (verifyDecision === 'verify') {
      updateAudit(audit.id, {
        status: 'closed',
        currentPhase: 'closed',
        phase: 'closed',
        closureType: 'with_cap',
      });
      toast.success('Audit verified and closed', {
        description: 'CAP confirmed effective. Audit is now archived.',
      });
    } else {
      updateAudit(audit.id, {
        status: 'cap_active',
        currentPhase: 'cap_active',
        phase: 'cap_active',
        reviewNotes: verifyNotes,
      });
      toast.success('CAP reopened', {
        description: 'Audit returned to CAP Active for additional remediation.',
      });
    }
    navigate('/');
  };

  return (
    <AppLayout>
      <div className="p-8 max-w-5xl">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate('/')}
            className="mb-4 gap-2 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>

          <div className="flex items-center gap-4 mb-4">
            <div className="h-14 w-14 rounded-2xl bg-status-pending-bg flex items-center justify-center">
              <Shield className="h-7 w-7 text-status-pending" />
            </div>
            <div>
              <p className="text-sm text-status-pending font-medium uppercase tracking-wide">{headerLabel}</p>
              <h1 className="text-3xl font-bold text-foreground">{audit.title}</h1>
            </div>
          </div>

          <div className="flex items-center gap-3 mb-2">
            <span className={cn(
              'text-xs font-medium uppercase tracking-wider',
              audit.type === 'external' ? 'text-status-pending' : 'text-primary'
            )}>
              {audit.type} Audit
            </span>
            <PriorityBadge priority={audit.priority} />
            <StatusBadge status={audit.status} />
          </div>
          <p className="text-muted-foreground">{audit.description}</p>

          {/* Meta Info */}
          <div className="flex flex-wrap items-center gap-6 mt-4 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <User className="h-4 w-4" />
              <span>Audited by: <strong className="text-foreground">{audit.assignedToName}</strong></span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Building2 className="h-4 w-4" />
              <span>{audit.department}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span>Due: {audit.dueDate}</span>
            </div>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Audit Summary */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Audit Summary</CardTitle>
                <CardDescription>Review the audit findings before closure</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">Actions Completed</p>
                    <p className="text-2xl font-bold text-foreground">
                      {audit.actions.filter(a => a.completed).length}/{audit.actions.length}
                    </p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">Evidence Files</p>
                    <p className="text-2xl font-bold text-foreground">{audit.evidence.length}</p>
                  </div>
                </div>

                {/* Action Items Summary */}
                <div className="space-y-2">
                  <p className="text-sm font-medium text-foreground">Completed Actions:</p>
                  {audit.actions.map((action, index) => (
                    <div 
                      key={action.id}
                      className="flex items-center gap-2 text-sm"
                    >
                      {action.completed ? (
                        <CheckCircle2 className="h-4 w-4 text-status-success" />
                      ) : (
                        <XCircle className="h-4 w-4 text-status-error" />
                      )}
                      <span className={cn(!action.completed && 'text-muted-foreground')}>
                        {action.description}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Evidence */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Evidence Documentation</CardTitle>
              </CardHeader>
              <CardContent>
                {audit.evidence.length > 0 ? (
                  <div className="space-y-2">
                    {audit.evidence.map((file) => (
                      <div 
                        key={file.id}
                        className="flex items-center gap-3 p-3 rounded-lg bg-muted/50"
                      >
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{file.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {file.uploadedBy} • {file.uploadedAt}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No evidence documentation
                  </p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Phase-aware Decision Panel */}
          <div className="space-y-6">
            {/* CLOSED — read only */}
            {isClosed && (
              <Card className="border-border/50 bg-status-success-bg/30">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-status-success" />
                    Audit Closed
                  </CardTitle>
                  <CardDescription>This audit is locked. No further actions can be taken.</CardDescription>
                </CardHeader>
              </Card>
            )}

            {/* CAP ACTIVE — externally managed; only "Mark CAP Complete" available */}
            {isCapActive && (
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-lg">CAP In Progress</CardTitle>
                  <CardDescription>
                    The Corrective Action Plan is being executed in Compliance Connect. When the CAP is
                    complete, mark it here to move the audit to QA verification.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-3 p-4 rounded-lg bg-status-warning-bg/30 border border-status-warning/20">
                    <FileWarning className="h-5 w-5 text-status-warning shrink-0 mt-0.5" />
                    <div className="text-sm">
                      <p className="font-medium text-status-warning">CAP linked externally</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Track CAP progress in Compliance Connect. Marking complete here does not close
                        the audit — it submits it for QA effectiveness verification.
                      </p>
                    </div>
                  </div>
                  <Button
                    className="w-full gap-2 bg-status-pending hover:bg-status-pending/90 text-white"
                    onClick={handleMarkCapComplete}
                  >
                    <Check className="h-4 w-4" />
                    Mark CAP Complete → Pending Verification
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* PENDING VERIFICATION — QA decides verify or reopen */}
            {isPendingVerification && (
              <>
                <Card className="border-border/50">
                  <CardHeader>
                    <CardTitle className="text-lg">QA Verification Decision</CardTitle>
                    <CardDescription>
                      Verify CAP effectiveness or reopen if remediation is insufficient.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <RadioGroup value={verifyDecision} onValueChange={(val) => setVerifyDecision(val as 'verify' | 'reopen')}>
                      <div
                        className={cn(
                          'flex items-center gap-3 p-4 rounded-lg border cursor-pointer transition-all',
                          verifyDecision === 'verify'
                            ? 'border-status-success bg-status-success-bg/50'
                            : 'border-border hover:border-status-success/50'
                        )}
                        onClick={() => setVerifyDecision('verify')}
                      >
                        <RadioGroupItem value="verify" id="verify" />
                        <Label htmlFor="verify" className="flex items-center gap-2 cursor-pointer flex-1">
                          <CheckCircle2 className={cn(
                            'h-5 w-5',
                            verifyDecision === 'verify' ? 'text-status-success' : 'text-muted-foreground'
                          )} />
                          <div>
                            <p className="font-medium">Verify & Close</p>
                            <p className="text-xs text-muted-foreground">CAP effective — close the audit</p>
                          </div>
                        </Label>
                      </div>

                      <div
                        className={cn(
                          'flex items-center gap-3 p-4 rounded-lg border cursor-pointer transition-all',
                          verifyDecision === 'reopen'
                            ? 'border-status-warning bg-status-warning-bg/50'
                            : 'border-border hover:border-status-warning/50'
                        )}
                        onClick={() => setVerifyDecision('reopen')}
                      >
                        <RadioGroupItem value="reopen" id="reopen" />
                        <Label htmlFor="reopen" className="flex items-center gap-2 cursor-pointer flex-1">
                          <FileWarning className={cn(
                            'h-5 w-5',
                            verifyDecision === 'reopen' ? 'text-status-warning' : 'text-muted-foreground'
                          )} />
                          <div>
                            <p className="font-medium">Reopen CAP</p>
                            <p className="text-xs text-muted-foreground">Insufficient — return to CAP Active</p>
                          </div>
                        </Label>
                      </div>
                    </RadioGroup>

                    {verifyDecision === 'reopen' && (
                      <div className="space-y-2 animate-fade-in">
                        <Label htmlFor="verifyNotes">Reason for Reopening (Required)</Label>
                        <Textarea
                          id="verifyNotes"
                          placeholder="Explain what remediation is still needed..."
                          value={verifyNotes}
                          onChange={(e) => setVerifyNotes(e.target.value)}
                          rows={4}
                        />
                      </div>
                    )}

                    <Button
                      className={cn(
                        'w-full gap-2',
                        verifyDecision === 'verify'
                          ? 'bg-status-success hover:bg-status-success/90 text-white'
                          : verifyDecision === 'reopen'
                          ? 'bg-status-warning hover:bg-status-warning/90 text-white'
                          : ''
                      )}
                      disabled={!verifyDecision}
                      onClick={handleSubmitVerification}
                    >
                      {verifyDecision === 'verify' ? (
                        <><Check className="h-4 w-4" /> Verify & Close Audit</>
                      ) : verifyDecision === 'reopen' ? (
                        <><FileWarning className="h-4 w-4" /> Reopen CAP</>
                      ) : (
                        'Select a Decision'
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </>
            )}

            {/* CLOSURE & CAP — original Mark Complete / Initiate CAP decision */}
            {!isClosed && !isCapActive && !isPendingVerification && (
              <>
                <Card className="border-border/50">
                  <CardHeader>
                    <CardTitle className="text-lg">Closure Decision</CardTitle>
                    <CardDescription>Complete or initiate CAP</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <RadioGroup value={decision} onValueChange={(val) => setDecision(val as 'complete' | 'cap')}>
                      <div
                        className={cn(
                          'flex items-center gap-3 p-4 rounded-lg border cursor-pointer transition-all',
                          decision === 'complete'
                            ? 'border-status-success bg-status-success-bg/50'
                            : 'border-border hover:border-status-success/50'
                        )}
                        onClick={() => setDecision('complete')}
                      >
                        <RadioGroupItem value="complete" id="complete" />
                        <Label htmlFor="complete" className="flex items-center gap-2 cursor-pointer flex-1">
                          <CheckCircle2 className={cn(
                            'h-5 w-5',
                            decision === 'complete' ? 'text-status-success' : 'text-muted-foreground'
                          )} />
                          <div>
                            <p className="font-medium">Mark as Complete</p>
                            <p className="text-xs text-muted-foreground">No corrective action needed</p>
                          </div>
                        </Label>
                      </div>

                      <div
                        className={cn(
                          'flex items-center gap-3 p-4 rounded-lg border cursor-pointer transition-all',
                          decision === 'cap'
                            ? 'border-status-warning bg-status-warning-bg/50'
                            : 'border-border hover:border-status-warning/50'
                        )}
                        onClick={() => setDecision('cap')}
                      >
                        <RadioGroupItem value="cap" id="cap" />
                        <Label htmlFor="cap" className="flex items-center gap-2 cursor-pointer flex-1">
                          <FileWarning className={cn(
                            'h-5 w-5',
                            decision === 'cap' ? 'text-status-warning' : 'text-muted-foreground'
                          )} />
                          <div>
                            <p className="font-medium">CAP Required</p>
                            <p className="text-xs text-muted-foreground">Initiate Corrective Action Plan</p>
                          </div>
                        </Label>
                      </div>
                    </RadioGroup>

                    {decision === 'cap' && (
                      <div className="space-y-2 animate-fade-in">
                        <Label htmlFor="capNotes">CAP Details (Required)</Label>
                        <Textarea
                          id="capNotes"
                          placeholder="Describe the corrective actions required..."
                          value={capNotes}
                          onChange={(e) => setCapNotes(e.target.value)}
                          rows={4}
                        />
                      </div>
                    )}

                    <Button
                      className={cn(
                        'w-full gap-2',
                        decision === 'complete'
                          ? 'bg-status-success hover:bg-status-success/90 text-white'
                          : decision === 'cap'
                          ? 'bg-status-warning hover:bg-status-warning/90 text-white'
                          : ''
                      )}
                      disabled={!decision}
                      onClick={handleSubmitClosure}
                    >
                      {decision === 'complete' ? (
                        <><Check className="h-4 w-4" /> Close Audit</>
                      ) : decision === 'cap' ? (
                        <><FileWarning className="h-4 w-4" /> Initiate CAP</>
                      ) : (
                        'Select a Decision'
                      )}
                    </Button>
                  </CardContent>
                </Card>

                {decision === 'cap' && (
                  <Card className="border-border/50 bg-status-warning-bg/30 animate-fade-in">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <AlertTriangle className="h-5 w-5 text-status-warning shrink-0 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium text-status-warning">CAP Workflow</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            The CAP will be routed to Compliance Connect for the responsible department to address.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
