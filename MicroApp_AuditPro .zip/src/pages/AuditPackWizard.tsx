import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { Calendar as CalendarIcon, ChevronRight, ChevronLeft, Check, AlertCircle, FileText, Download, Package, Save, Bookmark, Trash2 } from 'lucide-react';
import { AppLayout } from '@/components/layout/AppLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { useAuditPack } from '@/contexts/AuditPackContext';
import { useAudit } from '@/contexts/AuditContext';
import { AuditPackScope, PreviewData, CrosswalkRow, ScopeTemplate } from '@/types/auditPack';
import { useToast } from '@/hooks/use-toast';
import { generateAuditPackZip, generateReadmePdf, generateCrosswalkPdf } from '@/lib/auditPackGenerator';

type WizardStep = 'scope' | 'preview' | 'generate';

export default function AuditPackWizard() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { currentUser } = useAudit();
  const { controls, policies, departments, locations, generatePreview, generateExport, setCurrentScope, scopeTemplates, saveTemplate, deleteTemplate } = useAuditPack();
  
  const [step, setStep] = useState<WizardStep>('scope');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedExport, setGeneratedExport] = useState<any>(null);
  
  // Scope state
  const [dateRange, setDateRange] = useState<{ start: Date; end: Date }>({
    start: new Date(new Date().getFullYear(), 0, 1),
    end: new Date(),
  });
  const [selectedDepartments, setSelectedDepartments] = useState<string[]>([]);
  const [selectedLocations, setSelectedLocations] = useState<string[]>([]);
  const [selectedControls, setSelectedControls] = useState<string[]>([]);
  const [selectedPolicies, setSelectedPolicies] = useState<string[]>([]);
  const [includeLinks, setIncludeLinks] = useState(true);
  const [includeEvidenceFiles, setIncludeEvidenceFiles] = useState(true);
  const [includePHI, setIncludePHI] = useState(false);

  const [previewData, setPreviewData] = useState<PreviewData | null>(null);

  // Template dialog state
  const [showSaveTemplateDialog, setShowSaveTemplateDialog] = useState(false);
  const [templateName, setTemplateName] = useState('');
  const [templateDescription, setTemplateDescription] = useState('');

  const canEnablePHI = currentUser.role === 'admin';

  const buildScope = (): AuditPackScope => ({
    dateRange,
    departments: selectedDepartments.length > 0 ? selectedDepartments : undefined,
    locations: selectedLocations.length > 0 ? selectedLocations : undefined,
    controls: selectedControls.length > 0 ? selectedControls : undefined,
    policies: selectedPolicies.length > 0 ? selectedPolicies : undefined,
    includeLinks,
    includeEvidenceFiles,
    includePHI,
  });

  const handleNextStep = () => {
    if (step === 'scope') {
      const scope = buildScope();
      const preview = generatePreview(scope);
      setPreviewData(preview);
      setCurrentScope(scope);
      setStep('preview');
    } else if (step === 'preview') {
      setStep('generate');
    }
  };

  const handlePrevStep = () => {
    if (step === 'preview') {
      setStep('scope');
    } else if (step === 'generate') {
      setStep('preview');
    }
  };

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      const scope = buildScope();
      const exportRecord = await generateExport(scope, currentUser.name);
      setGeneratedExport(exportRecord);
      toast({
        title: 'Audit Pack Generated',
        description: `Export ${exportRecord.id} created successfully.`,
      });
    } catch (error) {
      toast({
        title: 'Generation Failed',
        description: 'An error occurred while generating the audit pack.',
        variant: 'destructive',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownloadZip = async () => {
    if (!previewData) return;
    const scope = buildScope();
    await generateAuditPackZip(scope, previewData, generatedExport);
  };

  const handleDownloadReadme = async () => {
    if (!previewData || !generatedExport) return;
    const scope = buildScope();
    await generateReadmePdf(scope, previewData, generatedExport);
  };

  const toggleArrayItem = (arr: string[], item: string, setter: (arr: string[]) => void) => {
    if (arr.includes(item)) {
      setter(arr.filter(i => i !== item));
    } else {
      setter([...arr, item]);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBgColor = (score: number) => {
    if (score >= 80) return 'bg-green-100';
    if (score >= 60) return 'bg-yellow-100';
    return 'bg-red-100';
  };

  const handleLoadTemplate = (template: ScopeTemplate) => {
    if (template.scope.departments) setSelectedDepartments(template.scope.departments);
    if (template.scope.locations) setSelectedLocations(template.scope.locations);
    if (template.scope.controls) setSelectedControls(template.scope.controls);
    if (template.scope.policies) setSelectedPolicies(template.scope.policies);
    setIncludeLinks(template.scope.includeLinks);
    setIncludeEvidenceFiles(template.scope.includeEvidenceFiles);
    setIncludePHI(template.scope.includePHI);
    toast({ title: 'Template Loaded', description: `Applied "${template.name}" settings` });
  };

  const handleSaveTemplate = () => {
    if (!templateName.trim()) {
      toast({ title: 'Error', description: 'Template name is required', variant: 'destructive' });
      return;
    }
    const scopeWithoutDateRange = {
      departments: selectedDepartments.length > 0 ? selectedDepartments : undefined,
      locations: selectedLocations.length > 0 ? selectedLocations : undefined,
      controls: selectedControls.length > 0 ? selectedControls : undefined,
      policies: selectedPolicies.length > 0 ? selectedPolicies : undefined,
      includeLinks,
      includeEvidenceFiles,
      includePHI,
    };
    saveTemplate(templateName, templateDescription, scopeWithoutDateRange, currentUser.name);
    setShowSaveTemplateDialog(false);
    setTemplateName('');
    setTemplateDescription('');
    toast({ title: 'Template Saved', description: `"${templateName}" saved successfully` });
  };

  const handleDownloadCrosswalk = () => {
    if (!previewData) return;
    generateCrosswalkPdf(previewData.crosswalk);
    toast({ title: 'Crosswalk PDF Downloaded' });
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Create Audit Pack</h1>
            <p className="text-muted-foreground mt-1">Generate a HIPAA-compliant audit export package</p>
          </div>
          <Button variant="outline" onClick={() => navigate('/audit-pack')}>
            Cancel
          </Button>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-4 py-4">
          {(['scope', 'preview', 'generate'] as WizardStep[]).map((s, index) => (
            <div key={s} className="flex items-center">
              <div className={cn(
                'flex items-center justify-center w-10 h-10 rounded-full border-2 font-semibold',
                step === s ? 'border-primary bg-primary text-primary-foreground' :
                  (['scope', 'preview', 'generate'].indexOf(step) > index) 
                    ? 'border-primary bg-primary/10 text-primary' 
                    : 'border-muted-foreground/30 text-muted-foreground'
              )}>
                {(['scope', 'preview', 'generate'].indexOf(step) > index) ? (
                  <Check className="h-5 w-5" />
                ) : (
                  index + 1
                )}
              </div>
              <span className={cn(
                'ml-2 font-medium capitalize',
                step === s ? 'text-foreground' : 'text-muted-foreground'
              )}>
                {s}
              </span>
              {index < 2 && (
                <ChevronRight className="h-5 w-5 mx-4 text-muted-foreground/50" />
              )}
            </div>
          ))}
        </div>

        {/* Step Content */}
        {step === 'scope' && (
          <div className="space-y-6">
            {/* Scope Templates */}
            {scopeTemplates.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Bookmark className="h-5 w-5" />
                    Scope Templates
                  </CardTitle>
                  <CardDescription>Load a saved scope configuration to get started quickly</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {scopeTemplates.map((template) => (
                      <div key={template.id} className="flex items-center gap-1">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleLoadTemplate(template)}
                          className="flex items-center gap-2"
                        >
                          <Bookmark className="h-3 w-3" />
                          {template.name}
                        </Button>
                        {template.createdBy !== 'System' && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => {
                              deleteTemplate(template.id);
                              toast({ title: 'Template Deleted' });
                            }}
                          >
                            <Trash2 className="h-3 w-3 text-destructive" />
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle>Define Scope</CardTitle>
                <CardDescription>Select the date range and filters for your audit pack</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Date Range */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">Date Range *</Label>
                  <div className="flex gap-4">
                    <div className="flex-1">
                    <Label className="text-sm text-muted-foreground">Start Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {format(dateRange.start, 'PPP')}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={dateRange.start}
                          onSelect={(date) => date && setDateRange({ ...dateRange, start: date })}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="flex-1">
                    <Label className="text-sm text-muted-foreground">End Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {format(dateRange.end, 'PPP')}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={dateRange.end}
                          onSelect={(date) => date && setDateRange({ ...dateRange, end: date })}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
              </div>

              {/* Filters Grid */}
              <div className="grid md:grid-cols-2 gap-6">
                {/* Departments */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">Departments</Label>
                  <p className="text-sm text-muted-foreground">Leave empty to include all</p>
                  <ScrollArea className="h-32 border rounded-md p-3">
                    {departments.map((dept) => (
                      <div key={dept} className="flex items-center space-x-2 py-1">
                        <Checkbox
                          id={`dept-${dept}`}
                          checked={selectedDepartments.includes(dept)}
                          onCheckedChange={() => toggleArrayItem(selectedDepartments, dept, setSelectedDepartments)}
                        />
                        <label htmlFor={`dept-${dept}`} className="text-sm cursor-pointer">{dept}</label>
                      </div>
                    ))}
                  </ScrollArea>
                </div>

                {/* Locations */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">Locations</Label>
                  <p className="text-sm text-muted-foreground">Leave empty to include all</p>
                  <ScrollArea className="h-32 border rounded-md p-3">
                    {locations.map((loc) => (
                      <div key={loc} className="flex items-center space-x-2 py-1">
                        <Checkbox
                          id={`loc-${loc}`}
                          checked={selectedLocations.includes(loc)}
                          onCheckedChange={() => toggleArrayItem(selectedLocations, loc, setSelectedLocations)}
                        />
                        <label htmlFor={`loc-${loc}`} className="text-sm cursor-pointer">{loc}</label>
                      </div>
                    ))}
                  </ScrollArea>
                </div>

                {/* Controls */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">HIPAA Controls</Label>
                  <p className="text-sm text-muted-foreground">Leave empty to include all</p>
                  <ScrollArea className="h-40 border rounded-md p-3">
                    {controls.map((ctrl) => (
                      <div key={ctrl.id} className="flex items-center space-x-2 py-1">
                        <Checkbox
                          id={`ctrl-${ctrl.id}`}
                          checked={selectedControls.includes(ctrl.id)}
                          onCheckedChange={() => toggleArrayItem(selectedControls, ctrl.id, setSelectedControls)}
                        />
                        <label htmlFor={`ctrl-${ctrl.id}`} className="text-sm cursor-pointer">
                          <span className="font-mono text-xs text-muted-foreground">{ctrl.cite}</span>{' '}
                          {ctrl.title}
                        </label>
                      </div>
                    ))}
                  </ScrollArea>
                </div>

                {/* Policies */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">Policies</Label>
                  <p className="text-sm text-muted-foreground">Leave empty to include all</p>
                  <ScrollArea className="h-40 border rounded-md p-3">
                    {policies.map((pol) => (
                      <div key={pol.id} className="flex items-center space-x-2 py-1">
                        <Checkbox
                          id={`pol-${pol.id}`}
                          checked={selectedPolicies.includes(pol.id)}
                          onCheckedChange={() => toggleArrayItem(selectedPolicies, pol.id, setSelectedPolicies)}
                        />
                        <label htmlFor={`pol-${pol.id}`} className="text-sm cursor-pointer">
                          {pol.title} <span className="text-xs text-muted-foreground">v{pol.version}</span>
                        </label>
                      </div>
                    ))}
                  </ScrollArea>
                </div>
              </div>

              {/* Toggles */}
              <div className="space-y-4 pt-4 border-t">
                <Label className="text-base font-semibold">Export Options</Label>
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="include-links">Include Links</Label>
                    <p className="text-sm text-muted-foreground">Include link-type evidence in the index</p>
                  </div>
                  <Switch id="include-links" checked={includeLinks} onCheckedChange={setIncludeLinks} />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="include-files">Include Evidence Files</Label>
                    <p className="text-sm text-muted-foreground">Bundle file-type evidence in the ZIP</p>
                  </div>
                  <Switch id="include-files" checked={includeEvidenceFiles} onCheckedChange={setIncludeEvidenceFiles} />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="include-phi" className={!canEnablePHI ? 'text-muted-foreground' : ''}>
                      Include PHI Evidence
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      {canEnablePHI 
                        ? 'Include evidence marked as containing PHI (Admin only)' 
                        : 'Only administrators can enable this option'}
                    </p>
                  </div>
                  <Switch 
                    id="include-phi" 
                    checked={includePHI} 
                    onCheckedChange={setIncludePHI}
                    disabled={!canEnablePHI}
                  />
                </div>
              </div>

              <div className="flex justify-between pt-4 gap-4">
                <Dialog open={showSaveTemplateDialog} onOpenChange={setShowSaveTemplateDialog}>
                  <DialogTrigger asChild>
                    <Button variant="outline">
                      <Save className="mr-2 h-4 w-4" />
                      Save as Template
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Save Scope Template</DialogTitle>
                      <DialogDescription>Save the current scope settings for reuse</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="template-name">Template Name *</Label>
                        <Input
                          id="template-name"
                          value={templateName}
                          onChange={(e) => setTemplateName(e.target.value)}
                          placeholder="e.g., Annual HIPAA Audit"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="template-desc">Description</Label>
                        <Textarea
                          id="template-desc"
                          value={templateDescription}
                          onChange={(e) => setTemplateDescription(e.target.value)}
                          placeholder="Brief description of this scope configuration"
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setShowSaveTemplateDialog(false)}>Cancel</Button>
                      <Button onClick={handleSaveTemplate}>Save Template</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
                <Button onClick={handleNextStep}>
                  Continue to Preview
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
          </div>
        )}

        {step === 'preview' && previewData && (
          <div className="space-y-6">
            {/* Readiness Score Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-4">
                  Readiness Score
                  <span className={cn(
                    'text-4xl font-bold px-4 py-2 rounded-lg',
                    getScoreColor(previewData.readinessScore.total),
                    getScoreBgColor(previewData.readinessScore.total)
                  )}>
                    {previewData.readinessScore.total}/100
                  </span>
                </CardTitle>
                <CardDescription>HIPAA compliance readiness based on current evidence and policies</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-4 mb-6">
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <div className="text-2xl font-bold text-primary">{previewData.readinessScore.breakdown.policyCoverage}/30</div>
                    <div className="text-sm text-muted-foreground">Policy Coverage</div>
                  </div>
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <div className="text-2xl font-bold text-primary">{previewData.readinessScore.breakdown.trainingCompletion}/25</div>
                    <div className="text-sm text-muted-foreground">Training Completion</div>
                  </div>
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <div className="text-2xl font-bold text-primary">{previewData.readinessScore.breakdown.evidenceCoverage}/30</div>
                    <div className="text-sm text-muted-foreground">Evidence Coverage</div>
                  </div>
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <div className="text-2xl font-bold text-primary">{previewData.readinessScore.breakdown.penalties}/15</div>
                    <div className="text-sm text-muted-foreground">Quality Score</div>
                  </div>
                </div>

                {previewData.readinessScore.nextActions.length > 0 && (
                  <div className="bg-yellow-50 dark:bg-yellow-950/20 border border-yellow-200 dark:border-yellow-900 rounded-lg p-4">
                    <h4 className="font-semibold text-yellow-800 dark:text-yellow-200 flex items-center gap-2">
                      <AlertCircle className="h-4 w-4" />
                      Recommended Next Actions
                    </h4>
                    <ul className="mt-2 space-y-1">
                      {previewData.readinessScore.nextActions.map((action, i) => (
                        <li key={i} className="text-sm text-yellow-700 dark:text-yellow-300">• {action}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Summary Cards */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Policies</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{previewData.policiesIncluded.length}</div>
                  <p className="text-sm text-muted-foreground">policies included</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Evidence</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{previewData.evidenceSummary.total}</div>
                  <div className="flex gap-2 mt-1">
                    <Badge variant="default" className="bg-green-600">{previewData.evidenceSummary.current} current</Badge>
                    {previewData.evidenceSummary.stale > 0 && (
                      <Badge variant="destructive">{previewData.evidenceSummary.stale} stale</Badge>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Training</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{previewData.trainingSummary.completionPercent}%</div>
                  <Progress value={previewData.trainingSummary.completionPercent} className="mt-2" />
                  {previewData.trainingSummary.overdueCount > 0 && (
                    <p className="text-sm text-destructive mt-1">{previewData.trainingSummary.overdueCount} overdue</p>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Risks & CAPAs</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4">
                    <div>
                      <div className="text-2xl font-bold">{previewData.risksSummary?.open || 0}</div>
                      <p className="text-xs text-muted-foreground">open risks</p>
                    </div>
                    <div>
                      <div className="text-2xl font-bold">{previewData.capasSummary?.inProgress || 0}</div>
                      <p className="text-xs text-muted-foreground">active CAPAs</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Crosswalk Table */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>HIPAA Crosswalk</CardTitle>
                  <CardDescription>Control-to-evidence mapping organized by HIPAA rule and safeguard</CardDescription>
                </div>
                <Button variant="outline" size="sm" onClick={handleDownloadCrosswalk}>
                  <Download className="mr-2 h-4 w-4" />
                  Download PDF
                </Button>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="all">
                  <TabsList>
                    <TabsTrigger value="all">All Controls</TabsTrigger>
                    <TabsTrigger value="privacy">Privacy Rule</TabsTrigger>
                    <TabsTrigger value="security">Security Rule</TabsTrigger>
                    <TabsTrigger value="breach">Breach Notification</TabsTrigger>
                  </TabsList>

                  <TabsContent value="all">
                    <CrosswalkTable rows={previewData.crosswalk} />
                  </TabsContent>
                  <TabsContent value="privacy">
                    <CrosswalkTable rows={previewData.crosswalk.filter(r => r.rule === 'PRIVACY')} />
                  </TabsContent>
                  <TabsContent value="security">
                    <CrosswalkTable rows={previewData.crosswalk.filter(r => r.rule === 'SECURITY')} />
                  </TabsContent>
                  <TabsContent value="breach">
                    <CrosswalkTable rows={previewData.crosswalk.filter(r => r.rule === 'BREACH')} />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* Evidence Gaps */}
            {previewData.evidenceSummary.missingByControl.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-destructive">Evidence Gaps</CardTitle>
                  <CardDescription>Controls missing required evidence types</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Control</TableHead>
                        <TableHead>Missing Evidence Types</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {previewData.evidenceSummary.missingByControl.map((gap) => (
                        <TableRow key={gap.controlCite}>
                          <TableCell>
                            <span className="font-mono text-xs">{gap.controlCite}</span>
                            <br />
                            <span className="text-sm">{gap.controlTitle}</span>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {gap.missing.map(m => (
                                <Badge key={m} variant="outline" className="text-destructive border-destructive">
                                  {m}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            )}

            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={handlePrevStep}>
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back to Scope
              </Button>
              <Button onClick={handleNextStep}>
                Continue to Generate
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        )}

        {step === 'generate' && previewData && (
          <Card>
            <CardHeader>
              <CardTitle>Generate Audit Pack</CardTitle>
              <CardDescription>Create your HIPAA-compliant audit export package</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {!generatedExport ? (
                <>
                  <div className="bg-muted/50 rounded-lg p-6 text-center">
                    <Package className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Ready to Generate</h3>
                    <p className="text-muted-foreground mb-4">
                      Your audit pack will include:
                    </p>
                    <div className="flex flex-wrap justify-center gap-2 mb-6">
                      <Badge>README PDF</Badge>
                      <Badge>Evidence Index</Badge>
                      <Badge>{previewData.policiesIncluded.length} Policies</Badge>
                      <Badge>{previewData.evidenceSummary.total} Evidence Items</Badge>
                      <Badge>Training Report</Badge>
                      <Badge>Export Manifest</Badge>
                    </div>
                    <Button size="lg" onClick={handleGenerate} disabled={isGenerating}>
                      {isGenerating ? (
                        <>
                          <span className="animate-spin mr-2">⏳</span>
                          Generating...
                        </>
                      ) : (
                        <>
                          <Package className="mr-2 h-5 w-5" />
                          Generate Audit Pack
                        </>
                      )}
                    </Button>
                  </div>
                  {isGenerating && (
                    <div className="space-y-2">
                      <Progress value={66} className="animate-pulse" />
                      <p className="text-sm text-center text-muted-foreground">
                        Building export package, computing integrity hash...
                      </p>
                    </div>
                  )}
                </>
              ) : (
                <div className="space-y-6">
                  <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-900 rounded-lg p-6 text-center">
                    <Check className="h-12 w-12 mx-auto text-green-600 mb-4" />
                    <h3 className="text-lg font-semibold text-green-800 dark:text-green-200 mb-2">
                      Audit Pack Generated Successfully
                    </h3>
                    <p className="text-green-700 dark:text-green-300 mb-4">
                      Export ID: <span className="font-mono">{generatedExport.id}</span>
                    </p>
                  </div>

                  <div className="bg-muted/50 rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Export Details</h4>
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Created:</span>{' '}
                        {format(generatedExport.createdAt, 'PPp')}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Created By:</span>{' '}
                        {generatedExport.createdBy}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Readiness Score:</span>{' '}
                        <span className={getScoreColor(generatedExport.readinessScore)}>
                          {generatedExport.readinessScore}/100
                        </span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Date Range:</span>{' '}
                        {generatedExport.scopeLabel}
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t">
                      <span className="text-muted-foreground text-sm">ZIP SHA-256:</span>
                      <p className="font-mono text-xs break-all bg-background p-2 rounded mt-1">
                        {generatedExport.zipSha256}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-4 justify-center">
                    <Button onClick={handleDownloadReadme}>
                      <FileText className="mr-2 h-4 w-4" />
                      Download README PDF
                    </Button>
                    <Button onClick={handleDownloadZip}>
                      <Download className="mr-2 h-4 w-4" />
                      Download ZIP Bundle
                    </Button>
                    <Button variant="outline" onClick={() => navigate('/audit-pack/history')}>
                      View Export History
                    </Button>
                  </div>
                </div>
              )}

              {!generatedExport && (
                <div className="flex justify-between pt-4 border-t">
                  <Button variant="outline" onClick={handlePrevStep}>
                    <ChevronLeft className="mr-2 h-4 w-4" />
                    Back to Preview
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </AppLayout>
  );
}

function CrosswalkTable({ rows }: { rows: CrosswalkRow[] }) {
  if (rows.length === 0) {
    return <p className="text-muted-foreground text-center py-8">No controls in this category</p>;
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Rule</TableHead>
          <TableHead>Safeguard</TableHead>
          <TableHead>Control</TableHead>
          <TableHead>Policies</TableHead>
          <TableHead>Evidence</TableHead>
          <TableHead>Training</TableHead>
          <TableHead>Gaps</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {rows.map((row) => (
          <TableRow key={row.controlCite}>
            <TableCell>
              <Badge variant="outline">{row.rule}</Badge>
            </TableCell>
            <TableCell>
              {row.safeguard ? (
                <Badge variant="secondary">{row.safeguard}</Badge>
              ) : (
                <span className="text-muted-foreground">—</span>
              )}
            </TableCell>
            <TableCell>
              <span className="font-mono text-xs">{row.controlCite}</span>
              <br />
              <span className="text-sm">{row.controlTitle}</span>
            </TableCell>
            <TableCell>
              {row.policies.length > 0 ? (
                <div className="text-sm">{row.policies.join(', ')}</div>
              ) : (
                <span className="text-destructive text-sm">None</span>
              )}
            </TableCell>
            <TableCell>
              <div className="flex gap-1">
                <Badge variant="default" className="bg-green-600">{row.currentEvidenceCount}</Badge>
                {row.staleEvidenceCount > 0 && (
                  <Badge variant="destructive">{row.staleEvidenceCount}</Badge>
                )}
              </div>
            </TableCell>
            <TableCell>
              <span className={row.trainingCompletion < 100 ? 'text-yellow-600' : 'text-green-600'}>
                {row.trainingCompletion}%
              </span>
            </TableCell>
            <TableCell>
              {row.gaps.length > 0 ? (
                <div className="flex flex-wrap gap-1">
                  {row.gaps.slice(0, 2).map((gap, i) => (
                    <Badge key={i} variant="outline" className="text-destructive border-destructive text-xs">
                      {gap}
                    </Badge>
                  ))}
                  {row.gaps.length > 2 && (
                    <Badge variant="outline" className="text-muted-foreground">
                      +{row.gaps.length - 2}
                    </Badge>
                  )}
                </div>
              ) : (
                <Check className="h-4 w-4 text-green-600" />
              )}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
