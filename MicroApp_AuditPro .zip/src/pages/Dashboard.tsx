import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAudit } from '@/contexts/AuditContext';
import { usePermissions } from '@/hooks/usePermissions';
import { AppLayout } from '@/components/layout/AppLayout';
import { AuditSection } from '@/components/audit/AuditSection';
import { DashboardMetrics } from '@/components/dashboard/DashboardMetrics';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { 
  Plus, 
  ClipboardList, 
  Eye, 
  Building2,
  History,
  FileSearch,
  Lock,
  Globe,
  User
} from 'lucide-react';

type ViewScope = 'organization' | 'department' | 'personal';

export default function Dashboard() {
  const navigate = useNavigate();
  const { 
    currentUser, 
    audits, 
    getDepartmentAudits, 
    getAuditHistory,
    getPreAuditItems,
    getPreAuditReviewItems
  } = useAudit();
  const permissions = usePermissions();
  
  const [activeTab, setActiveTab] = useState<string>('pre-audit');
  
  // Role-based view scope
  const isOrgLevel = currentUser.role === 'compliance_head' || currentUser.role === 'admin';
  const isDepartmentHead = currentUser.role === 'department_head';
  const showToggle = isOrgLevel || isDepartmentHead;
  
  const defaultScope: ViewScope = isOrgLevel ? 'organization' : isDepartmentHead ? 'department' : 'personal';
  const [viewScope, setViewScope] = useState<ViewScope>(defaultScope);

  // Helper to check if user is assigned to any phase
  const isUserAssignedToAudit = (audit: typeof audits[0]) => {
    if (!audit.phaseAssignees) return false;
    return Object.values(audit.phaseAssignees).includes(currentUser.id);
  };

  // Filter audits based on view scope
  const filterByScope = (auditList: typeof audits) => {
    switch (viewScope) {
      case 'organization':
        // Org-level users see ALL audits across all departments
        return auditList;
      case 'department':
        // Department view shows only user's department audits
        return auditList.filter(a => a.department === currentUser.department);
      case 'personal':
        // Personal view shows only audits where user is assigned or created
        return auditList.filter(a => 
          isUserAssignedToAudit(a) || 
          a.assignedTo === currentUser.id || 
          a.createdBy === currentUser.id
        );
      default:
        return auditList;
    }
  };

  // Get all pre-audit items (unfiltered by department for org-level)
  const getAllPreAuditItems = () => audits.filter(a => a.status === 'pre_audit');
  const getAllPreAuditReviewItems = () => audits.filter(a => a.status === 'pre_audit_review');
  
  // Get all to-do items (unfiltered by department for org-level)
  const getAllToDoItems = () => audits.filter(a => 
    ['draft', 'overview', 'evaluation', 'internal_review', 'remediation_required', 'cap_active', 'pending_verification'].includes(a.status)
  );
  
  // Get all history items (unfiltered by department for org-level)
  const getAllHistoryItems = () => audits.filter(a => a.status === 'closed');

  // Apply scope filtering
  const basePreAuditItems = isOrgLevel ? getAllPreAuditItems() : getPreAuditItems();
  const basePreAuditReviewItems = isOrgLevel ? getAllPreAuditReviewItems() : getPreAuditReviewItems();
  const baseToDoItems = isOrgLevel ? getAllToDoItems() : getDepartmentAudits().filter(a => 
    ['draft', 'overview', 'evaluation', 'internal_review', 'remediation_required', 'cap_active', 'pending_verification'].includes(a.status)
  );
  const baseHistoryItems = isOrgLevel ? getAllHistoryItems() : getAuditHistory();

  // Apply view scope filter
  const preAuditItems = filterByScope(basePreAuditItems);
  const preAuditReviewItems = filterByScope(basePreAuditReviewItems);
  const toDoItems = filterByScope(baseToDoItems);
  const historyItems = filterByScope(baseHistoryItems);

  const roleLabels = {
    staff: 'Staff (Read-only)',
    department_head: 'Department Head',
    compliance_head: 'Compliance Head',
    admin: 'Administrator',
  };

  const handleViewChange = (value: string) => {
    if (value) {
      setViewScope(value as ViewScope);
    }
  };

  const handleAuditClick = (auditId: string, section: 'pre-audit' | 'pre-audit-review' | 'todo' | 'review' | 'history') => {
    const audit = audits.find(a => a.id === auditId);
    
    if (section === 'review') {
      navigate(`/review/${auditId}`);
    } else if (section === 'pre-audit-review') {
      navigate(`/audit/${auditId}/phase/pre_audit?review=true`);
    } else if (section === 'history') {
      navigate(`/audit/${auditId}/phase/${audit?.currentPhase || 'overview'}`);
    } else {
      const phase = audit?.currentPhase || 'pre_audit';
      navigate(`/audit/${auditId}/phase/${phase}`);
    }
  };

  return (
    <AppLayout>
      <div className="p-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard</h1>
              <div className="flex items-center gap-3 text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <Building2 className="h-4 w-4" />
                  {currentUser.department}
                </span>
                <span>•</span>
                <span>{roleLabels[currentUser.role]}</span>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              {showToggle && (
                <ToggleGroup 
                  type="single" 
                  value={viewScope} 
                  onValueChange={handleViewChange}
                  className="bg-muted/50 p-1 rounded-lg"
                >
                  {isOrgLevel ? (
                    <ToggleGroupItem 
                      value="organization" 
                      aria-label="Organization view"
                      className="gap-2 data-[state=on]:bg-background data-[state=on]:shadow-sm"
                    >
                      <Globe className="h-4 w-4" />
                      Organization
                    </ToggleGroupItem>
                  ) : (
                    <ToggleGroupItem 
                      value="department" 
                      aria-label="Department view"
                      className="gap-2 data-[state=on]:bg-background data-[state=on]:shadow-sm"
                    >
                      <Building2 className="h-4 w-4" />
                      Department
                    </ToggleGroupItem>
                  )}
                  <ToggleGroupItem 
                    value="personal" 
                    aria-label="Personal view"
                    className="gap-2 data-[state=on]:bg-background data-[state=on]:shadow-sm"
                  >
                    <User className="h-4 w-4" />
                    Personal
                  </ToggleGroupItem>
                </ToggleGroup>
              )}
              
              {permissions.canCreateAudit ? (
                <Button 
                  onClick={() => navigate('/new-audit')}
                  className="gradient-primary hover:opacity-90 text-primary-foreground gap-2"
                >
                  <Plus className="h-4 w-4" />
                  New Pre-Audit Item
                </Button>
              ) : (
                <Badge variant="secondary" className="gap-2 py-2 px-3">
                  <Lock className="h-3 w-3" />
                  Read-only Access
                </Badge>
              )}
            </div>
          </div>
        </div>

        {/* Metrics Section */}
        <DashboardMetrics view={viewScope === 'personal' ? 'personal' : 'department'} />

        {/* Tabbed Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-6 bg-muted/50 p-1">
            <TabsTrigger value="pre-audit" className="gap-2 data-[state=active]:bg-background">
              <FileSearch className="h-4 w-4" />
              Pre-Audit
              <span className="ml-1 inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full bg-status-pending-bg text-status-pending text-xs font-medium">
                {preAuditItems.length + preAuditReviewItems.length}
              </span>
            </TabsTrigger>
            <TabsTrigger value="todo" className="gap-2 data-[state=active]:bg-background">
              <ClipboardList className="h-4 w-4" />
              To Do
              <span className="ml-1 inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full bg-status-info-bg text-status-info text-xs font-medium">
                {toDoItems.length}
              </span>
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-2 data-[state=active]:bg-background">
              <History className="h-4 w-4" />
              History
              <span className="ml-1 inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full bg-muted text-muted-foreground text-xs font-medium">
                {historyItems.length}
              </span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pre-audit" className="mt-0 space-y-6">
            <AuditSection
              title="Pre-Audit Preparation"
              subtitle="Items being prepared for audit"
              items={preAuditItems}
              onAuditClick={(audit) => handleAuditClick(audit.id, 'pre-audit')}
              emptyMessage="No items in pre-audit preparation"
              icon={<div className="h-10 w-10 rounded-xl bg-status-pending-bg flex items-center justify-center">
                <FileSearch className="h-5 w-5 text-status-pending" />
              </div>}
            />
            {preAuditReviewItems.length > 0 && (
              <AuditSection
                title="Pre-Audit Review"
                subtitle="Items awaiting review before starting audit lifecycle"
                items={preAuditReviewItems}
                onAuditClick={(audit) => handleAuditClick(audit.id, 'pre-audit-review')}
                emptyMessage="No items pending pre-audit review"
                icon={<div className="h-10 w-10 rounded-xl bg-status-warning-bg flex items-center justify-center">
                  <Eye className="h-5 w-5 text-status-warning" />
                </div>}
              />
            )}
          </TabsContent>

          <TabsContent value="todo" className="mt-0">
            <AuditSection
              title="Action Required"
              subtitle="Audit items requiring department action"
              items={toDoItems}
              onAuditClick={(audit) => handleAuditClick(audit.id, 'todo')}
              emptyMessage="No pending action items"
              icon={<div className="h-10 w-10 rounded-xl bg-status-info-bg flex items-center justify-center">
                <ClipboardList className="h-5 w-5 text-status-info" />
              </div>}
            />
          </TabsContent>

          <TabsContent value="history" className="mt-0">
            <AuditSection
              title="Audit History"
              subtitle="Past audits touched by your department"
              items={historyItems}
              onAuditClick={(audit) => handleAuditClick(audit.id, 'history')}
              emptyMessage="No audit history yet"
              icon={<div className="h-10 w-10 rounded-xl bg-muted flex items-center justify-center">
                <History className="h-5 w-5 text-muted-foreground" />
              </div>}
            />
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}