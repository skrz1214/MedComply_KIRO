import { useState, useRef } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useAudit } from '@/contexts/AuditContext';
import { usePermissions } from '@/hooks/usePermissions';
import { AppLayout } from '@/components/layout/AppLayout';
import { StatusBadge } from '@/components/audit/StatusBadge';
import { PriorityBadge } from '@/components/audit/PriorityBadge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PHASE_LABELS, PERIODICITY_LABELS } from '@/types/audit';
import { 
  ArrowLeft, 
  Calendar, 
  User, 
  Building2, 
  FileText, 
  Check,
  X,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Repeat,
  Upload,
  History,
  UserPlus,
  Lock
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const DEPARTMENTS = [
  'Nursing',
  'Quality Assurance',
  'Administration',
  'Laboratory',
  'Pharmacy',
  'Radiology',
];

export default function ScheduledReview() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { audits, approveAudit, rejectAudit, currentUser, users, updateAudit, addHistoryEntry, addPhaseAttachment } = useAudit();
  const permissions = usePermissions();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const source = searchParams.get('source') || 'personal';
  const audit = audits.find(a => a.id === id);
  const [decision, setDecision] = useState<'approve' | 'reject' | ''>('');
  const [reviewNotes, setReviewNotes] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState<string>('');
  const [selectedUserId, setSelectedUserId] = useState<string>('');

  // Staff users cannot perform reviews
  const canReview = permissions.canApproveReview || permissions.canRejectReview;

  const handleBack = () => {
    navigate(`/?view=${source}`);
  };

  if (!audit) {
    return (
      <AppLayout>
        <div className="p-8 flex items-center justify-center h-full">
          <div className="text-center">
            <h2 className="text-xl font-semibold mb-2">Audit Not Found</h2>
            <p className="text-muted-foreground mb-4">The audit item you're looking for doesn't exist.</p>
            <Button onClick={handleBack}>Return to Dashboard</Button>
          </div>
        </div>
      </AppLayout>
    );
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const newEvidence = {
      id: Date.now().toString(),
      name: file.name,
      type: file.type,
      uploadedAt: new Date().toISOString().split('T')[0],
      uploadedBy: currentUser.name,
      url: '#',
    };

    addPhaseAttachment(audit.id, audit.currentPhase, newEvidence);

    toast.success('Review attachment uploaded', {
      description: `${file.name} has been attached to this review.`,
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Filter users by selected department
  const filteredUsers = selectedDepartment 
    ? users.filter(u => u.department === selectedDepartment)
    : users;
  
  const selectedUser = users.find(u => u.id === selectedUserId);

  const handleSubmitReview = () => {
    // Validate department is selected
    if (!selectedDepartment) {
      toast.error('Department Required', {
        description: 'Please select a department before submitting.',
      });
      return;
    }

    if (decision === 'approve') {
      // Update audit with selected department/user
      updateAudit(audit.id, {
        department: selectedDepartment,
        ...(selectedUserId && { 
          assignedTo: selectedUserId, 
          assignedToName: selectedUser?.name || audit.assignedToName 
        }),
      });
      approveAudit(audit.id);
      addHistoryEntry(audit.id, {
        action: selectedUser 
          ? `Approved and assigned to ${selectedUser.name} (${selectedDepartment})`
          : `Approved and assigned to ${selectedDepartment}`,
        phase: audit.currentPhase,
        performedBy: currentUser.name,
        notes: reviewNotes || undefined,
      });
      toast.success('Audit Approved', {
        description: selectedUser 
          ? `Assigned to ${selectedUser.name} for audit.`
          : `Assigned to ${selectedDepartment} department for audit.`,
      });
    } else if (decision === 'reject') {
      if (!reviewNotes.trim()) {
        toast.error('Please provide feedback', {
          description: 'You must provide notes explaining why the review failed.',
        });
        return;
      }
      // Update audit with selected department/user
      updateAudit(audit.id, {
        department: selectedDepartment,
        ...(selectedUserId && { 
          assignedTo: selectedUserId, 
          assignedToName: selectedUser?.name || audit.assignedToName 
        }),
      });
      rejectAudit(audit.id, reviewNotes);
      addHistoryEntry(audit.id, {
        action: selectedUser 
          ? `Review failed - returned to ${selectedUser.name}`
          : `Review failed - returned to ${selectedDepartment}`,
        phase: audit.currentPhase,
        performedBy: currentUser.name,
        notes: reviewNotes,
      });
      toast.success('Review Returned', {
        description: selectedUser 
          ? `Sent back to ${selectedUser.name} with your feedback.`
          : `Sent back to ${selectedDepartment} department with your feedback.`,
      });
    }
    handleBack();
  };

  const completedActions = audit.actions.filter(a => a.completed).length;
  const totalActions = audit.actions.length;
  const allEvidence = Object.values(audit.phaseAttachments || {}).flat();

  return (
    <AppLayout>
      <div className="p-8 max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={handleBack}
            className="mb-4 gap-2 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to {source === 'department' ? 'Department' : 'My'} Dashboard
          </Button>

          <div className="flex items-center gap-4 mb-4">
            <div className="h-14 w-14 rounded-2xl bg-status-warning-bg flex items-center justify-center">
              <AlertTriangle className="h-7 w-7 text-status-warning" />
            </div>
            <div>
              <p className="text-sm text-status-warning font-medium uppercase tracking-wide">Scheduled Review</p>
              <h1 className="text-3xl font-bold text-foreground">{audit.title}</h1>
            </div>
          </div>

          <div className="flex items-center gap-3 mb-2">
            <span className={cn(
              'text-xs font-medium uppercase tracking-wider',
              audit.type === 'external' ? 'text-status-pending' : 'text-primary'
            )}>
              {audit.type} Audit
            </span>
            <PriorityBadge priority={audit.priority} />
            <StatusBadge status={audit.status} />
            {audit.isPeriodic && (
              <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium">
                <Repeat className="h-3 w-3" />
                {PERIODICITY_LABELS[audit.periodicity!]}
              </span>
            )}
          </div>
          <p className="text-muted-foreground">{audit.description}</p>

          {/* Meta Info */}
          <div className="flex flex-wrap items-center gap-6 mt-4 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <User className="h-4 w-4" />
              <span>Submitted by: <strong className="text-foreground">{audit.assignedToName}</strong></span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Building2 className="h-4 w-4" />
              <span>{audit.department}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span>Due: {audit.dueDate}</span>
            </div>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Status Summary */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Status Summary</CardTitle>
                <CardDescription>Review completed statuses and progress</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="p-4 rounded-lg bg-status-success-bg/50">
                    <p className="text-sm text-muted-foreground mb-1">Actions Completed</p>
                    <p className="text-2xl font-bold text-status-success">{completedActions}/{totalActions}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">Evidence Files</p>
                    <p className="text-2xl font-bold text-foreground">{allEvidence.length}</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm font-medium text-foreground mb-3">Current Status: {PHASE_LABELS[audit.currentPhase]}</p>
                  {audit.actions.map((action, index) => (
                    <div 
                      key={action.id}
                      className={cn(
                        'flex items-start gap-3 p-3 rounded-lg border',
                        action.completed 
                          ? 'bg-status-success-bg/50 border-status-success/30' 
                          : 'bg-status-error-bg/50 border-status-error/30'
                      )}
                    >
                      {action.completed ? (
                        <CheckCircle2 className="h-5 w-5 text-status-success shrink-0 mt-0.5" />
                      ) : (
                        <XCircle className="h-5 w-5 text-status-error shrink-0 mt-0.5" />
                      )}
                      <div className="flex-1">
                        <p className="text-sm">{index + 1}. {action.description}</p>
                        {action.completed && action.completedBy && (
                          <p className="text-xs text-muted-foreground mt-1">
                            Completed by {action.completedBy}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Evidence by Status */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Evidence Documentation</CardTitle>
                <CardDescription>All attachments across statuses</CardDescription>
              </CardHeader>
              <CardContent>
                {allEvidence.length > 0 ? (
                  <div className="space-y-2">
                    {allEvidence.map((file) => (
                      <div 
                        key={file.id}
                        className="flex items-center gap-3 p-3 rounded-lg bg-muted/50"
                      >
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{file.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {file.uploadedBy} • {file.uploadedAt}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No evidence was submitted
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Audit History */}
            {audit.history && audit.history.length > 0 && (
              <Card className="border-border/50">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <History className="h-5 w-5 text-muted-foreground" />
                    <CardTitle className="text-lg">Audit History</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {audit.history.slice().reverse().map((entry) => (
                      <div key={entry.id} className="flex items-start gap-3 p-3 rounded-lg bg-muted/30">
                        <div className="h-2 w-2 rounded-full bg-primary mt-2" />
                        <div className="flex-1">
                          <p className="text-sm font-medium">{entry.action}</p>
                          <p className="text-xs text-muted-foreground">
                            {entry.performedBy} • {new Date(entry.performedAt).toLocaleDateString()}
                          </p>
                          {entry.notes && (
                            <p className="text-xs text-muted-foreground mt-1 italic">"{entry.notes}"</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Review Decision */}
          <div className="space-y-6">
            {/* Upload Review Attachment */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Review Attachments</CardTitle>
                <CardDescription>Add review documentation</CardDescription>
              </CardHeader>
              <CardContent>
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  onChange={handleFileUpload}
                />
                <Button
                  variant="outline"
                  className="w-full gap-2"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="h-4 w-4" />
                  Upload Attachment
                </Button>
              </CardContent>
            </Card>

            {(() => {
              // Phase-aware next action. Only `pre_audit_review` and `internal_review`
              // are true "review decision" phases. Every other phase has its own
              // next step and should NOT show the Approve/Reject card.
              const phase = audit.currentPhase;

              type NextAction = {
                title: string;
                description: string;
                primaryLabel: string;
                primaryRoute?: string;
                tone: 'review' | 'forward' | 'locked';
                hint?: string;
              };

              const NEXT_ACTION_BY_PHASE: Record<typeof phase, NextAction> = {
                draft: {
                  title: 'Next: Start Pre-Audit',
                  description: 'This audit is still a draft. Open the audit to begin pre-audit preparation.',
                  primaryLabel: 'Open Pre-Audit',
                  primaryRoute: `/audit/${audit.id}`,
                  tone: 'forward',
                },
                pre_audit: {
                  title: 'Next: Submit Pre-Audit for Review',
                  description: 'Pre-audit preparation is in progress. Submit it from the audit page when ready.',
                  primaryLabel: 'Open Pre-Audit',
                  primaryRoute: `/audit/${audit.id}`,
                  tone: 'forward',
                },
                pre_audit_review: {
                  title: 'Pre-Audit Review Decision',
                  description: 'Approve to start the audit, or return for pre-audit corrections.',
                  primaryLabel: 'Approve Pre-Audit',
                  tone: 'review',
                },
                overview: {
                  title: 'Next: Begin Evidence Collection',
                  description: 'The audit has been approved. Continue from the audit page.',
                  primaryLabel: 'Open Audit',
                  primaryRoute: `/audit/${audit.id}`,
                  tone: 'forward',
                },
                evidence_collection: {
                  title: 'Next: Complete Evidence Collection',
                  description: 'Upload required evidence from the audit page, then move to evaluation.',
                  primaryLabel: 'Open Audit',
                  primaryRoute: `/audit/${audit.id}`,
                  tone: 'forward',
                },
                evaluation: {
                  title: 'Next: Submit for Internal Review',
                  description: 'Finish evaluation and submit for internal review from the audit page.',
                  primaryLabel: 'Open Audit',
                  primaryRoute: `/audit/${audit.id}`,
                  tone: 'forward',
                },
                internal_review: {
                  title: 'Internal Review Decision',
                  description: 'Approve to move to closure, or return for remediation.',
                  primaryLabel: 'Approve Audit',
                  tone: 'review',
                },
                remediation_required: {
                  title: 'Next: Resubmit After Remediation',
                  description: 'Address feedback and resubmit from the closure page.',
                  primaryLabel: 'Open Closure',
                  primaryRoute: `/closure/${audit.id}`,
                  tone: 'forward',
                },
                closure_cap: {
                  title: 'Next: Closure Decision',
                  description: 'Decide to close with or without a CAP from the closure page.',
                  primaryLabel: 'Open Closure',
                  primaryRoute: `/closure/${audit.id}`,
                  tone: 'forward',
                },
                cap_active: {
                  title: 'Next: CAP In Progress',
                  description: 'CAP is being executed externally. Track progress on the closure page.',
                  primaryLabel: 'Open Closure',
                  primaryRoute: `/closure/${audit.id}`,
                  tone: 'forward',
                },
                pending_verification: {
                  title: 'Next: Verify CAP Completion',
                  description: 'CAP is complete and awaiting QA verification on the closure page.',
                  primaryLabel: 'Open Closure',
                  primaryRoute: `/closure/${audit.id}`,
                  tone: 'forward',
                },
                closed: {
                  title: 'Audit Closed',
                  description: 'This audit is closed. No further actions can be taken.',
                  primaryLabel: 'View Audit',
                  primaryRoute: `/audit/${audit.id}`,
                  tone: 'locked',
                },
              };

              const next = NEXT_ACTION_BY_PHASE[phase];

              // Locked / forward-only phases: show a clear card pointing to the right place.
              if (next.tone !== 'review') {
                const Icon = next.tone === 'locked' ? Lock : ArrowLeft;
                return (
                  <Card className="border-border/50">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        {next.tone === 'locked' ? (
                          <Lock className="h-5 w-5 text-muted-foreground" />
                        ) : (
                          <CheckCircle2 className="h-5 w-5 text-primary" />
                        )}
                        {next.title}
                      </CardTitle>
                      <CardDescription>{next.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="mb-4 p-3 rounded-lg bg-muted/40 border border-border/50">
                        <p className="text-xs text-muted-foreground mb-1">Current Status</p>
                        <p className="text-sm font-medium text-foreground">{PHASE_LABELS[phase]}</p>
                      </div>
                      {next.tone !== 'locked' ? (
                        <Button
                          className="w-full gap-2"
                          onClick={() => next.primaryRoute && navigate(next.primaryRoute)}
                        >
                          {next.primaryLabel}
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          className="w-full gap-2"
                          onClick={() => next.primaryRoute && navigate(next.primaryRoute)}
                        >
                          {next.primaryLabel}
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                );
              }

              // Review phases: show the Approve / Reject decision card.
              return (
                <Card className="border-border/50">
                  <CardHeader>
                    <CardTitle className="text-lg">{next.title}</CardTitle>
                    <CardDescription>{next.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                <RadioGroup value={decision} onValueChange={(val) => setDecision(val as 'approve' | 'reject')}>
                  <div 
                    className={cn(
                      'flex items-center gap-3 p-4 rounded-lg border cursor-pointer transition-all',
                      decision === 'approve' 
                        ? 'border-status-success bg-status-success-bg/50' 
                        : 'border-border hover:border-status-success/50'
                    )}
                    onClick={() => setDecision('approve')}
                  >
                    <RadioGroupItem value="approve" id="approve" />
                    <Label htmlFor="approve" className="flex items-center gap-2 cursor-pointer flex-1">
                      <CheckCircle2 className={cn(
                        'h-5 w-5',
                        decision === 'approve' ? 'text-status-success' : 'text-muted-foreground'
                      )} />
                      <div>
                        <p className="font-medium">{phase === 'pre_audit_review' ? 'Approve Pre-Audit' : 'Ready for Closure'}</p>
                        <p className="text-xs text-muted-foreground">Approve and proceed</p>
                      </div>
                    </Label>
                  </div>

                  <div 
                    className={cn(
                      'flex items-center gap-3 p-4 rounded-lg border cursor-pointer transition-all',
                      decision === 'reject' 
                        ? 'border-status-error bg-status-error-bg/50' 
                        : 'border-border hover:border-status-error/50'
                    )}
                    onClick={() => setDecision('reject')}
                  >
                    <RadioGroupItem value="reject" id="reject" />
                    <Label htmlFor="reject" className="flex items-center gap-2 cursor-pointer flex-1">
                      <XCircle className={cn(
                        'h-5 w-5',
                        decision === 'reject' ? 'text-status-error' : 'text-muted-foreground'
                      )} />
                      <div>
                        <p className="font-medium">Return for Corrections</p>
                        <p className="text-xs text-muted-foreground">Send back with feedback</p>
                      </div>
                    </Label>
                  </div>
                </RadioGroup>

                {/* Department and User Selection - shown when decision is made */}
                {decision && (
                  <div className="space-y-4 animate-fade-in p-4 rounded-lg bg-muted/30 border border-border/50">
                    <div className="flex items-center gap-2 text-sm font-medium text-foreground">
                      <UserPlus className="h-4 w-4" />
                      <span>Assign To</span>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="space-y-2">
                        <Label className="text-xs text-muted-foreground">
                          Department <span className="text-status-error">*</span>
                        </Label>
                        <Select value={selectedDepartment} onValueChange={(val) => {
                          setSelectedDepartment(val);
                          setSelectedUserId(''); // Reset user when department changes
                        }}>
                          <SelectTrigger className={!selectedDepartment && decision ? 'border-status-error/50' : ''}>
                            <SelectValue placeholder="Select department (required)" />
                          </SelectTrigger>
                          <SelectContent>
                            {DEPARTMENTS.map(dept => (
                              <SelectItem key={dept} value={dept}>
                                {dept}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label className="text-xs text-muted-foreground">User (Optional)</Label>
                        <Select value={selectedUserId} onValueChange={setSelectedUserId} disabled={!selectedDepartment}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select user (optional)" />
                          </SelectTrigger>
                          <SelectContent>
                            {filteredUsers.map(user => (
                              <SelectItem key={user.id} value={user.id}>
                                {user.name} ({user.department})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      {selectedUser && (
                        <div className="flex items-center gap-2 p-2 rounded bg-primary/5 border border-primary/20 text-sm">
                          <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center text-xs font-semibold text-primary">
                            {selectedUser.name.charAt(0)}
                          </div>
                          <span className="text-foreground">{selectedUser.name}</span>
                          <span className="text-muted-foreground">({selectedUser.department})</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {decision === 'reject' && (
                  <div className="space-y-2 animate-fade-in">
                    <Label htmlFor="notes">Feedback Notes (Required)</Label>
                    <Textarea
                      id="notes"
                      placeholder="Explain what needs to be corrected..."
                      value={reviewNotes}
                      onChange={(e) => setReviewNotes(e.target.value)}
                      rows={4}
                    />
                  </div>
                )}

                {decision === 'approve' && (
                  <div className="space-y-2 animate-fade-in">
                    <Label htmlFor="notes">Review Notes (Optional)</Label>
                    <Textarea
                      id="notes"
                      placeholder="Add any additional notes..."
                      value={reviewNotes}
                      onChange={(e) => setReviewNotes(e.target.value)}
                      rows={3}
                    />
                  </div>
                )}

                <Button
                  className={cn(
                    'w-full gap-2',
                    decision === 'approve' 
                      ? 'bg-status-success hover:bg-status-success/90 text-white' 
                      : decision === 'reject'
                      ? 'bg-status-error hover:bg-status-error/90 text-white'
                      : ''
                  )}
                  disabled={!decision}
                  onClick={handleSubmitReview}
                >
                  {decision === 'approve' ? (
                    <>
                      <Check className="h-4 w-4" />
                      {next.primaryLabel}
                    </>
                  ) : decision === 'reject' ? (
                    <>
                      <X className="h-4 w-4" />
                      Return for Corrections
                    </>
                  ) : (
                    'Select a Decision'
                  )}
                </Button>
                  </CardContent>
                </Card>
              );
            })()}

            {/* Routing Info */}
            {audit.currentPhase === 'internal_review' && decision === 'approve' && (
              <Card className="border-border/50 bg-status-info-bg/30 animate-fade-in">
                <CardContent className="p-4">
                  <p className="text-sm text-status-info">
                    {audit.type === 'external' 
                      ? '→ Will be routed to Quality Assurance for final review'
                      : '→ Will move to Closure & CAP'}
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}