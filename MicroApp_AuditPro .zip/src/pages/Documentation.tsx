import { useState, useEffect } from 'react';
import { AppLayout } from '@/components/layout/AppLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { FileText, Download, BookOpen, TestTube, ClipboardCheck, Bot, Layers } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { StatusReference } from '@/components/docs/StatusReference';

interface Document {
  id: string;
  title: string;
  description: string;
  filename: string;
  path: string;
  icon: React.ReactNode;
  version: string;
  pdfPath?: string;
  pdfFilename?: string;
}

const documents: Document[] = [
  {
    id: 'prd',
    title: 'Product Requirements Document',
    description: 'Complete product specification, features, and requirements for AuditPro',
    filename: 'AuditPro-PRD.md',
    path: '/docs/PRD.md',
    icon: <BookOpen className="h-5 w-5" />,
    version: '2.1',
    pdfPath: '/docs/pdf/AuditPro-PRD.pdf',
    pdfFilename: 'AuditPro-PRD.pdf',
  },
  {
    id: 'tdd',
    title: 'Technical Design Document',
    description: 'System architecture, component design, data models, and technical specifications',
    filename: 'AuditPro-TDD.md',
    path: '/docs/TDD.md',
    icon: <FileText className="h-5 w-5" />,
    version: '1.0',
  },
  {
    id: 'qa',
    title: 'QA Test Scenarios',
    description: 'Comprehensive quality assurance test cases covering all features and edge cases',
    filename: 'AuditPro-QA-Test-Scenarios.md',
    path: '/docs/QA-Test-Scenarios.md',
    icon: <TestTube className="h-5 w-5" />,
    version: '1.0',
  },
  {
    id: 'uat',
    title: 'UAT Test Scenarios',
    description: 'User acceptance testing scenarios for end-user validation of business workflows',
    filename: 'AuditPro-UAT-Test-Scenarios.md',
    path: '/docs/UAT-Test-Scenarios.md',
    icon: <ClipboardCheck className="h-5 w-5" />,
    version: '1.0',
  },
  {
    id: 'system-prompt',
    title: 'AI System Prompt',
    description: 'System prompt for AI assistant integration with AuditPro',
    filename: 'AuditPro-System-Prompt.md',
    path: '/docs/System-Prompt.md',
    icon: <Bot className="h-5 w-5" />,
    version: '1.0',
  },
  {
    id: 'status-reference',
    title: 'Status Reference',
    description: 'The 12 audit statuses used in All Audits — colors, purpose, owners, and exit conditions',
    filename: '',
    path: '',
    icon: <Layers className="h-5 w-5" />,
    version: '1.0',
  },
];

export default function Documentation() {
  const [activeDoc, setActiveDoc] = useState<string>('prd');
  const [content, setContent] = useState<string>('Loading...');
  const [loading, setLoading] = useState(true);

  const currentDoc = documents.find(d => d.id === activeDoc) || documents[0];

  useEffect(() => {
    if (!currentDoc.path) {
      setContent('');
      setLoading(false);
      return;
    }
    setLoading(true);
    fetch(currentDoc.path)
      .then(res => res.text())
      .then(text => {
        setContent(text);
        setLoading(false);
      })
      .catch(() => {
        setContent('# Error loading document');
        setLoading(false);
      });
  }, [activeDoc, currentDoc.path]);

  const handleDownload = () => {
    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = currentDoc.filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handlePdfDownload = async () => {
    if (!currentDoc.pdfPath || !currentDoc.pdfFilename) return;
    try {
      const res = await fetch(currentDoc.pdfPath);
      if (!res.ok) throw new Error(`Failed to fetch PDF (${res.status})`);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = currentDoc.pdfFilename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('PDF download failed:', err);
      // Fallback: open in new tab
      window.open(currentDoc.pdfPath, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
              <BookOpen className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Documentation</h1>
              <p className="text-muted-foreground">AuditPro technical and product documentation</p>
            </div>
          </div>
        </div>

        {/* Document Tabs */}
        <Tabs value={activeDoc} onValueChange={setActiveDoc} className="space-y-4">
          <TabsList className="grid w-full grid-cols-6 h-auto p-1">
            {documents.map((doc) => (
              <TabsTrigger
                key={doc.id}
                value={doc.id}
                className="flex flex-col items-center gap-1 py-3 px-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                {doc.icon}
                <span className="text-xs font-medium text-center leading-tight">{doc.title.split(' ').slice(0, 2).join(' ')}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {documents.map((doc) => (
            <TabsContent key={doc.id} value={doc.id} className="space-y-4">
              {/* Document Info Card */}
              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        {doc.icon}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{doc.title}</CardTitle>
                        <CardDescription>{doc.description}</CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant="outline">v{doc.version}</Badge>
                      {doc.pdfPath && (
                        <Button onClick={handlePdfDownload} variant="default" className="gap-2">
                          <Download className="h-4 w-4" />
                          Download PDF
                        </Button>
                      )}
                      {doc.filename && (
                        <Button onClick={handleDownload} variant="outline" className="gap-2">
                          <Download className="h-4 w-4" />
                          Download MD
                        </Button>
                      )}
                    </div>
                  </div>
                </CardHeader>
              </Card>

              {/* Document Content */}
              <Card className="border-border/50">
                <CardContent className="p-0">
                  <ScrollArea className="h-[calc(100vh-380px)]">
                    {doc.id === 'status-reference' ? (
                      <div className="p-6">
                        <StatusReference />
                      </div>
                    ) : loading ? (
                      <div className="p-6 text-muted-foreground">Loading document...</div>
                    ) : (
                      <div className="p-6 prose prose-sm dark:prose-invert max-w-none
                        prose-headings:text-foreground 
                        prose-h1:text-2xl prose-h1:font-bold prose-h1:mb-4 prose-h1:mt-8
                        prose-h2:text-xl prose-h2:font-semibold prose-h2:mb-3 prose-h2:mt-6 prose-h2:border-b prose-h2:border-border/50 prose-h2:pb-2
                        prose-h3:text-lg prose-h3:font-medium prose-h3:mb-2 prose-h3:mt-4
                        prose-h4:text-base prose-h4:font-medium prose-h4:mb-2 prose-h4:mt-3
                        prose-p:text-muted-foreground prose-p:leading-relaxed prose-p:mb-3
                        prose-strong:text-foreground prose-strong:font-semibold
                        prose-code:text-primary prose-code:bg-primary/10 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:text-sm
                        prose-pre:bg-muted prose-pre:border prose-pre:border-border/50 prose-pre:rounded-lg prose-pre:p-4
                        prose-ul:text-muted-foreground prose-ul:my-2
                        prose-ol:text-muted-foreground prose-ol:my-2
                        prose-li:mb-1
                        prose-table:border-collapse prose-table:w-full prose-table:my-4
                        prose-th:bg-muted prose-th:border prose-th:border-border prose-th:px-3 prose-th:py-2 prose-th:text-left prose-th:font-medium prose-th:text-foreground
                        prose-td:border prose-td:border-border prose-td:px-3 prose-td:py-2 prose-td:text-muted-foreground
                        prose-hr:border-border prose-hr:my-6
                        prose-a:text-primary prose-a:no-underline hover:prose-a:underline
                      ">
                        <ReactMarkdown remarkPlugins={[remarkGfm]}>
                          {content}
                        </ReactMarkdown>
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </AppLayout>
  );
}
