import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAudit, mockUsers } from '@/contexts/AuditContext';
import { LinkedItemsSection } from '@/components/audit/LinkedItemsSection';
import { AppLayout } from '@/components/layout/AppLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { AuditType, Periodicity, PERIODICITY_LABELS } from '@/types/audit';
import { ArrowLeft, Plus, Trash2, FileText, Shield, Repeat, Calendar, AlertTriangle, Save } from 'lucide-react';
import { toast } from 'sonner';

const departments = [
  'Nursing',
  'Quality Assurance',
  'Administration',
  'Pharmacy',
  'Radiology',
  'Laboratory',
];

export default function EditAudit() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const { audits, updateAudit, deleteAudit, currentUser, addLinkedItem, removeLinkedItem } = useAudit();
  
  const audit = audits.find(a => a.id === id);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'internal' as AuditType,
    department: '',
    assignedTo: '',
    dueDate: '',
    priority: 'medium' as 'low' | 'medium' | 'high' | 'critical',
    isPeriodic: false,
    periodicity: 'monthly' as Periodicity,
    risksAndDependencies: '',
  });

  const [actions, setActions] = useState<{ id: string; description: string; completed: boolean }[]>([]);

  useEffect(() => {
    if (audit) {
      setFormData({
        title: audit.title,
        description: audit.description,
        type: audit.type,
        department: audit.department,
        assignedTo: audit.assignedTo,
        dueDate: audit.dueDate ? audit.dueDate.split('T')[0] : '',
        priority: audit.priority,
        isPeriodic: audit.isPeriodic,
        periodicity: audit.periodicity || 'monthly',
        risksAndDependencies: '',
      });
      setActions(audit.actions.map(a => ({
        id: a.id,
        description: a.description,
        completed: a.completed,
      })));
    }
  }, [audit]);

  if (!audit) {
    return (
      <AppLayout>
        <div className="p-8 text-center">
          <h1 className="text-2xl font-bold text-foreground">Audit not found</h1>
          <Button onClick={() => navigate('/scheduled-audits')} className="mt-4">
            Back to Scheduled Audits
          </Button>
        </div>
      </AppLayout>
    );
  }

  const addAction = () => {
    setActions([...actions, { id: Date.now().toString(), description: '', completed: false }]);
  };

  const removeAction = (actionId: string) => {
    if (actions.length > 1) {
      setActions(actions.filter(a => a.id !== actionId));
    }
  };

  const updateAction = (actionId: string, description: string) => {
    setActions(actions.map(a => a.id === actionId ? { ...a, description } : a));
  };

  const calculateNextScheduledDate = (dueDate: string, periodicity: Periodicity): string => {
    if (!dueDate) return '';
    const date = new Date(dueDate);
    switch (periodicity) {
      case 'daily':
        date.setDate(date.getDate() + 1);
        break;
      case 'weekly':
        date.setDate(date.getDate() + 7);
        break;
      case 'monthly':
        date.setMonth(date.getMonth() + 1);
        break;
      case 'quarterly':
        date.setMonth(date.getMonth() + 3);
        break;
      case 'annually':
        date.setFullYear(date.getFullYear() + 1);
        break;
    }
    return date.toISOString().split('T')[0];
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const assignedUser = mockUsers.find(u => u.id === formData.assignedTo);
    
    updateAudit(audit.id, {
      title: formData.title,
      description: formData.description,
      type: formData.type,
      department: formData.department,
      assignedTo: formData.assignedTo,
      assignedToName: assignedUser?.name || audit.assignedToName,
      dueDate: formData.dueDate,
      priority: formData.priority,
      isPeriodic: formData.isPeriodic,
      periodicity: formData.isPeriodic ? formData.periodicity : undefined,
      nextScheduledDate: formData.isPeriodic 
        ? calculateNextScheduledDate(formData.dueDate, formData.periodicity) 
        : undefined,
      actions: actions.filter(a => a.description.trim()).map(a => ({
        id: a.id,
        description: a.description,
        completed: a.completed,
      })),
    });

    toast.success('Audit updated successfully');
    navigate('/scheduled-audits');
  };

  const handleDelete = () => {
    deleteAudit(audit.id);
    toast.success('Audit deleted successfully');
    navigate('/scheduled-audits');
  };

  return (
    <AppLayout>
      <div className="p-8 max-w-4xl">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate('/scheduled-audits')}
            className="mb-4 gap-2 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Scheduled Audits
          </Button>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="h-14 w-14 rounded-2xl gradient-primary flex items-center justify-center">
                <FileText className="h-7 w-7 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-foreground">Edit Audit</h1>
                <p className="text-muted-foreground">Modify audit details, scheduling, and action steps</p>
              </div>
            </div>
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" className="gap-2">
                  <Trash2 className="h-4 w-4" />
                  Delete Audit
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete Audit</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete this audit? This action cannot be undone.
                    All history and evidence associated with this audit will be permanently removed.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Basic Information</CardTitle>
              <CardDescription>Update the audit details and classification</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Audit Title</Label>
                <Input
                  id="title"
                  placeholder="e.g., Medication Administration Compliance Review"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Provide a detailed description of the audit scope and objectives..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={4}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Audit Type</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value: AuditType) => setFormData({ ...formData, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="internal">Internal Audit</SelectItem>
                      <SelectItem value="external">External Audit</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Priority</Label>
                  <Select
                    value={formData.priority}
                    onValueChange={(value: 'low' | 'medium' | 'high' | 'critical') => 
                      setFormData({ ...formData, priority: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Scheduling */}
          <Card className="border-border/50">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-muted-foreground" />
                <div>
                  <CardTitle className="text-lg">Scheduling</CardTitle>
                  <CardDescription>Update the audit schedule and recurrence</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                <div className="flex items-center gap-3">
                  <Repeat className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Periodic Audit</p>
                    <p className="text-sm text-muted-foreground">Schedule this audit to repeat automatically</p>
                  </div>
                </div>
                <Switch
                  checked={formData.isPeriodic}
                  onCheckedChange={(checked) => setFormData({ ...formData, isPeriodic: checked })}
                />
              </div>

              {formData.isPeriodic && (
                <div className="space-y-2 animate-fade-in">
                  <Label>Periodicity</Label>
                  <Select
                    value={formData.periodicity}
                    onValueChange={(value: Periodicity) => setFormData({ ...formData, periodicity: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="annually">Annually</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    The audit will automatically be rescheduled after completion
                  </p>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="dueDate">Due Date</Label>
                <Input
                  id="dueDate"
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                  required
                />
                {formData.isPeriodic && formData.dueDate && (
                  <p className="text-xs text-primary">
                    Next scheduled: {calculateNextScheduledDate(formData.dueDate, formData.periodicity)}
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Assignment */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Assignment</CardTitle>
              <CardDescription>Update the audit assignment</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Department</Label>
                  <Select
                    value={formData.department}
                    onValueChange={(value) => setFormData({ ...formData, department: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {departments.map((dept) => (
                        <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Assign To</Label>
                  <Select
                    value={formData.assignedTo}
                    onValueChange={(value) => setFormData({ ...formData, assignedTo: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select team member" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockUsers.map((user) => (
                        <SelectItem key={user.id} value={user.id}>
                          {user.name} ({user.department})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Risks & Dependencies */}
          <Card className="border-border/50">
            <CardHeader>
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-muted-foreground" />
                <div>
                  <CardTitle className="text-lg">Risks & Dependencies</CardTitle>
                  <CardDescription>Document potential risks, blockers, or dependencies for this audit</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Document any risks, dependencies, or potential blockers for this audit..."
                value={formData.risksAndDependencies}
                onChange={(e) => setFormData({ ...formData, risksAndDependencies: e.target.value })}
                rows={4}
              />
            </CardContent>
          </Card>

          {/* Action Steps */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Action Steps</CardTitle>
              <CardDescription>Manage the action items for this audit</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {actions.map((action, index) => (
                <div key={action.id} className="flex items-center gap-3">
                  <span className="text-sm text-muted-foreground w-6">{index + 1}.</span>
                  <Input
                    placeholder="Describe the action step..."
                    value={action.description}
                    onChange={(e) => updateAction(action.id, e.target.value)}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeAction(action.id)}
                    disabled={actions.length === 1}
                    className="text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}

              <Button
                type="button"
                variant="outline"
                onClick={addAction}
                className="w-full gap-2"
              >
                <Plus className="h-4 w-4" />
                Add Action Step
              </Button>
            </CardContent>
          </Card>

          {/* Cross-Microapp Links */}
          <LinkedItemsSection
            auditId={audit.id}
            linkedItems={audit.linkedItems || []}
            onAddLink={(item) => addLinkedItem(audit.id, item)}
            onRemoveLink={(itemId) => removeLinkedItem(audit.id, itemId)}
          />

          {/* Submit */}
          <div className="flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={() => navigate('/scheduled-audits')}>
              Cancel
            </Button>
            <Button type="submit" className="gradient-primary text-primary-foreground gap-2">
              <Save className="h-4 w-4" />
              Save Changes
            </Button>
          </div>
        </form>
      </div>
    </AppLayout>
  );
}
