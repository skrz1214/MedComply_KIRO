import { useNavigate } from 'react-router-dom';
import { useAudit } from '@/contexts/AuditContext';
import { AppLayout } from '@/components/layout/AppLayout';
import { AuditCard } from '@/components/audit/AuditCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Plus,
  Search,
  Filter,
  FileText,
  FolderSearch,
  ClipboardCheck,
  ShieldCheck,
  FileSearch,
  CheckCircle2,
  CircleDot,
  Eye,
  Send,
  AlertCircle,
  Clock,
  FileWarning,
} from 'lucide-react';
import { useState } from 'react';
import { AuditType, AuditPhase, PHASE_LABELS, PHASE_ORDER } from '@/types/audit';

const PHASE_OPTIONS: AuditPhase[] = PHASE_ORDER;

export default function AllAudits() {
  const navigate = useNavigate();
  const { audits } = useAudit();

  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<AuditType | 'all'>('all');
  const [phaseFilter, setPhaseFilter] = useState<AuditPhase | 'all'>('all');

  const filteredAudits = audits.filter(audit => {
    const matchesSearch =
      audit.title.toLowerCase().includes(search.toLowerCase()) ||
      audit.description.toLowerCase().includes(search.toLowerCase());
    const matchesType = typeFilter === 'all' || audit.type === typeFilter;
    const matchesPhase = phaseFilter === 'all' || audit.currentPhase === phaseFilter;
    return matchesSearch && matchesType && matchesPhase;
  });

  // Count audits by phase for summary
  const phaseCounts = PHASE_OPTIONS.reduce((acc, phase) => {
    acc[phase] = audits.filter(a => a.currentPhase === phase).length;
    return acc;
  }, {} as Record<AuditPhase, number>);

  const handleAuditClick = (audit: typeof audits[0]) => {
    // Consistent routing based on current phase
    switch (audit.currentPhase) {
      case 'draft':
      case 'pre_audit':
      case 'pre_audit_review':
        navigate(`/audit/${audit.id}`);
        break;
      case 'internal_review':
        navigate(`/review/${audit.id}`);
        break;
      case 'remediation_required':
      case 'closure_cap':
      case 'cap_active':
      case 'pending_verification':
        navigate(`/closure/${audit.id}`);
        break;
      case 'closed':
        navigate(`/audit/${audit.id}`);
        break;
      default:
        navigate(`/audit/${audit.id}`);
    }
  };

  const phaseIcons: Record<AuditPhase, React.ElementType> = {
    draft: CircleDot,
    pre_audit: FileSearch,
    pre_audit_review: Eye,
    overview: FileText,
    evidence_collection: FolderSearch,
    evaluation: ClipboardCheck,
    internal_review: Send,
    remediation_required: AlertCircle,
    closure_cap: ShieldCheck,
    cap_active: FileWarning,
    pending_verification: Clock,
    closed: CheckCircle2,
  };

  // Top-row summary cards: highlight the most actionable phases
  const SUMMARY_PHASES: AuditPhase[] = [
    'pre_audit',
    'evidence_collection',
    'evaluation',
    'internal_review',
    'closed',
  ];

  return (
    <AppLayout>
      <div className="p-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">All Audits</h1>
            <p className="text-muted-foreground">View and manage all audit items across all statuses</p>
          </div>
          <Button
            onClick={() => navigate('/new-audit')}
            className="gradient-primary hover:opacity-90 text-primary-foreground gap-2"
          >
            <Plus className="h-4 w-4" />
            New Audit
          </Button>
        </div>

        {/* Status Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 mb-6">
          {SUMMARY_PHASES.map((phase) => {
            const Icon = phaseIcons[phase];
            const isActive = phaseFilter === phase;
            return (
              <button
                key={phase}
                onClick={() => setPhaseFilter(isActive ? 'all' : phase)}
                className={`p-3 rounded-lg border text-left transition-all ${
                  isActive
                    ? 'border-primary bg-primary/5 ring-1 ring-primary'
                    : 'border-border/50 bg-card hover:border-primary/30'
                }`}
                aria-pressed={isActive}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Icon className={`h-4 w-4 ${isActive ? 'text-primary' : 'text-muted-foreground'}`} />
                  <span className={`text-lg font-semibold ${isActive ? 'text-primary' : 'text-foreground'}`}>
                    {phaseCounts[phase]}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground truncate">{PHASE_LABELS[phase]}</p>
              </button>
            );
          })}
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 mb-6">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search audits..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>

          <Select value={phaseFilter} onValueChange={(val) => setPhaseFilter(val as AuditPhase | 'all')}>
            <SelectTrigger className="w-[220px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              {PHASE_OPTIONS.map((phase) => (
                <SelectItem key={phase} value={phase}>{PHASE_LABELS[phase]}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={typeFilter} onValueChange={(val) => setTypeFilter(val as AuditType | 'all')}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="internal">Internal</SelectItem>
              <SelectItem value="external">External</SelectItem>
            </SelectContent>
          </Select>

          {(typeFilter !== 'all' || phaseFilter !== 'all') && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setTypeFilter('all');
                setPhaseFilter('all');
              }}
              className="text-muted-foreground"
            >
              Clear filters
            </Button>
          )}
        </div>

        {/* Active Filters */}
        {(typeFilter !== 'all' || phaseFilter !== 'all') && (
          <div className="flex flex-wrap gap-2 mb-4">
            {phaseFilter !== 'all' && (
              <Badge variant="secondary" className="gap-1">
                Status: {PHASE_LABELS[phaseFilter]}
                <button
                  onClick={() => setPhaseFilter('all')}
                  className="ml-1 hover:text-foreground"
                  aria-label="Clear status filter"
                >
                  ×
                </button>
              </Badge>
            )}
            {typeFilter !== 'all' && (
              <Badge variant="secondary" className="gap-1">
                Type: {typeFilter}
                <button
                  onClick={() => setTypeFilter('all')}
                  className="ml-1 hover:text-foreground"
                  aria-label="Clear type filter"
                >
                  ×
                </button>
              </Badge>
            )}
          </div>
        )}

        {/* Results Count */}
        <p className="text-sm text-muted-foreground mb-4">
          Showing {filteredAudits.length} of {audits.length} audits
        </p>

        {/* Audits Grid */}
        {filteredAudits.length === 0 ? (
          <div className="bg-muted/30 rounded-lg border border-dashed border-border p-12 text-center">
            <p className="text-muted-foreground">No audits match your filters</p>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {filteredAudits.map((audit, index) => (
              <div
                key={audit.id}
                className="animate-slide-up"
                style={{ animationDelay: `${index * 30}ms` }}
              >
                <AuditCard
                  audit={audit}
                  onClick={() => handleAuditClick(audit)}
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
