import { useState } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useAudit } from '@/contexts/AuditContext';
import { useCAP } from '@/contexts/CAPContext';
import { usePermissions } from '@/hooks/usePermissions';
import { AppLayout } from '@/components/layout/AppLayout';
import { StatusBadge } from '@/components/audit/StatusBadge';
import { PriorityBadge } from '@/components/audit/PriorityBadge';
import { CAPManagement } from '@/components/cap/CAPManagement';
import { ClosureTab } from '@/components/closure/ClosureTab';
import { LinkedItemsSection } from '@/components/audit/LinkedItemsSection';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { toast } from '@/hooks/use-toast';
import {
  ArrowLeft, Calendar, User, Building2, FileText, CheckCircle2, XCircle,
  Clock, Shield, ClipboardList, FileWarning, Link2, Eye, Lock
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { LinkedItem, AuditAction } from '@/types/audit';
export default function AuditItemDetails() {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { audits, currentUser, addLinkedItem, removeLinkedItem, updateAudit } = useAudit();
  const { getCAPByAuditId } = useCAP();
  const defaultTab = searchParams.get('tab') || 'overview';
  const [activeTab, setActiveTab] = useState(defaultTab);

  const audit = audits.find(a => a.id === id);
  const cap = audit ? getCAPByAuditId(audit.id) : undefined;
  const permissions = usePermissions(audit);

  if (!audit) {
    return (
      <AppLayout>
        <div className="p-8 flex items-center justify-center h-full">
          <div className="text-center">
            <h2 className="text-xl font-semibold mb-2">Audit Not Found</h2>
            <p className="text-muted-foreground mb-4">The audit item doesn't exist.</p>
            <Button onClick={() => navigate('/')}>Return to Dashboard</Button>
          </div>
        </div>
      </AppLayout>
    );
  }

  const isComplete = audit.status === 'closed';
  const canToggleActions = permissions.canCompleteActions && !isComplete;

  const handleToggleAction = (action: AuditAction) => {
    if (!canToggleActions) return;
    const nowCompleting = !action.completed;
    const updatedActions = audit.actions.map(a =>
      a.id === action.id
        ? {
            ...a,
            completed: nowCompleting,
            completedAt: nowCompleting ? new Date().toISOString() : undefined,
            completedBy: nowCompleting ? currentUser.name : undefined,
          }
        : a
    );
    updateAudit(audit.id, { actions: updatedActions });
    toast({
      title: nowCompleting ? 'Action marked complete' : 'Action marked incomplete',
      description: action.description,
    });
  };

  return (
    <AppLayout>
      <div className="p-8 max-w-6xl">
        {/* Header */}
        <div className="mb-6">
          <Button variant="ghost" onClick={() => navigate(-1)} className="mb-4 gap-2 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>

          {isComplete && (
            <div className="mb-4 p-3 rounded-lg bg-status-success-bg/50 border border-status-success/20 flex items-center gap-2">
              <Shield className="h-5 w-5 text-status-success" />
              <span className="text-sm font-medium text-status-success">This audit is closed and read-only</span>
            </div>
          )}

          {!isComplete && permissions.isReadOnly && (
            <Alert className="mb-4 border-status-pending/30 bg-status-pending-bg/30">
              <Eye className="h-4 w-4 text-status-pending" aria-hidden="true" />
              <AlertTitle className="text-foreground">Read-only access</AlertTitle>
              <AlertDescription className="text-muted-foreground">
                You're signed in as <strong className="text-foreground">Staff</strong>. You can review this audit's details, evidence, actions, and history, but you cannot complete actions, upload evidence, or change the audit's status. Switch to a <strong className="text-foreground">Department Head</strong> or <strong className="text-foreground">Compliance Head</strong> role to edit.
              </AlertDescription>
            </Alert>
          )}

          <div className="flex items-center gap-4 mb-4">
            <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center">
              <ClipboardList className="h-7 w-7 text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-primary font-medium uppercase tracking-wide">Audit Item Details</p>
              <h1 className="text-2xl font-bold text-foreground">{audit.title}</h1>
            </div>
          </div>

          <div className="flex items-center gap-3 mb-2">
            <span className={cn('text-xs font-medium uppercase tracking-wider', audit.type === 'external' ? 'text-status-pending' : 'text-primary')}>
              {audit.type} Audit
            </span>
            <PriorityBadge priority={audit.priority} />
            <StatusBadge status={audit.status} closureType={audit.closureType} />
          </div>

          <div className="flex flex-wrap items-center gap-6 mt-4 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <User className="h-4 w-4" />
              <span>Assigned: <strong className="text-foreground">{audit.assignedToName}</strong></span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Building2 className="h-4 w-4" />
              <span>{audit.department}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span>Due: {audit.dueDate}</span>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-muted/50">
            <TabsTrigger value="overview" className="gap-2">
              <ClipboardList className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="links" className="gap-2">
              <Link2 className="h-4 w-4" />
              Links
              {(audit.linkedItems?.length || 0) > 0 && (
                <span className="ml-1 text-xs bg-primary/20 px-1.5 py-0.5 rounded">
                  {audit.linkedItems?.length}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="cap" className="gap-2">
              <FileWarning className="h-4 w-4" />
              CAP
              {cap && <span className="ml-1 text-xs bg-primary/20 px-1.5 py-0.5 rounded">{cap.actions.length}</span>}
            </TabsTrigger>
            <TabsTrigger value="closure" className="gap-2">
              <Shield className="h-4 w-4" />
              Closure
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <Card className="border-border/50">
              <CardHeader><CardTitle className="text-lg">Finding Details</CardTitle></CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{audit.description}</p>
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">Actions</p>
                    <p className="text-2xl font-bold">{audit.actions.filter(a => a.completed).length}/{audit.actions.length}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">Evidence</p>
                    <p className="text-2xl font-bold">{audit.evidence.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border/50">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">Actions</CardTitle>
                {!canToggleActions && !isComplete && (
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Lock className="h-3 w-3" aria-hidden="true" />
                    Read-only — switch role to edit
                  </span>
                )}
              </CardHeader>
              <CardContent>
                {audit.actions.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No actions defined for this audit.</p>
                ) : (
                  <ul className="space-y-2" role="list">
                    {audit.actions.map(action => {
                      const checkboxId = `action-${action.id}`;
                      return (
                        <li
                          key={action.id}
                          className={cn(
                            'flex items-start gap-3 p-3 rounded-lg border border-border/50 transition-colors',
                            canToggleActions && 'hover:bg-muted/50 cursor-pointer',
                            action.completed && 'bg-status-success-bg/20'
                          )}
                          onClick={() => canToggleActions && handleToggleAction(action)}
                        >
                          <Checkbox
                            id={checkboxId}
                            checked={action.completed}
                            disabled={!canToggleActions}
                            onCheckedChange={() => handleToggleAction(action)}
                            onClick={(e) => e.stopPropagation()}
                            aria-label={`Mark "${action.description}" as ${action.completed ? 'incomplete' : 'complete'}`}
                            className="mt-0.5"
                          />
                          <div className="flex-1 min-w-0">
                            <label
                              htmlFor={checkboxId}
                              className={cn(
                                'text-sm block',
                                action.completed && 'text-muted-foreground line-through',
                                canToggleActions && 'cursor-pointer'
                              )}
                              onClick={(e) => e.stopPropagation()}
                            >
                              {action.description}
                            </label>
                            {action.completed && action.completedBy && (
                              <p className="text-xs text-muted-foreground mt-1">
                                Completed by {action.completedBy}
                                {action.completedAt && ` • ${new Date(action.completedAt).toLocaleString()}`}
                              </p>
                            )}
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </CardContent>
            </Card>

            <Card className="border-border/50">
              <CardHeader><CardTitle className="text-lg">Activity Timeline</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {audit.history.map(entry => (
                    <div key={entry.id} className="flex items-start gap-3 text-sm">
                      <Clock className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="font-medium">{entry.action}</p>
                        <p className="text-muted-foreground">{entry.performedBy} • {new Date(entry.performedAt).toLocaleString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Links Tab */}
          <TabsContent value="links">
            <LinkedItemsSection
              auditId={audit.id}
              linkedItems={audit.linkedItems || []}
              onAddLink={(item) => addLinkedItem(audit.id, item)}
              onRemoveLink={(itemId) => removeLinkedItem(audit.id, itemId)}
              readOnly={isComplete}
            />
          </TabsContent>

          {/* CAP Tab */}
          <TabsContent value="cap">
            <CAPManagement auditId={audit.id} onCAPVerified={() => setActiveTab('closure')} />
          </TabsContent>

          {/* Closure Tab */}
          <TabsContent value="closure">
            <ClosureTab audit={audit} onClose={() => navigate('/')} />
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
