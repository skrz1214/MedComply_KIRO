import { useAudit } from '@/contexts/AuditContext';
import { AuditItem, UserRole } from '@/types/audit';

export interface Permissions {
  canViewAudit: boolean;
  canViewAllAudits: boolean;
  canCreateAudit: boolean;
  canEditAudit: boolean;
  canDeleteAudit: boolean;
  canUploadEvidence: boolean;
  canCompleteActions: boolean;
  canSubmitForReview: boolean;
  canApproveReview: boolean;
  canRejectReview: boolean;
  canAssignUsers: boolean;
  canAccessAdminSettings: boolean;
  canPerformClosure: boolean;
  canMakeCAPDecision: boolean;
  canConfigureMetrics: boolean;
  isReadOnly: boolean;
}

const rolePermissions: Record<UserRole, Permissions> = {
  staff: {
    canViewAudit: true,
    canViewAllAudits: false,
    canCreateAudit: false,
    canEditAudit: false,
    canDeleteAudit: false,
    canUploadEvidence: false,
    canCompleteActions: false,
    canSubmitForReview: false,
    canApproveReview: false,
    canRejectReview: false,
    canAssignUsers: false,
    canAccessAdminSettings: false,
    canPerformClosure: false,
    canMakeCAPDecision: false,
    canConfigureMetrics: false,
    isReadOnly: true,
  },
  department_head: {
    canViewAudit: true,
    canViewAllAudits: false,
    canCreateAudit: true,
    canEditAudit: true,
    canDeleteAudit: false,
    canUploadEvidence: true,
    canCompleteActions: true,
    canSubmitForReview: true,
    canApproveReview: true,
    canRejectReview: true,
    canAssignUsers: true,
    canAccessAdminSettings: false,
    canPerformClosure: true,
    canMakeCAPDecision: false,
    canConfigureMetrics: false,
    isReadOnly: false,
  },
  compliance_head: {
    canViewAudit: true,
    canViewAllAudits: true,
    canCreateAudit: true,
    canEditAudit: true,
    canDeleteAudit: false,
    canUploadEvidence: true,
    canCompleteActions: true,
    canSubmitForReview: true,
    canApproveReview: true,
    canRejectReview: true,
    canAssignUsers: true,
    canAccessAdminSettings: false,
    canPerformClosure: true,
    canMakeCAPDecision: true,
    canConfigureMetrics: false,
    isReadOnly: false,
  },
  admin: {
    canViewAudit: true,
    canViewAllAudits: true,
    canCreateAudit: true,
    canEditAudit: true,
    canDeleteAudit: true,
    canUploadEvidence: true,
    canCompleteActions: true,
    canSubmitForReview: true,
    canApproveReview: true,
    canRejectReview: true,
    canAssignUsers: true,
    canAccessAdminSettings: true,
    canPerformClosure: true,
    canMakeCAPDecision: true,
    canConfigureMetrics: true,
    isReadOnly: false,
  },
};

export function usePermissions(audit?: AuditItem): Permissions {
  const { currentUser } = useAudit();
  const base = rolePermissions[currentUser.role];

  // Assignee override: the user assigned to this audit can complete actions
  // and upload evidence on their own audit, regardless of role.
  if (audit && audit.assignedTo === currentUser.id) {
    return {
      ...base,
      canCompleteActions: true,
      canUploadEvidence: true,
      isReadOnly: false,
    };
  }

  return base;
}

export function useCanPerformAction(action: keyof Permissions, audit?: AuditItem): boolean {
  const permissions = usePermissions(audit);
  return permissions[action];
}
