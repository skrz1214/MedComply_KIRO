import { 
  LayoutDashboard, 
  Plus, 
  FileText, 
  Calendar,
  Shield,
  ChevronDown,
  Settings,
  Package,
} from 'lucide-react';
import { NavLink, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useAudit, mockUsers } from '@/contexts/AuditContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

const navigation = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard },
  { name: 'New Audit', href: '/new-audit', icon: Plus },
  { name: 'All Audits', href: '/audits', icon: FileText },
  { name: 'Scheduled Audits', href: '/scheduled-audits', icon: Calendar },
  { name: 'Audit Pack', href: '/audit-pack', icon: Package },
  { name: 'Admin Settings', href: '/admin', icon: Settings },
  { name: 'Documentation', href: '/docs', icon: FileText },
];

export function AppSidebar() {
  const location = useLocation();
  const { currentUser, setCurrentUser } = useAudit();

  const roleLabels = {
    staff: 'Staff (Read-only)',
    department_head: 'Department Head',
    compliance_head: 'Compliance Head',
    admin: 'Administrator',
  };

  return (
    <aside className="w-64 bg-sidebar text-sidebar-foreground flex flex-col h-screen sticky top-0">
      {/* Logo */}
      <div className="p-6 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg gradient-primary flex items-center justify-center">
            <Shield className="h-6 w-6 text-sidebar-primary-foreground" />
          </div>
          <div>
            <h1 className="font-bold text-lg text-sidebar-accent-foreground">AuditPro</h1>
            <p className="text-xs text-sidebar-foreground/60">MedComply Suite</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1">
        {navigation
          .filter(item => {
            // Hide Admin Settings from non-admin users
            if (item.href === '/admin' && currentUser.role !== 'admin') {
              return false;
            }
            // Hide New Audit from Staff (read-only)
            if (item.href === '/new-audit' && currentUser.role === 'staff') {
              return false;
            }
            return true;
          })
          .map((item) => {
            const isActive = location.pathname === item.href;
            return (
              <NavLink
                key={item.name}
                to={item.href}
                className={cn(
                  'flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200',
                  isActive 
                    ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-md' 
                    : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                )}
              >
                <item.icon className="h-5 w-5" />
                {item.name}
              </NavLink>
            );
          })}
      </nav>

      {/* User Switcher */}
      <div className="p-4 border-t border-sidebar-border">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-sidebar-accent transition-colors text-left">
              <Avatar className="h-10 w-10 border-2 border-sidebar-primary">
                <AvatarFallback className="bg-sidebar-primary text-sidebar-primary-foreground font-semibold">
                  {currentUser.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-sidebar-accent-foreground truncate">
                  {currentUser.name}
                </p>
                <p className="text-xs text-sidebar-foreground/60 truncate">
                  {roleLabels[currentUser.role]}
                </p>
              </div>
              <ChevronDown className="h-4 w-4 text-sidebar-foreground/60" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Switch User (Demo)</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {mockUsers.map((user) => (
              <DropdownMenuItem
                key={user.id}
                onClick={() => setCurrentUser(user)}
                className={cn(
                  currentUser.id === user.id && 'bg-accent'
                )}
              >
                <div className="flex items-center gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="text-xs">
                      {user.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">{user.name}</p>
                    <p className="text-xs text-muted-foreground">{roleLabels[user.role]}</p>
                  </div>
                </div>
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </aside>
  );
}
