import { useMemo, useState } from 'react';
import { useAudit } from '@/contexts/AuditContext';
import { useAdmin } from '@/contexts/AdminContext';
import { usePermissions } from '@/hooks/usePermissions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  AlertCircle, 
  Clock, 
  CheckCircle2, 
  TrendingUp, 
  TrendingDown,
  Target,
  AlertTriangle,
  FileSearch,
  ShieldCheck
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface DashboardMetricsProps {
  view: 'department' | 'personal';
}

export function DashboardMetrics({ view }: DashboardMetricsProps) {
  const { audits, currentUser, getDepartmentAudits, getPersonalAudits } = useAudit();
  const { settings } = useAdmin();
  const permissions = usePermissions();
  const { metricsPolicy } = settings;

  const [typeFilter, setTypeFilter] = useState<'all' | 'internal' | 'external'>('all');
  const [dateRange, setDateRange] = useState<'7d' | '30d' | '90d' | 'all'>('30d');

  // Get filtered audits based on view and filters
  const filteredAudits = useMemo(() => {
    let baseAudits = view === 'department' || permissions.canViewAllAudits
      ? (permissions.canViewAllAudits ? audits : getDepartmentAudits())
      : getPersonalAudits();

    // Type filter
    if (typeFilter !== 'all') {
      baseAudits = baseAudits.filter(a => a.type === typeFilter);
    }

    // Date range filter
    if (dateRange !== 'all') {
      const now = new Date();
      const daysAgo = dateRange === '7d' ? 7 : dateRange === '30d' ? 30 : 90;
      const cutoff = new Date(now.getTime() - daysAgo * 24 * 60 * 60 * 1000);
      baseAudits = baseAudits.filter(a => new Date(a.createdAt) >= cutoff);
    }

    return baseAudits;
  }, [audits, view, typeFilter, dateRange, permissions, getDepartmentAudits, getPersonalAudits]);

  // Calculate metrics
  const metrics = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Open audits (any phase except closed)
    const openAudits = filteredAudits.filter(a => a.currentPhase !== 'closed');

    // Overdue audits
    const overdueAudits = openAudits.filter(a => new Date(a.dueDate) < today);

    // Pending review
    const pendingReview = filteredAudits.filter(a => a.currentPhase === 'internal_review');

    // QA Review (external audits in internal_review)
    const qaReview = filteredAudits.filter(a =>
      a.currentPhase === 'internal_review' && a.type === 'external'
    );

    // CAP Required (external audits in CAP-related phases)
    const capRequired = filteredAudits.filter(a =>
      (a.currentPhase === 'cap_active' || a.currentPhase === 'remediation_required') && a.type === 'external'
    );

    // Completed audits
    const completedAudits = filteredAudits.filter(a => a.currentPhase === 'closed');
    
    // On-time completions
    const onTimeCompletions = completedAudits.filter(a => {
      const completedEntry = a.history.find(h => h.action.includes('closed') || h.action.includes('completed'));
      if (!completedEntry) return true; // Assume on-time if no completion entry
      const completedDate = new Date(completedEntry.performedAt);
      const dueDate = new Date(a.dueDate);
      return completedDate <= dueDate;
    });

    // External audits processed
    const externalProcessed = filteredAudits.filter(a => a.type === 'external' && a.currentPhase === 'closed');

    // Calculate rates
    const overdueRate = openAudits.length > 0 ? (overdueAudits.length / openAudits.length) * 100 : 0;
    const onTimeRate = completedAudits.length > 0 ? (onTimeCompletions.length / completedAudits.length) * 100 : 0;
    const capRate = externalProcessed.length > 0 
      ? (capRequired.length / (externalProcessed.length + capRequired.length)) * 100 
      : 0;

    // Average cycle time (for completed audits)
    const cycleTimes = completedAudits.map(a => {
      const created = new Date(a.createdAt);
      const completedEntry = a.history.find(h => h.action.includes('closed') || h.action.includes('completed'));
      const completed = completedEntry ? new Date(completedEntry.performedAt) : new Date();
      return Math.ceil((completed.getTime() - created.getTime()) / (1000 * 60 * 60 * 24));
    });
    const avgCycleTime = cycleTimes.length > 0 
      ? Math.round(cycleTimes.reduce((a, b) => a + b, 0) / cycleTimes.length) 
      : 0;

    return {
      openCount: openAudits.length,
      overdueCount: overdueAudits.length,
      pendingReviewCount: pendingReview.length,
      qaReviewCount: qaReview.length,
      capRequiredCount: capRequired.length,
      overdueRate: Math.round(overdueRate * 10) / 10,
      onTimeRate: Math.round(onTimeRate * 10) / 10,
      capRate: Math.round(capRate * 10) / 10,
      avgCycleTime,
    };
  }, [filteredAudits]);

  // Helper to determine if metric meets target
  const meetsTarget = (actual: number, target: number, type: 'below' | 'above') => {
    return type === 'below' ? actual <= target : actual >= target;
  };

  // For Staff, show minimal metrics
  if (currentUser.role === 'staff') {
    return (
      <div className="grid grid-cols-2 gap-4 mb-6">
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-status-info-bg flex items-center justify-center">
                <FileSearch className="h-5 w-5 text-status-info" />
              </div>
              <div>
                <p className="text-2xl font-bold">{metrics.openCount}</p>
                <p className="text-sm text-muted-foreground">My Open</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-status-error-bg flex items-center justify-center">
                <AlertCircle className="h-5 w-5 text-status-error" />
              </div>
              <div>
                <p className="text-2xl font-bold">{metrics.overdueCount}</p>
                <p className="text-sm text-muted-foreground">My Overdue</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4 mb-8">
      {/* Filters */}
      <div className="flex items-center gap-3">
        <Select value={dateRange} onValueChange={(v) => setDateRange(v as typeof dateRange)}>
          <SelectTrigger className="w-[130px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7d">Last 7 days</SelectItem>
            <SelectItem value="30d">Last 30 days</SelectItem>
            <SelectItem value="90d">Last 90 days</SelectItem>
            <SelectItem value="all">All time</SelectItem>
          </SelectContent>
        </Select>

        <Select value={typeFilter} onValueChange={(v) => setTypeFilter(v as typeof typeFilter)}>
          <SelectTrigger className="w-[130px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="internal">Internal</SelectItem>
            <SelectItem value="external">External</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Key Metrics (Success Metrics with Targets) */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {/* Overdue Rate */}
        <Card className="border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center justify-between">
              Overdue Rate
              {meetsTarget(metrics.overdueRate, metricsPolicy.overdueRateTarget, 'below') ? (
                <Badge variant="outline" className="bg-status-success-bg text-status-success border-status-success/20">
                  <CheckCircle2 className="h-3 w-3 mr-1" />
                  On Target
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-status-error-bg text-status-error border-status-error/20">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  Above Target
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold">{metrics.overdueRate}%</span>
              <span className="text-sm text-muted-foreground">/ {metricsPolicy.overdueRateTarget}% target</span>
            </div>
            <Progress 
              value={Math.min(metrics.overdueRate, 100)} 
              className="mt-2 h-2"
            />
          </CardContent>
        </Card>

        {/* On-Time Completion */}
        <Card className="border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center justify-between">
              On-Time Completion
              {meetsTarget(metrics.onTimeRate, metricsPolicy.onTimeCompletionTarget, 'above') ? (
                <Badge variant="outline" className="bg-status-success-bg text-status-success border-status-success/20">
                  <CheckCircle2 className="h-3 w-3 mr-1" />
                  On Target
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-status-error-bg text-status-error border-status-error/20">
                  <TrendingDown className="h-3 w-3 mr-1" />
                  Below Target
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold">{metrics.onTimeRate}%</span>
              <span className="text-sm text-muted-foreground">/ {metricsPolicy.onTimeCompletionTarget}% target</span>
            </div>
            <Progress 
              value={metrics.onTimeRate} 
              className="mt-2 h-2"
            />
          </CardContent>
        </Card>

        {/* Avg Cycle Time */}
        <Card className="border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center justify-between">
              Avg Cycle Time
              {meetsTarget(metrics.avgCycleTime, metricsPolicy.cycleTimeTargetDays, 'below') ? (
                <Badge variant="outline" className="bg-status-success-bg text-status-success border-status-success/20">
                  <CheckCircle2 className="h-3 w-3 mr-1" />
                  On Target
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-status-warning-bg text-status-warning border-status-warning/20">
                  <Clock className="h-3 w-3 mr-1" />
                  Slow
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold">{metrics.avgCycleTime}</span>
              <span className="text-sm text-muted-foreground">days / {metricsPolicy.cycleTimeTargetDays} target</span>
            </div>
            <Progress 
              value={Math.min((metrics.avgCycleTime / metricsPolicy.cycleTimeTargetDays) * 100, 100)} 
              className="mt-2 h-2"
            />
          </CardContent>
        </Card>

        {/* CAP Rate (External) */}
        {(permissions.canViewAllAudits || currentUser.role === 'compliance_head') && (
          <Card className="border-border/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                CAP Rate (External)
                {meetsTarget(metrics.capRate, metricsPolicy.capRequiredRateTarget, 'below') ? (
                  <Badge variant="outline" className="bg-status-success-bg text-status-success border-status-success/20">
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                    On Target
                  </Badge>
                ) : (
                  <Badge variant="outline" className="bg-status-warning-bg text-status-warning border-status-warning/20">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    High
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-bold">{metrics.capRate}%</span>
                <span className="text-sm text-muted-foreground">/ {metricsPolicy.capRequiredRateTarget}% target</span>
              </div>
              <Progress 
                value={Math.min(metrics.capRate, 100)} 
                className="mt-2 h-2"
              />
            </CardContent>
          </Card>
        )}
      </div>

      {/* Status Tiles (KPI Counts) */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{metrics.openCount}</p>
                <p className="text-xs text-muted-foreground">Open Audits</p>
              </div>
              <FileSearch className="h-5 w-5 text-status-info" />
            </div>
          </CardContent>
        </Card>

        <Card className={cn(
          "border-border/50",
          metrics.overdueCount > 0 && "border-status-error/50 bg-status-error/5"
        )}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{metrics.overdueCount}</p>
                <p className="text-xs text-muted-foreground">Overdue</p>
              </div>
              <AlertCircle className={cn(
                "h-5 w-5",
                metrics.overdueCount > 0 ? "text-status-error" : "text-muted-foreground"
              )} />
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{metrics.pendingReviewCount}</p>
                <p className="text-xs text-muted-foreground">Pending Review</p>
              </div>
              <Clock className="h-5 w-5 text-status-warning" />
            </div>
          </CardContent>
        </Card>

        {(permissions.canViewAllAudits || currentUser.role === 'compliance_head') && (
          <Card className="border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold">{metrics.qaReviewCount}</p>
                  <p className="text-xs text-muted-foreground">QA Review</p>
                </div>
                <ShieldCheck className="h-5 w-5 text-status-pending" />
              </div>
            </CardContent>
          </Card>
        )}

        {(permissions.canViewAllAudits || currentUser.role === 'compliance_head') && (
          <Card className={cn(
            "border-border/50",
            metrics.capRequiredCount > 0 && "border-status-warning/50 bg-status-warning/5"
          )}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold">{metrics.capRequiredCount}</p>
                  <p className="text-xs text-muted-foreground">CAP Required</p>
                </div>
                <AlertTriangle className="h-5 w-5 text-status-warning" />
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
