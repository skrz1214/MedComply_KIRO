import { useAdmin } from '@/contexts/AdminContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Users, Info } from 'lucide-react';
import { InfoHint } from './InfoHint';
import { toast } from '@/hooks/use-toast';
import { ROLE_LABELS, UserRoleV2 } from '@/types/admin';

const ROLE_OPTIONS: UserRoleV2[] = ['staff', 'department_head', 'compliance_head', 'admin'];

export function DefaultAssigneesTab() {
  const { settings, updateDefaultAssignee, addChangeLog } = useAdmin();

  const phaseLabel = (code: string) =>
    settings.phases.find((p) => p.code === code)?.label ?? code.replace(/_/g, ' ');

  const handleChange = (
    phase: string,
    field: 'internalRole' | 'externalRole',
    value: UserRoleV2,
    previous: UserRoleV2
  ) => {
    updateDefaultAssignee(phase, { [field]: value });
    addChangeLog({
      userId: '4',
      userName: 'Admin',
      settingArea: 'Default Assignees',
      changeType: 'update',
      beforeValue: previous,
      afterValue: value,
      description: `Changed ${field === 'internalRole' ? 'internal' : 'external'} default for ${phaseLabel(phase)} → ${ROLE_LABELS[value]}`,
    });
    toast({ title: 'Default updated' });
  };

  return (
    <div className="space-y-6">
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            Default Assignees
            <InfoHint content="Choose a default assignee role for each status. The system pre-fills the assignee field when an audit reaches that status, but anyone can be picked manually — these are suggestions, not restrictions." />
          </CardTitle>
          <CardDescription>
            Pre-fill the assignee picker when an audit enters each phase. Users can always override the default and assign anyone.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/50 border border-border/50">
            <Info className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
            <p className="text-sm text-muted-foreground">
              These defaults are <strong className="text-foreground">suggestions only</strong>. When an audit enters a phase, the picker is pre-filled with a user matching the default role — but the assignee can be changed to any user at any time.
            </p>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[40%]">Status</TableHead>
                <TableHead>Internal Audit Default</TableHead>
                <TableHead>External Audit Default</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {settings.defaultAssignees.map((row) => (
                <TableRow key={row.phase}>
                  <TableCell className="font-medium">{phaseLabel(row.phase)}</TableCell>
                  <TableCell>
                    <Select
                      value={row.internalRole}
                      onValueChange={(value: UserRoleV2) =>
                        handleChange(row.phase, 'internalRole', value, row.internalRole)
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {ROLE_OPTIONS.map((role) => (
                          <SelectItem key={role} value={role}>
                            {ROLE_LABELS[role]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Select
                      value={row.externalRole}
                      onValueChange={(value: UserRoleV2) =>
                        handleChange(row.phase, 'externalRole', value, row.externalRole)
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {ROLE_OPTIONS.map((role) => (
                          <SelectItem key={role} value={role}>
                            {ROLE_LABELS[role]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
