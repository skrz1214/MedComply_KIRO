import { useState } from 'react';
import { useAdmin } from '@/contexts/AdminContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Target, Percent, Clock, TrendingUp, AlertTriangle, Save, RotateCcw } from 'lucide-react';
import { toast } from 'sonner';
import { MetricsPolicy } from '@/types/admin';
import { InfoHint } from './InfoHint';

export function MetricsTargetsTab() {
  const { settings, updateSettings, logChange } = useAdmin();
  const [localPolicy, setLocalPolicy] = useState<MetricsPolicy>(settings.metricsPolicy);
  const [hasChanges, setHasChanges] = useState(false);

  const handleChange = (field: keyof MetricsPolicy, value: number) => {
    setLocalPolicy(prev => ({ ...prev, [field]: value }));
    setHasChanges(true);
  };

  const handlePriorityChange = (priority: 'low' | 'medium' | 'high' | 'critical', value: number) => {
    setLocalPolicy(prev => ({
      ...prev,
      cycleTimeByPriority: {
        ...prev.cycleTimeByPriority,
        [priority]: value,
      },
    }));
    setHasChanges(true);
  };

  const handleSave = () => {
    const beforeValue = JSON.stringify(settings.metricsPolicy);
    updateSettings({ metricsPolicy: localPolicy });
    logChange({
      settingArea: 'Metrics Targets',
      changeType: 'update',
      beforeValue,
      afterValue: JSON.stringify(localPolicy),
      description: 'Updated metrics targets configuration',
    });
    setHasChanges(false);
    toast.success('Metrics targets saved');
  };

  const handleReset = () => {
    setLocalPolicy(settings.metricsPolicy);
    setHasChanges(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="border-border/50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Target className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="flex items-center gap-2">
                  Metrics Targets
                  <InfoHint content="Org-wide KPI thresholds that drive the green/amber/red badges on every dashboard. Changes apply organization-wide on Save." />
                </CardTitle>
                <CardDescription>Configure target thresholds for dashboard metrics</CardDescription>
              </div>
            </div>
            {hasChanges && (
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleReset} className="gap-2">
                  <RotateCcw className="h-4 w-4" />
                  Reset
                </Button>
                <Button size="sm" onClick={handleSave} className="gap-2">
                  <Save className="h-4 w-4" />
                  Save Changes
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Overdue Rate Target */}
        <Card className="border-border/50">
          <CardHeader className="pb-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-status-error" />
              <CardTitle className="text-base flex items-center gap-1.5">
                Overdue Rate Target
                <InfoHint content="Maximum acceptable percentage of audits past their due date. The dashboard tile turns red when actual exceeds this number." />
              </CardTitle>
            </div>
            <CardDescription>Target maximum percentage of audits that are overdue</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <Label htmlFor="overdueRate">Target (%)</Label>
                <div className="flex items-center gap-2 mt-1.5">
                  <Input
                    id="overdueRate"
                    type="number"
                    min={0}
                    max={100}
                    value={localPolicy.overdueRateTarget}
                    onChange={(e) => handleChange('overdueRateTarget', Number(e.target.value))}
                  />
                  <Percent className="h-4 w-4 text-muted-foreground" />
                </div>
              </div>
              <Badge variant="outline" className="mt-6">
                Target: &lt; {localPolicy.overdueRateTarget}%
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* On-Time Completion Target */}
        <Card className="border-border/50">
          <CardHeader className="pb-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-status-success" />
              <CardTitle className="text-base flex items-center gap-1.5">
                On-Time Completion Target
                <InfoHint content="Minimum acceptable percentage of audits closed on or before their due date. Tile turns red below this threshold." />
              </CardTitle>
            </div>
            <CardDescription>Target percentage of audits completed by due date</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <Label htmlFor="onTimeRate">Target (%)</Label>
                <div className="flex items-center gap-2 mt-1.5">
                  <Input
                    id="onTimeRate"
                    type="number"
                    min={0}
                    max={100}
                    value={localPolicy.onTimeCompletionTarget}
                    onChange={(e) => handleChange('onTimeCompletionTarget', Number(e.target.value))}
                  />
                  <Percent className="h-4 w-4 text-muted-foreground" />
                </div>
              </div>
              <Badge variant="outline" className="mt-6">
                Target: &gt; {localPolicy.onTimeCompletionTarget}%
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Internal Review Turnaround */}
        <Card className="border-border/50">
          <CardHeader className="pb-4">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-status-info" />
              <CardTitle className="text-base flex items-center gap-1.5">
                Internal Review Turnaround
                <InfoHint content="Target days from audit submission to the internal reviewer's decision (approve / reject). Drives the 'Awaiting Review' tile on Dept Head dashboards." />
              </CardTitle>
            </div>
            <CardDescription>Target days from submission to review decision</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <Label htmlFor="reviewTurnaround">Target (days)</Label>
                <Input
                  id="reviewTurnaround"
                  type="number"
                  min={1}
                  value={localPolicy.internalReviewTurnaroundDays}
                  onChange={(e) => handleChange('internalReviewTurnaroundDays', Number(e.target.value))}
                  className="mt-1.5"
                />
              </div>
              <Badge variant="outline" className="mt-6">
                Target: ≤ {localPolicy.internalReviewTurnaroundDays} days
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* CAP Required Rate */}
        <Card className="border-border/50">
          <CardHeader className="pb-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-status-warning" />
              <CardTitle className="text-base flex items-center gap-1.5">
                CAP Required Rate (External)
                <InfoHint content="Maximum acceptable percentage of external audits that result in a Corrective Action Plan. A high CAP rate signals systemic compliance gaps." />
              </CardTitle>
            </div>
            <CardDescription>Target maximum CAP rate for external audits</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <Label htmlFor="capRate">Target (%)</Label>
                <div className="flex items-center gap-2 mt-1.5">
                  <Input
                    id="capRate"
                    type="number"
                    min={0}
                    max={100}
                    value={localPolicy.capRequiredRateTarget}
                    onChange={(e) => handleChange('capRequiredRateTarget', Number(e.target.value))}
                  />
                  <Percent className="h-4 w-4 text-muted-foreground" />
                </div>
              </div>
              <Badge variant="outline" className="mt-6">
                Target: &lt; {localPolicy.capRequiredRateTarget}%
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Cycle Time by Priority */}
      <Card className="border-border/50">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            <CardTitle className="text-base flex items-center gap-1.5">
              Cycle Time Targets by Priority
              <InfoHint content="Target days from creation to closure, broken down by audit priority. Higher-priority audits should have shorter targets." />
            </CardTitle>
          </div>
          <CardDescription>Target days to complete audits from creation to completion</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div>
              <Label htmlFor="cycleLow" className="flex items-center gap-2">
                <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">Low</Badge>
              </Label>
              <div className="flex items-center gap-2 mt-2">
                <Input
                  id="cycleLow"
                  type="number"
                  min={1}
                  value={localPolicy.cycleTimeByPriority.low}
                  onChange={(e) => handlePriorityChange('low', Number(e.target.value))}
                />
                <span className="text-sm text-muted-foreground">days</span>
              </div>
            </div>
            <div>
              <Label htmlFor="cycleMedium" className="flex items-center gap-2">
                <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/20">Medium</Badge>
              </Label>
              <div className="flex items-center gap-2 mt-2">
                <Input
                  id="cycleMedium"
                  type="number"
                  min={1}
                  value={localPolicy.cycleTimeByPriority.medium}
                  onChange={(e) => handlePriorityChange('medium', Number(e.target.value))}
                />
                <span className="text-sm text-muted-foreground">days</span>
              </div>
            </div>
            <div>
              <Label htmlFor="cycleHigh" className="flex items-center gap-2">
                <Badge variant="outline" className="bg-orange-500/10 text-orange-600 border-orange-500/20">High</Badge>
              </Label>
              <div className="flex items-center gap-2 mt-2">
                <Input
                  id="cycleHigh"
                  type="number"
                  min={1}
                  value={localPolicy.cycleTimeByPriority.high}
                  onChange={(e) => handlePriorityChange('high', Number(e.target.value))}
                />
                <span className="text-sm text-muted-foreground">days</span>
              </div>
            </div>
            <div>
              <Label htmlFor="cycleCritical" className="flex items-center gap-2">
                <Badge variant="outline" className="bg-red-500/10 text-red-600 border-red-500/20">Critical</Badge>
              </Label>
              <div className="flex items-center gap-2 mt-2">
                <Input
                  id="cycleCritical"
                  type="number"
                  min={1}
                  value={localPolicy.cycleTimeByPriority.critical}
                  onChange={(e) => handlePriorityChange('critical', Number(e.target.value))}
                />
                <span className="text-sm text-muted-foreground">days</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
