import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Package, Gauge, ShieldAlert, Link2, Archive, FileCheck, Save } from 'lucide-react';
import { toast } from 'sonner';
import { InfoHint } from './InfoHint';

export function AuditPackTab() {
  const [thresholds, setThresholds] = useState({ green: 85, amber: 70 });
  const [phiAdminOnly, setPhiAdminOnly] = useState(true);
  const [requirePhiJustification, setRequirePhiJustification] = useState(true);
  const [shareLinkTtlDays, setShareLinkTtlDays] = useState(7);
  const [shareLinkMaxTtlDays, setShareLinkMaxTtlDays] = useState(30);
  const [requireSharePassword, setRequireSharePassword] = useState(true);
  const [retentionDays, setRetentionDays] = useState(2555); // ~7 years HIPAA
  const [autoPurge, setAutoPurge] = useState(false);
  const [requireSha256, setRequireSha256] = useState(true);
  const [includeManifest, setIncludeManifest] = useState(true);
  const [defaultScopeNote, setDefaultScopeNote] = useState(
    'Default scope: last 12 months, all departments, all controls, exclude PHI.',
  );

  const handleSave = () => {
    toast.success('Audit Pack settings saved');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5 text-primary" />
            Audit Pack Configuration
            <InfoHint content="Org-wide defaults for the Audit Pack export feature: scope templates, readiness scoring, PHI safeguards, share-link policy, and retention. Overridable per-export by admins." />
          </CardTitle>
          <CardDescription>
            Configure organization-wide defaults for HIPAA-aligned Audit Pack exports, readiness scoring,
            PHI gating, share links, and retention.
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Readiness Score Thresholds */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Gauge className="h-5 w-5 text-primary" />
            Readiness Score Thresholds
            <InfoHint content="The Readiness Score (0-100%) summarizes whether an audit has the controls and evidence required for export. These thresholds set the green/amber/red bands." />
          </CardTitle>
          <CardDescription>
            Define the score bands used in the Readiness Hero and Preview step.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="green-threshold" className="flex items-center gap-1.5">
                <Badge className="bg-success text-success-foreground mr-2">Green</Badge>
                ≥ %
                <InfoHint content="Audits at or above this score are considered audit-ready and can be exported without warnings." />
              </Label>
              <Input
                id="green-threshold"
                type="number"
                min={0}
                max={100}
                value={thresholds.green}
                onChange={(e) => setThresholds({ ...thresholds, green: Number(e.target.value) })}
              />
              <p className="text-xs text-muted-foreground">Audit-ready, safe to export.</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="amber-threshold" className="flex items-center gap-1.5">
                <Badge variant="secondary" className="mr-2">Amber</Badge>
                ≥ %
                <InfoHint content="Audits between Amber and Green show warnings but can still be exported. Recommended to fix gaps first." />
              </Label>
              <Input
                id="amber-threshold"
                type="number"
                min={0}
                max={100}
                value={thresholds.amber}
                onChange={(e) => setThresholds({ ...thresholds, amber: Number(e.target.value) })}
              />
              <p className="text-xs text-muted-foreground">Address gaps before exporting.</p>
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-1.5">
                <Badge variant="destructive" className="mr-2">Red</Badge>
                Below Amber
                <InfoHint content="Audits below the Amber threshold are blocked from export unless an Admin explicitly overrides — captured in the audit trail." />
              </Label>
              <Input value={`< ${thresholds.amber}%`} disabled />
              <p className="text-xs text-muted-foreground">Export blocked unless overridden by Admin.</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* PHI Gating */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <ShieldAlert className="h-5 w-5 text-primary" />
            PHI Inclusion Gating
            <InfoHint content="Protected Health Information safeguards. Controls who can include PHI in an exported pack and what justification is required." />
          </CardTitle>
          <CardDescription>HIPAA controls for including Protected Health Information in exports.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
            <div className="space-y-0.5">
              <Label className="flex items-center gap-1.5">
                Restrict PHI Inclusion to Admins Only
                <InfoHint content="When ON, only the Admin role sees the 'Include PHI' toggle in the wizard. Other roles export PHI-redacted packs only." />
              </Label>
              <p className="text-sm text-muted-foreground">
                Only Admin role can toggle "Include PHI" in the Audit Pack wizard.
              </p>
            </div>
            <Switch checked={phiAdminOnly} onCheckedChange={setPhiAdminOnly} />
          </div>
          <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
            <div className="space-y-0.5">
              <Label className="flex items-center gap-1.5">
                Require Justification for PHI Inclusion
                <InfoHint content="Forces the user to type a written reason whenever PHI is included. The justification is permanently logged in the audit trail." />
              </Label>
              <p className="text-sm text-muted-foreground">
                Force a written reason captured in the audit trail when PHI is included.
              </p>
            </div>
            <Switch checked={requirePhiJustification} onCheckedChange={setRequirePhiJustification} />
          </div>
        </CardContent>
      </Card>

      {/* Share Links */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Link2 className="h-5 w-5 text-primary" />
            Share Link Defaults
            <InfoHint content="Read-only, time-limited links emailed to external auditors. Defaults here apply to every share link created — users can shorten the TTL but never extend past the maximum." />
          </CardTitle>
          <CardDescription>Time-limited, read-only links shared with external auditors.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="ttl" className="flex items-center gap-1.5">
                Default TTL (days)
                <InfoHint content="The pre-filled lifetime when a user creates a share link. Recommended: 7 days for active engagements." />
              </Label>
              <Input
                id="ttl"
                type="number"
                min={1}
                max={shareLinkMaxTtlDays}
                value={shareLinkTtlDays}
                onChange={(e) => setShareLinkTtlDays(Number(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ttl-max" className="flex items-center gap-1.5">
                Maximum Allowed TTL (days)
                <InfoHint content="Hard ceiling. Users cannot create a share link that lives longer than this. Keep tight (≤30 days) to limit data exposure." />
              </Label>
              <Input
                id="ttl-max"
                type="number"
                min={1}
                value={shareLinkMaxTtlDays}
                onChange={(e) => setShareLinkMaxTtlDays(Number(e.target.value))}
              />
            </div>
          </div>
          <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
            <div className="space-y-0.5">
              <Label className="flex items-center gap-1.5">
                Require Password on Share Links
                <InfoHint content="Generates a one-time password alongside the link, delivered out-of-band (recommended via SMS or phone). Adds a second factor for HIPAA-grade access control." />
              </Label>
              <p className="text-sm text-muted-foreground">
                Recipients must enter a one-time password to access shared packs.
              </p>
            </div>
            <Switch checked={requireSharePassword} onCheckedChange={setRequireSharePassword} />
          </div>
        </CardContent>
      </Card>

      {/* Retention */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Archive className="h-5 w-5 text-primary" />
            Export Retention Policy
            <InfoHint content="How long generated Audit Packs remain downloadable from Export History before being auto-purged. Manifest records (hash + metadata) are always retained for the full audit trail." />
          </CardTitle>
          <CardDescription>Retention for generated Audit Packs in Export History.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="retention" className="flex items-center gap-1.5">
              Retention period (days)
              <InfoHint content="HIPAA recordkeeping baseline is 6 years (~2190 days). 2555 days (~7 years) is a common conservative default that also satisfies CMS." />
            </Label>
            <Input
              id="retention"
              type="number"
              min={1}
              value={retentionDays}
              onChange={(e) => setRetentionDays(Number(e.target.value))}
            />
            <p className="text-xs text-muted-foreground">
              Default 2555 days (~7 years) per HIPAA recordkeeping guidance.
            </p>
          </div>
          <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
            <div className="space-y-0.5">
              <Label className="flex items-center gap-1.5">
                Auto-purge Expired Packs
                <InfoHint content="When ON, expired pack files are permanently deleted from storage. The manifest entry (hash, generator, scope) is retained even after purge so the audit trail stays intact." />
              </Label>
              <p className="text-sm text-muted-foreground">
                Permanently delete packs after retention period elapses (manifest record retained).
              </p>
            </div>
            <Switch checked={autoPurge} onCheckedChange={setAutoPurge} />
          </div>
        </CardContent>
      </Card>

      {/* Integrity */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <FileCheck className="h-5 w-5 text-primary" />
            Bundle Integrity
            <InfoHint content="Cryptographic and structural guarantees applied to every Audit Pack. Used by external auditors to verify the bundle has not been altered after export." />
          </CardTitle>
          <CardDescription>Cryptographic and manifest requirements for every export.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
            <div className="space-y-0.5">
              <Label className="flex items-center gap-1.5">
                Stamp SHA-256 on Every Export
                <InfoHint content="Computes an immutable SHA-256 hash of the final bundle and stores it on the manifest. Auditors can re-hash the file and compare to verify authenticity." />
              </Label>
              <p className="text-sm text-muted-foreground">
                Generate and store an immutable SHA-256 hash for the bundle.
              </p>
            </div>
            <Switch checked={requireSha256} onCheckedChange={setRequireSha256} />
          </div>
          <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
            <div className="space-y-0.5">
              <Label className="flex items-center gap-1.5">
                Include Manifest &amp; Evidence Index
                <InfoHint content="Bundles a machine-readable JSON manifest plus a human-readable PDF evidence index inside the ZIP. Strongly recommended — auditors expect both." />
              </Label>
              <p className="text-sm text-muted-foreground">
                Bundle a JSON manifest and PDF evidence index inside every Audit Pack.
              </p>
            </div>
            <Switch checked={includeManifest} onCheckedChange={setIncludeManifest} />
          </div>
        </CardContent>
      </Card>

      {/* Default Scope Template */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Package className="h-5 w-5 text-primary" />
            Default Scope Template
            <InfoHint content="Pre-filled scope description shown in Step 1 of the Audit Pack Wizard. Users can edit per export — this just saves typing for common engagements." />
          </CardTitle>
          <CardDescription>
            Pre-filled scope description shown in Step 1 of the Audit Pack Wizard.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Textarea
            value={defaultScopeNote}
            onChange={(e) => setDefaultScopeNote(e.target.value)}
            rows={3}
          />
        </CardContent>
      </Card>

      <Separator />

      <div className="flex justify-end">
        <Button onClick={handleSave} className="gap-2">
          <Save className="h-4 w-4" />
          Save Audit Pack Settings
        </Button>
      </div>
    </div>
  );
}
