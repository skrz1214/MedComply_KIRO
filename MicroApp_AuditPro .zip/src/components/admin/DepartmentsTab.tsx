import { useState } from 'react';
import { useAdmin } from '@/contexts/AdminContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Building2, Plus, Pencil, Trash2, Crown } from 'lucide-react';
import { InfoHint } from './InfoHint';
import { toast } from '@/hooks/use-toast';

export function DepartmentsTab() {
  const { settings, addDepartment, updateDepartment, deleteDepartment, addChangeLog } = useAdmin();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newDept, setNewDept] = useState({ name: '', code: '', isComplianceOwner: false });

  const handleAddDepartment = () => {
    if (!newDept.name || !newDept.code) {
      toast({ title: 'Error', description: 'Please fill in all required fields', variant: 'destructive' });
      return;
    }
    addDepartment(newDept);
    addChangeLog({
      userId: '4',
      userName: 'Admin',
      settingArea: 'Departments',
      changeType: 'create',
      beforeValue: '',
      afterValue: JSON.stringify(newDept),
      description: `Added department: ${newDept.name}`,
    });
    setNewDept({ name: '', code: '', isComplianceOwner: false });
    setIsAddDialogOpen(false);
    toast({ title: 'Success', description: 'Department added successfully' });
  };

  const handleToggleComplianceOwner = (id: string, currentValue: boolean) => {
    updateDepartment(id, { isComplianceOwner: !currentValue });
    toast({ title: 'Updated', description: 'Department compliance owner status updated' });
  };

  const handleDeleteDepartment = (id: string, name: string) => {
    deleteDepartment(id);
    addChangeLog({
      userId: '4',
      userName: 'Admin',
      settingArea: 'Departments',
      changeType: 'delete',
      beforeValue: name,
      afterValue: '',
      description: `Deleted department: ${name}`,
    });
    toast({ title: 'Deleted', description: 'Department removed successfully' });
  };

  return (
    <div className="space-y-6">
      <Card className="border-border/50">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              Department Management
              <InfoHint content="Departments group audit items by organizational unit. Routing rules, status assignees, and dashboard scopes all key off departments defined here." />
            </CardTitle>
            <CardDescription>Manage departments and designate compliance ownership</CardDescription>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Add Department
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Department</DialogTitle>
                <DialogDescription>Create a new department for audit management</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="dept-name" className="flex items-center gap-1.5">
                    Department Name
                    <InfoHint content="Human-readable name shown in audit forms, dashboards, and reports (e.g. 'Emergency Department')." />
                  </Label>
                  <Input
                    id="dept-name"
                    value={newDept.name}
                    onChange={(e) => setNewDept({ ...newDept, name: e.target.value })}
                    placeholder="e.g., Emergency Department"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dept-code" className="flex items-center gap-1.5">
                    Department Code
                    <InfoHint content="Short uppercase identifier (max 5 chars) used in audit IDs, badges, and integration field mappings (e.g. 'ED', 'HR')." />
                  </Label>
                  <Input
                    id="dept-code"
                    value={newDept.code}
                    onChange={(e) => setNewDept({ ...newDept, code: e.target.value.toUpperCase() })}
                    placeholder="e.g., ED"
                    maxLength={5}
                  />
                </div>
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                  <div className="space-y-0.5">
                    <Label className="flex items-center gap-1.5">
                      Compliance Owner Department
                      <InfoHint content="Designates this department as the QA/Compliance owner. External audits route here for final closure determination by the Compliance Head role." />
                    </Label>
                    <p className="text-sm text-muted-foreground">Receives external audits for closure</p>
                  </div>
                  <Switch
                    checked={newDept.isComplianceOwner}
                    onCheckedChange={(checked) => setNewDept({ ...newDept, isComplianceOwner: checked })}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleAddDepartment}>Add Department</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Department Name</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>
                  <span className="inline-flex items-center gap-1.5">
                    Compliance Owner
                    <InfoHint content="A crown icon marks the QA-owning department. Only one is typical, but multiple are supported for federated organizations." />
                  </span>
                </TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {settings.departments.map((dept) => (
                <TableRow key={dept.id}>
                  <TableCell className="font-medium">{dept.name}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{dept.code}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={dept.isComplianceOwner}
                        onCheckedChange={() => handleToggleComplianceOwner(dept.id, dept.isComplianceOwner)}
                      />
                      {dept.isComplianceOwner && (
                        <Crown className="h-4 w-4 text-amber-500" />
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {new Date(dept.createdAt).toLocaleDateString()}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon">
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive hover:text-destructive"
                        onClick={() => handleDeleteDepartment(dept.id, dept.name)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
