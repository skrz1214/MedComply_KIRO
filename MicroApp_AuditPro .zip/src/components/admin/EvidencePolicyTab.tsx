import { useAdmin } from '@/contexts/AdminContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Paperclip, Plus, X } from 'lucide-react';
import { InfoHint } from './InfoHint';
import { toast } from '@/hooks/use-toast';
import { useState } from 'react';

export function EvidencePolicyTab() {
  const { settings, updateEvidencePolicy, addChangeLog } = useAdmin();
  const [newFileType, setNewFileType] = useState('');

  const addFileType = () => {
    if (!newFileType) return;
    const types = [...settings.evidencePolicy.allowedFileTypes, newFileType.toLowerCase()];
    updateEvidencePolicy({ allowedFileTypes: types });
    addChangeLog({
      userId: '4',
      userName: 'Admin',
      settingArea: 'Evidence Policy',
      changeType: 'update',
      beforeValue: settings.evidencePolicy.allowedFileTypes.join(', '),
      afterValue: types.join(', '),
      description: `Added file type: ${newFileType}`,
    });
    setNewFileType('');
    toast({ title: 'Added', description: `File type ${newFileType} added` });
  };

  const removeFileType = (type: string) => {
    const types = settings.evidencePolicy.allowedFileTypes.filter((t) => t !== type);
    updateEvidencePolicy({ allowedFileTypes: types });
    toast({ title: 'Removed', description: `File type ${type} removed` });
  };

  const toggleRequiredPhase = (phase: string) => {
    const phases = settings.evidencePolicy.requiredPhases.includes(phase)
      ? settings.evidencePolicy.requiredPhases.filter((p) => p !== phase)
      : [...settings.evidencePolicy.requiredPhases, phase];
    updateEvidencePolicy({ requiredPhases: phases });
    toast({ title: 'Updated' });
  };

  return (
    <div className="space-y-6">
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Paperclip className="h-5 w-5 text-primary" />
            Evidence & Attachment Policy
            <InfoHint content="Org-wide rules for what files users can attach as evidence at any status of an audit. Enforced on upload — non-conforming files are rejected." />
          </CardTitle>
          <CardDescription>Configure file upload policies and requirements</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* File Types */}
          <div className="space-y-3">
            <Label className="flex items-center gap-1.5">
              Allowed File Types
              <InfoHint content="Whitelist of file extensions accepted as evidence. Anything not in this list is blocked at upload to reduce malware and PHI leakage risk." />
            </Label>
            <div className="flex flex-wrap gap-2">
              {settings.evidencePolicy.allowedFileTypes.map((type) => (
                <Badge key={type} variant="secondary" className="gap-1">
                  .{type}
                  <button
                    onClick={() => removeFileType(type)}
                    className="ml-1 hover:text-destructive"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                value={newFileType}
                onChange={(e) => setNewFileType(e.target.value.replace('.', ''))}
                placeholder="e.g., csv"
                className="max-w-[150px]"
              />
              <Button variant="outline" size="sm" onClick={addFileType}>
                <Plus className="h-4 w-4 mr-1" />
                Add
              </Button>
            </div>
          </div>

          {/* File Limits */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="max-size" className="flex items-center gap-1.5">
                Max File Size (MB)
                <InfoHint content="Per-file ceiling. Larger files are rejected. Recommended: 25 MB for typical PDFs and screenshots; raise only if you regularly attach video or imaging." />
              </Label>
              <Input
                id="max-size"
                type="number"
                value={settings.evidencePolicy.maxFileSize}
                onChange={(e) => {
                  updateEvidencePolicy({ maxFileSize: parseInt(e.target.value) || 25 });
                  toast({ title: 'Updated' });
                }}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="max-files" className="flex items-center gap-1.5">
                Max Files Per Status
                <InfoHint content="Caps how many evidence items a single user can attach in one status. Prevents accidental dumps and keeps the Audit Pack tidy." />
              </Label>
              <Input
                id="max-files"
                type="number"
                value={settings.evidencePolicy.maxFilesPerPhase}
                onChange={(e) => {
                  updateEvidencePolicy({ maxFilesPerPhase: parseInt(e.target.value) || 20 });
                  toast({ title: 'Updated' });
                }}
              />
            </div>
          </div>

          {/* Required Statuses */}
          <div className="space-y-3">
            <Label className="flex items-center gap-1.5">
              Statuses Requiring Evidence
              <InfoHint content="For each toggle ON, the audit cannot leave that status until at least one evidence file is attached. Pairs with the 'Required Evidence' setting on each Status." />
            </Label>
            <div className="space-y-2">
              {settings.phases.map((phase) => (
                <div key={phase.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <span>{phase.label}</span>
                  <Switch
                    checked={settings.evidencePolicy.requiredPhases.includes(phase.code)}
                    onCheckedChange={() => toggleRequiredPhase(phase.code)}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Active Toggle */}
          <div className="flex items-center justify-between p-4 rounded-lg border">
            <div className="space-y-0.5">
              <Label className="flex items-center gap-1.5">
                Policy Active
                <InfoHint content="Master switch. When OFF, no evidence rules are enforced — useful for staging environments but should remain ON in production." />
              </Label>
              <p className="text-sm text-muted-foreground">Enable or disable evidence policy enforcement</p>
            </div>
            <Switch
              checked={settings.evidencePolicy.isActive}
              onCheckedChange={(checked) => {
                updateEvidencePolicy({ isActive: checked });
                toast({ title: checked ? 'Policy Enabled' : 'Policy Disabled' });
              }}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
