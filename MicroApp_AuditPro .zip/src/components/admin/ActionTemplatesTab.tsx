import { useState } from 'react';
import { useAdmin } from '@/contexts/AdminContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { FileText, Plus, Trash2, GripVertical, Check } from 'lucide-react';
import { InfoHint } from './InfoHint';
import { toast } from '@/hooks/use-toast';

export function ActionTemplatesTab() {
  const { settings, addActionTemplate, updateActionTemplate, deleteActionTemplate, addChangeLog } = useAdmin();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newTemplate, setNewTemplate] = useState({
    name: '',
    description: '',
    auditType: 'both' as 'internal' | 'external' | 'both',
    department: '',
    phase: '',
    actions: [{ id: '1', description: '', isRequired: false, sortOrder: 1 }],
    isActive: true,
    priority: 1,
  });

  const addAction = () => {
    setNewTemplate({
      ...newTemplate,
      actions: [
        ...newTemplate.actions,
        { id: Date.now().toString(), description: '', isRequired: false, sortOrder: newTemplate.actions.length + 1 },
      ],
    });
  };

  const updateAction = (id: string, updates: any) => {
    setNewTemplate({
      ...newTemplate,
      actions: newTemplate.actions.map((a) => (a.id === id ? { ...a, ...updates } : a)),
    });
  };

  const removeAction = (id: string) => {
    setNewTemplate({
      ...newTemplate,
      actions: newTemplate.actions.filter((a) => a.id !== id),
    });
  };

  const handleAddTemplate = () => {
    if (!newTemplate.name) {
      toast({ title: 'Error', description: 'Please provide a template name', variant: 'destructive' });
      return;
    }
    addActionTemplate(newTemplate);
    addChangeLog({
      userId: '4',
      userName: 'Admin',
      settingArea: 'Action Templates',
      changeType: 'create',
      beforeValue: '',
      afterValue: newTemplate.name,
      description: `Created action template: ${newTemplate.name}`,
    });
    setNewTemplate({
      name: '',
      description: '',
      auditType: 'both',
      department: '',
      phase: '',
      actions: [{ id: '1', description: '', isRequired: false, sortOrder: 1 }],
      isActive: true,
      priority: 1,
    });
    setIsAddDialogOpen(false);
    toast({ title: 'Success', description: 'Template created' });
  };

  const handleDeleteTemplate = (id: string, name: string) => {
    deleteActionTemplate(id);
    addChangeLog({
      userId: '4',
      userName: 'Admin',
      settingArea: 'Action Templates',
      changeType: 'delete',
      beforeValue: name,
      afterValue: '',
      description: `Deleted action template: ${name}`,
    });
    toast({ title: 'Deleted', description: 'Template removed' });
  };

  return (
    <div className="space-y-6">
      <Card className="border-border/50">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              Action Templates
              <InfoHint content="Reusable checklists pre-loaded into new audits. Templates are matched by audit type / department / status, so users always start with the right action set." />
            </CardTitle>
            <CardDescription>Define reusable action checklists for different audit types</CardDescription>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Create Template
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create Action Template</DialogTitle>
                <DialogDescription>Build a reusable action checklist for audits</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="template-name" className="flex items-center gap-1.5">
                      Template Name
                      <InfoHint content="Friendly name shown in the template picker when creating an audit (e.g. 'HIPAA Compliance Checklist')." />
                    </Label>
                    <Input
                      id="template-name"
                      value={newTemplate.name}
                      onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })}
                      placeholder="e.g., HIPAA Compliance Checklist"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-1.5">
                      Audit Type
                      <InfoHint content="Restricts the template to internal, external, or applies to both. Only matching audits will see this template as a suggestion." />
                    </Label>
                    <Select value={newTemplate.auditType} onValueChange={(value: any) => setNewTemplate({ ...newTemplate, auditType: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="both">Both</SelectItem>
                        <SelectItem value="internal">Internal Only</SelectItem>
                        <SelectItem value="external">External Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="template-desc" className="flex items-center gap-1.5">
                    Description
                    <InfoHint content="Hint shown under the template name to help users pick the right one." />
                  </Label>
                  <Textarea
                    id="template-desc"
                    value={newTemplate.description}
                    onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })}
                    placeholder="Describe when to use this template..."
                  />
                </div>
                <div className="space-y-3">
                  <Label className="flex items-center gap-1.5">
                    Action Items
                    <InfoHint content="Each item becomes a checklist row in the audit. Mark items 'Required' to block status completion until they are checked off." />
                  </Label>
                  {newTemplate.actions.map((action, index) => (
                    <div key={action.id} className="flex items-center gap-2 p-3 border rounded-lg bg-muted/30">
                      <GripVertical className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground w-6">{index + 1}.</span>
                      <Input
                        value={action.description}
                        onChange={(e) => updateAction(action.id, { description: e.target.value })}
                        placeholder="Action description..."
                        className="flex-1"
                      />
                      <div className="flex items-center gap-2">
                        <Label className="text-xs text-muted-foreground">Required</Label>
                        <Switch
                          checked={action.isRequired}
                          onCheckedChange={(checked) => updateAction(action.id, { isRequired: checked })}
                        />
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive"
                        onClick={() => removeAction(action.id)}
                        disabled={newTemplate.actions.length === 1}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <Button variant="outline" onClick={addAction} className="w-full gap-2">
                    <Plus className="h-4 w-4" />
                    Add Action Item
                  </Button>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleAddTemplate}>Create Template</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="space-y-2">
            {settings.actionTemplates.map((template) => (
              <AccordionItem key={template.id} value={template.id} className="border rounded-lg px-4">
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-center gap-4 flex-1 text-left">
                    <div className="flex-1">
                      <p className="font-medium">{template.name}</p>
                      <p className="text-sm text-muted-foreground">{template.description}</p>
                    </div>
                    <Badge variant="outline">{template.auditType}</Badge>
                    <Badge variant={template.isActive ? 'default' : 'secondary'}>
                      {template.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="pt-4">
                  <div className="space-y-3">
                    {template.actions.map((action, index) => (
                      <div key={action.id} className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
                        <Check className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">{index + 1}.</span>
                        <span className="flex-1">{action.description}</span>
                        {action.isRequired && (
                          <Badge variant="destructive" className="text-xs">Required</Badge>
                        )}
                      </div>
                    ))}
                    <div className="flex justify-end gap-2 pt-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          updateActionTemplate(template.id, { isActive: !template.isActive });
                          toast({ title: template.isActive ? 'Deactivated' : 'Activated' });
                        }}
                      >
                        {template.isActive ? 'Deactivate' : 'Activate'}
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDeleteTemplate(template.id, template.name)}
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}
