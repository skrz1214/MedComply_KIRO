import { HelpCircle } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

interface InfoHintProps {
  /** The contextual explanation shown in the tooltip. */
  content: React.ReactNode;
  /** Optional accessible label for screen readers (defaults to "More information"). */
  label?: string;
  /** Tooltip side. */
  side?: 'top' | 'right' | 'bottom' | 'left';
  /** Extra classes for the trigger icon. */
  className?: string;
  /** Max width of the tooltip body. */
  contentClassName?: string;
}

/**
 * InfoHint — a compact, accessible help-icon that reveals contextual
 * intelligence about the adjacent admin section, field, or column.
 *
 * Use inline next to labels, table headers, card titles, or anywhere the
 * user might benefit from "what does this mean / when is it used?".
 */
export function InfoHint({
  content,
  label = 'More information',
  side = 'top',
  className,
  contentClassName,
}: InfoHintProps) {
  return (
    <Tooltip delayDuration={150}>
      <TooltipTrigger asChild>
        <button
          type="button"
          aria-label={label}
          className={cn(
            'inline-flex items-center justify-center rounded-full text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1',
            className,
          )}
          onClick={(e) => e.preventDefault()}
        >
          <HelpCircle className="h-3.5 w-3.5" aria-hidden="true" />
        </button>
      </TooltipTrigger>
      <TooltipContent
        side={side}
        className={cn('max-w-xs text-xs leading-relaxed', contentClassName)}
      >
        {content}
      </TooltipContent>
    </Tooltip>
  );
}
