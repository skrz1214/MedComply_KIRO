import { useAdmin } from '@/contexts/AdminContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { History, Search, Plus, Pencil, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { format } from 'date-fns';
import { InfoHint } from './InfoHint';

export function ChangeLogTab() {
  const { settings } = useAdmin();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterArea, setFilterArea] = useState('all');
  const [filterType, setFilterType] = useState('all');

  const filteredLogs = settings.changeLogs.filter((log) => {
    const matchesSearch =
      log.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.settingArea.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesArea = filterArea === 'all' || log.settingArea === filterArea;
    const matchesType = filterType === 'all' || log.changeType === filterType;
    return matchesSearch && matchesArea && matchesType;
  });

  const uniqueAreas = [...new Set(settings.changeLogs.map((log) => log.settingArea))];

  const getChangeIcon = (type: string) => {
    switch (type) {
      case 'create':
        return <Plus className="h-4 w-4 text-green-500" />;
      case 'update':
        return <Pencil className="h-4 w-4 text-blue-500" />;
      case 'delete':
        return <Trash2 className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  const getChangeBadge = (type: string) => {
    switch (type) {
      case 'create':
        return <Badge className="bg-green-100 text-green-700">Created</Badge>;
      case 'update':
        return <Badge className="bg-blue-100 text-blue-700">Updated</Badge>;
      case 'delete':
        return <Badge className="bg-red-100 text-red-700">Deleted</Badge>;
      default:
        return <Badge variant="secondary">{type}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5 text-primary" />
            Audit Settings Change Log
            <InfoHint content="Tamper-evident, append-only history of every admin setting change. Required by HIPAA / SOC 2 audit trails. Entries cannot be edited or deleted." />
          </CardTitle>
          <CardDescription>Immutable record of all settings changes with before/after snapshots</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Filters */}
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search logs..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
            <Select value={filterArea} onValueChange={setFilterArea}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by area" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Areas</SelectItem>
                {uniqueAreas.map((area) => (
                  <SelectItem key={area} value={area}>{area}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="create">Created</SelectItem>
                <SelectItem value="update">Updated</SelectItem>
                <SelectItem value="delete">Deleted</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Log Table */}
          {filteredLogs.length > 0 ? (
            <ScrollArea className="h-[500px] border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[180px]">Timestamp</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Area</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>
                      <span className="inline-flex items-center gap-1.5">
                        Before
                        <InfoHint content="Snapshot of the setting value immediately prior to the change. Use with 'After' to reconstruct what was modified." />
                      </span>
                    </TableHead>
                    <TableHead>
                      <span className="inline-flex items-center gap-1.5">
                        After
                        <InfoHint content="Snapshot of the new value the admin saved. Combined with 'Before' it forms a complete audit trail entry." />
                      </span>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLogs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="text-sm text-muted-foreground">
                        {format(new Date(log.timestamp), 'MMM d, yyyy HH:mm')}
                      </TableCell>
                      <TableCell className="font-medium">{log.userName}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{log.settingArea}</Badge>
                      </TableCell>
                      <TableCell>{getChangeBadge(log.changeType)}</TableCell>
                      <TableCell className="max-w-[200px] truncate">{log.description}</TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-[150px] truncate">
                        {log.beforeValue || '—'}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-[150px] truncate">
                        {log.afterValue || '—'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <History className="h-12 w-12 text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-medium">No Change Logs Found</h3>
              <p className="text-muted-foreground mt-1">
                {settings.changeLogs.length === 0
                  ? 'Settings changes will be recorded here'
                  : 'No logs match your current filters'}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Log Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Plus className="h-8 w-8 text-green-500" />
              <div>
                <p className="text-2xl font-bold">
                  {settings.changeLogs.filter((l) => l.changeType === 'create').length}
                </p>
                <p className="text-sm text-muted-foreground">Created</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Pencil className="h-8 w-8 text-blue-500" />
              <div>
                <p className="text-2xl font-bold">
                  {settings.changeLogs.filter((l) => l.changeType === 'update').length}
                </p>
                <p className="text-sm text-muted-foreground">Updated</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Trash2 className="h-8 w-8 text-red-500" />
              <div>
                <p className="text-2xl font-bold">
                  {settings.changeLogs.filter((l) => l.changeType === 'delete').length}
                </p>
                <p className="text-sm text-muted-foreground">Deleted</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
