import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Shield, Globe, Clock } from 'lucide-react';
import { InfoHint } from './InfoHint';

export function GeneralTab() {
  return (
    <div className="space-y-6">
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            Application Settings
            <InfoHint content="Top-level branding and global behavior toggles that apply to every audit and every user across the organization." />
          </CardTitle>
          <CardDescription>General configuration for AuditPro</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="app-name" className="flex items-center gap-1.5">
                Application Name
                <InfoHint content="Display name shown in the sidebar header, browser tab title, and generated PDFs / Audit Packs." />
              </Label>
              <Input id="app-name" defaultValue="AuditPro" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="org-name" className="flex items-center gap-1.5">
                Organization Name
                <InfoHint content="Legal entity name used on exports, audit cover pages, and notification emails sent to external auditors." />
              </Label>
              <Input id="org-name" defaultValue="MedComply Healthcare" />
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
              <div className="space-y-0.5">
                <Label className="flex items-center gap-1.5">
                  Enable Pre-Audit Status
                  <InfoHint content="When ON, every new audit must complete a Pre-Audit Preparation stage (checklist + materials) before entering the main 5-status lifecycle." />
                </Label>
                <p className="text-sm text-muted-foreground">Allow pre-audit preparation workflow before main audit</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
              <div className="space-y-0.5">
                <Label className="flex items-center gap-1.5">
                  Require Evidence for Closure
                  <InfoHint content="Blocks the Closure & CAP status from completing unless at least one piece of evidence is attached. Recommended for HIPAA-aligned audits." />
                </Label>
                <p className="text-sm text-muted-foreground">Mandate evidence upload before audit can be closed</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
              <div className="space-y-0.5">
                <Label className="flex items-center gap-1.5">
                  Auto-assign Next Audit Instance
                  <InfoHint content="For periodic audits, automatically generates the next scheduled instance the moment the current one is closed, using the configured periodicity." />
                </Label>
                <p className="text-sm text-muted-foreground">Automatically create next instance for periodic audits</p>
              </div>
              <Switch defaultChecked />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            Timezone & Date Settings
            <InfoHint content="Controls how dates are interpreted and displayed for due dates, schedules, audit trails, and notifications." />
          </CardTitle>
          <CardDescription>Configure date and time preferences</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="timezone" className="flex items-center gap-1.5">
                Default Timezone
                <InfoHint content="IANA timezone (e.g. America/New_York). All due dates and notifications are computed against this zone unless a user overrides it." />
              </Label>
              <Input id="timezone" defaultValue="America/New_York" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="date-format" className="flex items-center gap-1.5">
                Date Format
                <InfoHint content="Display pattern for dates throughout the UI and exports. Use tokens like MM/DD/YYYY, DD-MM-YYYY, or YYYY-MM-DD." />
              </Label>
              <Input id="date-format" defaultValue="MM/DD/YYYY" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5 text-primary" />
            Compliance Configuration
            <InfoHint content="Read-only summary of regulatory frameworks AuditPro is configured against. Drives evidence retention, PHI gating, and Audit Pack defaults." />
          </CardTitle>
          <CardDescription>Regulatory and compliance settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary">HIPAA Compliant</Badge>
            <Badge variant="secondary">SOC 2 Type II</Badge>
            <Badge variant="secondary">ISO 27001</Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            AuditPro is configured to meet healthcare compliance requirements. 
            Contact your administrator for additional compliance certifications.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
