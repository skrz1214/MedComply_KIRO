import { useAdmin } from '@/contexts/AdminContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ListChecks, ArrowRight, Info } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { InfoHint } from './InfoHint';
import { PHASE_ORDER, PHASE_LABELS } from '@/types/audit';
import { cn } from '@/lib/utils';

const phaseColors: Record<string, string> = {
  draft: 'bg-phase-draft',
  pre_audit: 'bg-phase-pre-audit',
  pre_audit_review: 'bg-phase-pre-audit-review',
  overview: 'bg-phase-overview',
  evidence_collection: 'bg-phase-evidence-collection',
  evaluation: 'bg-phase-evaluation',
  internal_review: 'bg-phase-internal-review',
  remediation_required: 'bg-phase-remediation-required',
  closure_cap: 'bg-phase-closure-cap',
  cap_active: 'bg-phase-cap-active',
  pending_verification: 'bg-phase-pending-verification',
  closed: 'bg-phase-closed',
};

const phaseColorNames: Record<string, string> = {
  draft: 'Slate',
  pre_audit: 'Blue',
  pre_audit_review: 'Sky',
  overview: 'Teal',
  evidence_collection: 'Cyan',
  evaluation: 'Amber',
  internal_review: 'Orange',
  remediation_required: 'Red',
  closure_cap: 'Purple',
  cap_active: 'Pink',
  pending_verification: 'Violet',
  closed: 'Green',
};

/**
 * PhaseRulesTab — formerly "Status & Phase Rules". In v2, Status was
 * removed entirely. Phase is now the single source of truth for an
 * audit's lifecycle position. This tab configures the 12 phases.
 */
export function StatusPhaseTab() {
  const { settings, updatePhase } = useAdmin();

  // Build a phase row list from the canonical PHASE_ORDER, falling back
  // to admin-configured phases for gating rules.
  const configuredPhases = settings.phases;
  const findConfig = (code: string) => configuredPhases.find(p => p.code === code);

  return (
    <div className="space-y-6">
      {/* v2 Migration Notice */}
      <Card className="border-primary/30 bg-primary/5">
        <CardContent className="p-4 flex items-start gap-3">
          <Info className="h-5 w-5 text-primary shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="font-medium text-foreground">Status is now the single source of truth</p>
            <p className="text-muted-foreground mt-1">
              In AuditPro v2, the legacy dual concept has been removed. The 12 statuses below cover every
              lifecycle state of an audit. All routing, navigation, badges, and filters are now driven by
              Status only.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Status Configuration */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ListChecks className="h-5 w-5 text-primary" />
            Status Configuration
            <InfoHint content="The 12 user-facing statuses of the audit lifecycle. Sidebar navigation, action buttons, evidence policy, and history grouping are all driven by Status." />
          </CardTitle>
          <CardDescription>Configure audit lifecycle statuses and gating rules</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>#</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>
                  <span className="inline-flex items-center gap-1.5">
                    Color
                    <InfoHint content="Color coding used across audit cards, badges, and dashboards to identify this status at a glance." />
                  </span>
                </TableHead>
                <TableHead>
                  <span className="inline-flex items-center gap-1.5">
                    Required Evidence
                    <InfoHint content="When ON, the status cannot be completed until at least one evidence file is uploaded." />
                  </span>
                </TableHead>
                <TableHead>
                  <span className="inline-flex items-center gap-1.5">
                    Required Actions
                    <InfoHint content="When ON, all action items in this status must be marked complete before the user can advance." />
                  </span>
                </TableHead>
                <TableHead>Active</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {PHASE_ORDER.map((code, index) => {
                const config = findConfig(code);
                return (
                  <TableRow key={code}>
                    <TableCell className="text-muted-foreground text-xs">{index + 1}</TableCell>
                    <TableCell className="font-medium">{PHASE_LABELS[code]}</TableCell>
                    <TableCell>
                      <span
                        aria-label={`${phaseColorNames[code] ?? 'Neutral'} color swatch`}
                        title={phaseColorNames[code] ?? 'Neutral'}
                        className={cn(
                          'inline-block h-5 w-5 rounded-full border border-border/50',
                          phaseColors[code] ?? 'bg-muted'
                        )}
                      />
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={config?.requiredEvidence ?? false}
                        disabled={!config}
                        onCheckedChange={(checked) => {
                          if (!config) return;
                          updatePhase(config.id, { requiredEvidence: checked });
                          toast({ title: 'Updated', description: `Evidence requirement updated for ${PHASE_LABELS[code]}` });
                        }}
                      />
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={config?.requiredActions ?? false}
                        disabled={!config}
                        onCheckedChange={(checked) => {
                          if (!config) return;
                          updatePhase(config.id, { requiredActions: checked });
                          toast({ title: 'Updated', description: `Action requirement updated for ${PHASE_LABELS[code]}` });
                        }}
                      />
                    </TableCell>
                    <TableCell>
                      {config ? (
                        <Switch
                          checked={config.isActive}
                          onCheckedChange={(checked) => {
                            updatePhase(config.id, { isActive: checked });
                            toast({ title: 'Updated', description: `Status ${PHASE_LABELS[code]} ${checked ? 'enabled' : 'disabled'}` });
                          }}
                        />
                      ) : (
                        <Badge variant="outline" className="text-xs">Built-in</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Status Flow Diagram */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Status Flow
            <InfoHint content="Canonical order of statuses. Audits typically progress left-to-right but may loop back (e.g. internal_review → remediation_required) when reviews fail." />
          </CardTitle>
          <CardDescription>Visual representation of the audit lifecycle</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-center justify-center gap-2 p-6 bg-muted/30 rounded-lg">
            {PHASE_ORDER.map((code, index) => (
              <div key={code} className="flex items-center gap-2">
                <Badge variant="outline" className="bg-card">
                  {PHASE_LABELS[code]}
                </Badge>
                {index < PHASE_ORDER.length - 1 && (
                  <ArrowRight className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
