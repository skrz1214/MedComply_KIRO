import { useAdmin } from '@/contexts/AdminContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Bell, Mail, Monitor } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { ROLE_LABELS } from '@/types/admin';
import { InfoHint } from './InfoHint';

export function NotificationsTab() {
  const { settings, updateNotification, addChangeLog } = useAdmin();

  const handleToggle = (id: string, field: 'emailEnabled' | 'inAppEnabled' | 'isActive', value: boolean) => {
    updateNotification(id, { [field]: value });
    addChangeLog({
      userId: '4',
      userName: 'Admin',
      settingArea: 'Notifications',
      changeType: 'update',
      beforeValue: `${field}: ${!value}`,
      afterValue: `${field}: ${value}`,
      description: `Updated notification ${field}`,
    });
    toast({ title: 'Updated' });
  };

  return (
    <div className="space-y-6">
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            Notification Configuration
            <InfoHint content="Each row is a system event that can fan out to email and / or in-app inboxes. Toggles here override per-user preferences for compliance-critical events." />
          </CardTitle>
          <CardDescription>Configure when and how notifications are sent</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>
                  <span className="inline-flex items-center gap-1.5">
                    Trigger Event
                    <InfoHint content="The system event that fires the notification (e.g. audit assigned, evidence uploaded, CAP overdue)." />
                  </span>
                </TableHead>
                <TableHead>
                  <span className="inline-flex items-center gap-1.5">
                    Email
                    <InfoHint content="Send an email to all users in the target roles. Honors quiet hours configured per user." />
                  </span>
                </TableHead>
                <TableHead>
                  <span className="inline-flex items-center gap-1.5">
                    In-App
                    <InfoHint content="Drop a notification into the bell icon in the AuditPro header. Always immediate." />
                  </span>
                </TableHead>
                <TableHead>
                  <span className="inline-flex items-center gap-1.5">
                    Target Roles
                    <InfoHint content="Which roles receive this notification. Edit by clicking the row to open the detail panel." />
                  </span>
                </TableHead>
                <TableHead>Active</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {settings.notifications.map((notification) => (
                <TableRow key={notification.id}>
                  <TableCell>
                    <div>
                      <p className="font-medium">{notification.triggerLabel}</p>
                      <p className="text-xs text-muted-foreground">{notification.trigger}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <Switch
                        checked={notification.emailEnabled}
                        onCheckedChange={(checked) => handleToggle(notification.id, 'emailEnabled', checked)}
                      />
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Monitor className="h-4 w-4 text-muted-foreground" />
                      <Switch
                        checked={notification.inAppEnabled}
                        onCheckedChange={(checked) => handleToggle(notification.id, 'inAppEnabled', checked)}
                      />
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {notification.targetRoles.map((role) => (
                        <Badge key={role} variant="outline" className="text-xs">
                          {ROLE_LABELS[role]}
                        </Badge>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={notification.isActive}
                      onCheckedChange={(checked) => handleToggle(notification.id, 'isActive', checked)}
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Template Preview */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Notification Templates
            <InfoHint content="Read-only preview of the message body shown to recipients. Templates support placeholders like {auditName}, {assignee}, {dueDate}." />
          </CardTitle>
          <CardDescription>Preview notification message templates</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {settings.notifications.slice(0, 3).map((notification) => (
            <div key={notification.id} className="p-4 rounded-lg bg-muted/50 space-y-2">
              <div className="flex items-center justify-between">
                <Badge variant="secondary">{notification.triggerLabel}</Badge>
              </div>
              <p className="text-sm text-muted-foreground">{notification.template}</p>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
