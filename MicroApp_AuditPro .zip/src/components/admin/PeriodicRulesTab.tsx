import { useAdmin } from '@/contexts/AdminContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Calendar, Clock, AlertTriangle } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { InfoHint } from './InfoHint';

export function PeriodicRulesTab() {
  const { settings, updatePeriodicRule, addChangeLog } = useAdmin();

  const handleUpdate = (id: string, field: string, value: any) => {
    updatePeriodicRule(id, { [field]: value });
    toast({ title: 'Updated', description: 'Periodic rule updated' });
  };

  return (
    <div className="space-y-6">
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-primary" />
            Periodic Audit Rules
            <InfoHint content="Defines how recurring audits behave for each periodicity (weekly, monthly, quarterly, annual). Drives automatic instance creation and overdue handling." />
          </CardTitle>
          <CardDescription>Configure scheduling and handling for recurring audits</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Periodicity</TableHead>
                <TableHead>
                  <span className="inline-flex items-center gap-1.5">
                    Auto-Create Next
                    <InfoHint content="When ON, the next audit instance is created automatically once the current one closes (using the configured recurrence)." />
                  </span>
                </TableHead>
                <TableHead>
                  <span className="inline-flex items-center gap-1.5">
                    Advance Notice (Days)
                    <InfoHint content="How many days before the next due date the system notifies assignees. 0 = no advance reminder." />
                  </span>
                </TableHead>
                <TableHead>
                  <span className="inline-flex items-center gap-1.5">
                    Missed Schedule Handling
                    <InfoHint content="What to do if the scheduled date passes without the audit being created. See the amber explainer card below for behavior of each option." />
                  </span>
                </TableHead>
                <TableHead>Active</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {settings.periodicRules.map((rule) => (
                <TableRow key={rule.id}>
                  <TableCell className="font-medium capitalize">{rule.periodicity}</TableCell>
                  <TableCell>
                    <Switch
                      checked={rule.autoCreateNextInstance}
                      onCheckedChange={(checked) => handleUpdate(rule.id, 'autoCreateNextInstance', checked)}
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      min={0}
                      value={rule.advanceNoticeDays}
                      onChange={(e) => handleUpdate(rule.id, 'advanceNoticeDays', parseInt(e.target.value) || 0)}
                      className="w-20"
                    />
                  </TableCell>
                  <TableCell>
                    <Select
                      value={rule.missedScheduleHandling}
                      onValueChange={(value) => handleUpdate(rule.id, 'missedScheduleHandling', value)}
                    >
                      <SelectTrigger className="w-[180px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="skip">Skip</SelectItem>
                        <SelectItem value="create_overdue">Create as Overdue</SelectItem>
                        <SelectItem value="notify_only">Notify Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={rule.isActive}
                      onCheckedChange={(checked) => handleUpdate(rule.id, 'isActive', checked)}
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Scheduling Info */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            Scheduling Configuration
            <InfoHint content="Cross-cutting toggles that apply to all periodicities (date computation, reminder dispatch)." />
          </CardTitle>
          <CardDescription>Additional scheduling settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
            <div className="space-y-0.5">
              <Label className="flex items-center gap-1.5">
                Calculate Next Scheduled Date Automatically
                <InfoHint content="When ON, AuditPro computes nextScheduledDate from the periodicity. When OFF, an admin must set it manually for each instance." />
              </Label>
              <p className="text-sm text-muted-foreground">System calculates nextScheduledDate based on periodicity</p>
            </div>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
            <div className="space-y-0.5">
              <Label className="flex items-center gap-1.5">
                Notify Before Due Date
                <InfoHint content="Sends reminder emails / in-app pings to assignees using the Advance Notice (Days) value configured per periodicity." />
              </Label>
              <p className="text-sm text-muted-foreground">Send reminders based on advance notice days</p>
            </div>
            <Switch defaultChecked />
          </div>
        </CardContent>
      </Card>

      {/* Missed Schedule Info */}
      <Card className="border-amber-200 bg-amber-50/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-amber-700">
            <AlertTriangle className="h-5 w-5" />
            Missed Schedule Handling
            <InfoHint content="Reference card. Pick one of these strategies in the table above for every periodicity you want to track." />
          </CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-amber-700 space-y-2">
          <p><strong>Skip:</strong> The missed audit instance is not created. The next scheduled date moves forward.</p>
          <p><strong>Create as Overdue:</strong> Creates the audit marked as overdue with the original due date.</p>
          <p><strong>Notify Only:</strong> Sends a notification to relevant users but does not auto-create the audit.</p>
        </CardContent>
      </Card>
    </div>
  );
}
