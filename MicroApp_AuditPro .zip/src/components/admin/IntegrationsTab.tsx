import { useAdmin } from '@/contexts/AdminContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Link, CheckCircle, XCircle, RefreshCw, AlertCircle } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { InfoHint } from './InfoHint';

export function IntegrationsTab() {
  const { settings, updateIntegration, addChangeLog } = useAdmin();

  const handleToggle = (id: string, isEnabled: boolean) => {
    updateIntegration(id, { isEnabled: !isEnabled });
    addChangeLog({
      userId: '4',
      userName: 'Admin',
      settingArea: 'Integrations',
      changeType: 'update',
      beforeValue: `enabled: ${isEnabled}`,
      afterValue: `enabled: ${!isEnabled}`,
      description: `${!isEnabled ? 'Enabled' : 'Disabled'} integration`,
    });
    toast({ title: !isEnabled ? 'Integration Enabled' : 'Integration Disabled' });
  };

  const testConnection = (id: string, name: string) => {
    toast({ title: 'Testing Connection', description: `Testing ${name} connection...` });
    setTimeout(() => {
      toast({ title: 'Connection Successful', description: `${name} connection verified` });
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Link className="h-5 w-5 text-primary" />
            Integration Configuration
            <InfoHint content="Outbound connections to sister microapps (ComplianceConnect for CAP, RiskGuard for risk linkage, FeedbackHub, EnforcePoint). Disabled integrations cause cross-app links to render read-only." />
          </CardTitle>
          <CardDescription>Configure connections to external systems (ComplianceConnect, RiskGuard, etc.)</CardDescription>
        </CardHeader>
        <CardContent>
          {settings.integrations.map((integration) => (
            <div key={integration.id} className="p-6 border rounded-lg space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {integration.isEnabled ? (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  ) : (
                    <XCircle className="h-5 w-5 text-muted-foreground" />
                  )}
                  <div>
                    <h4 className="font-medium">{integration.name}</h4>
                    <p className="text-sm text-muted-foreground">{integration.type}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant={integration.isEnabled ? 'default' : 'secondary'}>
                    {integration.isEnabled ? 'Active' : 'Inactive'}
                  </Badge>
                  <Switch
                    checked={integration.isEnabled}
                    onCheckedChange={() => handleToggle(integration.id, integration.isEnabled)}
                  />
                </div>
              </div>

              {integration.isEnabled && (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="flex items-center gap-1.5">
                        API Endpoint
                        <InfoHint content="Base URL for the integration's REST API. Must include scheme (https://) and exclude trailing slash." />
                      </Label>
                      <Input
                        value={integration.apiEndpoint || ''}
                        onChange={(e) => updateIntegration(integration.id, { apiEndpoint: e.target.value })}
                        placeholder="https://api.example.com/..."
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="flex items-center gap-1.5">
                        Last Sync
                        <InfoHint content="Timestamp of the most recent successful sync. 'Never' indicates the integration has not yet exchanged data." />
                      </Label>
                      <Input
                        value={integration.lastSyncAt || 'Never'}
                        disabled
                        className="bg-muted"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-1.5">
                      Retry Policy
                      <InfoHint content="How AuditPro handles failed sync calls. Exponential backoff doubles the delay after each failure to avoid hammering the remote system." />
                    </Label>
                    <div className="flex items-center gap-4 p-3 bg-muted/50 rounded-lg text-sm">
                      <span>Max Retries: <strong>{integration.retryPolicy.maxRetries}</strong></span>
                      <span>Delay: <strong>{integration.retryPolicy.retryDelaySeconds}s</strong></span>
                      <span>Exponential Backoff: <strong>{integration.retryPolicy.exponentialBackoff ? 'Yes' : 'No'}</strong></span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-1.5">
                      Field Mappings
                      <InfoHint content="Translates AuditPro fields into the remote system's schema. The source field is read from the audit; the target field is what the remote API expects." />
                    </Label>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Source Field</TableHead>
                          <TableHead>Target Field</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {integration.fieldMappings.map((mapping, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-mono text-sm">{mapping.sourceField}</TableCell>
                            <TableCell className="font-mono text-sm">{mapping.targetField}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => testConnection(integration.id, integration.name)}
                    >
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Test Connection
                    </Button>
                    <Button variant="outline" size="sm">
                      <AlertCircle className="h-4 w-4 mr-2" />
                      View Error Logs
                    </Button>
                  </div>
                </>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* CAP Integration Info */}
      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="text-primary">ComplianceConnect CAP Integration</CardTitle>
          <CardDescription>
            When CAP is required during external audit closure, AuditPro automatically creates a corresponding item in ComplianceConnect.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-2">
          <p>• CAP status is mirrored back to AuditPro</p>
          <p>• Field mappings determine how audit data is transferred</p>
          <p>• Error logs track any sync issues</p>
        </CardContent>
      </Card>
    </div>
  );
}
