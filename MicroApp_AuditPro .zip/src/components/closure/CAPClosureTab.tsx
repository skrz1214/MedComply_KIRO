import { useState } from 'react';
import { useAudit } from '@/contexts/AuditContext';
import { useCAP } from '@/contexts/CAPContext';
import { AuditItem } from '@/types/audit';
import { AuditClosure } from '@/types/cap';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { 
  Shield,
  ExternalLink,
  ClipboardList,
  ArrowRight
} from 'lucide-react';
import { toast } from 'sonner';

interface CAPClosureTabProps {
  audit: AuditItem;
  onClose?: () => void;
}

export function CAPClosureTab({ audit, onClose }: CAPClosureTabProps) {
  const { closeAudit, updateAudit, currentUser, addHistoryEntry } = useAudit();
  const { getCAPByAuditId } = useCAP();

  const cap = getCAPByAuditId(audit.id);

  const [closureSummary, setClosureSummary] = useState('');
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Validation checks
  const capVerified = cap?.status === 'verified';

  const canClose = capVerified;

  const handleRouteToCAPA = () => {
    // Move audit to cap_active phase when routing to CAPA microapp
    if (audit.currentPhase !== 'cap_active' && audit.currentPhase !== 'closed') {
      updateAudit(audit.id, { currentPhase: 'cap_active', phase: 'cap_active', status: 'cap_active' });
      addHistoryEntry(audit.id, {
        action: 'Audit routed to CAPA microapp',
        phase: 'cap_active',
        performedBy: currentUser.name,
        notes: 'Corrective Action Plan initiated',
      });
    }

    toast.info('Opening CAPA Microapp', {
      description: 'Redirecting to the CAPA management system...',
    });
    
    // In production, this would navigate to the CAPA app
    // window.open(`/capa/audit/${audit.id}`, '_blank');
  };

  const handleClosureSubmit = () => {
    if (!cap) return;
    
    setIsSubmitting(true);

    const closure: AuditClosure = {
      closureType: 'with_cap',
      closedBy: currentUser.name,
      closedAt: new Date().toISOString(),
      closureSummary,
      capId: cap.id,
      capVerificationId: cap.verification?.id,
    };

    closeAudit(audit.id, true);
    
    addHistoryEntry(audit.id, {
      action: 'Audit closed with CAP verification',
      phase: 'closure_cap',
      performedBy: currentUser.name,
      notes: closureSummary,
    });

    setIsSubmitting(false);
    setShowConfirmDialog(false);

    toast.success('Audit closed with CAP', {
      description: 'The audit has been marked as complete with verified corrective actions.',
    });

    onClose?.();
  };

  return (
    <div className="space-y-6">
      {/* Info Banner */}
      <div className="p-4 rounded-lg bg-primary/10 border border-primary/30">
        <div className="flex items-start gap-3">
          <Shield className="h-5 w-5 text-primary shrink-0 mt-0.5" />
          <div>
            <p className="font-medium text-primary">Corrective Action Plan (CAP)</p>
            <p className="text-sm text-muted-foreground mt-1">
              Route this audit to the CAPA microapp to manage corrective and preventive actions.
              Once all actions are verified in CAPA, return here to close the audit.
            </p>
          </div>
        </div>
      </div>

      {/* Route to CAPA Card */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <ExternalLink className="h-5 w-5 text-primary" />
            CAPA Microapp
          </CardTitle>
          <CardDescription>
            Manage corrective and preventive actions in the dedicated CAPA system
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 rounded-lg bg-muted/30 border border-border/30">
            <div className="flex items-start gap-3">
              <ClipboardList className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground mb-2">
                  The CAPA microapp enables you to:
                </p>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  <li>Define root cause analysis</li>
                  <li>Create corrective and preventive actions</li>
                  <li>Assign owners and set due dates</li>
                  <li>Track action completion and upload evidence</li>
                  <li>Request and complete verification</li>
                </ul>
              </div>
            </div>
          </div>
          
          <Button 
            className="w-full gap-2" 
            size="lg"
            onClick={handleRouteToCAPA}
          >
            <ExternalLink className="h-4 w-4" />
            Open CAPA Microapp
            <ArrowRight className="h-4 w-4 ml-auto" />
          </Button>
        </CardContent>
      </Card>


      {/* Closure Section - only when CAP is verified */}
      {canClose && (
        <Card className="border-status-success/30 bg-status-success/5 animate-fade-in">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2 text-status-success">
              <Shield className="h-5 w-5" />
              Close Audit with CAP
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="closureSummaryCAP">Closure Summary Notes</Label>
              <Textarea
                id="closureSummaryCAP"
                placeholder="Add any final notes about this closure..."
                value={closureSummary}
                onChange={(e) => setClosureSummary(e.target.value)}
                rows={3}
              />
            </div>

            <Button
              size="lg"
              className="w-full gap-2 bg-status-success hover:bg-status-success/90"
              onClick={() => setShowConfirmDialog(true)}
            >
              <Shield className="h-4 w-4" />
              Close Audit with Verified CAP
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Audit Closure</AlertDialogTitle>
            <AlertDialogDescription>
              This will close the audit with the completed CAP verification. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleClosureSubmit}
              disabled={isSubmitting}
              className="bg-status-success hover:bg-status-success/90"
            >
              {isSubmitting ? 'Closing...' : 'Confirm Closure'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
