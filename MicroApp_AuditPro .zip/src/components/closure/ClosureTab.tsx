import { useState, useMemo } from 'react';
import { useAudit } from '@/contexts/AuditContext';
import { useClosureReasons } from '@/contexts/ClosureReasonsContext';
import { useCAP } from '@/contexts/CAPContext';
import { AuditItem } from '@/types/audit';
import { ClosureReason, CAPEvidence, CLOSURE_REASON_CATEGORIES, AuditClosure } from '@/types/cap';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { 
  CheckCircle2, 
  XCircle, 
  FileWarning, 
  Shield,
  Upload,
  FileText,
  Trash2,
  AlertTriangle,
  Clock,
  User,
  Info
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface ClosureTabProps {
  audit: AuditItem;
  onClose?: () => void;
}

export function ClosureTab({ audit, onClose }: ClosureTabProps) {
  const { closeAudit, updateAudit, currentUser, addHistoryEntry } = useAudit();
  const { getActiveReasons } = useClosureReasons();
  const { getCAPByAuditId } = useCAP();

  const cap = getCAPByAuditId(audit.id);
  const activeReasons = getActiveReasons();

  const [closureType, setClosureType] = useState<'with_cap' | 'without_cap' | ''>('');
  const [selectedReasonId, setSelectedReasonId] = useState('');
  const [justification, setJustification] = useState('');
  const [closureSummary, setClosureSummary] = useState('');
  const [closureEvidence, setClosureEvidence] = useState<CAPEvidence[]>([]);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const selectedReason = useMemo(() => 
    activeReasons.find(r => r.id === selectedReasonId),
    [activeReasons, selectedReasonId]
  );

  // Group reasons by category
  const reasonsByCategory = useMemo(() => {
    const grouped: Record<string, ClosureReason[]> = {};
    activeReasons.forEach(reason => {
      if (!grouped[reason.category]) {
        grouped[reason.category] = [];
      }
      grouped[reason.category].push(reason);
    });
    return grouped;
  }, [activeReasons]);

  // Validation checks
  const capVerified = cap?.status === 'verified';
  const allActionsComplete = cap ? cap.actions.every(a => a.status === 'completed') : false;

  const canCloseWithCAP = capVerified;
  const canCloseWithoutCAP = () => {
    if (!selectedReason) return false;
    if (selectedReason.requiresJustification && !justification.trim()) return false;
    if (selectedReason.requiresEvidence && closureEvidence.length === 0) return false;
    return true;
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newEvidence: CAPEvidence[] = Array.from(files).map((file, index) => ({
      id: `${Date.now()}-${index}`,
      name: file.name,
      type: file.type,
      uploadedAt: new Date().toISOString(),
      uploadedBy: currentUser.name,
      url: URL.createObjectURL(file),
    }));

    setClosureEvidence(prev => [...prev, ...newEvidence]);
  };

  const handleRemoveEvidence = (id: string) => {
    setClosureEvidence(prev => prev.filter(e => e.id !== id));
  };

  const handleClosureSubmit = () => {
    setIsSubmitting(true);

    const closure: AuditClosure = {
      closureType: closureType as 'with_cap' | 'without_cap',
      closedBy: currentUser.name,
      closedAt: new Date().toISOString(),
      closureSummary,
    };

    if (closureType === 'without_cap') {
      closure.reasonId = selectedReasonId;
      closure.reasonName = selectedReason?.name;
      closure.justification = justification;
      closure.closureEvidence = closureEvidence;
      closure.requiresApproval = selectedReason?.requiresApproval;
      
      if (selectedReason?.requiresApproval) {
        closure.approvalStatus = 'pending';
      }
    } else {
      closure.capId = cap?.id;
      closure.capVerificationId = cap?.verification?.id;
    }

    // Update audit with closure details
    closeAudit(audit.id, closureType === 'with_cap');
    
    addHistoryEntry(audit.id, {
      action: closureType === 'with_cap' 
        ? 'Audit closed with CAP verification' 
        : `Audit closed without CAP: ${selectedReason?.name}`,
      phase: 'closure_cap',
      performedBy: currentUser.name,
      notes: closureSummary,
    });

    setIsSubmitting(false);
    setShowConfirmDialog(false);

    toast.success(
      closureType === 'with_cap' 
        ? 'Audit closed with CAP' 
        : 'Audit closed without CAP',
      {
        description: selectedReason?.requiresApproval 
          ? 'Awaiting approval before final closure.'
          : 'The audit has been marked as complete.',
      }
    );

    onClose?.();
  };

  const isValid = closureType === 'with_cap' ? canCloseWithCAP : canCloseWithoutCAP();

  return (
    <div className="space-y-6">
      {/* Closure Path Selection */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-lg">Closure Decision</CardTitle>
          <CardDescription>Select how to close this audit item</CardDescription>
        </CardHeader>
        <CardContent>
          <RadioGroup 
            value={closureType} 
            onValueChange={(val) => setClosureType(val as 'with_cap' | 'without_cap')}
            className="space-y-3"
          >
            {/* Close With CAP */}
            <div 
              className={cn(
                'flex items-start gap-3 p-4 rounded-lg border cursor-pointer transition-all',
                closureType === 'with_cap' 
                  ? 'border-status-success bg-status-success-bg/30' 
                  : 'border-border hover:border-status-success/50',
                !cap && 'opacity-50 cursor-not-allowed'
              )}
              onClick={() => cap && setClosureType('with_cap')}
            >
              <RadioGroupItem value="with_cap" id="with_cap" disabled={!cap} />
              <Label htmlFor="with_cap" className="flex-1 cursor-pointer">
                <div className="flex items-center gap-2 mb-1">
                  <Shield className={cn(
                    'h-5 w-5',
                    closureType === 'with_cap' ? 'text-status-success' : 'text-muted-foreground'
                  )} />
                  <span className="font-medium">Close With CAP</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Close the audit after CAP verification is complete
                </p>
                
                {/* CAP Checklist */}
                {cap && (
                  <div className="mt-3 space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      {cap ? (
                        <CheckCircle2 className="h-4 w-4 text-status-success" />
                      ) : (
                        <XCircle className="h-4 w-4 text-status-error" />
                      )}
                      <span>CAP exists</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {allActionsComplete ? (
                        <CheckCircle2 className="h-4 w-4 text-status-success" />
                      ) : (
                        <XCircle className="h-4 w-4 text-status-error" />
                      )}
                      <span>All actions complete</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {capVerified ? (
                        <CheckCircle2 className="h-4 w-4 text-status-success" />
                      ) : (
                        <XCircle className="h-4 w-4 text-status-error" />
                      )}
                      <span>Verification complete</span>
                    </div>
                    {cap.verification && (
                      <div className="flex items-center gap-2 pl-6 text-muted-foreground">
                        <User className="h-3 w-3" />
                        <span>Verified by {cap.verification.verifierName} on {new Date(cap.verification.verifiedAt).toLocaleDateString()}</span>
                      </div>
                    )}
                  </div>
                )}

                {!cap && (
                  <div className="mt-3 p-2 rounded bg-muted/50 text-sm text-muted-foreground">
                    No CAP has been created for this audit item.
                  </div>
                )}
              </Label>
            </div>

            {/* Close Without CAP */}
            <div 
              className={cn(
                'flex items-start gap-3 p-4 rounded-lg border cursor-pointer transition-all',
                closureType === 'without_cap' 
                  ? 'border-status-warning bg-status-warning-bg/30' 
                  : 'border-border hover:border-status-warning/50'
              )}
              onClick={() => setClosureType('without_cap')}
            >
              <RadioGroupItem value="without_cap" id="without_cap" />
              <Label htmlFor="without_cap" className="flex-1 cursor-pointer">
                <div className="flex items-center gap-2 mb-1">
                  <FileWarning className={cn(
                    'h-5 w-5',
                    closureType === 'without_cap' ? 'text-status-warning' : 'text-muted-foreground'
                  )} />
                  <span className="font-medium">Close Without CAP</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Close the audit with a validated closure reason
                </p>
              </Label>
            </div>
          </RadioGroup>
        </CardContent>
      </Card>

      {/* Close Without CAP Form */}
      {closureType === 'without_cap' && (
        <Card className="border-border/50 animate-fade-in">
          <CardHeader>
            <CardTitle className="text-lg">Closure Reason</CardTitle>
            <CardDescription>Select or provide a reason for closing without corrective action</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Reason Selection */}
            <div className="space-y-2">
              <Label htmlFor="closureReason">
                Closure Reason <span className="text-status-error">*</span>
              </Label>
              <Select value={selectedReasonId} onValueChange={setSelectedReasonId}>
                <SelectTrigger id="closureReason">
                  <SelectValue placeholder="Select a closure reason..." />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border z-50 max-h-[300px]">
                  {Object.entries(reasonsByCategory).map(([category, reasons]) => (
                    <div key={category}>
                      <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground bg-muted/50">
                        {CLOSURE_REASON_CATEGORIES[category as keyof typeof CLOSURE_REASON_CATEGORIES]}
                      </div>
                      {reasons.map(reason => (
                        <SelectItem key={reason.id} value={reason.id}>
                          <div className="flex items-center gap-2">
                            <span>{reason.name}</span>
                            {reason.requiresApproval && (
                              <span className="text-xs text-status-warning">(Requires Approval)</span>
                            )}
                          </div>
                        </SelectItem>
                      ))}
                    </div>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Selected Reason Details */}
            {selectedReason && (
              <div className="p-3 rounded-lg bg-muted/50 space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Info className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">Requirements for this reason:</span>
                </div>
                <div className="grid grid-cols-3 gap-2 pl-6">
                  <div className="flex items-center gap-1">
                    {selectedReason.requiresJustification ? (
                      <AlertTriangle className="h-3 w-3 text-status-warning" />
                    ) : (
                      <CheckCircle2 className="h-3 w-3 text-status-success" />
                    )}
                    <span>Justification {selectedReason.requiresJustification ? 'Required' : 'Optional'}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {selectedReason.requiresEvidence ? (
                      <AlertTriangle className="h-3 w-3 text-status-warning" />
                    ) : (
                      <CheckCircle2 className="h-3 w-3 text-status-success" />
                    )}
                    <span>Evidence {selectedReason.requiresEvidence ? 'Required' : 'Optional'}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {selectedReason.requiresApproval ? (
                      <AlertTriangle className="h-3 w-3 text-status-warning" />
                    ) : (
                      <CheckCircle2 className="h-3 w-3 text-status-success" />
                    )}
                    <span>Approval {selectedReason.requiresApproval ? 'Required' : 'Not Required'}</span>
                  </div>
                </div>
                {selectedReason.requiresApproval && selectedReason.approverRole && (
                  <p className="pl-6 text-muted-foreground">
                    Approver: {selectedReason.approverRole}
                  </p>
                )}
              </div>
            )}

            {/* Justification */}
            {selectedReason && (
              <div className="space-y-2">
                <Label htmlFor="justification">
                  Justification {selectedReason.requiresJustification && <span className="text-status-error">*</span>}
                </Label>
                <Textarea
                  id="justification"
                  placeholder="Provide justification for this closure reason..."
                  value={justification}
                  onChange={(e) => setJustification(e.target.value)}
                  rows={4}
                />
              </div>
            )}

            {/* Evidence Upload */}
            {selectedReason && (
              <div className="space-y-2">
                <Label>
                  Supporting Evidence {selectedReason.requiresEvidence && <span className="text-status-error">*</span>}
                </Label>
                <div className="border-2 border-dashed border-border rounded-lg p-4">
                  <input
                    type="file"
                    multiple
                    onChange={handleFileUpload}
                    className="hidden"
                    id="evidence-upload"
                  />
                  <label 
                    htmlFor="evidence-upload"
                    className="flex flex-col items-center cursor-pointer"
                  >
                    <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                    <span className="text-sm text-muted-foreground">
                      Click to upload or drag and drop
                    </span>
                  </label>
                </div>
                {closureEvidence.length > 0 && (
                  <div className="space-y-2 mt-2">
                    {closureEvidence.map(evidence => (
                      <div 
                        key={evidence.id}
                        className="flex items-center gap-3 p-2 rounded-lg bg-muted/50"
                      >
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm flex-1 truncate">{evidence.name}</span>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleRemoveEvidence(evidence.id)}
                        >
                          <Trash2 className="h-4 w-4 text-status-error" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Closure Summary */}
      {closureType && (
        <Card className="border-border/50 animate-fade-in">
          <CardHeader>
            <CardTitle className="text-lg">Closure Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="closureSummary">Summary Notes</Label>
              <Textarea
                id="closureSummary"
                placeholder="Add any final notes about this closure..."
                value={closureSummary}
                onChange={(e) => setClosureSummary(e.target.value)}
                rows={3}
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Submit Button */}
      <div className="flex justify-end gap-3">
        <Button
          size="lg"
          className={cn(
            'gap-2',
            closureType === 'with_cap' 
              ? 'bg-status-success hover:bg-status-success/90' 
              : closureType === 'without_cap'
              ? 'bg-status-warning hover:bg-status-warning/90 text-foreground'
              : ''
          )}
          disabled={!closureType || !isValid}
          onClick={() => setShowConfirmDialog(true)}
        >
          {closureType === 'with_cap' ? (
            <>
              <Shield className="h-4 w-4" />
              Close With CAP
            </>
          ) : closureType === 'without_cap' ? (
            <>
              <FileWarning className="h-4 w-4" />
              Close Without CAP
            </>
          ) : (
            'Select a Closure Path'
          )}
        </Button>
      </div>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Audit Closure</AlertDialogTitle>
            <AlertDialogDescription>
              {closureType === 'with_cap' ? (
                'This will close the audit with the completed CAP verification. This action cannot be undone.'
              ) : (
                <>
                  This will close the audit without a Corrective Action Plan.
                  {selectedReason?.requiresApproval && (
                    <span className="block mt-2 text-status-warning font-medium">
                      Note: This closure requires approval before it is finalized.
                    </span>
                  )}
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleClosureSubmit}
              disabled={isSubmitting}
              className={cn(
                closureType === 'with_cap'
                  ? 'bg-status-success hover:bg-status-success/90'
                  : 'bg-status-warning hover:bg-status-warning/90'
              )}
            >
              {isSubmitting ? 'Closing...' : 'Confirm Closure'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
