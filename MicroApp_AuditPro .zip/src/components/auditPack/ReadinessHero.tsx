import { TrendingUp, TrendingDown, Minus, ArrowRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

interface ReadinessHeroProps {
  score: number;
  previousScore?: number;
  topGaps: string[];
  breakdown: {
    policyCoverage: number;
    trainingCompletion: number;
    evidenceCoverage: number;
    penalties: number;
  };
  canGenerate: boolean;
}

const SIZE = 180;
const STROKE = 14;
const RADIUS = (SIZE - STROKE) / 2;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

function getScoreTone(score: number) {
  if (score >= 80) return { ring: 'hsl(var(--status-success))', label: 'Audit Ready', tone: 'success' as const };
  if (score >= 60) return { ring: 'hsl(var(--status-warning))', label: 'Needs Attention', tone: 'warning' as const };
  return { ring: 'hsl(var(--status-error))', label: 'Not Ready', tone: 'error' as const };
}

export function ReadinessHero({ score, previousScore, topGaps, breakdown, canGenerate }: ReadinessHeroProps) {
  const navigate = useNavigate();
  const { ring, label, tone } = getScoreTone(score);
  const dashOffset = CIRCUMFERENCE - (score / 100) * CIRCUMFERENCE;

  const delta = previousScore !== undefined ? score - previousScore : 0;
  const TrendIcon = delta > 0 ? TrendingUp : delta < 0 ? TrendingDown : Minus;
  const trendTone = delta > 0 ? 'text-status-success' : delta < 0 ? 'text-status-error' : 'text-muted-foreground';

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-gradient-to-br from-card to-secondary/30 shadow-card">
      {/* Decorative blur */}
      <div
        className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full opacity-20 blur-3xl"
        style={{ background: ring }}
        aria-hidden
      />

      <div className="relative grid gap-8 p-6 md:grid-cols-[auto_1fr] md:p-8">
        {/* Gauge */}
        <div className="flex flex-col items-center justify-center">
          <div className="relative" style={{ width: SIZE, height: SIZE }}>
            <svg width={SIZE} height={SIZE} className="-rotate-90">
              <circle
                cx={SIZE / 2}
                cy={SIZE / 2}
                r={RADIUS}
                stroke="hsl(var(--muted))"
                strokeWidth={STROKE}
                fill="none"
              />
              <circle
                cx={SIZE / 2}
                cy={SIZE / 2}
                r={RADIUS}
                stroke={ring}
                strokeWidth={STROKE}
                fill="none"
                strokeLinecap="round"
                strokeDasharray={CIRCUMFERENCE}
                strokeDashoffset={dashOffset}
                style={{ transition: 'stroke-dashoffset 0.8s ease-out' }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-5xl font-bold tabular-nums text-foreground">{score}</span>
              <span className="text-xs font-medium text-muted-foreground">out of 100</span>
            </div>
          </div>
          <Badge
            className={cn(
              'mt-3 border-0',
              tone === 'success' && 'bg-status-success-bg text-status-success',
              tone === 'warning' && 'bg-status-warning-bg text-status-warning',
              tone === 'error' && 'bg-status-error-bg text-status-error',
            )}
          >
            {label}
          </Badge>
        </div>

        {/* Content */}
        <div className="flex flex-col justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 text-sm font-medium text-primary">
              <Sparkles className="h-4 w-4" />
              Readiness Score
            </div>
            <h2 className="mt-1 text-2xl font-bold text-foreground md:text-3xl">
              Your organization is{' '}
              <span
                className={cn(
                  tone === 'success' && 'text-status-success',
                  tone === 'warning' && 'text-status-warning',
                  tone === 'error' && 'text-status-error',
                )}
              >
                {score >= 80 ? 'audit-ready' : score >= 60 ? 'nearly ready' : 'not yet ready'}
              </span>
            </h2>
            <p className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
              <TrendIcon className={cn('h-4 w-4', trendTone)} />
              {delta === 0
                ? 'No change since last export'
                : `${delta > 0 ? '+' : ''}${delta} pts since last export`}
            </p>
          </div>

          {/* Breakdown */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <BreakdownItem label="Policy Coverage" value={breakdown.policyCoverage} max={30} />
            <BreakdownItem label="Training" value={breakdown.trainingCompletion} max={25} />
            <BreakdownItem label="Evidence" value={breakdown.evidenceCoverage} max={30} />
            <BreakdownItem label="Penalty Buffer" value={breakdown.penalties} max={15} />
          </div>

          {/* Top gaps + CTA */}
          {topGaps.length > 0 ? (
            <div className="rounded-lg border border-status-warning/20 bg-status-warning-bg/40 p-4">
              <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-status-warning">
                Top {Math.min(topGaps.length, 3)} gap{topGaps.length === 1 ? '' : 's'} to address
              </p>
              <ul className="space-y-1 text-sm text-foreground">
                {topGaps.slice(0, 3).map((gap, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="mt-1.5 inline-block h-1.5 w-1.5 flex-shrink-0 rounded-full bg-status-warning" />
                    {gap}
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <div className="rounded-lg border border-status-success/20 bg-status-success-bg/40 p-4 text-sm text-status-success">
              ✓ No gaps detected. You're ready to generate a defensible export.
            </div>
          )}

          <div className="flex flex-wrap gap-2">
            <Button onClick={() => navigate('/audit-pack/new')} disabled={!canGenerate}>
              {topGaps.length > 0 ? 'Fix Gaps & Generate' : 'Generate Audit Pack'}
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button variant="outline" onClick={() => navigate('/audit-pack/history')}>
              View History
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

function BreakdownItem({ label, value, max }: { label: string; value: number; max: number }) {
  const pct = Math.min(100, Math.round((value / max) * 100));
  return (
    <div className="rounded-lg border border-border bg-card p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 text-lg font-semibold tabular-nums text-foreground">
        {value}
        <span className="text-xs font-normal text-muted-foreground">/{max}</span>
      </p>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
        <div
          className="h-full rounded-full bg-primary transition-all duration-500"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
