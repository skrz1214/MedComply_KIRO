import { PHASE_ORDER, PHASE_LABELS, AuditPhase } from '@/types/audit';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const STATUS_VAR: Record<AuditPhase, string> = {
  draft: '--phase-draft',
  pre_audit: '--phase-pre-audit',
  pre_audit_review: '--phase-pre-audit-review',
  overview: '--phase-overview',
  evidence_collection: '--phase-evidence-collection',
  evaluation: '--phase-evaluation',
  internal_review: '--phase-internal-review',
  remediation_required: '--phase-remediation-required',
  closure_cap: '--phase-closure-cap',
  cap_active: '--phase-cap-active',
  pending_verification: '--phase-pending-verification',
  closed: '--phase-closed',
};

const STATUS_DESCRIPTIONS: Record<AuditPhase, { purpose: string; owner: string; exit: string }> = {
  draft: {
    purpose: 'Audit has been created but not yet submitted. Editable working copy.',
    owner: 'Creator (Department Head / Compliance Head / Admin)',
    exit: 'Submitted to start Pre-Audit Preparation.',
  },
  pre_audit: {
    purpose: 'Pre-audit preparation: scope confirmation, checklist setup, and required attachments uploaded before fieldwork.',
    owner: 'Department Head (or assigned preparer)',
    exit: 'Submitted for Pre-Audit Review.',
  },
  pre_audit_review: {
    purpose: 'Pre-audit package submitted; awaiting approval to officially begin the audit.',
    owner: 'Compliance Head',
    exit: 'Approved → moves to Audit Overview, or returned to Pre-Audit.',
  },
  overview: {
    purpose: 'Audit officially started. Scope, criteria, and assignees confirmed; fieldwork can begin.',
    owner: 'Department Head',
    exit: 'Proceeds to Evidence Collection.',
  },
  evidence_collection: {
    purpose: 'Active gathering of documents, screenshots, logs and records that support the audit findings.',
    owner: 'Department Head and assigned staff',
    exit: 'All required evidence uploaded → Evaluation.',
  },
  evaluation: {
    purpose: 'Reviewing collected evidence against criteria. Findings, gaps and observations are documented.',
    owner: 'Department Head',
    exit: 'Submitted for Internal Review.',
  },
  internal_review: {
    purpose: 'Internal QA pass. Reviewer validates findings, evidence quality, and completeness.',
    owner: 'Compliance Head (Internal) or Department Head reviewer',
    exit: 'Approved → Closure & CAP, or sent back as Remediation Required.',
  },
  remediation_required: {
    purpose: 'Returned with reviewer comments. Owner must address gaps before re-submitting.',
    owner: 'Department Head',
    exit: 'Re-submitted → returns to Internal Review.',
  },
  closure_cap: {
    purpose: 'Closure decision point: choose to Close Without CAP or raise a Corrective Action Plan.',
    owner: 'Compliance Head',
    exit: 'Closed (no CAP) → Closed; CAP raised → CAP Active.',
  },
  cap_active: {
    purpose: 'A CAP has been raised and is being executed in the CAPA / ComplianceConnect microapp. AuditPro tracks the link.',
    owner: 'CAP Owner (external microapp)',
    exit: 'CAP completed externally → Pending Verification.',
  },
  pending_verification: {
    purpose: 'CAP execution complete. Awaiting QA verification that corrective actions effectively addressed the finding.',
    owner: 'Compliance Head (QA)',
    exit: 'Verified → Closed; insufficient → CAP reopened.',
  },
  closed: {
    purpose: 'Final state. Audit is locked, audit pack is exportable, and history is preserved.',
    owner: 'System (read-only for all roles)',
    exit: 'Terminal status. Periodic audits will spawn a new instance per schedule.',
  },
};

export function StatusReference() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-foreground mb-2">Audit Status Reference</h2>
        <p className="text-sm text-muted-foreground leading-relaxed">
          The audit lifecycle is expressed through 12 sequential statuses, shown on every audit card and
          in the <strong>All Audits</strong> view. Each status uses a dedicated color token from the
          design system so it can be recognized at a glance. The table below explains the purpose, the
          typical owner, and how an audit exits each status.
        </p>
      </div>

      <div className="rounded-lg border border-border/50 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead className="w-[60px]">#</TableHead>
              <TableHead className="w-[220px]">Status</TableHead>
              <TableHead>Purpose</TableHead>
              <TableHead className="w-[200px]">Typical Owner</TableHead>
              <TableHead className="w-[260px]">Exit Condition</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {PHASE_ORDER.map((phase, idx) => {
              const info = STATUS_DESCRIPTIONS[phase];
              const colorVar = STATUS_VAR[phase];
              return (
                <TableRow key={phase}>
                  <TableCell className="font-mono text-xs text-muted-foreground">{idx + 1}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span
                        aria-hidden="true"
                        className="inline-block h-3 w-3 rounded-full ring-2 ring-offset-1 ring-offset-background"
                        style={{
                          backgroundColor: `hsl(var(${colorVar}))`,
                          boxShadow: `0 0 0 1px hsl(var(${colorVar}) / 0.3)`,
                        }}
                      />
                      <span
                        className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold"
                        style={{
                          backgroundColor: `hsl(var(${colorVar}) / 0.12)`,
                          color: `hsl(var(${colorVar}))`,
                          borderColor: `hsl(var(${colorVar}) / 0.3)`,
                        }}
                      >
                        {PHASE_LABELS[phase]}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground leading-relaxed">
                    {info.purpose}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{info.owner}</TableCell>
                  <TableCell className="text-sm text-muted-foreground leading-relaxed">
                    {info.exit}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      <div className="rounded-lg border border-border/50 bg-muted/30 p-4 text-sm text-muted-foreground">
        <p className="mb-2">
          <strong className="text-foreground">Note:</strong> Status colors shown here match the badges
          rendered on audit cards in <em>All Audits</em>, the dashboard, and audit detail pages. Status
          progression is driven exclusively by workflow action buttons — there is no manual
          previous/next navigation.
        </p>
        <p>
          Statuses <code className="text-primary bg-primary/10 px-1 rounded">cap_active</code> and{' '}
          <code className="text-primary bg-primary/10 px-1 rounded">pending_verification</code> are
          only reached when a CAP is raised; otherwise audits move directly from{' '}
          <em>Closure &amp; CAP</em> to <em>Closed</em>.
        </p>
      </div>
    </div>
  );
}
