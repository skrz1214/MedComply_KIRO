import { AuditPhase, PHASE_LABELS, ClosureType, CLOSURE_TYPE_LABELS } from '@/types/audit';
import { cn } from '@/lib/utils';
import {
  CircleDot,
  Clock,
  Eye,
  Search,
  ClipboardCheck,
  AlertCircle,
  FileWarning,
  CheckCircle2,
  ShieldCheck,
  ShieldX,
  GitMerge,
  XCircle,
  FileSearch,
  Send,
} from 'lucide-react';

interface PhaseBadgeProps {
  phase: AuditPhase;
  closureType?: ClosureType;
  size?: 'sm' | 'md';
}

const phaseConfig: Record<AuditPhase, {
  className: string;
  icon: React.ElementType;
}> = {
  draft: {
    className: 'bg-muted text-muted-foreground',
    icon: CircleDot,
  },
  pre_audit: {
    className: 'bg-status-pending-bg text-status-pending',
    icon: FileSearch,
  },
  pre_audit_review: {
    className: 'bg-status-warning-bg text-status-warning',
    icon: Eye,
  },
  overview: {
    className: 'bg-status-info-bg text-status-info',
    icon: Clock,
  },
  evidence_collection: {
    className: 'bg-status-info-bg text-status-info',
    icon: Search,
  },
  evaluation: {
    className: 'bg-status-pending-bg text-status-pending',
    icon: ClipboardCheck,
  },
  internal_review: {
    className: 'bg-status-warning-bg text-status-warning',
    icon: Send,
  },
  remediation_required: {
    className: 'bg-status-error-bg text-status-error',
    icon: AlertCircle,
  },
  closure_cap: {
    className: 'bg-status-pending-bg text-status-pending',
    icon: ShieldCheck,
  },
  cap_active: {
    className: 'bg-status-warning-bg text-status-warning',
    icon: FileWarning,
  },
  pending_verification: {
    className: 'bg-status-pending-bg text-status-pending',
    icon: ClipboardCheck,
  },
  closed: {
    className: 'bg-status-success-bg text-status-success',
    icon: CheckCircle2,
  },
};

const closureTypeConfig: Record<ClosureType, {
  className: string;
  icon: React.ElementType;
}> = {
  with_cap: {
    className: 'bg-status-success-bg text-status-success',
    icon: ShieldCheck,
  },
  without_cap: {
    className: 'bg-status-success-bg text-status-success',
    icon: CheckCircle2,
  },
  risk_accepted: {
    className: 'bg-status-warning-bg text-status-warning',
    icon: ShieldX,
  },
  duplicate_merged: {
    className: 'bg-muted text-muted-foreground',
    icon: GitMerge,
  },
  invalidated: {
    className: 'bg-muted text-muted-foreground',
    icon: XCircle,
  },
};

/**
 * PhaseBadge — single visual indicator for an audit's lifecycle position.
 *
 * Phase is the only user-facing concept (status has been removed in v2).
 * For closed audits with a closureType, the closure variant is shown
 * (e.g. "Closed – With CAP").
 */
export function PhaseBadge({ phase, closureType, size = 'md' }: PhaseBadgeProps) {
  // For closed audits, show the closure type variant if available.
  if (phase === 'closed' && closureType) {
    const config = closureTypeConfig[closureType];
    const Icon = config.icon;
    return (
      <span
        className={cn(
          'inline-flex items-center gap-1.5 rounded-full font-medium',
          config.className,
          size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-3 py-1 text-sm',
        )}
      >
        <Icon className={size === 'sm' ? 'h-3 w-3' : 'h-4 w-4'} aria-hidden="true" />
        {CLOSURE_TYPE_LABELS[closureType]}
      </span>
    );
  }

  const config = phaseConfig[phase];
  const Icon = config.icon;
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full font-medium',
        config.className,
        size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-3 py-1 text-sm',
      )}
    >
      <Icon className={size === 'sm' ? 'h-3 w-3' : 'h-4 w-4'} aria-hidden="true" />
      {PHASE_LABELS[phase]}
    </span>
  );
}

/**
 * @deprecated Use `PhaseBadge` with the `phase` prop instead. This compat
 * shim accepts the legacy `status` prop name and forwards it as `phase`.
 */
export function StatusBadge({
  status,
  closureType,
  size = 'md',
}: {
  status: AuditPhase;
  closureType?: ClosureType;
  size?: 'sm' | 'md';
}) {
  return <PhaseBadge phase={status} closureType={closureType} size={size} />;
}
