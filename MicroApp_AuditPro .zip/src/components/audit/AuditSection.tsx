import { AuditItem } from '@/types/audit';
import { AuditCard } from './AuditCard';
import { cn } from '@/lib/utils';

interface AuditSectionProps {
  title: string;
  subtitle?: string;
  items: AuditItem[];
  onAuditClick: (audit: AuditItem) => void;
  emptyMessage?: string;
  icon?: React.ReactNode;
}

export function AuditSection({ 
  title, 
  subtitle,
  items, 
  onAuditClick, 
  emptyMessage = 'No items',
  icon
}: AuditSectionProps) {
  return (
    <div className="animate-fade-in">
      <div className="flex items-center gap-3 mb-4">
        {icon}
        <div>
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            {title}
            <span className="inline-flex items-center justify-center min-w-[24px] h-6 px-2 rounded-full bg-primary/10 text-primary text-sm font-medium">
              {items.length}
            </span>
          </h2>
          {subtitle && (
            <p className="text-sm text-muted-foreground">{subtitle}</p>
          )}
        </div>
      </div>
      
      {items.length === 0 ? (
        <div className="bg-muted/30 rounded-lg border border-dashed border-border p-8 text-center">
          <p className="text-muted-foreground">{emptyMessage}</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {items.map((audit, index) => (
            <div 
              key={audit.id} 
              className="animate-slide-up"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <AuditCard audit={audit} onClick={() => onAuditClick(audit)} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
