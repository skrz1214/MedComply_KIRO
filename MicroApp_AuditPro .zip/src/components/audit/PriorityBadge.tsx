import { cn } from '@/lib/utils';

interface PriorityBadgeProps {
  priority: 'low' | 'medium' | 'high' | 'critical';
  size?: 'sm' | 'md';
}

const priorityConfig = {
  low: {
    label: 'Low',
    className: 'bg-muted text-muted-foreground',
  },
  medium: {
    label: 'Medium',
    className: 'bg-status-info-bg text-status-info',
  },
  high: {
    label: 'High',
    className: 'bg-status-warning-bg text-status-warning',
  },
  critical: {
    label: 'Critical',
    className: 'bg-status-error-bg text-status-error',
  },
};

export function PriorityBadge({ priority, size = 'md' }: PriorityBadgeProps) {
  const config = priorityConfig[priority];

  return (
    <span
      className={cn(
        'inline-flex items-center rounded font-medium uppercase tracking-wide',
        config.className,
        size === 'sm' ? 'px-1.5 py-0.5 text-[10px]' : 'px-2 py-0.5 text-xs'
      )}
    >
      {config.label}
    </span>
  );
}
