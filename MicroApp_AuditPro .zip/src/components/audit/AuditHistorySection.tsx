import { useNavigate } from 'react-router-dom';
import { AuditItem } from '@/types/audit';
import { Check, ArrowRight, History as HistoryIcon, FileText } from 'lucide-react';

interface AuditHistorySectionProps {
  audit: AuditItem;
  pastAudits: AuditItem[];
  source: string;
}

export function AuditHistorySection({ audit, pastAudits, source }: AuditHistorySectionProps) {
  const navigate = useNavigate();

  // Only show for periodic audits
  if (!audit.isPeriodic) {
    return null;
  }

  return (
    <div className="p-4 rounded-lg border border-border/50 bg-card">
      <div className="flex items-center gap-2 mb-4">
        <HistoryIcon className="h-5 w-5 text-primary" />
        <h4 className="font-semibold text-foreground">Audit History</h4>
        {pastAudits.length > 0 && (
          <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
            {pastAudits.length} previous
          </span>
        )}
      </div>

      {pastAudits.length > 0 ? (
        <div className="space-y-2">
          {pastAudits.map((pastAudit) => (
            <button
              key={pastAudit.id}
              onClick={() => navigate(`/audit/${pastAudit.id}/phase/overview?source=${source}`)}
              className="w-full flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors text-left"
            >
              <div className="flex items-center gap-3">
                <div className="h-8 w-8 rounded-full bg-status-success/10 flex items-center justify-center">
                  <Check className="h-4 w-4 text-status-success" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">
                    Completed {new Date(pastAudit.createdAt).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {pastAudit.actions.filter(a => a.completed).length}/{pastAudit.actions.length} actions • {Object.values(pastAudit.phaseAttachments || {}).flat().length} attachments
                  </p>
                </div>
              </div>
              <ArrowRight className="h-4 w-4 text-muted-foreground" />
            </button>
          ))}
        </div>
      ) : (
        <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/30">
          <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
            <FileText className="h-4 w-4 text-muted-foreground" />
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">No Previous History</p>
            <p className="text-xs text-muted-foreground">
              This is the first audit cycle for this periodic audit
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
