import { AuditItem, PHASE_LABELS, CLOSURE_TYPE_LABELS } from '@/types/audit';
import { Card, CardContent } from '@/components/ui/card';
import { StatusBadge } from './StatusBadge';
import { PriorityBadge } from './PriorityBadge';
import { Calendar, User, Building2, ArrowRight, FileText, FolderSearch, ClipboardCheck, ShieldCheck, FileSearch, FileEdit, Eye, AlertTriangle, Clock, FileWarning } from 'lucide-react';
import { cn } from '@/lib/utils';

const phaseIcons: Record<string, React.ElementType> = {
  draft: FileEdit,
  pre_audit: FileSearch,
  pre_audit_review: Eye,
  overview: FileText,
  evidence_collection: FolderSearch,
  evaluation: ClipboardCheck,
  internal_review: ClipboardCheck,
  remediation_required: AlertTriangle,
  closure_cap: ShieldCheck,
  cap_active: FileWarning,
  pending_verification: Clock,
  closed: ShieldCheck,
};

const phaseColors: Record<string, string> = {
  draft: 'bg-phase-draft/15 text-phase-draft',
  pre_audit: 'bg-phase-pre-audit/15 text-phase-pre-audit',
  pre_audit_review: 'bg-phase-pre-audit-review/15 text-phase-pre-audit-review',
  overview: 'bg-phase-overview/15 text-phase-overview',
  evidence_collection: 'bg-phase-evidence-collection/15 text-phase-evidence-collection',
  evaluation: 'bg-phase-evaluation/15 text-phase-evaluation',
  internal_review: 'bg-phase-internal-review/15 text-phase-internal-review',
  remediation_required: 'bg-phase-remediation-required/15 text-phase-remediation-required',
  closure_cap: 'bg-phase-closure-cap/15 text-phase-closure-cap',
  cap_active: 'bg-phase-cap-active/15 text-phase-cap-active',
  pending_verification: 'bg-phase-pending-verification/15 text-phase-pending-verification',
  closed: 'bg-phase-closed/15 text-phase-closed',
};

interface AuditCardProps {
  audit: AuditItem;
  onClick: () => void;
}

export function AuditCard({ audit, onClick }: AuditCardProps) {
  const isOverdue = new Date(audit.dueDate) < new Date() && audit.status !== 'closed';
  const PhaseIcon = phaseIcons[audit.currentPhase] ?? FileText;

  return (
    <Card 
      className={cn(
        'cursor-pointer transition-all duration-200 hover:shadow-elevated hover:-translate-y-0.5 group',
        'border-border/50 bg-card'
      )}
      onClick={onClick}
    >
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <span className={cn(
                'text-xs font-medium uppercase tracking-wider',
                audit.type === 'external' ? 'text-status-pending' : 'text-primary'
              )}>
                {audit.type} Audit
              </span>
              <PriorityBadge priority={audit.priority} size="sm" />
            </div>
            
            <h3 className="font-semibold text-foreground mb-1 truncate group-hover:text-primary transition-colors">
              {audit.title}
            </h3>
            
            <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
              {audit.description}
            </p>

            <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <User className="h-4 w-4" />
                <span>{audit.assignedToName}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Building2 className="h-4 w-4" />
                <span>{audit.department}</span>
              </div>
              <div className={cn(
                'flex items-center gap-1.5',
                isOverdue && 'text-status-error font-medium'
              )}>
                <Calendar className="h-4 w-4" />
                <span>{isOverdue ? 'Overdue: ' : 'Due: '}{audit.dueDate}</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col items-end gap-3">
            {audit.status === 'closed' && audit.closureType ? (
              <StatusBadge status={audit.status} closureType={audit.closureType} size="sm" />
            ) : (
              <span
                className={cn(
                  'inline-flex items-center gap-1.5 rounded-full font-medium px-2 py-0.5 text-xs',
                  phaseColors[audit.currentPhase]
                )}
              >
                <PhaseIcon className="h-3 w-3" />
                {PHASE_LABELS[audit.currentPhase]}
              </span>
            )}
            <ArrowRight className="h-5 w-5 text-muted-foreground/50 group-hover:text-primary group-hover:translate-x-1 transition-all" />
          </div>
        </div>

        {/* Progress indicator */}
        {audit.actions.length > 0 && (
          <div className="mt-4 pt-4 border-t border-border/50">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="text-muted-foreground">Action Progress</span>
              <span className="font-medium text-foreground">
                {audit.actions.filter(a => a.completed).length}/{audit.actions.length}
              </span>
            </div>
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary rounded-full transition-all duration-500"
                style={{ 
                  width: `${(audit.actions.filter(a => a.completed).length / audit.actions.length) * 100}%` 
                }}
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
