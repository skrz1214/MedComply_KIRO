import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  Link2, 
  Plus, 
  ExternalLink, 
  Trash2, 
  Shield, 
  AlertTriangle,
  MessageSquare,
  Gavel
} from 'lucide-react';
import { 
  LinkedItem, 
  MicroApp, 
  MICROAPP_LABELS, 
  MICROAPP_COLORS 
} from '@/types/audit';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface LinkedItemsSectionProps {
  auditId: string;
  linkedItems: LinkedItem[];
  onAddLink: (item: Omit<LinkedItem, 'id' | 'linkedAt' | 'linkedBy'>) => void;
  onRemoveLink: (itemId: string) => void;
  readOnly?: boolean;
}

const MICROAPP_ICONS: Record<MicroApp, React.ReactNode> = {
  RiskGuard: <AlertTriangle className="h-4 w-4" />,
  ComplianceConnect: <Shield className="h-4 w-4" />,
  FeedbackHub: <MessageSquare className="h-4 w-4" />,
  EnforcePoint: <Gavel className="h-4 w-4" />,
};

// Mock data for demonstration - in real app, this would come from API
const MOCK_ITEMS: Record<MicroApp, { id: string; title: string; type: string; status: string }[]> = {
  RiskGuard: [
    { id: 'RG-001', title: 'Data Breach Risk Assessment', type: 'Risk Assessment', status: 'Open' },
    { id: 'RG-002', title: 'Third Party Vendor Risk', type: 'Vendor Risk', status: 'In Progress' },
    { id: 'RG-003', title: 'System Vulnerability Analysis', type: 'IT Risk', status: 'Pending Review' },
  ],
  ComplianceConnect: [
    { id: 'CC-001', title: 'HIPAA Compliance Review', type: 'Regulatory', status: 'Active' },
    { id: 'CC-002', title: 'Annual Policy Update', type: 'Policy', status: 'Draft' },
    { id: 'CC-003', title: 'Training Completion Tracking', type: 'Training', status: 'In Progress' },
  ],
  FeedbackHub: [
    { id: 'FH-001', title: 'Patient Safety Concern Report', type: 'Safety Report', status: 'New' },
    { id: 'FH-002', title: 'Staff Feedback - Process Improvement', type: 'Feedback', status: 'Under Review' },
    { id: 'FH-003', title: 'Equipment Malfunction Report', type: 'Incident Report', status: 'Investigating' },
  ],
  EnforcePoint: [
    { id: 'EP-001', title: 'Policy Violation - Documentation', type: 'Enforcement', status: 'Pending Action' },
    { id: 'EP-002', title: 'Corrective Action Required', type: 'Corrective Action', status: 'In Progress' },
    { id: 'EP-003', title: 'Follow-up Inspection', type: 'Inspection', status: 'Scheduled' },
  ],
};

export function LinkedItemsSection({ 
  auditId, 
  linkedItems, 
  onAddLink, 
  onRemoveLink,
  readOnly = false 
}: LinkedItemsSectionProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedMicroApp, setSelectedMicroApp] = useState<MicroApp | ''>('');
  const [selectedItemId, setSelectedItemId] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();

  const availableItems = selectedMicroApp ? MOCK_ITEMS[selectedMicroApp] : [];
  const filteredItems = availableItems.filter(item => 
    item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedItem = availableItems.find(item => item.id === selectedItemId);

  const handleAddLink = () => {
    if (!selectedMicroApp || !selectedItem) return;

    // Check if already linked
    if (linkedItems.some(l => l.itemId === selectedItem.id && l.microApp === selectedMicroApp)) {
      toast({
        title: 'Already Linked',
        description: 'This item is already linked to this audit.',
        variant: 'destructive',
      });
      return;
    }

    onAddLink({
      microApp: selectedMicroApp,
      itemId: selectedItem.id,
      itemTitle: selectedItem.title,
      itemType: selectedItem.type,
      status: selectedItem.status,
      url: `/${selectedMicroApp.toLowerCase()}/${selectedItem.id}`,
    });

    toast({
      title: 'Item Linked',
      description: `${selectedItem.title} has been linked to this audit.`,
    });

    setDialogOpen(false);
    setSelectedMicroApp('');
    setSelectedItemId('');
    setSearchTerm('');
  };

  const handleRemoveLink = (item: LinkedItem) => {
    onRemoveLink(item.id);
    toast({
      title: 'Link Removed',
      description: `${item.itemTitle} has been unlinked from this audit.`,
    });
  };

  return (
    <Card className="border-border/50">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg flex items-center gap-2">
          <Link2 className="h-5 w-5 text-primary" />
          Cross-Microapp Links
          {linkedItems.length > 0 && (
            <Badge variant="secondary" className="ml-2">
              {linkedItems.length}
            </Badge>
          )}
        </CardTitle>
        {!readOnly && (
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="gap-2">
                <Plus className="h-4 w-4" />
                Link Item
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Link External Item</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Select Microapp</Label>
                  <Select 
                    value={selectedMicroApp} 
                    onValueChange={(value) => {
                      setSelectedMicroApp(value as MicroApp);
                      setSelectedItemId('');
                      setSearchTerm('');
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a microapp..." />
                    </SelectTrigger>
                    <SelectContent>
                      {(Object.keys(MICROAPP_LABELS) as MicroApp[]).map((app) => (
                        <SelectItem key={app} value={app}>
                          <div className="flex items-center gap-2">
                            {MICROAPP_ICONS[app]}
                            {MICROAPP_LABELS[app]}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedMicroApp && (
                  <>
                    <div className="space-y-2">
                      <Label>Search Items</Label>
                      <Input
                        placeholder="Search by title or ID..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Select Item</Label>
                      <div className="max-h-48 overflow-y-auto border rounded-md">
                        {filteredItems.length === 0 ? (
                          <p className="p-4 text-sm text-muted-foreground text-center">
                            No items found
                          </p>
                        ) : (
                          filteredItems.map((item) => (
                            <button
                              key={item.id}
                              onClick={() => setSelectedItemId(item.id)}
                              className={cn(
                                'w-full p-3 text-left border-b last:border-b-0 hover:bg-muted/50 transition-colors',
                                selectedItemId === item.id && 'bg-primary/5 border-l-2 border-l-primary'
                              )}
                            >
                              <div className="flex items-start justify-between gap-2">
                                <div>
                                  <p className="font-medium text-sm">{item.title}</p>
                                  <p className="text-xs text-muted-foreground">{item.id} • {item.type}</p>
                                </div>
                                <Badge variant="outline" className="text-xs shrink-0">
                                  {item.status}
                                </Badge>
                              </div>
                            </button>
                          ))
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddLink} disabled={!selectedMicroApp || !selectedItemId}>
                  Link Item
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </CardHeader>
      <CardContent>
        {linkedItems.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Link2 className="h-10 w-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No linked items</p>
            <p className="text-xs mt-1">Link items from other microapps to track relationships</p>
          </div>
        ) : (
          <div className="space-y-3">
            {linkedItems.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-muted/30 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className={cn('p-2 rounded-lg', MICROAPP_COLORS[item.microApp])}>
                    {MICROAPP_ICONS[item.microApp]}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-sm">{item.itemTitle}</p>
                      <Badge 
                        variant="outline" 
                        className={cn('text-xs', MICROAPP_COLORS[item.microApp])}
                      >
                        {MICROAPP_LABELS[item.microApp]}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {item.itemId} • {item.itemType} • {item.status}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {item.url && (
                    <Button variant="ghost" size="icon" className="h-8 w-8" asChild>
                      <a href={item.url} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    </Button>
                  )}
                  {!readOnly && (
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8 text-destructive hover:text-destructive"
                      onClick={() => handleRemoveLink(item)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
