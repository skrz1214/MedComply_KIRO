import { CAPStatus } from '@/types/cap';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface CAPStatusBadgeProps {
  status: CAPStatus;
  className?: string;
}

const statusConfig: Record<CAPStatus, { label: string; variant: string }> = {
  not_started: { label: 'Not Started', variant: 'bg-muted text-muted-foreground' },
  in_progress: { label: 'In Progress', variant: 'bg-status-info-bg text-status-info border-status-info/20' },
  blocked: { label: 'Blocked', variant: 'bg-status-error-bg text-status-error border-status-error/20' },
  ready_for_verification: { label: 'Ready for Verification', variant: 'bg-status-warning-bg text-status-warning border-status-warning/20' },
  verified: { label: 'Verified', variant: 'bg-status-success-bg text-status-success border-status-success/20' },
  closed: { label: 'Closed', variant: 'bg-status-success-bg text-status-success border-status-success/20' },
};

export function CAPStatusBadge({ status, className }: CAPStatusBadgeProps) {
  const config = statusConfig[status];
  
  return (
    <Badge 
      variant="outline" 
      className={cn('font-medium border', config.variant, className)}
    >
      {config.label}
    </Badge>
  );
}
