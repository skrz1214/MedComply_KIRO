import { useState } from 'react';
import { CAP, CAPAction, CAPActionType } from '@/types/cap';
import { useCAP } from '@/contexts/CAPContext';
import { useAudit } from '@/contexts/AuditContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { CAPStatusBadge } from './CAPStatusBadge';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { 
  Plus, 
  FileText, 
  Calendar, 
  User, 
  CheckCircle2, 
  AlertTriangle,
  Clock,
  Upload,
  Trash2,
  Edit2,
  Shield,
  XCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface CAPManagementProps {
  auditId: string;
  onCAPCreated?: (cap: CAP) => void;
  onCAPVerified?: () => void;
}

export function CAPManagement({ auditId, onCAPCreated, onCAPVerified }: CAPManagementProps) {
  const { 
    getCAPByAuditId, 
    createCAP, 
    addCAPAction, 
    updateCAPAction,
    deleteCAPAction,
    markActionComplete, 
    submitForVerification,
    verifyCAPAndClose,
    addCAPEvidence
  } = useCAP();
  const { currentUser, users } = useAudit();

  const cap = getCAPByAuditId(auditId);
  
  const [showCreateCAP, setShowCreateCAP] = useState(false);
  const [showAddAction, setShowAddAction] = useState(false);
  const [showVerification, setShowVerification] = useState(false);
  const [editingAction, setEditingAction] = useState<CAPAction | null>(null);

  // Create CAP form state
  const [rootCause, setRootCause] = useState('');
  const [capOwner, setCAPOwner] = useState(currentUser.id);
  const [targetDate, setTargetDate] = useState('');

  // Add action form state
  const [actionTitle, setActionTitle] = useState('');
  const [actionDescription, setActionDescription] = useState('');
  const [actionType, setActionType] = useState<CAPActionType>('corrective');
  const [actionOwner, setActionOwner] = useState(currentUser.id);
  const [actionDueDate, setActionDueDate] = useState('');

  // Verification form state
  const [verificationOutcome, setVerificationOutcome] = useState<'pass' | 'fail'>('pass');
  const [verificationNotes, setVerificationNotes] = useState('');

  const handleCreateCAP = () => {
    if (!rootCause.trim() || !targetDate) {
      toast.error('Please fill in all required fields');
      return;
    }

    const owner = users.find(u => u.id === capOwner);
    const newCAP = createCAP({
      auditId,
      rootCause,
      ownerId: capOwner,
      ownerName: owner?.name || currentUser.name,
      targetCompletionDate: targetDate,
    });

    toast.success('CAP created successfully');
    setShowCreateCAP(false);
    setRootCause('');
    setTargetDate('');
    onCAPCreated?.(newCAP);
  };

  const handleAddAction = () => {
    if (!cap || !actionTitle.trim() || !actionDueDate) {
      toast.error('Please fill in all required fields');
      return;
    }

    const owner = users.find(u => u.id === actionOwner);
    addCAPAction(cap.id, {
      title: actionTitle,
      description: actionDescription,
      type: actionType,
      ownerId: actionOwner,
      ownerName: owner?.name || currentUser.name,
      dueDate: actionDueDate,
    });

    toast.success('Action added successfully');
    setShowAddAction(false);
    resetActionForm();
  };

  const handleUpdateAction = () => {
    if (!cap || !editingAction || !actionTitle.trim() || !actionDueDate) {
      toast.error('Please fill in all required fields');
      return;
    }

    const owner = users.find(u => u.id === actionOwner);
    updateCAPAction(cap.id, editingAction.id, {
      title: actionTitle,
      description: actionDescription,
      type: actionType,
      ownerId: actionOwner,
      ownerName: owner?.name || currentUser.name,
      dueDate: actionDueDate,
    });

    toast.success('Action updated successfully');
    setEditingAction(null);
    resetActionForm();
  };

  const resetActionForm = () => {
    setActionTitle('');
    setActionDescription('');
    setActionType('corrective');
    setActionOwner(currentUser.id);
    setActionDueDate('');
  };

  const handleEditAction = (action: CAPAction) => {
    setEditingAction(action);
    setActionTitle(action.title);
    setActionDescription(action.description);
    setActionType(action.type);
    setActionOwner(action.ownerId);
    setActionDueDate(action.dueDate);
  };

  const handleDeleteAction = (actionId: string) => {
    if (!cap) return;
    deleteCAPAction(cap.id, actionId);
    toast.success('Action deleted');
  };

  const handleMarkComplete = (actionId: string) => {
    if (!cap) return;
    markActionComplete(cap.id, actionId, currentUser.name);
    toast.success('Action marked as complete');
  };

  const handleSubmitForVerification = () => {
    if (!cap) return;
    
    const incompleteActions = cap.actions.filter(a => a.status !== 'completed');
    if (incompleteActions.length > 0) {
      toast.error('All actions must be completed before verification');
      return;
    }

    submitForVerification(cap.id);
    toast.success('CAP submitted for verification');
  };

  const handleVerify = () => {
    if (!cap) return;

    verifyCAPAndClose(cap.id, {
      verifierId: currentUser.id,
      verifierName: currentUser.name,
      verifiedAt: new Date().toISOString(),
      outcome: verificationOutcome,
      notes: verificationNotes,
      evidence: [],
    });

    if (verificationOutcome === 'pass') {
      toast.success('CAP verified and closed');
      onCAPVerified?.();
    } else {
      toast.info('CAP verification failed - returned to in progress');
    }

    setShowVerification(false);
    setVerificationNotes('');
  };

  const allActionsComplete = cap ? cap.actions.every(a => a.status === 'completed') : false;
  const canVerify = cap && cap.status === 'ready_for_verification' && 
    (currentUser.role === 'compliance_head' || currentUser.role === 'admin');

  // No CAP exists - show create CTA
  if (!cap) {
    return (
      <Card className="border-border/50">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <div className="h-16 w-16 rounded-full bg-status-warning-bg flex items-center justify-center mb-4">
            <AlertTriangle className="h-8 w-8 text-status-warning" />
          </div>
          <h3 className="text-lg font-semibold mb-2">No Corrective Action Plan</h3>
          <p className="text-muted-foreground text-center mb-6 max-w-md">
            A CAP has not been created for this audit item. Create one to define corrective and preventive actions.
          </p>
          
          <Dialog open={showCreateCAP} onOpenChange={setShowCreateCAP}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Create CAP
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Create Corrective Action Plan</DialogTitle>
                <DialogDescription>
                  Define the root cause and assign ownership for corrective actions.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="rootCause">
                    Root Cause Analysis <span className="text-status-error">*</span>
                  </Label>
                  <Textarea
                    id="rootCause"
                    placeholder="Describe the root cause of the finding..."
                    value={rootCause}
                    onChange={(e) => setRootCause(e.target.value)}
                    rows={4}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="capOwner">
                      CAP Owner <span className="text-status-error">*</span>
                    </Label>
                    <Select value={capOwner} onValueChange={setCAPOwner}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select owner" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover border-border z-50">
                        {users.map((user) => (
                          <SelectItem key={user.id} value={user.id}>
                            {user.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="targetDate">
                      Target Completion <span className="text-status-error">*</span>
                    </Label>
                    <Input
                      id="targetDate"
                      type="date"
                      value={targetDate}
                      onChange={(e) => setTargetDate(e.target.value)}
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowCreateCAP(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateCAP}>Create CAP</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>
    );
  }

  // CAP exists - show management UI
  return (
    <div className="space-y-6">
      {/* CAP Header */}
      <Card className="border-border/50">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg">Corrective Action Plan</CardTitle>
              <CardDescription>Manage corrective and preventive actions</CardDescription>
            </div>
            <CAPStatusBadge status={cap.status} />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-lg bg-muted/50">
              <p className="text-sm text-muted-foreground mb-1">CAP Owner</p>
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">{cap.ownerName}</span>
              </div>
            </div>
            <div className="p-4 rounded-lg bg-muted/50">
              <p className="text-sm text-muted-foreground mb-1">Target Completion</p>
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">{cap.targetCompletionDate}</span>
              </div>
            </div>
            <div className="p-4 rounded-lg bg-muted/50">
              <p className="text-sm text-muted-foreground mb-1">Actions</p>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">
                  {cap.actions.filter(a => a.status === 'completed').length}/{cap.actions.length} Complete
                </span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-muted/30 border border-border/50">
            <p className="text-sm font-medium mb-1">Root Cause</p>
            <p className="text-sm text-muted-foreground">{cap.rootCause}</p>
          </div>
        </CardContent>
      </Card>

      {/* Actions Table */}
      <Card className="border-border/50">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Actions</CardTitle>
            <Dialog open={showAddAction || !!editingAction} onOpenChange={(open) => {
              if (!open) {
                setShowAddAction(false);
                setEditingAction(null);
                resetActionForm();
              } else {
                setShowAddAction(true);
              }
            }}>
              <DialogTrigger asChild>
                <Button size="sm" className="gap-2">
                  <Plus className="h-4 w-4" />
                  Add Action
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>{editingAction ? 'Edit Action' : 'Add Action'}</DialogTitle>
                  <DialogDescription>
                    Define a corrective or preventive action to address the finding.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="actionTitle">
                      Action Title <span className="text-status-error">*</span>
                    </Label>
                    <Input
                      id="actionTitle"
                      placeholder="Enter action title..."
                      value={actionTitle}
                      onChange={(e) => setActionTitle(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="actionDescription">Description</Label>
                    <Textarea
                      id="actionDescription"
                      placeholder="Describe the action in detail..."
                      value={actionDescription}
                      onChange={(e) => setActionDescription(e.target.value)}
                      rows={3}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="actionType">Type</Label>
                      <Select value={actionType} onValueChange={(v) => setActionType(v as CAPActionType)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-popover border-border z-50">
                          <SelectItem value="corrective">Corrective</SelectItem>
                          <SelectItem value="preventive">Preventive</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="actionOwner">Owner</Label>
                      <Select value={actionOwner} onValueChange={setActionOwner}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-popover border-border z-50">
                          {users.map((user) => (
                            <SelectItem key={user.id} value={user.id}>
                              {user.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="actionDueDate">
                      Due Date <span className="text-status-error">*</span>
                    </Label>
                    <Input
                      id="actionDueDate"
                      type="date"
                      value={actionDueDate}
                      onChange={(e) => setActionDueDate(e.target.value)}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => {
                    setShowAddAction(false);
                    setEditingAction(null);
                    resetActionForm();
                  }}>
                    Cancel
                  </Button>
                  <Button onClick={editingAction ? handleUpdateAction : handleAddAction}>
                    {editingAction ? 'Update Action' : 'Add Action'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {cap.actions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>No actions defined yet. Add actions to track corrective measures.</p>
            </div>
          ) : (
            <div className="rounded-lg border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>Action</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Owner</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {cap.actions.map((action) => (
                    <TableRow key={action.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{action.title}</p>
                          {action.description && (
                            <p className="text-sm text-muted-foreground line-clamp-1">
                              {action.description}
                            </p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={cn(
                          action.type === 'corrective' 
                            ? 'bg-status-info-bg text-status-info border-status-info/20' 
                            : 'bg-status-pending-bg text-status-pending border-status-pending/20'
                        )}>
                          {action.type === 'corrective' ? 'Corrective' : 'Preventive'}
                        </Badge>
                      </TableCell>
                      <TableCell>{action.ownerName}</TableCell>
                      <TableCell>{action.dueDate}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={cn(
                          action.status === 'completed' && 'bg-status-success-bg text-status-success border-status-success/20',
                          action.status === 'in_progress' && 'bg-status-info-bg text-status-info border-status-info/20',
                          action.status === 'blocked' && 'bg-status-error-bg text-status-error border-status-error/20',
                          action.status === 'pending' && 'bg-muted text-muted-foreground'
                        )}>
                          {action.status === 'completed' ? 'Completed' : 
                           action.status === 'in_progress' ? 'In Progress' :
                           action.status === 'blocked' ? 'Blocked' : 'Pending'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          {action.status !== 'completed' && (
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleMarkComplete(action.id)}
                              title="Mark complete"
                            >
                              <CheckCircle2 className="h-4 w-4 text-status-success" />
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleEditAction(action)}
                            title="Edit action"
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button size="sm" variant="ghost" title="Delete action">
                                <Trash2 className="h-4 w-4 text-status-error" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Action</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Are you sure you want to delete this action? This cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction 
                                  onClick={() => handleDeleteAction(action.id)}
                                  className="bg-status-error hover:bg-status-error/90"
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Verification Section */}
      {cap.actions.length > 0 && (
        <Card className="border-border/50">
          <CardHeader>
            <CardTitle className="text-lg">Verification</CardTitle>
          </CardHeader>
          <CardContent>
            {cap.status === 'verified' && cap.verification ? (
              <div className="p-4 rounded-lg bg-status-success-bg/50 border border-status-success/20">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="h-5 w-5 text-status-success" />
                  <span className="font-medium text-status-success">CAP Verified</span>
                </div>
                <div className="text-sm text-muted-foreground space-y-1">
                  <p>Verified by: {cap.verification.verifierName}</p>
                  <p>Date: {new Date(cap.verification.verifiedAt).toLocaleDateString()}</p>
                  {cap.verification.notes && <p>Notes: {cap.verification.notes}</p>}
                </div>
              </div>
            ) : cap.status === 'ready_for_verification' ? (
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-status-warning-bg/50 border border-status-warning/20">
                  <div className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-status-warning" />
                    <span className="font-medium text-status-warning">Awaiting Verification</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    All actions are complete. CAP is ready for verification.
                  </p>
                </div>
                {canVerify && (
                  <Dialog open={showVerification} onOpenChange={setShowVerification}>
                    <DialogTrigger asChild>
                      <Button className="gap-2">
                        <Shield className="h-4 w-4" />
                        Verify CAP
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Verify Corrective Action Plan</DialogTitle>
                        <DialogDescription>
                          Review the completed actions and determine if the CAP adequately addresses the finding.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div className="space-y-2">
                          <Label>Verification Outcome</Label>
                          <div className="grid grid-cols-2 gap-3">
                            <button
                              type="button"
                              onClick={() => setVerificationOutcome('pass')}
                              className={cn(
                                'flex items-center gap-2 p-3 rounded-lg border transition-all',
                                verificationOutcome === 'pass'
                                  ? 'border-status-success bg-status-success-bg/50'
                                  : 'border-border hover:border-status-success/50'
                              )}
                            >
                              <CheckCircle2 className={cn(
                                'h-5 w-5',
                                verificationOutcome === 'pass' ? 'text-status-success' : 'text-muted-foreground'
                              )} />
                              <span className="font-medium">Pass</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setVerificationOutcome('fail')}
                              className={cn(
                                'flex items-center gap-2 p-3 rounded-lg border transition-all',
                                verificationOutcome === 'fail'
                                  ? 'border-status-error bg-status-error-bg/50'
                                  : 'border-border hover:border-status-error/50'
                              )}
                            >
                              <XCircle className={cn(
                                'h-5 w-5',
                                verificationOutcome === 'fail' ? 'text-status-error' : 'text-muted-foreground'
                              )} />
                              <span className="font-medium">Fail</span>
                            </button>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="verificationNotes">Verification Notes</Label>
                          <Textarea
                            id="verificationNotes"
                            placeholder="Add verification notes..."
                            value={verificationNotes}
                            onChange={(e) => setVerificationNotes(e.target.value)}
                            rows={4}
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setShowVerification(false)}>
                          Cancel
                        </Button>
                        <Button 
                          onClick={handleVerify}
                          className={cn(
                            verificationOutcome === 'pass'
                              ? 'bg-status-success hover:bg-status-success/90'
                              : 'bg-status-error hover:bg-status-error/90'
                          )}
                        >
                          {verificationOutcome === 'pass' ? 'Verify & Close' : 'Fail Verification'}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-muted/50">
                  <p className="text-sm text-muted-foreground">
                    Complete all actions to submit for verification.
                  </p>
                  <div className="mt-2 flex items-center gap-2">
                    {allActionsComplete ? (
                      <CheckCircle2 className="h-4 w-4 text-status-success" />
                    ) : (
                      <Clock className="h-4 w-4 text-muted-foreground" />
                    )}
                    <span className="text-sm">
                      {cap.actions.filter(a => a.status === 'completed').length}/{cap.actions.length} actions complete
                    </span>
                  </div>
                </div>
                <Button 
                  onClick={handleSubmitForVerification}
                  disabled={!allActionsComplete}
                  className="gap-2"
                >
                  <Shield className="h-4 w-4" />
                  Request Verification
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
