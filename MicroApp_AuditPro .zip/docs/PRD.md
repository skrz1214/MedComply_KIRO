# AuditPro - Product Requirements Document (PRD)

**Version:** 2.5  
**Last Updated:** 2026-04-16  
**Status:** Active Development

---

## 1. Product Overview

### 1.1 Product Name
**AuditPro** - Healthcare Audit Management Microapp (Part of MedComply Suite)

### 1.2 Purpose
AuditPro provides centralized lifecycle management for internal and external audits in healthcare organizations. It streamlines audit workflows, evidence collection, review processes, and corrective action planning (CAP) with integration to ComplianceConnect.

### 1.3 Target Users
| Role | Description | Key Permissions |
|------|-------------|-----------------|
| **Staff (Read-only)** | View audits they are assigned to or belong to their department | View only, no edits |
| **Department Head** | Oversees department audits, assigns tasks, conducts internal reviews | Upload evidence, complete actions, assign phases, submit for review |
| **Compliance Head** | QA/Compliance authority for external audit closures | Final closure decisions, CAP determinations, org-wide visibility |
| **Admin** | Full system access and configuration | All permissions, Admin Settings access |

---

## 2. User Roles & Permissions

### 2.1 Role Definitions

#### Staff (Read-only)
- Can view audits they are assigned to OR belong to their department scope
- Can view phase details, evidence lists, action checklists, history
- **Cannot** upload evidence, edit audit fields, complete actions, submit for review, approve/reject, assign/reassign, change phase/status, or perform QA closure/CAP decisions
- Can add comments/notes only if policy allows (default: view-only, no comments)

#### Department Head
- Oversees department audits
- Can assign phase assignees within their department
- Can upload evidence and complete actions for audits in their department
- Can submit audits for internal review
- Can perform **internal review** decisions (approve/reject) for department audits
- Cannot access Admin Settings
- Cannot change system configuration

#### Compliance Head
- Equivalent to QA/Compliance authority for external audit closures
- Can access org-wide audit visibility
- Can perform QA review for external audits and final determinations in **closure_cap**
- Can decide **CAP required** vs **no CAP**, initiate CAP integration to ComplianceConnect
- Can override routing outcomes if policy allows (admin configurable)
- Cannot modify Admin Settings unless also Admin

#### Admin
- Full system access
- Can manage Admin Settings, departments, routing rules, templates, policies, integrations
- Can view and manage audit settings change logs

### 2.2 Permission Matrix

| Action | Staff | Dept Head | Compliance Head | Admin |
|--------|-------|-----------|-----------------|-------|
| View assigned audits | ✓ | ✓ | ✓ | ✓ |
| View department audits | ✓ | ✓ | ✓ | ✓ |
| View all audits | ✗ | ✗ | ✓ | ✓ |
| Create audits | ✗ | ✓ | ✓ | ✓ |
| Upload evidence | ✗ \* | ✓ | ✓ | ✓ |
| Complete actions | ✗ \* | ✓ | ✓ | ✓ |
| Assign phases | ✗ | ✓ | ✓ | ✓ |
| Submit for review | ✗ | ✓ | ✓ | ✓ |
| Approve/reject reviews | ✗ | ✓ | ✓ | ✓ |
| Close external audits | ✗ | ✗ | ✓ | ✓ |
| CAP decisions | ✗ | ✗ | ✓ | ✓ |
| Access Admin Settings | ✗ | ✗ | ✗ | ✓ |

\* **Assignee override:** When a user is the assignee of an audit (either the primary `assignedTo` user or the assignee of the current phase via `phaseAssignees`), they may **complete action items and upload evidence on that specific audit**, regardless of their base role. This override exists so Staff users can fulfill phase work assigned to them. It does **not** grant any other elevated permission (no submit-for-review, no approve/reject, no closure, no admin access). Outside of audits where they are the assignee, Staff remain strictly read-only.

### 2.3 Assignee Override Rule

- **Trigger:** `audit.assignedTo === currentUser.id` **OR** `audit.phaseAssignees[currentPhase] === currentUser.id`.
- **Granted on the affected audit only:**
  - `canCompleteActions: true` — toggle checklist action items as complete/incomplete on the current phase.
  - `canUploadEvidence: true` — upload phase attachments and evidence files.
  - `isReadOnly: false` — the read-only banner is suppressed for that audit.
- **Not granted by the override:** submitting for review, approving/rejecting, reassigning phases, closure decisions, CAP decisions, or Admin Settings access. These remain strictly role-gated.
- **UI behavior:** The "Read-only Access" banner is hidden when the override applies. Action checkboxes and the upload control become interactive; all other workflow controls follow the user's base role.
- **Audit trail:** Action toggles and evidence uploads performed under the override are recorded in audit history with the assignee's name, exactly as for any other role.

### 2.4 Workflow Diagram

The diagram below shows how the role + assignee override determines what a user can do on an audit, and how the audit progresses through review, QA, CAP, and closure.



![Audit Workflow Diagram](/docs/diagrams/audit-workflow.svg)

**Diagram summary:**
- Staff is read-only by default.
- If the current user is the audit assignee or the current phase assignee, the **assignee override** allows checklist completion and evidence upload on that audit only.
- Department Head, Compliance Head, and Admin retain their existing role-based workflow permissions.
- Approved audits continue through internal review, QA routing for external audits, CAP decisioning, verification, and closure.

---

## 3. Core Features

### 3.1 Dashboard

#### Unified Dashboard with Role-Based View Toggle
The dashboard displays audit items with a role-based view toggle that varies by user role:

| Role | Toggle Options | Default View |
|------|----------------|--------------|
| **Staff** | No toggle (read-only view) | Personal assignments only |
| **Department Head** | Department / Personal | Department |
| **Compliance Head** | Organization / Personal | Organization |
| **Admin** | Organization / Personal | Organization |

#### View Scope Behavior

**Organization View** (Compliance Head, Admin only):
- Shows ALL audits across the entire organization regardless of department
- Pre-Audit tab: All pre-audit items from all departments
- To Do tab: All active audits (draft, open, under_evaluation, internal_review, remediation_required, in_cap, pending_verification) from all departments
- History tab: All closed audits from all departments
- Full visibility for compliance oversight and administrative management

**Department View** (Department Head default):
- Shows only audits within the user's assigned department
- Pre-Audit tab: Pre-audit items from user's department
- To Do tab: Active audits from user's department
- History tab: Closed audits from user's department
- Enables department-level management and oversight

**Personal View** (All roles with toggle):
- Shows only audits where the user has direct involvement
- Filters to audits where user is:
  - Assigned to any phase (via phaseAssignees)
  - The primary assignee (assignedTo)
  - The creator (createdBy)
- Same filtering applied across Pre-Audit, To Do, and History tabs
- Provides focused view of user's individual workload
- Department Head retains full edit permissions (not read-only like Staff)

#### Staff View (No Toggle)
- Staff users see Personal view by default with no toggle option
- Read-only access: can view but cannot edit, upload, or submit
- Shows only audits they are assigned to or created

#### Dashboard Sections
- **Key Metrics section**: Displays KPIs (Overdue Rate, Cycle Time, On-Time Completion, Review Turnaround, CAP Required Rate) with target vs actual comparison
- **Status Tiles section**: Quick counts for Open Audits, Overdue, Pending Review, QA Review, CAP Required
- **Pre-Audit tab**: Items in pre-audit preparation and review
- **To Do tab**: Items requiring action
- **History tab**: Past completed audits

#### Audit History Tab
- Tracks past audits touched by users and departments
- Provides audit transparency and traceability
- Displays historical completed audits for periodic items

### 3.2 All Audits Page
- Displays all audits with consistent experience across all stages
- **Phase summary cards**: Quick counts by phase with click-to-filter
- **Advanced filters**: Phase, Status, Type, Search
- **Active filter badges**: Visual indication of applied filters
- **Consistent navigation**: Routes to appropriate view based on phase

### 3.3 Audit Types
| Type | Description | Closure Routing |
|------|-------------|-----------------|
| **Internal** | Audits conducted within the organization | Routes back to originating department |
| **External** | Audits from external regulatory bodies | Routes to Compliance Head for closure |

### 3.4 Audit Status Flow
```
pre_audit → pre_audit_review → draft → open → under_evaluation → internal_review → qa_review → complete
                                                        ↓
                                                  review_failed (returns to assignee)
                                                        ↓
                                              remediation_required
                                                        ↓
                                                     in_cap
                                                        ↓
                                              pending_verification
```

**Status Definitions:**
| Status | Description |
|--------|-------------|
| `pre_audit` | Pre-audit preparation stage |
| `pre_audit_review` | Pre-audit submitted for review |
| `draft` | Initial state, audit created but not started |
| `open` | Audit is open and in progress |
| `under_evaluation` | Actively being evaluated |
| `internal_review` | Submitted for internal review |
| `review_failed` | Returned by reviewer with feedback |
| `remediation_required` | Remediation actions needed |
| `in_cap` | Corrective Action Plan in progress |
| `pending_verification` | Awaiting verification |
| `closed` | Audit finalized |

---

## 4. Audit Lifecycle Phases

AuditPro implements a **phase-based workflow** with eight distinct stages.

### 4.1 Phase Overview

| Phase | Label | Description | Key Activities |
|-------|-------|-------------|----------------|
| `pre_audit` | Pre-Audit Preparation | Initial preparation | Gather materials before formal audit |
| `overview` | Audit Overview | Initial audit details | Review scope, objectives, requirements |
| `evidence_collection` | Evidence Collection | Gathering documentation | Upload evidence, collect documents |
| `evaluation` | Evaluation | Reviewing findings | Evaluate evidence, complete actions |
| `internal_review` | Internal Review | Submit for approval | Reviewer approval/rejection |
| `closure_cap` | Closure & CAP | Final determination | Finalize audit, CAP decision |
| `cap_active` | CAP Active | CAP in progress | CAP created in CAPA microapp |
| `pending_verification` | Pending Verification | Awaiting verification | Auditor verification |
| `closed` | Closed | Final state | Audit complete |

### 4.2 Phase Navigation
- Visual **phase stepper** with checkmarks and current highlight
- Phase gating rules are admin-configurable
- Each phase can have a different assignee
- Phase assignee changes logged in history
- Phase-specific attachments tracked separately

### 4.3 Pre-Audit Workflow
1. Creator prepares item with action checklist
2. Submits for pre-audit review
3. Reviewer can approve (moving to main audit lifecycle) or reject with QC feedback
4. Pre-audit items tracked separately on dashboard

---

## 5. Audit Creation

### 5.1 New Audit Form
Required fields:
- **Title**: Descriptive audit name
- **Description**: Detailed scope and objectives
- **Audit Type**: Internal or External
- **Department**: Assigned department
- **Priority**: Low, Medium, High, or Critical
- **Due Date**: Target completion date

### 5.2 Periodicity Options
| Pattern | Description |
|---------|-------------|
| **One-time** | Single occurrence audit |
| **Periodic** | Recurring audit with schedule |

**Periodic Options:** Daily, Weekly, Monthly, Quarterly, Annually

System calculates `nextScheduledDate` for periodic audits.

### 5.3 Action Steps
- Configurable action items per audit (template-driven)
- Checkbox-based completion tracking
- Completion timestamp and user recorded

### 5.4 Cross-Microapp Linking
Link audits to items from other MedComply microapps:
- **RiskGuard**: Risk assessments
- **ComplianceConnect**: CAP/Control items
- **FeedbackHub**: Feedback/Complaints
- **EnforcePoint**: Enforcement actions

---

## 6. Evidence & Attachments

### 6.1 Attachment Capability
Attachments can be uploaded at **every phase** of the audit lifecycle:
- Pre-Audit Preparation
- Audit Overview
- Evidence Collection
- Evaluation
- Internal Review
- Closure & CAP

### 6.2 Attachment Tracking
- Attachments are **phase-specific**
- Categorized by the stage they were added
- Evidence history maintained throughout lifecycle

### 6.3 Evidence Policy (Admin Configurable)
- Allowed file types
- Maximum files per phase
- Maximum file size
- Required evidence toggles per phase

---

## 7. Review Workflow

### 7.1 Internal Review Process
```
Assignee completes audit actions
          ↓
Submits for internal review
          ↓
Internal Reviewer evaluates
          ↓
    ┌─────┴─────┐
    ↓           ↓
 Approve     Reject
    ↓           ↓
Routes to   Returns to
next phase  assignee with
            feedback
```

### 7.2 Review Decision Options

#### Ready for Audit (Approve)
- **Department**: Required field
- **User**: Optional field
- Advances audit to next stage
- Internal: Routes to originating department
- External: Routes to Compliance Head

#### Review Failed (Reject)
- **Department**: Required field
- **User**: Optional field
- **Notes**: Required - must explain rejection reason
- Returns audit to assignee with feedback

---

## 8. Closure & CAP

### 8.1 Closure Types
| Closure Type | Description |
|--------------|-------------|
| `with_cap` | Closed with Corrective Action Plan |
| `without_cap` | Closed without CAP (with reason) |
| `risk_accepted` | Risk accepted closure |
| `duplicate_merged` | Duplicate or merged finding |
| `invalidated` | Finding invalidated |

### 8.2 CAP Integration
When CAP is required:
- System creates a ComplianceConnect item
- Routes to responsible department for corrective actions
- Tracks CAP completion status via CAPA microapp

When no CAP required:
- Select closure reason from managed list
- Provide justification/evidence based on reason requirements
- Audit marked as "Complete"

### 8.3 Closure Reasons (Admin Managed)
Each closure reason has metadata:
- Category (invalidated, not applicable, already corrected, etc.)
- Requires justification flag
- Requires evidence flag
- Requires approval flag

### 8.4 Phase-Aware Closure Interface (`/closure/:id`)

The closure page renders a **different decision panel based on the audit's `currentPhase`** so the user is never shown an action that doesn't apply to the audit's lifecycle position. There is no manual previous/next navigation — each panel exposes only the legal next workflow action.

| Phase | Header Label | Decision Panel | Available Actions |
|-------|-------------|----------------|-------------------|
| `closure_cap` | QA Review & Closure | Closure Decision | **Mark as Complete** → `closed`, or **CAP Required** → `cap_active` (CAP details required) |
| `cap_active` | CAP In Progress | Read-only CAP status banner | **Mark CAP Complete → Pending Verification** (single action; CAP execution itself happens in ComplianceConnect/CAPA) |
| `pending_verification` | QA Verification | QA Verification Decision | **Verify & Close** → `closed` with `closureType = with_cap`, or **Reopen CAP** → `cap_active` (reason required) |
| `closed` | Audit Closed | Locked confirmation card | None — read-only for all roles |

**Behavioural rules:**
- The Closure page always shows **Audit Summary** and **Evidence Documentation** for context, regardless of phase.
- The action buttons in each panel are the *only* path to advance or reverse the closure phases — phase changes are never set via dropdowns or manual phase pickers.
- **Reopen CAP** requires a written reason and returns the audit to `cap_active`; it does NOT create a new CAP — the existing linked ComplianceConnect item is reused.
- **Verify & Close** automatically stamps `closureType = with_cap` since reaching `pending_verification` implies a CAP path was taken.
- For `closed` audits, no action buttons render — the page is fully read-only and the Audit Pack export remains the only available downstream action.

---

## 9. Audit Pack

The **Audit Pack** module generates HIPAA-aligned, SHA-256 stamped export bundles (PDF + ZIP) for internal readiness checks and external regulator submissions. It is on-demand and not gated to a specific audit phase.

### 9.1 Workflow Diagram

The diagram below shows how a user moves from the Audit Pack landing screen through the three-step wizard (Scope → Preview → Generate) and produces a defensible export.



![Audit Pack Workflow Diagram](/docs/diagrams/audit-pack-workflow.svg)

**Diagram summary:**
- **Staff** cannot generate Audit Packs. **Dept Head**, **Compliance Head**, and **Admin** can.
- Users land on the Readiness Hero (score, breakdown, top gaps) and choose between viewing **Export History** or starting the **Wizard**.
- The wizard collects **Scope** (date range, departments, locations, controls, policies, options) and supports saving reusable **Scope Templates**.
- The **Preview** step computes the Readiness Score in four bands: Policy Coverage (30%), Training Completion (25%), Evidence Coverage (30%), Penalty Buffer (15%).
- If gaps are unacceptable, the user returns to fix them (upload evidence, complete training, refresh stale items) before generating.
- Including **PHI** is an **Admin-only** gate.
- The **Generate** step produces a Crosswalk PDF, Evidence Index, Manifest with SHA-256 hashes, and a ZIP bundle of policies, evidence, training, and CAPA logs.
- Completed exports are **immutable** and can optionally be exposed to external auditors via a time-limited **read-only Share Link**.

### 9.2 Readiness Score
| Band | Weight | Source |
|------|--------|--------|
| Policy Coverage | 30 | Approved policies linked to in-scope HIPAA controls |
| Training Completion | 25 | Completed assignments vs. required, in-window |
| Evidence Coverage | 30 | Controls with current (non-stale) evidence |
| Penalty Buffer | 15 | Deductions for stale evidence and overdue CAPAs |

### 9.3 Outputs
- **README PDF** — single-file executive summary.
- **Crosswalk PDF** — HIPAA Rule × Control × Policy × Evidence matrix.
- **ZIP Bundle** — evidence files, policies, training records, CAPA logs.
- **Manifest** — JSON with SHA-256 hashes for each artifact and the bundle.
- **Share Link** — time-limited, revocable, read-only auditor view.

---

## 10. Admin Settings

### 10.1 Admin Settings Tabs (Admin Only)

| Tab | Purpose |
|-----|---------|
| **General** | Organization name, timezone, locale, system-wide settings |
| **Departments** | Manage departments, designate compliance owner |
| **Audit Types & Routing** | Configure routing rules for internal/external audits |
| **Status & Phase Rules** | Define status transitions and phase gating |
| **Phase Assignee Rules** | Auto-assignment rules by department/phase |
| **Action Templates** | Reusable action checklists by audit type |
| **Evidence & Attachments** | File policies, required evidence settings |
| **Periodic Audit Rules** | Scheduling options, missed schedule handling |
| **Notifications** | Trigger configuration, delivery channels |
| **Integrations** | ComplianceConnect CAP integration, external systems |
| **Audit Settings Change Log** | Immutable audit trail of all settings changes |

### 10.2 Departments Configuration
- Add/edit/delete departments
- Set department code
- Designate Compliance/QA closure owner
- Configure active/inactive status

### 10.3 Routing Rules
- Source type (internal/external)
- Source phase triggers
- Destination department
- Destination phase
- Auto-assignee settings
- Priority/condition-based routing

### 10.4 Action Templates
- Template name and description
- Audit type association
- Department association
- Phase assignment
- Reusable action items

### 10.5 Change Log
- Immutable audit trail
- Before/after snapshots
- Filterable by date, category, user
- Searchable

---

## 11. Data Models

### 11.1 AuditItem
```typescript
interface AuditItem {
  id: string;
  title: string;
  description: string;
  type: 'internal' | 'external';
  status: AuditStatus;
  closureType?: ClosureType;
  closureReason?: string;
  department: string;
  assignedTo: string;
  assignedToName: string;
  createdBy: string;
  createdAt: string;
  dueDate: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  phase: AuditPhase;
  currentPhase: AuditPhase;
  evidence: Evidence[];
  actions: AuditAction[];
  reviewNotes?: string;
  capRequired?: boolean;
  isPeriodic: boolean;
  periodicity?: Periodicity;
  nextScheduledDate?: string;
  phaseAttachments: PhaseAttachments;
  phaseAssignees?: PhaseAssignees;
  history: AuditHistoryEntry[];
  linkedItems?: LinkedItem[];
}
```

### 11.2 User Roles
```typescript
type UserRole = 'staff' | 'department_head' | 'compliance_head' | 'admin';
```

### 11.3 Audit Phases
```typescript
type AuditPhase = 
  | 'pre_audit'
  | 'overview'
  | 'evidence_collection'
  | 'evaluation'
  | 'internal_review'
  | 'closure_cap'
  | 'cap_active'
  | 'pending_verification'
  | 'closed';
```

### 11.4 Departments (Seed Data)
- Nursing
- Quality Assurance/Compliance
- Administration
- Laboratory
- Pharmacy
- Radiology

---

## 12. Cross-Microapp Integration

### 12.1 Linked Items Panel
In Audit Detail, users can link to:
- **RiskGuard**: Related risks
- **ComplianceConnect**: Related CAP/Control items
- **FeedbackHub**: Related feedback/complaints
- **EnforcePoint**: Related enforcement actions

### 12.2 Relationship Types
- Related Risk
- Related CAP/Control
- Related Enforcement Action
- Related Feedback/Complaint
- Evidence Reference
- Duplicate/Similar
- Other

### 12.3 Link Tracking
- Link/unlink actions logged in history
- RBAC "Restricted" state for access control
- Universal join table `cross_app_reference`

---

## 13. Notifications

### 13.1 Notification Triggers
- New audit assigned
- Phase handoff
- Submitted for internal review
- Review rejected (include notes)
- External audit routed to Compliance Head
- CAP created
- Audit completed
- Due date approaching
- Overdue notification

### 13.2 Delivery Channels
- In-app notifications
- Email notifications
- Configurable per trigger

---

## 14. Technical Architecture

### 14.1 Technology Stack
- **Frontend**: React 18, TypeScript
- **Styling**: Tailwind CSS, shadcn/ui components
- **State Management**: React Context (AuditContext, AdminContext)
- **Routing**: React Router DOM
- **Build Tool**: Vite

### 14.2 Key Components
| Component | Purpose |
|-----------|---------|
| `AuditContext` | Central state management for audits |
| `AdminContext` | Admin settings state management |
| `AppLayout` | Main application layout with sidebar |
| `Dashboard` | Main dashboard with To Do/To Review tabs |
| `AllAudits` | All audits view with filters |
| `AuditPhase` | Phase-based audit detail view |
| `ScheduledReview` | Internal review interface |
| `ClosureCAP` | Closure and CAP management |
| `NewAudit` | Audit creation form |
| `AdminSettings` | Admin configuration page |
| `AuditCard` | Audit item display component |

---

## 15. Accessibility & Performance

### 15.1 WCAG 2.1 AA Compliance
- Semantic HTML with proper heading hierarchy
- Keyboard-only navigation with logical focus order
- Visible focus indicators on all interactive elements
- Focus trapping in modals with ESC to close
- Form labels with aria-describedby for errors/help
- Color contrast minimums (4.5:1 normal, 3:1 large)
- Touch targets minimum 44x44px
- Respect for prefers-reduced-motion
- Meaningful ARIA labels
- Screen reader support through live regions

### 15.2 Performance Targets
- Smooth lists up to 100 items
- Key screens load quickly (<2 seconds target)
- Responsive with collapsible sidebar

---

## 16. Business Requirements FAQ

This section addresses common business and product questions. It complements the rest of the PRD with explicit answers that product, compliance, and business stakeholders frequently ask.

### 16.1 Are audit phases fixed?
Yes — the five UI phases are fixed and standardized: **Pre-Audit Preparation → Evidence Collection → Evaluation → Internal Review → Closure & CAP**. The phase set is not user-configurable. However, **phase-level rules** (assignees, SLAs, required evidence, skip conditions for Pre-Audit) can be configured in **Admin Settings → Phase & Assignee Configuration**.

### 16.2 What is the difference between a checklist and an action item?
- **Checklist** = a reusable **template** of steps. Defined once in **Admin Settings → Action Templates** and associated with an audit type, department, and phase.
- **Action Item** = an **instance** of a checklist step on a live audit. Each action item has an owner, due date, status (pending/complete), and a completion timestamp once checked off. Action items are tracked, reportable, and contribute to the audit's progress and Audit Pack readiness.

In short: **Checklists are the design; action items are the execution.**

### 16.3 Who can create a new audit?
- **Department Head** can create audits scoped to their department.
- **Compliance Head** can create audits org-wide (any department).
- **Admin** can create audits anywhere and also create the templates that drive them.
- **Staff** **cannot** create audits — they are read-only by default.

Periodic audits are created automatically by the scheduler based on the periodicity rules (see §5).

### 16.4 Is one person responsible for the whole audit lifecycle?
There are two distinct ownership concepts:
- **Audit Owner (`assignedTo`)** — a single user who owns the audit end-to-end. They are the accountable point of contact for the entire lifecycle.
- **Phase Assignee (`phaseAssignees[phase]`)** — the user responsible for executing a specific phase. Each phase can have a different assignee.

This separation supports **segregation of duties** — for example, the Audit Owner may be a Department Head, while individual phases are delegated to staff members for evidence collection or to the Compliance Head for QA/closure.

### 16.5 Can a single phase be reassigned across multiple users (A → B → C)?
Yes. Phase assignees are **explicitly reassignable** at any time:
- Via **Admin Settings → Phase & Assignee Configuration** for org-wide rules.
- Via the **phase sidebar** on the Audit Phase page for per-audit overrides (Department Head, Compliance Head, or Admin).

Each reassignment is recorded in the **Audit History** trail with who reassigned, when, and to whom — preserving full accountability.

### 16.6 How does the end-to-end workflow work?
The standard lifecycle is:
1. **Audit is created** (manually by Dept Head/Compliance Head/Admin, or automatically by the scheduler).
2. **Pre-Audit Preparation** — checklists prepared, materials gathered (skippable per audit type configuration).
3. **Evidence Collection** — phase assignee uploads evidence and attachments; assignee override rule may apply.
4. **Evaluation** — the evidence is assessed against controls.
5. **Submit for Internal Review** — work is handed to an internal reviewer (Department Head for internal audits).
6. **Internal Review** — reviewer can **Approve** (forward to closure) or **Reject** (return to assignee with feedback).
7. **Closure & CAP** — for **internal audits**, the Department Head/Admin closes; for **external audits**, the **Compliance Head** performs the QA review and final determination.
8. **CAP decision** — Compliance Head decides **CAP required** (creates a CAP in ComplianceConnect/CAPA microapp) or **Close without CAP** (selects a configured Closure Reason).
9. **Closed** — audit is locked; only Audit Pack exports remain available.
10. **Audit Pack** — generate at any phase for readiness checks; generate after closure for the official, immutable, SHA-256-stamped export for regulators.

A visual representation is provided in §2.4 (Workflow Diagram).

### 16.7 What is the internal review experience?
- **Who reviews:** Department Head (for department audits) or Compliance Head (for external audits).
- **What they see:** all phase content, all evidence, action item status, history, and any reviewer notes.
- **Decision options:** **Approve** (advance to next phase) or **Reject** (return to the previous phase assignee with required feedback comment).
- **Audit trail:** every approve/reject is timestamped and recorded with the reviewer's identity and comment.
- **SLA:** internal review must be completed within the SLA defined in **Admin Settings → Phase & Assignee Configuration**; overdue reviews are surfaced on dashboards.

### 16.8 At what phase can an Audit Pack be generated?
Audit Packs can be generated at **any phase** — the Audit Pack module is on-demand, not gated to a specific phase. Recommended use per phase:

| Phase | Recommended Use |
|-------|-----------------|
| **Pre-Audit / Overview** | Generate a draft pack to see the **Readiness Score** and identify evidence gaps before the audit formally begins |
| **Evidence Collection / Evaluation** | Generate an *interim* pack to share progress with stakeholders or validate that collected evidence maps to HIPAA controls |
| **Internal Review** | Bundle the current evidence set for the reviewer's offline review |
| **Closure & CAP** | Generate the *final* defensible pack for the closure authority's records |
| **Closed** | Generate the *official, point-in-time* export for external auditors, regulators, or board reviews — most common trigger |
| **Anytime (ad-hoc)** | In response to a regulator request, subpoena, or internal QA committee — independent of any open audit |

**Important:** Closed audits are preferred for official external-facing packs because their evidence is immutable and the SHA-256 hash represents a stable, defensible snapshot.

### 16.9 Who can generate an Audit Pack?
- **Compliance Head** and **Admin** — org-wide scope.
- **Department Head** — scoped to their department.
- **Staff** — cannot generate Audit Packs.

### 16.10 What evidence rules apply?
- Evidence can be uploaded at **every phase** (Overview, Evidence Collection, Evaluation, Internal Review, Closure & CAP).
- Each evidence item has metadata: control mapping, uploader, timestamp, file hash.
- Evidence is **immutable once an audit is closed** — required for defensibility and the SHA-256 integrity hash on the Audit Pack export.
- Configurable **evidence policies** (required types, retention) live in **Admin Settings → Evidence Policy**.

### 16.11 What visibility do different roles have?
| Role | Visibility |
|------|------------|
| **Staff** | Audits assigned to them OR within their department scope (read-only) |
| **Department Head** | All audits in their department (full edit on those) |
| **Compliance Head** | Org-wide audits; QA authority on external audits |
| **Admin** | Everything, plus Admin Settings |

### 16.12 What are the SLAs for each phase?
SLAs are configured per audit type and per phase in **Admin Settings → Phase & Assignee Configuration**. Default targets:
- Pre-Audit Preparation: 3 business days
- Evidence Collection: 10 business days
- Evaluation: 5 business days
- Internal Review: 3 business days
- Closure & CAP: 5 business days (CAP follow-up tracked in ComplianceConnect/CAPA)

Overdue items are highlighted on dashboards and trigger configurable notifications.

### 16.13 How does AuditPro support HIPAA compliance?
- All evidence is mapped to HIPAA Administrative, Physical, and Technical safeguards.
- Audit Pack exports include a HIPAA control coverage matrix and SHA-256 integrity hash.
- Closure Reasons and CAP decisions are recorded in a permanent audit trail.
- All actions (create, edit, reassign, close, export) are logged with actor, timestamp, and context for HIPAA §164.312(b) audit controls.
- Roles enforce least-privilege access; Staff cannot mutate any data.

---

## 17. Developer FAQ

### 17.1 What is the architecture?
React 18 + Vite + TypeScript with **Context API** for domain-scoped state (`AuditContext`, `CAPContext`, `AdminContext`, `AuditPackContext`, `ClosureReasonsContext`). Routing via `react-router-dom`. UI components from **shadcn/ui** + Tailwind CSS v3. No external state management library — Context is sufficient at current scale.

### 17.2 How is the design system enforced?
All colors are **HSL semantic tokens** defined in `src/index.css` and mapped in `tailwind.config.ts`. Components must use semantic classes (`bg-primary`, `text-foreground`, `bg-status-success`) — never raw color classes (`bg-blue-500`, `text-green-600`). This enables consistent theming and dark mode without per-component changes.

### 17.3 How is RBAC implemented?
The `usePermissions()` hook in `src/hooks/usePermissions.ts` returns boolean capability flags derived from the current user's role and the audit/phase context. UI elements are gated declaratively (`{permissions.canCloseAudit && <Button .../>}`). The four roles (Staff, Department Head, Compliance Head, Admin) and the assignee-override rule are encoded inside the hook so that gating logic is centralized.

### 17.4 How does the audit lifecycle map to code?
Five UI phases are defined in `src/types/audit.ts`. Each phase has a route under `/audits/:id/:phase` rendered by `src/pages/AuditPhase.tsx`. Phase transitions are explicit — they happen only when a workflow action button is clicked (no manual prev/next). The backend status lifecycle (`draft → in_progress → pending_review → ready_for_audit → qa_review → closed`) is internal and **never displayed in the UI** — only phases are shown.

### 17.5 How does the Audit Pack module work?
- `src/lib/auditPackGenerator.ts` computes the Readiness Score from policy coverage, training, evidence freshness, and penalties.
- The wizard at `src/pages/AuditPackWizard.tsx` walks the user through scope → evidence selection → review → export.
- Outputs are PDF (single-file summary) or ZIP (full bundle with evidence files, manifest, and SHA-256 hashes).
- PHI is never embedded outside scoped evidence; manifest entries reference file hashes for tamper detection.

### 17.6 Where do I add a new admin setting?
1. Add the type in `src/types/admin.ts`.
2. Extend `AdminContext` with state and update functions.
3. Create a new tab component in `src/components/admin/` and register it in `src/pages/AdminSettings.tsx`.
4. If the setting affects RBAC or workflow, update `usePermissions` accordingly.

### 17.7 Where do I add a new cross-microapp link target?
Cross-microapp linking is handled in `src/components/audit/LinkedItemsSection.tsx`. Add the new microapp to the link-target enum in `src/types/audit.ts` and provide an icon + label mapping in the component.

### 17.8 How are forms validated?
Forms use `react-hook-form` + `zod` resolvers. Schemas live alongside the form component. Submit handlers call the relevant Context method which performs optimistic update + persistence.

### 17.9 What testing strategy is used?
The project uses Vitest (`bun run test`) for unit and component tests. UAT scenarios are documented in `public/docs/UAT-Test-Scenarios.md` and QA scenarios in `public/docs/QA-Test-Scenarios.md`. End-to-end smoke tests are tracked in the Documentation tab.

### 17.10 What conventions should I follow?
- Small, focused components — split when a file grows past ~200 lines.
- Read files before editing; never modify a file you haven't read in the current session.
- Use semantic tokens, never raw Tailwind colors.
- Prefer search-replace edits over full file rewrites.
- Every workflow action that mutates audit state must append to the Audit History.

### 17.11 What about deployment?
The app is deployed on Lovable (Vite static build). Lovable Cloud (Supabase under the hood) provides the database, auth, and storage for evidence files. Migrations live in `supabase/migrations/` (when Cloud is enabled). Edge functions handle server-side concerns like Audit Pack ZIP generation and signed share links.

---

## 18. Changelog

| Date | Version | Changes |
|------|---------|---------|
| 2026-04-29 | 2.6 | Added §8.4 Phase-Aware Closure Interface documenting the four closure-page variants (`closure_cap`, `cap_active`, `pending_verification`, `closed`) and the action buttons available in each. |
| 2026-04-16 | 2.5 | Added §9 Audit Pack with workflow diagram (`/docs/diagrams/audit-pack-workflow.svg`); renumbered subsequent sections (Admin Settings → §10, …, Changelog → §18). |
| 2026-04-16 | 2.4 | Restored Business Requirements FAQ (§15) and Developer FAQ (§16); renumbered Changelog to §17. |
| 2026-04-16 | 2.1 | Added assignee override rule (Staff and other roles assigned to a phase can complete actions and upload evidence on that audit). Added end-to-end audit workflow diagram in section 2.4. |
| 2025-12-15 | 2.0 | Updated role system (Staff, Department Head, Compliance Head, Admin), added full Admin Settings with 11 tabs, enhanced All Audits page with phase filters, added cross-microapp linking |
| 2025-12-13 | 1.1 | Added Internal Review phase, integrated CAP Management and Closure workflows into closure_cap phase |
| 2025-12-11 | 1.0 | Initial PRD creation |

---

*This document should be updated whenever significant changes are made to the AuditPro application flow, features, or data models.*
