# AuditPro - QA Test Scenarios

**Version:** 1.0  
**Last Updated:** 2025-12-25  
**Status:** Active

---

## 1. Document Overview

### 1.1 Purpose
This document provides comprehensive Quality Assurance test scenarios for the AuditPro application. It covers functional, integration, regression, and edge case testing across all features.

### 1.2 Scope
- All user roles (Staff, Department Head, Compliance Head, Admin)
- All audit lifecycle phases
- Admin settings functionality
- Cross-microapp integration
- Dashboard and reporting features

### 1.3 Test Environment
- **Browser Support:** Chrome (latest), Firefox (latest), Safari (latest), Edge (latest)
- **Resolution Testing:** 1920x1080, 1366x768, 768x1024 (tablet), 375x812 (mobile)
- **Test Data:** Use seeded mock data for consistent testing

---

## 2. Authentication & Authorization Tests

### 2.1 Role-Based Access Control

#### TC-AUTH-001: Staff User Access
**Priority:** Critical  
**Precondition:** User logged in as Staff role

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Navigate to Dashboard | Dashboard loads with Personal view only (no toggle) |
| 2 | Verify sidebar navigation | "New Audit" link NOT visible |
| 3 | Verify sidebar navigation | "Admin Settings" link NOT visible |
| 4 | Open any audit | All edit controls disabled |
| 5 | Attempt to upload evidence | Upload button disabled or hidden |
| 6 | Attempt to complete action item | Checkbox disabled |

#### TC-AUTH-002: Department Head Access
**Priority:** Critical  
**Precondition:** User logged in as Department Head role

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Navigate to Dashboard | Dashboard shows Department/Personal toggle |
| 2 | Verify default view | Department view selected by default |
| 3 | Verify sidebar | "New Audit" visible, "Admin Settings" hidden |
| 4 | Open department audit | Edit controls enabled |
| 5 | Upload evidence | Upload successful |
| 6 | Submit for review | Review submission successful |

#### TC-AUTH-003: Compliance Head Access
**Priority:** Critical  
**Precondition:** User logged in as Compliance Head role

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Navigate to Dashboard | Dashboard shows Organization/Personal toggle |
| 2 | Verify default view | Organization view selected by default |
| 3 | View all departments | Audits from all departments visible |
| 4 | Access external audit closure | Closure controls enabled |
| 5 | Make CAP decision | CAP decision saved successfully |

#### TC-AUTH-004: Admin Access
**Priority:** Critical  
**Precondition:** User logged in as Admin role

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Navigate to Dashboard | Full access with Organization/Personal toggle |
| 2 | Access Admin Settings | Admin Settings page loads successfully |
| 3 | Modify any setting | Changes saved with change log entry |
| 4 | Access all 11 tabs | All tabs accessible and functional |

---

## 3. Dashboard Tests

### 3.1 View Toggle Functionality

#### TC-DASH-001: Organization View Filter
**Priority:** High  
**Precondition:** Logged in as Compliance Head or Admin

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Select "Organization" toggle | Toggle visually selected |
| 2 | Check Pre-Audit tab | Shows all pre-audit items from ALL departments |
| 3 | Check To Do tab | Shows all active audits from ALL departments |
| 4 | Check History tab | Shows all closed audits from ALL departments |
| 5 | Verify counts | Status tiles reflect organization-wide counts |

#### TC-DASH-002: Department View Filter
**Priority:** High  
**Precondition:** Logged in as Department Head

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Verify "Department" toggle default | Department toggle selected |
| 2 | Check Pre-Audit tab | Shows only audits from user's department |
| 3 | Check To Do tab | Shows only active audits from user's department |
| 4 | Check History tab | Shows only closed audits from user's department |
| 5 | Create audit in different department | Audit NOT visible in Department view |

#### TC-DASH-003: Personal View Filter
**Priority:** High  
**Precondition:** Logged in as Department Head

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Select "Personal" toggle | Toggle visually selected |
| 2 | Check all tabs | Only shows audits where user is assigned/creator |
| 3 | Verify edit permissions | Department Head retains edit permissions |
| 4 | Audit assigned to different user | Audit NOT visible in Personal view |

### 3.2 Metrics Display

#### TC-DASH-004: Key Metrics Accuracy
**Priority:** Medium  
**Precondition:** Dashboard with multiple audits

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Check Overdue Rate | Correctly calculated (overdue/total × 100) |
| 2 | Check On-Time Completion | Matches actual completion data |
| 3 | Check metrics targets | Target vs actual comparison displayed |
| 4 | Switch view toggle | Metrics update to reflect filtered data |

#### TC-DASH-005: Status Tiles
**Priority:** Medium  
**Precondition:** Dashboard with audits in various statuses

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Verify Open Audits count | Matches actual open audit count |
| 2 | Verify Overdue count | Matches audits past due date |
| 3 | Verify Pending Review count | Matches audits in review status |
| 4 | Click status tile | Filters audit list to that status |

---

## 4. Audit Creation Tests

### 4.1 New Audit Form

#### TC-CREATE-001: Required Fields Validation
**Priority:** Critical  
**Precondition:** Navigate to New Audit page

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Submit empty form | Validation errors for all required fields |
| 2 | Fill Title only | Other required field errors persist |
| 3 | Fill all required fields | Form submits successfully |
| 4 | Verify required fields | Title, Description, Type, Department, Priority, Due Date |

#### TC-CREATE-002: Audit Type Selection
**Priority:** High  
**Precondition:** On New Audit form

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Select "Internal" type | Type saved correctly |
| 2 | Select "External" type | Type saved correctly |
| 3 | Submit audit | Type reflected in audit details |
| 4 | Check routing | External routes to Compliance Head for closure |

#### TC-CREATE-003: Periodicity Configuration
**Priority:** High  
**Precondition:** On New Audit form

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Toggle "Is Periodic" on | Periodicity options appear |
| 2 | Select "Monthly" | Schedule configured correctly |
| 3 | Submit audit | `isPeriodic: true`, `periodicity: 'monthly'` saved |
| 4 | Verify scheduled date | `nextScheduledDate` calculated correctly |

#### TC-CREATE-004: Action Template Selection
**Priority:** Medium  
**Precondition:** Action templates configured in Admin Settings

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Select audit type | Matching templates available |
| 2 | Select department | Templates filtered by department |
| 3 | Apply template | Action items pre-populated |
| 4 | Modify action items | Custom items can be added/removed |

---

## 5. Audit Lifecycle Tests

### 5.1 Phase Navigation

#### TC-PHASE-001: Phase Stepper Display
**Priority:** High  
**Precondition:** Open audit in active phase

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | View phase stepper | All 8 phases displayed in order |
| 2 | Verify current phase | Current phase highlighted |
| 3 | Verify completed phases | Completed phases show checkmarks |
| 4 | Click completed phase | Navigation to that phase |
| 5 | Click future phase | Navigation blocked (if gating enabled) |

#### TC-PHASE-002: Pre-Audit Workflow
**Priority:** High  
**Precondition:** Create new audit starting in pre_audit

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Complete pre-audit preparation | All actions completed |
| 2 | Submit for pre-audit review | Status changes to `pre_audit_review` |
| 3 | Reviewer approves | Audit advances to `draft` |
| 4 | Reviewer rejects | Audit returns with QC feedback |

#### TC-PHASE-003: Evidence Collection Phase
**Priority:** High  
**Precondition:** Audit in evidence_collection phase

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Upload evidence file | File uploaded successfully |
| 2 | Verify evidence metadata | Name, type, uploader, timestamp recorded |
| 3 | Upload multiple files | All files saved to phase |
| 4 | Delete evidence | Evidence removed (if permitted) |
| 5 | Move to next phase | Phase-specific evidence retained |

#### TC-PHASE-004: Internal Review Workflow
**Priority:** Critical  
**Precondition:** Audit submitted for internal review

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Reviewer opens audit | Review interface displayed |
| 2 | Select "Ready for Audit" | Department/User fields appear |
| 3 | Approve without notes | Audit advances to next phase |
| 4 | Select "Review Failed" | Notes field required |
| 5 | Reject with notes | Audit returns to assignee with feedback |
| 6 | Verify history | Review decision logged |

### 5.2 Closure Workflow

#### TC-CLOSE-001: Close With CAP
**Priority:** Critical  
**Precondition:** Audit in closure_cap phase (Compliance Head)

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Select "CAP Required" | CAP form displayed |
| 2 | Fill CAP details | All required fields validated |
| 3 | Submit CAP | CAP item created in ComplianceConnect |
| 4 | Audit status changes | Status = `in_cap` |
| 5 | Verify audit history | CAP creation logged |

#### TC-CLOSE-002: Close Without CAP
**Priority:** Critical  
**Precondition:** Audit in closure_cap phase

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Select "No CAP Required" | Closure reason dropdown appears |
| 2 | Select closure reason | Reason recorded |
| 3 | Add justification (if required) | Justification saved |
| 4 | Submit closure | Audit status = `closed` |
| 5 | Closure type saved | `closureType: 'without_cap'` |

---

## 6. All Audits Page Tests

### 6.1 Filtering and Search

#### TC-ALL-001: Phase Filter
**Priority:** High  
**Precondition:** All Audits page with multiple audits

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Click phase summary card | Audits filtered to that phase |
| 2 | Verify filter badge | Active filter badge displayed |
| 3 | Click same card again | Filter cleared |
| 4 | Select multiple phases | Combined filter applied |

#### TC-ALL-002: Advanced Filters
**Priority:** Medium  
**Precondition:** All Audits page

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Filter by Status | Only matching statuses shown |
| 2 | Filter by Type | Internal/External filtered correctly |
| 3 | Search by title | Matching audits returned |
| 4 | Combine filters | All filters applied together |
| 5 | Clear all filters | All audits displayed |

---

## 7. Admin Settings Tests

### 7.1 Department Management

#### TC-ADMIN-001: Add Department
**Priority:** High  
**Precondition:** Admin Settings > Departments tab

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Click "Add Department" | Form modal appears |
| 2 | Enter department name | Name field populated |
| 3 | Enter department code | Code field populated |
| 4 | Set compliance owner | Owner assigned |
| 5 | Save department | Department added to list |
| 6 | Verify change log | Entry created for addition |

#### TC-ADMIN-002: Edit Department
**Priority:** Medium  
**Precondition:** Existing department in list

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Click edit button | Edit modal appears with data |
| 2 | Modify name | Name updated |
| 3 | Save changes | Department updated |
| 4 | Verify change log | Before/after values logged |

### 7.2 Routing Rules

#### TC-ADMIN-003: Configure Routing Rule
**Priority:** High  
**Precondition:** Admin Settings > Routing tab

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Add new routing rule | Form appears |
| 2 | Set source type (External) | Source type saved |
| 3 | Set destination (Compliance Head) | Destination configured |
| 4 | Save rule | Rule active |
| 5 | Create external audit | Routes to Compliance Head |

### 7.3 Change Log

#### TC-ADMIN-004: Change Log Integrity
**Priority:** High  
**Precondition:** Multiple admin changes made

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Navigate to Change Log tab | Log entries displayed |
| 2 | Verify entry fields | Date, user, category, before/after values |
| 3 | Filter by category | Entries filtered correctly |
| 4 | Search entries | Matching entries returned |
| 5 | Attempt to modify entry | No modification possible (immutable) |

---

## 8. Evidence & Attachments Tests

#### TC-EVID-001: Phase-Specific Attachments
**Priority:** High  
**Precondition:** Audit with multiple phases completed

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Upload in Evidence Collection | File tagged to phase |
| 2 | Move to Evaluation | Previous evidence accessible |
| 3 | Upload in Evaluation | New file tagged to Evaluation |
| 4 | View all attachments | Organized by phase |

#### TC-EVID-002: File Type Validation
**Priority:** Medium  
**Precondition:** Evidence policy configured

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Upload allowed file type | Upload successful |
| 2 | Upload disallowed type | Error message displayed |
| 3 | Upload over size limit | Error message displayed |
| 4 | Upload max files exceeded | Error message displayed |

---

## 9. Cross-Microapp Integration Tests

#### TC-LINK-001: Link to External Item
**Priority:** Medium  
**Precondition:** Audit in any phase

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Open Linked Items section | Link panel displayed |
| 2 | Click "Add Link" | Link form appears |
| 3 | Select microapp (RiskGuard) | Microapp selected |
| 4 | Enter item ID | ID validated |
| 5 | Select relationship type | Type saved |
| 6 | Save link | Link added to audit |
| 7 | Verify history | Link action logged |

---

## 10. Responsive Design Tests

#### TC-RESP-001: Mobile Navigation
**Priority:** Medium  
**Precondition:** Browser at 375px width

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | View sidebar | Sidebar collapsed or hamburger menu |
| 2 | Tap menu icon | Sidebar opens as overlay |
| 3 | Navigate to page | Sidebar closes automatically |
| 4 | View dashboard | Content adapts to mobile layout |

#### TC-RESP-002: Tablet Layout
**Priority:** Medium  
**Precondition:** Browser at 768px width

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | View dashboard | Two-column layout or adapted single column |
| 2 | View audit details | Phase stepper horizontal or dropdown |
| 3 | Fill forms | Forms usable with touch |

---

## 11. Edge Cases & Error Handling

#### TC-EDGE-001: Empty States
**Priority:** Low  
**Precondition:** New user with no audits

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | View Dashboard | Empty state message displayed |
| 2 | View All Audits | "No audits found" message |
| 3 | View Scheduled Audits | Empty state with create CTA |

#### TC-EDGE-002: Concurrent Editing
**Priority:** Medium  
**Precondition:** Two users editing same audit

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | User A opens audit | Audit displayed |
| 2 | User B opens same audit | Audit displayed |
| 3 | User A saves changes | Changes saved |
| 4 | User B saves changes | Conflict handling (last-write-wins or merge) |

#### TC-EDGE-003: Invalid Route Handling
**Priority:** Low  
**Precondition:** None

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Navigate to /invalid-route | 404 Not Found page |
| 2 | Navigate to /audit/invalid-id | Error message or redirect |
| 3 | Navigate to /admin (as Staff) | Access denied or redirect |

---

## 12. Performance Tests

#### TC-PERF-001: Large Dataset Rendering
**Priority:** Medium  
**Precondition:** 100+ audits in system

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Load Dashboard | Renders within 2 seconds |
| 2 | Load All Audits | List renders within 2 seconds |
| 3 | Apply filter | Filter applies within 500ms |
| 4 | Scroll through list | Smooth scrolling, no lag |

---

## 13. Test Execution Checklist

### 13.1 Smoke Test Suite (Quick Validation)
- [ ] TC-AUTH-004 (Admin login)
- [ ] TC-DASH-001 (Dashboard loads)
- [ ] TC-CREATE-001 (Create audit)
- [ ] TC-PHASE-004 (Review workflow)
- [ ] TC-ALL-001 (All Audits filter)

### 13.2 Regression Test Suite (Full Validation)
- [ ] All TC-AUTH tests
- [ ] All TC-DASH tests
- [ ] All TC-CREATE tests
- [ ] All TC-PHASE tests
- [ ] All TC-CLOSE tests
- [ ] All TC-ALL tests
- [ ] All TC-ADMIN tests
- [ ] All TC-EVID tests
- [ ] All TC-LINK tests
- [ ] All TC-RESP tests
- [ ] All TC-EDGE tests
- [ ] All TC-PERF tests

---

## 14. Defect Severity Definitions

| Severity | Definition | Example |
|----------|------------|---------|
| **Critical** | Application unusable, no workaround | Login fails, data loss |
| **High** | Major feature broken, workaround exists | Cannot create audit via UI (API works) |
| **Medium** | Feature works with issues | Filter not resetting properly |
| **Low** | Minor issue, cosmetic | Typo in label |

---

## 15. Changelog

| Date | Version | Changes |
|------|---------|---------|
| 2025-12-25 | 1.0 | Initial QA Test Scenarios document |

---

*This document should be updated whenever new features are added or existing functionality changes.*
