# AuditPro - Technical Design Document (TDD)

**Version:** 1.0  
**Last Updated:** 2025-12-25  
**Status:** Active Development

---

## 1. Document Overview

### 1.1 Purpose
This Technical Design Document provides the comprehensive technical specification for AuditPro, a healthcare audit management microapp within the MedComply Suite. It details the system architecture, component design, data flows, and implementation guidelines.

### 1.2 Scope
This document covers:
- System architecture and technology stack
- Component hierarchy and relationships
- State management patterns
- Data models and interfaces
- API integration points
- Security considerations
- Performance requirements

### 1.3 Audience
- Frontend Developers
- Backend Developers
- QA Engineers
- DevOps Engineers
- Technical Architects

---

## 2. System Architecture

### 2.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        AuditPro Frontend                        │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │
│  │   React 18  │  │  TypeScript │  │     Tailwind CSS        │ │
│  └─────────────┘  └─────────────┘  └─────────────────────────┘ │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │
│  │ React Router│  │ React Query │  │      shadcn/ui          │ │
│  └─────────────┘  └─────────────┘  └─────────────────────────┘ │
├─────────────────────────────────────────────────────────────────┤
│                    State Management Layer                        │
│  ┌──────────────┐  ┌──────────────┐  ┌────────────────────┐    │
│  │ AuditContext │  │ AdminContext │  │ ClosureReasonsCtx  │    │
│  └──────────────┘  └──────────────┘  └────────────────────┘    │
│  ┌──────────────┐                                               │
│  │  CAPContext  │                                               │
│  └──────────────┘                                               │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Future Backend Integration                    │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │
│  │  Supabase   │  │ PostgreSQL  │  │    Edge Functions       │ │
│  └─────────────┘  └─────────────┘  └─────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Technology Stack

| Layer | Technology | Version | Purpose |
|-------|------------|---------|---------|
| **Framework** | React | 18.3.1 | UI component library |
| **Language** | TypeScript | 5.x | Type-safe development |
| **Styling** | Tailwind CSS | 3.x | Utility-first CSS |
| **UI Components** | shadcn/ui | Latest | Pre-built accessible components |
| **Routing** | React Router DOM | 6.30.1 | Client-side routing |
| **State** | React Context | Built-in | Global state management |
| **Data Fetching** | TanStack Query | 5.83.0 | Server state management |
| **Build Tool** | Vite | 5.x | Fast development builds |
| **Forms** | React Hook Form | 7.61.1 | Form state management |
| **Validation** | Zod | 3.25.76 | Schema validation |
| **Date Handling** | date-fns | 3.6.0 | Date manipulation |
| **Charts** | Recharts | 2.15.4 | Data visualization |

---

## 3. Directory Structure

```
src/
├── components/
│   ├── admin/           # Admin settings tab components
│   │   ├── ActionTemplatesTab.tsx
│   │   ├── ChangeLogTab.tsx
│   │   ├── DepartmentsTab.tsx
│   │   ├── EvidencePolicyTab.tsx
│   │   ├── GeneralTab.tsx
│   │   ├── IntegrationsTab.tsx
│   │   ├── MetricsTargetsTab.tsx
│   │   ├── NotificationsTab.tsx
│   │   ├── PeriodicRulesTab.tsx
│   │   ├── PhaseAssigneeTab.tsx
│   │   ├── RoutingTab.tsx
│   │   └── StatusPhaseTab.tsx
│   ├── audit/           # Audit display components
│   │   ├── AuditCard.tsx
│   │   ├── AuditHistorySection.tsx
│   │   ├── AuditSection.tsx
│   │   ├── LinkedItemsSection.tsx
│   │   ├── PriorityBadge.tsx
│   │   └── StatusBadge.tsx
│   ├── cap/             # CAP management components
│   │   ├── CAPManagement.tsx
│   │   └── CAPStatusBadge.tsx
│   ├── closure/         # Closure workflow components
│   │   ├── CAPClosureTab.tsx
│   │   ├── CloseWithoutCAPTab.tsx
│   │   └── ClosureTab.tsx
│   ├── dashboard/       # Dashboard components
│   │   └── DashboardMetrics.tsx
│   ├── layout/          # Layout components
│   │   ├── AppLayout.tsx
│   │   └── AppSidebar.tsx
│   └── ui/              # shadcn/ui components
├── contexts/
│   ├── AdminContext.tsx
│   ├── AuditContext.tsx
│   ├── CAPContext.tsx
│   └── ClosureReasonsContext.tsx
├── hooks/
│   ├── use-mobile.tsx
│   ├── use-toast.ts
│   └── usePermissions.ts
├── lib/
│   └── utils.ts
├── pages/
│   ├── AdminSettings.tsx
│   ├── AllAudits.tsx
│   ├── AuditItemDetails.tsx
│   ├── AuditPhase.tsx
│   ├── ClosureCAP.tsx
│   ├── Dashboard.tsx
│   ├── EditAudit.tsx
│   ├── NewAudit.tsx
│   ├── NotFound.tsx
│   ├── PRDDocumentation.tsx
│   ├── ScheduledAudits.tsx
│   └── ScheduledReview.tsx
├── types/
│   ├── admin.ts
│   ├── audit.ts
│   └── cap.ts
├── App.tsx
├── index.css
├── main.tsx
└── vite-env.d.ts
```

---

## 4. Component Architecture

### 4.1 Component Hierarchy

```
App
├── QueryClientProvider
│   └── TooltipProvider
│       └── AuditProvider
│           └── CAPProvider
│               └── ClosureReasonsProvider
│                   └── AdminProvider
│                       └── BrowserRouter
│                           └── Routes
│                               ├── Dashboard
│                               ├── NewAudit
│                               ├── EditAudit
│                               ├── AuditPhase
│                               ├── AuditItemDetails
│                               ├── ScheduledReview
│                               ├── ClosureCAP
│                               ├── AllAudits
│                               ├── ScheduledAudits
│                               ├── AdminSettings
│                               └── NotFound
```

### 4.2 Page Components

#### Dashboard
- **Path:** `/`
- **Purpose:** Main entry point displaying audit items by status
- **Key Features:**
  - Role-based view toggle (Organization/Department/Personal)
  - Tabs: Pre-Audit, To Do, History
  - Key metrics display
  - Status tiles with counts

#### NewAudit
- **Path:** `/new-audit`
- **Purpose:** Create new audit items
- **Key Features:**
  - Form validation with Zod
  - Periodicity configuration
  - Action template selection
  - Cross-microapp linking

#### AuditPhase
- **Path:** `/audit/:id/phase/:phase`
- **Purpose:** Phase-specific audit management
- **Key Features:**
  - Phase stepper navigation
  - Evidence upload per phase
  - Action checklist management
  - Phase transition controls

#### AllAudits
- **Path:** `/audits`
- **Purpose:** View all audits with filtering
- **Key Features:**
  - Phase summary cards
  - Advanced filters (phase, status, type, search)
  - Sortable columns
  - Pagination

#### AdminSettings
- **Path:** `/admin`
- **Purpose:** System configuration
- **Key Features:**
  - 11 configuration tabs
  - Role-restricted (Admin only)
  - Change log tracking

---

## 5. State Management

### 5.1 Context Providers

#### AuditContext
**Purpose:** Central state for audit items and current user

```typescript
interface AuditContextType {
  audits: AuditItem[];
  currentUser: User;
  setCurrentUser: (user: User) => void;
  addAudit: (audit: AuditItem) => void;
  updateAudit: (id: string, updates: Partial<AuditItem>) => void;
  deleteAudit: (id: string) => void;
  getAuditById: (id: string) => AuditItem | undefined;
}
```

#### AdminContext
**Purpose:** Admin settings and configuration

```typescript
interface AdminContextType {
  departments: Department[];
  routingRules: RoutingRule[];
  actionTemplates: ActionTemplate[];
  evidencePolicy: EvidencePolicy;
  periodicRules: PeriodicRules;
  notificationSettings: NotificationSettings;
  integrationSettings: IntegrationSettings;
  changeLog: ChangeLogEntry[];
  // CRUD operations for each entity
}
```

#### CAPContext
**Purpose:** Corrective Action Plan management

```typescript
interface CAPContextType {
  capItems: CAPItem[];
  addCAP: (cap: CAPItem) => void;
  updateCAP: (id: string, updates: Partial<CAPItem>) => void;
  getCAPsByAuditId: (auditId: string) => CAPItem[];
}
```

#### ClosureReasonsContext
**Purpose:** Manage audit closure reasons

```typescript
interface ClosureReasonsContextType {
  closureReasons: ClosureReason[];
  addClosureReason: (reason: ClosureReason) => void;
  updateClosureReason: (id: string, updates: Partial<ClosureReason>) => void;
  deleteClosureReason: (id: string) => void;
}
```

### 5.2 State Flow Diagram

```
User Action → Component → Context Action → State Update → Re-render
     │                         │
     ▼                         ▼
  Toast/Notification     History Log Entry
```

---

## 6. Data Models

### 6.1 Core Interfaces

#### AuditItem
```typescript
interface AuditItem {
  id: string;
  title: string;
  description: string;
  type: 'internal' | 'external';
  status: AuditStatus;
  closureType?: ClosureType;
  closureReason?: string;
  department: string;
  assignedTo: string;
  assignedToName: string;
  createdBy: string;
  createdAt: string;
  dueDate: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  phase: AuditPhase;
  currentPhase: AuditPhase;
  evidence: Evidence[];
  actions: AuditAction[];
  reviewNotes?: string;
  capRequired?: boolean;
  isPeriodic: boolean;
  periodicity?: Periodicity;
  nextScheduledDate?: string;
  phaseAttachments: PhaseAttachments;
  phaseAssignees?: PhaseAssignees;
  history: AuditHistoryEntry[];
  linkedItems?: LinkedItem[];
}
```

#### AuditStatus
```typescript
type AuditStatus = 
  | 'pre_audit'
  | 'pre_audit_review'
  | 'draft'
  | 'open'
  | 'under_evaluation'
  | 'internal_review'
  | 'review_failed'
  | 'remediation_required'
  | 'in_cap'
  | 'pending_verification'
  | 'closed';
```

#### AuditPhase
```typescript
type AuditPhase = 
  | 'pre_audit'
  | 'overview'
  | 'evidence_collection'
  | 'evaluation'
  | 'internal_review'
  | 'closure_cap'
  | 'cap_active'
  | 'pending_verification'
  | 'closed';
```

#### User
```typescript
interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
}

type UserRole = 'staff' | 'department_head' | 'compliance_head' | 'admin';
```

### 6.2 Supporting Interfaces

#### Evidence
```typescript
interface Evidence {
  id: string;
  name: string;
  type: string;
  uploadedBy: string;
  uploadedAt: string;
  phase: AuditPhase;
}
```

#### AuditAction
```typescript
interface AuditAction {
  id: string;
  title: string;
  description?: string;
  completed: boolean;
  completedBy?: string;
  completedAt?: string;
}
```

#### AuditHistoryEntry
```typescript
interface AuditHistoryEntry {
  id: string;
  action: string;
  performedBy: string;
  performedAt: string;
  details?: string;
  previousValue?: string;
  newValue?: string;
}
```

---

## 7. Routing Architecture

### 7.1 Route Definitions

| Path | Component | Auth Required | Roles Allowed |
|------|-----------|---------------|---------------|
| `/` | Dashboard | Yes | All |
| `/new-audit` | NewAudit | Yes | DH, CH, Admin |
| `/edit-audit/:id` | EditAudit | Yes | DH, CH, Admin |
| `/audit/:id` | AuditPhase | Yes | All |
| `/audit/:id/phase/:phase` | AuditPhase | Yes | All |
| `/audit/:id/details` | AuditItemDetails | Yes | All |
| `/review/:id` | ScheduledReview | Yes | DH, CH, Admin |
| `/closure/:id` | ClosureCAP | Yes | CH, Admin |
| `/audits` | AllAudits | Yes | All |
| `/scheduled-audits` | ScheduledAudits | Yes | All |
| `/admin` | AdminSettings | Yes | Admin only |
| `/prd` | PRDDocumentation | Yes | All |
| `*` | NotFound | No | All |

### 7.2 Navigation Guards

```typescript
// Role-based navigation filtering
const canAccessRoute = (route: string, role: UserRole): boolean => {
  const adminOnlyRoutes = ['/admin'];
  const createRoutes = ['/new-audit'];
  
  if (adminOnlyRoutes.includes(route) && role !== 'admin') {
    return false;
  }
  
  if (createRoutes.includes(route) && role === 'staff') {
    return false;
  }
  
  return true;
};
```

---

## 8. Security Design

### 8.1 Role-Based Access Control (RBAC)

```typescript
interface Permission {
  action: string;
  resource: string;
}

const rolePermissions: Record<UserRole, Permission[]> = {
  staff: [
    { action: 'view', resource: 'assigned_audits' },
    { action: 'view', resource: 'department_audits' },
  ],
  department_head: [
    { action: 'view', resource: 'department_audits' },
    { action: 'create', resource: 'audits' },
    { action: 'edit', resource: 'department_audits' },
    { action: 'upload', resource: 'evidence' },
    { action: 'review', resource: 'internal_audits' },
  ],
  compliance_head: [
    { action: 'view', resource: 'all_audits' },
    { action: 'create', resource: 'audits' },
    { action: 'edit', resource: 'all_audits' },
    { action: 'close', resource: 'external_audits' },
    { action: 'cap_decision', resource: 'audits' },
  ],
  admin: [
    { action: '*', resource: '*' },
  ],
};
```

### 8.2 Data Visibility Rules

| Role | Audit Visibility |
|------|------------------|
| Staff | Assigned audits + department audits (read-only) |
| Department Head | Department audits (full access) |
| Compliance Head | All audits (full access) |
| Admin | All audits (full access) + settings |

---

## 9. Performance Considerations

### 9.1 Optimization Strategies

- **Code Splitting:** React.lazy() for route-based splitting
- **Memoization:** React.memo(), useMemo(), useCallback() for expensive computations
- **Virtual Scrolling:** Consider for large audit lists (100+ items)
- **Image Optimization:** Lazy loading for evidence thumbnails
- **Bundle Analysis:** Regular Vite bundle analysis

### 9.2 Performance Targets

| Metric | Target |
|--------|--------|
| First Contentful Paint | < 1.5s |
| Time to Interactive | < 3s |
| Largest Contentful Paint | < 2.5s |
| List render (100 items) | < 100ms |

---

## 10. Error Handling

### 10.1 Error Boundaries

```typescript
class ErrorBoundary extends React.Component {
  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }
  
  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Error caught:', error, errorInfo);
    // Log to error tracking service
  }
}
```

### 10.2 Toast Notifications

```typescript
// Success notifications
toast.success('Audit created successfully');

// Error notifications
toast.error('Failed to save changes');

// Warning notifications
toast.warning('Please complete all required fields');
```

---

## 11. Testing Strategy

### 11.1 Testing Pyramid

```
           ┌───────────┐
           │    E2E    │  <- Critical paths only
           ├───────────┤
           │Integration│  <- Component interactions
           ├───────────┤
           │   Unit    │  <- Pure functions, hooks
           └───────────┘
```

### 11.2 Test Coverage Targets

| Category | Target Coverage |
|----------|-----------------|
| Unit Tests | 80% |
| Integration Tests | 60% |
| E2E Tests | Critical paths |

---

## 12. Deployment Architecture

### 12.1 Build Process

```bash
# Development
npm run dev

# Production build
npm run build

# Preview production build
npm run preview
```

### 12.2 Environment Configuration

```typescript
// Environment variables
VITE_API_URL=https://api.example.com
VITE_SUPABASE_URL=https://xxx.supabase.co
VITE_SUPABASE_ANON_KEY=xxx
```

---

## 13. Future Considerations

### 13.1 Planned Enhancements

1. **Backend Integration:** Supabase/Lovable Cloud for persistence
2. **Real-time Updates:** WebSocket connections for live updates
3. **Offline Support:** Service worker for offline capability
4. **Mobile App:** React Native version
5. **Advanced Analytics:** Enhanced reporting dashboard

### 13.2 Scalability Considerations

- Database sharding for multi-tenant deployment
- CDN for static asset delivery
- Horizontal scaling for API layer
- Caching strategy for frequently accessed data

---

## 14. Changelog

| Date | Version | Changes |
|------|---------|---------|
| 2025-12-25 | 1.0 | Initial TDD creation |

---

*This document should be updated whenever significant technical changes are made to the AuditPro application.*
