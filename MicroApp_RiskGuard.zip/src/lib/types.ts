// RiskGuard Type Definitions

export type RiskStage = 'Report' | 'Evaluate' | 'Treat' | 'Monitor' | 'Reassess' | 'Closed';
export type SubStatus = 'Draft' | 'Submitted';
export type RiskLevel = 'Low' | 'Medium' | 'High' | 'Critical';
export type HarmLevel = 'None' | 'Mild' | 'Moderate' | 'Severe' | 'Death' | 'Unknown';
export type Priority = 'Routine' | 'Urgent' | 'Immediate';

export const RISK_CATEGORIES = [
  'Patient Safety',
  'Medication',
  'Fall',
  'Pressure Injury',
  'Infection Control',
  'Clinical Care',
  'Diagnostic',
  'Device/Equipment',
  'Staffing',
  'Workplace Safety',
  'Violence/Security',
  'Environmental',
  'Privacy/HIPAA',
  'Compliance/Regulatory',
  'Finance/Billing',
  'IT/Cyber',
  'Other',
] as const;

export const REPORT_TYPES = [
  'Near Miss',
  'Unsafe Condition (Hazard)',
  'Adverse Event',
  'Complaint',
  'Observation',
] as const;

export const LOCATION_TYPES = [
  'Inpatient',
  'Outpatient',
  'ER',
  'OR',
  'Pharmacy',
  'Lab',
  'Parking/Exterior',
  'Home Visit',
  'Other',
] as const;

export const FACILITY_TYPES = [
  'Hospital',
  'Clinic',
  'ASC',
  'Nursing Home',
  'Home Health',
  'Hospice',
  'Pharmacy',
  'Lab',
  'Imaging',
  'Behavioral Health',
  'Dental',
  'Other',
] as const;

export const DEPARTMENTS = [
  'Nursing',
  'Pharmacy',
  'Radiology',
  'Lab',
  'Surgery',
  'Emergency',
  'ICU',
  'Home Health',
  'HR',
  'IT',
  'Facilities',
  'Admin',
  'Finance',
  'Quality',
  'Other',
] as const;

export const CONTRIBUTING_FACTORS = [
  'Communication',
  'Training',
  'Staffing/Workload',
  'Policy Gap',
  'Human Factors',
  'Equipment',
  'Environment',
  'IT/System',
  'Medication Storage/Labeling',
  'Handoff',
  'Documentation',
  'Patient Factors',
  'Vendor/External',
  'Other',
] as const;

export const OUTCOME_TYPES = [
  'Physical Harm',
  'Psychological Harm',
  'Delay in Care',
  'Additional Treatment',
  'Escalation of Care',
  'Property Damage',
  'Financial Loss',
  'Regulatory Exposure',
  'Reputation Risk',
  'Privacy Impact',
] as const;

export const TREATMENT_TYPES = [
  'CAPA',
  'Process Change',
  'Training',
  'Tech Fix',
  'Policy Update',
  'Maintenance',
  'Vendor Action',
  'Other',
] as const;

export const ROME_DECISIONS = [
  { value: 'retain', label: 'Retain', description: 'Accept the risk as is' },
  { value: 'optimize', label: 'Optimize', description: 'Improve existing controls' },
  { value: 'mitigate', label: 'Mitigate', description: 'Reduce impact or likelihood' },
  { value: 'eliminate', label: 'Eliminate', description: 'Remove the risk source entirely' },
] as const;

export const RELATIONSHIP_TYPES = [
  'Source of Risk',
  'Related Complaint/Feedback',
  'Related Audit Finding',
  'Related Enforcement Action',
  'Control/Policy Reference',
  'Evidence',
  'Mitigation/CAPA',
  'Duplicate/Similar',
  'Other',
] as const;

export interface Attachment {
  id: string;
  name: string;
  size: number;
  type: string;
  uploadedBy: string;
  uploadedAt: string;
  stage: RiskStage;
  confidentialityLevel: 'Standard' | 'Restricted' | 'Legal Hold';
}

export interface PersonInvolved {
  partyType: 'Patient' | 'Staff' | 'Visitor' | 'Vendor' | 'Unknown';
  ageGroup?: string;
  role?: string;
  employmentType?: 'Employee' | 'Contractor' | 'Agency';
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  owner: string;
  dueDate: string;
  status: 'Pending' | 'In Progress' | 'Completed' | 'Overdue';
  createdAt: string;
}

export interface MonitoringMetric {
  id: string;
  name: string;
  target: string;
  frequency: string;
  dataSource: string;
  owner: string;
}

export interface MonitoringLog {
  id: string;
  date: string;
  note: string;
  status: 'On Track' | 'At Risk' | 'Off Track';
  recordedBy: string;
}

export interface ActivityLog {
  id: string;
  action: string;
  details: string;
  performedBy: string;
  performedAt: string;
  stage: RiskStage;
}

export interface CrossAppReference {
  id: string;
  sourceApp: 'RiskGuard' | 'ComplianceConnect' | 'EnforcePoint' | 'FeedbackHub' | 'AuditPro';
  sourceRecordId: string;
  targetApp: 'RiskGuard' | 'ComplianceConnect' | 'EnforcePoint' | 'FeedbackHub' | 'AuditPro';
  targetRecordId: string;
  targetTitle: string;
  relationshipType: string;
  linkNote?: string;
  createdBy: string;
  createdAt: string;
}

export interface RiskReport {
  id: string;
  
  // Report Basics
  facilityId?: string;
  facilityType?: string;
  departmentId: string;
  category: string;
  reportType: string;
  discoveredAt: string;
  occurredAt?: string;
  howIdentified: string;
  
  // Event Details
  locationType: string;
  locationText?: string;
  title: string;
  description: string;
  eventClassification?: string;
  witnessed: 'Yes' | 'No' | 'Unknown';
  witnessNames?: string;
  ongoing: boolean;
  immediateActionsTaken?: string;
  
  // People Involved
  peopleInvolved: PersonInvolved[];
  numberAffected?: number;
  
  // Impact & Severity
  actualHarmLevel: HarmLevel;
  potentialHarmLevel: HarmLevel;
  outcomeTypes: string[];
  reachedPatient: 'Yes' | 'No' | 'Unknown';
  sentinelSuspected: 'Yes' | 'No' | 'Unsure';
  
  // Contributing Factors
  contributingFactors: string[];
  preventionSuggestion?: string;
  
  // Notifications
  notifiedPatientFamily: 'Yes' | 'No' | 'NA' | 'Unknown';
  notifiedProvider: 'Yes' | 'No' | 'NA' | 'Unknown';
  notifiedSupervisor: 'Yes' | 'No' | 'NA' | 'Unknown';
  notifiedRiskQuality: 'Yes' | 'No' | 'NA' | 'Unknown';
  notifiedSecurity: 'Yes' | 'No' | 'NA' | 'Unknown';
  notifiedPrivacy: 'Yes' | 'No' | 'NA' | 'Unknown';
  regulatoryReportingRequired: 'Yes' | 'No' | 'Unsure';
  priority: Priority;
  requestedFollowUp: boolean;
  contactMethod?: string;
  
  // Reporter
  isAnonymous: boolean;
  reporterName?: string;
  reporterEmail?: string;
  reporterId?: string;
  attestationConfirmed: boolean;
  
  // Status & Lifecycle
  stage: RiskStage;
  subStatus: SubStatus;
  templateIdUsed?: string;
  
  // Evaluation
  likelihood?: number;
  impact?: number;
  readiness?: number;
  riskScore?: number;
  riskLevel?: RiskLevel;
  overrideFlag?: boolean;
  overrideReason?: string;
  evaluationSummary?: string;
  evaluationDecision?: 'Treat' | 'Monitor' | 'Close';
  
  // Treatment
  romeDecision?: string;
  treatmentType?: string;
  mitigationPlan?: string;
  expectedOutcome?: string;
  interimControls?: boolean;
  interimControlsDetails?: string;
  
  // Monitoring
  monitoringMetrics: MonitoringMetric[];
  monitoringLogs: MonitoringLog[];
  
  // Reassessment
  effectivenessReview?: string;
  residualLikelihood?: number;
  residualImpact?: number;
  residualScore?: number;
  residualLevel?: RiskLevel;
  
  // Closure
  closureReason?: string;
  closureSummary?: string;
  closedAt?: string;
  closedBy?: string;
  finalClassification?: string;
  finalHarmLevel?: HarmLevel;
  finalRiskLevel?: RiskLevel;
  
  // Relationships
  tasks: Task[];
  attachments: Attachment[];
  activityLog: ActivityLog[];
  crossAppReferences: CrossAppReference[];
  
  // Metadata
  createdAt: string;
  createdBy: string;
  updatedAt: string;
  assignee: string;
}

export interface RiskTemplate {
  id: string;
  name: string;
  description: string;
  whenToUse?: string;
  tags: string[];
  visibility: 'Private' | 'Department' | 'Organization';
  version: number;
  changeNotes?: string;
  isArchived: boolean;
  
  // Defaults
  facilityType?: string;
  departmentId?: string;
  category: string;
  reportType?: string;
  eventClassification?: string;
  locationType?: string;
  suggestedTitle?: string;
  defaultFactors?: string[];
  defaultNotifications?: Record<string, string>;
  priority?: Priority;
  suggestedLikelihood?: number;
  suggestedImpact?: number;
  
  // Linked Content
  linkedContent: string[];
  
  // Metadata
  createdAt: string;
  createdBy: string;
  updatedAt: string;
  updatedBy: string;
}

// Utility functions
export function calculateRiskScore(likelihood: number, impact: number, readiness: number): { baseScore: number; adjustedScore: number; scoreRounded: number } {
  const baseScore = likelihood * impact;
  const readinessFactor = (4 - readiness) / 3;
  const adjustedScore = baseScore * readinessFactor;
  const scoreRounded = Math.round(adjustedScore);
  return { baseScore, adjustedScore, scoreRounded };
}

export function getRiskLevel(score: number): RiskLevel {
  if (score >= 13) return 'Critical';
  if (score >= 8) return 'High';
  if (score >= 4) return 'Medium';
  return 'Low';
}

export function getRiskLevelStyle(level: RiskLevel | string): string {
  switch (level) {
    case 'Critical':
      return 'bg-risk-critical/10 text-risk-critical border-risk-critical/20';
    case 'High':
      return 'bg-risk-high/10 text-risk-high border-risk-high/20';
    case 'Medium':
      return 'bg-risk-medium/10 text-risk-medium border-risk-medium/20';
    case 'Low':
    default:
      return 'bg-risk-low/10 text-risk-low border-risk-low/20';
  }
}

export function getStageStyle(stage: RiskStage): { color: string; bgColor: string; borderColor: string } {
  const styles: Record<RiskStage, { color: string; bgColor: string; borderColor: string }> = {
    Report: { color: 'text-status-reported', bgColor: 'bg-status-reported/10', borderColor: 'border-status-reported/20' },
    Evaluate: { color: 'text-status-evaluation', bgColor: 'bg-status-evaluation/10', borderColor: 'border-status-evaluation/20' },
    Treat: { color: 'text-status-treatment', bgColor: 'bg-status-treatment/10', borderColor: 'border-status-treatment/20' },
    Monitor: { color: 'text-status-monitoring', bgColor: 'bg-status-monitoring/10', borderColor: 'border-status-monitoring/20' },
    Reassess: { color: 'text-status-reassess', bgColor: 'bg-status-reassess/10', borderColor: 'border-status-reassess/20' },
    Closed: { color: 'text-status-closed', bgColor: 'bg-status-closed/10', borderColor: 'border-status-closed/20' },
  };
  return styles[stage];
}

export function generateRiskId(): string {
  const num = Math.floor(Math.random() * 9000) + 1000;
  return `RG-${num}`;
}
