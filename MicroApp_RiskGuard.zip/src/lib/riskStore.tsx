import { createContext, useCallback, useContext, useEffect, useMemo, useState, ReactNode } from 'react';
import { RiskReport, RiskStage, SubStatus, generateRiskId } from './types';
import { mockRisks } from './mockData';

const STORAGE_KEY = 'riskguard.userRisks.v1';
const DRAFT_FORMS_KEY = 'riskguard.draftForms.v1';

/** Raw wizard form state kept alongside a draft so it can be reopened prefilled. */
export type DraftForm = Record<string, unknown>;

interface RiskStoreValue {
  /** Seeded risks plus everything created in-app, newest first. */
  risks: RiskReport[];
  addRisk: (risk: RiskReport) => void;
  updateRisk: (id: string, patch: Partial<RiskReport>) => void;
  getRiskById: (id: string) => RiskReport | undefined;
  saveDraftForm: (id: string, form: DraftForm) => void;
  getDraftForm: (id: string) => DraftForm | undefined;
  stats: {
    byStage: Record<RiskStage, number>;
    byLevel: Record<string, number>;
    byCategory: Record<string, number>;
    total: number;
  };
}

const RiskStoreContext = createContext<RiskStoreValue | null>(null);

function readStored<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeStored(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable — keep working in memory */
  }
}

export function RiskStoreProvider({ children }: { children: ReactNode }) {
  const [userRisks, setUserRisks] = useState<RiskReport[]>(() =>
    readStored<RiskReport[]>(STORAGE_KEY, [])
  );
  const [draftForms, setDraftForms] = useState<Record<string, DraftForm>>(() =>
    readStored<Record<string, DraftForm>>(DRAFT_FORMS_KEY, {})
  );

  useEffect(() => {
    writeStored(STORAGE_KEY, userRisks);
  }, [userRisks]);

  useEffect(() => {
    writeStored(DRAFT_FORMS_KEY, draftForms);
  }, [draftForms]);

  const addRisk = useCallback((risk: RiskReport) => {
    setUserRisks(prev => [risk, ...prev.filter(r => r.id !== risk.id)]);
  }, []);

  const updateRisk = useCallback((id: string, patch: Partial<RiskReport>) => {
    setUserRisks(prev =>
      prev.map(r =>
        r.id === id ? { ...r, ...patch, updatedAt: new Date().toISOString() } : r
      )
    );
  }, []);

  const saveDraftForm = useCallback((id: string, form: DraftForm) => {
    setDraftForms(prev => ({ ...prev, [id]: form }));
  }, []);

  const risks = useMemo(() => {
    const merged = [...userRisks, ...mockRisks];
    return merged.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [userRisks]);

  const getRiskById = useCallback(
    (id: string) => risks.find(r => r.id === id),
    [risks]
  );

  const getDraftForm = useCallback((id: string) => draftForms[id], [draftForms]);

  const stats = useMemo(() => {
    const byStage: Record<RiskStage, number> = {
      Report: 0,
      Evaluate: 0,
      Treat: 0,
      Monitor: 0,
      Reassess: 0,
      Closed: 0,
    };
    const byLevel: Record<string, number> = { Critical: 0, High: 0, Medium: 0, Low: 0 };
    const byCategory: Record<string, number> = {};

    risks.forEach(risk => {
      byStage[risk.stage]++;
      if (risk.riskLevel) byLevel[risk.riskLevel]++;
      byCategory[risk.category] = (byCategory[risk.category] || 0) + 1;
    });

    return { byStage, byLevel, byCategory, total: risks.length };
  }, [risks]);

  const value = useMemo(
    () => ({ risks, addRisk, updateRisk, getRiskById, saveDraftForm, getDraftForm, stats }),
    [risks, addRisk, updateRisk, getRiskById, saveDraftForm, getDraftForm, stats]
  );

  return <RiskStoreContext.Provider value={value}>{children}</RiskStoreContext.Provider>;
}

export function useRiskStore(): RiskStoreValue {
  const ctx = useContext(RiskStoreContext);
  if (!ctx) throw new Error('useRiskStore must be used within a RiskStoreProvider');
  return ctx;
}

/** Ids used by risks created in-app, so they never collide with seeded RG-1xxx ids. */
export function newRiskId(): string {
  return generateRiskId();
}

interface NewRiskInput {
  id?: string;
  title: string;
  description: string;
  category: string;
  departmentId: string;
  subStatus: SubStatus;
  facilityType?: string;
  reportType?: string;
  discoveredAt?: string;
  occurredAt?: string;
  howIdentified?: string;
  locationType?: string;
  locationText?: string;
  witnessed?: RiskReport['witnessed'];
  witnessNames?: string;
  ongoing?: boolean;
  immediateActionsTaken?: string;
  peopleInvolved?: RiskReport['peopleInvolved'];
  numberAffected?: number;
  actualHarmLevel?: RiskReport['actualHarmLevel'];
  potentialHarmLevel?: RiskReport['potentialHarmLevel'];
  outcomeTypes?: string[];
  reachedPatient?: RiskReport['reachedPatient'];
  sentinelSuspected?: RiskReport['sentinelSuspected'];
  contributingFactors?: string[];
  preventionSuggestion?: string;
  notifiedPatientFamily?: RiskReport['notifiedPatientFamily'];
  notifiedProvider?: RiskReport['notifiedProvider'];
  notifiedSupervisor?: RiskReport['notifiedSupervisor'];
  notifiedRiskQuality?: RiskReport['notifiedRiskQuality'];
  notifiedSecurity?: RiskReport['notifiedSecurity'];
  notifiedPrivacy?: RiskReport['notifiedPrivacy'];
  regulatoryReportingRequired?: RiskReport['regulatoryReportingRequired'];
  priority?: RiskReport['priority'];
  requestedFollowUp?: boolean;
  contactMethod?: string;
  isAnonymous?: boolean;
  reporterName?: string;
  reporterEmail?: string;
  attestationConfirmed?: boolean;
  crossAppReferences?: RiskReport['crossAppReferences'];
  attachments?: RiskReport['attachments'];
  templateIdUsed?: string;
}

/** Builds a complete RiskReport from the partial data a reporting form collects. */
export function buildRiskReport(input: NewRiskInput): RiskReport {
  const now = new Date().toISOString();
  const reporter = input.isAnonymous
    ? 'Anonymous'
    : input.reporterName?.trim() || 'current-user@health.org';

  return {
    id: input.id || newRiskId(),
    facilityType: input.facilityType || undefined,
    departmentId: input.departmentId || 'Unassigned',
    category: input.category || 'Uncategorized',
    reportType: input.reportType || 'Incident',
    discoveredAt: input.discoveredAt || now,
    occurredAt: input.occurredAt,
    howIdentified: input.howIdentified || 'Not specified',
    locationType: input.locationType || 'Not specified',
    locationText: input.locationText,
    title: input.title,
    description: input.description,
    witnessed: input.witnessed || 'Unknown',
    witnessNames: input.witnessNames,
    ongoing: input.ongoing ?? false,
    immediateActionsTaken: input.immediateActionsTaken,
    peopleInvolved: input.peopleInvolved || [],
    numberAffected: input.numberAffected,
    actualHarmLevel: input.actualHarmLevel || 'None',
    potentialHarmLevel: input.potentialHarmLevel || 'None',
    outcomeTypes: input.outcomeTypes || [],
    reachedPatient: input.reachedPatient || 'Unknown',
    sentinelSuspected: input.sentinelSuspected || 'Unsure',
    contributingFactors: input.contributingFactors || [],
    preventionSuggestion: input.preventionSuggestion,
    notifiedPatientFamily: input.notifiedPatientFamily || 'Unknown',
    notifiedProvider: input.notifiedProvider || 'Unknown',
    notifiedSupervisor: input.notifiedSupervisor || 'Unknown',
    notifiedRiskQuality: input.notifiedRiskQuality || 'Unknown',
    notifiedSecurity: input.notifiedSecurity || 'Unknown',
    notifiedPrivacy: input.notifiedPrivacy || 'Unknown',
    regulatoryReportingRequired: input.regulatoryReportingRequired || 'Unsure',
    priority: input.priority || 'Routine',
    requestedFollowUp: input.requestedFollowUp ?? false,
    contactMethod: input.contactMethod,
    isAnonymous: input.isAnonymous ?? false,
    reporterName: input.isAnonymous ? undefined : input.reporterName,
    reporterEmail: input.isAnonymous ? undefined : input.reporterEmail,
    attestationConfirmed: input.attestationConfirmed ?? false,
    stage: 'Report',
    subStatus: input.subStatus,
    templateIdUsed: input.templateIdUsed,
    tasks: [],
    attachments: input.attachments || [],
    activityLog: [
      {
        id: '1',
        action: input.subStatus === 'Draft' ? 'Draft Saved' : 'Risk Reported',
        details:
          input.subStatus === 'Draft'
            ? 'Report saved as draft'
            : 'Initial report submitted',
        performedBy: reporter,
        performedAt: now,
        stage: 'Report',
      },
    ],
    crossAppReferences: input.crossAppReferences || [],
    monitoringMetrics: [],
    monitoringLogs: [],
    createdAt: now,
    createdBy: reporter,
    updatedAt: now,
    assignee: 'Unassigned',
  };
}
