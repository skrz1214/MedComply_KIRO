import { ArrowLeft, FileText, Upload, X } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { useState } from "react";
import { LinkedItemsPanel } from "@/components/LinkedItemsPanel";
import { CrossAppReference } from "@/lib/types";
import { useRiskStore, buildRiskReport, newRiskId } from "@/lib/riskStore";

const ReportRisk = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const template = location.state?.template;
  const [attachments, setAttachments] = useState<File[]>([]);
  const [crossReferences, setCrossReferences] = useState<CrossAppReference[]>([]);
  const { addRisk } = useRiskStore();

  const [title, setTitle] = useState(template?.name || "");
  const [description, setDescription] = useState(template?.description || "");
  const [category, setCategory] = useState<string>(template?.category || "");
  const [department, setDepartment] = useState<string>(template?.department || "");
  const [locationText, setLocationText] = useState("");
  const [immediateAction, setImmediateAction] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const id = newRiskId();
    addRisk(
      buildRiskReport({
        id,
        subStatus: "Submitted",
        title: title.trim(),
        description: description.trim(),
        category,
        departmentId: department,
        locationText: locationText.trim() || undefined,
        immediateActionsTaken: immediateAction.trim() || undefined,
        crossAppReferences: crossReferences,
        templateIdUsed: template?.id,
        attestationConfirmed: true,
      })
    );

    toast.success(`Risk ${id} reported successfully`);
    navigate("/risks");
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setAttachments(prev => [...prev, ...newFiles]);
    }
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const handleAddReference = (ref: Omit<CrossAppReference, 'id' | 'createdAt' | 'createdBy'>) => {
    const newRef: CrossAppReference = {
      ...ref,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      createdBy: 'current-user@health.org',
    };
    setCrossReferences(prev => [...prev, newRef]);
  };

  const handleRemoveReference = (id: string, reason: string) => {
    setCrossReferences(prev => prev.filter(ref => ref.id !== id));
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Page Header */}
      <section className="bg-gradient-to-br from-secondary/5 to-primary/5 border-b border-border">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center gap-4 mb-2">
            <Button variant="ghost" size="icon" onClick={() => navigate("/process")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h2 className="text-3xl font-bold text-foreground">
              Report New Risk
            </h2>
          </div>
          <p className="text-muted-foreground ml-12">
            {template ? (
              <span className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Using template: <strong>{template.name}</strong>
              </span>
            ) : (
              "Document a new risk incident for evaluation and treatment"
            )}
          </p>
        </div>
      </section>

      {/* Form */}
      <section className="container mx-auto px-6 py-8">
        <div className="max-w-5xl mx-auto">
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Main Form */}
            <div className="lg:col-span-2">
              <form onSubmit={handleSubmit}>
                <Card>
                  <CardHeader>
                    <CardTitle>Report Basics</CardTitle>
                    <CardDescription>
                      Provide basic information about the risk incident
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="title">Risk Title *</Label>
                      <Input
                        id="title"
                        placeholder="Brief description of the risk"
                        value={title}
                        onChange={e => setTitle(e.target.value)}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="description">Description *</Label>
                      <Textarea
                        id="description"
                        placeholder="Detailed description of what happened, when, where, and who was involved"
                        value={description}
                        onChange={e => setDescription(e.target.value)}
                        rows={4}
                        required
                      />
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="category">Category *</Label>
                        <Select required value={category} onValueChange={setCategory}>
                          <SelectTrigger id="category">
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Fall">Falls Prevention</SelectItem>
                            <SelectItem value="Medication">Medication Safety</SelectItem>
                            <SelectItem value="Infection Control">Infection Control</SelectItem>
                            <SelectItem value="Patient Safety">Abuse &amp; Neglect</SelectItem>
                            <SelectItem value="Environmental">Emergency Preparedness</SelectItem>
                            <SelectItem value="Finance/Billing">Billing Integrity</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="department">Department *</Label>
                        <Select required value={department} onValueChange={setDepartment}>
                          <SelectTrigger id="department">
                            <SelectValue placeholder="Select department" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Nursing">Nursing</SelectItem>
                            <SelectItem value="Pharmacy">Pharmacy</SelectItem>
                            <SelectItem value="Home Health">Home Health</SelectItem>
                            <SelectItem value="Quality">Clinical</SelectItem>
                            <SelectItem value="Facilities">Facilities</SelectItem>
                            <SelectItem value="Other">Assisted Living</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        placeholder="Where did this occur?"
                        value={locationText}
                        onChange={e => setLocationText(e.target.value)}
                      />
                    </div>


                    <div className="space-y-2">
                      <Label htmlFor="immediate-action">Immediate Action Taken</Label>
                      <Textarea
                        id="immediate-action"
                        placeholder="What immediate steps were taken to address the situation?"
                        value={immediateAction}
                        onChange={e => setImmediateAction(e.target.value)}
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="attachments">Attachments (Evidence)</Label>
                      <div className="border-2 border-dashed border-border rounded-lg p-4 hover:border-primary/50 transition-colors">
                        <div className="flex flex-col items-center gap-2 text-center">
                          <Upload className="h-8 w-8 text-muted-foreground" />
                          <div>
                            <Label htmlFor="file-upload" className="cursor-pointer text-primary hover:text-primary/80">
                              Click to upload
                            </Label>
                            <span className="text-muted-foreground"> or drag and drop</span>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            PDF, images, documents (max 10MB each)
                          </p>
                          <Input
                            id="file-upload"
                            type="file"
                            multiple
                            onChange={handleFileChange}
                            className="hidden"
                            accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif"
                          />
                        </div>
                      </div>
                      
                      {attachments.length > 0 && (
                        <div className="mt-4 space-y-2">
                          <p className="text-sm font-medium">Attached files ({attachments.length})</p>
                          {attachments.map((file, index) => (
                            <div key={index} className="flex items-center justify-between p-3 border border-border rounded-lg bg-muted/30">
                              <div className="flex items-center gap-2">
                                <FileText className="h-4 w-4 text-primary" />
                                <div>
                                  <p className="text-sm font-medium">{file.name}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {(file.size / 1024).toFixed(1)} KB
                                  </p>
                                </div>
                              </div>
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={() => removeAttachment(index)}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="pt-4 flex gap-3">
                      <Button type="submit" className="flex-1">
                        Submit Risk Report
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => navigate("/process")}
                      >
                        Cancel
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </form>
            </div>

            {/* Cross-Reference Panel */}
            <div className="lg:col-span-1">
              <div className="sticky top-6">
                <LinkedItemsPanel
                  references={crossReferences}
                  onAdd={handleAddReference}
                  onRemove={handleRemoveReference}
                />
                <p className="text-xs text-muted-foreground mt-2 px-1">
                  Link related items from ComplianceConnect, EnforcePoint, FeedbackHub, or AuditPro
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ReportRisk;
