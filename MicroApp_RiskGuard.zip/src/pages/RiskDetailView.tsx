import { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { RiskStageStepper } from '@/components/RiskStageStepper';
import { LinkedItemsPanel } from '@/components/LinkedItemsPanel';
import { useRiskStore } from '@/lib/riskStore';
import { getRiskLevelStyle, getStageStyle, CrossAppReference } from '@/lib/types';
import {
  ArrowLeft,
  FileText,
  User,
  MapPin,
  Calendar,
  AlertTriangle,
  Download,
  Paperclip,
  Clock,
  ArrowRight,
} from 'lucide-react';

export default function RiskDetailView() {
  const { riskId } = useParams();
  const navigate = useNavigate();
  
  const { getRiskById } = useRiskStore();
  const risk = getRiskById(riskId || '');
  
  const [linkedItems, setLinkedItems] = useState<CrossAppReference[]>([]);

  if (!risk) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">Risk Not Found</h2>
            <p className="text-muted-foreground mb-4">The risk you are looking for does not exist.</p>
            <Button onClick={() => navigate('/risks')}>Back to Risk Queue</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const stageStyle = getStageStyle(risk.stage);

  const handleAddReference = (ref: Omit<CrossAppReference, 'id' | 'createdAt' | 'createdBy'>) => {
    const newRef: CrossAppReference = {
      ...ref,
      id: `ref-${Date.now()}`,
      sourceRecordId: risk.id,
      createdAt: new Date().toISOString(),
      createdBy: 'current-user',
    };
    setLinkedItems(prev => [...prev, newRef]);
  };

  const handleRemoveReference = (id: string) => {
    setLinkedItems(prev => prev.filter(r => r.id !== id));
  };

  const handleStageAction = () => {
    if (risk.stage === 'Report') {
      navigate(`/risks/${risk.id}/evaluate`);
    } else if (risk.stage !== 'Closed') {
      navigate(`/risks/${risk.id}/${risk.stage.toLowerCase()}`);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="bg-gradient-to-br from-primary/5 to-secondary/5 border-b">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center gap-4 mb-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/risks')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="text-base">{risk.id}</Badge>
              <Badge variant="outline" className={`${stageStyle.bgColor} ${stageStyle.color} ${stageStyle.borderColor}`}>
                {risk.stage}
              </Badge>
              {risk.riskLevel && (
                <Badge variant="outline" className={getRiskLevelStyle(risk.riskLevel)}>
                  {risk.riskLevel}
                </Badge>
              )}
              <Badge variant="outline">{risk.priority}</Badge>
            </div>
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">{risk.title}</h1>
          <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1"><FileText className="h-4 w-4" />{risk.category}</span>
            <span className="flex items-center gap-1"><MapPin className="h-4 w-4" />{risk.departmentId}</span>
            <span className="flex items-center gap-1"><User className="h-4 w-4" />{risk.assignee}</span>
            <span className="flex items-center gap-1"><Calendar className="h-4 w-4" />{new Date(risk.createdAt).toLocaleDateString()}</span>
          </div>
        </div>
      </section>

      {/* Stage Stepper */}
      <section className="container mx-auto px-6 py-6">
        <Card>
          <CardContent className="p-6">
            <RiskStageStepper currentStage={risk.stage} />
            {risk.stage !== 'Closed' && (
              <div className="flex justify-end mt-4">
                <Button onClick={handleStageAction}>
                  {risk.stage === 'Report' ? 'Begin Evaluation' : `Go to ${risk.stage}`}
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </section>

      {/* Main Content */}
      <section className="container mx-auto px-6 pb-12">
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <Tabs defaultValue="overview">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="people">People</TabsTrigger>
                <TabsTrigger value="impact">Impact</TabsTrigger>
                <TabsTrigger value="attachments">Attachments ({risk.attachments.length})</TabsTrigger>
                <TabsTrigger value="history">History</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="mt-6 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Event Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Description</p>
                      <p className="mt-1">{risk.description}</p>
                    </div>
                    <Separator />
                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <p className="text-sm text-muted-foreground">Report Type</p>
                        <p className="font-medium">{risk.reportType}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Location</p>
                        <p className="font-medium">{risk.locationType} {risk.locationText && `- ${risk.locationText}`}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Discovered</p>
                        <p className="font-medium">{new Date(risk.discoveredAt).toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Occurred</p>
                        <p className="font-medium">{risk.occurredAt ? new Date(risk.occurredAt).toLocaleString() : 'Unknown'}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Witnessed</p>
                        <p className="font-medium">{risk.witnessed}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Ongoing</p>
                        <p className="font-medium">{risk.ongoing ? 'Yes' : 'No'}</p>
                      </div>
                    </div>
                    {risk.immediateActionsTaken && (
                      <>
                        <Separator />
                        <div>
                          <p className="text-sm text-muted-foreground">Immediate Actions Taken</p>
                          <p className="mt-1">{risk.immediateActionsTaken}</p>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>

                {risk.riskScore && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Risk Assessment</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid gap-4 md:grid-cols-4">
                        <div className="text-center p-4 bg-muted/50 rounded-lg">
                          <p className="text-sm text-muted-foreground">Likelihood</p>
                          <p className="text-2xl font-bold">{risk.likelihood}</p>
                        </div>
                        <div className="text-center p-4 bg-muted/50 rounded-lg">
                          <p className="text-sm text-muted-foreground">Impact</p>
                          <p className="text-2xl font-bold">{risk.impact}</p>
                        </div>
                        <div className="text-center p-4 bg-muted/50 rounded-lg">
                          <p className="text-sm text-muted-foreground">Readiness</p>
                          <p className="text-2xl font-bold">{risk.readiness}</p>
                        </div>
                        <div className="text-center p-4 bg-primary/10 rounded-lg">
                          <p className="text-sm text-muted-foreground">Risk Score</p>
                          <p className="text-2xl font-bold text-primary">{risk.riskScore}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {risk.contributingFactors.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Contributing Factors</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {risk.contributingFactors.map(factor => (
                          <Badge key={factor} variant="secondary">{factor}</Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="people" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>People Involved</CardTitle>
                    <CardDescription>Parties affected by or involved in this event (minimal PHI)</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {risk.peopleInvolved.length === 0 ? (
                      <p className="text-muted-foreground">No people information recorded</p>
                    ) : (
                      <div className="space-y-4">
                        {risk.peopleInvolved.map((person, index) => (
                          <div key={index} className="p-4 border rounded-lg">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge>{person.partyType}</Badge>
                              {person.ageGroup && <Badge variant="outline">{person.ageGroup}</Badge>}
                            </div>
                            {person.role && <p className="text-sm">Role: {person.role}</p>}
                            {person.employmentType && <p className="text-sm">Employment: {person.employmentType}</p>}
                          </div>
                        ))}
                        {risk.numberAffected && (
                          <p className="text-sm text-muted-foreground">Total affected: {risk.numberAffected}</p>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="impact" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Impact & Severity</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <p className="text-sm text-muted-foreground">Actual Harm Level</p>
                        <Badge className="mt-1" variant={risk.actualHarmLevel === 'None' ? 'secondary' : 'destructive'}>
                          {risk.actualHarmLevel}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Potential Harm Level</p>
                        <Badge className="mt-1" variant="outline">{risk.potentialHarmLevel}</Badge>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Reached Patient</p>
                        <p className="font-medium">{risk.reachedPatient}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Sentinel/Never Event Suspected</p>
                        <p className="font-medium">{risk.sentinelSuspected}</p>
                      </div>
                    </div>
                    {risk.outcomeTypes.length > 0 && (
                      <>
                        <Separator />
                        <div>
                          <p className="text-sm text-muted-foreground mb-2">Outcome Types</p>
                          <div className="flex flex-wrap gap-2">
                            {risk.outcomeTypes.map(outcome => (
                              <Badge key={outcome} variant="outline">{outcome}</Badge>
                            ))}
                          </div>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="attachments" className="mt-6">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>Attachments & Evidence</CardTitle>
                        <CardDescription>Files attached during the risk lifecycle</CardDescription>
                      </div>
                      <Button variant="outline" size="sm">
                        <Paperclip className="h-4 w-4 mr-2" />
                        Add Attachment
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {risk.attachments.length === 0 ? (
                      <p className="text-muted-foreground text-center py-8">No attachments</p>
                    ) : (
                      <div className="space-y-2">
                        {risk.attachments.map(attachment => (
                          <div key={attachment.id} className="flex items-center justify-between p-3 border rounded-lg">
                            <div className="flex items-center gap-3">
                              <FileText className="h-5 w-5 text-primary" />
                              <div>
                                <p className="font-medium">{attachment.name}</p>
                                <p className="text-xs text-muted-foreground">
                                  {(attachment.size / 1024).toFixed(1)} KB • {attachment.stage} stage • {attachment.uploadedBy}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">{attachment.confidentialityLevel}</Badge>
                              <Button variant="ghost" size="icon">
                                <Download className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="history" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Activity Log</CardTitle>
                    <CardDescription>Complete audit trail of actions</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {risk.activityLog.length === 0 ? (
                      <p className="text-muted-foreground text-center py-8">No activity recorded</p>
                    ) : (
                      <div className="space-y-4">
                        {risk.activityLog.map((log, index) => (
                          <div key={log.id} className="flex gap-4">
                            <div className="flex flex-col items-center">
                              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                                <Clock className="h-4 w-4 text-primary" />
                              </div>
                              {index < risk.activityLog.length - 1 && (
                                <div className="w-0.5 flex-1 bg-border mt-2" />
                              )}
                            </div>
                            <div className="pb-4">
                              <p className="font-medium">{log.action}</p>
                              <p className="text-sm text-muted-foreground">{log.details}</p>
                              <p className="text-xs text-muted-foreground mt-1">
                                {log.performedBy} • {new Date(log.performedAt).toLocaleString()} • {log.stage} stage
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <LinkedItemsPanel
              references={[...risk.crossAppReferences, ...linkedItems]}
              onAdd={handleAddReference}
              onRemove={handleRemoveReference}
              readOnly={risk.stage === 'Closed'}
            />

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Quick Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Reported By</p>
                  <p className="font-medium">{risk.isAnonymous ? 'Anonymous' : risk.reporterName || 'Unknown'}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Created</p>
                  <p className="font-medium">{new Date(risk.createdAt).toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Last Updated</p>
                  <p className="font-medium">{new Date(risk.updatedAt).toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Template Used</p>
                  <p className="font-medium">{risk.templateIdUsed || 'None'}</p>
                </div>
              </CardContent>
            </Card>

            {risk.stage === 'Closed' && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Closure Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Closure Reason</p>
                    <p className="font-medium">{risk.closureReason}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Summary</p>
                    <p>{risk.closureSummary}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Closed By</p>
                    <p className="font-medium">{risk.closedBy}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Closed At</p>
                    <p className="font-medium">{risk.closedAt && new Date(risk.closedAt).toLocaleString()}</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
