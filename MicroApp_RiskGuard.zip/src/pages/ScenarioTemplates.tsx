import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Plus, Edit, Trash2, FileText } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface ScenarioTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  department?: string;
  linkedContent: string[];
  status: "active" | "inactive";
  createdBy: string;
  createdAt: string;
}

const categories = [
  "ABUSE_NEGLECT",
  "MEDICATION_SAFETY",
  "FALLS",
  "INFECTION_CONTROL",
  "BILLING_INTEGRITY",
];

const departments = [
  "NURSING",
  "PHARMACY",
  "HOME_HEALTH",
  "ASSISTED_LIVING",
];

export default function ScenarioTemplates() {
  const navigate = useNavigate();
  const { toast } = useToast();

  const [templates, setTemplates] = useState<ScenarioTemplate[]>([
    {
      id: "1",
      name: "Medication Administration Error - Pharmacy",
      description: "Wrong medication dispensed or administered to patient",
      category: "MEDICATION_SAFETY",
      department: "PHARMACY",
      linkedContent: ["SOP-MED-001", "POLICY-MED-SAFETY"],
      status: "active",
      createdBy: "admin@health.org",
      createdAt: "2025-01-15",
    },
    {
      id: "2",
      name: "Patient Fall with Injury",
      description: "Patient fall resulting in injury requiring medical attention",
      category: "FALLS",
      department: "NURSING",
      linkedContent: ["SOP-FALL-001", "POLICY-FALL-PREVENTION"],
      status: "active",
      createdBy: "compliance@health.org",
      createdAt: "2025-01-10",
    },
    {
      id: "3",
      name: "Suspected Abuse or Neglect",
      description: "Report of suspected physical, emotional, or financial abuse",
      category: "ABUSE_NEGLECT",
      linkedContent: ["SOP-ABUSE-001", "POLICY-SAFEGUARDING"],
      status: "active",
      createdBy: "compliance@health.org",
      createdAt: "2025-01-05",
    },
  ]);

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<ScenarioTemplate | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    category: "",
    department: "",
    linkedContent: "",
    status: "active" as "active" | "inactive",
  });

  const handleCreateOrUpdate = () => {
    if (!formData.name || !formData.description || !formData.category) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    if (editingTemplate) {
      setTemplates(
        templates.map((t) =>
          t.id === editingTemplate.id
            ? {
                ...t,
                ...formData,
                linkedContent: formData.linkedContent.split(",").map((s) => s.trim()),
              }
            : t
        )
      );
      toast({
        title: "Template Updated",
        description: `"${formData.name}" has been updated successfully.`,
      });
    } else {
      const newTemplate: ScenarioTemplate = {
        id: Date.now().toString(),
        ...formData,
        linkedContent: formData.linkedContent.split(",").map((s) => s.trim()),
        createdBy: "current-user@health.org",
        createdAt: new Date().toISOString().split("T")[0],
      };
      setTemplates([...templates, newTemplate]);
      toast({
        title: "Template Created",
        description: `"${formData.name}" has been created successfully.`,
      });
    }

    setIsDialogOpen(false);
    setEditingTemplate(null);
    setFormData({
      name: "",
      description: "",
      category: "",
      department: "",
      linkedContent: "",
      status: "active",
    });
  };

  const handleEdit = (template: ScenarioTemplate) => {
    setEditingTemplate(template);
    setFormData({
      name: template.name,
      description: template.description,
      category: template.category,
      department: template.department || "",
      linkedContent: template.linkedContent.join(", "),
      status: template.status,
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    setTemplates(templates.filter((t) => t.id !== id));
    toast({
      title: "Template Deleted",
      description: "The scenario template has been deleted.",
    });
  };

  const handleUseTemplate = (template: ScenarioTemplate) => {
    navigate("/report-risk", { state: { template } });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <div className="container mx-auto p-6 max-w-6xl">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/process")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-foreground">Scenario Templates</h1>
              <p className="text-muted-foreground">Pre-configured risk scenarios for quick reporting</p>
            </div>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => {
                setEditingTemplate(null);
                setFormData({
                  name: "",
                  description: "",
                  category: "",
                  department: "",
                  linkedContent: "",
                  status: "active",
                });
              }}>
                <Plus className="h-4 w-4 mr-2" />
                New Template
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>{editingTemplate ? "Edit Template" : "Create New Template"}</DialogTitle>
                <DialogDescription>
                  Templates pre-fill risk data but do not define scoring rules. Scoring follows Org/Category/Category+Department precedence.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Template Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g., Medication Administration Error"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe the risk scenario..."
                    rows={3}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">Category *</Label>
                    <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                      <SelectTrigger id="category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat} value={cat}>
                            {cat.replace(/_/g, " ")}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="department">Department (Optional)</Label>
                    <Select value={formData.department} onValueChange={(value) => setFormData({ ...formData, department: value })}>
                      <SelectTrigger id="department">
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments.map((dept) => (
                          <SelectItem key={dept} value={dept}>
                            {dept.replace(/_/g, " ")}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="linkedContent">Linked Program Content (comma-separated)</Label>
                  <Input
                    id="linkedContent"
                    value={formData.linkedContent}
                    onChange={(e) => setFormData({ ...formData, linkedContent: e.target.value })}
                    placeholder="e.g., SOP-MED-001, POLICY-MED-SAFETY"
                  />
                </div>
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select value={formData.status} onValueChange={(value: "active" | "inactive") => setFormData({ ...formData, status: value })}>
                    <SelectTrigger id="status">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateOrUpdate}>
                  {editingTemplate ? "Update" : "Create"} Template
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4">
          {templates.map((template) => (
            <Card key={template.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <CardTitle>{template.name}</CardTitle>
                      <Badge variant={template.status === "active" ? "default" : "secondary"}>
                        {template.status}
                      </Badge>
                    </div>
                    <CardDescription>{template.description}</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => handleUseTemplate(template)}>
                      <FileText className="h-4 w-4 mr-2" />
                      Use Template
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(template)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(template.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Category:</span>
                    <p className="font-medium">{template.category.replace(/_/g, " ")}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Department:</span>
                    <p className="font-medium">{template.department?.replace(/_/g, " ") || "—"}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Linked Content:</span>
                    <p className="font-medium">{template.linkedContent.length} items</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Created:</span>
                    <p className="font-medium">{template.createdAt}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
