import { Button } from "@/components/ui/button";
import { ArrowLeft, Download, Printer } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";

export default function PRDDocument() {
  const handleDownloadPDF = () => {
    toast.info("Opening print dialog - select 'Save as PDF' to download");
    window.print();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header - Hidden when printing */}
      <header className="border-b border-border bg-card print:hidden">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" asChild>
              <Link to="/">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
            <Button onClick={handleDownloadPDF}>
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
          </div>
        </div>
      </header>

      {/* PRD Content */}
      <main className="container mx-auto px-6 py-8 max-w-4xl print:max-w-none print:px-12">
        <article className="prose prose-slate dark:prose-invert max-w-none print:prose-sm">
          {/* Title Page */}
          <div className="text-center mb-12 print:mb-8">
            <h1 className="text-4xl font-bold mb-4 print:text-3xl">RiskGuard</h1>
            <h2 className="text-2xl text-muted-foreground mb-6 print:text-xl">Product Requirements Document (PRD)</h2>
            <p className="text-muted-foreground">Version 1.1 | {new Date().toLocaleDateString()}</p>
            <p className="text-muted-foreground">Healthcare Risk Management System</p>
          </div>

          <hr className="my-8" />

          {/* Table of Contents */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Table of Contents</h2>
            <ol className="list-decimal list-inside space-y-1 text-sm">
              <li>Executive Summary</li>
              <li>Product Overview</li>
              <li>Navigation & Entry Points</li>
              <li>Core Lifecycle & Workflow</li>
              <li>Feature Requirements</li>
              <li>Data Model</li>
              <li>User Roles & Permissions</li>
              <li>Technical Requirements</li>
              <li>Security & Compliance</li>
              <li>Version History & Changelog</li>
            </ol>
          </section>

          <hr className="my-8 print:break-after-page" />

          {/* 1. Executive Summary */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">1. Executive Summary</h2>
            <p>
              RiskGuard is a comprehensive healthcare risk management microapp designed to support 
              any healthcare facility type (hospital, clinic, ASC, nursing home, home health, hospice, 
              pharmacy, lab, imaging, behavioral health, dental, etc.). The system provides a standard 
              healthcare risk reporting and management workflow supporting patient safety events, staff 
              safety, security, privacy, medication, clinical, operational, environmental, and compliance risks.
            </p>
          </section>

          {/* 2. Product Overview */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">2. Product Overview</h2>
            
            <h3 className="text-xl font-semibold mb-2">2.1 Objectives</h3>
            <ul className="list-disc list-inside space-y-1">
              <li>Standardize risk reporting across all healthcare facility types</li>
              <li>Implement a complete risk lifecycle management workflow</li>
              <li>Enable cross-application references with other healthcare microapps</li>
              <li>Provide configurable scoring, templates, and taxonomies</li>
              <li>Support regulatory compliance and audit requirements</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">2.2 Target Users</h3>
            <ul className="list-disc list-inside space-y-1">
              <li><strong>Reporters</strong>: Staff members who identify and report risks</li>
              <li><strong>Department Heads</strong>: Manage risks within their department</li>
              <li><strong>Risk/Quality Managers</strong>: Evaluate, treat, and close risks</li>
              <li><strong>Compliance Officers</strong>: Configure scoring and policies</li>
              <li><strong>Administrators</strong>: Manage system configuration</li>
            </ul>
          </section>

          {/* 3. Navigation & Entry Points */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">3. Navigation & Entry Points</h2>
            
            <h3 className="text-xl font-semibold mb-2">3.1 Main Navigation</h3>
            <p className="mb-2">The left sidebar provides access to all major application areas:</p>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li><strong>Dashboard</strong>: Overview of risk KPIs and recent activity</li>
              <li><strong>Report a Risk</strong>: Entry point for creating new risk reports</li>
              <li><strong>Risk Queue</strong>: List of all risks with filtering and search</li>
              <li><strong>Templates</strong>: Pre-configured risk intake templates</li>
              <li><strong>Program</strong>: Category-based library of SOPs, policies, and documents</li>
              <li><strong>Scoring</strong>: Risk scoring configuration settings</li>
              <li><strong>Admin Config</strong>: System configuration and taxonomies</li>
              <li><strong>PRD</strong>: This product requirements document</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">3.2 Report a Risk Entry Point</h3>
            <p className="mb-2">The "Report a Risk" page provides two options for creating new risks:</p>
            <table className="w-full text-sm border-collapse border border-border mb-4">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left">Option</th>
                  <th className="border border-border p-2 text-left">Description</th>
                  <th className="border border-border p-2 text-left">Route</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-semibold">Report Risk</td>
                  <td className="border border-border p-2">Create a new risk report from scratch with blank form</td>
                  <td className="border border-border p-2 font-mono">/report-risk</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">Use Template</td>
                  <td className="border border-border p-2">Select a pre-configured template to pre-fill risk data</td>
                  <td className="border border-border p-2 font-mono">/scenario-templates → /risks/new</td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2 mt-4">3.3 Cross-Referencing at Report Stage</h3>
            <p className="mb-2">Both reporting routes include the Cross-Reference Panel, allowing users to link related items from other microapps during initial risk creation:</p>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Available on both manual report and template-based report flows</li>
              <li>Persistent side panel visible throughout the Report Basics stage</li>
              <li>Search and link items from ComplianceConnect, EnforcePoint, FeedbackHub, AuditPro</li>
              <li>Relationship type selection required for each link</li>
              <li>Optional link notes for context</li>
            </ul>
          </section>

          {/* 4. Core Lifecycle */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">4. Core Lifecycle & Workflow</h2>
            
            <h3 className="text-xl font-semibold mb-2">4.1 Risk Stages</h3>
            <p className="mb-4">The risk lifecycle follows these sequential stages:</p>
            <div className="bg-muted p-4 rounded-lg mb-4 font-mono text-center">
              Report → Evaluate → Treat → Monitor → Reassess → Closed
            </div>

            <h3 className="text-xl font-semibold mb-2">4.2 Stage Transitions</h3>
            <ul className="list-disc list-inside space-y-1">
              <li><strong>Report</strong> → Evaluate</li>
              <li><strong>Evaluate</strong> → Treat OR Monitor OR Closed (with required closure reason + approver)</li>
              <li><strong>Treat</strong> → Monitor</li>
              <li><strong>Monitor</strong> → Reassess</li>
              <li><strong>Reassess</strong> → Treat (loop) OR Closed</li>
              <li>All stages support "Send Back" to prior stage with required reason</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">4.3 Stage Requirements</h3>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left">Stage</th>
                  <th className="border border-border p-2 text-left">Required Fields</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2">Report</td>
                  <td className="border border-border p-2">Title, Description, Category, Department</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Evaluate</td>
                  <td className="border border-border p-2">Likelihood, Impact, Readiness, Evaluation Summary</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Treat</td>
                  <td className="border border-border p-2">ROME Decision, Mitigation Plan</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Monitor</td>
                  <td className="border border-border p-2">At least one Monitoring Metric</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Reassess</td>
                  <td className="border border-border p-2">Effectiveness Review</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Closed</td>
                  <td className="border border-border p-2">Closure Reason, Closure Summary</td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 5. Feature Requirements */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">5. Feature Requirements</h2>

            <h3 className="text-xl font-semibold mb-2">5.1 New Risk Report (Report Stage)</h3>
            <p className="mb-2">Wizard or collapsible sections with the following:</p>
            
            <h4 className="font-semibold mt-4">A) Report Basics</h4>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Facility / Organization (multi-tenant)</li>
              <li>Department / Unit / Service Line</li>
              <li>Report Category (configurable taxonomy)</li>
              <li>Report Type: Near Miss / Unsafe Condition / Adverse Event / Complaint / Observation</li>
              <li>Date & Time Discovered / Occurred</li>
              <li>How identified: Staff observed / Patient reported / Family reported / Audit / Other</li>
            </ul>

            <h4 className="font-semibold mt-4">B) Event / Risk Details</h4>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Location Type: Inpatient / Outpatient / ER / OR / Pharmacy / Lab / Other</li>
              <li>Specific Location (text)</li>
              <li>Brief Title / Summary (required)</li>
              <li>Detailed Description (required)</li>
              <li>Event Classification (configurable)</li>
              <li>Witnessed? (Yes/No/Unknown)</li>
              <li>Ongoing? (Yes/No)</li>
            </ul>

            <h4 className="font-semibold mt-4">C) People Involved</h4>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Party Type: Patient / Staff / Visitor / Vendor / Unknown</li>
              <li>If Patient: masked ID, age group, sex</li>
              <li>If Staff: role, employment type</li>
              <li>Number affected</li>
            </ul>

            <h4 className="font-semibold mt-4">D) Impact & Severity</h4>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Actual Harm Level: None / Mild / Moderate / Severe / Death / Unknown</li>
              <li>Potential Harm Level: None / Mild / Moderate / Severe / Catastrophic</li>
              <li>Outcome Types (multi-select)</li>
              <li>Sentinel/Never Event suspected?</li>
            </ul>

            <h4 className="font-semibold mt-4">E) Contributing Factors</h4>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Multi-select: Communication, Training, Staffing, Policy gap, Human factors, Equipment, etc.</li>
              <li>What could prevent recurrence? (text)</li>
            </ul>

            <h4 className="font-semibold mt-4">F) Notifications & Escalation</h4>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Immediate actions taken</li>
              <li>Notified parties (Patient/Family, Provider, Supervisor, Risk/Quality, Security, Privacy)</li>
              <li>Regulatory reporting required?</li>
              <li>Escalation Priority: Routine / Urgent / Immediate</li>
            </ul>

            <h4 className="font-semibold mt-4">G) Attachments</h4>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Upload files (photos/PDF/logs) with PHI warning</li>
              <li>Evidence type + confidentiality label</li>
            </ul>

            <h4 className="font-semibold mt-4">H) Reporter</h4>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Anonymous reporting toggle (policy-controlled)</li>
              <li>Reporter identity auto-filled when not anonymous</li>
              <li>Attestation checkbox required</li>
            </ul>
          </section>

          {/* 5.2-5.5 Other Stages */}
          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-2">5.2 Evaluate Stage</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Confirm/adjust category, classification, harm levels</li>
              <li>Risk Scoring: Likelihood (1-5) × Impact (1-5) × Readiness Factor</li>
              <li>Risk Level mapping (Low/Medium/High/Critical)</li>
              <li>Role-gated override with required reason + audit</li>
              <li>Decision: Treat / Monitor / Close</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">5.3 Treat Stage</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>ROME Decision: Retain / Optimize / Mitigate / Eliminate</li>
              <li>Treatment type: CAPA / Process change / Training / Tech fix / Policy update / Other</li>
              <li>Mitigation plan with action tasks (owner + due date + status)</li>
              <li>Interim controls</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">5.4 Monitor Stage</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Monitoring metrics (name, target, frequency, data source, owner)</li>
              <li>Monitoring logs (date, note, status)</li>
              <li>Alerts for overdue tasks or missed cycles</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">5.5 Reassess Stage</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Effectiveness review with evidence</li>
              <li>Residual scoring: likelihood/impact → residual score/level</li>
              <li>Decision: back to Treat (loop) OR Close</li>
            </ul>
          </section>

          {/* 5.6 Templates */}
          <section className="mb-8 print:break-before-page">
            <h3 className="text-xl font-semibold mb-2">5.6 Risk Intake Templates</h3>
            <p className="mb-2">Pre-configured templates that prefill risk report information:</p>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Template name, description, tags</li>
              <li>Default: category, report type, location type, contributing factors</li>
              <li>Visibility scope: Private / Department / Organization</li>
              <li>Versioning with change notes</li>
              <li>Actions: Create, Use, Duplicate, Edit, Archive</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">5.7 Cross-App References</h3>
            <p className="mb-2">Link risks to records in other healthcare microapps:</p>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li><strong>ComplianceConnect</strong>: policies, controls, citations, CAPA</li>
              <li><strong>EnforcePoint</strong>: enforcement actions, investigations, notices</li>
              <li><strong>FeedbackHub</strong>: complaints, grievances, feedback</li>
              <li><strong>AuditPro</strong>: audits, findings, evidence, action plans</li>
            </ul>
            <p className="mt-2 text-sm">Relationship types: Source of Risk, Related Complaint, Related Audit Finding, Control/Policy Reference, Evidence, Mitigation/CAPA, Duplicate/Similar, Other</p>

            <h3 className="text-xl font-semibold mb-2 mt-4">5.8 Dashboard & Reporting</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>KPIs: Total risks, Open risks, Critical/High count, Closed count</li>
              <li>Risk distribution by stage and level</li>
              <li>Top categories by volume</li>
              <li>Recent risks and urgent risks lists</li>
              <li>CSV export (role-gated)</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">5.9 Program Library</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Category-based library of SOPs, policies, job aids, best practices</li>
              <li>Document management with attachments</li>
              <li>Add/edit/delete categories and documents</li>
              <li>Document metadata: title, type, owner, effective date, status</li>
            </ul>
          </section>

          {/* 6. Data Model */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">6. Data Model</h2>
            
            <h3 className="text-xl font-semibold mb-2">6.1 Core Tables</h3>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left">Table</th>
                  <th className="border border-border p-2 text-left">Key Fields</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">risk_report</td>
                  <td className="border border-border p-2">id, org_id, facility_id, department_id, status_stage, category, likelihood, impact, risk_score, risk_level, priority, assignee, created_at, closed_at</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">risk_report_people</td>
                  <td className="border border-border p-2">risk_id, party_type, age_group, role</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">risk_report_factors</td>
                  <td className="border border-border p-2">risk_id, factor_type, notes</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">risk_report_attachments</td>
                  <td className="border border-border p-2">risk_id, file_name, file_url, evidence_type, confidentiality</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">risk_report_tasks</td>
                  <td className="border border-border p-2">risk_id, stage, task_description, owner, due_date, status</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">risk_template</td>
                  <td className="border border-border p-2">id, name, description, visibility_scope, defaults, version</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">cross_app_reference</td>
                  <td className="border border-border p-2">source_app, source_record_id, target_app, target_record_id, relationship_type</td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 7. User Roles */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">7. User Roles & Permissions</h2>
            
            <h3 className="text-xl font-semibold mb-2">7.1 Role Definitions</h3>
            <table className="w-full text-sm border-collapse border border-border mb-6">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left">Role</th>
                  <th className="border border-border p-2 text-left">Capabilities</th>
                  <th className="border border-border p-2 text-left">Scope Toggle</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2">Admin</td>
                  <td className="border border-border p-2">Full access: configure scoring, manage program content, create templates, manage users</td>
                  <td className="border border-border p-2">Organization / Personal</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Compliance Head</td>
                  <td className="border border-border p-2">Configure scoring, manage program content, create templates, close risks</td>
                  <td className="border border-border p-2">Organization / Personal</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Department Head</td>
                  <td className="border border-border p-2">Same as Compliance Head but scoped to their department</td>
                  <td className="border border-border p-2">Department / Personal</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Contributor/Staff (Read-Only)</td>
                  <td className="border border-border p-2">Read-only for all system items except Risk management. Can: report risks, update evaluations/treatment/monitoring. Cannot: modify scoring, create/edit templates, program content, or admin config</td>
                  <td className="border border-border p-2">Personal only (no toggle)</td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">7.2 Scope Toggle Behavior</h3>
            <p className="text-sm mb-3">
              The scope toggle allows users to filter risk items based on their viewing context:
            </p>
            <ul className="list-disc list-inside text-sm space-y-1 mb-4">
              <li><strong>Organization</strong>: View all risks across the entire organization (Admin, Compliance Head only)</li>
              <li><strong>Department</strong>: View risks within the users assigned department (Department Head only)</li>
              <li><strong>Personal</strong>: View only risks created by or assigned to the current user</li>
            </ul>
            <p className="text-sm">
              <strong>Note:</strong> Contributor/Staff role does not have a scope toggle as they are restricted to Personal scope by default.
            </p>
          </section>

          {/* 8. Technical Requirements */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">8. Technical Requirements</h2>
            
            <h3 className="text-xl font-semibold mb-2">8.1 Technology Stack</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li><strong>Frontend</strong>: React 18, TypeScript, Vite, Tailwind CSS</li>
              <li><strong>UI Components</strong>: shadcn/ui, Radix UI primitives</li>
              <li><strong>State Management</strong>: React Query, React Hook Form</li>
              <li><strong>Backend</strong>: Lovable Cloud (Supabase)</li>
              <li><strong>Database</strong>: PostgreSQL with Row Level Security</li>
              <li><strong>Authentication</strong>: Supabase Auth (email, SSO)</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">8.2 Browser Support</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Chrome (latest 2 versions)</li>
              <li>Firefox (latest 2 versions)</li>
              <li>Safari (latest 2 versions)</li>
              <li>Edge (latest 2 versions)</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">8.3 Performance Requirements</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Page load time less than 3 seconds</li>
              <li>API response time less than 500ms</li>
              <li>Support for 1000+ concurrent users</li>
            </ul>
          </section>

          {/* 9. Security & Compliance */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">9. Security & Compliance</h2>
            
            <h3 className="text-xl font-semibold mb-2">9.1 Accessibility</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>ADA + WCAG 2.1 AA compliant</li>
              <li>Keyboard navigation support</li>
              <li>Screen reader compatible (ARIA labels)</li>
              <li>Focus management and error summaries</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">9.2 Data Security</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>PHI minimization by default</li>
              <li>Masked patient identifiers</li>
              <li>Role-based viewing of sensitive fields</li>
              <li>Secure attachments with confidentiality labels</li>
              <li>Full audit logging for edits, transitions, overrides</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">9.3 Compliance</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>HIPAA compliant data handling</li>
              <li>Configurable data retention policies</li>
              <li>Anonymous reporting with internal audit trace</li>
              <li>Regulatory reporting flags and tracking</li>
            </ul>
          </section>

          {/* 10. Version History */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">10. Version History & Changelog</h2>
            
            <h3 className="text-xl font-semibold mb-2">Version Comparison: Nov 24 → Dec 14, 2024</h3>
            <p className="text-sm mb-4 text-muted-foreground">
              The following table summarizes all changes made between the Nov 24 baseline version and the Dec 14 latest version.
            </p>

            <table className="w-full text-sm border-collapse border border-border mb-6">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-1/6">Section</th>
                  <th className="border border-border p-2 text-left w-1/4">Change Type</th>
                  <th className="border border-border p-2 text-left">Description</th>
                </tr>
              </thead>
              <tbody>
                {/* Navigation Changes */}
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 3</td>
                  <td className="border border-border p-2"><span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-0.5 rounded text-xs">NEW</span></td>
                  <td className="border border-border p-2">Added "Navigation & Entry Points" section defining main navigation structure and Report a Risk entry points</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 3.2</td>
                  <td className="border border-border p-2"><span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-0.5 rounded text-xs">NEW</span></td>
                  <td className="border border-border p-2">Documented two-route risk reporting: "Report Risk" (manual) and "Use Template" (template-based)</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 3.3</td>
                  <td className="border border-border p-2"><span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-0.5 rounded text-xs">NEW</span></td>
                  <td className="border border-border p-2">Added Cross-Referencing at Report Stage documentation for linking items from other microapps</td>
                </tr>

                {/* Workflow Changes */}
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 4.2</td>
                  <td className="border border-border p-2"><span className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-0.5 rounded text-xs">ENHANCED</span></td>
                  <td className="border border-border p-2">Added "Send Back" transition capability with required reason for all stages</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 4.3</td>
                  <td className="border border-border p-2"><span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-0.5 rounded text-xs">NEW</span></td>
                  <td className="border border-border p-2">Added Stage Requirements table documenting required fields for each workflow stage</td>
                </tr>

                {/* Feature Changes */}
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 5.1</td>
                  <td className="border border-border p-2"><span className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-0.5 rounded text-xs">ENHANCED</span></td>
                  <td className="border border-border p-2">Expanded New Risk Report form structure with 8 detailed sections (A-H) including PHI handling and attestation</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 5.6</td>
                  <td className="border border-border p-2"><span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-0.5 rounded text-xs">NEW</span></td>
                  <td className="border border-border p-2">Added Risk Intake Templates feature with versioning, visibility scope, and template actions</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 5.7</td>
                  <td className="border border-border p-2"><span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-0.5 rounded text-xs">NEW</span></td>
                  <td className="border border-border p-2">Added Cross-App References feature linking to ComplianceConnect, EnforcePoint, FeedbackHub, AuditPro</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 5.8</td>
                  <td className="border border-border p-2"><span className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-0.5 rounded text-xs">ENHANCED</span></td>
                  <td className="border border-border p-2">Enhanced Dashboard KPIs with risk distribution visualizations and CSV export capability</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 5.9</td>
                  <td className="border border-border p-2"><span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-0.5 rounded text-xs">NEW</span></td>
                  <td className="border border-border p-2">Added Program Library feature for SOPs, policies, and document management</td>
                </tr>

                {/* Data Model Changes */}
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 6.1</td>
                  <td className="border border-border p-2"><span className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-0.5 rounded text-xs">ENHANCED</span></td>
                  <td className="border border-border p-2">Added new tables: risk_template, cross_app_reference; expanded risk_report fields</td>
                </tr>

                {/* User Roles Changes */}
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 7.1</td>
                  <td className="border border-border p-2"><span className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-0.5 rounded text-xs">ENHANCED</span></td>
                  <td className="border border-border p-2">Added Scope Toggle column to Role Definitions table</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 7.2</td>
                  <td className="border border-border p-2"><span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-0.5 rounded text-xs">NEW</span></td>
                  <td className="border border-border p-2">Added Scope Toggle Behavior documentation: Organization/Department/Personal filtering by role</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 7</td>
                  <td className="border border-border p-2"><span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-0.5 rounded text-xs">NEW</span></td>
                  <td className="border border-border p-2">Added mock role switcher for testing: Admin, Compliance Head, Department Head, Staff roles</td>
                </tr>

                {/* Technical Changes */}
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 8.1</td>
                  <td className="border border-border p-2"><span className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-0.5 rounded text-xs">ENHANCED</span></td>
                  <td className="border border-border p-2">Updated technology stack to include React Query, React Hook Form, Lovable Cloud backend</td>
                </tr>

                {/* Security Changes */}
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 9.2</td>
                  <td className="border border-border p-2"><span className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-0.5 rounded text-xs">ENHANCED</span></td>
                  <td className="border border-border p-2">Added masked patient identifiers and role-based viewing of sensitive fields</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">Section 9.3</td>
                  <td className="border border-border p-2"><span className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-0.5 rounded text-xs">ENHANCED</span></td>
                  <td className="border border-border p-2">Added anonymous reporting with internal audit trace and regulatory reporting flags</td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2 mt-6">Change Summary</h3>
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-green-700 dark:text-green-300">10</p>
                <p className="text-sm text-green-600 dark:text-green-400">New Features</p>
              </div>
              <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-blue-700 dark:text-blue-300">8</p>
                <p className="text-sm text-blue-600 dark:text-blue-400">Enhancements</p>
              </div>
              <div className="bg-muted border border-border rounded-lg p-4 text-center">
                <p className="text-2xl font-bold">18</p>
                <p className="text-sm text-muted-foreground">Total Changes</p>
              </div>
            </div>

            <h3 className="text-xl font-semibold mb-2 mt-6">Key Highlights (Dec 14 Release)</h3>
            <ul className="list-disc list-inside text-sm space-y-2">
              <li><strong>Scope Toggle</strong>: Role-based filtering (Organization/Department/Personal) for Admin, Compliance Head, and Department Head roles</li>
              <li><strong>Cross-App References</strong>: Link risks to records in ComplianceConnect, EnforcePoint, FeedbackHub, and AuditPro</li>
              <li><strong>Risk Intake Templates</strong>: Pre-configured templates with versioning, visibility scope, and template actions</li>
              <li><strong>Program Library</strong>: Category-based document management for SOPs, policies, and best practices</li>
              <li><strong>Enhanced Navigation</strong>: Two-route risk reporting with manual and template-based options</li>
              <li><strong>Mock Role Switcher</strong>: Testing capability to switch between Admin, Compliance Head, Department Head, and Staff roles</li>
            </ul>
          </section>

          {/* Footer */}
          <hr className="my-8" />
          <footer className="text-center text-sm text-muted-foreground">
            <p>RiskGuard PRD v1.1 | Dec 14, 2024</p>
            <p>Previous Version: v1.0 | Nov 24, 2024</p>
            <p className="mt-2">© {new Date().getFullYear()} Healthcare Risk Management System</p>
          </footer>
        </article>
      </main>

      {/* Print Styles */}
      <style>{`
        @media print {
          body { 
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          .print\\:hidden { display: none !important; }
          .print\\:break-before-page { break-before: page; }
          .print\\:break-after-page { break-after: page; }
          @page { margin: 1in; }
        }
      `}</style>
    </div>
  );
}
