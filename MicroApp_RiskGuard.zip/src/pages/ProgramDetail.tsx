import { Shield, FileText, Download, Edit, Plus, ArrowLeft, Trash2, Upload, Paperclip, X, MoreHorizontal, Eye } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useState } from "react";
import { toast } from "sonner";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Attachment {
  id: string;
  name: string;
  size: string;
  type: string;
}

interface Document {
  id: string;
  title: string;
  type: string;
  owner: string;
  effectiveDate: string;
  lastReviewed: string;
  status: string;
  attachments?: Attachment[];
}

const initialDocuments: Document[] = [
  {
    id: "1",
    title: "Fall Risk Assessment Protocol",
    type: "SOP",
    owner: "Nursing Director",
    effectiveDate: "2024-01-15",
    lastReviewed: "2024-01-15",
    status: "Active",
  },
  {
    id: "2",
    title: "Post-Fall Response Procedure",
    type: "Policy",
    owner: "Quality Manager",
    effectiveDate: "2024-02-01",
    lastReviewed: "2024-02-01",
    status: "Active",
  },
  {
    id: "3",
    title: "Environmental Safety Checklist",
    type: "Job Aid",
    owner: "Facilities Manager",
    effectiveDate: "2024-01-10",
    lastReviewed: "2024-01-10",
    status: "Active",
  },
  {
    id: "4",
    title: "Fall Prevention Best Practices",
    type: "Reference",
    owner: "Clinical Lead",
    effectiveDate: "2023-12-15",
    lastReviewed: "2024-03-15",
    status: "Under Review",
  },
];

const categoryNames: Record<string, string> = {
  falls: "Falls Prevention",
  medication: "Medication Safety",
  infection: "Infection Control",
  abuse: "Abuse & Neglect",
  emergency: "Emergency Preparedness",
  billing: "Billing Integrity",
};

const ProgramDetail = () => {
  const { categoryId } = useParams();
  const [documents, setDocuments] = useState<Document[]>(initialDocuments);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<Document | null>(null);
  const [newDoc, setNewDoc] = useState({
    title: "",
    type: "Policy",
    owner: "",
    effectiveDate: new Date().toISOString().split('T')[0],
  });
  const [editDoc, setEditDoc] = useState({
    title: "",
    type: "Policy",
    owner: "",
    effectiveDate: "",
    status: "Active",
  });
  const [attachments, setAttachments] = useState<Attachment[]>([]);

  const categoryName = categoryId ? categoryNames[categoryId] || categoryId : "Category";

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    
    const newAttachments: Attachment[] = Array.from(files).map(file => ({
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      name: file.name,
      size: formatFileSize(file.size),
      type: file.type || 'application/octet-stream',
    }));
    
    setAttachments([...attachments, ...newAttachments]);
    e.target.value = ''; // Reset input
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const removeAttachment = (id: string) => {
    setAttachments(attachments.filter(a => a.id !== id));
  };

  const handleAddDocument = () => {
    if (!newDoc.title || !newDoc.owner) {
      toast.error("Please fill in all required fields");
      return;
    }

    const doc: Document = {
      id: Date.now().toString(),
      title: newDoc.title,
      type: newDoc.type,
      owner: newDoc.owner,
      effectiveDate: newDoc.effectiveDate,
      lastReviewed: newDoc.effectiveDate,
      status: "Active",
      attachments: attachments.length > 0 ? [...attachments] : undefined,
    };

    setDocuments([...documents, doc]);
    setNewDoc({
      title: "",
      type: "Policy",
      owner: "",
      effectiveDate: new Date().toISOString().split('T')[0],
    });
    setAttachments([]);
    setIsDialogOpen(false);
    toast.success("Document added successfully");
  };

  const handleDeleteDocument = (id: string) => {
    setDocuments(documents.filter(d => d.id !== id));
    toast.success("Document removed");
  };

  const handleViewDocument = (doc: Document) => {
    setSelectedDoc(doc);
    setIsViewDialogOpen(true);
  };

  const handleEditDocument = (doc: Document) => {
    setSelectedDoc(doc);
    setEditDoc({
      title: doc.title,
      type: doc.type,
      owner: doc.owner,
      effectiveDate: doc.effectiveDate,
      status: doc.status,
    });
    setIsEditDialogOpen(true);
  };

  const handleSaveEdit = () => {
    if (!selectedDoc || !editDoc.title || !editDoc.owner) {
      toast.error("Please fill in all required fields");
      return;
    }

    setDocuments(documents.map(d => 
      d.id === selectedDoc.id 
        ? { 
            ...d, 
            title: editDoc.title,
            type: editDoc.type,
            owner: editDoc.owner,
            effectiveDate: editDoc.effectiveDate,
            status: editDoc.status,
            lastReviewed: new Date().toISOString().split('T')[0],
          }
        : d
    ));
    setIsEditDialogOpen(false);
    setSelectedDoc(null);
    toast.success("Document updated successfully");
  };

  const handleDownloadDocument = (doc: Document) => {
    // In a real app, this would download the actual file
    toast.success(`Downloading "${doc.title}"...`);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">RiskGuard</h1>
            </Link>
            <div className="flex gap-2">
              <Button variant="outline" asChild>
                <Link to="/program">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Program
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Page Header */}
      <section className="bg-gradient-to-br from-primary/5 to-secondary/5 border-b border-border">
        <div className="container mx-auto px-6 py-8">
          <div className="flex items-center justify-between">
            <div>
              <Badge variant="outline" className="mb-3">
                Risk Category
              </Badge>
              <h2 className="text-3xl font-bold text-foreground mb-2">
                {categoryName}
              </h2>
              <p className="text-muted-foreground">
                Policies and procedures for {categoryName.toLowerCase()}
              </p>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  Add Document
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Document</DialogTitle>
                  <DialogDescription>
                    Add a policy, SOP, job aid, or reference document to this category.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="doc-title">Document Title *</Label>
                    <Input
                      id="doc-title"
                      placeholder="e.g., Infection Control Policy"
                      value={newDoc.title}
                      onChange={(e) => setNewDoc({ ...newDoc, title: e.target.value })}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="doc-type">Document Type</Label>
                      <Select value={newDoc.type} onValueChange={(v) => setNewDoc({ ...newDoc, type: v })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Policy">Policy</SelectItem>
                          <SelectItem value="SOP">SOP</SelectItem>
                          <SelectItem value="Procedure">Procedure</SelectItem>
                          <SelectItem value="Job Aid">Job Aid</SelectItem>
                          <SelectItem value="Reference">Reference</SelectItem>
                          <SelectItem value="Form">Form</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="doc-date">Effective Date</Label>
                      <Input
                        id="doc-date"
                        type="date"
                        value={newDoc.effectiveDate}
                        onChange={(e) => setNewDoc({ ...newDoc, effectiveDate: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="doc-owner">Document Owner *</Label>
                    <Input
                      id="doc-owner"
                      placeholder="e.g., Nursing Director"
                      value={newDoc.owner}
                      onChange={(e) => setNewDoc({ ...newDoc, owner: e.target.value })}
                    />
                  </div>
                  
                  {/* Attachments Section */}
                  <div className="space-y-2">
                    <Label>Attachments</Label>
                    <div className="border border-dashed border-border rounded-lg p-4">
                      <input
                        type="file"
                        id="file-upload"
                        className="hidden"
                        multiple
                        accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.jpg,.jpeg,.png"
                        onChange={handleFileChange}
                      />
                      <label
                        htmlFor="file-upload"
                        className="flex flex-col items-center justify-center cursor-pointer py-2"
                      >
                        <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                        <span className="text-sm font-medium text-foreground">Click to upload files</span>
                        <span className="text-xs text-muted-foreground mt-1">PDF, Word, Excel, PowerPoint, Images</span>
                      </label>
                    </div>
                    
                    {attachments.length > 0 && (
                      <div className="space-y-2 mt-3">
                        {attachments.map(attachment => (
                          <div 
                            key={attachment.id}
                            className="flex items-center justify-between p-2 bg-muted/50 rounded-md"
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <Paperclip className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                              <span className="text-sm truncate">{attachment.name}</span>
                              <span className="text-xs text-muted-foreground flex-shrink-0">({attachment.size})</span>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 flex-shrink-0"
                              onClick={() => removeAttachment(attachment.id)}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex justify-end gap-3">
                  <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddDocument}>
                    Add Document
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </section>

      {/* Documents Table */}
      <section className="container mx-auto px-6 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Program Documents</CardTitle>
            <CardDescription>
              SOPs, policies, job aids, and references for this category
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Owner</TableHead>
                  <TableHead>Effective Date</TableHead>
                  <TableHead>Last Reviewed</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {documents.map((doc) => (
                  <TableRow key={doc.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        {doc.title}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{doc.type}</Badge>
                    </TableCell>
                    <TableCell>{doc.owner}</TableCell>
                    <TableCell>{doc.effectiveDate}</TableCell>
                    <TableCell>{doc.lastReviewed}</TableCell>
                    <TableCell>
                      <Badge
                        variant={doc.status === "Active" ? "default" : "secondary"}
                      >
                        {doc.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-popover">
                          <DropdownMenuItem onClick={() => handleViewDocument(doc)}>
                            <Eye className="h-4 w-4 mr-2" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDownloadDocument(doc)}>
                            <Download className="h-4 w-4 mr-2" />
                            Download
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleEditDocument(doc)}>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem 
                            onClick={() => handleDeleteDocument(doc.id)}
                            className="text-destructive focus:text-destructive"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </section>

      {/* View Document Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Document Details</DialogTitle>
          </DialogHeader>
          {selectedDoc && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground text-xs">Title</Label>
                  <p className="font-medium">{selectedDoc.title}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground text-xs">Type</Label>
                  <p><Badge variant="outline">{selectedDoc.type}</Badge></p>
                </div>
                <div>
                  <Label className="text-muted-foreground text-xs">Owner</Label>
                  <p>{selectedDoc.owner}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground text-xs">Status</Label>
                  <p><Badge variant={selectedDoc.status === "Active" ? "default" : "secondary"}>{selectedDoc.status}</Badge></p>
                </div>
                <div>
                  <Label className="text-muted-foreground text-xs">Effective Date</Label>
                  <p>{selectedDoc.effectiveDate}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground text-xs">Last Reviewed</Label>
                  <p>{selectedDoc.lastReviewed}</p>
                </div>
              </div>
              {/* Attachments Section */}
              <div>
                <Label className="text-muted-foreground text-xs">Attachments ({selectedDoc.attachments?.length || 0})</Label>
                {selectedDoc.attachments && selectedDoc.attachments.length > 0 ? (
                  <div className="mt-2 space-y-2">
                    {selectedDoc.attachments.map(att => (
                      <div key={att.id} className="flex items-center justify-between p-2 bg-muted/50 rounded">
                        <div className="flex items-center gap-2 min-w-0">
                          <Paperclip className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                          <span className="text-sm truncate">{att.name}</span>
                          <span className="text-xs text-muted-foreground flex-shrink-0">({att.size})</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            toast.success(`Downloading "${att.name}"...`);
                          }}
                          title="Download attachment"
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground mt-2">No attachments</p>
                )}
              </div>
            </div>
          )}
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
              Close
            </Button>
            <Button onClick={() => {
              setIsViewDialogOpen(false);
              if (selectedDoc) handleEditDocument(selectedDoc);
            }}>
              <Edit className="h-4 w-4 mr-2" />
              Edit
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Document Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Document</DialogTitle>
            <DialogDescription>
              Update the document details below.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-title">Document Title *</Label>
              <Input
                id="edit-title"
                value={editDoc.title}
                onChange={(e) => setEditDoc({ ...editDoc, title: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-type">Document Type</Label>
                <Select value={editDoc.type} onValueChange={(v) => setEditDoc({ ...editDoc, type: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Policy">Policy</SelectItem>
                    <SelectItem value="SOP">SOP</SelectItem>
                    <SelectItem value="Procedure">Procedure</SelectItem>
                    <SelectItem value="Job Aid">Job Aid</SelectItem>
                    <SelectItem value="Reference">Reference</SelectItem>
                    <SelectItem value="Form">Form</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-status">Status</Label>
                <Select value={editDoc.status} onValueChange={(v) => setEditDoc({ ...editDoc, status: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Under Review">Under Review</SelectItem>
                    <SelectItem value="Archived">Archived</SelectItem>
                  </SelectContent>
                </Select>
            </div>
            
            {/* Attachments in Edit */}
            <div className="space-y-2">
              <Label>Attachments ({selectedDoc?.attachments?.length || 0})</Label>
              {selectedDoc?.attachments && selectedDoc.attachments.length > 0 ? (
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {selectedDoc.attachments.map(att => (
                    <div key={att.id} className="flex items-center justify-between p-2 bg-muted/50 rounded">
                      <div className="flex items-center gap-2 min-w-0">
                        <Paperclip className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="text-sm truncate">{att.name}</span>
                        <span className="text-xs text-muted-foreground flex-shrink-0">({att.size})</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          toast.success(`Downloading "${att.name}"...`);
                        }}
                        title="Download"
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No attachments</p>
              )}
            </div>
          </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-owner">Document Owner *</Label>
                <Input
                  id="edit-owner"
                  value={editDoc.owner}
                  onChange={(e) => setEditDoc({ ...editDoc, owner: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-date">Effective Date</Label>
                <Input
                  id="edit-date"
                  type="date"
                  value={editDoc.effectiveDate}
                  onChange={(e) => setEditDoc({ ...editDoc, effectiveDate: e.target.value })}
                />
              </div>
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveEdit}>
              Save Changes
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProgramDetail;
