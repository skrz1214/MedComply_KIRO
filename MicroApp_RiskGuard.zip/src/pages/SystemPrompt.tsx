import { Button } from "@/components/ui/button";
import { ArrowLeft, Download } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";

export default function SystemPrompt() {
  const handleDownloadPDF = () => {
    toast.info("Opening print dialog - select 'Save as PDF' to download");
    window.print();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header - Hidden when printing */}
      <header className="border-b border-border bg-card print:hidden">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" asChild>
              <Link to="/">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
            <Button onClick={handleDownloadPDF}>
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
          </div>
        </div>
      </header>

      {/* System Prompt Content */}
      <main className="container mx-auto px-6 py-8 max-w-5xl print:max-w-none print:px-12">
        <article className="prose prose-slate dark:prose-invert max-w-none print:prose-sm">
          {/* Title Page */}
          <div className="text-center mb-12 print:mb-8">
            <h1 className="text-4xl font-bold mb-4 print:text-3xl">RiskGuard</h1>
            <h2 className="text-2xl text-muted-foreground mb-6 print:text-xl">System Prompt Document</h2>
            <p className="text-muted-foreground">Version 1.0 | {new Date().toLocaleDateString()}</p>
            <p className="text-muted-foreground">AI Agent Configuration for Healthcare Risk Management</p>
          </div>

          <hr className="my-8" />

          {/* Table of Contents */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Table of Contents</h2>
            <ol className="list-decimal list-inside space-y-1 text-sm">
              <li>System Identity & Role</li>
              <li>Application Overview</li>
              <li>Navigation Structure</li>
              <li>Core Workflow & Lifecycle</li>
              <li>Feature Modules</li>
              <li>User Roles & Permissions</li>
              <li>Data Model & Entities</li>
              <li>Cross-Application Integration</li>
              <li>Security & Compliance</li>
              <li>Response Guidelines</li>
              <li>Error Handling</li>
            </ol>
          </section>

          <hr className="my-8 print:break-after-page" />

          {/* 1. System Identity */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">1. System Identity & Role</h2>
            <div className="bg-muted p-4 rounded-lg mb-4 font-mono text-sm">
              <pre className="whitespace-pre-wrap">{`You are RiskGuard AI, an intelligent assistant for a healthcare risk management system. Your primary function is to help healthcare professionals report, evaluate, treat, monitor, and reassess risks across all facility types including hospitals, clinics, ASCs, nursing homes, home health, hospice, pharmacies, labs, imaging centers, behavioral health, and dental facilities.

You support the complete risk management lifecycle and assist with:
- Risk intake and reporting
- Risk evaluation and scoring
- Treatment planning and mitigation
- Monitoring and metrics tracking
- Reassessment and closure
- Template management
- Cross-application references
- Dashboard analytics and reporting`}</pre>
            </div>
          </section>

          {/* 2. Application Overview */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">2. Application Overview</h2>
            
            <h3 className="text-xl font-semibold mb-2">2.1 Purpose</h3>
            <p className="mb-4">
              RiskGuard is a comprehensive healthcare risk management microapp designed to standardize risk reporting and management workflows. It supports patient safety events, staff safety, security, privacy, medication, clinical, operational, environmental, and compliance risks.
            </p>

            <h3 className="text-xl font-semibold mb-2">2.2 Target Users</h3>
            <table className="w-full text-sm border-collapse border border-border mb-4">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left">User Type</th>
                  <th className="border border-border p-2 text-left">Primary Functions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2">Reporters</td>
                  <td className="border border-border p-2">Staff members who identify and report risks</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Department Heads</td>
                  <td className="border border-border p-2">Manage risks within their department</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Risk/Quality Managers</td>
                  <td className="border border-border p-2">Evaluate, treat, and close risks</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Compliance Officers</td>
                  <td className="border border-border p-2">Configure scoring and policies</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Administrators</td>
                  <td className="border border-border p-2">Manage system configuration</td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">2.3 Technology Stack</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li><strong>Frontend</strong>: React 18, TypeScript, Vite, Tailwind CSS</li>
              <li><strong>UI Components</strong>: shadcn/ui, Radix UI primitives</li>
              <li><strong>State Management</strong>: React Query, React Hook Form</li>
              <li><strong>Backend</strong>: Lovable Cloud (Supabase)</li>
              <li><strong>Database</strong>: PostgreSQL with Row Level Security</li>
              <li><strong>Authentication</strong>: Supabase Auth (email, SSO)</li>
            </ul>
          </section>

          {/* 3. Navigation Structure */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">3. Navigation Structure</h2>
            
            <h3 className="text-xl font-semibold mb-2">3.1 Main Navigation Menu</h3>
            <table className="w-full text-sm border-collapse border border-border mb-4">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left">Menu Item</th>
                  <th className="border border-border p-2 text-left">Route</th>
                  <th className="border border-border p-2 text-left">Description</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2">Dashboard</td>
                  <td className="border border-border p-2 font-mono">/</td>
                  <td className="border border-border p-2">Overview of risk KPIs, charts, and recent activity</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Report a Risk</td>
                  <td className="border border-border p-2 font-mono">/process</td>
                  <td className="border border-border p-2">Entry point for creating new risk reports</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Risk Queue</td>
                  <td className="border border-border p-2 font-mono">/risks</td>
                  <td className="border border-border p-2">List of all risks with filtering and search</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Templates</td>
                  <td className="border border-border p-2 font-mono">/scenario-templates</td>
                  <td className="border border-border p-2">Pre-configured risk intake templates</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Program</td>
                  <td className="border border-border p-2 font-mono">/program</td>
                  <td className="border border-border p-2">Category-based library of SOPs, policies, documents</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Scoring</td>
                  <td className="border border-border p-2 font-mono">/scoring-settings</td>
                  <td className="border border-border p-2">Risk scoring configuration settings</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Admin Config</td>
                  <td className="border border-border p-2 font-mono">/admin</td>
                  <td className="border border-border p-2">System configuration and taxonomies</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">PRD</td>
                  <td className="border border-border p-2 font-mono">/prd</td>
                  <td className="border border-border p-2">Product Requirements Document</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">QA Test Cases</td>
                  <td className="border border-border p-2 font-mono">/qa-test-cases</td>
                  <td className="border border-border p-2">Quality Assurance test case documentation</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">UAT Test Cases</td>
                  <td className="border border-border p-2 font-mono">/uat-test-cases</td>
                  <td className="border border-border p-2">User Acceptance Testing scenarios</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">System Prompt</td>
                  <td className="border border-border p-2 font-mono">/system-prompt</td>
                  <td className="border border-border p-2">AI agent configuration documentation</td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">3.2 Report a Risk Entry Points</h3>
            <p className="mb-2">The "Report a Risk" page provides two options:</p>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li><strong>Report Risk</strong> (/report-risk): Create a new risk report from scratch with blank form</li>
              <li><strong>Use Template</strong> (/scenario-templates): Select a pre-configured template to pre-fill risk data</li>
            </ul>
          </section>

          {/* 4. Core Workflow */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">4. Core Workflow & Lifecycle</h2>
            
            <h3 className="text-xl font-semibold mb-2">4.1 Risk Lifecycle Stages</h3>
            <div className="bg-muted p-4 rounded-lg mb-4 font-mono text-center text-lg">
              Report → Evaluate → Treat → Monitor → Reassess → Closed
            </div>

            <h3 className="text-xl font-semibold mb-2">4.2 Stage Transitions</h3>
            <table className="w-full text-sm border-collapse border border-border mb-4">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left">From Stage</th>
                  <th className="border border-border p-2 text-left">Allowed Transitions</th>
                  <th className="border border-border p-2 text-left">Notes</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2">Report</td>
                  <td className="border border-border p-2">→ Evaluate</td>
                  <td className="border border-border p-2">Initial submission complete</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Evaluate</td>
                  <td className="border border-border p-2">→ Treat, → Monitor, → Closed</td>
                  <td className="border border-border p-2">Close requires reason + approver</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Treat</td>
                  <td className="border border-border p-2">→ Monitor</td>
                  <td className="border border-border p-2">Treatment plan defined</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Monitor</td>
                  <td className="border border-border p-2">→ Reassess</td>
                  <td className="border border-border p-2">Monitoring metrics established</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Reassess</td>
                  <td className="border border-border p-2">→ Treat (loop), → Closed</td>
                  <td className="border border-border p-2">Effectiveness review complete</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">All Stages</td>
                  <td className="border border-border p-2">← Send Back (prior stage)</td>
                  <td className="border border-border p-2">Required reason for send back</td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">4.3 Stage Required Fields</h3>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left">Stage</th>
                  <th className="border border-border p-2 text-left">Required Fields</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2">Report</td>
                  <td className="border border-border p-2">Title, Description, Category, Department</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Evaluate</td>
                  <td className="border border-border p-2">Likelihood (1-5), Impact (1-5), Readiness, Evaluation Summary</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Treat</td>
                  <td className="border border-border p-2">ROME Decision (Retain/Optimize/Mitigate/Eliminate), Mitigation Plan</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Monitor</td>
                  <td className="border border-border p-2">At least one Monitoring Metric</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Reassess</td>
                  <td className="border border-border p-2">Effectiveness Review</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Closed</td>
                  <td className="border border-border p-2">Closure Reason, Closure Summary</td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 5. Feature Modules */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">5. Feature Modules</h2>

            <h3 className="text-xl font-semibold mb-2">5.1 Risk Report Form (Report Stage)</h3>
            <div className="bg-muted p-4 rounded-lg mb-4 text-sm">
              <p className="font-semibold mb-2">Form Sections:</p>
              <ul className="list-disc list-inside space-y-1">
                <li><strong>A) Report Basics</strong>: Facility, Department, Category, Report Type, Date/Time, How Identified</li>
                <li><strong>B) Event/Risk Details</strong>: Location Type, Specific Location, Title, Description, Classification, Witnessed, Ongoing</li>
                <li><strong>C) People Involved</strong>: Party Type (Patient/Staff/Visitor/Vendor), Demographics, Number Affected</li>
                <li><strong>D) Impact & Severity</strong>: Actual Harm Level, Potential Harm Level, Outcome Types, Sentinel Event Flag</li>
                <li><strong>E) Contributing Factors</strong>: Multi-select factors, Prevention suggestions</li>
                <li><strong>F) Notifications & Escalation</strong>: Immediate actions, Notified parties, Regulatory reporting, Priority</li>
                <li><strong>G) Attachments</strong>: File uploads with PHI warning, Evidence type, Confidentiality label</li>
                <li><strong>H) Reporter</strong>: Anonymous toggle, Identity auto-fill, Attestation checkbox</li>
              </ul>
            </div>

            <h3 className="text-xl font-semibold mb-2">5.2 Evaluate Stage</h3>
            <ul className="list-disc list-inside text-sm space-y-1 mb-4">
              <li>Confirm/adjust category, classification, harm levels</li>
              <li>Risk Scoring: Likelihood (1-5) × Impact (1-5) × Readiness Factor</li>
              <li>Risk Level mapping: Low (1-6), Medium (7-12), High (13-18), Critical (19-25)</li>
              <li>Role-gated override with required reason + audit trail</li>
              <li>Decision: Treat / Monitor / Close</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2">5.3 Treat Stage</h3>
            <ul className="list-disc list-inside text-sm space-y-1 mb-4">
              <li>ROME Decision: Retain / Optimize / Mitigate / Eliminate</li>
              <li>Treatment types: CAPA, Process change, Training, Tech fix, Policy update, Other</li>
              <li>Mitigation plan with action tasks (owner, due date, status)</li>
              <li>Interim controls documentation</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2">5.4 Monitor Stage</h3>
            <ul className="list-disc list-inside text-sm space-y-1 mb-4">
              <li>Monitoring metrics: name, target, frequency, data source, owner</li>
              <li>Monitoring logs: date, note, status</li>
              <li>Alerts for overdue tasks or missed monitoring cycles</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2">5.5 Reassess Stage</h3>
            <ul className="list-disc list-inside text-sm space-y-1 mb-4">
              <li>Effectiveness review with evidence</li>
              <li>Residual scoring: revised likelihood/impact → residual score/level</li>
              <li>Decision: return to Treat (loop) OR Close</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2">5.6 Template Library</h3>
            <ul className="list-disc list-inside text-sm space-y-1 mb-4">
              <li>Template attributes: name, description, tags</li>
              <li>Default values: category, report type, location type, contributing factors</li>
              <li>Visibility scope: Private / Department / Organization</li>
              <li>Versioning with change notes</li>
              <li>Actions: Create, Use, Duplicate, Edit, Archive</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2">5.7 Program Library</h3>
            <ul className="list-disc list-inside text-sm space-y-1 mb-4">
              <li>Category-based organization of SOPs, policies, job aids, best practices</li>
              <li>Document metadata: title, type, owner, effective date, status</li>
              <li>File attachments support</li>
              <li>Add/edit/delete categories and documents</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2">5.8 Dashboard</h3>
            <ul className="list-disc list-inside text-sm space-y-1 mb-4">
              <li>KPI Cards: Total Risks, Open Risks, Critical/High count, Closed count</li>
              <li>Risk distribution by stage (Report/Evaluate/Treat/Monitor/Reassess/Closed)</li>
              <li>Risk distribution by level (Low/Medium/High/Critical)</li>
              <li>Top categories by volume</li>
              <li>Recent risks and urgent risks lists</li>
              <li>Scope toggle for filtering (Organization/Department/Personal)</li>
              <li>CSV export (role-gated)</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2">5.9 Scoring Configuration</h3>
            <ul className="list-disc list-inside text-sm space-y-1 mb-4">
              <li>Likelihood scale definitions (1-5)</li>
              <li>Impact scale definitions (1-5)</li>
              <li>Readiness factor configuration</li>
              <li>Risk level thresholds (Low/Medium/High/Critical)</li>
              <li>Color coding settings</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2">5.10 Admin Configuration</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Category taxonomy management</li>
              <li>Classification options</li>
              <li>Location types</li>
              <li>Contributing factor options</li>
              <li>System-wide settings</li>
            </ul>
          </section>

          {/* 6. User Roles */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">6. User Roles & Permissions</h2>
            
            <h3 className="text-xl font-semibold mb-2">6.1 Role Definitions</h3>
            <table className="w-full text-sm border-collapse border border-border mb-4">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left">Role</th>
                  <th className="border border-border p-2 text-left">Capabilities</th>
                  <th className="border border-border p-2 text-left">Scope Toggle</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-semibold">Admin</td>
                  <td className="border border-border p-2">Full access: configure scoring, manage program content, create templates, manage users, all CRUD operations</td>
                  <td className="border border-border p-2">Organization / Personal</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">Compliance Head</td>
                  <td className="border border-border p-2">Configure scoring, manage program content, create templates, close risks, approve overrides</td>
                  <td className="border border-border p-2">Organization / Personal</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">Department Head</td>
                  <td className="border border-border p-2">Same as Compliance Head but scoped to their department only</td>
                  <td className="border border-border p-2">Department / Personal</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">Contributor/Staff</td>
                  <td className="border border-border p-2">Read-only for system items. Can: report risks, update evaluations/treatment/monitoring. Cannot: modify scoring, create templates, edit program content, access admin config</td>
                  <td className="border border-border p-2">Personal only</td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">6.2 Scope Toggle Behavior</h3>
            <div className="bg-muted p-4 rounded-lg mb-4 text-sm">
              <ul className="list-disc list-inside space-y-1">
                <li><strong>Organization</strong>: View all risks across the entire organization (Admin, Compliance Head only)</li>
                <li><strong>Department</strong>: View risks within user's assigned department (Department Head only)</li>
                <li><strong>Personal</strong>: View only risks created by or assigned to current user</li>
              </ul>
              <p className="mt-2 text-muted-foreground">Note: Contributor/Staff role does not have scope toggle - restricted to Personal scope.</p>
            </div>

            <h3 className="text-xl font-semibold mb-2">6.3 Permission Matrix</h3>
            <table className="w-full text-xs border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left">Feature</th>
                  <th className="border border-border p-2 text-center">Admin</th>
                  <th className="border border-border p-2 text-center">Compliance</th>
                  <th className="border border-border p-2 text-center">Dept Head</th>
                  <th className="border border-border p-2 text-center">Staff</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2">Report Risks</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Evaluate/Treat/Monitor</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Close Risks</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓*</td>
                  <td className="border border-border p-2 text-center">✗</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Scoring Config</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✗</td>
                  <td className="border border-border p-2 text-center">✗</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Templates (Create/Edit)</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓*</td>
                  <td className="border border-border p-2 text-center">✗</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Program Content</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓*</td>
                  <td className="border border-border p-2 text-center">Read</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Admin Config</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✗</td>
                  <td className="border border-border p-2 text-center">✗</td>
                  <td className="border border-border p-2 text-center">✗</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">CSV Export</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓</td>
                  <td className="border border-border p-2 text-center">✓*</td>
                  <td className="border border-border p-2 text-center">✗</td>
                </tr>
              </tbody>
            </table>
            <p className="text-xs text-muted-foreground mt-2">* Department scope only</p>
          </section>

          {/* 7. Data Model */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">7. Data Model & Entities</h2>
            
            <h3 className="text-xl font-semibold mb-2">7.1 Core Entities</h3>
            <table className="w-full text-sm border-collapse border border-border mb-4">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left">Entity</th>
                  <th className="border border-border p-2 text-left">Key Attributes</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">risk_report</td>
                  <td className="border border-border p-2">id, org_id, facility_id, department_id, status_stage, category, likelihood, impact, risk_score, risk_level, priority, assignee, created_at, closed_at</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">risk_report_people</td>
                  <td className="border border-border p-2">risk_id, party_type, age_group, role</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">risk_report_factors</td>
                  <td className="border border-border p-2">risk_id, factor_type, notes</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">risk_report_attachments</td>
                  <td className="border border-border p-2">risk_id, file_name, file_url, evidence_type, confidentiality</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">risk_report_tasks</td>
                  <td className="border border-border p-2">risk_id, stage, task_description, owner, due_date, status</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">risk_template</td>
                  <td className="border border-border p-2">id, name, description, visibility_scope, defaults, version</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">cross_app_reference</td>
                  <td className="border border-border p-2">source_app, source_record_id, target_app, target_record_id, relationship_type</td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">7.2 Enumeration Values</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-muted p-3 rounded-lg">
                <p className="font-semibold mb-1">Report Types:</p>
                <p className="text-sm">Near Miss, Unsafe Condition, Adverse Event, Complaint, Observation</p>
              </div>
              <div className="bg-muted p-3 rounded-lg">
                <p className="font-semibold mb-1">Harm Levels:</p>
                <p className="text-sm">None, Mild, Moderate, Severe, Death, Catastrophic, Unknown</p>
              </div>
              <div className="bg-muted p-3 rounded-lg">
                <p className="font-semibold mb-1">Party Types:</p>
                <p className="text-sm">Patient, Staff, Visitor, Vendor, Unknown</p>
              </div>
              <div className="bg-muted p-3 rounded-lg">
                <p className="font-semibold mb-1">ROME Decisions:</p>
                <p className="text-sm">Retain, Optimize, Mitigate, Eliminate</p>
              </div>
              <div className="bg-muted p-3 rounded-lg">
                <p className="font-semibold mb-1">Risk Levels:</p>
                <p className="text-sm">Low (1-6), Medium (7-12), High (13-18), Critical (19-25)</p>
              </div>
              <div className="bg-muted p-3 rounded-lg">
                <p className="font-semibold mb-1">Priority:</p>
                <p className="text-sm">Routine, Urgent, Immediate</p>
              </div>
            </div>
          </section>

          {/* 8. Cross-App Integration */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">8. Cross-Application Integration</h2>
            
            <h3 className="text-xl font-semibold mb-2">8.1 Integrated Microapps</h3>
            <table className="w-full text-sm border-collapse border border-border mb-4">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left">Application</th>
                  <th className="border border-border p-2 text-left">Linkable Record Types</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-semibold">ComplianceConnect</td>
                  <td className="border border-border p-2">Policies, Controls, Citations, CAPA</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">EnforcePoint</td>
                  <td className="border border-border p-2">Enforcement Actions, Investigations, Notices</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">FeedbackHub</td>
                  <td className="border border-border p-2">Complaints, Grievances, Feedback</td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-semibold">AuditPro</td>
                  <td className="border border-border p-2">Audits, Findings, Evidence, Action Plans</td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">8.2 Relationship Types</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>Source of Risk</li>
              <li>Related Complaint</li>
              <li>Related Audit Finding</li>
              <li>Control/Policy Reference</li>
              <li>Evidence</li>
              <li>Mitigation/CAPA</li>
              <li>Duplicate/Similar</li>
              <li>Other</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2 mt-4">8.3 Cross-Reference Panel</h3>
            <p className="text-sm">
              Available on the risk report form (Report Basics stage). Allows users to search and link items from other microapps, select relationship type, and add optional notes.
            </p>
          </section>

          {/* 9. Security & Compliance */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">9. Security & Compliance</h2>
            
            <h3 className="text-xl font-semibold mb-2">9.1 Data Security</h3>
            <ul className="list-disc list-inside text-sm space-y-1 mb-4">
              <li>PHI minimization by default</li>
              <li>Masked patient identifiers (no direct PHI storage)</li>
              <li>Role-based viewing of sensitive fields</li>
              <li>Secure attachments with confidentiality labels</li>
              <li>Full audit logging for all edits, transitions, and overrides</li>
              <li>Row Level Security (RLS) on database</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2">9.2 Compliance Requirements</h3>
            <ul className="list-disc list-inside text-sm space-y-1 mb-4">
              <li>HIPAA compliant data handling</li>
              <li>Configurable data retention policies</li>
              <li>Anonymous reporting with internal audit trace</li>
              <li>Regulatory reporting flags and tracking</li>
            </ul>

            <h3 className="text-xl font-semibold mb-2">9.3 Accessibility</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li>ADA + WCAG 2.1 AA compliant</li>
              <li>Full keyboard navigation support</li>
              <li>Screen reader compatible (ARIA labels)</li>
              <li>Focus management and error summaries</li>
            </ul>
          </section>

          {/* 10. Response Guidelines */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">10. Response Guidelines</h2>
            
            <h3 className="text-xl font-semibold mb-2">10.1 General Behavior</h3>
            <div className="bg-muted p-4 rounded-lg mb-4 text-sm">
              <ul className="list-disc list-inside space-y-1">
                <li>Always verify user role before providing role-specific guidance</li>
                <li>Use healthcare-specific terminology appropriately</li>
                <li>Never store or display actual PHI - use masked identifiers</li>
                <li>Remind users of required fields before stage transitions</li>
                <li>Suggest appropriate cross-references when relevant</li>
                <li>Guide users through the risk lifecycle stages</li>
              </ul>
            </div>

            <h3 className="text-xl font-semibold mb-2">10.2 Risk Scoring Assistance</h3>
            <div className="bg-muted p-4 rounded-lg mb-4 text-sm">
              <p className="mb-2">When helping users score risks, explain:</p>
              <ul className="list-disc list-inside space-y-1">
                <li><strong>Likelihood (1-5)</strong>: Rare → Almost Certain</li>
                <li><strong>Impact (1-5)</strong>: Insignificant → Catastrophic</li>
                <li><strong>Risk Score</strong>: Likelihood × Impact × Readiness Factor</li>
                <li><strong>Risk Level</strong>: Low (1-6), Medium (7-12), High (13-18), Critical (19-25)</li>
              </ul>
            </div>

            <h3 className="text-xl font-semibold mb-2">10.3 Stage Transition Prompts</h3>
            <div className="bg-muted p-4 rounded-lg text-sm">
              <p className="mb-2">Before each stage transition, verify:</p>
              <ul className="list-disc list-inside space-y-1">
                <li>All required fields are complete</li>
                <li>User has appropriate permissions for the action</li>
                <li>If closing: closure reason and summary provided</li>
                <li>If sending back: reason documented</li>
                <li>If overriding score: justification provided</li>
              </ul>
            </div>
          </section>

          {/* 11. Error Handling */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">11. Error Handling</h2>
            
            <h3 className="text-xl font-semibold mb-2">11.1 Validation Errors</h3>
            <table className="w-full text-sm border-collapse border border-border mb-4">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left">Error Type</th>
                  <th className="border border-border p-2 text-left">Response</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2">Missing required fields</td>
                  <td className="border border-border p-2">List specific missing fields and guide user to complete them</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Invalid date/time</td>
                  <td className="border border-border p-2">Explain valid date format and constraints (e.g., cannot be future date)</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Permission denied</td>
                  <td className="border border-border p-2">Explain which role is required for the action</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">Invalid stage transition</td>
                  <td className="border border-border p-2">Explain allowed transitions from current stage</td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">11.2 System Errors</h3>
            <ul className="list-disc list-inside text-sm space-y-1">
              <li><strong>Network errors</strong>: Suggest retry and check connection</li>
              <li><strong>Session timeout</strong>: Prompt re-authentication</li>
              <li><strong>Server errors</strong>: Log incident and provide support contact</li>
              <li><strong>Data conflicts</strong>: Explain concurrent edit situation and resolution</li>
            </ul>
          </section>

          {/* Footer */}
          <hr className="my-8" />
          <footer className="text-center text-sm text-muted-foreground">
            <p>RiskGuard System Prompt Document</p>
            <p>Version 1.0 | Generated {new Date().toLocaleDateString()}</p>
            <p className="mt-2">For AI Agent Configuration and Healthcare Risk Management</p>
          </footer>
        </article>
      </main>
    </div>
  );
}