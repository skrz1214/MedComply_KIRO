import { Shield, ClipboardCheck, Stethoscope, Eye, RefreshCw, CheckCircle2, ArrowRight } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

type RiskItem = {
  id: string;
  title: string;
  category: string;
  department: string;
  level: string;
  assignee: string;
};

const mockRisks: Record<string, RiskItem[]> = {
  evaluate: [
    { id: "R-001", title: "Patient fall in room 204", category: "Falls", department: "Nursing", level: "High", assignee: "John Doe" },
    { id: "R-003", title: "Medication error incident", category: "Medication", department: "Pharmacy", level: "Critical", assignee: "Jane Smith" },
  ],
  treat: [
    { id: "R-002", title: "Equipment malfunction", category: "Equipment", department: "Radiology", level: "Medium", assignee: "Mike Johnson" },
  ],
  monitor: [
    { id: "R-004", title: "Staff injury report", category: "Workplace Safety", department: "HR", level: "Low", assignee: "Sarah Wilson" },
    { id: "R-005", title: "Data breach attempt", category: "Cybersecurity", department: "IT", level: "High", assignee: "Tom Brown" },
  ],
  reassess: [
    { id: "R-006", title: "Fire safety compliance", category: "Safety", department: "Facilities", level: "Medium", assignee: "Lisa Green" },
  ],
};

const stages = [
  { 
    key: "evaluate", 
    label: "Evaluate", 
    icon: ClipboardCheck, 
    description: "Assess likelihood, impact, and readiness",
    color: "text-status-evaluation",
    bgColor: "bg-status-evaluation/10",
    borderColor: "border-status-evaluation/20"
  },
  { 
    key: "treat", 
    label: "Treat", 
    icon: Stethoscope, 
    description: "Define ROME treatment strategy",
    color: "text-status-treatment",
    bgColor: "bg-status-treatment/10",
    borderColor: "border-status-treatment/20"
  },
  { 
    key: "monitor", 
    label: "Monitor", 
    icon: Eye, 
    description: "Track treatment implementation",
    color: "text-status-monitoring",
    bgColor: "bg-status-monitoring/10",
    borderColor: "border-status-monitoring/20"
  },
  { 
    key: "reassess", 
    label: "Reassess", 
    icon: RefreshCw, 
    description: "Evaluate residual risk and decide closure",
    color: "text-status-reassess",
    bgColor: "bg-status-reassess/10",
    borderColor: "border-status-reassess/20"
  },
];

const getRiskLevelStyle = (level: string) => {
  switch (level.toLowerCase()) {
    case "critical":
      return "bg-risk-critical/10 text-risk-critical border-risk-critical/20";
    case "high":
      return "bg-risk-high/10 text-risk-high border-risk-high/20";
    case "medium":
      return "bg-risk-medium/10 text-risk-medium border-risk-medium/20";
    default:
      return "bg-risk-low/10 text-risk-low border-risk-low/20";
  }
};

const StagesOverview = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">RiskGuard</h1>
            </Link>
            <Button variant="outline" asChild>
              <Link to="/process">Back to Process</Link>
            </Button>
          </div>
        </div>
      </header>

      <section className="bg-gradient-to-br from-secondary/5 to-primary/5 border-b border-border">
        <div className="container mx-auto px-6 py-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-foreground mb-2">
              Risk Management Stages
            </h2>
            <p className="text-muted-foreground">
              Evaluate → Treat → Monitor → Reassess/Close
            </p>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-6 py-8">
        <div className="grid gap-6 lg:grid-cols-2">
          {stages.map((stage) => {
            const StageIcon = stage.icon;
            const risks = mockRisks[stage.key] || [];
            
            return (
              <Card key={stage.key} className="overflow-hidden">
                <CardHeader className={`${stage.bgColor} border-b ${stage.borderColor}`}>
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg bg-background/80`}>
                      <StageIcon className={`h-5 w-5 ${stage.color}`} />
                    </div>
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {stage.label}
                        <Badge variant="secondary" className="ml-2">
                          {risks.length}
                        </Badge>
                      </CardTitle>
                      <CardDescription>{stage.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-4">
                  {risks.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      No risks at this stage
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {risks.map((risk) => (
                        <div
                          key={risk.id}
                          className="flex items-center justify-between p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                          onClick={() => navigate(`/process/${stage.key}/${risk.id}`)}
                        >
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant="outline" className="text-xs">
                                {risk.id}
                              </Badge>
                              <Badge variant="outline" className={getRiskLevelStyle(risk.level)}>
                                {risk.level}
                              </Badge>
                            </div>
                            <p className="font-medium text-sm truncate">{risk.title}</p>
                            <p className="text-xs text-muted-foreground">
                              {risk.category} • {risk.department} • {risk.assignee}
                            </p>
                          </div>
                          <ArrowRight className="h-4 w-4 text-muted-foreground flex-shrink-0 ml-2" />
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>
    </div>
  );
};

export default StagesOverview;
