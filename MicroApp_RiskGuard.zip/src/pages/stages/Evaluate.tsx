import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { RiskStageStepper } from '@/components/RiskStageStepper';
import { LinkedItemsPanel } from '@/components/LinkedItemsPanel';
import { useRiskStore } from '@/lib/riskStore';
import { getRiskLevelStyle, calculateRiskScore, getRiskLevel } from '@/lib/types';
import { toast } from 'sonner';
import { ArrowLeft, UserPlus, ArrowRight, RotateCcw, XCircle } from 'lucide-react';

export default function Evaluate() {
  const { riskId } = useParams();
  const navigate = useNavigate();

  const { getRiskById } = useRiskStore();
  const risk = getRiskById(riskId || '');

  const [likelihood, setLikelihood] = useState(risk?.likelihood?.toString() || '3');
  const [impact, setImpact] = useState(risk?.impact?.toString() || '4');
  const [readiness, setReadiness] = useState(risk?.readiness?.toString() || '2');
  const [evaluationNotes, setEvaluationNotes] = useState('');
  const [decision, setDecision] = useState<string>('');
  const [assignee, setAssignee] = useState('john.doe');
  const [sendBackReason, setSendBackReason] = useState('');
  const [closeReason, setCloseReason] = useState('');

  const [isReassignOpen, setIsReassignOpen] = useState(false);
  const [isSendBackOpen, setIsSendBackOpen] = useState(false);
  const [isCloseOpen, setIsCloseOpen] = useState(false);

  if (!risk) {
    return (
      <div className="p-8 text-center">
        <p>Risk not found</p>
        <Button onClick={() => navigate('/risks')} className="mt-4">Back to Queue</Button>
      </div>
    );
  }

  const { baseScore, adjustedScore, scoreRounded } = calculateRiskScore(
    parseInt(likelihood),
    parseInt(impact),
    parseInt(readiness)
  );
  const level = getRiskLevel(scoreRounded);

  const handleReassign = () => {
    toast.success(`Risk reassigned to ${assignee}`);
    setIsReassignOpen(false);
  };

  const handleSendBack = () => {
    if (!sendBackReason.trim()) {
      toast.error('Please provide a reason');
      return;
    }
    toast.success('Risk sent back to Report stage');
    navigate('/risks');
  };

  const handleClose = () => {
    if (!closeReason.trim()) {
      toast.error('Please provide a closure reason');
      return;
    }
    toast.success('Risk closed successfully');
    navigate('/risks');
  };

  const handleSubmit = () => {
    if (!decision) {
      toast.error('Please select a decision');
      return;
    }
    if (decision === 'Treat') {
      toast.success('Risk submitted to Treatment stage');
      navigate(`/risks/${riskId}/treat`);
    } else if (decision === 'Monitor') {
      toast.success('Risk submitted to Monitor stage');
      navigate(`/risks/${riskId}/monitor`);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="bg-gradient-to-br from-status-evaluation/10 to-primary/5 border-b">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center gap-4 mb-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(`/risks/${riskId}`)}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="flex items-center gap-3">
              <Badge variant="outline">{risk.id}</Badge>
              <Badge className="bg-status-evaluation/20 text-status-evaluation border-status-evaluation/30">
                Evaluate Stage
              </Badge>
              <Badge variant="outline" className={getRiskLevelStyle(level)}>{level}</Badge>
            </div>
          </div>
          <h1 className="text-2xl font-bold">{risk.title}</h1>
          <p className="text-muted-foreground">{risk.category} • {risk.departmentId} • Assigned to: {risk.assignee}</p>
        </div>
      </section>

      {/* Stage Stepper */}
      <section className="container mx-auto px-6 py-6">
        <Card>
          <CardContent className="p-6">
            <RiskStageStepper currentStage="Evaluate" />
          </CardContent>
        </Card>
      </section>

      {/* Main Content */}
      <section className="container mx-auto px-6 pb-12">
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Risk Assessment</CardTitle>
                <CardDescription>Evaluate likelihood, impact, and organizational readiness</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="space-y-2">
                    <Label>Likelihood (1-5)</Label>
                    <Select value={likelihood} onValueChange={setLikelihood}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 - Rare</SelectItem>
                        <SelectItem value="2">2 - Unlikely</SelectItem>
                        <SelectItem value="3">3 - Possible</SelectItem>
                        <SelectItem value="4">4 - Likely</SelectItem>
                        <SelectItem value="5">5 - Almost Certain</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Impact (1-5)</Label>
                    <Select value={impact} onValueChange={setImpact}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 - Negligible</SelectItem>
                        <SelectItem value="2">2 - Minor</SelectItem>
                        <SelectItem value="3">3 - Moderate</SelectItem>
                        <SelectItem value="4">4 - Major</SelectItem>
                        <SelectItem value="5">5 - Severe</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Readiness (1-3)</Label>
                    <Select value={readiness} onValueChange={setReadiness}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 - Low (weak controls)</SelectItem>
                        <SelectItem value="2">2 - Medium</SelectItem>
                        <SelectItem value="3">3 - High (strong controls)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Separator />

                <div className="bg-muted/50 p-6 rounded-lg">
                  <h3 className="font-semibold mb-4">Calculated Risk Score</h3>
                  <div className="grid gap-4 md:grid-cols-4 text-center">
                    <div>
                      <p className="text-sm text-muted-foreground">Base (L×I)</p>
                      <p className="text-2xl font-bold">{baseScore}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Adjusted</p>
                      <p className="text-2xl font-bold">{adjustedScore.toFixed(1)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Final</p>
                      <p className="text-2xl font-bold">{scoreRounded}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Level</p>
                      <Badge className={getRiskLevelStyle(level)}>{level}</Badge>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Evaluation Notes *</Label>
                  <Textarea
                    value={evaluationNotes}
                    onChange={e => setEvaluationNotes(e.target.value)}
                    placeholder="Document your evaluation findings and rationale..."
                    rows={4}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Decision *</Label>
                  <Select value={decision} onValueChange={setDecision}>
                    <SelectTrigger><SelectValue placeholder="Select next action" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Treat">Proceed to Treatment</SelectItem>
                      <SelectItem value="Monitor">Skip to Monitoring (low risk)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Stage Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-3">
                  <Dialog open={isReassignOpen} onOpenChange={setIsReassignOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline"><UserPlus className="h-4 w-4 mr-2" />Re-assign</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Re-assign Risk</DialogTitle>
                        <DialogDescription>Select a new assignee</DialogDescription>
                      </DialogHeader>
                      <Select value={assignee} onValueChange={setAssignee}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="john.doe">John Doe</SelectItem>
                          <SelectItem value="jane.smith">Jane Smith</SelectItem>
                          <SelectItem value="mike.johnson">Mike Johnson</SelectItem>
                        </SelectContent>
                      </Select>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setIsReassignOpen(false)}>Cancel</Button>
                        <Button onClick={handleReassign}>Confirm</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>

                  <Dialog open={isSendBackOpen} onOpenChange={setIsSendBackOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline"><RotateCcw className="h-4 w-4 mr-2" />Send Back</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Send Back to Report</DialogTitle>
                        <DialogDescription>Provide a reason for sending back</DialogDescription>
                      </DialogHeader>
                      <Textarea
                        value={sendBackReason}
                        onChange={e => setSendBackReason(e.target.value)}
                        placeholder="Explain why..."
                        rows={4}
                      />
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setIsSendBackOpen(false)}>Cancel</Button>
                        <Button variant="destructive" onClick={handleSendBack}>Send Back</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>

                  <Dialog open={isCloseOpen} onOpenChange={setIsCloseOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline"><XCircle className="h-4 w-4 mr-2" />Close Risk</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Close Risk</DialogTitle>
                        <DialogDescription>Provide closure reason</DialogDescription>
                      </DialogHeader>
                      <Select value={closeReason} onValueChange={setCloseReason}>
                        <SelectTrigger><SelectValue placeholder="Select reason" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Duplicate">Duplicate</SelectItem>
                          <SelectItem value="Not a risk">Not a Risk</SelectItem>
                          <SelectItem value="Entered in error">Entered in Error</SelectItem>
                          <SelectItem value="Moved to other system">Moved to Other System</SelectItem>
                        </SelectContent>
                      </Select>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setIsCloseOpen(false)}>Cancel</Button>
                        <Button onClick={handleClose}>Close Risk</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>

                  <Button onClick={handleSubmit} className="ml-auto">
                    Submit <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <LinkedItemsPanel references={risk.crossAppReferences} />
          </div>
        </div>
      </section>
    </div>
  );
}
