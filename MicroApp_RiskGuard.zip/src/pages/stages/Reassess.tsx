import { Shield, ArrowLeft, UserPlus, CheckCircle, RotateCcw, XCircle } from "lucide-react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { useState } from "react";

const Reassess = () => {
  const { riskId } = useParams();
  const navigate = useNavigate();
  const [residualLikelihood, setResidualLikelihood] = useState("2");
  const [residualImpact, setResidualImpact] = useState("3");
  const [residualReadiness, setResidualReadiness] = useState("3");
  const [assignee, setAssignee] = useState("john.doe");
  const [sendBackReason, setSendBackReason] = useState("");
  const [closeReason, setCloseReason] = useState("");
  const [isReassignOpen, setIsReassignOpen] = useState(false);
  const [isSendBackOpen, setIsSendBackOpen] = useState(false);
  const [isCloseOpen, setIsCloseOpen] = useState(false);

  const calculateScore = () => {
    const L = parseInt(residualLikelihood);
    const I = parseInt(residualImpact);
    const R = parseInt(residualReadiness);
    const maxReadiness = 3;
    
    const baseScore = L * I;
    const readinessFactor = (maxReadiness + 1 - R) / maxReadiness;
    const adjustedScore = baseScore * readinessFactor;
    const scoreRounded = Math.round(adjustedScore);
    
    return { baseScore, adjustedScore, scoreRounded };
  };

  const getRiskLevel = (score: number) => {
    if (score >= 13) return { level: "Critical", color: "bg-risk-critical/10 text-risk-critical border-risk-critical/20" };
    if (score >= 8) return { level: "High", color: "bg-risk-high/10 text-risk-high border-risk-high/20" };
    if (score >= 4) return { level: "Medium", color: "bg-risk-medium/10 text-risk-medium border-risk-medium/20" };
    return { level: "Low", color: "bg-risk-low/10 text-risk-low border-risk-low/20" };
  };

  const { baseScore, adjustedScore, scoreRounded } = calculateScore();
  const { level, color } = getRiskLevel(scoreRounded);

  const handleReassign = () => {
    toast.success(`Risk reassigned to ${assignee}`);
    setIsReassignOpen(false);
  };

  const handleSendBack = () => {
    toast.success("Risk sent back to Monitor stage");
    setSendBackReason("");
    setIsSendBackOpen(false);
    navigate(`/process/monitor/${riskId || "R-001"}`);
  };

  const handleContinueMonitoring = () => {
    toast.success("Risk returned to Monitor stage for continued monitoring");
    navigate(`/process/monitor/${riskId || "R-001"}`);
  };

  const handleCloseRisk = () => {
    toast.success("Risk has been closed");
    setCloseReason("");
    setIsCloseOpen(false);
    navigate("/process/stages");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">RiskGuard</h1>
            </Link>
            <Button variant="outline" asChild>
              <Link to="/process/stages">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Stages
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <section className="bg-gradient-to-br from-secondary/5 to-primary/5 border-b border-border">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Badge variant="outline">{riskId || "R-001"}</Badge>
                <Badge variant="outline" className="bg-status-reassess/10 text-status-reassess border-status-reassess/20">
                  Reassess Stage
                </Badge>
                <Badge variant="outline" className={color}>
                  {level} (Residual)
                </Badge>
              </div>
              <h2 className="text-3xl font-bold text-foreground mb-2">
                Patient fall in room 204
              </h2>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>Assigned to: John Doe</span>
                <span>•</span>
                <span>Category: Falls</span>
                <span>•</span>
                <span>Department: Nursing</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-6 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Residual Risk Assessment</CardTitle>
              <CardDescription>
                Reassess the risk after treatment implementation to determine residual risk level
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <Card className="border-muted">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">Initial Risk Score</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold">12</span>
                      <Badge variant="outline" className="bg-risk-high/10 text-risk-high border-risk-high/20">
                        High
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-primary/50">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">Residual Risk Score</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold">{scoreRounded}</span>
                      <Badge variant="outline" className={color}>
                        {level}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="residual-likelihood">Residual Likelihood (1-5)</Label>
                <Select value={residualLikelihood} onValueChange={setResidualLikelihood}>
                  <SelectTrigger id="residual-likelihood">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 - Rare</SelectItem>
                    <SelectItem value="2">2 - Unlikely</SelectItem>
                    <SelectItem value="3">3 - Possible</SelectItem>
                    <SelectItem value="4">4 - Likely</SelectItem>
                    <SelectItem value="5">5 - Almost Certain</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="residual-impact">Residual Impact (1-5)</Label>
                <Select value={residualImpact} onValueChange={setResidualImpact}>
                  <SelectTrigger id="residual-impact">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 - Negligible</SelectItem>
                    <SelectItem value="2">2 - Minor</SelectItem>
                    <SelectItem value="3">3 - Moderate</SelectItem>
                    <SelectItem value="4">4 - Major</SelectItem>
                    <SelectItem value="5">5 - Severe</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="residual-readiness">Residual Readiness (1-3)</Label>
                <Select value={residualReadiness} onValueChange={setResidualReadiness}>
                  <SelectTrigger id="residual-readiness">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 - Low Readiness (weak controls)</SelectItem>
                    <SelectItem value="2">2 - Medium Readiness</SelectItem>
                    <SelectItem value="3">3 - High Readiness (strong controls)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="reassess-notes">Reassessment Notes</Label>
                <Textarea
                  id="reassess-notes"
                  placeholder="Document effectiveness of treatment and any observations..."
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Stage Actions</CardTitle>
              <CardDescription>
                Re-assign, continue monitoring, or close the risk
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-3">
                <Dialog open={isReassignOpen} onOpenChange={setIsReassignOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline">
                      <UserPlus className="h-4 w-4 mr-2" />
                      Re-assign
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Re-assign Risk</DialogTitle>
                      <DialogDescription>
                        Select a new assignee for this risk reassessment
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Assign to</Label>
                        <Select value={assignee} onValueChange={setAssignee}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="john.doe">John Doe</SelectItem>
                            <SelectItem value="jane.smith">Jane Smith</SelectItem>
                            <SelectItem value="mike.johnson">Mike Johnson</SelectItem>
                            <SelectItem value="sarah.wilson">Sarah Wilson</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsReassignOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleReassign}>Confirm</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                <Dialog open={isSendBackOpen} onOpenChange={setIsSendBackOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline">
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Send Back to Monitor
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Send Back to Monitor Stage</DialogTitle>
                      <DialogDescription>
                        Provide a reason for sending this risk back
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Reason</Label>
                        <Textarea
                          value={sendBackReason}
                          onChange={(e) => setSendBackReason(e.target.value)}
                          placeholder="Explain why this risk needs more monitoring..."
                          rows={4}
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsSendBackOpen(false)}>
                        Cancel
                      </Button>
                      <Button variant="destructive" onClick={handleSendBack}>
                        Send Back
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                <Button variant="secondary" onClick={handleContinueMonitoring}>
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Continue Monitoring
                </Button>

                <Dialog open={isCloseOpen} onOpenChange={setIsCloseOpen}>
                  <DialogTrigger asChild>
                    <Button className="ml-auto">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Close Risk
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Close Risk</DialogTitle>
                      <DialogDescription>
                        Provide a rationale for closing this risk
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Closure Rationale</Label>
                        <Textarea
                          value={closeReason}
                          onChange={(e) => setCloseReason(e.target.value)}
                          placeholder="Explain why this risk can be closed (e.g., treatment effective, risk eliminated, accepted at current level)..."
                          rows={4}
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsCloseOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleCloseRisk}>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Confirm Close
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Reassess;
