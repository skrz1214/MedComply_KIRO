import { Shield, ArrowLeft, UserPlus, ArrowRight, RotateCcw, Plus, Trash2 } from "lucide-react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { useState } from "react";

type MonitoringEntry = {
  date: string;
  status: string;
  notes: string;
};

const Monitor = () => {
  const { riskId } = useParams();
  const navigate = useNavigate();
  const [assignee, setAssignee] = useState("john.doe");
  const [sendBackReason, setSendBackReason] = useState("");
  const [isReassignOpen, setIsReassignOpen] = useState(false);
  const [isSendBackOpen, setIsSendBackOpen] = useState(false);
  const [monitoringEntries, setMonitoringEntries] = useState<MonitoringEntry[]>([
    { date: "2024-03-20", status: "on-track", notes: "Treatment implementation in progress" },
    { date: "2024-03-15", status: "on-track", notes: "Initial monitoring started" },
  ]);
  const [newEntry, setNewEntry] = useState({ date: "", status: "", notes: "" });

  const handleReassign = () => {
    toast.success(`Risk reassigned to ${assignee}`);
    setIsReassignOpen(false);
  };

  const handleSendBack = () => {
    toast.success("Risk sent back to Treatment stage");
    setSendBackReason("");
    setIsSendBackOpen(false);
    navigate(`/process/treat/${riskId || "R-001"}`);
  };

  const handleSubmitToNextStage = () => {
    toast.success("Risk submitted to Reassess stage");
    navigate(`/process/reassess/${riskId || "R-001"}`);
  };

  const handleAddEntry = () => {
    if (newEntry.date && newEntry.status && newEntry.notes) {
      setMonitoringEntries([newEntry, ...monitoringEntries]);
      setNewEntry({ date: "", status: "", notes: "" });
      toast.success("Monitoring entry added");
    }
  };

  const handleRemoveEntry = (index: number) => {
    setMonitoringEntries(monitoringEntries.filter((_, i) => i !== index));
    toast.success("Monitoring entry removed");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">RiskGuard</h1>
            </Link>
            <Button variant="outline" asChild>
              <Link to="/process/stages">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Stages
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <section className="bg-gradient-to-br from-secondary/5 to-primary/5 border-b border-border">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Badge variant="outline">{riskId || "R-001"}</Badge>
                <Badge variant="outline" className="bg-status-monitoring/10 text-status-monitoring border-status-monitoring/20">
                  Monitor Stage
                </Badge>
                <Badge variant="outline" className="bg-risk-high/10 text-risk-high border-risk-high/20">
                  High
                </Badge>
              </div>
              <h2 className="text-3xl font-bold text-foreground mb-2">
                Patient fall in room 204
              </h2>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>Assigned to: John Doe</span>
                <span>•</span>
                <span>Category: Falls</span>
                <span>•</span>
                <span>Department: Nursing</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-6 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Add Monitoring Entry</CardTitle>
              <CardDescription>
                Track the progress of risk treatment implementation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="entry-date">Date</Label>
                  <Input
                    id="entry-date"
                    type="date"
                    value={newEntry.date}
                    onChange={(e) => setNewEntry({ ...newEntry, date: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="entry-status">Status</Label>
                  <Select
                    value={newEntry.status}
                    onValueChange={(value) => setNewEntry({ ...newEntry, status: value })}
                  >
                    <SelectTrigger id="entry-status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="on-track">On Track</SelectItem>
                      <SelectItem value="at-risk">At Risk</SelectItem>
                      <SelectItem value="delayed">Delayed</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="entry-notes">Notes</Label>
                <Textarea
                  id="entry-notes"
                  placeholder="Describe current status and any observations..."
                  rows={3}
                  value={newEntry.notes}
                  onChange={(e) => setNewEntry({ ...newEntry, notes: e.target.value })}
                />
              </div>
              <Button onClick={handleAddEntry} className="w-full">
                <Plus className="h-4 w-4 mr-2" />
                Add Entry
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Monitoring History</CardTitle>
              <CardDescription>
                Previous monitoring entries and status updates
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {monitoringEntries.map((entry, index) => (
                  <div key={index} className="flex items-start justify-between p-4 border border-border rounded-lg">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{entry.date}</span>
                        <Badge variant="outline" className={
                          entry.status === "on-track" ? "bg-risk-low/10 text-risk-low border-risk-low/20" :
                          entry.status === "at-risk" ? "bg-risk-medium/10 text-risk-medium border-risk-medium/20" :
                          entry.status === "delayed" ? "bg-risk-high/10 text-risk-high border-risk-high/20" :
                          "bg-primary/10 text-primary border-primary/20"
                        }>
                          {entry.status === "on-track" ? "On Track" :
                           entry.status === "at-risk" ? "At Risk" :
                           entry.status === "delayed" ? "Delayed" : "Completed"}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{entry.notes}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveEntry(index)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Stage Actions</CardTitle>
              <CardDescription>
                Re-assign, send back to previous stage, or submit to next stage
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-3">
                <Dialog open={isReassignOpen} onOpenChange={setIsReassignOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline">
                      <UserPlus className="h-4 w-4 mr-2" />
                      Re-assign
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Re-assign Risk</DialogTitle>
                      <DialogDescription>
                        Select a new assignee for monitoring this risk
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Assign to</Label>
                        <Select value={assignee} onValueChange={setAssignee}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="john.doe">John Doe</SelectItem>
                            <SelectItem value="jane.smith">Jane Smith</SelectItem>
                            <SelectItem value="mike.johnson">Mike Johnson</SelectItem>
                            <SelectItem value="sarah.wilson">Sarah Wilson</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsReassignOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleReassign}>Confirm</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                <Dialog open={isSendBackOpen} onOpenChange={setIsSendBackOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline">
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Send Back to Treatment
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Send Back to Treatment Stage</DialogTitle>
                      <DialogDescription>
                        Provide a reason for sending this risk back
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Reason</Label>
                        <Textarea
                          value={sendBackReason}
                          onChange={(e) => setSendBackReason(e.target.value)}
                          placeholder="Explain why this risk needs to go back to treatment..."
                          rows={4}
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsSendBackOpen(false)}>
                        Cancel
                      </Button>
                      <Button variant="destructive" onClick={handleSendBack}>
                        Send Back
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                <Button onClick={handleSubmitToNextStage} className="ml-auto">
                  Submit to Reassess
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Monitor;
