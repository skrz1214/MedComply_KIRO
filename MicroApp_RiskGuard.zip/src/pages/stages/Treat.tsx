import { Shield, ArrowLeft, UserPlus, ArrowRight, RotateCcw } from "lucide-react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { useState } from "react";

const Treat = () => {
  const { riskId } = useParams();
  const navigate = useNavigate();
  const [romeDecision, setRomeDecision] = useState("");
  const [assignee, setAssignee] = useState("john.doe");
  const [sendBackReason, setSendBackReason] = useState("");
  const [isReassignOpen, setIsReassignOpen] = useState(false);
  const [isSendBackOpen, setIsSendBackOpen] = useState(false);

  const handleReassign = () => {
    toast.success(`Risk reassigned to ${assignee}`);
    setIsReassignOpen(false);
  };

  const handleSendBack = () => {
    toast.success("Risk sent back to Evaluate stage");
    setSendBackReason("");
    setIsSendBackOpen(false);
    navigate(`/process/evaluate/${riskId || "R-001"}`);
  };

  const handleSubmitToNextStage = () => {
    toast.success("Risk submitted to Monitor stage");
    navigate(`/process/monitor/${riskId || "R-001"}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">RiskGuard</h1>
            </Link>
            <Button variant="outline" asChild>
              <Link to="/process/stages">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Stages
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <section className="bg-gradient-to-br from-secondary/5 to-primary/5 border-b border-border">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Badge variant="outline">{riskId || "R-001"}</Badge>
                <Badge variant="outline" className="bg-status-treatment/10 text-status-treatment border-status-treatment/20">
                  Treatment Stage
                </Badge>
                <Badge variant="outline" className="bg-risk-high/10 text-risk-high border-risk-high/20">
                  High
                </Badge>
              </div>
              <h2 className="text-3xl font-bold text-foreground mb-2">
                Patient fall in room 204
              </h2>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>Assigned to: John Doe</span>
                <span>•</span>
                <span>Category: Falls</span>
                <span>•</span>
                <span>Department: Nursing</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-6 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Treatment Plan</CardTitle>
              <CardDescription>
                Define ROME strategy: Retain / Optimize / Mitigate / Eliminate
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="rome-decision">ROME Decision</Label>
                <Select value={romeDecision} onValueChange={setRomeDecision}>
                  <SelectTrigger id="rome-decision">
                    <SelectValue placeholder="Select treatment approach" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="retain">Retain - Accept the risk</SelectItem>
                    <SelectItem value="optimize">Optimize - Improve controls</SelectItem>
                    <SelectItem value="mitigate">Mitigate - Reduce impact/likelihood</SelectItem>
                    <SelectItem value="eliminate">Eliminate - Remove the risk source</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="treatment-description">Treatment Description</Label>
                <Textarea
                  id="treatment-description"
                  placeholder="Describe the treatment approach in detail..."
                  rows={4}
                />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="responsible-person">Responsible Person</Label>
                  <Select>
                    <SelectTrigger id="responsible-person">
                      <SelectValue placeholder="Select responsible person" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="john.doe">John Doe</SelectItem>
                      <SelectItem value="jane.smith">Jane Smith</SelectItem>
                      <SelectItem value="mike.johnson">Mike Johnson</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="target-date">Target Completion Date</Label>
                  <Input id="target-date" type="date" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="resources">Required Resources</Label>
                <Textarea
                  id="resources"
                  placeholder="List resources needed for treatment implementation..."
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="success-criteria">Success Criteria</Label>
                <Textarea
                  id="success-criteria"
                  placeholder="Define measurable criteria for treatment success..."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Stage Actions</CardTitle>
              <CardDescription>
                Re-assign, send back to previous stage, or submit to next stage
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-3">
                <Dialog open={isReassignOpen} onOpenChange={setIsReassignOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline">
                      <UserPlus className="h-4 w-4 mr-2" />
                      Re-assign
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Re-assign Risk</DialogTitle>
                      <DialogDescription>
                        Select a new assignee for this treatment plan
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Assign to</Label>
                        <Select value={assignee} onValueChange={setAssignee}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="john.doe">John Doe</SelectItem>
                            <SelectItem value="jane.smith">Jane Smith</SelectItem>
                            <SelectItem value="mike.johnson">Mike Johnson</SelectItem>
                            <SelectItem value="sarah.wilson">Sarah Wilson</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsReassignOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleReassign}>Confirm</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                <Dialog open={isSendBackOpen} onOpenChange={setIsSendBackOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline">
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Send Back to Evaluate
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Send Back to Evaluate Stage</DialogTitle>
                      <DialogDescription>
                        Provide a reason for sending this risk back
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Reason</Label>
                        <Textarea
                          value={sendBackReason}
                          onChange={(e) => setSendBackReason(e.target.value)}
                          placeholder="Explain why this risk needs to go back to evaluation..."
                          rows={4}
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsSendBackOpen(false)}>
                        Cancel
                      </Button>
                      <Button variant="destructive" onClick={handleSendBack}>
                        Send Back
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                <Button onClick={handleSubmitToNextStage} className="ml-auto">
                  Submit to Monitor
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Treat;
