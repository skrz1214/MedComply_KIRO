import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Save, Plus, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface Band {
  min: number;
  max: number;
  level: string;
}

interface ScoringConfig {
  type: "org" | "category" | "category-department";
  category?: string;
  department?: string;
  bands: Band[];
}

const categories = [
  "ABUSE_NEGLECT",
  "MEDICATION_SAFETY",
  "FALLS",
  "INFECTION_CONTROL",
  "BILLING_INTEGRITY",
];

const departments = [
  "NURSING",
  "PHARMACY",
  "HOME_HEALTH",
  "ASSISTED_LIVING",
];

export default function ScoringSettings() {
  const navigate = useNavigate();
  const { toast } = useToast();

  // Organization-level default bands
  const [orgBands, setOrgBands] = useState<Band[]>([
    { min: 1, max: 3, level: "Low" },
    { min: 4, max: 7, level: "Medium" },
    { min: 8, max: 12, level: "High" },
    { min: 13, max: 25, level: "Critical" },
  ]);

  // Category-level overrides
  const [categoryConfigs, setCategoryConfigs] = useState<Record<string, Band[]>>({
    ABUSE_NEGLECT: [
      { min: 1, max: 2, level: "Low" },
      { min: 3, max: 4, level: "Medium" },
      { min: 5, max: 7, level: "High" },
      { min: 8, max: 25, level: "Critical" },
    ],
    MEDICATION_SAFETY: [
      { min: 1, max: 3, level: "Low" },
      { min: 4, max: 6, level: "Medium" },
      { min: 7, max: 10, level: "High" },
      { min: 11, max: 25, level: "Critical" },
    ],
  });

  // Category+Department overrides
  const [categoryDeptConfigs, setCategoryDeptConfigs] = useState<Record<string, Band[]>>({
    "MEDICATION_SAFETY:PHARMACY": [
      { min: 1, max: 2, level: "Low" },
      { min: 3, max: 5, level: "Medium" },
      { min: 6, max: 8, level: "High" },
      { min: 9, max: 25, level: "Critical" },
    ],
    "BILLING_INTEGRITY:HOME_HEALTH": [
      { min: 1, max: 2, level: "Low" },
      { min: 3, max: 4, level: "Medium" },
      { min: 5, max: 6, level: "High" },
      { min: 7, max: 25, level: "Critical" },
    ],
  });

  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [selectedDepartment, setSelectedDepartment] = useState<string>("");

  const validateBands = (bands: Band[]): boolean => {
    for (let i = 0; i < bands.length; i++) {
      if (bands[i].min > bands[i].max) return false;
      if (i > 0 && bands[i].min !== bands[i - 1].max + 1) return false;
    }
    return true;
  };

  const handleSaveOrgBands = () => {
    if (!validateBands(orgBands)) {
      toast({
        title: "Invalid Configuration",
        description: "Bands must not overlap and must cover the full range.",
        variant: "destructive",
      });
      return;
    }
    toast({
      title: "Organization Settings Saved",
      description: "New configuration version created successfully.",
    });
  };

  const handleSaveCategoryBands = (category: string, bands: Band[]) => {
    if (!validateBands(bands)) {
      toast({
        title: "Invalid Configuration",
        description: "Bands must not overlap and must cover the full range.",
        variant: "destructive",
      });
      return;
    }
    setCategoryConfigs({ ...categoryConfigs, [category]: bands });
    toast({
      title: "Category Settings Saved",
      description: `Configuration for ${category} updated successfully.`,
    });
  };

  const handleSaveCategoryDeptBands = (key: string, bands: Band[]) => {
    if (!validateBands(bands)) {
      toast({
        title: "Invalid Configuration",
        description: "Bands must not overlap and must cover the full range.",
        variant: "destructive",
      });
      return;
    }
    setCategoryDeptConfigs({ ...categoryDeptConfigs, [key]: bands });
    toast({
      title: "Category+Department Settings Saved",
      description: `Configuration updated successfully.`,
    });
  };

  const renderBandEditor = (bands: Band[], onUpdate: (bands: Band[]) => void, onSave: () => void) => {
    return (
      <div className="space-y-4">
        {bands.map((band, index) => (
          <div key={index} className="grid grid-cols-4 gap-4 items-end">
            <div>
              <Label htmlFor={`min-${index}`}>Min Score</Label>
              <Input
                id={`min-${index}`}
                type="number"
                value={band.min}
                onChange={(e) => {
                  const newBands = [...bands];
                  newBands[index].min = parseInt(e.target.value);
                  onUpdate(newBands);
                }}
              />
            </div>
            <div>
              <Label htmlFor={`max-${index}`}>Max Score</Label>
              <Input
                id={`max-${index}`}
                type="number"
                value={band.max}
                onChange={(e) => {
                  const newBands = [...bands];
                  newBands[index].max = parseInt(e.target.value);
                  onUpdate(newBands);
                }}
              />
            </div>
            <div>
              <Label htmlFor={`level-${index}`}>Risk Level</Label>
              <Input
                id={`level-${index}`}
                value={band.level}
                onChange={(e) => {
                  const newBands = [...bands];
                  newBands[index].level = e.target.value;
                  onUpdate(newBands);
                }}
              />
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                const newBands = bands.filter((_, i) => i !== index);
                onUpdate(newBands);
              }}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        ))}
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => {
              const lastBand = bands[bands.length - 1];
              const newBands = [
                ...bands,
                { min: lastBand.max + 1, max: lastBand.max + 5, level: "New Level" },
              ];
              onUpdate(newBands);
            }}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Band
          </Button>
          <Button onClick={onSave}>
            <Save className="h-4 w-4 mr-2" />
            Save Configuration
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <div className="container mx-auto p-6 max-w-6xl">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-foreground">Risk Scoring Settings</h1>
            <p className="text-muted-foreground">Configure scoring thresholds and risk level bands</p>
          </div>
        </div>

        <Tabs defaultValue="organization" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="organization">Organization Defaults</TabsTrigger>
            <TabsTrigger value="category">Category Overrides</TabsTrigger>
            <TabsTrigger value="category-dept">Category + Department</TabsTrigger>
          </TabsList>

          <TabsContent value="organization">
            <Card>
              <CardHeader>
                <CardTitle>Organization-Level Default Scoring</CardTitle>
                <CardDescription>
                  These defaults apply to all risks unless overridden by category or category+department configurations.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {renderBandEditor(orgBands, setOrgBands, handleSaveOrgBands)}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="category">
            <Card>
              <CardHeader>
                <CardTitle>Category-Level Overrides</CardTitle>
                <CardDescription>
                  Override organization defaults for specific risk categories.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="category-select">Select Category</Label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger id="category-select">
                      <SelectValue placeholder="Choose a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat} value={cat}>
                          {cat.replace(/_/g, " ")}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedCategory && categoryConfigs[selectedCategory] && (
                  <div className="border-t pt-6">
                    <h3 className="text-lg font-semibold mb-4">
                      Configuration for {selectedCategory.replace(/_/g, " ")}
                    </h3>
                    {renderBandEditor(
                      categoryConfigs[selectedCategory],
                      (bands) => setCategoryConfigs({ ...categoryConfigs, [selectedCategory]: bands }),
                      () => handleSaveCategoryBands(selectedCategory, categoryConfigs[selectedCategory])
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="category-dept">
            <Card>
              <CardHeader>
                <CardTitle>Category + Department Overrides</CardTitle>
                <CardDescription>
                  Highest precedence: Override both organization and category defaults for specific category+department combinations.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="cat-select">Select Category</Label>
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger id="cat-select">
                        <SelectValue placeholder="Choose a category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat} value={cat}>
                            {cat.replace(/_/g, " ")}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="dept-select">Select Department</Label>
                    <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                      <SelectTrigger id="dept-select">
                        <SelectValue placeholder="Choose a department" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments.map((dept) => (
                          <SelectItem key={dept} value={dept}>
                            {dept.replace(/_/g, " ")}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {selectedCategory && selectedDepartment && (
                  <div className="border-t pt-6">
                    <h3 className="text-lg font-semibold mb-4">
                      Configuration for {selectedCategory.replace(/_/g, " ")} + {selectedDepartment.replace(/_/g, " ")}
                    </h3>
                    {(() => {
                      const key = `${selectedCategory}:${selectedDepartment}`;
                      const bands = categoryDeptConfigs[key] || [...orgBands];
                      return renderBandEditor(
                        bands,
                        (newBands) => setCategoryDeptConfigs({ ...categoryDeptConfigs, [key]: newBands }),
                        () => handleSaveCategoryDeptBands(key, bands)
                      );
                    })()}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
