import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import {
  RISK_CATEGORIES,
  REPORT_TYPES,
  LOCATION_TYPES,
  FACILITY_TYPES,
  DEPARTMENTS,
  CONTRIBUTING_FACTORS,
  OUTCOME_TYPES,
  generateRiskId,
  CrossAppReference,
} from '@/lib/types';
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Save,
  Send,
  Upload,
  X,
  FileText,
  User,
  Building2,
  MapPin,
  Users,
  Activity,
  Bell,
  Paperclip,
} from 'lucide-react';
import { LinkedItemsPanel } from '@/components/LinkedItemsPanel';
import { useRiskStore, buildRiskReport, newRiskId } from '@/lib/riskStore';
import type { RiskReport } from '@/lib/types';

/** Combines a date input and optional time input into an ISO timestamp. */
function toIso(date: string, time?: string): string | undefined {
  if (!date) return undefined;
  const parsed = new Date(`${date}T${time || '00:00'}`);
  return isNaN(parsed.getTime()) ? undefined : parsed.toISOString();
}

const WIZARD_STEPS = [
  { id: 'basics', label: 'Report Basics', icon: Building2 },
  { id: 'details', label: 'Event Details', icon: FileText },
  { id: 'people', label: 'People Involved', icon: Users },
  { id: 'impact', label: 'Impact & Severity', icon: Activity },
  { id: 'factors', label: 'Contributing Factors', icon: MapPin },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'attachments', label: 'Attachments', icon: Paperclip },
  { id: 'reporter', label: 'Reporter Info', icon: User },
];

export default function NewRiskWizard() {
  const navigate = useNavigate();
  const location = useLocation();
  const template = location.state?.template;
  const draftId: string | undefined = location.state?.draftId;

  const { addRisk, updateRisk, saveDraftForm, getDraftForm } = useRiskStore();
  const savedDraft = draftId ? getDraftForm(draftId) : undefined;

  const [currentStep, setCurrentStep] = useState(0);
  const [isDraft, setIsDraft] = useState(true);
  // Id of the persisted record for this report (created on first save/submit)
  const [riskRecordId, setRiskRecordId] = useState<string | null>(draftId ?? null);
  const [attachments, setAttachments] = useState<File[]>([]);
  const [crossReferences, setCrossReferences] = useState<CrossAppReference[]>([]);

  // Form state
  const [formData, setFormData] = useState({
    // Basics
    facilityType: template?.facilityType || '',
    department: template?.departmentId || '',
    category: template?.category || '',
    reportType: template?.reportType || '',
    discoveredDate: '',
    discoveredTime: '',
    occurredDate: '',
    occurredTime: '',
    occurredUnknown: false,
    howIdentified: '',

    // Details
    locationType: template?.locationType || '',
    locationText: '',
    title: template?.suggestedTitle || template?.name || '',
    description: template?.description || '',
    witnessed: '',
    witnessNames: '',
    ongoing: false,
    immediateActions: '',

    // People
    partyTypes: [] as string[],
    patientAgeGroup: '',
    staffRole: '',
    numberAffected: '',

    // Impact
    actualHarm: '',
    potentialHarm: '',
    outcomes: [] as string[],
    reachedPatient: '',
    sentinelSuspected: '',

    // Factors
    contributingFactors: template?.defaultFactors || ([] as string[]),
    preventionSuggestion: '',

    // Notifications
    notifiedPatientFamily: 'Unknown',
    notifiedProvider: 'Unknown',
    notifiedSupervisor: 'Unknown',
    notifiedRiskQuality: 'Unknown',
    notifiedSecurity: 'Unknown',
    notifiedPrivacy: 'Unknown',
    regulatoryRequired: '',
    priority: template?.priority || 'Routine',
    requestFollowUp: false,
    contactMethod: '',

    // Reporter
    isAnonymous: false,
    reporterName: '',
    reporterEmail: '',
    attestation: false,

    // Reopening a saved draft overrides all defaults above
    ...(savedDraft || {}),
  });

  const updateForm = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleArrayField = (field: string, value: string) => {
    setFormData(prev => {
      const arr = prev[field as keyof typeof prev] as string[];
      return {
        ...prev,
        [field]: arr.includes(value)
          ? arr.filter(v => v !== value)
          : [...arr, value],
      };
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setAttachments(prev => [...prev, ...Array.from(e.target.files!)]);
    }
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  /** Maps the wizard form state onto the fields a RiskReport needs. */
  const toRiskFields = () => ({
    title: formData.title?.trim() || 'Untitled report',
    description: formData.description?.trim() || '',
    category: formData.category,
    departmentId: formData.department,
    facilityType: formData.facilityType,
    reportType: formData.reportType,
    discoveredAt: toIso(formData.discoveredDate, formData.discoveredTime),
    occurredAt: formData.occurredUnknown
      ? undefined
      : toIso(formData.occurredDate, formData.occurredTime),
    howIdentified: formData.howIdentified,
    locationType: formData.locationType,
    locationText: formData.locationText,
    witnessed: (formData.witnessed || 'Unknown') as RiskReport['witnessed'],
    witnessNames: formData.witnessNames,
    ongoing: formData.ongoing,
    immediateActionsTaken: formData.immediateActions,
    peopleInvolved: (formData.partyTypes || []).map((partyType: string) => ({
      partyType,
      ageGroup: partyType === 'Patient' ? formData.patientAgeGroup || undefined : undefined,
      role: partyType === 'Staff' ? formData.staffRole || undefined : undefined,
    })) as RiskReport['peopleInvolved'],
    numberAffected: formData.numberAffected ? Number(formData.numberAffected) : undefined,
    actualHarmLevel: (formData.actualHarm || 'None') as RiskReport['actualHarmLevel'],
    potentialHarmLevel: (formData.potentialHarm || 'None') as RiskReport['potentialHarmLevel'],
    outcomeTypes: formData.outcomes,
    reachedPatient: (formData.reachedPatient || 'Unknown') as RiskReport['reachedPatient'],
    sentinelSuspected: (formData.sentinelSuspected || 'Unsure') as RiskReport['sentinelSuspected'],
    contributingFactors: formData.contributingFactors,
    preventionSuggestion: formData.preventionSuggestion,
    notifiedPatientFamily: formData.notifiedPatientFamily as RiskReport['notifiedPatientFamily'],
    notifiedProvider: formData.notifiedProvider as RiskReport['notifiedProvider'],
    notifiedSupervisor: formData.notifiedSupervisor as RiskReport['notifiedSupervisor'],
    notifiedRiskQuality: formData.notifiedRiskQuality as RiskReport['notifiedRiskQuality'],
    notifiedSecurity: formData.notifiedSecurity as RiskReport['notifiedSecurity'],
    notifiedPrivacy: formData.notifiedPrivacy as RiskReport['notifiedPrivacy'],
    regulatoryReportingRequired: (formData.regulatoryRequired ||
      'Unsure') as RiskReport['regulatoryReportingRequired'],
    priority: formData.priority as RiskReport['priority'],
    requestedFollowUp: formData.requestFollowUp,
    contactMethod: formData.contactMethod,
    isAnonymous: formData.isAnonymous,
    reporterName: formData.reporterName,
    reporterEmail: formData.reporterEmail,
    attestationConfirmed: formData.attestation,
    crossAppReferences: crossReferences,
    templateIdUsed: template?.id,
  });

  const handleSaveDraft = () => {
    const id = riskRecordId ?? newRiskId();
    const fields = toRiskFields();

    if (riskRecordId) {
      updateRisk(id, { ...fields, stage: 'Report', subStatus: 'Draft' });
    } else {
      addRisk(buildRiskReport({ ...fields, id, subStatus: 'Draft' }));
      setRiskRecordId(id);
    }
    // Keep the raw form state so the draft reopens exactly as it was left
    saveDraftForm(id, formData);

    setIsDraft(true);
    toast.success(`Draft ${id} saved to your Risk Queue`);
  };

  const handleSubmit = () => {
    if (!formData.attestation) {
      toast.error('Please confirm the attestation before submitting');
      return;
    }
    if (!formData.title || !formData.description || !formData.category) {
      toast.error('Please fill in all required fields');
      return;
    }

    const id = riskRecordId ?? newRiskId();
    const fields = toRiskFields();

    if (riskRecordId) {
      updateRisk(id, { ...fields, stage: 'Report', subStatus: 'Submitted' });
    } else {
      addRisk(buildRiskReport({ ...fields, id, subStatus: 'Submitted' }));
    }
    setRiskRecordId(id);
    setIsDraft(false);

    toast.success(`Risk ${id} submitted successfully`);
    navigate('/risks');
  };


  const handleAddReference = (ref: Omit<CrossAppReference, 'id' | 'createdAt' | 'createdBy'>) => {
    const newRef: CrossAppReference = {
      ...ref,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      createdBy: 'current-user@health.org',
    };
    setCrossReferences(prev => [...prev, newRef]);
  };

  const handleRemoveReference = (id: string, reason: string) => {
    setCrossReferences(prev => prev.filter(ref => ref.id !== id));
  };

  const progress = ((currentStep + 1) / WIZARD_STEPS.length) * 100;

  const renderStepContent = () => {
    switch (WIZARD_STEPS[currentStep].id) {
      case 'basics':
        return (
          <div className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Facility Type</Label>
                <Select value={formData.facilityType} onValueChange={v => updateForm('facilityType', v)}>
                  <SelectTrigger><SelectValue placeholder="Select facility type" /></SelectTrigger>
                  <SelectContent>
                    {FACILITY_TYPES.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Department / Unit *</Label>
                <Select value={formData.department} onValueChange={v => updateForm('department', v)}>
                  <SelectTrigger><SelectValue placeholder="Select department" /></SelectTrigger>
                  <SelectContent>
                    {DEPARTMENTS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Report Category *</Label>
                <Select value={formData.category} onValueChange={v => updateForm('category', v)}>
                  <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                  <SelectContent>
                    {RISK_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Report Type *</Label>
                <Select value={formData.reportType} onValueChange={v => updateForm('reportType', v)}>
                  <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                  <SelectContent>
                    {REPORT_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Separator />
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Date & Time Discovered *</Label>
                <div className="flex gap-2">
                  <Input type="date" value={formData.discoveredDate} onChange={e => updateForm('discoveredDate', e.target.value)} />
                  <Input type="time" value={formData.discoveredTime} onChange={e => updateForm('discoveredTime', e.target.value)} />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Date & Time Occurred</Label>
                <div className="flex gap-2">
                  <Input type="date" value={formData.occurredDate} onChange={e => updateForm('occurredDate', e.target.value)} disabled={formData.occurredUnknown} />
                  <Input type="time" value={formData.occurredTime} onChange={e => updateForm('occurredTime', e.target.value)} disabled={formData.occurredUnknown} />
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <Checkbox id="occurred-unknown" checked={formData.occurredUnknown} onCheckedChange={v => updateForm('occurredUnknown', v)} />
                  <label htmlFor="occurred-unknown" className="text-sm">Unknown when occurred</label>
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <Label>How was this identified? *</Label>
              <Select value={formData.howIdentified} onValueChange={v => updateForm('howIdentified', v)}>
                <SelectTrigger><SelectValue placeholder="Select identification method" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Staff observed">Staff observed</SelectItem>
                  <SelectItem value="Patient reported">Patient reported</SelectItem>
                  <SelectItem value="Family reported">Family reported</SelectItem>
                  <SelectItem value="Audit">Audit</SelectItem>
                  <SelectItem value="Monitoring system">Monitoring system</SelectItem>
                  <SelectItem value="External notification">External notification</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );

      case 'details':
        return (
          <div className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Location Type *</Label>
                <Select value={formData.locationType} onValueChange={v => updateForm('locationType', v)}>
                  <SelectTrigger><SelectValue placeholder="Select location type" /></SelectTrigger>
                  <SelectContent>
                    {LOCATION_TYPES.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Specific Location</Label>
                <Input value={formData.locationText} onChange={e => updateForm('locationText', e.target.value)} placeholder="e.g., Room 204, East Wing" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Brief Title / Summary *</Label>
              <Input value={formData.title} onChange={e => updateForm('title', e.target.value)} placeholder="Brief description of the event" />
            </div>
            <div className="space-y-2">
              <Label>Detailed Description *</Label>
              <Textarea value={formData.description} onChange={e => updateForm('description', e.target.value)} placeholder="Describe what happened, when, where, and who was involved..." rows={5} />
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Was this witnessed?</Label>
                <Select value={formData.witnessed} onValueChange={v => updateForm('witnessed', v)}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Yes">Yes</SelectItem>
                    <SelectItem value="No">No</SelectItem>
                    <SelectItem value="Unknown">Unknown</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {formData.witnessed === 'Yes' && (
                <div className="space-y-2">
                  <Label>Witness Names</Label>
                  <Input value={formData.witnessNames} onChange={e => updateForm('witnessNames', e.target.value)} placeholder="Names of witnesses" />
                </div>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Checkbox id="ongoing" checked={formData.ongoing} onCheckedChange={v => updateForm('ongoing', v)} />
              <label htmlFor="ongoing" className="text-sm font-medium">Is this ongoing?</label>
            </div>
            {formData.ongoing && (
              <div className="space-y-2">
                <Label className="text-destructive">Immediate Safety Actions Taken *</Label>
                <Textarea value={formData.immediateActions} onChange={e => updateForm('immediateActions', e.target.value)} placeholder="What immediate steps were taken?" rows={3} />
              </div>
            )}
          </div>
        );

      case 'people':
        return (
          <div className="space-y-6">
            <div className="space-y-2">
              <Label>Party Types Involved (select all that apply)</Label>
              <div className="flex flex-wrap gap-2">
                {['Patient', 'Staff', 'Visitor', 'Vendor', 'Unknown'].map(type => (
                  <Badge key={type} variant={formData.partyTypes.includes(type) ? 'default' : 'outline'} className="cursor-pointer" onClick={() => toggleArrayField('partyTypes', type)}>
                    {type}
                  </Badge>
                ))}
              </div>
            </div>
            {formData.partyTypes.includes('Patient') && (
              <div className="space-y-2">
                <Label>Patient Age Group</Label>
                <Select value={formData.patientAgeGroup} onValueChange={v => updateForm('patientAgeGroup', v)}>
                  <SelectTrigger><SelectValue placeholder="Select age group" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Pediatric (0-17)">Pediatric (0-17)</SelectItem>
                    <SelectItem value="Adult (18-64)">Adult (18-64)</SelectItem>
                    <SelectItem value="Geriatric (65+)">Geriatric (65+)</SelectItem>
                    <SelectItem value="Unknown">Unknown</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            {formData.partyTypes.includes('Staff') && (
              <div className="space-y-2">
                <Label>Staff Role</Label>
                <Input value={formData.staffRole} onChange={e => updateForm('staffRole', e.target.value)} placeholder="e.g., Nurse, Physician, Tech" />
              </div>
            )}
            <div className="space-y-2">
              <Label>Number of People Affected</Label>
              <Input type="number" value={formData.numberAffected} onChange={e => updateForm('numberAffected', e.target.value)} placeholder="Enter number" min="0" />
            </div>
          </div>
        );

      case 'impact':
        return (
          <div className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Actual Harm Level *</Label>
                <Select value={formData.actualHarm} onValueChange={v => updateForm('actualHarm', v)}>
                  <SelectTrigger><SelectValue placeholder="Select harm level" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="None">None</SelectItem>
                    <SelectItem value="Mild">Mild</SelectItem>
                    <SelectItem value="Moderate">Moderate</SelectItem>
                    <SelectItem value="Severe">Severe</SelectItem>
                    <SelectItem value="Death">Death</SelectItem>
                    <SelectItem value="Unknown">Unknown</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Potential Harm Level *</Label>
                <Select value={formData.potentialHarm} onValueChange={v => updateForm('potentialHarm', v)}>
                  <SelectTrigger><SelectValue placeholder="Select potential harm" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="None">None</SelectItem>
                    <SelectItem value="Mild">Mild</SelectItem>
                    <SelectItem value="Moderate">Moderate</SelectItem>
                    <SelectItem value="Severe">Severe</SelectItem>
                    <SelectItem value="Catastrophic">Catastrophic</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Outcome Types (select all that apply)</Label>
              <div className="grid gap-2 md:grid-cols-2">
                {OUTCOME_TYPES.map(outcome => (
                  <div key={outcome} className="flex items-center gap-2">
                    <Checkbox id={`outcome-${outcome}`} checked={formData.outcomes.includes(outcome)} onCheckedChange={() => toggleArrayField('outcomes', outcome)} />
                    <label htmlFor={`outcome-${outcome}`} className="text-sm">{outcome}</label>
                  </div>
                ))}
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Did it reach the patient?</Label>
                <Select value={formData.reachedPatient} onValueChange={v => updateForm('reachedPatient', v)}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Yes">Yes</SelectItem>
                    <SelectItem value="No">No</SelectItem>
                    <SelectItem value="Unknown">Unknown</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Sentinel / Never Event suspected?</Label>
                <Select value={formData.sentinelSuspected} onValueChange={v => updateForm('sentinelSuspected', v)}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Yes">Yes</SelectItem>
                    <SelectItem value="No">No</SelectItem>
                    <SelectItem value="Unsure">Unsure</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            {formData.sentinelSuspected === 'Yes' && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>This will trigger escalation routing to Risk/Quality leadership.</AlertDescription>
              </Alert>
            )}
          </div>
        );

      case 'factors':
        return (
          <div className="space-y-6">
            <div className="space-y-2">
              <Label>Contributing Factors (select all that apply)</Label>
              <div className="grid gap-2 md:grid-cols-2">
                {CONTRIBUTING_FACTORS.map(factor => (
                  <div key={factor} className="flex items-center gap-2">
                    <Checkbox id={`factor-${factor}`} checked={formData.contributingFactors.includes(factor)} onCheckedChange={() => toggleArrayField('contributingFactors', factor)} />
                    <label htmlFor={`factor-${factor}`} className="text-sm">{factor}</label>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <Label>What could prevent recurrence?</Label>
              <Textarea value={formData.preventionSuggestion} onChange={e => updateForm('preventionSuggestion', e.target.value)} placeholder="Describe potential preventive measures..." rows={4} />
            </div>
          </div>
        );

      case 'notifications':
        return (
          <div className="space-y-6">
            <p className="text-sm text-muted-foreground">Indicate who has been notified about this event.</p>
            <div className="grid gap-4 md:grid-cols-2">
              {[
                { field: 'notifiedPatientFamily', label: 'Patient / Family' },
                { field: 'notifiedProvider', label: 'Provider' },
                { field: 'notifiedSupervisor', label: 'Supervisor / Manager' },
                { field: 'notifiedRiskQuality', label: 'Risk / Quality' },
                { field: 'notifiedSecurity', label: 'Security' },
                { field: 'notifiedPrivacy', label: 'Privacy Officer' },
              ].map(({ field, label }) => (
                <div key={field} className="space-y-2">
                  <Label>{label}</Label>
                  <Select value={formData[field as keyof typeof formData] as string} onValueChange={v => updateForm(field, v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Yes">Yes</SelectItem>
                      <SelectItem value="No">No</SelectItem>
                      <SelectItem value="NA">N/A</SelectItem>
                      <SelectItem value="Unknown">Unknown</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              ))}
            </div>
            <Separator />
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Regulatory Reporting Required?</Label>
                <Select value={formData.regulatoryRequired} onValueChange={v => updateForm('regulatoryRequired', v)}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Yes">Yes</SelectItem>
                    <SelectItem value="No">No</SelectItem>
                    <SelectItem value="Unsure">Unsure</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Escalation Priority *</Label>
                <Select value={formData.priority} onValueChange={v => updateForm('priority', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Routine">Routine</SelectItem>
                    <SelectItem value="Urgent">Urgent</SelectItem>
                    <SelectItem value="Immediate">Immediate</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Checkbox id="followup" checked={formData.requestFollowUp} onCheckedChange={v => updateForm('requestFollowUp', v)} />
                <label htmlFor="followup" className="text-sm">Request follow-up</label>
              </div>
              {formData.requestFollowUp && (
                <div className="space-y-2">
                  <Label>Preferred Contact Method</Label>
                  <Input value={formData.contactMethod} onChange={e => updateForm('contactMethod', e.target.value)} placeholder="Phone, email, etc." />
                </div>
              )}
            </div>
          </div>
        );

      case 'attachments':
        return (
          <div className="space-y-6">
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>Do not upload unnecessary PHI. Minimize sensitive information in attachments.</AlertDescription>
            </Alert>
            <div className="border-2 border-dashed border-border rounded-lg p-6 hover:border-primary/50 transition-colors">
              <div className="flex flex-col items-center gap-3 text-center">
                <Upload className="h-10 w-10 text-muted-foreground" />
                <div>
                  <Label htmlFor="file-upload" className="cursor-pointer text-primary hover:text-primary/80">Click to upload</Label>
                  <span className="text-muted-foreground"> or drag and drop</span>
                </div>
                <p className="text-xs text-muted-foreground">PDF, images, documents (max 20MB each)</p>
                <Input id="file-upload" type="file" multiple onChange={handleFileChange} className="hidden" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif" />
              </div>
            </div>
            {attachments.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium">Attached files ({attachments.length})</p>
                {attachments.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg bg-muted/30">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-primary" />
                      <div>
                        <p className="text-sm font-medium">{file.name}</p>
                        <p className="text-xs text-muted-foreground">{(file.size / 1024).toFixed(1)} KB</p>
                      </div>
                    </div>
                    <Button type="button" variant="ghost" size="sm" onClick={() => removeAttachment(index)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        );

      case 'reporter':
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <Checkbox id="anonymous" checked={formData.isAnonymous} onCheckedChange={v => updateForm('isAnonymous', v)} />
              <label htmlFor="anonymous" className="text-sm font-medium">Submit anonymously</label>
            </div>
            {!formData.isAnonymous && (
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Your Name *</Label>
                  <Input value={formData.reporterName} onChange={e => updateForm('reporterName', e.target.value)} placeholder="Full name" />
                </div>
                <div className="space-y-2">
                  <Label>Your Email *</Label>
                  <Input type="email" value={formData.reporterEmail} onChange={e => updateForm('reporterEmail', e.target.value)} placeholder="email@organization.org" />
                </div>
              </div>
            )}
            <Separator />
            <div className="space-y-4">
              <div className="flex items-start gap-2">
                <Checkbox id="attestation" checked={formData.attestation} onCheckedChange={v => updateForm('attestation', v)} />
                <label htmlFor="attestation" className="text-sm">
                  I attest that the information provided is accurate to the best of my knowledge. I understand this report is for quality improvement and patient safety purposes.
                </label>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Alert className="rounded-none border-x-0 border-t-0 bg-destructive/10">
        <AlertTriangle className="h-4 w-4 text-destructive" />
        <AlertDescription className="text-destructive">
          <strong>If this is an emergency, call facility emergency response / 911.</strong> Do not use this form for urgent care.
        </AlertDescription>
      </Alert>

      <div className="container mx-auto px-6 py-6 max-w-6xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">New Risk Report</h1>
            {template && (
              <p className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                <FileText className="h-4 w-4" />
                Using template: <strong>{template.name}</strong>
              </p>
            )}
          </div>
          <Button variant="outline" onClick={() => navigate('/risks')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Cancel
          </Button>
        </div>

        {/* Progress */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
            <span>Step {currentStep + 1} of {WIZARD_STEPS.length}</span>
            <span>{Math.round(progress)}% complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step Tabs */}
        <div className="flex gap-1 overflow-x-auto pb-4 mb-6">
          {WIZARD_STEPS.map((step, index) => {
            const Icon = step.icon;
            const isActive = index === currentStep;
            const isComplete = index < currentStep;
            return (
              <button
                key={step.id}
                onClick={() => setCurrentStep(index)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm whitespace-nowrap transition-colors ${
                  isActive ? 'bg-primary text-primary-foreground' : isComplete ? 'bg-status-closed/10 text-status-closed' : 'bg-muted text-muted-foreground hover:bg-muted/80'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span className="hidden md:inline">{step.label}</span>
              </button>
            );
          })}
        </div>

        {/* Main Content with Cross-Reference Panel */}
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            {/* Step Content */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {(() => {
                    const Icon = WIZARD_STEPS[currentStep].icon;
                    return <Icon className="h-5 w-5" />;
                  })()}
                  {WIZARD_STEPS[currentStep].label}
                </CardTitle>
                <CardDescription>
                  {currentStep === 0 && 'Provide basic information about the risk event'}
                  {currentStep === 1 && 'Describe what happened and where'}
                  {currentStep === 2 && 'Identify who was involved (minimal PHI)'}
                  {currentStep === 3 && 'Assess the harm and potential impact'}
                  {currentStep === 4 && 'Identify what may have contributed to this event'}
                  {currentStep === 5 && 'Document notifications and escalation priority'}
                  {currentStep === 6 && 'Attach supporting evidence or documentation'}
                  {currentStep === 7 && 'Confirm your information and submit'}
                </CardDescription>
              </CardHeader>
              <CardContent>{renderStepContent()}</CardContent>
            </Card>

            {/* Navigation */}
            <div className="flex items-center justify-between mt-6">
              <Button variant="outline" onClick={() => setCurrentStep(prev => prev - 1)} disabled={currentStep === 0}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Previous
              </Button>
              <div className="flex gap-2">
                <Button variant="outline" onClick={handleSaveDraft}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Draft
                </Button>
                {currentStep < WIZARD_STEPS.length - 1 ? (
                  <Button onClick={() => setCurrentStep(prev => prev + 1)}>
                    Next
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                ) : (
                  <Button onClick={handleSubmit}>
                    <Send className="h-4 w-4 mr-2" />
                    Submit Report
                  </Button>
                )}
              </div>
            </div>
          </div>

          {/* Cross-Reference Panel */}
          <div className="lg:col-span-1">
            <div className="sticky top-6">
              <LinkedItemsPanel
                references={crossReferences}
                onAdd={handleAddReference}
                onRemove={handleRemoveReference}
              />
              <p className="text-xs text-muted-foreground mt-2 px-1">
                Link related items from ComplianceConnect, EnforcePoint, FeedbackHub, or AuditPro
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
