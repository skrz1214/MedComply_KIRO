import { Shield, FileText, ChevronRight, Plus } from "lucide-react";
import { Link } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { toast } from "sonner";

const initialCategories = [
  {
    id: "falls",
    name: "Falls Prevention",
    description: "Policies and procedures for fall prevention and management",
    documentCount: 12,
    color: "bg-blue-500/10 text-blue-700 border-blue-200",
  },
  {
    id: "medication",
    name: "Medication Safety",
    description: "Medication administration, storage, and safety protocols",
    documentCount: 18,
    color: "bg-purple-500/10 text-purple-700 border-purple-200",
  },
  {
    id: "infection",
    name: "Infection Control",
    description: "Infection prevention and control measures",
    documentCount: 15,
    color: "bg-green-500/10 text-green-700 border-green-200",
  },
  {
    id: "abuse",
    name: "Abuse & Neglect",
    description: "Prevention, detection, and reporting procedures",
    documentCount: 10,
    color: "bg-red-500/10 text-red-700 border-red-200",
  },
  {
    id: "emergency",
    name: "Emergency Preparedness",
    description: "Emergency response and disaster preparedness",
    documentCount: 8,
    color: "bg-orange-500/10 text-orange-700 border-orange-200",
  },
  {
    id: "billing",
    name: "Billing Integrity",
    description: "Billing compliance and documentation standards",
    documentCount: 14,
    color: "bg-cyan-500/10 text-cyan-700 border-cyan-200",
  },
];

const Program = () => {
  const [categories, setCategories] = useState(initialCategories);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newCategory, setNewCategory] = useState({
    name: "",
    description: "",
  });

  const handleAddCategory = () => {
    if (!newCategory.name.trim()) {
      toast.error("Please enter a category name");
      return;
    }
    
    const category = {
      id: newCategory.name.toLowerCase().replace(/\s+/g, "-"),
      name: newCategory.name.trim(),
      description: newCategory.description.trim() || "No description provided",
      documentCount: 0,
      color: "bg-primary/10 text-primary border-primary/20",
    };
    setCategories([...categories, category]);
    setNewCategory({ name: "", description: "" });
    setIsDialogOpen(false);
    toast.success(`Category "${category.name}" added successfully`);
  };
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">RiskGuard</h1>
            </Link>
            <Button variant="outline" asChild>
              <Link to="/">Dashboard</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Page Header */}
      <section className="bg-gradient-to-br from-primary/5 to-secondary/5 border-b border-border">
        <div className="container mx-auto px-6 py-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold text-foreground mb-2">
                Risk Management Program
              </h2>
              <p className="text-muted-foreground">
                Category-based library of SOPs, policies, job aids, and best practices
              </p>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  Add Category
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Category</DialogTitle>
                  <DialogDescription>
                    Create a new risk management category for organizing SOPs, policies, and best practices.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="category-name">Category Name *</Label>
                    <Input
                      id="category-name"
                      placeholder="e.g., Patient Safety"
                      value={newCategory.name}
                      onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category-description">Description (optional)</Label>
                    <Textarea
                      id="category-description"
                      placeholder="Brief description of this category's scope and purpose"
                      value={newCategory.description}
                      onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
                      rows={3}
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-3">
                  <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddCategory}>
                    Add Category
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="container mx-auto px-6 py-8">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {categories.map((category) => (
            <Link key={category.id} to={`/program/${category.id}`}>
              <Card className="group transition-all duration-300 hover:shadow-lg hover:-translate-y-1 cursor-pointer h-full">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-xl mb-2 group-hover:text-primary transition-colors">
                        {category.name}
                      </CardTitle>
                      <CardDescription>{category.description}</CardDescription>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <Badge variant="secondary" className={category.color}>
                      {category.documentCount} documents
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Program;
