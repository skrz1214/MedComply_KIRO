import { Button } from "@/components/ui/button";
import { ArrowLeft, Download } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";

export default function QATestCases() {
  const handleDownloadPDF = () => {
    toast.info("Opening print dialog - select 'Save as PDF' to download");
    window.print();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header - Hidden when printing */}
      <header className="border-b border-border bg-card print:hidden">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" asChild>
              <Link to="/">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
            <Button onClick={handleDownloadPDF}>
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
          </div>
        </div>
      </header>

      {/* QA Test Cases Content */}
      <main className="container mx-auto px-6 py-8 max-w-5xl print:max-w-none print:px-12">
        <article className="prose prose-slate dark:prose-invert max-w-none print:prose-sm">
          {/* Title Page */}
          <div className="text-center mb-12 print:mb-8">
            <h1 className="text-4xl font-bold mb-4 print:text-3xl">RiskGuard</h1>
            <h2 className="text-2xl text-muted-foreground mb-6 print:text-xl">QA Test Cases Document</h2>
            <p className="text-muted-foreground">Version 1.0 | {new Date().toLocaleDateString()}</p>
            <p className="text-muted-foreground">Quality Assurance Testing</p>
          </div>

          <hr className="my-8" />

          {/* Table of Contents */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Table of Contents</h2>
            <ol className="list-decimal list-inside space-y-1 text-sm">
              <li>Authentication & Authorization</li>
              <li>Dashboard Module</li>
              <li>Risk Report Module</li>
              <li>Risk Queue Module</li>
              <li>Evaluate Stage</li>
              <li>Treat Stage</li>
              <li>Monitor Stage</li>
              <li>Reassess Stage</li>
              <li>Template Library</li>
              <li>Program Library</li>
              <li>Scoring Configuration</li>
              <li>Admin Configuration</li>
              <li>Cross-App References</li>
              <li>Role-Based Access</li>
              <li>Performance & Security</li>
            </ol>
          </section>

          <hr className="my-8 print:break-after-page" />

          {/* 1. Authentication & Authorization */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">1. Authentication & Authorization</h2>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-001</td>
                  <td className="border border-border p-2">Valid user login</td>
                  <td className="border border-border p-2">1. Navigate to login page<br/>2. Enter valid credentials<br/>3. Click Login</td>
                  <td className="border border-border p-2">User redirected to Dashboard with correct role permissions</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-002</td>
                  <td className="border border-border p-2">Invalid credentials rejection</td>
                  <td className="border border-border p-2">1. Navigate to login page<br/>2. Enter invalid credentials<br/>3. Click Login</td>
                  <td className="border border-border p-2">Error message displayed, login rejected</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-003</td>
                  <td className="border border-border p-2">Session timeout</td>
                  <td className="border border-border p-2">1. Login successfully<br/>2. Wait for session timeout<br/>3. Attempt action</td>
                  <td className="border border-border p-2">User redirected to login page with session expired message</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-004</td>
                  <td className="border border-border p-2">Password reset flow</td>
                  <td className="border border-border p-2">1. Click "Forgot Password"<br/>2. Enter email<br/>3. Complete reset flow</td>
                  <td className="border border-border p-2">Password reset email sent, new password accepted</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-005</td>
                  <td className="border border-border p-2">Logout functionality</td>
                  <td className="border border-border p-2">1. Login successfully<br/>2. Click Logout<br/>3. Attempt to access protected route</td>
                  <td className="border border-border p-2">Session cleared, redirected to login page</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 2. Dashboard Module */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">2. Dashboard Module</h2>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-010</td>
                  <td className="border border-border p-2">Dashboard KPI display</td>
                  <td className="border border-border p-2">1. Login as any role<br/>2. Navigate to Dashboard</td>
                  <td className="border border-border p-2">KPI cards show: Total Risks, Open Risks, Critical/High count, Closed count</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-011</td>
                  <td className="border border-border p-2">Risk distribution by stage chart</td>
                  <td className="border border-border p-2">1. Navigate to Dashboard<br/>2. Verify stage distribution chart</td>
                  <td className="border border-border p-2">Chart displays risks distributed across Report/Evaluate/Treat/Monitor/Reassess/Closed stages</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-012</td>
                  <td className="border border-border p-2">Risk distribution by level chart</td>
                  <td className="border border-border p-2">1. Navigate to Dashboard<br/>2. Verify level distribution chart</td>
                  <td className="border border-border p-2">Chart displays risks by Low/Medium/High/Critical levels</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-013</td>
                  <td className="border border-border p-2">Recent risks list</td>
                  <td className="border border-border p-2">1. Navigate to Dashboard<br/>2. View recent risks section</td>
                  <td className="border border-border p-2">Recent risks displayed with title, category, status, date</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-014</td>
                  <td className="border border-border p-2">Scope toggle - Organization view</td>
                  <td className="border border-border p-2">1. Login as Admin/Compliance Head<br/>2. Select "Organization" scope</td>
                  <td className="border border-border p-2">Dashboard shows all organizational risks</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-015</td>
                  <td className="border border-border p-2">Scope toggle - Department view</td>
                  <td className="border border-border p-2">1. Login as Department Head<br/>2. Select "Department" scope</td>
                  <td className="border border-border p-2">Dashboard shows only department-specific risks</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-016</td>
                  <td className="border border-border p-2">Scope toggle - Personal view</td>
                  <td className="border border-border p-2">1. Login as any role<br/>2. Select "Personal" scope</td>
                  <td className="border border-border p-2">Dashboard shows only risks created by or assigned to current user</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-017</td>
                  <td className="border border-border p-2">CSV export functionality</td>
                  <td className="border border-border p-2">1. Login as Admin<br/>2. Click CSV Export button</td>
                  <td className="border border-border p-2">CSV file downloaded with all visible risk data</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 3. Risk Report Module */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">3. Risk Report Module</h2>
            
            <h3 className="text-xl font-semibold mb-2">3.1 Report a Risk Entry Points</h3>
            <table className="w-full text-sm border-collapse border border-border mb-6">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-020</td>
                  <td className="border border-border p-2">Report Risk entry point</td>
                  <td className="border border-border p-2">1. Click "Report a Risk" in nav<br/>2. Select "Report Risk" option</td>
                  <td className="border border-border p-2">Navigate to blank risk report form</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-021</td>
                  <td className="border border-border p-2">Use Template entry point</td>
                  <td className="border border-border p-2">1. Click "Report a Risk" in nav<br/>2. Select "Use Template" option</td>
                  <td className="border border-border p-2">Navigate to Template Library for selection</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">3.2 Report Basics Section</h3>
            <table className="w-full text-sm border-collapse border border-border mb-6">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-022</td>
                  <td className="border border-border p-2">Facility selection</td>
                  <td className="border border-border p-2">1. Open risk report form<br/>2. Select facility from dropdown</td>
                  <td className="border border-border p-2">Facility selected, facility type auto-populated</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-023</td>
                  <td className="border border-border p-2">Department selection</td>
                  <td className="border border-border p-2">1. Select facility<br/>2. Select department from dropdown</td>
                  <td className="border border-border p-2">Departments filtered by selected facility</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-024</td>
                  <td className="border border-border p-2">Category selection</td>
                  <td className="border border-border p-2">1. Select category from dropdown</td>
                  <td className="border border-border p-2">Category selected from configurable taxonomy</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-025</td>
                  <td className="border border-border p-2">Report Type selection</td>
                  <td className="border border-border p-2">1. Select report type: Near Miss/Unsafe Condition/Adverse Event/Complaint/Observation</td>
                  <td className="border border-border p-2">Report type selected and stored</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-026</td>
                  <td className="border border-border p-2">Date/Time Discovered</td>
                  <td className="border border-border p-2">1. Select date discovered<br/>2. Select time discovered</td>
                  <td className="border border-border p-2">Date/time picker works, validates not future date</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-027</td>
                  <td className="border border-border p-2">How Identified field</td>
                  <td className="border border-border p-2">1. Select identification method from options</td>
                  <td className="border border-border p-2">Options include: Staff observed, Patient reported, Family reported, Audit, Other</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">3.3 Event/Risk Details Section</h3>
            <table className="w-full text-sm border-collapse border border-border mb-6">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-030</td>
                  <td className="border border-border p-2">Location Type selection</td>
                  <td className="border border-border p-2">1. Select location type from dropdown</td>
                  <td className="border border-border p-2">Options include: Inpatient/Outpatient/ER/OR/Pharmacy/Lab/Other</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-031</td>
                  <td className="border border-border p-2">Title field validation</td>
                  <td className="border border-border p-2">1. Enter title<br/>2. Try to submit without title</td>
                  <td className="border border-border p-2">Title required, max length enforced</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-032</td>
                  <td className="border border-border p-2">Description field validation</td>
                  <td className="border border-border p-2">1. Enter description<br/>2. Try to submit without description</td>
                  <td className="border border-border p-2">Description required, rich text supported</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-033</td>
                  <td className="border border-border p-2">Witnessed field</td>
                  <td className="border border-border p-2">1. Select witnessed option: Yes/No/Unknown</td>
                  <td className="border border-border p-2">Selection saved correctly</td>
                  <td className="border border-border p-2 text-center"><span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-0.5 rounded text-xs">Low</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-034</td>
                  <td className="border border-border p-2">Ongoing risk toggle</td>
                  <td className="border border-border p-2">1. Toggle ongoing: Yes/No</td>
                  <td className="border border-border p-2">Selection affects escalation priority suggestions</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">3.4 People Involved Section</h3>
            <table className="w-full text-sm border-collapse border border-border mb-6">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-040</td>
                  <td className="border border-border p-2">Party type selection - Patient</td>
                  <td className="border border-border p-2">1. Select "Patient" as party type</td>
                  <td className="border border-border p-2">Patient-specific fields appear: masked ID, age group, sex</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-041</td>
                  <td className="border border-border p-2">Party type selection - Staff</td>
                  <td className="border border-border p-2">1. Select "Staff" as party type</td>
                  <td className="border border-border p-2">Staff-specific fields appear: role, employment type</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-042</td>
                  <td className="border border-border p-2">PHI minimization</td>
                  <td className="border border-border p-2">1. Enter patient information<br/>2. Verify displayed data</td>
                  <td className="border border-border p-2">Patient ID masked, minimal PHI collected</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-043</td>
                  <td className="border border-border p-2">Number affected field</td>
                  <td className="border border-border p-2">1. Enter number of people affected</td>
                  <td className="border border-border p-2">Accepts positive integers only</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">3.5 Impact & Severity Section</h3>
            <table className="w-full text-sm border-collapse border border-border mb-6">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-050</td>
                  <td className="border border-border p-2">Actual Harm Level selection</td>
                  <td className="border border-border p-2">1. Select actual harm level</td>
                  <td className="border border-border p-2">Options: None/Mild/Moderate/Severe/Death/Unknown</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-051</td>
                  <td className="border border-border p-2">Potential Harm Level selection</td>
                  <td className="border border-border p-2">1. Select potential harm level</td>
                  <td className="border border-border p-2">Options: None/Mild/Moderate/Severe/Catastrophic</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-052</td>
                  <td className="border border-border p-2">Outcome Types multi-select</td>
                  <td className="border border-border p-2">1. Select multiple outcome types</td>
                  <td className="border border-border p-2">Multiple selections allowed and saved</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-053</td>
                  <td className="border border-border p-2">Sentinel/Never Event detection</td>
                  <td className="border border-border p-2">1. Select "Sentinel Event suspected"<br/>2. Verify escalation routing</td>
                  <td className="border border-border p-2">Risk flagged for immediate review, escalation priority auto-set</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">3.6 Contributing Factors Section</h3>
            <table className="w-full text-sm border-collapse border border-border mb-6">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-060</td>
                  <td className="border border-border p-2">Contributing factors multi-select</td>
                  <td className="border border-border p-2">1. Select multiple contributing factors</td>
                  <td className="border border-border p-2">Options include: Communication, Training, Staffing, Policy gap, Human factors, Equipment, etc.</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-061</td>
                  <td className="border border-border p-2">Prevention suggestion field</td>
                  <td className="border border-border p-2">1. Enter prevention suggestion text</td>
                  <td className="border border-border p-2">Free text field accepts and saves input</td>
                  <td className="border border-border p-2 text-center"><span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-0.5 rounded text-xs">Low</span></td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">3.7 Notifications & Escalation Section</h3>
            <table className="w-full text-sm border-collapse border border-border mb-6">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-070</td>
                  <td className="border border-border p-2">Immediate actions taken</td>
                  <td className="border border-border p-2">1. Enter immediate actions taken</td>
                  <td className="border border-border p-2">Free text field accepts input</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-071</td>
                  <td className="border border-border p-2">Notified parties checkboxes</td>
                  <td className="border border-border p-2">1. Select notified parties</td>
                  <td className="border border-border p-2">Options: Patient/Family, Provider, Supervisor, Risk/Quality, Security, Privacy</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-072</td>
                  <td className="border border-border p-2">Regulatory reporting flag</td>
                  <td className="border border-border p-2">1. Toggle regulatory reporting required</td>
                  <td className="border border-border p-2">Flag saved and visible in Evaluate stage</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-073</td>
                  <td className="border border-border p-2">Escalation Priority selection</td>
                  <td className="border border-border p-2">1. Select escalation priority: Routine/Urgent/Immediate</td>
                  <td className="border border-border p-2">Priority saved and affects workflow routing</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">3.8 Attachments Section</h3>
            <table className="w-full text-sm border-collapse border border-border mb-6">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-080</td>
                  <td className="border border-border p-2">File upload functionality</td>
                  <td className="border border-border p-2">1. Click upload button<br/>2. Select file(s)</td>
                  <td className="border border-border p-2">Files uploaded, progress shown, file list updated</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-081</td>
                  <td className="border border-border p-2">File type validation</td>
                  <td className="border border-border p-2">1. Try to upload invalid file type</td>
                  <td className="border border-border p-2">Error message shown, invalid file rejected</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-082</td>
                  <td className="border border-border p-2">PHI warning display</td>
                  <td className="border border-border p-2">1. Navigate to attachments section</td>
                  <td className="border border-border p-2">PHI warning banner displayed prominently</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-083</td>
                  <td className="border border-border p-2">Evidence type selection</td>
                  <td className="border border-border p-2">1. Upload file<br/>2. Select evidence type</td>
                  <td className="border border-border p-2">Evidence type saved with attachment</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-084</td>
                  <td className="border border-border p-2">Confidentiality label</td>
                  <td className="border border-border p-2">1. Upload file<br/>2. Select confidentiality level</td>
                  <td className="border border-border p-2">Confidentiality label saved and enforced</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">3.9 Reporter Section</h3>
            <table className="w-full text-sm border-collapse border border-border mb-6">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-090</td>
                  <td className="border border-border p-2">Reporter identity auto-fill</td>
                  <td className="border border-border p-2">1. Navigate to reporter section</td>
                  <td className="border border-border p-2">Logged-in user info auto-populated</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-091</td>
                  <td className="border border-border p-2">Anonymous reporting toggle</td>
                  <td className="border border-border p-2">1. Enable anonymous reporting (if policy allows)</td>
                  <td className="border border-border p-2">Reporter identity hidden from display, audit trace maintained</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-092</td>
                  <td className="border border-border p-2">Attestation checkbox required</td>
                  <td className="border border-border p-2">1. Try to submit without attestation</td>
                  <td className="border border-border p-2">Submission blocked, error displayed</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">3.10 Form Actions</h3>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-095</td>
                  <td className="border border-border p-2">Save Draft functionality</td>
                  <td className="border border-border p-2">1. Fill partial form<br/>2. Click "Save Draft"</td>
                  <td className="border border-border p-2">Draft saved, confirmation shown, risk appears in queue with Draft status</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-096</td>
                  <td className="border border-border p-2">Submit Report functionality</td>
                  <td className="border border-border p-2">1. Fill all required fields<br/>2. Click "Submit Report"</td>
                  <td className="border border-border p-2">Report submitted, confirmation shown, risk moves to Evaluate stage</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-097</td>
                  <td className="border border-border p-2">Form validation on submit</td>
                  <td className="border border-border p-2">1. Leave required fields empty<br/>2. Click Submit</td>
                  <td className="border border-border p-2">Validation errors displayed for each missing required field</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-098</td>
                  <td className="border border-border p-2">Autosave functionality</td>
                  <td className="border border-border p-2">1. Make changes to form<br/>2. Wait for autosave interval</td>
                  <td className="border border-border p-2">Form auto-saved, indicator shown</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-099</td>
                  <td className="border border-border p-2">Emergency banner display</td>
                  <td className="border border-border p-2">1. Navigate to risk report form</td>
                  <td className="border border-border p-2">Emergency banner visible: "If this is an emergency, call facility emergency response / 911"</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 4. Risk Queue Module */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">4. Risk Queue Module</h2>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-100</td>
                  <td className="border border-border p-2">Risk list display</td>
                  <td className="border border-border p-2">1. Navigate to Risk Queue</td>
                  <td className="border border-border p-2">List displays all risks with: ID, Title, Category, Status, Risk Level, Assignee, Date</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-101</td>
                  <td className="border border-border p-2">Filter by stage</td>
                  <td className="border border-border p-2">1. Select stage filter<br/>2. Apply filter</td>
                  <td className="border border-border p-2">List shows only risks in selected stage</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-102</td>
                  <td className="border border-border p-2">Filter by risk level</td>
                  <td className="border border-border p-2">1. Select risk level filter<br/>2. Apply filter</td>
                  <td className="border border-border p-2">List shows only risks with selected level</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-103</td>
                  <td className="border border-border p-2">Filter by category</td>
                  <td className="border border-border p-2">1. Select category filter<br/>2. Apply filter</td>
                  <td className="border border-border p-2">List shows only risks in selected category</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-104</td>
                  <td className="border border-border p-2">Search functionality</td>
                  <td className="border border-border p-2">1. Enter search term<br/>2. Execute search</td>
                  <td className="border border-border p-2">Results filtered by title, description, ID match</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-105</td>
                  <td className="border border-border p-2">Sort functionality</td>
                  <td className="border border-border p-2">1. Click column header to sort</td>
                  <td className="border border-border p-2">List sorted by selected column (asc/desc toggle)</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-106</td>
                  <td className="border border-border p-2">Pagination</td>
                  <td className="border border-border p-2">1. Navigate through pages<br/>2. Change page size</td>
                  <td className="border border-border p-2">Pagination controls work correctly</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-107</td>
                  <td className="border border-border p-2">Risk detail navigation</td>
                  <td className="border border-border p-2">1. Click on a risk row</td>
                  <td className="border border-border p-2">Navigate to Risk Detail view</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-108</td>
                  <td className="border border-border p-2">Scope toggle integration</td>
                  <td className="border border-border p-2">1. Change scope toggle<br/>2. Verify list updates</td>
                  <td className="border border-border p-2">List filtered according to selected scope</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 5. Evaluate Stage */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">5. Evaluate Stage</h2>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-110</td>
                  <td className="border border-border p-2">Stage stepper display</td>
                  <td className="border border-border p-2">1. Open risk in Evaluate stage</td>
                  <td className="border border-border p-2">Stage stepper shows Evaluate as current, previous stages completed</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-111</td>
                  <td className="border border-border p-2">Category confirmation/adjustment</td>
                  <td className="border border-border p-2">1. Review pre-filled category<br/>2. Adjust if needed</td>
                  <td className="border border-border p-2">Category can be confirmed or changed with audit log entry</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-112</td>
                  <td className="border border-border p-2">Likelihood scoring (1-5)</td>
                  <td className="border border-border p-2">1. Select likelihood value 1-5</td>
                  <td className="border border-border p-2">Value selected and stored, score recalculated</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-113</td>
                  <td className="border border-border p-2">Impact scoring (1-5)</td>
                  <td className="border border-border p-2">1. Select impact value 1-5</td>
                  <td className="border border-border p-2">Value selected and stored, score recalculated</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-114</td>
                  <td className="border border-border p-2">Readiness scoring (1-3)</td>
                  <td className="border border-border p-2">1. Select readiness value 1-3</td>
                  <td className="border border-border p-2">Value selected and stored, readiness factor calculated</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-115</td>
                  <td className="border border-border p-2">Score calculation verification</td>
                  <td className="border border-border p-2">1. Set L=3, I=4, R=2<br/>2. Verify calculated score</td>
                  <td className="border border-border p-2">baseScore=12, readinessFactor=0.67, adjustedScore=8 (rounded)</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-116</td>
                  <td className="border border-border p-2">Risk level determination</td>
                  <td className="border border-border p-2">1. Complete scoring<br/>2. Verify risk level</td>
                  <td className="border border-border p-2">Risk level (Low/Medium/High/Critical) mapped from score using config bands</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-117</td>
                  <td className="border border-border p-2">Score override functionality</td>
                  <td className="border border-border p-2">1. Login as authorized role<br/>2. Override score<br/>3. Enter override reason</td>
                  <td className="border border-border p-2">Override applied with audit entry, reason required</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-118</td>
                  <td className="border border-border p-2">Evaluation summary field</td>
                  <td className="border border-border p-2">1. Enter evaluation summary</td>
                  <td className="border border-border p-2">Summary saved, required for stage completion</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-119</td>
                  <td className="border border-border p-2">Decision: Proceed to Treat</td>
                  <td className="border border-border p-2">1. Complete evaluation<br/>2. Select "Proceed to Treat"</td>
                  <td className="border border-border p-2">Risk moves to Treat stage</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-120</td>
                  <td className="border border-border p-2">Decision: Skip to Monitor</td>
                  <td className="border border-border p-2">1. Complete evaluation<br/>2. Select "Skip to Monitor"</td>
                  <td className="border border-border p-2">Risk moves directly to Monitor stage</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-121</td>
                  <td className="border border-border p-2">Decision: Close risk</td>
                  <td className="border border-border p-2">1. Complete evaluation<br/>2. Select "Close"<br/>3. Enter closure reason</td>
                  <td className="border border-border p-2">Closure reason + approver signature required, risk closed</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-122</td>
                  <td className="border border-border p-2">Send Back to Report</td>
                  <td className="border border-border p-2">1. Click "Send Back"<br/>2. Enter reason</td>
                  <td className="border border-border p-2">Risk returned to Report stage, reason logged</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-123</td>
                  <td className="border border-border p-2">Re-assignment functionality</td>
                  <td className="border border-border p-2">1. Click "Re-assign"<br/>2. Select new assignee</td>
                  <td className="border border-border p-2">Risk reassigned, notification sent to new assignee</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 6. Treat Stage */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">6. Treat Stage</h2>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-130</td>
                  <td className="border border-border p-2">ROME Decision - Retain</td>
                  <td className="border border-border p-2">1. Select "Retain" option</td>
                  <td className="border border-border p-2">Retain selected, justification required</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-131</td>
                  <td className="border border-border p-2">ROME Decision - Optimize</td>
                  <td className="border border-border p-2">1. Select "Optimize" option</td>
                  <td className="border border-border p-2">Optimize selected, mitigation plan section enabled</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-132</td>
                  <td className="border border-border p-2">ROME Decision - Mitigate</td>
                  <td className="border border-border p-2">1. Select "Mitigate" option</td>
                  <td className="border border-border p-2">Mitigate selected, mitigation plan required</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-133</td>
                  <td className="border border-border p-2">ROME Decision - Eliminate</td>
                  <td className="border border-border p-2">1. Select "Eliminate" option</td>
                  <td className="border border-border p-2">Eliminate selected, elimination plan required</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-134</td>
                  <td className="border border-border p-2">Treatment type selection</td>
                  <td className="border border-border p-2">1. Select treatment type</td>
                  <td className="border border-border p-2">Options: CAPA, Process change, Training, Tech fix, Policy update, Other</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-135</td>
                  <td className="border border-border p-2">Add action task</td>
                  <td className="border border-border p-2">1. Click "Add Task"<br/>2. Enter task details</td>
                  <td className="border border-border p-2">Task added with: description, owner, due date, status</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-136</td>
                  <td className="border border-border p-2">Update task status</td>
                  <td className="border border-border p-2">1. Change task status</td>
                  <td className="border border-border p-2">Status updated: Pending/In Progress/Completed</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-137</td>
                  <td className="border border-border p-2">Interim controls documentation</td>
                  <td className="border border-border p-2">1. Enter interim control measures</td>
                  <td className="border border-border p-2">Interim controls saved</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-138</td>
                  <td className="border border-border p-2">Expected outcome documentation</td>
                  <td className="border border-border p-2">1. Enter expected outcome</td>
                  <td className="border border-border p-2">Expected outcome saved</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-139</td>
                  <td className="border border-border p-2">Proceed to Monitor</td>
                  <td className="border border-border p-2">1. Complete treatment plan<br/>2. Click "Proceed to Monitor"</td>
                  <td className="border border-border p-2">Risk moves to Monitor stage</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-140</td>
                  <td className="border border-border p-2">Send Back to Evaluate</td>
                  <td className="border border-border p-2">1. Click "Send Back"<br/>2. Enter reason</td>
                  <td className="border border-border p-2">Risk returned to Evaluate stage</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 7. Monitor Stage */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">7. Monitor Stage</h2>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-150</td>
                  <td className="border border-border p-2">Add monitoring metric</td>
                  <td className="border border-border p-2">1. Click "Add Metric"<br/>2. Enter metric details</td>
                  <td className="border border-border p-2">Metric added: name, target, frequency, data source, owner</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-151</td>
                  <td className="border border-border p-2">Metric required validation</td>
                  <td className="border border-border p-2">1. Try to proceed without metrics</td>
                  <td className="border border-border p-2">Error: At least one metric required</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-152</td>
                  <td className="border border-border p-2">Add monitoring log entry</td>
                  <td className="border border-border p-2">1. Click "Add Log Entry"<br/>2. Enter log details</td>
                  <td className="border border-border p-2">Log entry added: date, note, status</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-153</td>
                  <td className="border border-border p-2">Overdue task alert</td>
                  <td className="border border-border p-2">1. Create task with past due date<br/>2. Verify alert display</td>
                  <td className="border border-border p-2">Overdue alert displayed prominently</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-154</td>
                  <td className="border border-border p-2">Missed monitoring cycle alert</td>
                  <td className="border border-border p-2">1. Set monitoring frequency<br/>2. Miss scheduled cycle</td>
                  <td className="border border-border p-2">Alert displayed for missed monitoring cycle</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-155</td>
                  <td className="border border-border p-2">Proceed to Reassess</td>
                  <td className="border border-border p-2">1. Complete monitoring<br/>2. Click "Proceed to Reassess"</td>
                  <td className="border border-border p-2">Risk moves to Reassess stage</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-156</td>
                  <td className="border border-border p-2">Send Back to Treat</td>
                  <td className="border border-border p-2">1. Click "Send Back"<br/>2. Enter reason</td>
                  <td className="border border-border p-2">Risk returned to Treat stage</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 8. Reassess Stage */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">8. Reassess Stage</h2>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-160</td>
                  <td className="border border-border p-2">Effectiveness review entry</td>
                  <td className="border border-border p-2">1. Enter effectiveness review with evidence</td>
                  <td className="border border-border p-2">Review documented with supporting evidence</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-161</td>
                  <td className="border border-border p-2">Residual likelihood scoring</td>
                  <td className="border border-border p-2">1. Enter residual likelihood (1-5)</td>
                  <td className="border border-border p-2">Residual likelihood captured</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-162</td>
                  <td className="border border-border p-2">Residual impact scoring</td>
                  <td className="border border-border p-2">1. Enter residual impact (1-5)</td>
                  <td className="border border-border p-2">Residual impact captured</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-163</td>
                  <td className="border border-border p-2">Residual score calculation</td>
                  <td className="border border-border p-2">1. Enter residual L and I<br/>2. Verify calculated score</td>
                  <td className="border border-border p-2">Residual score and level calculated correctly</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-164</td>
                  <td className="border border-border p-2">Decision: Back to Treat (loop)</td>
                  <td className="border border-border p-2">1. Complete reassessment<br/>2. Select "Back to Treat"</td>
                  <td className="border border-border p-2">Risk returns to Treat stage for additional treatment</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-165</td>
                  <td className="border border-border p-2">Decision: Close risk</td>
                  <td className="border border-border p-2">1. Complete reassessment<br/>2. Select "Close Risk"<br/>3. Enter closure details</td>
                  <td className="border border-border p-2">Risk closed with closure reason and summary</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-166</td>
                  <td className="border border-border p-2">Closed risk read-only state</td>
                  <td className="border border-border p-2">1. View closed risk</td>
                  <td className="border border-border p-2">All fields read-only, only post-closure notes editable (if policy permits)</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 9. Template Library */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">9. Template Library</h2>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-170</td>
                  <td className="border border-border p-2">Template list display</td>
                  <td className="border border-border p-2">1. Navigate to Templates</td>
                  <td className="border border-border p-2">Templates displayed with: name, description, category, tags, visibility</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-171</td>
                  <td className="border border-border p-2">Create new template</td>
                  <td className="border border-border p-2">1. Click "Create Template"<br/>2. Fill template details<br/>3. Save</td>
                  <td className="border border-border p-2">New template created with: name, description, default values, visibility scope</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-172</td>
                  <td className="border border-border p-2">Use template</td>
                  <td className="border border-border p-2">1. Select template<br/>2. Click "Use Template"</td>
                  <td className="border border-border p-2">New risk form opens with template defaults pre-filled</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-173</td>
                  <td className="border border-border p-2">Duplicate template</td>
                  <td className="border border-border p-2">1. Select template<br/>2. Click "Duplicate"</td>
                  <td className="border border-border p-2">Copy created with editable name</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-174</td>
                  <td className="border border-border p-2">Edit template</td>
                  <td className="border border-border p-2">1. Select template<br/>2. Click "Edit"<br/>3. Modify and save</td>
                  <td className="border border-border p-2">Template updated, version incremented</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-175</td>
                  <td className="border border-border p-2">Archive template</td>
                  <td className="border border-border p-2">1. Select template<br/>2. Click "Archive"</td>
                  <td className="border border-border p-2">Template archived, no longer visible in active list</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-176</td>
                  <td className="border border-border p-2">Template visibility - Private</td>
                  <td className="border border-border p-2">1. Create template with Private visibility<br/>2. Login as different user</td>
                  <td className="border border-border p-2">Template only visible to creator</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-177</td>
                  <td className="border border-border p-2">Template visibility - Department</td>
                  <td className="border border-border p-2">1. Create template with Department visibility<br/>2. Login as user in same/different department</td>
                  <td className="border border-border p-2">Template visible only to department members</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-178</td>
                  <td className="border border-border p-2">Template visibility - Organization</td>
                  <td className="border border-border p-2">1. Create template with Organization visibility</td>
                  <td className="border border-border p-2">Template visible to all organization users</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-179</td>
                  <td className="border border-border p-2">Template search</td>
                  <td className="border border-border p-2">1. Enter search term</td>
                  <td className="border border-border p-2">Templates filtered by name, description, tags</td>
                  <td className="border border-border p-2 text-center"><span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-0.5 rounded text-xs">Low</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-180</td>
                  <td className="border border-border p-2">Template filter by category</td>
                  <td className="border border-border p-2">1. Select category filter</td>
                  <td className="border border-border p-2">Templates filtered by selected category</td>
                  <td className="border border-border p-2 text-center"><span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-0.5 rounded text-xs">Low</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 10. Program Library */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">10. Program Library</h2>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-190</td>
                  <td className="border border-border p-2">Program categories display</td>
                  <td className="border border-border p-2">1. Navigate to Program</td>
                  <td className="border border-border p-2">Categories displayed with document counts</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-191</td>
                  <td className="border border-border p-2">Create category</td>
                  <td className="border border-border p-2">1. Click "Add Category"<br/>2. Enter category name<br/>3. Save</td>
                  <td className="border border-border p-2">New category created</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-192</td>
                  <td className="border border-border p-2">Add document to category</td>
                  <td className="border border-border p-2">1. Select category<br/>2. Click "Add Document"<br/>3. Enter metadata and upload</td>
                  <td className="border border-border p-2">Document added with: title, type, owner, effective date, status</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-193</td>
                  <td className="border border-border p-2">View document</td>
                  <td className="border border-border p-2">1. Click on document</td>
                  <td className="border border-border p-2">Document details and file displayed</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-194</td>
                  <td className="border border-border p-2">Edit document metadata</td>
                  <td className="border border-border p-2">1. Select document<br/>2. Click "Edit"<br/>3. Modify and save</td>
                  <td className="border border-border p-2">Document metadata updated</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-195</td>
                  <td className="border border-border p-2">Delete document</td>
                  <td className="border border-border p-2">1. Select document<br/>2. Click "Delete"<br/>3. Confirm</td>
                  <td className="border border-border p-2">Document removed from library</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 11. Scoring Configuration */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">11. Scoring Configuration</h2>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-200</td>
                  <td className="border border-border p-2">View scoring configurations</td>
                  <td className="border border-border p-2">1. Navigate to Scoring Settings</td>
                  <td className="border border-border p-2">Org-level, Category, and Category+Dept configs displayed</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-201</td>
                  <td className="border border-border p-2">Create Org-level config</td>
                  <td className="border border-border p-2">1. Create organization default scoring config</td>
                  <td className="border border-border p-2">Org-level config saved as default</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-202</td>
                  <td className="border border-border p-2">Create Category-level config</td>
                  <td className="border border-border p-2">1. Select category<br/>2. Create scoring config</td>
                  <td className="border border-border p-2">Category config overrides Org-level for that category</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-203</td>
                  <td className="border border-border p-2">Create Category+Dept config</td>
                  <td className="border border-border p-2">1. Select category and department<br/>2. Create scoring config</td>
                  <td className="border border-border p-2">Category+Dept config overrides both Org and Category level</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-204</td>
                  <td className="border border-border p-2">Config precedence verification</td>
                  <td className="border border-border p-2">1. Create configs at all 3 levels<br/>2. Create risk in that category+dept<br/>3. Verify scoring uses correct config</td>
                  <td className="border border-border p-2">Category+Dept config applied (highest precedence)</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-205</td>
                  <td className="border border-border p-2">Risk level band configuration</td>
                  <td className="border border-border p-2">1. Configure risk level bands (score ranges)</td>
                  <td className="border border-border p-2">Bands saved: Low (1-4), Medium (5-9), High (10-15), Critical (16-25)</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-206</td>
                  <td className="border border-border p-2">Config versioning</td>
                  <td className="border border-border p-2">1. Modify existing config<br/>2. Save changes</td>
                  <td className="border border-border p-2">New version created, original version preserved</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-207</td>
                  <td className="border border-border p-2">Historical scoring preservation</td>
                  <td className="border border-border p-2">1. View previously evaluated risk<br/>2. Modify scoring config<br/>3. Re-view risk</td>
                  <td className="border border-border p-2">Risk retains original score/level from evaluation time config</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 12. Admin Configuration */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">12. Admin Configuration</h2>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-210</td>
                  <td className="border border-border p-2">Risk categories management</td>
                  <td className="border border-border p-2">1. Add/edit/delete risk categories</td>
                  <td className="border border-border p-2">Categories updated, reflected in report form dropdowns</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-211</td>
                  <td className="border border-border p-2">Harm level definitions</td>
                  <td className="border border-border p-2">1. Configure harm level definitions</td>
                  <td className="border border-border p-2">Harm levels available in report form</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-212</td>
                  <td className="border border-border p-2">Outcome types management</td>
                  <td className="border border-border p-2">1. Add/edit/delete outcome types</td>
                  <td className="border border-border p-2">Outcome types updated in report form</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-213</td>
                  <td className="border border-border p-2">Report types management</td>
                  <td className="border border-border p-2">1. Add/edit/delete report types</td>
                  <td className="border border-border p-2">Report types updated in form</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-214</td>
                  <td className="border border-border p-2">Contributing factors management</td>
                  <td className="border border-border p-2">1. Add/edit/delete contributing factors</td>
                  <td className="border border-border p-2">Factors updated in report form multi-select</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-215</td>
                  <td className="border border-border p-2">Treatment types management</td>
                  <td className="border border-border p-2">1. Add/edit/delete treatment types</td>
                  <td className="border border-border p-2">Treatment types updated in Treat stage</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-216</td>
                  <td className="border border-border p-2">Facility types management</td>
                  <td className="border border-border p-2">1. Add/edit/delete facility types</td>
                  <td className="border border-border p-2">Facility types available in form</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-217</td>
                  <td className="border border-border p-2">Departments management</td>
                  <td className="border border-border p-2">1. Add/edit/delete departments</td>
                  <td className="border border-border p-2">Departments available in form and scope toggle</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-218</td>
                  <td className="border border-border p-2">Anonymous reporting policy</td>
                  <td className="border border-border p-2">1. Toggle anonymous reporting setting</td>
                  <td className="border border-border p-2">Anonymous toggle visibility controlled in report form</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-219</td>
                  <td className="border border-border p-2">Required fields by stage</td>
                  <td className="border border-border p-2">1. Configure required fields for each stage</td>
                  <td className="border border-border p-2">Stage validation enforces configured required fields</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 13. Cross-App References */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">13. Cross-App References</h2>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-220</td>
                  <td className="border border-border p-2">Cross-reference panel display</td>
                  <td className="border border-border p-2">1. Open risk report/detail view</td>
                  <td className="border border-border p-2">Cross-reference panel visible on right side</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-221</td>
                  <td className="border border-border p-2">Search ComplianceConnect records</td>
                  <td className="border border-border p-2">1. Select ComplianceConnect app<br/>2. Search for records</td>
                  <td className="border border-border p-2">Policies, controls, citations, CAPA records searchable</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-222</td>
                  <td className="border border-border p-2">Search EnforcePoint records</td>
                  <td className="border border-border p-2">1. Select EnforcePoint app<br/>2. Search for records</td>
                  <td className="border border-border p-2">Enforcement actions, investigations, notices searchable</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-223</td>
                  <td className="border border-border p-2">Search FeedbackHub records</td>
                  <td className="border border-border p-2">1. Select FeedbackHub app<br/>2. Search for records</td>
                  <td className="border border-border p-2">Complaints, grievances, feedback records searchable</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-224</td>
                  <td className="border border-border p-2">Search AuditPro records</td>
                  <td className="border border-border p-2">1. Select AuditPro app<br/>2. Search for records</td>
                  <td className="border border-border p-2">Audits, findings, evidence, action plans searchable</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-225</td>
                  <td className="border border-border p-2">Add cross-reference link</td>
                  <td className="border border-border p-2">1. Search and select record<br/>2. Select relationship type<br/>3. Add optional notes</td>
                  <td className="border border-border p-2">Link created with relationship type and notes</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-226</td>
                  <td className="border border-border p-2">Relationship type selection</td>
                  <td className="border border-border p-2">1. View relationship type options</td>
                  <td className="border border-border p-2">Options: Source of Risk, Related Complaint, Related Audit Finding, Control/Policy Reference, Evidence, Mitigation/CAPA, Duplicate/Similar, Other</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-227</td>
                  <td className="border border-border p-2">Remove cross-reference link</td>
                  <td className="border border-border p-2">1. Click remove on existing link</td>
                  <td className="border border-border p-2">Link removed from risk</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-228</td>
                  <td className="border border-border p-2">Permission-restricted record display</td>
                  <td className="border border-border p-2">1. Link record user lacks access to<br/>2. View as restricted user</td>
                  <td className="border border-border p-2">Record shows "Restricted" indicator, link preserved</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 14. Role-Based Access */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">14. Role-Based Access</h2>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-230</td>
                  <td className="border border-border p-2">Admin role - Full access</td>
                  <td className="border border-border p-2">1. Login as Admin<br/>2. Verify access to all modules</td>
                  <td className="border border-border p-2">Access to: all risks, scoring config, templates, program, admin config</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-231</td>
                  <td className="border border-border p-2">Compliance Head - Full access</td>
                  <td className="border border-border p-2">1. Login as Compliance Head<br/>2. Verify access</td>
                  <td className="border border-border p-2">Access to: all risks, scoring config, templates, program, close risks</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-232</td>
                  <td className="border border-border p-2">Department Head - Scoped access</td>
                  <td className="border border-border p-2">1. Login as Department Head<br/>2. Verify access</td>
                  <td className="border border-border p-2">Access scoped to department only, all features within scope</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-233</td>
                  <td className="border border-border p-2">Staff - Limited access</td>
                  <td className="border border-border p-2">1. Login as Staff<br/>2. Verify access</td>
                  <td className="border border-border p-2">Can: report risks, update workflow. Cannot: modify scoring, templates, program, admin</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-234</td>
                  <td className="border border-border p-2">Staff - No scope toggle</td>
                  <td className="border border-border p-2">1. Login as Staff<br/>2. Check for scope toggle</td>
                  <td className="border border-border p-2">Scope toggle not visible, Personal scope only</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-235</td>
                  <td className="border border-border p-2">Scoring config access control</td>
                  <td className="border border-border p-2">1. Login as Staff<br/>2. Try to access Scoring Settings</td>
                  <td className="border border-border p-2">Access denied or menu hidden</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-236</td>
                  <td className="border border-border p-2">Template creation access control</td>
                  <td className="border border-border p-2">1. Login as Staff<br/>2. Try to create template</td>
                  <td className="border border-border p-2">Create button hidden or action denied</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-237</td>
                  <td className="border border-border p-2">Admin config access control</td>
                  <td className="border border-border p-2">1. Login as Staff<br/>2. Try to access Admin Config</td>
                  <td className="border border-border p-2">Access denied or menu hidden</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 15. Performance & Security */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">15. Performance & Security</h2>
            
            <h3 className="text-xl font-semibold mb-2">15.1 Performance Tests</h3>
            <table className="w-full text-sm border-collapse border border-border mb-6">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-240</td>
                  <td className="border border-border p-2">Page load time</td>
                  <td className="border border-border p-2">1. Clear cache<br/>2. Load dashboard page<br/>3. Measure load time</td>
                  <td className="border border-border p-2">Page loads in less than 3 seconds</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-241</td>
                  <td className="border border-border p-2">API response time</td>
                  <td className="border border-border p-2">1. Monitor API calls<br/>2. Measure response times</td>
                  <td className="border border-border p-2">API responses under 500ms</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-242</td>
                  <td className="border border-border p-2">Large data set handling</td>
                  <td className="border border-border p-2">1. Load Risk Queue with 1000+ risks</td>
                  <td className="border border-border p-2">Page remains responsive, pagination works</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">15.2 Security Tests</h3>
            <table className="w-full text-sm border-collapse border border-border mb-6">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-250</td>
                  <td className="border border-border p-2">XSS prevention</td>
                  <td className="border border-border p-2">1. Enter script tags in form fields<br/>2. Submit and view</td>
                  <td className="border border-border p-2">Scripts escaped, not executed</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-251</td>
                  <td className="border border-border p-2">SQL injection prevention</td>
                  <td className="border border-border p-2">1. Enter SQL injection patterns in search/filters</td>
                  <td className="border border-border p-2">Queries parameterized, injection fails</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-252</td>
                  <td className="border border-border p-2">CSRF protection</td>
                  <td className="border border-border p-2">1. Attempt cross-site request forgery</td>
                  <td className="border border-border p-2">CSRF tokens validated, request rejected</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-253</td>
                  <td className="border border-border p-2">Unauthorized access prevention</td>
                  <td className="border border-border p-2">1. Try to access restricted URLs directly</td>
                  <td className="border border-border p-2">Redirected to login or access denied</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-254</td>
                  <td className="border border-border p-2">Audit logging verification</td>
                  <td className="border border-border p-2">1. Perform various actions<br/>2. Check audit log</td>
                  <td className="border border-border p-2">All edits, transitions, overrides logged with user/timestamp</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-255</td>
                  <td className="border border-border p-2">Anonymous report audit trace</td>
                  <td className="border border-border p-2">1. Submit anonymous report<br/>2. Check internal audit</td>
                  <td className="border border-border p-2">Reporter identity hidden from UI but maintained in audit trace</td>
                  <td className="border border-border p-2 text-center"><span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">High</span></td>
                </tr>
              </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">15.3 Accessibility Tests</h3>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left w-16">TC ID</th>
                  <th className="border border-border p-2 text-left">Test Case</th>
                  <th className="border border-border p-2 text-left">Steps</th>
                  <th className="border border-border p-2 text-left">Expected Result</th>
                  <th className="border border-border p-2 text-left w-20">Priority</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-260</td>
                  <td className="border border-border p-2">Keyboard navigation</td>
                  <td className="border border-border p-2">1. Navigate entire app using keyboard only</td>
                  <td className="border border-border p-2">All interactive elements accessible via Tab/Enter/Space</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-261</td>
                  <td className="border border-border p-2">Screen reader compatibility</td>
                  <td className="border border-border p-2">1. Use screen reader to navigate app</td>
                  <td className="border border-border p-2">All elements have appropriate ARIA labels</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-262</td>
                  <td className="border border-border p-2">Focus management</td>
                  <td className="border border-border p-2">1. Open modals/dialogs<br/>2. Verify focus handling</td>
                  <td className="border border-border p-2">Focus trapped in modals, returned on close</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-263</td>
                  <td className="border border-border p-2">Color contrast</td>
                  <td className="border border-border p-2">1. Run contrast checker on all pages</td>
                  <td className="border border-border p-2">All text meets WCAG 2.1 AA contrast ratios</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
                <tr>
                  <td className="border border-border p-2 font-mono">QA-264</td>
                  <td className="border border-border p-2">Error announcement</td>
                  <td className="border border-border p-2">1. Trigger form validation errors</td>
                  <td className="border border-border p-2">Errors announced to screen readers, focus moved to error</td>
                  <td className="border border-border p-2 text-center"><span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">Medium</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          <hr className="my-8" />

          {/* Summary */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Test Case Summary</h2>
            <table className="w-full text-sm border-collapse border border-border">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-2 text-left">Section</th>
                  <th className="border border-border p-2 text-center">High Priority</th>
                  <th className="border border-border p-2 text-center">Medium Priority</th>
                  <th className="border border-border p-2 text-center">Low Priority</th>
                  <th className="border border-border p-2 text-center">Total</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-2">1. Authentication</td>
                  <td className="border border-border p-2 text-center">3</td>
                  <td className="border border-border p-2 text-center">2</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center font-semibold">5</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">2. Dashboard</td>
                  <td className="border border-border p-2 text-center">4</td>
                  <td className="border border-border p-2 text-center">4</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center font-semibold">8</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">3. Risk Report</td>
                  <td className="border border-border p-2 text-center">18</td>
                  <td className="border border-border p-2 text-center">14</td>
                  <td className="border border-border p-2 text-center">2</td>
                  <td className="border border-border p-2 text-center font-semibold">34</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">4. Risk Queue</td>
                  <td className="border border-border p-2 text-center">3</td>
                  <td className="border border-border p-2 text-center">6</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center font-semibold">9</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">5. Evaluate Stage</td>
                  <td className="border border-border p-2 text-center">9</td>
                  <td className="border border-border p-2 text-center">5</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center font-semibold">14</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">6. Treat Stage</td>
                  <td className="border border-border p-2 text-center">5</td>
                  <td className="border border-border p-2 text-center">6</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center font-semibold">11</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">7. Monitor Stage</td>
                  <td className="border border-border p-2 text-center">3</td>
                  <td className="border border-border p-2 text-center">4</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center font-semibold">7</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">8. Reassess Stage</td>
                  <td className="border border-border p-2 text-center">4</td>
                  <td className="border border-border p-2 text-center">3</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center font-semibold">7</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">9. Template Library</td>
                  <td className="border border-border p-2 text-center">2</td>
                  <td className="border border-border p-2 text-center">7</td>
                  <td className="border border-border p-2 text-center">2</td>
                  <td className="border border-border p-2 text-center font-semibold">11</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">10. Program Library</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center">6</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center font-semibold">6</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">11. Scoring Config</td>
                  <td className="border border-border p-2 text-center">5</td>
                  <td className="border border-border p-2 text-center">3</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center font-semibold">8</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">12. Admin Config</td>
                  <td className="border border-border p-2 text-center">1</td>
                  <td className="border border-border p-2 text-center">9</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center font-semibold">10</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">13. Cross-App Refs</td>
                  <td className="border border-border p-2 text-center">2</td>
                  <td className="border border-border p-2 text-center">7</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center font-semibold">9</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">14. Role-Based Access</td>
                  <td className="border border-border p-2 text-center">8</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center font-semibold">8</td>
                </tr>
                <tr>
                  <td className="border border-border p-2">15. Performance & Security</td>
                  <td className="border border-border p-2 text-center">6</td>
                  <td className="border border-border p-2 text-center">8</td>
                  <td className="border border-border p-2 text-center">0</td>
                  <td className="border border-border p-2 text-center font-semibold">14</td>
                </tr>
                <tr className="bg-muted font-bold">
                  <td className="border border-border p-2">TOTAL</td>
                  <td className="border border-border p-2 text-center">73</td>
                  <td className="border border-border p-2 text-center">84</td>
                  <td className="border border-border p-2 text-center">4</td>
                  <td className="border border-border p-2 text-center">161</td>
                </tr>
              </tbody>
            </table>
          </section>
        </article>
      </main>
    </div>
  );
}