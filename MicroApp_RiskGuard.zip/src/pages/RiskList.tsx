import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useRiskStore } from '@/lib/riskStore';
import { RiskStage, RiskLevel, getRiskLevelStyle, getStageStyle, RISK_CATEGORIES, DEPARTMENTS } from '@/lib/types';
import { ScopeToggle, ScopeFilter, UserRole } from '@/components/ScopeToggle';
import {
  Plus,
  Search,
  Filter,
  ArrowRight,
  FileText,
  ClipboardCheck,
  Stethoscope,
  Eye,
  RefreshCw,
  CheckCircle2,
  Download,
  LayoutGrid,
  List,
} from 'lucide-react';

const STAGE_ICONS: Record<RiskStage, React.ElementType> = {
  Report: FileText,
  Evaluate: ClipboardCheck,
  Treat: Stethoscope,
  Monitor: Eye,
  Reassess: RefreshCw,
  Closed: CheckCircle2,
};

export default function RiskList() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [stageFilter, setStageFilter] = useState<string>('all');
  const [levelFilter, setLevelFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  
  // Mock current user role - in production this would come from auth context
  const [currentUserRole, setCurrentUserRole] = useState<UserRole>('admin');
  const [scopeFilter, setScopeFilter] = useState<ScopeFilter>('organization');
  
  // Reset scope when role changes
  const handleRoleChange = (role: UserRole) => {
    setCurrentUserRole(role);
    setScopeFilter(role === 'department_head' ? 'department' : role === 'contributor' ? 'personal' : 'organization');
  };

  const { risks, stats } = useRiskStore();

  const filteredRisks = risks.filter(risk => {
    const matchesSearch = risk.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      risk.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      risk.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStage = stageFilter === 'all' || risk.stage === stageFilter;
    const matchesLevel = levelFilter === 'all' || risk.riskLevel === levelFilter;
    const matchesCategory = categoryFilter === 'all' || risk.category === categoryFilter;
    const matchesDept = departmentFilter === 'all' || risk.departmentId === departmentFilter;
    return matchesSearch && matchesStage && matchesLevel && matchesCategory && matchesDept;
  });

  const handleRiskClick = (riskId: string, stage: RiskStage, subStatus?: string) => {
    if (stage === 'Report' && subStatus === 'Draft') {
      // Reopen an unfinished report in the wizard, prefilled
      navigate('/risks/new', { state: { draftId: riskId } });
    } else if (stage === 'Report' || stage === 'Closed') {
      navigate(`/risks/${riskId}`);
    } else {
      navigate(`/risks/${riskId}/${stage.toLowerCase()}`);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="bg-gradient-to-br from-primary via-primary/90 to-secondary py-8 border-b">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-primary-foreground">Risk Queue</h1>
              <p className="text-primary-foreground/80">Manage and track all risk reports</p>
            </div>
            <div className="flex items-center gap-3">
              <Select value={currentUserRole} onValueChange={(val) => handleRoleChange(val as UserRole)}>
                <SelectTrigger className="w-[160px] bg-secondary/20 border-secondary/30 text-primary-foreground">
                  <SelectValue placeholder="Select Role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="compliance_head">Compliance Head</SelectItem>
                  <SelectItem value="department_head">Department Head</SelectItem>
                  <SelectItem value="contributor">Staff (Read-Only)</SelectItem>
                </SelectContent>
              </Select>
              {currentUserRole !== 'contributor' && (
                <ScopeToggle
                  role={currentUserRole}
                  value={scopeFilter}
                  onChange={setScopeFilter}
                />
              )}
              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => navigate('/scenario-templates')}>
                  <FileText className="h-4 w-4 mr-2" />
                  Use Template
                </Button>
                <Button variant="secondary" onClick={() => navigate('/risks/new')}>
                  <Plus className="h-4 w-4 mr-2" />
                  Report Risk
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stage Quick Stats */}
      <section className="container mx-auto px-6 py-6">
        <div className="grid gap-3 grid-cols-2 md:grid-cols-6">
          {(['Report', 'Evaluate', 'Treat', 'Monitor', 'Reassess', 'Closed'] as RiskStage[]).map(stage => {
            const Icon = STAGE_ICONS[stage];
            const style = getStageStyle(stage);
            const count = stats.byStage[stage];
            return (
              <Card
                key={stage}
                className={`cursor-pointer transition-all hover:shadow-md ${stageFilter === stage ? 'ring-2 ring-primary' : ''}`}
                onClick={() => setStageFilter(stageFilter === stage ? 'all' : stage)}
              >
                <CardContent className="p-4 flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${style.bgColor}`}>
                    <Icon className={`h-4 w-4 ${style.color}`} />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{count}</p>
                    <p className="text-xs text-muted-foreground">{stage}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* Filters */}
      <section className="container mx-auto px-6 pb-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search by ID, title, or description..."
                  className="pl-10"
                />
              </div>
              <div className="flex gap-2 flex-wrap">
                <Select value={levelFilter} onValueChange={setLevelFilter}>
                  <SelectTrigger className="w-[130px]">
                    <SelectValue placeholder="Risk Level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Levels</SelectItem>
                    <SelectItem value="Critical">Critical</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Low">Low</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {RISK_CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Department" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Depts</SelectItem>
                    {DEPARTMENTS.map(dept => (
                      <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="flex border rounded-lg">
                  <Button
                    variant={viewMode === 'table' ? 'secondary' : 'ghost'}
                    size="icon"
                    onClick={() => setViewMode('table')}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === 'cards' ? 'secondary' : 'ghost'}
                    size="icon"
                    onClick={() => setViewMode('cards')}
                  >
                    <LayoutGrid className="h-4 w-4" />
                  </Button>
                </div>
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>
            {(stageFilter !== 'all' || levelFilter !== 'all' || categoryFilter !== 'all' || departmentFilter !== 'all') && (
              <div className="flex gap-2 mt-4 flex-wrap">
                {stageFilter !== 'all' && (
                  <Badge variant="secondary" className="cursor-pointer" onClick={() => setStageFilter('all')}>
                    Stage: {stageFilter} ×
                  </Badge>
                )}
                {levelFilter !== 'all' && (
                  <Badge variant="secondary" className="cursor-pointer" onClick={() => setLevelFilter('all')}>
                    Level: {levelFilter} ×
                  </Badge>
                )}
                {categoryFilter !== 'all' && (
                  <Badge variant="secondary" className="cursor-pointer" onClick={() => setCategoryFilter('all')}>
                    Category: {categoryFilter} ×
                  </Badge>
                )}
                {departmentFilter !== 'all' && (
                  <Badge variant="secondary" className="cursor-pointer" onClick={() => setDepartmentFilter('all')}>
                    Dept: {departmentFilter} ×
                  </Badge>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setStageFilter('all');
                    setLevelFilter('all');
                    setCategoryFilter('all');
                    setDepartmentFilter('all');
                  }}
                >
                  Clear all
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </section>

      {/* Results */}
      <section className="container mx-auto px-6 pb-12">
        <p className="text-sm text-muted-foreground mb-4">{filteredRisks.length} risks found</p>
        
        {viewMode === 'table' ? (
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Risk ID</TableHead>
                  <TableHead>Title</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Stage</TableHead>
                  <TableHead>Risk Level</TableHead>
                  <TableHead>Assignee</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRisks.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                      No risks found matching your filters
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredRisks.map(risk => {
                    const stageStyle = getStageStyle(risk.stage);
                    const StageIcon = STAGE_ICONS[risk.stage];
                    return (
                      <TableRow
                        key={risk.id}
                        className="cursor-pointer hover:bg-muted/50"
                        onClick={() => handleRiskClick(risk.id, risk.stage, risk.subStatus)}
                      >
                        <TableCell>
                          <Badge variant="outline">{risk.id}</Badge>
                        </TableCell>
                        <TableCell className="font-medium max-w-[250px] truncate">{risk.title}</TableCell>
                        <TableCell>{risk.category}</TableCell>
                        <TableCell>{risk.departmentId}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={`${stageStyle.bgColor} ${stageStyle.color} ${stageStyle.borderColor}`}>
                            <StageIcon className="h-3 w-3 mr-1" />
                            {risk.stage}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {risk.riskLevel && (
                            <Badge variant="outline" className={getRiskLevelStyle(risk.riskLevel)}>
                              {risk.riskLevel}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{risk.assignee}</TableCell>
                        <TableCell>
                          <ArrowRight className="h-4 w-4 text-muted-foreground" />
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredRisks.map(risk => {
              const stageStyle = getStageStyle(risk.stage);
              const StageIcon = STAGE_ICONS[risk.stage];
              return (
                <Card
                  key={risk.id}
                  className="cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => handleRiskClick(risk.id, risk.stage, risk.subStatus)}
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <Badge variant="outline">{risk.id}</Badge>
                      {risk.riskLevel && (
                        <Badge variant="outline" className={getRiskLevelStyle(risk.riskLevel)}>
                          {risk.riskLevel}
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-base line-clamp-2">{risk.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-4">{risk.description}</p>
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-1.5">
                        <Badge variant="outline" className={`${stageStyle.bgColor} ${stageStyle.color} ${stageStyle.borderColor}`}>
                          <StageIcon className="h-3 w-3 mr-1" />
                          {risk.stage}
                        </Badge>
                      </div>
                      <span className="text-muted-foreground">{risk.assignee}</span>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
