import { Button } from "@/components/ui/button";
import { ArrowLeft, Download } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";

export default function UATTestCases() {
  const handleDownloadPDF = () => {
    toast.info("Opening print dialog - select 'Save as PDF' to download");
    window.print();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header - Hidden when printing */}
      <header className="border-b border-border bg-card print:hidden">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" asChild>
              <Link to="/">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
            <Button onClick={handleDownloadPDF}>
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
          </div>
        </div>
      </header>

      {/* UAT Test Cases Content */}
      <main className="container mx-auto px-6 py-8 max-w-5xl print:max-w-none print:px-12">
        <article className="prose prose-slate dark:prose-invert max-w-none print:prose-sm">
          {/* Title Page */}
          <div className="text-center mb-12 print:mb-8">
            <h1 className="text-4xl font-bold mb-4 print:text-3xl">RiskGuard</h1>
            <h2 className="text-2xl text-muted-foreground mb-6 print:text-xl">User Acceptance Test (UAT) Cases</h2>
            <p className="text-muted-foreground">Version 1.0 | {new Date().toLocaleDateString()}</p>
            <p className="text-muted-foreground">Business User Testing</p>
          </div>

          <hr className="my-8" />

          {/* Introduction */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Introduction</h2>
            <p className="mb-4">
              This document contains User Acceptance Test (UAT) cases designed for business users to validate 
              that the RiskGuard system meets their operational requirements. Unlike QA test cases which focus 
              on technical functionality, UAT cases are scenario-based and reflect real-world usage patterns.
            </p>
            <div className="bg-muted p-4 rounded-lg mb-4">
              <h3 className="font-semibold mb-2">UAT Testing Guidelines</h3>
              <ul className="list-disc list-inside text-sm space-y-1">
                <li>Each scenario should be executed by a user with the specified role</li>
                <li>Document actual results and any deviations from expected behavior</li>
                <li>Note any usability concerns or suggestions for improvement</li>
                <li>All critical scenarios must pass before go-live approval</li>
              </ul>
            </div>
          </section>

          {/* Table of Contents */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Table of Contents</h2>
            <ol className="list-decimal list-inside space-y-1 text-sm">
              <li>End-to-End Risk Lifecycle Scenarios</li>
              <li>Risk Reporting Scenarios</li>
              <li>Risk Evaluation Scenarios</li>
              <li>Treatment Planning Scenarios</li>
              <li>Monitoring & Reassessment Scenarios</li>
              <li>Template Management Scenarios</li>
              <li>Dashboard & Reporting Scenarios</li>
              <li>Role-Based Access Scenarios</li>
              <li>Cross-Application Integration Scenarios</li>
              <li>Compliance & Audit Scenarios</li>
            </ol>
          </section>

          <hr className="my-8 print:break-after-page" />

          {/* 1. End-to-End Risk Lifecycle Scenarios */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">1. End-to-End Risk Lifecycle Scenarios</h2>
            
            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-001: Complete Risk Lifecycle - Patient Safety Event</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Staff Reporter → Risk Manager → Quality Director</div>
                <div><strong>Priority:</strong> <span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">Critical</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">A nurse discovers a medication administration error where a patient received the wrong dosage. The incident must be reported, evaluated, treated, monitored, and closed following organizational protocols.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li><strong>Report Stage (Staff):</strong> Log in as staff nurse. Navigate to "Report a Risk". Fill in medication error details including patient info (masked), actual harm level, contributing factors. Submit report.</li>
                  <li><strong>Evaluate Stage (Risk Manager):</strong> Log in as Risk Manager. Open the submitted risk from queue. Confirm category as "Medication". Assign Likelihood=3, Impact=4, Readiness=2. Verify calculated risk score. Add evaluation notes. Proceed to Treat.</li>
                  <li><strong>Treat Stage (Risk Manager):</strong> Select ROME decision "Mitigate". Choose treatment type "Process change". Add action tasks: pharmacy double-check protocol, nursing education session. Set due dates and owners. Proceed to Monitor.</li>
                  <li><strong>Monitor Stage (Risk Manager):</strong> Add monitoring metric: "Medication error rate" with target &lt;1%, monthly frequency. Log initial monitoring entry. Proceed to Reassess after monitoring period.</li>
                  <li><strong>Reassess Stage (Quality Director):</strong> Review effectiveness evidence. Enter residual likelihood=1, impact=3. Verify improved residual score. Close risk with summary.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Risk progresses through all stages with proper documentation. Audit trail shows all transitions and users. Final closure includes residual risk assessment showing improvement from original score.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-002: Urgent Risk with Sentinel Event</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Staff → Compliance Head</div>
                <div><strong>Priority:</strong> <span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">Critical</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">A serious adverse event occurs that qualifies as a sentinel event. The system must properly flag this for immediate attention and regulatory reporting consideration.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Log in as reporting staff. Create new risk report.</li>
                  <li>Select actual harm level "Severe" or "Death".</li>
                  <li>Check "Sentinel/Never Event suspected" checkbox.</li>
                  <li>Set escalation priority to "Immediate".</li>
                  <li>Submit report.</li>
                  <li>Verify risk appears with urgent indicators in queue.</li>
                  <li>Log in as Compliance Head. Verify immediate notification received.</li>
                  <li>Confirm regulatory reporting flag is visible.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Sentinel event is clearly flagged. Risk appears at top of queue with visual urgency indicators. Compliance Head receives notification. Regulatory reporting requirement is tracked.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-003: Risk Closed at Evaluate Stage</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Department Head</div>
                <div><strong>Priority:</strong> <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">High</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">A reported risk is evaluated and determined to be a duplicate or non-issue. It should be closed directly from evaluation without proceeding through treatment.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Open a risk in Evaluate stage.</li>
                  <li>Complete evaluation scoring.</li>
                  <li>Select decision "Close Risk".</li>
                  <li>Enter closure reason: "Duplicate of RISK-001".</li>
                  <li>Provide electronic signature/approval.</li>
                  <li>Confirm closure.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Risk is closed directly from Evaluate stage. Closure reason and approver are documented. Risk appears in Closed status in queue. Audit trail shows direct closure path.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-2">UAT-004: Treatment Loop Back from Reassessment</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Quality Manager</div>
                <div><strong>Priority:</strong> <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">High</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">After initial treatment and monitoring, reassessment reveals that the risk is not adequately controlled. Additional treatment measures are required.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Open risk in Reassess stage that completed initial treatment cycle.</li>
                  <li>Enter effectiveness review showing insufficient improvement.</li>
                  <li>Enter residual scores that remain elevated.</li>
                  <li>Select decision "Back to Treat".</li>
                  <li>Return to Treat stage.</li>
                  <li>Add additional action tasks.</li>
                  <li>Complete second treatment cycle through Monitor and back to Reassess.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Risk successfully loops back to Treat stage. Previous treatment history preserved. New treatment actions added to existing plan. Full audit trail shows treatment iteration.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>
          </section>

          {/* 2. Risk Reporting Scenarios */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">2. Risk Reporting Scenarios</h2>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-010: Report Risk from Scratch</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Staff Nurse</div>
                <div><strong>Priority:</strong> <span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">Critical</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">A frontline staff member needs to report a new risk incident that doesn't match any existing template.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Navigate to "Report a Risk" from sidebar.</li>
                  <li>Select "Report Risk" option (not template).</li>
                  <li>Complete all required sections: Basics, Details, People, Impact, Factors, Notifications.</li>
                  <li>Add one attachment with PHI warning acknowledgment.</li>
                  <li>Verify reporter section shows logged-in user info.</li>
                  <li>Check attestation box.</li>
                  <li>Submit report.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Risk report created successfully. Confirmation message displayed. Risk appears in queue with "Submitted" status in Report stage. Reporter can view their submitted risk.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-011: Report Risk Using Template</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Clinical Staff</div>
                <div><strong>Priority:</strong> <span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">Critical</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">A staff member needs to report a common risk type that has a pre-configured template available.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Navigate to "Report a Risk" → "Use Template".</li>
                  <li>Browse or search for "Fall Risk" template.</li>
                  <li>Click "Use This Template".</li>
                  <li>Verify form opens with pre-filled values (category, department, contributing factors, etc.).</li>
                  <li>Complete remaining required fields specific to this incident.</li>
                  <li>Submit report.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Template pre-fills relevant fields accurately. User only needs to add incident-specific details. Submitted risk shows template-derived values plus user additions.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-012: Anonymous Risk Report</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Staff Member</div>
                <div><strong>Priority:</strong> <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">High</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">A staff member wants to report a sensitive issue anonymously to protect their identity while ensuring the concern is documented.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Begin new risk report.</li>
                  <li>Navigate to Reporter section.</li>
                  <li>Enable "Report Anonymously" toggle (if policy allows).</li>
                  <li>Verify reporter name fields are hidden/cleared.</li>
                  <li>Complete and submit report.</li>
                  <li>View submitted report - verify reporter shows as "Anonymous".</li>
                  <li>(Admin verification) Check internal audit - actual reporter identity maintained.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Report submitted with "Anonymous" as reporter. Other users cannot see reporter identity. System maintains internal audit trace of actual submitter for compliance purposes.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-2">UAT-013: Save and Resume Draft Report</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Staff Member</div>
                <div><strong>Priority:</strong> <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">High</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">A staff member begins a risk report but is interrupted (patient care need). They need to save their work and return later to complete it.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Begin new risk report and fill in several sections.</li>
                  <li>Click "Save Draft".</li>
                  <li>Verify confirmation message.</li>
                  <li>Log out of system.</li>
                  <li>Log back in (hours later).</li>
                  <li>Navigate to Risk Queue or drafts.</li>
                  <li>Find and open draft report.</li>
                  <li>Verify all previously entered data is preserved.</li>
                  <li>Complete and submit report.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Draft saved successfully with all entered data. Draft accessible from user's view. All data preserved after logout/login. Draft can be completed and submitted without data loss.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>
          </section>

          {/* 3. Risk Evaluation Scenarios */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">3. Risk Evaluation Scenarios</h2>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-020: Standard Risk Scoring</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Risk Manager</div>
                <div><strong>Priority:</strong> <span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">Critical</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">A risk manager evaluates a submitted risk and assigns likelihood, impact, and readiness scores to calculate the overall risk level.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Open risk in Evaluate stage.</li>
                  <li>Review reported information.</li>
                  <li>Assign Likelihood = 4 (Likely).</li>
                  <li>Assign Impact = 3 (Moderate).</li>
                  <li>Assign Readiness = 2 (Partial controls).</li>
                  <li>Observe calculated risk score.</li>
                  <li>Verify risk level assignment (should be High based on config).</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Score calculated as: Base=12, Readiness Factor=0.67, Adjusted=8 (rounded). Risk level correctly mapped to configured band. Score breakdown displayed clearly.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-021: Score Override with Justification</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Compliance Head</div>
                <div><strong>Priority:</strong> <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">High</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">Due to organizational context not captured in standard scoring, a senior leader needs to override the calculated risk level with documented justification.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Open risk with calculated score/level.</li>
                  <li>Click "Override Score" or similar action.</li>
                  <li>Enter override risk level.</li>
                  <li>Enter required justification explaining organizational factors.</li>
                  <li>Confirm override.</li>
                  <li>Verify risk level updated with override indicator.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Override applied with visual indicator. Original calculated score still visible. Justification documented. Audit log captures override action, user, timestamp, and reason.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-2">UAT-022: Send Back to Report Stage</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Risk Manager</div>
                <div><strong>Priority:</strong> <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">High</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">During evaluation, the risk manager identifies that key information is missing from the original report and needs to send it back for additional details.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Open risk in Evaluate stage.</li>
                  <li>Identify missing information (e.g., witness statements).</li>
                  <li>Click "Send Back" action.</li>
                  <li>Enter reason: "Please add witness statements and clarify timeline."</li>
                  <li>Confirm send back.</li>
                  <li>Verify risk returns to Report stage.</li>
                  <li>Original reporter receives notification (if configured).</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Risk moved back to Report stage with status indicating revision needed. Send-back reason visible on risk. Original reporter can edit and resubmit. Audit trail shows transition.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>
          </section>

          {/* 4. Treatment Planning Scenarios */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">4. Treatment Planning Scenarios</h2>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-030: Create Mitigation Plan with Multiple Tasks</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Department Head</div>
                <div><strong>Priority:</strong> <span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">Critical</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">A department head creates a comprehensive treatment plan for a high-risk issue with multiple action items assigned to different team members.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Open risk in Treat stage.</li>
                  <li>Select ROME decision "Mitigate".</li>
                  <li>Select treatment type "Process change".</li>
                  <li>Add Task 1: "Update SOP" - Owner: Quality Mgr - Due: 2 weeks.</li>
                  <li>Add Task 2: "Staff training" - Owner: Educator - Due: 3 weeks.</li>
                  <li>Add Task 3: "Implement checklist" - Owner: Supervisor - Due: 1 week.</li>
                  <li>Enter interim controls.</li>
                  <li>Enter expected outcome.</li>
                  <li>Proceed to Monitor.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">All tasks created with owners and due dates. Task owners notified. Tasks visible in task tracking. Interim controls and expected outcome documented.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-031: ROME Decision - Retain Risk</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Risk Manager</div>
                <div><strong>Priority:</strong> <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">High</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">After evaluation, the organization decides to accept a low-level risk rather than invest in mitigation. This decision must be documented with business justification.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Open low-risk item in Treat stage.</li>
                  <li>Select ROME decision "Retain".</li>
                  <li>Enter justification: "Cost of mitigation exceeds potential impact. Risk accepted per policy."</li>
                  <li>Document risk acceptance authority level.</li>
                  <li>Proceed (may skip directly to Monitor or Close based on policy).</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">"Retain" decision documented with business justification. Risk acceptance recorded. Audit trail shows conscious decision to retain risk.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-2">UAT-032: Task Status Updates</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Task Owner (Various)</div>
                <div><strong>Priority:</strong> <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">High</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">Team members update the status of their assigned action items as work progresses.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Log in as assigned task owner.</li>
                  <li>Navigate to risk with assigned task.</li>
                  <li>Update task status from "Pending" to "In Progress".</li>
                  <li>Add progress note.</li>
                  <li>Later, update status to "Completed".</li>
                  <li>Verify completion reflected on risk treatment plan.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Task status changes saved. Progress notes visible. Completion status reflected in overall treatment plan view. Risk owner sees updated task status.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>
          </section>

          {/* 5. Monitoring & Reassessment Scenarios */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">5. Monitoring & Reassessment Scenarios</h2>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-040: Configure Monitoring Metrics</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Quality Manager</div>
                <div><strong>Priority:</strong> <span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">Critical</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">A quality manager sets up monitoring metrics to track the effectiveness of risk treatment measures over time.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Open risk in Monitor stage.</li>
                  <li>Click "Add Monitoring Metric".</li>
                  <li>Enter: Name="Fall rate per 1000 patient days", Target="&lt;2", Frequency="Monthly", Data Source="Incident reports", Owner="Quality Analyst".</li>
                  <li>Add second metric if applicable.</li>
                  <li>Save metrics.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Metrics configured with all required fields. Metric owners assigned. Monitoring schedule established. Dashboard/reports can display metric trends.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-041: Log Monitoring Entry</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Quality Analyst</div>
                <div><strong>Priority:</strong> <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">High</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">During the monitoring period, team members log periodic updates on metric progress and observations.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Open risk in Monitor stage.</li>
                  <li>Click "Add Monitoring Log Entry".</li>
                  <li>Enter date, current metric value, observations.</li>
                  <li>Note whether metric is on track or needs attention.</li>
                  <li>Save entry.</li>
                  <li>View monitoring history showing all log entries.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Log entry saved with timestamp. Monitoring history shows chronological entries. Trend visible over time. Alerts generated if off-track.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-2">UAT-042: Complete Effectiveness Reassessment</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Risk Manager</div>
                <div><strong>Priority:</strong> <span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">Critical</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">After the monitoring period, a comprehensive effectiveness review is conducted to determine if treatment was successful.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Open risk in Reassess stage.</li>
                  <li>Review monitoring history and metric results.</li>
                  <li>Enter effectiveness review summary with evidence.</li>
                  <li>Assign residual likelihood (should be lower than original).</li>
                  <li>Assign residual impact.</li>
                  <li>Verify residual risk score/level calculated.</li>
                  <li>Make decision: Close (if effective) or Back to Treat (if not).</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Effectiveness documented with supporting evidence. Residual scores show improvement. Comparison to original score visible. Decision documented with rationale.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>
          </section>

          {/* 6. Template Management Scenarios */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">6. Template Management Scenarios</h2>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-050: Create Department Template</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Department Head</div>
                <div><strong>Priority:</strong> <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">High</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">A department head creates a risk template specific to their department's common incident types to standardize reporting.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Navigate to Templates.</li>
                  <li>Click "Create New Template".</li>
                  <li>Enter: Name="ED - Patient Elopement", Description, Tags.</li>
                  <li>Set default values: Category="Security", Dept="Emergency", Location Type="ER".</li>
                  <li>Pre-select common contributing factors.</li>
                  <li>Set Visibility to "Department".</li>
                  <li>Save template.</li>
                  <li>Verify only department members can see template.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Template created with all configured defaults. Visibility correctly limited to department. Template appears in library for department staff.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-2">UAT-051: Duplicate and Customize Template</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Compliance Head</div>
                <div><strong>Priority:</strong> <span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-0.5 rounded text-xs">Medium</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">A Compliance Head wants to create a similar template based on an existing one with minor modifications.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Find existing template in library.</li>
                  <li>Click "Duplicate".</li>
                  <li>Rename to appropriate new name.</li>
                  <li>Modify defaults as needed.</li>
                  <li>Change visibility if needed.</li>
                  <li>Save as new template.</li>
                  <li>Verify both original and duplicate exist separately.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">New template created independently from original. Original unchanged. New template fully editable. Both appear in library.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>
          </section>

          {/* 7. Dashboard & Reporting Scenarios */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">7. Dashboard & Reporting Scenarios</h2>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-060: Executive Dashboard Review</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Compliance Head</div>
                <div><strong>Priority:</strong> <span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">Critical</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">An executive needs to quickly assess the organization's risk posture from the dashboard.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Log in as Compliance Head.</li>
                  <li>Set scope toggle to "Organization".</li>
                  <li>Review KPI cards: Total, Open, Critical/High, Closed counts.</li>
                  <li>Review risk distribution by stage chart.</li>
                  <li>Review risk distribution by level chart.</li>
                  <li>Identify top risk categories by volume.</li>
                  <li>Review urgent/overdue risks list.</li>
                  <li>Drill down into specific risk from dashboard.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Dashboard provides comprehensive organizational risk overview. All visualizations render correctly. Drill-down navigation works. Data accurately reflects current risk portfolio.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-2">UAT-061: Export Risk Data</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Admin</div>
                <div><strong>Priority:</strong> <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">High</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">For a board report, an administrator needs to export risk data to manipulate in Excel.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Navigate to Dashboard or Risk Queue.</li>
                  <li>Apply any desired filters.</li>
                  <li>Click "Export CSV".</li>
                  <li>Download file.</li>
                  <li>Open in Excel and verify data completeness.</li>
                  <li>Verify sensitive fields are appropriately handled.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">CSV downloads successfully. All visible risk data included. Data formatted correctly for analysis. PHI/sensitive data handled per policy.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>
          </section>

          {/* 8. Role-Based Access Scenarios */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">8. Role-Based Access Scenarios</h2>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-070: Staff Role Restrictions</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Staff (Read-Only)</div>
                <div><strong>Priority:</strong> <span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">Critical</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">Verify that staff members cannot access administrative functions while maintaining ability to report risks and update assigned work.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Log in as Staff role.</li>
                  <li>Verify can access: Dashboard (Personal only), Report a Risk, assigned risks.</li>
                  <li>Verify can update evaluation/treatment on assigned risks.</li>
                  <li>Verify cannot access: Scoring Settings, Admin Config.</li>
                  <li>Verify cannot create/edit templates.</li>
                  <li>Verify cannot edit Program Library content.</li>
                  <li>Verify no scope toggle visible (Personal scope only).</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Staff user can perform day-to-day risk work but cannot modify system configuration. Menu items hidden or disabled appropriately. Unauthorized URL access denied.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-071: Department Head Scope Boundary</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Department Head</div>
                <div><strong>Priority:</strong> <span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">Critical</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">Verify Department Heads can only view and manage risks within their assigned department.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Log in as Department Head (assigned to "Emergency Department").</li>
                  <li>Set scope toggle to "Department".</li>
                  <li>Verify Risk Queue shows only ED risks.</li>
                  <li>Verify cannot view risks from other departments.</li>
                  <li>Verify can create templates with Department visibility.</li>
                  <li>Attempt to access risk from another department by URL.</li>
                  <li>Verify access denied.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Department Head sees only their department's risks. Cross-department access blocked. Scope toggle shows Department/Personal only (not Organization).</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-2">UAT-072: Admin Full Access Verification</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Admin</div>
                <div><strong>Priority:</strong> <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">High</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">Verify Admin role has unrestricted access to all system functions.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Log in as Admin.</li>
                  <li>Verify Organization scope available and shows all risks.</li>
                  <li>Access and modify Scoring Settings.</li>
                  <li>Access and modify Admin Config taxonomies.</li>
                  <li>Create organization-wide template.</li>
                  <li>Manage Program Library content.</li>
                  <li>View all users and permissions (if applicable).</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Admin has full access to all modules and configuration. Organization-wide view available. All administrative functions accessible.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>
          </section>

          {/* 9. Cross-Application Integration Scenarios */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">9. Cross-Application Integration Scenarios</h2>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-080: Link Risk to Compliance Policy</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Risk Manager</div>
                <div><strong>Priority:</strong> <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">High</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">A risk is identified as related to a specific compliance policy. The risk manager needs to link the risk to the relevant policy in ComplianceConnect.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Open risk in any stage.</li>
                  <li>Navigate to cross-reference panel.</li>
                  <li>Select "ComplianceConnect" as source app.</li>
                  <li>Search for relevant policy.</li>
                  <li>Select policy from results.</li>
                  <li>Choose relationship type "Control/Policy Reference".</li>
                  <li>Add note explaining relevance.</li>
                  <li>Save link.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Policy linked to risk with relationship type. Link visible in cross-reference panel. Policy accessible via link (if user has permission in ComplianceConnect).</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-2">UAT-081: Link Risk to Patient Complaint</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Quality Manager</div>
                <div><strong>Priority:</strong> <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded text-xs">High</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">A risk originated from a patient complaint filed in FeedbackHub. The quality manager links the source complaint to the risk record.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Open risk that originated from a complaint.</li>
                  <li>Open cross-reference panel.</li>
                  <li>Select "FeedbackHub" as source.</li>
                  <li>Search for and select the original complaint.</li>
                  <li>Set relationship type to "Source of Risk".</li>
                  <li>Add note: "Risk created based on this complaint."</li>
                  <li>Save link.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Complaint linked as source. Relationship type correctly reflects "Source of Risk". Both RiskGuard and FeedbackHub users can trace the connection.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>
          </section>

          {/* 10. Compliance & Audit Scenarios */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">10. Compliance & Audit Scenarios</h2>

            <div className="border border-border rounded-lg p-4 mb-6">
              <h3 className="text-lg font-semibold mb-2">UAT-090: Audit Trail Verification</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Compliance Head</div>
                <div><strong>Priority:</strong> <span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">Critical</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">For regulatory audit preparation, verify that all risk management activities are properly logged with user attribution and timestamps.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Select a closed risk that went through all stages.</li>
                  <li>Open risk detail/history view.</li>
                  <li>Review audit trail showing: creation, stage transitions, evaluations, treatments, reassessments.</li>
                  <li>Verify each entry shows: user, timestamp, action, changes.</li>
                  <li>Verify score overrides show justification.</li>
                  <li>Verify send-back actions show reason.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Complete chronological audit trail available. All user actions attributed. Timestamps accurate. Overrides and special actions include required justification.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-2">UAT-091: Regulatory Reporting Flag Tracking</h3>
              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div><strong>Role:</strong> Compliance Head</div>
                <div><strong>Priority:</strong> <span className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded text-xs">Critical</span></div>
              </div>
              <div className="mb-4">
                <strong>Business Scenario:</strong>
                <p className="text-sm text-muted-foreground">Track risks that require regulatory reporting to ensure compliance with reporting obligations.</p>
              </div>
              <div className="mb-4">
                <strong>Steps:</strong>
                <ol className="list-decimal list-inside text-sm space-y-2 ml-4">
                  <li>Filter Risk Queue for "Regulatory Reporting Required" flag.</li>
                  <li>Review list of risks requiring external reporting.</li>
                  <li>Open individual risk and verify flag visible.</li>
                  <li>Document reporting status/completion.</li>
                  <li>Verify flag persists through all stages.</li>
                </ol>
              </div>
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <strong>Expected Outcome:</strong>
                <p className="text-sm">Risks with regulatory reporting requirements easily identifiable. Filter works correctly. Flag visible throughout risk lifecycle. Reporting status trackable.</p>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
                <div className="border border-border p-2 rounded">
                  <strong>Pass/Fail:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Tester:</strong> ____
                </div>
                <div className="border border-border p-2 rounded">
                  <strong>Date:</strong> ____
                </div>
              </div>
            </div>
          </section>

          <hr className="my-8" />

          {/* UAT Sign-off Section */}
          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-bold mb-4">UAT Sign-off</h2>
            
            <div className="bg-muted p-6 rounded-lg mb-6">
              <h3 className="text-lg font-semibold mb-4">Test Execution Summary</h3>
              <table className="w-full text-sm border-collapse border border-border">
                <thead>
                  <tr className="bg-background">
                    <th className="border border-border p-2 text-left">Category</th>
                    <th className="border border-border p-2 text-center">Total Tests</th>
                    <th className="border border-border p-2 text-center">Passed</th>
                    <th className="border border-border p-2 text-center">Failed</th>
                    <th className="border border-border p-2 text-center">Blocked</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border border-border p-2">End-to-End Lifecycle</td><td className="border border-border p-2 text-center">4</td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td></tr>
                  <tr><td className="border border-border p-2">Risk Reporting</td><td className="border border-border p-2 text-center">4</td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td></tr>
                  <tr><td className="border border-border p-2">Risk Evaluation</td><td className="border border-border p-2 text-center">3</td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td></tr>
                  <tr><td className="border border-border p-2">Treatment Planning</td><td className="border border-border p-2 text-center">3</td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td></tr>
                  <tr><td className="border border-border p-2">Monitoring & Reassess</td><td className="border border-border p-2 text-center">3</td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td></tr>
                  <tr><td className="border border-border p-2">Template Management</td><td className="border border-border p-2 text-center">2</td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td></tr>
                  <tr><td className="border border-border p-2">Dashboard & Reporting</td><td className="border border-border p-2 text-center">2</td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td></tr>
                  <tr><td className="border border-border p-2">Role-Based Access</td><td className="border border-border p-2 text-center">3</td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td></tr>
                  <tr><td className="border border-border p-2">Cross-App Integration</td><td className="border border-border p-2 text-center">2</td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td></tr>
                  <tr><td className="border border-border p-2">Compliance & Audit</td><td className="border border-border p-2 text-center">2</td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td><td className="border border-border p-2 text-center"></td></tr>
                  <tr className="font-bold bg-background">
                    <td className="border border-border p-2">TOTAL</td>
                    <td className="border border-border p-2 text-center">28</td>
                    <td className="border border-border p-2 text-center"></td>
                    <td className="border border-border p-2 text-center"></td>
                    <td className="border border-border p-2 text-center"></td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold mb-4">UAT Approval</h3>
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-8">
                  <div>
                    <p className="font-semibold mb-2">Business Owner Approval</p>
                    <div className="space-y-2 text-sm">
                      <p>Name: ________________________________</p>
                      <p>Title: ________________________________</p>
                      <p>Signature: ____________________________</p>
                      <p>Date: ________________________________</p>
                    </div>
                  </div>
                  <div>
                    <p className="font-semibold mb-2">IT/Project Manager Approval</p>
                    <div className="space-y-2 text-sm">
                      <p>Name: ________________________________</p>
                      <p>Title: ________________________________</p>
                      <p>Signature: ____________________________</p>
                      <p>Date: ________________________________</p>
                    </div>
                  </div>
                </div>
                <div className="pt-4 border-t border-border">
                  <p className="text-sm text-muted-foreground">
                    By signing above, the approvers confirm that User Acceptance Testing has been completed 
                    satisfactorily and the RiskGuard system is approved for production deployment.
                  </p>
                </div>
              </div>
            </div>
          </section>
        </article>
      </main>
    </div>
  );
}