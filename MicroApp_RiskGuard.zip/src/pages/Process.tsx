import { Plus, FileText } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const Process = () => {
  const navigate = useNavigate();
  
  return (
    <div className="min-h-screen bg-background">
      {/* Page Header */}
      <section className="bg-gradient-to-br from-secondary/5 to-primary/5 border-b border-border">
        <div className="container mx-auto px-6 py-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-foreground mb-2">
              Report a Risk
            </h2>
            <p className="text-muted-foreground">
              Choose how you want to report a new risk
            </p>
          </div>
        </div>
      </section>

      {/* Action Cards */}
      <section className="container mx-auto px-6 py-12">
        <div className="max-w-3xl mx-auto grid gap-6 md:grid-cols-2">
          <Card 
            className="group cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1 hover:border-primary/50"
            onClick={() => navigate("/report-risk")}
          >
            <CardHeader className="text-center pb-2">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Plus className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-xl group-hover:text-primary transition-colors">
                Report Risk
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <CardDescription>
                Create a new risk report from scratch by manually entering all risk details
              </CardDescription>
            </CardContent>
          </Card>

          <Card 
            className="group cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1 hover:border-primary/50"
            onClick={() => navigate("/scenario-templates")}
          >
            <CardHeader className="text-center pb-2">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-secondary/10">
                <FileText className="h-8 w-8 text-secondary" />
              </div>
              <CardTitle className="text-xl group-hover:text-primary transition-colors">
                Use Template
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <CardDescription>
                Choose from pre-configured risk scenarios with pre-filled categories and departments
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Process;
