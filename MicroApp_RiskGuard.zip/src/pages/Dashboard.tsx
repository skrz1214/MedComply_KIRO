import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { getRiskStats, mockRisks } from '@/lib/mockData';
import { RiskStage, getRiskLevelStyle, getStageStyle } from '@/lib/types';
import { ScopeToggle, ScopeFilter, UserRole } from '@/components/ScopeToggle';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Plus,
  FileText,
  ClipboardCheck,
  Stethoscope,
  Eye,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Download,
  ArrowRight,
} from 'lucide-react';

const STAGE_ICONS: Record<RiskStage, React.ElementType> = {
  Report: FileText,
  Evaluate: ClipboardCheck,
  Treat: Stethoscope,
  Monitor: Eye,
  Reassess: RefreshCw,
  Closed: CheckCircle2,
};

export default function Dashboard() {
  const navigate = useNavigate();
  const stats = getRiskStats();
  
  // Mock current user role - in production this would come from auth context
  const [currentUserRole, setCurrentUserRole] = useState<UserRole>('admin');
  const [scopeFilter, setScopeFilter] = useState<ScopeFilter>('organization');
  
  // Reset scope when role changes
  const handleRoleChange = (role: UserRole) => {
    setCurrentUserRole(role);
    setScopeFilter(role === 'department_head' ? 'department' : role === 'contributor' ? 'personal' : 'organization');
  };

  const recentRisks = mockRisks
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const urgentRisks = mockRisks.filter(r => 
    r.priority === 'Immediate' || r.priority === 'Urgent'
  ).slice(0, 3);

  const handleExport = () => {
    const today = new Date().toISOString().split('T')[0];
    
    // Build CSV with summary section first
    const csvRows = [
      // Header
      ['RiskGuard Dashboard Export'],
      [`Generated: ${today}`],
      [''],
      // KPI Summary
      ['=== DASHBOARD SUMMARY ==='],
      ['Metric', 'Value'],
      ['Total Risks', stats.total],
      ['Open Risks', stats.total - stats.byStage.Closed],
      ['Critical / High Priority', stats.byLevel.Critical + stats.byLevel.High],
      ['Closed Risks', stats.byStage.Closed],
      [''],
      // By Stage
      ['=== RISKS BY STAGE ==='],
      ['Stage', 'Count', 'Percentage'],
      ...(['Report', 'Evaluate', 'Treat', 'Monitor', 'Reassess', 'Closed'] as const).map(stage => [
        stage,
        stats.byStage[stage],
        `${stats.total > 0 ? Math.round((stats.byStage[stage] / stats.total) * 100) : 0}%`
      ]),
      [''],
      // By Level
      ['=== RISKS BY LEVEL ==='],
      ['Level', 'Count', 'Percentage'],
      ...(['Critical', 'High', 'Medium', 'Low'] as const).map(level => [
        level,
        stats.byLevel[level],
        `${stats.total > 0 ? Math.round((stats.byLevel[level] / stats.total) * 100) : 0}%`
      ]),
      [''],
      // By Category
      ['=== TOP CATEGORIES ==='],
      ['Category', 'Count'],
      ...Object.entries(stats.byCategory)
        .sort((a, b) => b[1] - a[1])
        .map(([category, count]) => [category, count]),
      [''],
      // Detailed Risk List
      ['=== DETAILED RISK LIST ==='],
      ['ID', 'Title', 'Category', 'Department', 'Stage', 'Risk Level', 'Priority', 'Assignee', 'Created'],
      ...mockRisks.map(r => [
        r.id, 
        `"${r.title.replace(/"/g, '""')}"`, // Escape quotes in title
        r.category, 
        r.departmentId, 
        r.stage, 
        r.riskLevel || '', 
        r.priority, 
        r.assignee, 
        r.createdAt
      ])
    ];

    const csv = csvRows.map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `riskguard-dashboard-export-${today}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary via-primary/90 to-secondary py-10">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <h1 className="text-3xl font-bold text-primary-foreground mb-2">RiskGuard Dashboard</h1>
              <p className="text-primary-foreground/80">Healthcare Risk Management System</p>
            </div>
            <div className="flex items-center gap-3">
              <Select value={currentUserRole} onValueChange={(val) => handleRoleChange(val as UserRole)}>
                <SelectTrigger className="w-[160px] bg-secondary/20 border-secondary/30 text-primary-foreground">
                  <SelectValue placeholder="Select Role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="compliance_head">Compliance Head</SelectItem>
                  <SelectItem value="department_head">Department Head</SelectItem>
                  <SelectItem value="contributor">Staff (Read-Only)</SelectItem>
                </SelectContent>
              </Select>
              {currentUserRole !== 'contributor' && (
                <ScopeToggle
                  role={currentUserRole}
                  value={scopeFilter}
                  onChange={setScopeFilter}
                />
              )}
              <div className="flex gap-2">
                <Button variant="secondary" onClick={handleExport}>
                  <Download className="h-4 w-4 mr-2" />
                  Export CSV
                </Button>
                <Button variant="secondary" onClick={() => navigate('/risks/new')}>
                  <Plus className="h-4 w-4 mr-2" />
                  Report Risk
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* KPI Cards */}
      <section className="container mx-auto px-6 py-8">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Total Risks</CardDescription>
              <CardTitle className="text-4xl">{stats.total}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">All time records</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Open Risks</CardDescription>
              <CardTitle className="text-4xl text-primary">
                {stats.total - stats.byStage.Closed}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Requiring attention</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Critical / High</CardDescription>
              <CardTitle className="text-4xl text-destructive">
                {stats.byLevel.Critical + stats.byLevel.High}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Priority items</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Closed This Month</CardDescription>
              <CardTitle className="text-4xl text-status-closed">{stats.byStage.Closed}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Successfully resolved</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Stage Overview */}
      <section className="container mx-auto px-6 pb-8">
        <Card>
          <CardHeader>
            <CardTitle>Risks by Stage</CardTitle>
            <CardDescription>Current distribution across the lifecycle</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-6">
              {(['Report', 'Evaluate', 'Treat', 'Monitor', 'Reassess', 'Closed'] as RiskStage[]).map(stage => {
                const Icon = STAGE_ICONS[stage];
                const style = getStageStyle(stage);
                const count = stats.byStage[stage];
                const percentage = stats.total > 0 ? Math.round((count / stats.total) * 100) : 0;
                return (
                  <div
                    key={stage}
                    className={`p-4 rounded-lg border cursor-pointer transition-all hover:shadow-md ${style.bgColor} ${style.borderColor}`}
                    onClick={() => navigate('/risks')}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <Icon className={`h-5 w-5 ${style.color}`} />
                      <span className={`font-medium ${style.color}`}>{stage}</span>
                    </div>
                    <p className="text-3xl font-bold">{count}</p>
                    <p className="text-sm text-muted-foreground">{percentage}% of total</p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Risk Level Distribution */}
      <section className="container mx-auto px-6 pb-8">
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Risk Level Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {(['Critical', 'High', 'Medium', 'Low'] as const).map(level => {
                  const count = stats.byLevel[level];
                  const percentage = stats.total > 0 ? Math.round((count / stats.total) * 100) : 0;
                  return (
                    <div key={level}>
                      <div className="flex items-center justify-between mb-1">
                        <Badge className={getRiskLevelStyle(level)}>{level}</Badge>
                        <span className="text-sm font-medium">{count} ({percentage}%)</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            level === 'Critical' ? 'bg-risk-critical' :
                            level === 'High' ? 'bg-risk-high' :
                            level === 'Medium' ? 'bg-risk-medium' :
                            'bg-risk-low'
                          }`}
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Top Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(stats.byCategory)
                  .sort((a, b) => b[1] - a[1])
                  .slice(0, 5)
                  .map(([category, count]) => (
                    <div key={category} className="flex items-center justify-between p-3 border rounded-lg">
                      <span className="font-medium">{category}</span>
                      <Badge variant="secondary">{count}</Badge>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Recent and Urgent */}
      <section className="container mx-auto px-6 pb-12">
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Recent Risks</CardTitle>
                  <CardDescription>Latest reported risks</CardDescription>
                </div>
                <Button variant="ghost" size="sm" onClick={() => navigate('/risks')}>
                  View All <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentRisks.map(risk => {
                  const stageStyle = getStageStyle(risk.stage);
                  return (
                    <div
                      key={risk.id}
                      className="flex items-center justify-between p-3 border rounded-lg cursor-pointer hover:bg-muted/50"
                      onClick={() => navigate(`/risks/${risk.id}`)}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline" className="text-xs">{risk.id}</Badge>
                          <Badge variant="outline" className={`${stageStyle.bgColor} ${stageStyle.color} text-xs`}>
                            {risk.stage}
                          </Badge>
                        </div>
                        <p className="font-medium truncate">{risk.title}</p>
                      </div>
                      <ArrowRight className="h-4 w-4 text-muted-foreground ml-2" />
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-destructive" />
                    Urgent Attention
                  </CardTitle>
                  <CardDescription>Immediate and urgent priority risks</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {urgentRisks.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">No urgent risks</p>
              ) : (
                <div className="space-y-3">
                  {urgentRisks.map(risk => (
                    <div
                      key={risk.id}
                      className="flex items-center justify-between p-3 border border-destructive/20 bg-destructive/5 rounded-lg cursor-pointer hover:bg-destructive/10"
                      onClick={() => navigate(`/risks/${risk.id}`)}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline" className="text-xs">{risk.id}</Badge>
                          <Badge variant="destructive" className="text-xs">{risk.priority}</Badge>
                        </div>
                        <p className="font-medium truncate">{risk.title}</p>
                        <p className="text-xs text-muted-foreground">{risk.category} • {risk.assignee}</p>
                      </div>
                      <ArrowRight className="h-4 w-4 text-muted-foreground ml-2" />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
