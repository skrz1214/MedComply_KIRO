import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { mockTemplates } from '@/lib/mockData';
import {
  RISK_CATEGORIES,
  REPORT_TYPES,
  LOCATION_TYPES,
  FACILITY_TYPES,
  DEPARTMENTS,
  CONTRIBUTING_FACTORS,
  RiskTemplate,
} from '@/lib/types';
import {
  ArrowLeft,
  Plus,
  Edit,
  Trash2,
  FileText,
  Copy,
  Archive,
  Search,
  Eye,
} from 'lucide-react';

export default function TemplateLibrary() {
  const navigate = useNavigate();
  const { toast } = useToast();

  const [templates, setTemplates] = useState<RiskTemplate[]>(mockTemplates);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [visibilityFilter, setVisibilityFilter] = useState('all');
  const [showArchived, setShowArchived] = useState(false);
  
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<RiskTemplate | null>(null);
  const [previewTemplate, setPreviewTemplate] = useState<RiskTemplate | null>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    whenToUse: '',
    tags: '',
    visibility: 'Organization' as 'Private' | 'Department' | 'Organization',
    facilityType: '',
    departmentId: '',
    category: '',
    reportType: '',
    locationType: '',
    suggestedTitle: '',
    defaultFactors: [] as string[],
    priority: 'Routine',
    suggestedLikelihood: '',
    suggestedImpact: '',
    linkedContent: '',
    changeNotes: '',
  });

  const filteredTemplates = useMemo(() => {
    return templates.filter(t => {
      const matchesSearch = t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        t.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesCategory = categoryFilter === 'all' || t.category === categoryFilter;
      const matchesVisibility = visibilityFilter === 'all' || t.visibility === visibilityFilter;
      const matchesArchived = showArchived || !t.isArchived;
      return matchesSearch && matchesCategory && matchesVisibility && matchesArchived;
    });
  }, [templates, searchQuery, categoryFilter, visibilityFilter, showArchived]);

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      whenToUse: '',
      tags: '',
      visibility: 'Organization',
      facilityType: '',
      departmentId: '',
      category: '',
      reportType: '',
      locationType: '',
      suggestedTitle: '',
      defaultFactors: [],
      priority: 'Routine',
      suggestedLikelihood: '',
      suggestedImpact: '',
      linkedContent: '',
      changeNotes: '',
    });
    setEditingTemplate(null);
  };

  const handleEdit = (template: RiskTemplate) => {
    setEditingTemplate(template);
    setFormData({
      name: template.name,
      description: template.description,
      whenToUse: template.whenToUse || '',
      tags: template.tags.join(', '),
      visibility: template.visibility,
      facilityType: template.facilityType || '',
      departmentId: template.departmentId || '',
      category: template.category,
      reportType: template.reportType || '',
      locationType: template.locationType || '',
      suggestedTitle: template.suggestedTitle || '',
      defaultFactors: template.defaultFactors || [],
      priority: template.priority || 'Routine',
      suggestedLikelihood: template.suggestedLikelihood?.toString() || '',
      suggestedImpact: template.suggestedImpact?.toString() || '',
      linkedContent: template.linkedContent.join(', '),
      changeNotes: '',
    });
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.name || !formData.description || !formData.category) {
      toast({
        title: 'Validation Error',
        description: 'Please fill in all required fields.',
        variant: 'destructive',
      });
      return;
    }

    const templateData: Partial<RiskTemplate> = {
      name: formData.name,
      description: formData.description,
      whenToUse: formData.whenToUse,
      tags: formData.tags.split(',').map(s => s.trim()).filter(Boolean),
      visibility: formData.visibility,
      facilityType: formData.facilityType || undefined,
      departmentId: formData.departmentId || undefined,
      category: formData.category,
      reportType: formData.reportType || undefined,
      locationType: formData.locationType || undefined,
      suggestedTitle: formData.suggestedTitle || undefined,
      defaultFactors: formData.defaultFactors,
      priority: formData.priority as any,
      suggestedLikelihood: formData.suggestedLikelihood ? parseInt(formData.suggestedLikelihood) : undefined,
      suggestedImpact: formData.suggestedImpact ? parseInt(formData.suggestedImpact) : undefined,
      linkedContent: formData.linkedContent.split(',').map(s => s.trim()).filter(Boolean),
      changeNotes: formData.changeNotes || undefined,
      updatedAt: new Date().toISOString(),
      updatedBy: 'current-user@hospital.org',
    };

    if (editingTemplate) {
      setTemplates(templates.map(t =>
        t.id === editingTemplate.id
          ? { ...t, ...templateData, version: t.version + 1 }
          : t
      ));
      toast({ title: 'Template Updated', description: `"${formData.name}" has been updated.` });
    } else {
      const newTemplate: RiskTemplate = {
        id: `TPL-${Date.now()}`,
        ...templateData as any,
        version: 1,
        isArchived: false,
        createdAt: new Date().toISOString(),
        createdBy: 'current-user@hospital.org',
      };
      setTemplates([...templates, newTemplate]);
      toast({ title: 'Template Created', description: `"${formData.name}" has been created.` });
    }

    setIsDialogOpen(false);
    resetForm();
  };

  const handleDuplicate = (template: RiskTemplate) => {
    const duplicate: RiskTemplate = {
      ...template,
      id: `TPL-${Date.now()}`,
      name: `${template.name} (Copy)`,
      version: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setTemplates([...templates, duplicate]);
    toast({ title: 'Template Duplicated', description: 'A copy has been created.' });
  };

  const handleArchive = (id: string) => {
    setTemplates(templates.map(t =>
      t.id === id ? { ...t, isArchived: !t.isArchived } : t
    ));
    toast({ title: 'Template Updated', description: 'Archive status changed.' });
  };

  const handleDelete = (id: string) => {
    setTemplates(templates.filter(t => t.id !== id));
    toast({ title: 'Template Deleted', description: 'The template has been removed.' });
  };

  const handleUseTemplate = (template: RiskTemplate) => {
    navigate('/risks/new', { state: { template } });
  };

  const toggleFactor = (factor: string) => {
    setFormData(prev => ({
      ...prev,
      defaultFactors: prev.defaultFactors.includes(factor)
        ? prev.defaultFactors.filter(f => f !== factor)
        : [...prev.defaultFactors, factor],
    }));
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6 max-w-6xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/risks')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Risk Intake Templates</h1>
              <p className="text-muted-foreground">Pre-configured templates for quick risk reporting</p>
            </div>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetForm}>
                <Plus className="h-4 w-4 mr-2" />
                New Template
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingTemplate ? 'Edit Template' : 'Create New Template'}</DialogTitle>
                <DialogDescription>
                  Templates pre-fill risk data. Scoring follows Org/Category/Category+Department precedence.
                </DialogDescription>
              </DialogHeader>
              
              <Tabs defaultValue="basics" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="basics">Basics</TabsTrigger>
                  <TabsTrigger value="defaults">Defaults</TabsTrigger>
                  <TabsTrigger value="scoring">Scoring & Content</TabsTrigger>
                </TabsList>
                
                <TabsContent value="basics" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label>Template Name *</Label>
                    <Input
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g., Medication Administration Error"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Description *</Label>
                    <Textarea
                      value={formData.description}
                      onChange={e => setFormData({ ...formData, description: e.target.value })}
                      placeholder="What is this template for?"
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>When to Use</Label>
                    <Textarea
                      value={formData.whenToUse}
                      onChange={e => setFormData({ ...formData, whenToUse: e.target.value })}
                      placeholder="Describe scenarios when this template should be used"
                      rows={2}
                    />
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Tags (comma-separated)</Label>
                      <Input
                        value={formData.tags}
                        onChange={e => setFormData({ ...formData, tags: e.target.value })}
                        placeholder="medication, pharmacy, safety"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Visibility</Label>
                      <Select value={formData.visibility} onValueChange={(v: any) => setFormData({ ...formData, visibility: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Private">Private</SelectItem>
                          <SelectItem value="Department">Department</SelectItem>
                          <SelectItem value="Organization">Organization</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="defaults" className="space-y-4 mt-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Facility Type</Label>
                      <Select value={formData.facilityType} onValueChange={v => setFormData({ ...formData, facilityType: v })}>
                        <SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger>
                        <SelectContent>
                          {FACILITY_TYPES.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Department</Label>
                      <Select value={formData.departmentId} onValueChange={v => setFormData({ ...formData, departmentId: v })}>
                        <SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger>
                        <SelectContent>
                          {DEPARTMENTS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Category *</Label>
                      <Select value={formData.category} onValueChange={v => setFormData({ ...formData, category: v })}>
                        <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                        <SelectContent>
                          {RISK_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Report Type</Label>
                      <Select value={formData.reportType} onValueChange={v => setFormData({ ...formData, reportType: v })}>
                        <SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger>
                        <SelectContent>
                          {REPORT_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Location Type</Label>
                      <Select value={formData.locationType} onValueChange={v => setFormData({ ...formData, locationType: v })}>
                        <SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger>
                        <SelectContent>
                          {LOCATION_TYPES.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Priority</Label>
                      <Select value={formData.priority} onValueChange={v => setFormData({ ...formData, priority: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Routine">Routine</SelectItem>
                          <SelectItem value="Urgent">Urgent</SelectItem>
                          <SelectItem value="Immediate">Immediate</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Suggested Title</Label>
                    <Input
                      value={formData.suggestedTitle}
                      onChange={e => setFormData({ ...formData, suggestedTitle: e.target.value })}
                      placeholder="Pre-filled title for reports"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Default Contributing Factors</Label>
                    <div className="grid gap-2 md:grid-cols-2 border rounded-lg p-3 max-h-48 overflow-y-auto">
                      {CONTRIBUTING_FACTORS.map(factor => (
                        <div key={factor} className="flex items-center gap-2">
                          <Checkbox
                            id={`factor-${factor}`}
                            checked={formData.defaultFactors.includes(factor)}
                            onCheckedChange={() => toggleFactor(factor)}
                          />
                          <label htmlFor={`factor-${factor}`} className="text-sm">{factor}</label>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="scoring" className="space-y-4 mt-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Suggested Likelihood (1-5)</Label>
                      <Select value={formData.suggestedLikelihood} onValueChange={v => setFormData({ ...formData, suggestedLikelihood: v })}>
                        <SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 - Rare</SelectItem>
                          <SelectItem value="2">2 - Unlikely</SelectItem>
                          <SelectItem value="3">3 - Possible</SelectItem>
                          <SelectItem value="4">4 - Likely</SelectItem>
                          <SelectItem value="5">5 - Almost Certain</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Suggested Impact (1-5)</Label>
                      <Select value={formData.suggestedImpact} onValueChange={v => setFormData({ ...formData, suggestedImpact: v })}>
                        <SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 - Negligible</SelectItem>
                          <SelectItem value="2">2 - Minor</SelectItem>
                          <SelectItem value="3">3 - Moderate</SelectItem>
                          <SelectItem value="4">4 - Major</SelectItem>
                          <SelectItem value="5">5 - Severe</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Note: Suggested scoring values are defaults only. Users can edit them. Actual scoring follows the configured precedence rules.
                  </p>
                  <div className="space-y-2">
                    <Label>Linked Program Content (comma-separated)</Label>
                    <Input
                      value={formData.linkedContent}
                      onChange={e => setFormData({ ...formData, linkedContent: e.target.value })}
                      placeholder="SOP-MED-001, POLICY-SAFETY"
                    />
                  </div>
                  {editingTemplate && (
                    <div className="space-y-2">
                      <Label>Change Notes</Label>
                      <Textarea
                        value={formData.changeNotes}
                        onChange={e => setFormData({ ...formData, changeNotes: e.target.value })}
                        placeholder="Describe what changed in this version"
                        rows={2}
                      />
                    </div>
                  )}
                </TabsContent>
              </Tabs>
              
              <DialogFooter className="mt-6">
                <Button variant="outline" onClick={() => { setIsDialogOpen(false); resetForm(); }}>
                  Cancel
                </Button>
                <Button onClick={handleSave}>
                  {editingTemplate ? 'Update' : 'Create'} Template
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search templates..."
                  className="pl-10"
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {RISK_CATEGORIES.map(cat => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={visibilityFilter} onValueChange={setVisibilityFilter}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Visibility" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="Private">Private</SelectItem>
                  <SelectItem value="Department">Department</SelectItem>
                  <SelectItem value="Organization">Organization</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex items-center gap-2">
                <Checkbox id="show-archived" checked={showArchived} onCheckedChange={v => setShowArchived(!!v)} />
                <label htmlFor="show-archived" className="text-sm">Show archived</label>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Template List */}
        <div className="grid gap-4">
          {filteredTemplates.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center text-muted-foreground">
                No templates found matching your filters
              </CardContent>
            </Card>
          ) : (
            filteredTemplates.map(template => (
              <Card key={template.id} className={template.isArchived ? 'opacity-60' : ''}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        <CardTitle className="text-lg">{template.name}</CardTitle>
                        <Badge variant="outline">v{template.version}</Badge>
                        <Badge variant="secondary">{template.visibility}</Badge>
                        {template.isArchived && <Badge variant="destructive">Archived</Badge>}
                      </div>
                      <CardDescription>{template.description}</CardDescription>
                    </div>
                    <div className="flex gap-1 ml-4">
                      <Button variant="outline" size="sm" onClick={() => handleUseTemplate(template)} disabled={template.isArchived}>
                        <FileText className="h-4 w-4 mr-2" />
                        Use
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => { setPreviewTemplate(template); setIsPreviewOpen(true); }}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleEdit(template)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDuplicate(template)}>
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleArchive(template.id)}>
                        <Archive className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDelete(template.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Category:</span>
                      <p className="font-medium">{template.category}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Department:</span>
                      <p className="font-medium">{template.departmentId || '—'}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Linked Content:</span>
                      <p className="font-medium">{template.linkedContent.length} items</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Updated:</span>
                      <p className="font-medium">{new Date(template.updatedAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                  {template.tags.length > 0 && (
                    <div className="flex gap-1 mt-3 flex-wrap">
                      {template.tags.map(tag => (
                        <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Preview Dialog */}
        <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Template Preview</DialogTitle>
              <DialogDescription>What will be pre-filled when using this template</DialogDescription>
            </DialogHeader>
            {previewTemplate && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div><span className="text-muted-foreground">Category:</span> <strong>{previewTemplate.category}</strong></div>
                  <div><span className="text-muted-foreground">Report Type:</span> <strong>{previewTemplate.reportType || '—'}</strong></div>
                  <div><span className="text-muted-foreground">Department:</span> <strong>{previewTemplate.departmentId || '—'}</strong></div>
                  <div><span className="text-muted-foreground">Location Type:</span> <strong>{previewTemplate.locationType || '—'}</strong></div>
                  <div><span className="text-muted-foreground">Priority:</span> <strong>{previewTemplate.priority || 'Routine'}</strong></div>
                  <div><span className="text-muted-foreground">Facility Type:</span> <strong>{previewTemplate.facilityType || '—'}</strong></div>
                </div>
                {previewTemplate.suggestedTitle && (
                  <div><span className="text-muted-foreground">Suggested Title:</span> <strong>{previewTemplate.suggestedTitle}</strong></div>
                )}
                {previewTemplate.defaultFactors && previewTemplate.defaultFactors.length > 0 && (
                  <div>
                    <span className="text-muted-foreground">Default Factors:</span>
                    <div className="flex gap-1 mt-1 flex-wrap">
                      {previewTemplate.defaultFactors.map(f => <Badge key={f} variant="outline">{f}</Badge>)}
                    </div>
                  </div>
                )}
                {previewTemplate.linkedContent.length > 0 && (
                  <div>
                    <span className="text-muted-foreground">Linked Content:</span>
                    <div className="flex gap-1 mt-1 flex-wrap">
                      {previewTemplate.linkedContent.map(c => <Badge key={c} variant="secondary">{c}</Badge>)}
                    </div>
                  </div>
                )}
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsPreviewOpen(false)}>Close</Button>
              <Button onClick={() => { setIsPreviewOpen(false); if (previewTemplate) handleUseTemplate(previewTemplate); }}>
                Use This Template
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
