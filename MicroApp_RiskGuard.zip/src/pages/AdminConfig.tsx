import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import {
  ArrowLeft,
  Save,
  Plus,
  Trash2,
  Settings,
  ListChecks,
  Shield,
  Users,
  FileText,
  Upload,
  File,
  ExternalLink,
  X,
} from 'lucide-react';

// Types for category documents
interface CategoryDocument {
  id: string;
  name: string;
  type: 'policy' | 'procedure';
  url?: string;
  uploadedAt: string;
}

interface CategoryWithDocs {
  name: string;
  documents: CategoryDocument[];
}

// Stage Fields Editor Component
function StageFieldsEditor({ 
  stage, 
  fields, 
  onUpdate 
}: { 
  stage: string; 
  fields: string[]; 
  onUpdate: (fields: string[]) => void;
}) {
  const [newField, setNewField] = useState('');

  const handleAddField = () => {
    if (newField && !fields.includes(newField)) {
      onUpdate([...fields, newField]);
      setNewField('');
      toast.success(`Field "${newField}" added to ${stage.replace('Required', '')} stage`);
    }
  };

  const handleRemoveField = (field: string) => {
    onUpdate(fields.filter(f => f !== field));
    toast.success(`Field "${field}" removed`);
  };

  return (
    <div className="space-y-3 p-4 border border-border rounded-lg">
      <Label className="capitalize font-medium">{stage.replace('Required', '')} Stage</Label>
      <div className="flex gap-2">
        <Input
          value={newField}
          onChange={e => setNewField(e.target.value)}
          placeholder="Add required field..."
          onKeyDown={e => e.key === 'Enter' && handleAddField()}
          className="flex-1"
        />
        <Button size="sm" onClick={handleAddField}>
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <div className="flex flex-wrap gap-2">
        {fields.map(field => (
          <Badge key={field} variant="secondary" className="px-3 py-1.5 text-sm">
            {field}
            <button
              onClick={() => handleRemoveField(field)}
              className="ml-2 hover:text-destructive"
            >
              <Trash2 className="h-3 w-3" />
            </button>
          </Badge>
        ))}
      </div>
      <p className="text-xs text-muted-foreground">These fields are required to advance from this stage</p>
    </div>
  );
}

export default function AdminConfig() {
  const navigate = useNavigate();
  
  // Taxonomy config with documents
  const [categoriesWithDocs, setCategoriesWithDocs] = useState<CategoryWithDocs[]>([
    { name: 'Patient Safety', documents: [
      { id: '1', name: 'Patient Safety Policy v2.1', type: 'policy', uploadedAt: '2024-01-15' },
      { id: '2', name: 'Fall Prevention Procedure', type: 'procedure', uploadedAt: '2024-02-01' },
    ]},
    { name: 'Medication', documents: [
      { id: '3', name: 'Medication Administration Policy', type: 'policy', uploadedAt: '2024-01-10' },
    ]},
    { name: 'Fall', documents: [] },
    { name: 'Infection Control', documents: [
      { id: '4', name: 'Infection Control Policy', type: 'policy', uploadedAt: '2024-03-01' },
      { id: '5', name: 'Hand Hygiene Procedure', type: 'procedure', uploadedAt: '2024-03-05' },
    ]},
    { name: 'Clinical Care', documents: [] },
    { name: 'Device/Equipment', documents: [] },
    { name: 'Privacy/HIPAA', documents: [
      { id: '6', name: 'HIPAA Compliance Policy', type: 'policy', uploadedAt: '2024-01-01' },
    ]},
    { name: 'Compliance/Regulatory', documents: [] },
    { name: 'IT/Cyber', documents: [] },
    { name: 'Other', documents: [] },
  ]);
  const [newCategory, setNewCategory] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryWithDocs | null>(null);
  const [newDocName, setNewDocName] = useState('');
  const [newDocType, setNewDocType] = useState<'policy' | 'procedure'>('policy');
  const [newDocUrl, setNewDocUrl] = useState('');

  // Departments config
  const [departments, setDepartments] = useState([
    'Emergency Department', 'ICU', 'Medical/Surgical', 'Pharmacy', 'Laboratory',
    'Radiology', 'Operating Room', 'Outpatient Clinic', 'Administration', 'IT'
  ]);
  const [newDepartment, setNewDepartment] = useState('');


  // Threshold config
  const [thresholds, setThresholds] = useState({
    low: { min: 1, max: 3 },
    medium: { min: 4, max: 7 },
    high: { min: 8, max: 12 },
    critical: { min: 13, max: 25 },
  });

  // Stage rules
  const [stageRules, setStageRules] = useState({
    reportRequired: ['title', 'description', 'category', 'department'],
    evaluateRequired: ['likelihood', 'impact', 'readiness', 'evaluationSummary'],
    treatRequired: ['romeDecision', 'mitigationPlan'],
    monitorRequired: ['monitoringMetric'],
    reassessRequired: ['effectivenessReview'],
    closeRequired: ['closureReason', 'closureSummary'],
  });

  // Policies
  const [policies, setPolicies] = useState({
    allowAnonymousReporting: true,
    requireAttestationOnSubmit: true,
    autoEscalateSentinelEvents: true,
    requireApprovalForClose: true,
    enablePostClosureNotes: false,
    retentionPeriodYears: 7,
  });

  const handleAddCategory = () => {
    if (newCategory && !categoriesWithDocs.find(c => c.name === newCategory)) {
      setCategoriesWithDocs([...categoriesWithDocs, { name: newCategory, documents: [] }]);
      setNewCategory('');
      toast.success('Category added');
    }
  };

  const handleRemoveCategory = (cat: string) => {
    setCategoriesWithDocs(categoriesWithDocs.filter(c => c.name !== cat));
    toast.success('Category removed');
  };

  const handleAddDocument = () => {
    if (!selectedCategory || !newDocName) return;
    
    const newDoc: CategoryDocument = {
      id: Date.now().toString(),
      name: newDocName,
      type: newDocType,
      url: newDocUrl || undefined,
      uploadedAt: new Date().toISOString().split('T')[0],
    };
    
    setCategoriesWithDocs(categoriesWithDocs.map(cat => 
      cat.name === selectedCategory.name 
        ? { ...cat, documents: [...cat.documents, newDoc] }
        : cat
    ));
    
    setSelectedCategory(prev => prev ? { ...prev, documents: [...prev.documents, newDoc] } : null);
    setNewDocName('');
    setNewDocUrl('');
    toast.success('Document added');
  };

  const handleRemoveDocument = (docId: string) => {
    if (!selectedCategory) return;
    
    setCategoriesWithDocs(categoriesWithDocs.map(cat => 
      cat.name === selectedCategory.name 
        ? { ...cat, documents: cat.documents.filter(d => d.id !== docId) }
        : cat
    ));
    
    setSelectedCategory(prev => prev ? { ...prev, documents: prev.documents.filter(d => d.id !== docId) } : null);
    toast.success('Document removed');
  };

  const handleAddDepartment = () => {
    if (newDepartment && !departments.includes(newDepartment)) {
      setDepartments([...departments, newDepartment]);
      setNewDepartment('');
      toast.success('Department added');
    }
  };

  const handleRemoveDepartment = (dept: string) => {
    setDepartments(departments.filter(d => d !== dept));
    toast.success('Department removed');
  };


  const handleSave = () => {
    toast.success('Configuration saved successfully');
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6 max-w-5xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Admin Configuration</h1>
              <p className="text-muted-foreground">Manage taxonomy, thresholds, stage rules, and policies</p>
            </div>
          </div>
          <Button onClick={handleSave}>
            <Save className="h-4 w-4 mr-2" />
            Save Changes
          </Button>
        </div>

        <Tabs defaultValue="taxonomy">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="taxonomy" className="flex items-center gap-2">
              <ListChecks className="h-4 w-4" />
              Taxonomy
            </TabsTrigger>
            <TabsTrigger value="thresholds" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Thresholds
            </TabsTrigger>
            <TabsTrigger value="stages" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Stage Rules
            </TabsTrigger>
            <TabsTrigger value="policies" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Policies
            </TabsTrigger>
          </TabsList>

          <TabsContent value="taxonomy" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Risk Categories</CardTitle>
                <CardDescription>Configure the categories available for risk reporting</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={newCategory}
                    onChange={e => setNewCategory(e.target.value)}
                    placeholder="New category name"
                    onKeyDown={e => e.key === 'Enter' && handleAddCategory()}
                  />
                  <Button onClick={handleAddCategory}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {categoriesWithDocs.map(cat => (
                    <Badge 
                      key={cat.name} 
                      variant="secondary" 
                      className="px-3 py-1.5 text-sm cursor-pointer hover:bg-secondary/80 transition-colors"
                      onClick={() => setSelectedCategory(cat)}
                    >
                      <span className="flex items-center gap-1.5">
                        {cat.name}
                        {cat.documents.length > 0 && (
                          <span className="bg-primary/20 text-primary text-xs px-1.5 py-0.5 rounded-full">
                            {cat.documents.length}
                          </span>
                        )}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRemoveCategory(cat.name);
                        }}
                        className="ml-2 hover:text-destructive"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">Click a category to manage its policies and procedures</p>

                {/* Category Documents Dialog */}
                <Dialog open={!!selectedCategory} onOpenChange={(open) => !open && setSelectedCategory(null)}>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2">
                        <FileText className="h-5 w-5" />
                        {selectedCategory?.name} — Policies & Procedures
                      </DialogTitle>
                      <DialogDescription>
                        Manage policies and procedures documents for this risk category
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-4">
                      {/* Add new document */}
                      <Card>
                        <CardHeader className="py-3">
                          <CardTitle className="text-sm">Add Document</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div className="grid grid-cols-2 gap-3">
                            <div className="space-y-1.5">
                              <Label className="text-xs">Document Name</Label>
                              <Input
                                value={newDocName}
                                onChange={e => setNewDocName(e.target.value)}
                                placeholder="e.g., Fall Prevention Policy"
                              />
                            </div>
                            <div className="space-y-1.5">
                              <Label className="text-xs">Type</Label>
                              <Select value={newDocType} onValueChange={(v: 'policy' | 'procedure') => setNewDocType(v)}>
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="policy">Policy</SelectItem>
                                  <SelectItem value="procedure">Procedure</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <div className="space-y-1.5">
                            <Label className="text-xs">Document URL (optional)</Label>
                            <Input
                              value={newDocUrl}
                              onChange={e => setNewDocUrl(e.target.value)}
                              placeholder="https://..."
                            />
                          </div>
                          <Button onClick={handleAddDocument} disabled={!newDocName} size="sm">
                            <Plus className="h-4 w-4 mr-1" />
                            Add Document
                          </Button>
                        </CardContent>
                      </Card>

                      {/* Document list */}
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Documents ({selectedCategory?.documents.length || 0})</Label>
                        <ScrollArea className="h-[200px] border border-border rounded-lg">
                          {selectedCategory?.documents.length === 0 ? (
                            <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                              No documents added yet
                            </div>
                          ) : (
                            <div className="p-2 space-y-2">
                              {selectedCategory?.documents.map(doc => (
                                <div 
                                  key={doc.id} 
                                  className="flex items-center justify-between p-3 bg-muted/50 rounded-lg"
                                >
                                  <div className="flex items-center gap-3">
                                    <File className="h-4 w-4 text-muted-foreground" />
                                    <div>
                                      <p className="text-sm font-medium">{doc.name}</p>
                                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                        <Badge variant="outline" className="text-xs px-1.5 py-0">
                                          {doc.type}
                                        </Badge>
                                        <span>Added {doc.uploadedAt}</span>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-1">
                                    {doc.url && (
                                      <Button variant="ghost" size="icon" className="h-8 w-8" asChild>
                                        <a href={doc.url} target="_blank" rel="noopener noreferrer">
                                          <ExternalLink className="h-4 w-4" />
                                        </a>
                                      </Button>
                                    )}
                                    <Button 
                                      variant="ghost" 
                                      size="icon" 
                                      className="h-8 w-8 text-destructive hover:text-destructive"
                                      onClick={() => handleRemoveDocument(doc.id)}
                                    >
                                      <X className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </ScrollArea>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Departments</CardTitle>
                <CardDescription>Manage departments/units for risk assignment and scoping</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={newDepartment}
                    onChange={e => setNewDepartment(e.target.value)}
                    placeholder="New department name"
                    onKeyDown={e => e.key === 'Enter' && handleAddDepartment()}
                  />
                  <Button onClick={handleAddDepartment}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {departments.map(dept => (
                    <Badge key={dept} variant="secondary" className="px-3 py-1.5 text-sm">
                      {dept}
                      <button
                        onClick={() => handleRemoveDepartment(dept)}
                        className="ml-2 hover:text-destructive"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

          </TabsContent>

          <TabsContent value="thresholds" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Risk Level Thresholds</CardTitle>
                <CardDescription>Define score ranges for each risk level</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {(['low', 'medium', 'high', 'critical'] as const).map(level => (
                  <div key={level} className="space-y-2">
                    <Label className="capitalize flex items-center gap-2">
                      <Badge className={
                        level === 'critical' ? 'bg-risk-critical' :
                        level === 'high' ? 'bg-risk-high' :
                        level === 'medium' ? 'bg-risk-medium' :
                        'bg-risk-low'
                      }>
                        {level}
                      </Badge>
                    </Label>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">Min:</span>
                        <Input
                          type="number"
                          value={thresholds[level].min}
                          onChange={e => setThresholds({
                            ...thresholds,
                            [level]: { ...thresholds[level], min: parseInt(e.target.value) }
                          })}
                          className="w-20"
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">Max:</span>
                        <Input
                          type="number"
                          value={thresholds[level].max}
                          onChange={e => setThresholds({
                            ...thresholds,
                            [level]: { ...thresholds[level], max: parseInt(e.target.value) }
                          })}
                          className="w-20"
                        />
                      </div>
                    </div>
                  </div>
                ))}
                <p className="text-xs text-muted-foreground">
                  Risk Score = Likelihood × Impact × Readiness Factor. Scores are mapped to levels based on these thresholds.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="stages" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Required Fields by Stage</CardTitle>
                <CardDescription>Configure which fields must be completed before advancing to the next stage</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {Object.entries(stageRules).map(([stage, fields]) => (
                  <StageFieldsEditor
                    key={stage}
                    stage={stage}
                    fields={fields}
                    onUpdate={(newFields) => setStageRules({ ...stageRules, [stage]: newFields })}
                  />
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Stage Transitions</CardTitle>
                <CardDescription>Allowed transitions between stages</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <p>• <strong>Report</strong> → Evaluate</p>
                  <p>• <strong>Evaluate</strong> → Treat, Monitor, or Closed</p>
                  <p>• <strong>Treat</strong> → Monitor</p>
                  <p>• <strong>Monitor</strong> → Reassess</p>
                  <p>• <strong>Reassess</strong> → Treat (loop) or Closed</p>
                  <p className="text-muted-foreground mt-4">All stages support "Send Back" to the previous stage with required reason.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="policies" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Reporting Policies</CardTitle>
                <CardDescription>Configure organizational policies for risk reporting</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Allow Anonymous Reporting</Label>
                    <p className="text-sm text-muted-foreground">Reporters can submit without identifying themselves</p>
                  </div>
                  <Switch
                    checked={policies.allowAnonymousReporting}
                    onCheckedChange={v => setPolicies({ ...policies, allowAnonymousReporting: v })}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Require Attestation on Submit</Label>
                    <p className="text-sm text-muted-foreground">Reporter must confirm accuracy before submitting</p>
                  </div>
                  <Switch
                    checked={policies.requireAttestationOnSubmit}
                    onCheckedChange={v => setPolicies({ ...policies, requireAttestationOnSubmit: v })}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Auto-Escalate Sentinel Events</Label>
                    <p className="text-sm text-muted-foreground">Automatically route suspected sentinel events to leadership</p>
                  </div>
                  <Switch
                    checked={policies.autoEscalateSentinelEvents}
                    onCheckedChange={v => setPolicies({ ...policies, autoEscalateSentinelEvents: v })}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Require Approval for Closure</Label>
                    <p className="text-sm text-muted-foreground">Risk/Quality manager must approve before closing a risk</p>
                  </div>
                  <Switch
                    checked={policies.requireApprovalForClose}
                    onCheckedChange={v => setPolicies({ ...policies, requireApprovalForClose: v })}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Enable Post-Closure Notes</Label>
                    <p className="text-sm text-muted-foreground">Allow adding notes after a risk is closed</p>
                  </div>
                  <Switch
                    checked={policies.enablePostClosureNotes}
                    onCheckedChange={v => setPolicies({ ...policies, enablePostClosureNotes: v })}
                  />
                </div>
                <Separator />
                <div className="space-y-2">
                  <Label>Data Retention Period (years)</Label>
                  <Input
                    type="number"
                    value={policies.retentionPeriodYears}
                    onChange={e => setPolicies({ ...policies, retentionPeriodYears: parseInt(e.target.value) })}
                    className="w-32"
                  />
                  <p className="text-sm text-muted-foreground">How long to retain closed risk records</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
