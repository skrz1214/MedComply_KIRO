import { Link } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, Clock, CheckCircle2, Plus } from "lucide-react";

// Mock risk data
const mockRisks = [
  { id: "RISK-001", title: "Patient Data Access Control", category: "Data Privacy", department: "IT", status: "In Progress", dueDate: "2024-02-15", riskLevel: "High" },
  { id: "RISK-002", title: "Medication Storage Temperature", category: "Patient Safety", department: "Pharmacy", status: "In Progress", dueDate: "2024-02-20", riskLevel: "Critical" },
  { id: "RISK-003", title: "Staff Training Compliance", category: "Regulatory", department: "HR", status: "Overdue", dueDate: "2024-01-10", riskLevel: "Medium" },
  { id: "RISK-004", title: "Equipment Maintenance Schedule", category: "Operational", department: "Facilities", status: "Overdue", dueDate: "2024-01-25", riskLevel: "High" },
  { id: "RISK-005", title: "Infection Control Protocol", category: "Patient Safety", department: "Nursing", status: "Closed", dueDate: "2024-01-05", riskLevel: "Low" },
  { id: "RISK-006", title: "Vendor Security Assessment", category: "Data Privacy", department: "IT", status: "Closed", dueDate: "2024-01-15", riskLevel: "Medium" },
  { id: "RISK-007", title: "Emergency Response Drill", category: "Operational", department: "Admin", status: "In Progress", dueDate: "2024-02-28", riskLevel: "Medium" },
];

const getRiskLevelColor = (level: string) => {
  switch (level) {
    case "Critical": return "bg-risk-critical text-white";
    case "High": return "bg-risk-high text-white";
    case "Medium": return "bg-risk-medium text-foreground";
    case "Low": return "bg-risk-low text-foreground";
    default: return "bg-muted text-muted-foreground";
  }
};

const getStatusIcon = (status: string) => {
  switch (status) {
    case "In Progress": return <Clock className="h-4 w-4 text-primary" />;
    case "Overdue": return <AlertCircle className="h-4 w-4 text-destructive" />;
    case "Closed": return <CheckCircle2 className="h-4 w-4 text-green-600" />;
    default: return null;
  }
};

const RiskTable = ({ risks }: { risks: typeof mockRisks }) => (
  <Table>
    <TableHeader>
      <TableRow>
        <TableHead>Risk ID</TableHead>
        <TableHead>Title</TableHead>
        <TableHead>Category</TableHead>
        <TableHead>Department</TableHead>
        <TableHead>Risk Level</TableHead>
        <TableHead>Due Date</TableHead>
      </TableRow>
    </TableHeader>
    <TableBody>
      {risks.length === 0 ? (
        <TableRow>
          <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
            No risks found
          </TableCell>
        </TableRow>
      ) : (
        risks.map((risk) => (
          <TableRow key={risk.id} className="cursor-pointer hover:bg-muted/50">
            <TableCell>
              <Link to={`/risk/${risk.id}`} className="text-primary hover:underline font-medium">
                {risk.id}
              </Link>
            </TableCell>
            <TableCell className="font-medium">{risk.title}</TableCell>
            <TableCell>{risk.category}</TableCell>
            <TableCell>{risk.department}</TableCell>
            <TableCell>
              <Badge className={getRiskLevelColor(risk.riskLevel)}>{risk.riskLevel}</Badge>
            </TableCell>
            <TableCell>{risk.dueDate}</TableCell>
          </TableRow>
        ))
      )}
    </TableBody>
  </Table>
);

const Index = () => {
  const inProgressRisks = mockRisks.filter(r => r.status === "In Progress");
  const overdueRisks = mockRisks.filter(r => r.status === "Overdue");
  const closedRisks = mockRisks.filter(r => r.status === "Closed");

  return (
    <div className="bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary/90 to-secondary py-12">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div className="max-w-3xl">
              <h1 className="mb-4 text-3xl font-bold text-white">
                Medical Compliance Risk Management
              </h1>
              <p className="text-lg text-white/90">
                Comprehensive risk management for healthcare organizations. Manage compliance, evaluate risks, and ensure patient safety.
              </p>
            </div>
            <Link to="/report-risk">
              <Button size="lg" variant="secondary" className="flex items-center gap-2 shadow-lg">
                <Plus className="h-5 w-5" />
                Report Risk
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Quick Stats */}
      <section className="container mx-auto px-6 py-8">
        <div className="grid gap-4 md:grid-cols-4 max-w-5xl mx-auto">
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>In Progress</CardDescription>
              <CardTitle className="text-3xl text-primary">{inProgressRisks.length}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Overdue</CardDescription>
              <CardTitle className="text-3xl text-destructive">{overdueRisks.length}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Closed</CardDescription>
              <CardTitle className="text-3xl text-green-600">{closedRisks.length}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Total Risks</CardDescription>
              <CardTitle className="text-3xl">{mockRisks.length}</CardTitle>
            </CardHeader>
          </Card>
        </div>
      </section>

      {/* Risk Lists */}
      <section className="container mx-auto px-6 pb-12">
        <Card className="max-w-6xl mx-auto">
          <CardHeader>
            <CardTitle>Risk Overview</CardTitle>
            <CardDescription>View and manage all risks by status</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="in-progress" className="w-full">
              <TabsList className="grid w-full grid-cols-3 max-w-md">
                <TabsTrigger value="in-progress" className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  In Progress ({inProgressRisks.length})
                </TabsTrigger>
                <TabsTrigger value="overdue" className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  Overdue ({overdueRisks.length})
                </TabsTrigger>
                <TabsTrigger value="closed" className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4" />
                  Closed ({closedRisks.length})
                </TabsTrigger>
              </TabsList>
              <TabsContent value="in-progress" className="mt-6">
                <RiskTable risks={inProgressRisks} />
              </TabsContent>
              <TabsContent value="overdue" className="mt-6">
                <RiskTable risks={overdueRisks} />
              </TabsContent>
              <TabsContent value="closed" className="mt-6">
                <RiskTable risks={closedRisks} />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </section>
    </div>
  );
};

export default Index;
