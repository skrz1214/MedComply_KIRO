import { Shield, ArrowLeft, FileText, CheckCircle2, AlertCircle, Upload, X, Download, Paperclip } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { useState } from "react";

type Attachment = {
  name: string;
  size: number;
  uploadedBy: string;
  uploadedAt: string;
  step: string;
};

const RiskDetail = () => {
  const { riskId } = useParams();
  const [likelihood, setLikelihood] = useState("3");
  const [impact, setImpact] = useState("4");
  const [readiness, setReadiness] = useState("2");
  
  // Mock existing attachments from previous steps
  const [existingAttachments] = useState<Attachment[]>([
    { name: "incident-photo.jpg", size: 245, uploadedBy: "Jane Smith", uploadedAt: "2024-03-15 14:35", step: "Report" },
    { name: "witness-statement.pdf", size: 156, uploadedBy: "Jane Smith", uploadedAt: "2024-03-15 14:40", step: "Report" },
  ]);
  
  const [evaluateAttachments, setEvaluateAttachments] = useState<File[]>([]);
  const [treatmentAttachments, setTreatmentAttachments] = useState<File[]>([]);
  const [monitoringAttachments, setMonitoringAttachments] = useState<File[]>([]);

  const calculateScore = () => {
    const L = parseInt(likelihood);
    const I = parseInt(impact);
    const R = parseInt(readiness);
    const maxReadiness = 3;
    
    const baseScore = L * I;
    const readinessFactor = (maxReadiness + 1 - R) / maxReadiness;
    const adjustedScore = baseScore * readinessFactor;
    const scoreRounded = Math.round(adjustedScore);
    
    return { baseScore, adjustedScore, scoreRounded };
  };

  const getRiskLevel = (score: number) => {
    if (score >= 13) return { level: "Critical", color: "bg-risk-critical/10 text-risk-critical border-risk-critical/20" };
    if (score >= 8) return { level: "High", color: "bg-risk-high/10 text-risk-high border-risk-high/20" };
    if (score >= 4) return { level: "Medium", color: "bg-risk-medium/10 text-risk-medium border-risk-medium/20" };
    return { level: "Low", color: "bg-risk-low/10 text-risk-low border-risk-low/20" };
  };

  const { baseScore, adjustedScore, scoreRounded } = calculateScore();
  const { level, color } = getRiskLevel(scoreRounded);

  const handleEvaluationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Risk evaluation saved successfully");
  };

  const handleFileChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    setAttachments: React.Dispatch<React.SetStateAction<File[]>>
  ) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setAttachments(prev => [...prev, ...newFiles]);
    }
  };

  const removeAttachment = (
    index: number,
    setAttachments: React.Dispatch<React.SetStateAction<File[]>>
  ) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const AttachmentSection = ({ 
    currentAttachments, 
    setCurrentAttachments,
    inputId 
  }: { 
    currentAttachments: File[];
    setCurrentAttachments: React.Dispatch<React.SetStateAction<File[]>>;
    inputId: string;
  }) => (
    <div className="space-y-4">
      <div>
        <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
          <Paperclip className="h-4 w-4" />
          Previous Attachments ({existingAttachments.length})
        </h4>
        <div className="space-y-2">
          {existingAttachments.map((file, index) => (
            <div key={index} className="flex items-center justify-between p-3 border border-border rounded-lg bg-muted/20">
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">{file.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {file.size} KB • {file.step} • {file.uploadedBy} • {file.uploadedAt}
                  </p>
                </div>
              </div>
              <Button variant="ghost" size="sm">
                <Download className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      <div>
        <h4 className="text-sm font-semibold mb-3">Add New Attachments</h4>
        <div className="border-2 border-dashed border-border rounded-lg p-4 hover:border-primary/50 transition-colors">
          <div className="flex flex-col items-center gap-2 text-center">
            <Upload className="h-6 w-6 text-muted-foreground" />
            <div>
              <Label htmlFor={inputId} className="cursor-pointer text-primary hover:text-primary/80 text-sm">
                Click to upload
              </Label>
              <span className="text-muted-foreground text-sm"> or drag and drop</span>
            </div>
            <p className="text-xs text-muted-foreground">
              PDF, images, documents (max 10MB each)
            </p>
            <Input
              id={inputId}
              type="file"
              multiple
              onChange={(e) => handleFileChange(e, setCurrentAttachments)}
              className="hidden"
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif"
            />
          </div>
        </div>
        
        {currentAttachments.length > 0 && (
          <div className="mt-3 space-y-2">
            <p className="text-sm font-medium">New files ({currentAttachments.length})</p>
            {currentAttachments.map((file, index) => (
              <div key={index} className="flex items-center justify-between p-3 border border-border rounded-lg bg-muted/30">
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-primary" />
                  <div>
                    <p className="text-sm font-medium">{file.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {(file.size / 1024).toFixed(1)} KB
                    </p>
                  </div>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => removeAttachment(index, setCurrentAttachments)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">RiskGuard</h1>
            </Link>
            <Button variant="outline" asChild>
              <Link to="/process">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Process
              </Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Risk Header */}
      <section className="bg-gradient-to-br from-secondary/5 to-primary/5 border-b border-border">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Badge variant="outline">R-001</Badge>
                <Badge variant="outline" className="bg-status-evaluation/10 text-status-evaluation border-status-evaluation/20">
                  Under Evaluation
                </Badge>
                <Badge variant="outline" className={color}>
                  {level}
                </Badge>
              </div>
              <h2 className="text-3xl font-bold text-foreground mb-2">
                Patient fall in room 204
              </h2>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>Category: Falls</span>
                <span>•</span>
                <span>Department: Nursing</span>
                <span>•</span>
                <span>Reported: 2024-03-15</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="container mx-auto px-6 py-8">
        <Tabs defaultValue="evaluate" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="evaluate">Evaluate</TabsTrigger>
            <TabsTrigger value="treatment">Treatment</TabsTrigger>
            <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Risk Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-muted-foreground">Description</Label>
                  <p className="mt-1">
                    Patient in room 204 experienced a fall while attempting to reach the bathroom without assistance. 
                    Patient sustained minor bruising but no serious injuries. Staff responded immediately.
                  </p>
                </div>
                <Separator />
                <div>
                  <Label className="text-muted-foreground">Location</Label>
                  <p className="mt-1">Room 204, East Wing</p>
                </div>
                <Separator />
                <div>
                  <Label className="text-muted-foreground">Reported By</Label>
                  <p className="mt-1">Jane Smith, RN</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Linked Program Content</CardTitle>
                <CardDescription>Related SOPs and policies</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 p-3 border border-border rounded-lg">
                    <FileText className="h-4 w-4 text-primary" />
                    <span className="font-medium">Fall Risk Assessment Protocol</span>
                  </div>
                  <div className="flex items-center gap-2 p-3 border border-border rounded-lg">
                    <FileText className="h-4 w-4 text-primary" />
                    <span className="font-medium">Post-Fall Response Procedure</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="evaluate" className="space-y-6">
            <form onSubmit={handleEvaluationSubmit}>
              <Card>
                <CardHeader>
                  <CardTitle>Risk Evaluation</CardTitle>
                  <CardDescription>
                    Assess likelihood, impact, and readiness to calculate risk score
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="likelihood">Likelihood (1-5)</Label>
                    <Select value={likelihood} onValueChange={setLikelihood}>
                      <SelectTrigger id="likelihood">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 - Rare</SelectItem>
                        <SelectItem value="2">2 - Unlikely</SelectItem>
                        <SelectItem value="3">3 - Possible</SelectItem>
                        <SelectItem value="4">4 - Likely</SelectItem>
                        <SelectItem value="5">5 - Almost Certain</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="impact">Impact (1-5)</Label>
                    <Select value={impact} onValueChange={setImpact}>
                      <SelectTrigger id="impact">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 - Negligible</SelectItem>
                        <SelectItem value="2">2 - Minor</SelectItem>
                        <SelectItem value="3">3 - Moderate</SelectItem>
                        <SelectItem value="4">4 - Major</SelectItem>
                        <SelectItem value="5">5 - Severe</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="readiness">Readiness (1-3)</Label>
                    <Select value={readiness} onValueChange={setReadiness}>
                      <SelectTrigger id="readiness">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 - Low Readiness (weak controls)</SelectItem>
                        <SelectItem value="2">2 - Medium Readiness</SelectItem>
                        <SelectItem value="3">3 - High Readiness (strong controls)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  <div className="bg-muted/50 p-6 rounded-lg space-y-3">
                    <h3 className="font-semibold text-lg">Calculated Risk Score</h3>
                    <div className="grid gap-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Base Score (L × I):</span>
                        <span className="font-medium">{baseScore}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Adjusted Score:</span>
                        <span className="font-medium">{adjustedScore.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Rounded Score:</span>
                        <span className="font-medium">{scoreRounded}</span>
                      </div>
                      <Separator />
                      <div className="flex justify-between items-center pt-2">
                        <span className="font-semibold">Risk Level:</span>
                        <Badge variant="outline" className={color}>
                          {level}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground mt-4">
                      Formula: baseScore = L × I; readinessFactor = (4 - R) / 3; adjustedScore = baseScore × readinessFactor
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="evaluation-notes">Evaluation Notes</Label>
                    <Textarea
                      id="evaluation-notes"
                      placeholder="Additional context or observations about this risk"
                      rows={4}
                    />
                  </div>

                  <Separator />

                  <AttachmentSection 
                    currentAttachments={evaluateAttachments}
                    setCurrentAttachments={setEvaluateAttachments}
                    inputId="evaluate-file-upload"
                  />

                  <Button type="submit" className="w-full">
                    Save Evaluation
                  </Button>
                </CardContent>
              </Card>
            </form>
          </TabsContent>

          <TabsContent value="treatment" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Treatment Plan</CardTitle>
                <CardDescription>
                  Define ROME strategy: Retain / Optimize / Mitigate / Eliminate
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="rome-decision">ROME Decision</Label>
                  <Select>
                    <SelectTrigger id="rome-decision">
                      <SelectValue placeholder="Select treatment approach" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="retain">Retain - Accept the risk</SelectItem>
                      <SelectItem value="optimize">Optimize - Improve controls</SelectItem>
                      <SelectItem value="mitigate">Mitigate - Reduce impact/likelihood</SelectItem>
                      <SelectItem value="eliminate">Eliminate - Remove the risk</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="treatment-actions">Treatment Actions</Label>
                  <Textarea
                    id="treatment-actions"
                    placeholder="Describe specific actions to be taken"
                    rows={4}
                  />
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="responsible">Responsible Person</Label>
                    <Input id="responsible" placeholder="Name and role" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="target-date">Target Date</Label>
                    <Input id="target-date" type="date" />
                  </div>
                </div>

                <Separator />

                <AttachmentSection 
                  currentAttachments={treatmentAttachments}
                  setCurrentAttachments={setTreatmentAttachments}
                  inputId="treatment-file-upload"
                />

                <Button className="w-full">
                  Save Treatment Plan
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="monitoring" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Monitoring & Reassessment</CardTitle>
                <CardDescription>
                  Track residual risk and monitor treatment effectiveness
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-muted/50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle2 className="h-5 w-5 text-status-monitoring" />
                    <span className="font-semibold">Current Status</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Treatment plan is being executed. Next review scheduled for 2024-04-15.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="monitoring-notes">Monitoring Notes</Label>
                  <Textarea
                    id="monitoring-notes"
                    placeholder="Document progress, observations, and any changes"
                    rows={4}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="next-review">Next Review Date</Label>
                  <Input id="next-review" type="date" />
                </div>

                <Separator />

                <AttachmentSection 
                  currentAttachments={monitoringAttachments}
                  setCurrentAttachments={setMonitoringAttachments}
                  inputId="monitoring-file-upload"
                />

                <Button className="w-full">
                  Update Monitoring Status
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>All Attachments</CardTitle>
                <CardDescription>View all evidence and documents across all steps</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {existingAttachments.map((file, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border border-border rounded-lg bg-muted/20">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">{file.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {file.size} KB • Step: {file.step} • {file.uploadedBy} • {file.uploadedAt}
                          </p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Risk History</CardTitle>
                <CardDescription>Timeline of actions and updates</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className="rounded-full bg-primary/10 p-2">
                        <AlertCircle className="h-4 w-4 text-primary" />
                      </div>
                      <div className="h-full w-px bg-border mt-2" />
                    </div>
                    <div className="flex-1 pb-4">
                      <p className="font-medium">Risk Reported</p>
                      <p className="text-sm text-muted-foreground">Jane Smith, RN</p>
                      <p className="text-xs text-muted-foreground">2024-03-15 14:30</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className="rounded-full bg-secondary/10 p-2">
                        <CheckCircle2 className="h-4 w-4 text-secondary" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">Evaluation Started</p>
                      <p className="text-sm text-muted-foreground">Dr. Michael Chen</p>
                      <p className="text-xs text-muted-foreground">2024-03-15 16:00</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </section>
    </div>
  );
};

export default RiskDetail;
