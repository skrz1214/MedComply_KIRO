import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { CrossAppReference, RELATIONSHIP_TYPES } from '@/lib/types';
import { Link2, Plus, ExternalLink, X } from 'lucide-react';
import { toast } from 'sonner';

interface LinkedItemsPanelProps {
  references: CrossAppReference[];
  onAdd?: (ref: Omit<CrossAppReference, 'id' | 'createdAt' | 'createdBy'>) => void;
  onRemove?: (id: string, reason: string) => void;
  readOnly?: boolean;
}

const APP_OPTIONS = [
  { value: 'RiskGuard', label: 'RiskGuard', prefix: 'RG' },
  { value: 'ComplianceConnect', label: 'ComplianceConnect', prefix: 'CC' },
  { value: 'EnforcePoint', label: 'EnforcePoint', prefix: 'EP' },
  { value: 'FeedbackHub', label: 'FeedbackHub', prefix: 'FH' },
  { value: 'AuditPro', label: 'AuditPro', prefix: 'AP' },
] as const;

// Mock linked items for demo
const MOCK_SEARCH_RESULTS = [
  { id: 'CC-1001', title: 'HIPAA Compliance Policy', app: 'ComplianceConnect', status: 'Active' },
  { id: 'CC-1002', title: 'Patient Safety Protocol', app: 'ComplianceConnect', status: 'Active' },
  { id: 'FH-2001', title: 'Patient Complaint - Wait Time', app: 'FeedbackHub', status: 'Resolved' },
  { id: 'AP-3001', title: 'Quarterly Safety Audit', app: 'AuditPro', status: 'Complete' },
  { id: 'EP-4001', title: 'CMS Citation Response', app: 'EnforcePoint', status: 'Pending' },
];

export function LinkedItemsPanel({ references, onAdd, onRemove, readOnly = false }: LinkedItemsPanelProps) {
  const [isLinkOpen, setIsLinkOpen] = useState(false);
  const [isUnlinkOpen, setIsUnlinkOpen] = useState(false);
  const [unlinkId, setUnlinkId] = useState<string | null>(null);
  const [unlinkReason, setUnlinkReason] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [targetApp, setTargetApp] = useState<string>('');
  const [relationshipType, setRelationshipType] = useState<string>('');
  const [linkNote, setLinkNote] = useState('');
  const [selectedItem, setSelectedItem] = useState<typeof MOCK_SEARCH_RESULTS[0] | null>(null);

  const filteredResults = MOCK_SEARCH_RESULTS.filter(item => 
    (!targetApp || item.app === targetApp) &&
    item.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleLink = () => {
    if (!selectedItem || !relationshipType) {
      toast.error('Please select an item and relationship type');
      return;
    }
    onAdd?.({
      sourceApp: 'RiskGuard',
      sourceRecordId: '',
      targetApp: selectedItem.app as any,
      targetRecordId: selectedItem.id,
      targetTitle: selectedItem.title,
      relationshipType,
      linkNote,
    });
    toast.success('Item linked successfully');
    setIsLinkOpen(false);
    resetForm();
  };

  const handleUnlink = () => {
    if (!unlinkId || !unlinkReason.trim()) {
      toast.error('Please provide a reason for unlinking');
      return;
    }
    onRemove?.(unlinkId, unlinkReason);
    toast.success('Item unlinked');
    setIsUnlinkOpen(false);
    setUnlinkId(null);
    setUnlinkReason('');
  };

  const resetForm = () => {
    setSearchQuery('');
    setTargetApp('');
    setRelationshipType('');
    setLinkNote('');
    setSelectedItem(null);
  };

  const getAppBadgeColor = (app: string) => {
    const colors: Record<string, string> = {
      RiskGuard: 'bg-primary/10 text-primary',
      ComplianceConnect: 'bg-secondary/10 text-secondary',
      EnforcePoint: 'bg-destructive/10 text-destructive',
      FeedbackHub: 'bg-accent/10 text-accent',
      AuditPro: 'bg-status-monitoring/10 text-status-monitoring',
    };
    return colors[app] || 'bg-muted text-muted-foreground';
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-base">
              <Link2 className="h-4 w-4" />
              Linked Items
            </CardTitle>
            <CardDescription>Cross-app references</CardDescription>
          </div>
          {!readOnly && (
            <Dialog open={isLinkOpen} onOpenChange={setIsLinkOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Plus className="h-4 w-4 mr-1" />
                  Link
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Link to External Record</DialogTitle>
                  <DialogDescription>
                    Search and link records from other applications
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Target Application</Label>
                      <Select value={targetApp} onValueChange={setTargetApp}>
                        <SelectTrigger>
                          <SelectValue placeholder="All applications" />
                        </SelectTrigger>
                        <SelectContent>
                          {APP_OPTIONS.filter(a => a.value !== 'RiskGuard').map(app => (
                            <SelectItem key={app.value} value={app.value}>
                              {app.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Search</Label>
                      <Input
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        placeholder="Search by ID or title..."
                      />
                    </div>
                  </div>

                  <div className="border rounded-lg max-h-48 overflow-y-auto">
                    {filteredResults.length === 0 ? (
                      <p className="text-sm text-muted-foreground p-4 text-center">No results found</p>
                    ) : (
                      filteredResults.map(item => (
                        <div
                          key={item.id}
                          onClick={() => setSelectedItem(item)}
                          className={`flex items-center justify-between p-3 border-b last:border-b-0 cursor-pointer transition-colors ${
                            selectedItem?.id === item.id ? 'bg-primary/10' : 'hover:bg-muted/50'
                          }`}
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">{item.id}</Badge>
                              <Badge className={getAppBadgeColor(item.app)} variant="outline">
                                {item.app}
                              </Badge>
                            </div>
                            <p className="text-sm font-medium mt-1">{item.title}</p>
                          </div>
                          <Badge variant="secondary">{item.status}</Badge>
                        </div>
                      ))
                    )}
                  </div>

                  {selectedItem && (
                    <>
                      <div className="space-y-2">
                        <Label>Relationship Type *</Label>
                        <Select value={relationshipType} onValueChange={setRelationshipType}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select relationship" />
                          </SelectTrigger>
                          <SelectContent>
                            {RELATIONSHIP_TYPES.map(type => (
                              <SelectItem key={type} value={type}>{type}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Link Note (optional)</Label>
                        <Textarea
                          value={linkNote}
                          onChange={e => setLinkNote(e.target.value)}
                          placeholder="Add context about this link..."
                          rows={2}
                        />
                      </div>
                    </>
                  )}
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => { setIsLinkOpen(false); resetForm(); }}>
                    Cancel
                  </Button>
                  <Button onClick={handleLink} disabled={!selectedItem || !relationshipType}>
                    Link Item
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {references.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">No linked items</p>
        ) : (
          <div className="space-y-2">
            {references.map(ref => (
              <div
                key={ref.id}
                className="flex items-center justify-between p-3 border rounded-lg bg-muted/30"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline" className="text-xs">{ref.targetRecordId}</Badge>
                    <Badge className={getAppBadgeColor(ref.targetApp)} variant="outline">
                      {ref.targetApp}
                    </Badge>
                  </div>
                  <p className="text-sm font-medium truncate">{ref.targetTitle}</p>
                  <p className="text-xs text-muted-foreground">{ref.relationshipType}</p>
                </div>
                <div className="flex items-center gap-1 ml-2">
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                  {!readOnly && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => { setUnlinkId(ref.id); setIsUnlinkOpen(true); }}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        <Dialog open={isUnlinkOpen} onOpenChange={setIsUnlinkOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Unlink Item</DialogTitle>
              <DialogDescription>Please provide a reason for removing this link</DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <Label>Reason *</Label>
              <Textarea
                value={unlinkReason}
                onChange={e => setUnlinkReason(e.target.value)}
                placeholder="Explain why this link is being removed..."
                rows={3}
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsUnlinkOpen(false)}>Cancel</Button>
              <Button variant="destructive" onClick={handleUnlink}>Unlink</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
