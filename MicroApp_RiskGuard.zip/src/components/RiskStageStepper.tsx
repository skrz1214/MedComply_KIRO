import { RiskStage, getStageStyle } from '@/lib/types';
import { cn } from '@/lib/utils';
import { FileText, ClipboardCheck, Stethoscope, Eye, RefreshCw, CheckCircle2 } from 'lucide-react';

const STAGES: { key: RiskStage; label: string; icon: React.ElementType }[] = [
  { key: 'Report', label: 'Report', icon: FileText },
  { key: 'Evaluate', label: 'Evaluate', icon: ClipboardCheck },
  { key: 'Treat', label: 'Treat', icon: Stethoscope },
  { key: 'Monitor', label: 'Monitor', icon: Eye },
  { key: 'Reassess', label: 'Reassess', icon: RefreshCw },
  { key: 'Closed', label: 'Closed', icon: CheckCircle2 },
];

interface RiskStageStepperProps {
  currentStage: RiskStage;
  className?: string;
}

export function RiskStageStepper({ currentStage, className }: RiskStageStepperProps) {
  const currentIndex = STAGES.findIndex(s => s.key === currentStage);

  return (
    <div className={cn('flex items-center justify-between gap-2', className)}>
      {STAGES.map((stage, index) => {
        const Icon = stage.icon;
        const isCompleted = index < currentIndex;
        const isCurrent = index === currentIndex;
        const isPending = index > currentIndex;
        const style = getStageStyle(stage.key);

        return (
          <div key={stage.key} className="flex items-center flex-1">
            <div className="flex flex-col items-center flex-1">
              <div
                className={cn(
                  'flex h-10 w-10 items-center justify-center rounded-full border-2 transition-all',
                  isCompleted && 'bg-status-closed border-status-closed text-primary-foreground',
                  isCurrent && cn(style.bgColor, style.borderColor, style.color),
                  isPending && 'bg-muted border-border text-muted-foreground'
                )}
              >
                {isCompleted ? (
                  <CheckCircle2 className="h-5 w-5" />
                ) : (
                  <Icon className="h-5 w-5" />
                )}
              </div>
              <span
                className={cn(
                  'mt-2 text-xs font-medium',
                  isCurrent && style.color,
                  isCompleted && 'text-status-closed',
                  isPending && 'text-muted-foreground'
                )}
              >
                {stage.label}
              </span>
            </div>
            {index < STAGES.length - 1 && (
              <div
                className={cn(
                  'h-0.5 w-full max-w-[60px] mx-2',
                  index < currentIndex ? 'bg-status-closed' : 'bg-border'
                )}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}
