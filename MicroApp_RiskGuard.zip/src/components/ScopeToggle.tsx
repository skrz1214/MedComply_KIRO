import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { Building2, User, Users } from 'lucide-react';

export type UserRole = 'admin' | 'compliance_head' | 'department_head' | 'contributor';
export type ScopeFilter = 'organization' | 'department' | 'personal';

interface ScopeToggleProps {
  role: UserRole;
  value: ScopeFilter;
  onChange: (value: ScopeFilter) => void;
}

export function ScopeToggle({ role, value, onChange }: ScopeToggleProps) {
  const isOrgLevel = role === 'admin' || role === 'compliance_head';
  
  return (
    <ToggleGroup
      type="single"
      value={value}
      onValueChange={(val) => val && onChange(val as ScopeFilter)}
      className="bg-muted rounded-lg p-1"
    >
      {isOrgLevel ? (
        <>
          <ToggleGroupItem
            value="organization"
            aria-label="Organization scope"
            className="data-[state=on]:bg-background data-[state=on]:text-foreground px-3 py-1.5 text-sm"
          >
            <Building2 className="h-4 w-4 mr-1.5" />
            Organization
          </ToggleGroupItem>
          <ToggleGroupItem
            value="personal"
            aria-label="Personal scope"
            className="data-[state=on]:bg-background data-[state=on]:text-foreground px-3 py-1.5 text-sm"
          >
            <User className="h-4 w-4 mr-1.5" />
            Personal
          </ToggleGroupItem>
        </>
      ) : (
        <>
          <ToggleGroupItem
            value="department"
            aria-label="Department scope"
            className="data-[state=on]:bg-background data-[state=on]:text-foreground px-3 py-1.5 text-sm"
          >
            <Users className="h-4 w-4 mr-1.5" />
            Department
          </ToggleGroupItem>
          <ToggleGroupItem
            value="personal"
            aria-label="Personal scope"
            className="data-[state=on]:bg-background data-[state=on]:text-foreground px-3 py-1.5 text-sm"
          >
            <User className="h-4 w-4 mr-1.5" />
            Personal
          </ToggleGroupItem>
        </>
      )}
    </ToggleGroup>
  );
}
