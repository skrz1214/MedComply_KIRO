import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Layout } from "./components/Layout";
import { RiskStoreProvider } from "./lib/riskStore";
import Dashboard from "./pages/Dashboard";
import Program from "./pages/Program";
import ProgramDetail from "./pages/ProgramDetail";
import RiskList from "./pages/RiskList";
import NewRiskWizard from "./pages/NewRiskWizard";
import RiskDetailView from "./pages/RiskDetailView";
import ScoringSettings from "./pages/ScoringSettings";
import TemplateLibrary from "./pages/TemplateLibrary";
import AdminConfig from "./pages/AdminConfig";
import Evaluate from "./pages/stages/Evaluate";
import Treat from "./pages/stages/Treat";
import Monitor from "./pages/stages/Monitor";
import Reassess from "./pages/stages/Reassess";
import PRDDocument from "./pages/PRDDocument";
import QATestCases from "./pages/QATestCases";
import UATTestCases from "./pages/UATTestCases";
import SystemPrompt from "./pages/SystemPrompt";
import Process from "./pages/Process";
import ReportRisk from "./pages/ReportRisk";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <RiskStoreProvider>
        <BrowserRouter>
          <Layout>
            <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/process" element={<Process />} />
            <Route path="/report-risk" element={<ReportRisk />} />
            <Route path="/program" element={<Program />} />
            <Route path="/program/:categoryId" element={<ProgramDetail />} />
            <Route path="/risks" element={<RiskList />} />
            <Route path="/risks/new" element={<NewRiskWizard />} />
            <Route path="/risks/:riskId" element={<RiskDetailView />} />
            <Route path="/risks/:riskId/evaluate" element={<Evaluate />} />
            <Route path="/risks/:riskId/treat" element={<Treat />} />
            <Route path="/risks/:riskId/monitor" element={<Monitor />} />
            <Route path="/risks/:riskId/reassess" element={<Reassess />} />
            <Route path="/scoring-settings" element={<ScoringSettings />} />
            <Route path="/scenario-templates" element={<TemplateLibrary />} />
            <Route path="/admin" element={<AdminConfig />} />
            <Route path="/prd" element={<PRDDocument />} />
            <Route path="/qa-test-cases" element={<QATestCases />} />
            <Route path="/uat-test-cases" element={<UATTestCases />} />
            <Route path="/system-prompt" element={<SystemPrompt />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
            </Routes>
          </Layout>
        </BrowserRouter>
      </RiskStoreProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
