## Goal

Any risk created through the reporting flows — both **Submitted** reports and **Drafts** saved mid-way — should immediately show up in the Risk Queue list at `/risks`.

## Current behavior (verified)

- `src/pages/NewRiskWizard.tsx` — `handleSubmit` only generates an ID, fires a toast, and navigates to `/risks`. `handleSaveDraft` only fires a toast. Neither stores anything.
- `src/pages/ReportRisk.tsx` — the quick form's submit only toasts and navigates.
- `src/pages/RiskList.tsx` reads directly from the static `mockRisks` array in `src/lib/mockData.ts`, so nothing new can ever appear.

## What to build

**1. A shared in-app risk store**

Add a small store (React context + provider in `App.tsx`, backed by `localStorage` so refreshes don't wipe reports):

- Holds the seeded `mockRisks` plus any user-created risks.
- `addRisk(risk)` and `updateRisk(id, patch)` for submit/draft-save.
- Exposes the merged list and the existing helpers (`getRiskById`, `getRiskStats`, `getRisksByStage`) so other screens stay consistent.

**2. Wire the reporting flows into it**

- **Wizard submit** — build a `RiskReport` from `formData` (title, description, category, department, report type, dates, harm levels, contributing factors, reporter), stage `Report`, substatus `Submitted`, and add it to the store before navigating.
- **Wizard Save Draft** — create the record on first save with substatus `Draft` (keep its generated ID in state), and update the same record on subsequent saves. Drafts do not require attestation/validation.
- **Quick report form (`ReportRisk.tsx`)** — same mapping, added as `Submitted`.

**3. Surface them in the Risk Queue**

- `RiskList.tsx` reads from the store instead of importing `mockRisks` directly, so new entries and stage counts update automatically.
- Show a small `Draft` / `Submitted` badge next to the Report-stage entries so unfinished reports are distinguishable.
- Newest-first ordering so a just-created report is at the top.
- Clicking a Draft reopens the wizard prefilled; clicking a Submitted report opens the existing detail/stage route (unchanged behavior).

## Technical notes

- No backend involved; this is client-side state persisted to `localStorage`. If you later want reports shared across users/devices, that needs Lovable Cloud — say the word and I'll plan that instead.
- Assignee for new reports defaults to unassigned (or the department's default reviewer) since the Report stage has no assignee picker today.
