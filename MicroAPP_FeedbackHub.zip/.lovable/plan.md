# Add QA & UAT Test Documents to Documentation Page

Extend the existing Documentation page (`src/pages/Documentation.tsx`) with two new tabs and downloadable markdown documents alongside the existing PRD and System Prompt.

## New Documents

### 1. QA Test Plan (`FeedbackHub-QA-TestPlan.md`)
Technical test cases covering:
- **Test Environment & Setup** — roles, test data, prerequisites
- **Functional Test Cases** — organized by feature area:
  - Feedback Submission (form validation, attachments, microapp labels/refs, due date)
  - Dashboard & Scope Toggle (Personal/Department/Organization filtering per role)
  - Task Tabs (To Do, To Review, Overdue, Resolved, Closed filter logic)
  - Feedback Details (status transitions, priority, reassignment, notes)
  - Admin Settings (CRUD for departments/categories/priorities, routing rules, test rules panel, workflow policy, metrics thresholds, audit log)
  - Role-Based Access (each role's permissions and restrictions)
- **Cross-Microapp Integration** — labels and references behavior
- **Analytics & Metrics** — threshold color coding, chart accuracy
- **Negative Test Cases** — invalid inputs, missing permissions, edge cases
- **Regression Checklist** — critical paths
- **Defect Severity Definitions**

Each test case: ID, Title, Preconditions, Steps, Expected Result, Priority.

### 2. UAT Test Plan (`FeedbackHub-UAT-TestPlan.md`)
Business-user-focused scenarios covering:
- **UAT Overview & Objectives**
- **User Acceptance Criteria** by role:
  - Healthcare Staff scenarios (submit, track own feedback)
  - Department Manager scenarios (department oversight, assignment)
  - Compliance Officer scenarios (org-wide view, analytics, lifecycle)
  - Administrator scenarios (configuration, policies, audit)
- **End-to-End Workflow Scenarios** — realistic compliance feedback lifecycles
- **Sign-off Criteria** — pass/fail thresholds
- **UAT Test Execution Log Template** — for testers to record results
- **Issue Reporting Template**

Each scenario: Scenario ID, Business Context, Actor Role, Steps, Expected Outcome, Pass/Fail.

## UI Changes

`src/pages/Documentation.tsx`:
- Add 2 new `TabsTrigger` entries: "QA Test Plan" (ClipboardCheck icon) and "UAT Test Plan" (UserCheck icon)
- Add corresponding `TabsContent` panels matching the existing PRD/System Prompt card pattern (header with title, description, Download button; preview pane showing the markdown content)
- Reuse the existing `downloadDocument` helper

No changes needed to routing, sidebar, contexts, or other components — the existing Documentation tab in the sidebar already opens this page.

## Technical Notes

- Documents stored as string constants in `Documentation.tsx` (consistent with existing PRD/System Prompt pattern)
- Markdown format (`.md`) with `text/markdown` MIME for downloads
- Preview rendered in scrollable monospace `<pre>` block (same as existing tabs)
- Tabs list will wrap responsively to handle 4 tabs on smaller viewports
