// User roles
export type UserRole = 'healthcare-staff' | 'compliance-officer' | 'department-manager' | 'administrator';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department?: string;
  createdAt: string;
}

// Admin configuration types
export interface Department {
  id: string;
  name: string;
  code: string;
  managerId?: string;
  isActive: boolean;
  createdAt: string;
}

export interface CategoryConfig {
  id: string;
  name: string;
  code: string;
  description?: string;
  isActive: boolean;
  order: number;
}

export interface PriorityConfig {
  id: string;
  name: string;
  code: string;
  dueDays: number;
  color: string;
  isActive: boolean;
  order: number;
}

export interface RoutingRule {
  id: string;
  name: string;
  description?: string;
  conditions: RoutingCondition[];
  assignTo: string;
  setDueDays?: number;
  order: number;
  isActive: boolean;
}

export interface RoutingCondition {
  field: 'category' | 'priority' | 'department';
  operator: 'equals' | 'not_equals' | 'in';
  value: string | string[];
}

export interface WorkflowPolicy {
  allowSendBack: boolean;
  requireResolutionNote: boolean;
  requireClosureNote: boolean;
  whoCanChangeStatus: UserRole[];
  whoCanReassign: UserRole[];
  whoCanChangePriority: UserRole[];
  staffCanAddNotes: boolean;
  managerCanChangeStatus: boolean;
  managerCanReassign: boolean;
}

export interface AttachmentPolicy {
  submissionMaxFiles: number;
  submissionMaxSizeMB: number;
  noteMaxFiles: number;
  noteMaxSizeMB: number;
  allowedFileTypes: string[];
  enableDragDrop: boolean;
}

export interface ActivityFeedPolicy {
  enabledEventTypes: string[];
  retentionDays: number;
  staffSeesOwnOnly: boolean;
  managerSeesDepartmentOnly: boolean;
}

export interface AuditLogEntry {
  id: string;
  action: string;
  actor: string;
  actorRole: UserRole;
  entityType: string;
  entityId: string;
  changes: Record<string, { old: unknown; new: unknown }>;
  timestamp: string;
}

export interface MetricsThresholds {
  resolutionTimeTargetDays: number;
  resolutionTimeWarningDays: number;
  overdueRateTargetPercent: number;
  overdueRateWarningPercent: number;
}

export interface AdminConfig {
  departments: Department[];
  categories: CategoryConfig[];
  priorities: PriorityConfig[];
  routingRules: RoutingRule[];
  workflowPolicy: WorkflowPolicy;
  attachmentPolicy: AttachmentPolicy;
  activityFeedPolicy: ActivityFeedPolicy;
  metricsThresholds: MetricsThresholds;
}
