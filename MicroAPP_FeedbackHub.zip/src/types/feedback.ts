export type FeedbackStatus = 'pending' | 'in-progress' | 'under-review' | 'resolved' | 'closed';
export type FeedbackPriority = 'low' | 'medium' | 'high' | 'critical';
export type FeedbackCategory = 'compliance-issue' | 'process-improvement' | 'safety-concern' | 'policy-question' | 'training-request' | 'other';
export type MicroappLabel = 'ComplianceConnect' | 'RiskGuard' | 'EnforcePoint' | 'AuditPro';

export interface Attachment {
  id: string;
  name: string;
  size: number;
  type: string;
  url: string;
  uploadedAt: string;
  uploadedBy: string;
}

export interface MicroappReference {
  id: string;
  microapp: MicroappLabel;
  itemId: string;
  itemTitle: string;
  addedBy: string;
  addedAt: string;
}

export interface FeedbackItem {
  id: string;
  title: string;
  description: string;
  category: FeedbackCategory;
  priority: FeedbackPriority;
  status: FeedbackStatus;
  department: string;
  submittedBy: string;
  submittedAt: string;
  assignedTo?: string;
  dueDate?: string;
  lastUpdated: string;
  attachments?: Attachment[];
  notes?: FeedbackNote[];
  history?: FeedbackHistoryEntry[];
  microappLabels?: MicroappLabel[];
  microappReferences?: MicroappReference[];
}

export interface FeedbackNote {
  id: string;
  content: string;
  author: string;
  createdAt: string;
  attachments?: Attachment[];
}

export interface FeedbackHistoryEntry {
  id: string;
  action: string;
  actor: string;
  timestamp: string;
  details?: string;
}

export interface ActivityItem {
  id: string;
  feedbackId: string;
  feedbackTitle: string;
  action: string;
  actor: string;
  timestamp: string;
  type: 'submission' | 'update' | 'assignment' | 'comment' | 'status-change' | 'resolution';
}
