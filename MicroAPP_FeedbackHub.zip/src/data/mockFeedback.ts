import { FeedbackItem, ActivityItem } from '@/types/feedback';

export const mockFeedbacks: FeedbackItem[] = [
  {
    id: 'FB-001',
    title: 'Hand Hygiene Protocol Clarification Needed',
    description: 'The current hand hygiene protocol documentation has conflicting information between Section 3.2 and Appendix A regarding alcohol-based sanitizer usage frequency. This inconsistency has caused confusion among nursing staff during shift handovers.',
    category: 'compliance-issue',
    priority: 'high',
    status: 'pending',
    department: 'Infection Control',
    submittedBy: 'Sarah Mitchell',
    submittedAt: '2024-12-10T09:30:00Z',
    assignedTo: 'Dr. James Wilson',
    dueDate: '2025-12-20T17:00:00Z',
    lastUpdated: '2024-12-10T09:30:00Z',
    notes: [],
    history: [
      {
        id: 'H-001',
        action: 'Feedback submitted',
        actor: 'Sarah Mitchell',
        timestamp: '2024-12-10T09:30:00Z',
      }
    ]
  },
  {
    id: 'FB-002',
    title: 'PPE Supply Chain Documentation Gap',
    description: 'Current PPE inventory tracking system does not capture lot numbers for N95 respirators, making recall traceability difficult. Recommend implementing barcode scanning for all PPE deliveries.',
    category: 'process-improvement',
    priority: 'medium',
    status: 'in-progress',
    department: 'Supply Chain',
    submittedBy: 'Michael Chen',
    submittedAt: '2024-12-08T14:15:00Z',
    assignedTo: 'Emily Rodriguez',
    dueDate: '2025-12-25T17:00:00Z',
    lastUpdated: '2024-12-09T11:20:00Z',
    notes: [
      {
        id: 'N-001',
        content: 'Initial assessment complete. Working with IT on barcode scanner integration.',
        author: 'Emily Rodriguez',
        createdAt: '2024-12-09T11:20:00Z'
      }
    ],
    history: [
      {
        id: 'H-002',
        action: 'Feedback submitted',
        actor: 'Michael Chen',
        timestamp: '2024-12-08T14:15:00Z',
      },
      {
        id: 'H-003',
        action: 'Status changed to In Progress',
        actor: 'Emily Rodriguez',
        timestamp: '2024-12-09T11:20:00Z',
      }
    ]
  },
  {
    id: 'FB-003',
    title: 'Medication Storage Temperature Alert Training',
    description: 'Staff need additional training on responding to temperature excursion alerts for medication storage units. Two incidents this week where alerts were acknowledged but not properly escalated.',
    category: 'training-request',
    priority: 'critical',
    status: 'under-review',
    department: 'Pharmacy',
    submittedBy: 'Dr. Lisa Park',
    submittedAt: '2024-12-09T16:45:00Z',
    assignedTo: 'Robert Thompson',
    dueDate: '2025-12-18T17:00:00Z',
    lastUpdated: '2024-12-10T08:00:00Z',
    notes: [
      {
        id: 'N-002',
        content: 'Escalated to department heads. Training session scheduled for Friday.',
        author: 'Robert Thompson',
        createdAt: '2024-12-10T08:00:00Z'
      }
    ],
    history: [
      {
        id: 'H-004',
        action: 'Feedback submitted',
        actor: 'Dr. Lisa Park',
        timestamp: '2024-12-09T16:45:00Z',
      },
      {
        id: 'H-005',
        action: 'Assigned to Robert Thompson',
        actor: 'System',
        timestamp: '2024-12-09T17:00:00Z',
      },
      {
        id: 'H-006',
        action: 'Status changed to Under Review',
        actor: 'Robert Thompson',
        timestamp: '2024-12-10T08:00:00Z',
      }
    ]
  },
  {
    id: 'FB-004',
    title: 'Patient Privacy Signage in Waiting Areas',
    description: 'HIPAA compliance review identified that privacy signage in the East Wing waiting area is outdated (2019 version). Need to update with current language and contact information.',
    category: 'compliance-issue',
    priority: 'low',
    status: 'closed',
    department: 'Facilities',
    submittedBy: 'Jennifer Adams',
    submittedAt: '2024-12-05T10:00:00Z',
    assignedTo: 'Mark Stevens',
    lastUpdated: '2024-12-08T15:30:00Z',
    notes: [
      {
        id: 'N-003',
        content: 'New signage ordered and installed. Verified compliance with current HIPAA requirements.',
        author: 'Mark Stevens',
        createdAt: '2024-12-08T15:30:00Z'
      }
    ],
    history: [
      {
        id: 'H-007',
        action: 'Feedback submitted',
        actor: 'Jennifer Adams',
        timestamp: '2024-12-05T10:00:00Z',
      },
      {
        id: 'H-008',
        action: 'Status changed to Closed',
        actor: 'Mark Stevens',
        timestamp: '2024-12-08T15:30:00Z',
      }
    ]
  },
  {
    id: 'FB-005',
    title: 'Incident Reporting Form Field Missing',
    description: 'The digital incident reporting form is missing a field for witness contact information. This information is required for compliance documentation but staff are having to add it in comments section.',
    category: 'process-improvement',
    priority: 'medium',
    status: 'resolved',
    department: 'Quality Assurance',
    submittedBy: 'David Kim',
    submittedAt: '2024-12-11T08:20:00Z',
    dueDate: '2024-12-18T17:00:00Z',
    lastUpdated: '2024-12-13T14:00:00Z',
    notes: [
      {
        id: 'N-004',
        content: 'Form updated with witness contact fields. Deployed to production.',
        author: 'IT Support',
        createdAt: '2024-12-13T14:00:00Z'
      }
    ],
    history: [
      {
        id: 'H-009',
        action: 'Feedback submitted',
        actor: 'David Kim',
        timestamp: '2024-12-11T08:20:00Z',
      },
      {
        id: 'H-010',
        action: 'Status changed to Resolved',
        actor: 'IT Support',
        timestamp: '2024-12-13T14:00:00Z',
      }
    ]
  },
  {
    id: 'FB-006',
    title: 'Emergency Exit Signage Maintenance',
    description: 'Several emergency exit signs in Building C have dim lighting and need battery replacement or repair.',
    category: 'safety-concern',
    priority: 'high',
    status: 'in-progress',
    department: 'Facilities',
    submittedBy: 'Amanda Foster',
    submittedAt: '2024-12-12T11:00:00Z',
    assignedTo: 'Mark Stevens',
    dueDate: '2024-12-10T17:00:00Z',
    lastUpdated: '2024-12-12T11:00:00Z',
    notes: [],
    history: [
      {
        id: 'H-011',
        action: 'Feedback submitted',
        actor: 'Amanda Foster',
        timestamp: '2024-12-12T11:00:00Z',
      }
    ]
  },
  {
    id: 'FB-007',
    title: 'Controlled Substance Audit Discrepancy',
    description: 'Monthly controlled substance audit revealed a 2-unit discrepancy in morphine sulfate count. Investigation required per DEA guidelines.',
    category: 'compliance-issue',
    priority: 'critical',
    status: 'under-review',
    department: 'Pharmacy',
    submittedBy: 'Dr. Lisa Park',
    submittedAt: '2024-12-11T09:00:00Z',
    assignedTo: 'Dr. James Wilson',
    dueDate: '2025-12-15T17:00:00Z',
    lastUpdated: '2024-12-12T14:00:00Z',
    notes: [
      {
        id: 'N-005',
        content: 'Reviewing dispensing logs from the past 30 days. Preliminary findings suggest documentation error.',
        author: 'Dr. James Wilson',
        createdAt: '2024-12-12T14:00:00Z'
      }
    ],
    history: [
      {
        id: 'H-012',
        action: 'Feedback submitted',
        actor: 'Dr. Lisa Park',
        timestamp: '2024-12-11T09:00:00Z',
      },
      {
        id: 'H-013',
        action: 'Status changed to Under Review',
        actor: 'Dr. James Wilson',
        timestamp: '2024-12-12T14:00:00Z',
      }
    ]
  },
  {
    id: 'FB-008',
    title: 'Sterilization Log Format Update',
    description: 'Current sterilization logs do not capture operator certification expiry dates. Recommend adding this field for compliance tracking.',
    category: 'process-improvement',
    priority: 'medium',
    status: 'under-review',
    department: 'Laboratory',
    submittedBy: 'Michael Chen',
    submittedAt: '2024-12-09T10:30:00Z',
    assignedTo: 'Emily Rodriguez',
    dueDate: '2025-12-22T17:00:00Z',
    lastUpdated: '2024-12-11T16:00:00Z',
    notes: [
      {
        id: 'N-006',
        content: 'Template revision drafted. Pending approval from Lab Director.',
        author: 'Emily Rodriguez',
        createdAt: '2024-12-11T16:00:00Z'
      }
    ],
    history: [
      {
        id: 'H-014',
        action: 'Feedback submitted',
        actor: 'Michael Chen',
        timestamp: '2024-12-09T10:30:00Z',
      },
      {
        id: 'H-015',
        action: 'Status changed to Under Review',
        actor: 'Emily Rodriguez',
        timestamp: '2024-12-11T16:00:00Z',
      }
    ]
  },
  {
    id: 'FB-009',
    title: 'Visitor Badge System Enhancement',
    description: 'Implemented new visitor badge system with photo ID and expiry time stamp as requested.',
    category: 'process-improvement',
    priority: 'low',
    status: 'resolved',
    department: 'Administration',
    submittedBy: 'Jennifer Adams',
    submittedAt: '2024-12-01T08:00:00Z',
    assignedTo: 'Robert Thompson',
    lastUpdated: '2024-12-10T12:00:00Z',
    notes: [
      {
        id: 'N-007',
        content: 'New badge printers installed at all entry points. Staff trained on new system.',
        author: 'Robert Thompson',
        createdAt: '2024-12-10T12:00:00Z'
      }
    ],
    history: [
      {
        id: 'H-016',
        action: 'Feedback submitted',
        actor: 'Jennifer Adams',
        timestamp: '2024-12-01T08:00:00Z',
      },
      {
        id: 'H-017',
        action: 'Status changed to Resolved',
        actor: 'Robert Thompson',
        timestamp: '2024-12-10T12:00:00Z',
      }
    ]
  },
  {
    id: 'FB-010',
    title: 'Fire Drill Documentation Gap',
    description: 'Fire drill conducted last week but evacuation time was not recorded. Updated procedure now includes mandatory time tracking.',
    category: 'safety-concern',
    priority: 'medium',
    status: 'resolved',
    department: 'Facilities',
    submittedBy: 'Amanda Foster',
    submittedAt: '2024-12-03T14:00:00Z',
    assignedTo: 'Mark Stevens',
    lastUpdated: '2024-12-09T10:00:00Z',
    notes: [
      {
        id: 'N-008',
        content: 'Updated fire drill checklist now includes time tracking fields. All floor wardens notified.',
        author: 'Mark Stevens',
        createdAt: '2024-12-09T10:00:00Z'
      }
    ],
    history: [
      {
        id: 'H-018',
        action: 'Feedback submitted',
        actor: 'Amanda Foster',
        timestamp: '2024-12-03T14:00:00Z',
      },
      {
        id: 'H-019',
        action: 'Status changed to Resolved',
        actor: 'Mark Stevens',
        timestamp: '2024-12-09T10:00:00Z',
      }
    ]
  }
];

export const mockActivities: ActivityItem[] = [
  {
    id: 'A-001',
    feedbackId: 'FB-003',
    feedbackTitle: 'Medication Storage Temperature Alert Training',
    action: 'Status updated to Under Review',
    actor: 'Robert Thompson',
    timestamp: '2024-12-10T08:00:00Z',
    type: 'status-change'
  },
  {
    id: 'A-002',
    feedbackId: 'FB-001',
    feedbackTitle: 'Hand Hygiene Protocol Clarification Needed',
    action: 'Feedback submitted',
    actor: 'Sarah Mitchell',
    timestamp: '2024-12-10T09:30:00Z',
    type: 'submission'
  },
  {
    id: 'A-003',
    feedbackId: 'FB-002',
    feedbackTitle: 'PPE Supply Chain Documentation Gap',
    action: 'Note added',
    actor: 'Emily Rodriguez',
    timestamp: '2024-12-09T11:20:00Z',
    type: 'comment'
  },
  {
    id: 'A-004',
    feedbackId: 'FB-004',
    feedbackTitle: 'Patient Privacy Signage in Waiting Areas',
    action: 'Feedback resolved',
    actor: 'Mark Stevens',
    timestamp: '2024-12-08T15:30:00Z',
    type: 'resolution'
  },
  {
    id: 'A-005',
    feedbackId: 'FB-005',
    feedbackTitle: 'Incident Reporting Form Field Missing',
    action: 'Feedback submitted',
    actor: 'David Kim',
    timestamp: '2024-12-11T08:20:00Z',
    type: 'submission'
  }
];

export const departments = [
  'Infection Control',
  'Supply Chain',
  'Pharmacy',
  'Facilities',
  'Quality Assurance',
  'Human Resources',
  'Nursing',
  'Administration',
  'Laboratory',
  'Radiology'
];

export const teamMembers = [
  'Dr. James Wilson',
  'Emily Rodriguez',
  'Robert Thompson',
  'Mark Stevens',
  'Sarah Mitchell',
  'Michael Chen',
  'Dr. Lisa Park',
  'Jennifer Adams',
  'David Kim',
  'Amanda Foster'
];
