import React, { createContext, useContext, useState, ReactNode } from 'react';
import { User, UserRole } from '@/types/admin';

interface UserContextType {
  currentUser: User;
  setCurrentUser: (user: User) => void;
  switchRole: (role: UserRole) => void;
  hasPermission: (permission: Permission) => boolean;
}

type Permission = 
  | 'submit_feedback'
  | 'edit_own_feedback'
  | 'view_all_feedback'
  | 'change_status'
  | 'change_priority'
  | 'reassign'
  | 'add_notes'
  | 'access_admin'
  | 'manage_users'
  | 'view_audit_log';

const rolePermissions: Record<UserRole, Permission[]> = {
  'healthcare-staff': ['submit_feedback', 'add_notes'],
  'compliance-officer': [
    'submit_feedback', 
    'view_all_feedback', 
    'change_status', 
    'change_priority', 
    'reassign', 
    'add_notes'
  ],
  'department-manager': [
    'submit_feedback', 
    'add_notes'
  ],
  'administrator': [
    'submit_feedback',
    'view_all_feedback',
    'change_status',
    'change_priority',
    'reassign',
    'add_notes',
    'access_admin',
    'manage_users',
    'view_audit_log'
  ],
};

const mockUsers: Record<UserRole, User> = {
  'healthcare-staff': {
    id: 'user-001',
    name: 'Sarah Mitchell',
    email: 'sarah.mitchell@hospital.org',
    role: 'healthcare-staff',
    department: 'Nursing',
    createdAt: '2024-01-15T08:00:00Z',
  },
  'compliance-officer': {
    id: 'user-002',
    name: 'Dr. James Wilson',
    email: 'james.wilson@hospital.org',
    role: 'compliance-officer',
    department: 'Compliance',
    createdAt: '2023-06-01T08:00:00Z',
  },
  'department-manager': {
    id: 'user-003',
    name: 'Emily Rodriguez',
    email: 'emily.rodriguez@hospital.org',
    role: 'department-manager',
    department: 'Pharmacy',
    createdAt: '2023-03-20T08:00:00Z',
  },
  'administrator': {
    id: 'user-004',
    name: 'Admin User',
    email: 'admin@hospital.org',
    role: 'administrator',
    createdAt: '2022-01-01T08:00:00Z',
  },
};

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User>(mockUsers['compliance-officer']);

  const switchRole = (role: UserRole) => {
    setCurrentUser(mockUsers[role]);
  };

  const hasPermission = (permission: Permission): boolean => {
    return rolePermissions[currentUser.role].includes(permission);
  };

  return (
    <UserContext.Provider value={{ currentUser, setCurrentUser, switchRole, hasPermission }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}
