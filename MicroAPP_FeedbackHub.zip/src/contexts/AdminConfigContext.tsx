import React, { createContext, useContext, useState, ReactNode } from 'react';
import { 
  AdminConfig, 
  Department, 
  CategoryConfig, 
  PriorityConfig, 
  RoutingRule,
  WorkflowPolicy,
  AttachmentPolicy,
  ActivityFeedPolicy,
  AuditLogEntry,
  MetricsThresholds
} from '@/types/admin';

interface AdminConfigContextType {
  config: AdminConfig;
  auditLog: AuditLogEntry[];
  updateDepartments: (departments: Department[]) => void;
  updateCategories: (categories: CategoryConfig[]) => void;
  updatePriorities: (priorities: PriorityConfig[]) => void;
  updateRoutingRules: (rules: RoutingRule[]) => void;
  updateWorkflowPolicy: (policy: WorkflowPolicy) => void;
  updateAttachmentPolicy: (policy: AttachmentPolicy) => void;
  updateActivityFeedPolicy: (policy: ActivityFeedPolicy) => void;
  updateMetricsThresholds: (thresholds: MetricsThresholds) => void;
  addAuditLog: (entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) => void;
}

const defaultConfig: AdminConfig = {
  departments: [
    { id: 'dept-001', name: 'Nursing', code: 'NUR', isActive: true, createdAt: '2024-01-01T00:00:00Z' },
    { id: 'dept-002', name: 'Pharmacy', code: 'PHR', isActive: true, createdAt: '2024-01-01T00:00:00Z' },
    { id: 'dept-003', name: 'Radiology', code: 'RAD', isActive: true, createdAt: '2024-01-01T00:00:00Z' },
    { id: 'dept-004', name: 'Laboratory', code: 'LAB', isActive: true, createdAt: '2024-01-01T00:00:00Z' },
    { id: 'dept-005', name: 'Emergency', code: 'EMR', isActive: true, createdAt: '2024-01-01T00:00:00Z' },
    { id: 'dept-006', name: 'Surgery', code: 'SUR', isActive: true, createdAt: '2024-01-01T00:00:00Z' },
    { id: 'dept-007', name: 'Compliance', code: 'CMP', isActive: true, createdAt: '2024-01-01T00:00:00Z' },
  ],
  categories: [
    { id: 'cat-001', name: 'Compliance Issue', code: 'compliance-issue', description: 'Regulatory or policy violations', isActive: true, order: 1 },
    { id: 'cat-002', name: 'Process Improvement', code: 'process-improvement', description: 'Workflow optimization suggestions', isActive: true, order: 2 },
    { id: 'cat-003', name: 'Safety Concern', code: 'safety-concern', description: 'Patient or staff safety issues', isActive: true, order: 3 },
    { id: 'cat-004', name: 'Policy Question', code: 'policy-question', description: 'Questions about existing policies', isActive: true, order: 4 },
    { id: 'cat-005', name: 'Training Request', code: 'training-request', description: 'Requests for additional training', isActive: true, order: 5 },
    { id: 'cat-006', name: 'Other', code: 'other', description: 'Miscellaneous feedback', isActive: true, order: 6 },
  ],
  priorities: [
    { id: 'pri-001', name: 'Low', code: 'low', dueDays: 14, color: 'hsl(var(--muted-foreground))', isActive: true, order: 1 },
    { id: 'pri-002', name: 'Medium', code: 'medium', dueDays: 7, color: 'hsl(142.1 76.2% 36.3%)', isActive: true, order: 2 },
    { id: 'pri-003', name: 'High', code: 'high', dueDays: 3, color: 'hsl(38 92% 50%)', isActive: true, order: 3 },
    { id: 'pri-004', name: 'Critical', code: 'critical', dueDays: 1, color: 'hsl(0 84.2% 60.2%)', isActive: true, order: 4 },
  ],
  routingRules: [
    {
      id: 'rule-001',
      name: 'Critical Safety to Emergency Lead',
      description: 'Route critical safety concerns to Emergency department lead',
      conditions: [
        { field: 'priority', operator: 'equals', value: 'critical' },
        { field: 'category', operator: 'equals', value: 'safety-concern' },
      ],
      assignTo: 'Dr. James Wilson',
      setDueDays: 1,
      order: 1,
      isActive: true,
    },
    {
      id: 'rule-002',
      name: 'Compliance Issues to Compliance Team',
      description: 'All compliance issues go to compliance officers',
      conditions: [
        { field: 'category', operator: 'equals', value: 'compliance-issue' },
      ],
      assignTo: 'Dr. James Wilson',
      order: 2,
      isActive: true,
    },
    {
      id: 'rule-003',
      name: 'Default Fallback',
      description: 'Fallback rule for unmatched feedback',
      conditions: [],
      assignTo: 'Compliance Pool',
      order: 99,
      isActive: true,
    },
  ],
  workflowPolicy: {
    allowSendBack: false,
    requireResolutionNote: true,
    requireClosureNote: false,
    whoCanChangeStatus: ['compliance-officer', 'administrator'],
    whoCanReassign: ['compliance-officer', 'administrator'],
    whoCanChangePriority: ['compliance-officer', 'administrator'],
    staffCanAddNotes: true,
    managerCanChangeStatus: false,
    managerCanReassign: false,
  },
  attachmentPolicy: {
    submissionMaxFiles: 5,
    submissionMaxSizeMB: 10,
    noteMaxFiles: 3,
    noteMaxSizeMB: 10,
    allowedFileTypes: ['image/*', 'application/pdf', '.doc', '.docx', '.xls', '.xlsx', '.txt'],
    enableDragDrop: true,
  },
  activityFeedPolicy: {
    enabledEventTypes: ['submission', 'update', 'assignment', 'comment', 'status-change', 'resolution'],
    retentionDays: 90,
    staffSeesOwnOnly: true,
    managerSeesDepartmentOnly: true,
  },
  metricsThresholds: {
    resolutionTimeTargetDays: 2,
    resolutionTimeWarningDays: 4,
    overdueRateTargetPercent: 10,
    overdueRateWarningPercent: 20,
  },
};

const defaultAuditLog: AuditLogEntry[] = [
  {
    id: 'audit-001',
    action: 'Created routing rule',
    actor: 'Admin User',
    actorRole: 'administrator',
    entityType: 'routing_rule',
    entityId: 'rule-001',
    changes: { name: { old: null, new: 'Critical Safety to Emergency Lead' } },
    timestamp: '2024-12-01T10:30:00Z',
  },
  {
    id: 'audit-002',
    action: 'Updated workflow policy',
    actor: 'Admin User',
    actorRole: 'administrator',
    entityType: 'workflow_policy',
    entityId: 'policy',
    changes: { requireResolutionNote: { old: false, new: true } },
    timestamp: '2024-12-05T14:15:00Z',
  },
];

const AdminConfigContext = createContext<AdminConfigContextType | undefined>(undefined);

export function AdminConfigProvider({ children }: { children: ReactNode }) {
  const [config, setConfig] = useState<AdminConfig>(defaultConfig);
  const [auditLog, setAuditLog] = useState<AuditLogEntry[]>(defaultAuditLog);

  const addAuditLog = (entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) => {
    const newEntry: AuditLogEntry = {
      ...entry,
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString(),
    };
    setAuditLog(prev => [newEntry, ...prev]);
  };

  const updateDepartments = (departments: Department[]) => {
    setConfig(prev => ({ ...prev, departments }));
  };

  const updateCategories = (categories: CategoryConfig[]) => {
    setConfig(prev => ({ ...prev, categories }));
  };

  const updatePriorities = (priorities: PriorityConfig[]) => {
    setConfig(prev => ({ ...prev, priorities }));
  };

  const updateRoutingRules = (routingRules: RoutingRule[]) => {
    setConfig(prev => ({ ...prev, routingRules }));
  };

  const updateWorkflowPolicy = (workflowPolicy: WorkflowPolicy) => {
    setConfig(prev => ({ ...prev, workflowPolicy }));
  };

  const updateAttachmentPolicy = (attachmentPolicy: AttachmentPolicy) => {
    setConfig(prev => ({ ...prev, attachmentPolicy }));
  };

  const updateActivityFeedPolicy = (activityFeedPolicy: ActivityFeedPolicy) => {
    setConfig(prev => ({ ...prev, activityFeedPolicy }));
  };

  const updateMetricsThresholds = (metricsThresholds: MetricsThresholds) => {
    setConfig(prev => ({ ...prev, metricsThresholds }));
  };

  return (
    <AdminConfigContext.Provider
      value={{
        config,
        auditLog,
        updateDepartments,
        updateCategories,
        updatePriorities,
        updateRoutingRules,
        updateWorkflowPolicy,
        updateAttachmentPolicy,
        updateActivityFeedPolicy,
        updateMetricsThresholds,
        addAuditLog,
      }}
    >
      {children}
    </AdminConfigContext.Provider>
  );
}

export function useAdminConfig() {
  const context = useContext(AdminConfigContext);
  if (context === undefined) {
    throw new Error('useAdminConfig must be used within an AdminConfigProvider');
  }
  return context;
}
