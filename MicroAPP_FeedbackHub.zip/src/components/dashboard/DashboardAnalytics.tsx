import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FeedbackItem } from '@/types/feedback';
import { useAdminConfig } from '@/contexts/AdminConfigContext';
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, Legend, Area, AreaChart } from 'recharts';
import { TrendingUp, Clock, AlertTriangle, BarChart3 } from 'lucide-react';

interface DashboardAnalyticsProps {
  feedbacks: FeedbackItem[];
}

export function DashboardAnalytics({ feedbacks }: DashboardAnalyticsProps) {
  const { config } = useAdminConfig();
  const { metricsThresholds } = config;
  const now = new Date();
  
  // Status distribution
  const statusCounts = feedbacks.reduce((acc, f) => {
    acc[f.status] = (acc[f.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const statusData = [
    { name: 'Pending', value: statusCounts['pending'] || 0, color: 'hsl(var(--muted-foreground))' },
    { name: 'In Progress', value: statusCounts['in-progress'] || 0, color: 'hsl(var(--warning))' },
    { name: 'Under Review', value: statusCounts['under-review'] || 0, color: 'hsl(var(--primary))' },
    { name: 'Resolved', value: statusCounts['resolved'] || 0, color: 'hsl(var(--success))' },
    { name: 'Closed', value: statusCounts['closed'] || 0, color: 'hsl(var(--secondary))' },
  ].filter(d => d.value > 0);

  // Overdue rate
  const activeItems = feedbacks.filter(f => !['resolved', 'closed'].includes(f.status));
  const overdueItems = activeItems.filter(f => f.dueDate && new Date(f.dueDate) < now);
  const overdueRate = activeItems.length > 0 ? (overdueItems.length / activeItems.length) * 100 : 0;

  // Average resolution time (in days) - for resolved/closed items
  const resolvedItems = feedbacks.filter(f => ['resolved', 'closed'].includes(f.status));
  const avgResolutionTime = resolvedItems.length > 0
    ? resolvedItems.reduce((sum, f) => {
        const submitted = new Date(f.submittedAt);
        const updated = new Date(f.lastUpdated);
        return sum + (updated.getTime() - submitted.getTime()) / (1000 * 60 * 60 * 24);
      }, 0) / resolvedItems.length
    : 0;

  // Weekly trend data with more details
  const trendData = [
    { day: 'Mon', date: 'Dec 9', submissions: 3, resolved: 2 },
    { day: 'Tue', date: 'Dec 10', submissions: 5, resolved: 3 },
    { day: 'Wed', date: 'Dec 11', submissions: 2, resolved: 4 },
    { day: 'Thu', date: 'Dec 12', submissions: 7, resolved: 5 },
    { day: 'Fri', date: 'Dec 13', submissions: 4, resolved: 3 },
    { day: 'Sat', date: 'Dec 14', submissions: 1, resolved: 2 },
    { day: 'Sun', date: 'Dec 15', submissions: 2, resolved: 1 },
  ];

  const totalSubmissions = trendData.reduce((sum, d) => sum + d.submissions, 0);
  const totalResolved = trendData.reduce((sum, d) => sum + d.resolved, 0);

  // Get color based on thresholds
  const getResolutionColor = (time: number) => {
    if (time <= metricsThresholds.resolutionTimeTargetDays) return 'text-success';
    if (time <= metricsThresholds.resolutionTimeWarningDays) return 'text-warning';
    return 'text-destructive';
  };

  const getResolutionBarColor = (time: number) => {
    if (time <= metricsThresholds.resolutionTimeTargetDays) return 'bg-success';
    if (time <= metricsThresholds.resolutionTimeWarningDays) return 'bg-warning';
    return 'bg-destructive';
  };

  const getOverdueColor = (rate: number) => {
    if (rate <= metricsThresholds.overdueRateTargetPercent) return 'text-success';
    if (rate <= metricsThresholds.overdueRateWarningPercent) return 'text-warning';
    return 'text-destructive';
  };

  const getOverdueBarColor = (rate: number) => {
    if (rate <= metricsThresholds.overdueRateTargetPercent) return 'bg-success';
    if (rate <= metricsThresholds.overdueRateWarningPercent) return 'bg-warning';
    return 'bg-destructive';
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
      {/* Average Resolution Time */}
      <Card className="shadow-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <Clock className="h-4 w-4" />
            Avg. Resolution Time
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className={`text-2xl font-bold ${getResolutionColor(avgResolutionTime)}`}>
            {avgResolutionTime.toFixed(1)} days
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Target: &lt; {metricsThresholds.resolutionTimeTargetDays} days
          </p>
          <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all ${getResolutionBarColor(avgResolutionTime)}`}
              style={{ width: `${Math.min((avgResolutionTime / (metricsThresholds.resolutionTimeWarningDays * 1.5)) * 100, 100)}%` }}
            />
          </div>
        </CardContent>
      </Card>

      {/* Overdue Rate */}
      <Card className="shadow-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <AlertTriangle className="h-4 w-4" />
            Overdue Rate
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className={`text-2xl font-bold ${getOverdueColor(overdueRate)}`}>
            {overdueRate.toFixed(0)}%
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Target: &lt; {metricsThresholds.overdueRateTargetPercent}%
          </p>
          <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all ${getOverdueBarColor(overdueRate)}`}
              style={{ width: `${Math.min(overdueRate, 100)}%` }}
            />
          </div>
        </CardContent>
      </Card>

      {/* Status Distribution */}
      <Card className="shadow-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Status Distribution
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[80px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={20}
                  outerRadius={35}
                  dataKey="value"
                  stroke="none"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            {statusData.slice(0, 3).map((entry) => (
              <div key={entry.name} className="flex items-center gap-1 text-xs">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
                <span className="text-muted-foreground">{entry.name}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Weekly Trend - Enhanced */}
      <Card className="shadow-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Weekly Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[80px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="submissionsGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="resolvedGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--success))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--success))" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                <XAxis 
                  dataKey="day" 
                  tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis hide />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                  labelFormatter={(value, payload) => {
                    if (payload && payload[0]) {
                      return payload[0].payload.date;
                    }
                    return value;
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="submissions" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={2}
                  fill="url(#submissionsGradient)"
                  name="Submitted"
                />
                <Area 
                  type="monotone" 
                  dataKey="resolved" 
                  stroke="hsl(var(--success))" 
                  strokeWidth={2}
                  fill="url(#resolvedGradient)"
                  name="Resolved"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="flex items-center justify-between mt-2 text-xs">
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-primary" />
              <span className="text-muted-foreground">{totalSubmissions} submitted</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-success" />
              <span className="text-muted-foreground">{totalResolved} resolved</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
