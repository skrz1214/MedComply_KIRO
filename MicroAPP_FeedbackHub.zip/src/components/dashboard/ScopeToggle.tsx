import { useUser } from '@/contexts/UserContext';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { Building2, User, Users } from 'lucide-react';

export type FeedbackScope = 'personal' | 'department' | 'organization';

interface ScopeToggleProps {
  scope: FeedbackScope;
  onScopeChange: (scope: FeedbackScope) => void;
}

export function ScopeToggle({ scope, onScopeChange }: ScopeToggleProps) {
  const { currentUser } = useUser();
  const role = currentUser.role;

  // Only show toggle for roles that have scope options
  if (role === 'healthcare-staff') {
    return null;
  }

  const isDepartmentManager = role === 'department-manager';
  const isComplianceOrAdmin = role === 'compliance-officer' || role === 'administrator';

  if (!isDepartmentManager && !isComplianceOrAdmin) {
    return null;
  }

  return (
    <div className="flex items-center gap-3">
      <span className="text-sm text-muted-foreground">View:</span>
      <ToggleGroup
        type="single"
        value={scope}
        onValueChange={(value) => {
          if (value) onScopeChange(value as FeedbackScope);
        }}
        className="bg-muted/50 p-1 rounded-lg"
      >
        <ToggleGroupItem
          value="personal"
          aria-label="Personal view"
          className="data-[state=on]:bg-background data-[state=on]:shadow-sm px-3 gap-1.5"
        >
          <User className="h-4 w-4" />
          <span className="text-sm">Personal</span>
        </ToggleGroupItem>

        {isDepartmentManager && (
          <ToggleGroupItem
            value="department"
            aria-label="Department view"
            className="data-[state=on]:bg-background data-[state=on]:shadow-sm px-3 gap-1.5"
          >
            <Users className="h-4 w-4" />
            <span className="text-sm">Department</span>
          </ToggleGroupItem>
        )}

        {isComplianceOrAdmin && (
          <ToggleGroupItem
            value="organization"
            aria-label="Organization view"
            className="data-[state=on]:bg-background data-[state=on]:shadow-sm px-3 gap-1.5"
          >
            <Building2 className="h-4 w-4" />
            <span className="text-sm">Organization</span>
          </ToggleGroupItem>
        )}
      </ToggleGroup>
    </div>
  );
}
