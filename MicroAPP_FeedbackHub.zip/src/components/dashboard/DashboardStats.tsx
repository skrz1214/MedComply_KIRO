import { Card, CardContent } from '@/components/ui/card';
import { FeedbackItem } from '@/types/feedback';
import { ListTodo, Eye, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { isPast, parseISO } from 'date-fns';

interface DashboardStatsProps {
  feedbacks: FeedbackItem[];
}

export function DashboardStats({ feedbacks }: DashboardStatsProps) {
  // To Do: pending or in-progress (not overdue)
  const todoCount = feedbacks.filter(f => 
    (f.status === 'pending' || f.status === 'in-progress') &&
    !(f.dueDate && isPast(parseISO(f.dueDate)))
  ).length;
  
  const toReviewCount = feedbacks.filter(f => f.status === 'under-review').length;
  
  const overdueCount = feedbacks.filter(f => 
    f.dueDate && 
    isPast(parseISO(f.dueDate)) && 
    f.status !== 'resolved' &&
    f.status !== 'closed'
  ).length;
  
  const resolvedCount = feedbacks.filter(f => f.status === 'resolved').length;
  const closedCount = feedbacks.filter(f => f.status === 'closed').length;

  const stats = [
    { label: 'To Do', value: todoCount, icon: ListTodo, color: 'text-primary bg-primary/10' },
    { label: 'To Review', value: toReviewCount, icon: Eye, color: 'text-warning bg-warning/10' },
    { label: 'Overdue', value: overdueCount, icon: AlertTriangle, color: 'text-destructive bg-destructive/10' },
    { label: 'Resolved', value: resolvedCount, icon: CheckCircle, color: 'text-success bg-success/10' },
    { label: 'Closed', value: closedCount, icon: XCircle, color: 'text-muted-foreground bg-muted' },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <Card 
            key={stat.label} 
            className="shadow-card hover:shadow-card-hover transition-all duration-200 animate-slide-up"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={cn("p-2.5 rounded-xl", stat.color)}>
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
