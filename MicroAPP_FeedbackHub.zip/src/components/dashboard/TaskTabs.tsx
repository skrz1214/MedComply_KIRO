import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FeedbackItem } from '@/types/feedback';
import { FeedbackCard } from '@/components/feedback/FeedbackCard';
import { ListTodo, Eye, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { isPast, parseISO } from 'date-fns';

interface TaskTabsProps {
  feedbacks: FeedbackItem[];
  onFeedbackClick: (feedbackId: string) => void;
}

export function TaskTabs({ feedbacks, onFeedbackClick }: TaskTabsProps) {
  // To Do: pending or in-progress (not overdue)
  const todoItems = feedbacks.filter(f => 
    (f.status === 'pending' || f.status === 'in-progress') &&
    !(f.dueDate && isPast(parseISO(f.dueDate)))
  );

  // To Review: under-review status
  const toReviewItems = feedbacks.filter(f => f.status === 'under-review');

  // Overdue: past due date and not resolved/closed
  const overdueItems = feedbacks.filter(f => 
    f.dueDate && 
    isPast(parseISO(f.dueDate)) && 
    f.status !== 'resolved' &&
    f.status !== 'closed'
  );

  // Resolved: resolved status
  const resolvedItems = feedbacks.filter(f => f.status === 'resolved');

  // Closed: closed status
  const closedItems = feedbacks.filter(f => f.status === 'closed');

  const renderTabContent = (items: FeedbackItem[], emptyIcon: React.ReactNode, emptyTitle: string, emptyDescription: string) => {
    if (items.length > 0) {
      return (
        <div className="grid gap-4">
          {items.map((feedback, index) => (
            <div 
              key={feedback.id}
              className="animate-slide-up"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <FeedbackCard
                feedback={feedback}
                onClick={() => onFeedbackClick(feedback.id)}
              />
            </div>
          ))}
        </div>
      );
    }
    return (
      <div className="text-center py-12">
        {emptyIcon}
        <p className="text-muted-foreground">{emptyTitle}</p>
        <p className="text-sm text-muted-foreground/70 mt-1">{emptyDescription}</p>
      </div>
    );
  };

  return (
    <Tabs defaultValue="todo" className="w-full">
      <TabsList className="w-full justify-start bg-muted/50 p-1 h-auto flex-wrap gap-1">
        <TabsTrigger value="todo" className="gap-2 data-[state=active]:bg-card data-[state=active]:shadow-sm">
          <ListTodo className="h-4 w-4" />
          To Do
          <span className="ml-1 px-2 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-semibold">
            {todoItems.length}
          </span>
        </TabsTrigger>
        <TabsTrigger value="review" className="gap-2 data-[state=active]:bg-card data-[state=active]:shadow-sm">
          <Eye className="h-4 w-4" />
          To Review
          <span className="ml-1 px-2 py-0.5 rounded-full bg-warning/10 text-warning text-xs font-semibold">
            {toReviewItems.length}
          </span>
        </TabsTrigger>
        <TabsTrigger value="overdue" className="gap-2 data-[state=active]:bg-card data-[state=active]:shadow-sm">
          <AlertTriangle className="h-4 w-4" />
          Overdue
          <span className="ml-1 px-2 py-0.5 rounded-full bg-destructive/10 text-destructive text-xs font-semibold">
            {overdueItems.length}
          </span>
        </TabsTrigger>
        <TabsTrigger value="resolved" className="gap-2 data-[state=active]:bg-card data-[state=active]:shadow-sm">
          <CheckCircle className="h-4 w-4" />
          Resolved
          <span className="ml-1 px-2 py-0.5 rounded-full bg-success/10 text-success text-xs font-semibold">
            {resolvedItems.length}
          </span>
        </TabsTrigger>
        <TabsTrigger value="closed" className="gap-2 data-[state=active]:bg-card data-[state=active]:shadow-sm">
          <XCircle className="h-4 w-4" />
          Closed
          <span className="ml-1 px-2 py-0.5 rounded-full bg-muted-foreground/20 text-muted-foreground text-xs font-semibold">
            {closedItems.length}
          </span>
        </TabsTrigger>
      </TabsList>

      <TabsContent value="todo" className="mt-6">
        {renderTabContent(
          todoItems,
          <ListTodo className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />,
          "No items to do",
          "Pending and in-progress feedback will appear here"
        )}
      </TabsContent>

      <TabsContent value="review" className="mt-6">
        {renderTabContent(
          toReviewItems,
          <Eye className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />,
          "No items to review",
          "Items awaiting review will appear here"
        )}
      </TabsContent>

      <TabsContent value="overdue" className="mt-6">
        {renderTabContent(
          overdueItems,
          <AlertTriangle className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />,
          "No overdue items",
          "Feedback past their due date will appear here"
        )}
      </TabsContent>

      <TabsContent value="resolved" className="mt-6">
        {renderTabContent(
          resolvedItems,
          <CheckCircle className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />,
          "No resolved items",
          "Resolved feedback will appear here"
        )}
      </TabsContent>

      <TabsContent value="closed" className="mt-6">
        {renderTabContent(
          closedItems,
          <XCircle className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />,
          "No closed items",
          "Closed feedback will appear here"
        )}
      </TabsContent>
    </Tabs>
  );
}
