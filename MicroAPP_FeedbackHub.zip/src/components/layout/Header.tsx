import { Button } from '@/components/ui/button';
import { Plus, Bell, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { RoleSwitcher } from '@/components/layout/RoleSwitcher';

interface HeaderProps {
  onNewFeedback: () => void;
}

export function Header({ onNewFeedback }: HeaderProps) {
  return (
    <header className="h-16 border-b border-border bg-card px-6 flex items-center justify-between">
      <div className="flex items-center gap-4 flex-1 max-w-md">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search feedbacks..." 
            className="pl-10 bg-background"
          />
        </div>
      </div>

      <div className="flex items-center gap-3">
        <Button variant="accent" onClick={onNewFeedback} className="gap-2">
          <Plus className="h-4 w-4" />
          New Feedback
        </Button>
        
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          <span className="absolute top-1 right-1 h-2 w-2 bg-destructive rounded-full" />
        </Button>
        
        <RoleSwitcher />
      </div>
    </header>
  );
}
