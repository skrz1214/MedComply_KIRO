import { 
  LayoutDashboard, 
  MessageSquareText, 
  ChevronLeft,
  ChevronRight,
  Shield,
  Plus,
  BookOpen,
  Settings
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '@/contexts/UserContext';

interface AppSidebarProps {
  currentView: string;
  onViewChange: (view: string) => void;
  onNewFeedback: () => void;
}

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'my-feedbacks', label: 'My Feedbacks', icon: MessageSquareText },
  { id: 'documentation', label: 'Documentation', icon: BookOpen },
];

export function AppSidebar({ currentView, onViewChange, onNewFeedback }: AppSidebarProps) {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  const { hasPermission } = useUser();

  return (
    <aside 
      className={cn(
        "gradient-hero flex flex-col transition-all duration-300",
        collapsed ? "w-16" : "w-64"
      )}
    >
      {/* Header */}
      <div className="p-4 flex items-center gap-3">
        <div className="h-10 w-10 rounded-xl bg-sidebar-primary/20 flex items-center justify-center flex-shrink-0">
          <Shield className="h-6 w-6 text-sidebar-primary" />
        </div>
        {!collapsed && (
          <div className="animate-fade-in">
            <h1 className="font-bold text-sidebar-foreground text-lg">FeedbackHub</h1>
            <p className="text-xs text-sidebar-foreground/60">MedComply</p>
          </div>
        )}
      </div>

      {/* New Feedback Button */}
      <div className="px-2 pb-2">
        <Button
          onClick={onNewFeedback}
          className={cn(
            "w-full gap-2 bg-sidebar-primary hover:bg-sidebar-primary/90 text-sidebar-primary-foreground",
            collapsed && "px-0 justify-center"
          )}
        >
          <Plus className="h-5 w-5 flex-shrink-0" />
          {!collapsed && <span className="animate-fade-in">New Feedback</span>}
        </Button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-2 py-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200",
                "text-sidebar-foreground/80 hover:text-sidebar-foreground",
                isActive 
                  ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                  : "hover:bg-sidebar-accent/50"
              )}
            >
              <Icon className="h-5 w-5 flex-shrink-0" />
              {!collapsed && (
                <span className="font-medium text-sm animate-fade-in">{item.label}</span>
              )}
            </button>
          );
        })}

        {/* Admin Settings - Only visible to administrators */}
        {hasPermission('access_admin') && (
          <button
            onClick={() => onViewChange('admin-settings')}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200",
              "text-sidebar-foreground/80 hover:text-sidebar-foreground",
              currentView === 'admin-settings'
                ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                : "hover:bg-sidebar-accent/50"
            )}
          >
            <Settings className="h-5 w-5 flex-shrink-0" />
            {!collapsed && (
              <span className="font-medium text-sm animate-fade-in">Admin Settings</span>
            )}
          </button>
        )}
      </nav>

      {/* Footer */}
      <div className="p-2 border-t border-sidebar-border">
        <button
          onClick={() => setCollapsed(!collapsed)}
          className={cn(
            "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200",
            "text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
          )}
        >
          {collapsed ? (
            <ChevronRight className="h-5 w-5" />
          ) : (
            <>
              <ChevronLeft className="h-5 w-5" />
              <span className="font-medium text-sm">Collapse</span>
            </>
          )}
        </button>
      </div>
    </aside>
  );
}
