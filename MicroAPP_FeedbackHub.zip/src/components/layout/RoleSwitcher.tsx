import { useUser } from '@/contexts/UserContext';
import { UserRole } from '@/types/admin';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { User, ChevronDown, Shield, Stethoscope, Building2, UserCog } from 'lucide-react';

const roleConfig: Record<UserRole, { label: string; icon: React.ElementType; color: string }> = {
  'healthcare-staff': { label: 'Healthcare Staff', icon: Stethoscope, color: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' },
  'compliance-officer': { label: 'Compliance Officer', icon: Shield, color: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' },
  'department-manager': { label: 'Department Manager', icon: Building2, color: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200' },
  'administrator': { label: 'Administrator', icon: UserCog, color: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' },
};

export function RoleSwitcher() {
  const { currentUser, switchRole } = useUser();
  const currentRoleConfig = roleConfig[currentUser.role];
  const Icon = currentRoleConfig.icon;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Icon className="h-4 w-4" />
          <span className="hidden sm:inline">{currentUser.name}</span>
          <Badge variant="secondary" className={`hidden md:inline-flex ${currentRoleConfig.color}`}>
            {currentRoleConfig.label}
          </Badge>
          <ChevronDown className="h-4 w-4 opacity-50" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium">{currentUser.name}</p>
            <p className="text-xs text-muted-foreground">{currentUser.email}</p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuLabel className="text-xs text-muted-foreground">Switch Role (Demo)</DropdownMenuLabel>
        {(Object.keys(roleConfig) as UserRole[]).map((role) => {
          const config = roleConfig[role];
          const RoleIcon = config.icon;
          return (
            <DropdownMenuItem
              key={role}
              onClick={() => switchRole(role)}
              className={currentUser.role === role ? 'bg-accent' : ''}
            >
              <RoleIcon className="h-4 w-4 mr-2" />
              <span>{config.label}</span>
              {currentUser.role === role && (
                <Badge variant="outline" className="ml-auto text-xs">Current</Badge>
              )}
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
