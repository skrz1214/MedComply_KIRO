import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { FeedbackItem } from '@/types/feedback';
import { StatusBadge } from './StatusBadge';
import { PriorityBadge } from './PriorityBadge';
import { Calendar, User, Building2, ChevronRight, Paperclip } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';

interface FeedbackCardProps {
  feedback: FeedbackItem;
  onClick?: () => void;
  className?: string;
}

export function FeedbackCard({ feedback, onClick, className }: FeedbackCardProps) {
  const attachmentCount = feedback.attachments?.length || 0;

  return (
    <Card 
      className={cn(
        "cursor-pointer transition-all duration-200 hover:shadow-card-hover hover:border-primary/20 group",
        className
      )}
      onClick={onClick}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-medium text-muted-foreground">{feedback.id}</span>
              <StatusBadge status={feedback.status} />
              <PriorityBadge priority={feedback.priority} />
              {attachmentCount > 0 && (
                <span className="inline-flex items-center gap-1 text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
                  <Paperclip className="h-3 w-3" />
                  {attachmentCount}
                </span>
              )}
            </div>
            <h3 className="font-semibold text-foreground line-clamp-1 group-hover:text-primary transition-colors">
              {feedback.title}
            </h3>
          </div>
          <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
          {feedback.description}
        </p>
        <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <Building2 className="h-3.5 w-3.5" />
            <span>{feedback.department}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <User className="h-3.5 w-3.5" />
            <span>{feedback.assignedTo || 'Unassigned'}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Calendar className="h-3.5 w-3.5" />
            <span>{formatDistanceToNow(new Date(feedback.submittedAt), { addSuffix: true })}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
