import { Badge } from '@/components/ui/badge';
import { FeedbackStatus } from '@/types/feedback';
import { Clock, Loader2, Eye, CheckCircle, XCircle } from 'lucide-react';

interface StatusBadgeProps {
  status: FeedbackStatus;
}

const statusConfig: Record<FeedbackStatus, { label: string; variant: 'default' | 'warning' | 'secondary' | 'destructive' | 'outline'; icon: React.ElementType }> = {
  'pending': { label: 'Pending', variant: 'outline', icon: Clock },
  'in-progress': { label: 'In Progress', variant: 'warning', icon: Loader2 },
  'under-review': { label: 'Under Review', variant: 'default', icon: Eye },
  'resolved': { label: 'Resolved', variant: 'secondary', icon: CheckCircle },
  'closed': { label: 'Closed', variant: 'secondary', icon: XCircle },
};

export function StatusBadge({ status }: StatusBadgeProps) {
  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <Badge variant={config.variant} className="gap-1">
      <Icon className="h-3 w-3" />
      {config.label}
    </Badge>
  );
}
