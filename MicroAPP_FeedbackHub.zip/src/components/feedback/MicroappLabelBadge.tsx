import { MicroappLabel } from '@/types/feedback';
import { Badge } from '@/components/ui/badge';
import { Shield, AlertTriangle, Scale, ClipboardCheck } from 'lucide-react';
import { cn } from '@/lib/utils';

interface MicroappLabelBadgeProps {
  label: MicroappLabel;
  className?: string;
}

const labelConfig: Record<MicroappLabel, { 
  icon: React.ElementType; 
  bgClass: string; 
  textClass: string;
  description: string;
}> = {
  ComplianceConnect: {
    icon: Shield,
    bgClass: 'bg-purple-100 dark:bg-purple-900/30',
    textClass: 'text-purple-700 dark:text-purple-300',
    description: 'Process failure, repeat trend, high risk harm potential',
  },
  RiskGuard: {
    icon: AlertTriangle,
    bgClass: 'bg-orange-100 dark:bg-orange-900/30',
    textClass: 'text-orange-700 dark:text-orange-300',
    description: 'Risk-related issue',
  },
  EnforcePoint: {
    icon: Scale,
    bgClass: 'bg-red-100 dark:bg-red-900/30',
    textClass: 'text-red-700 dark:text-red-300',
    description: 'Enforcement-related issue',
  },
  AuditPro: {
    icon: ClipboardCheck,
    bgClass: 'bg-blue-100 dark:bg-blue-900/30',
    textClass: 'text-blue-700 dark:text-blue-300',
    description: 'Audit-related issue',
  },
};

export function MicroappLabelBadge({ label, className }: MicroappLabelBadgeProps) {
  const config = labelConfig[label];
  const Icon = config.icon;

  return (
    <Badge 
      variant="outline" 
      className={cn(
        'gap-1.5 font-medium border-0',
        config.bgClass,
        config.textClass,
        className
      )}
    >
      <Icon className="h-3 w-3" />
      {label}
    </Badge>
  );
}

export function getMicroappLabelConfig() {
  return labelConfig;
}
