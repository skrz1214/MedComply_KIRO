import { useState } from 'react';
import { MicroappLabel, MicroappReference } from '@/types/feedback';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { MicroappLabelBadge, getMicroappLabelConfig } from './MicroappLabelBadge';
import { Plus, X, ExternalLink } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface MicroappReferenceManagerProps {
  references: MicroappReference[];
  onReferencesChange: (references: MicroappReference[]) => void;
  disabled?: boolean;
}

const microappOptions: MicroappLabel[] = ['ComplianceConnect', 'RiskGuard', 'EnforcePoint', 'AuditPro'];

export function MicroappReferenceManager({
  references,
  onReferencesChange,
  disabled = false,
}: MicroappReferenceManagerProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [selectedMicroapp, setSelectedMicroapp] = useState<MicroappLabel | ''>('');
  const [itemId, setItemId] = useState('');
  const [itemTitle, setItemTitle] = useState('');

  const labelConfig = getMicroappLabelConfig();

  const handleAddReference = () => {
    if (!selectedMicroapp) {
      toast({
        title: "Select microapp",
        description: "Please select a microapp to reference.",
        variant: "destructive",
      });
      return;
    }

    if (!itemId.trim()) {
      toast({
        title: "Item ID required",
        description: "Please enter the item ID from the selected microapp.",
        variant: "destructive",
      });
      return;
    }

    if (!itemTitle.trim()) {
      toast({
        title: "Item title required",
        description: "Please enter a title or description for the referenced item.",
        variant: "destructive",
      });
      return;
    }

    // Check for duplicate
    const isDuplicate = references.some(
      (ref) => ref.microapp === selectedMicroapp && ref.itemId === itemId.trim()
    );

    if (isDuplicate) {
      toast({
        title: "Duplicate reference",
        description: "This item has already been added as a reference.",
        variant: "destructive",
      });
      return;
    }

    const newReference: MicroappReference = {
      id: `REF-${Date.now()}`,
      microapp: selectedMicroapp,
      itemId: itemId.trim(),
      itemTitle: itemTitle.trim(),
      addedBy: 'Current User',
      addedAt: new Date().toISOString(),
    };

    onReferencesChange([...references, newReference]);

    // Reset form
    setSelectedMicroapp('');
    setItemId('');
    setItemTitle('');
    setIsAdding(false);

    toast({
      title: "Reference added",
      description: `Linked to ${selectedMicroapp} item ${itemId}.`,
    });
  };

  const handleRemoveReference = (referenceId: string) => {
    onReferencesChange(references.filter((ref) => ref.id !== referenceId));
    toast({
      title: "Reference removed",
      description: "The cross-microapp reference has been removed.",
    });
  };

  if (disabled) {
    return (
      <div className="space-y-3">
        {references.length > 0 ? (
          references.map((ref) => (
            <div
              key={ref.id}
              className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 border border-border/50"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <MicroappLabelBadge label={ref.microapp} />
                  <span className="text-xs text-muted-foreground">{ref.itemId}</span>
                </div>
                <p className="text-sm font-medium truncate">{ref.itemTitle}</p>
              </div>
            </div>
          ))
        ) : (
          <p className="text-sm text-muted-foreground italic">No cross-microapp references</p>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {references.length > 0 && (
        <div className="space-y-2">
          {references.map((ref) => (
            <div
              key={ref.id}
              className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 border border-border/50 group"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <MicroappLabelBadge label={ref.microapp} />
                  <span className="text-xs text-muted-foreground font-mono">{ref.itemId}</span>
                </div>
                <p className="text-sm font-medium truncate">{ref.itemTitle}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Added by {ref.addedBy}
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => handleRemoveReference(ref.id)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      )}

      {isAdding ? (
        <div className="space-y-3 p-4 rounded-lg border border-dashed border-primary/50 bg-primary/5">
          <div className="space-y-2">
            <Label>Microapp</Label>
            <Select
              value={selectedMicroapp}
              onValueChange={(value: MicroappLabel) => setSelectedMicroapp(value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select microapp" />
              </SelectTrigger>
              <SelectContent>
                {microappOptions.map((app) => {
                  const config = labelConfig[app];
                  const Icon = config.icon;
                  return (
                    <SelectItem key={app} value={app}>
                      <div className="flex items-center gap-2">
                        <Icon className="h-4 w-4" />
                        {app}
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Item ID</Label>
            <Input
              placeholder="e.g., CC-001, RG-123"
              value={itemId}
              onChange={(e) => setItemId(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label>Item Title / Description</Label>
            <Input
              placeholder="Brief description of the referenced item"
              value={itemTitle}
              onChange={(e) => setItemTitle(e.target.value)}
            />
          </div>

          <div className="flex gap-2">
            <Button size="sm" onClick={handleAddReference} className="gap-1">
              <Plus className="h-3 w-3" />
              Add Reference
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                setIsAdding(false);
                setSelectedMicroapp('');
                setItemId('');
                setItemTitle('');
              }}
            >
              Cancel
            </Button>
          </div>
        </div>
      ) : (
        <Button
          variant="outline"
          size="sm"
          className="w-full gap-2 border-dashed"
          onClick={() => setIsAdding(true)}
        >
          <ExternalLink className="h-4 w-4" />
          Add Cross-Microapp Reference
        </Button>
      )}
    </div>
  );
}
