import { useState } from 'react';
import { FeedbackItem, FeedbackStatus, FeedbackPriority, Attachment, MicroappLabel, MicroappReference } from '@/types/feedback';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { StatusBadge } from './StatusBadge';
import { PriorityBadge } from './PriorityBadge';
import { Separator } from '@/components/ui/separator';
import { teamMembers } from '@/data/mockFeedback';
import { FileAttachmentUpload, AttachmentList } from './FileAttachment';
import { MicroappLabelSelect } from './MicroappLabelSelect';
import { MicroappLabelBadge } from './MicroappLabelBadge';
import { MicroappReferenceManager } from './MicroappReferenceManager';
import { 
  ArrowLeft, 
  Calendar, 
  User, 
  Building2, 
  MessageSquare,
  UserPlus,
  Clock,
  History,
  Paperclip,
  AlertTriangle,
  Link2,
  ExternalLink,
  CalendarIcon
} from 'lucide-react';
import { format, formatDistanceToNow, isPast, parseISO } from 'date-fns';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface FeedbackDetailsProps {
  feedback: FeedbackItem;
  onBack: () => void;
  onUpdate: (feedbackId: string, updates: Partial<FeedbackItem>) => void;
}

const statusOptions: { value: FeedbackStatus; label: string }[] = [
  { value: 'pending', label: 'Pending' },
  { value: 'in-progress', label: 'In Progress' },
  { value: 'under-review', label: 'Under Review' },
  { value: 'resolved', label: 'Resolved' },
  { value: 'closed', label: 'Closed' },
];

const priorityOptions: { value: FeedbackPriority; label: string }[] = [
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
  { value: 'critical', label: 'Critical' },
];

export function FeedbackDetails({ feedback, onBack, onUpdate }: FeedbackDetailsProps) {
  const [newNote, setNewNote] = useState('');
  const [noteAttachments, setNoteAttachments] = useState<Attachment[]>([]);
  const [selectedStatus, setSelectedStatus] = useState<FeedbackStatus>(feedback.status);
  const [selectedPriority, setSelectedPriority] = useState<FeedbackPriority>(feedback.priority);
  const [selectedAssignee, setSelectedAssignee] = useState(feedback.assignedTo || '');
  const [selectedMicroappLabels, setSelectedMicroappLabels] = useState<MicroappLabel[]>(
    feedback.microappLabels || []
  );
  const [selectedDueDate, setSelectedDueDate] = useState<Date | undefined>(
    feedback.dueDate ? new Date(feedback.dueDate) : undefined
  );
  const [dueDateOpen, setDueDateOpen] = useState(false);

  const isNotClosed = feedback.status !== 'closed';
  const isOverdue = feedback.dueDate && isPast(parseISO(feedback.dueDate)) && feedback.status !== 'closed';

  const handleDueDateChange = (date: Date | undefined) => {
    setSelectedDueDate(date);
    setDueDateOpen(false);
    onUpdate(feedback.id, { dueDate: date?.toISOString() });
    toast({
      title: "Due date updated",
      description: date ? `Due date set to ${format(date, 'PPP')}` : 'Due date removed',
    });
  };

  const handleAddNote = () => {
    if (!newNote.trim() && noteAttachments.length === 0) {
      toast({
        title: "Content required",
        description: "Please enter a note or attach files before adding.",
        variant: "destructive"
      });
      return;
    }

    const note = {
      id: `N-${Date.now()}`,
      content: newNote,
      author: 'Current User',
      createdAt: new Date().toISOString(),
      attachments: noteAttachments,
    };

    onUpdate(feedback.id, {
      notes: [...(feedback.notes || []), note],
    });

    setNewNote('');
    setNoteAttachments([]);
    toast({
      title: "Note added",
      description: "Your note has been added to this feedback.",
    });
  };

  const handlePriorityChange = (priority: FeedbackPriority) => {
    setSelectedPriority(priority);
    onUpdate(feedback.id, { priority });
    toast({
      title: "Priority updated",
      description: `Feedback priority changed to ${priority}.`,
    });
  };

  const handleStatusChange = (status: FeedbackStatus) => {
    setSelectedStatus(status);
    onUpdate(feedback.id, { status });
    toast({
      title: "Status updated",
      description: `Feedback status changed to ${status}.`,
    });
  };

  const handleReassign = () => {
    if (!selectedAssignee) {
      toast({
        title: "Select assignee",
        description: "Please select a team member to reassign.",
        variant: "destructive"
      });
      return;
    }

    onUpdate(feedback.id, { assignedTo: selectedAssignee });
    toast({
      title: "Feedback reassigned",
      description: `Feedback has been reassigned to ${selectedAssignee}.`,
    });
  };

  const handleMicroappLabelsChange = (labels: MicroappLabel[]) => {
    setSelectedMicroappLabels(labels);
    onUpdate(feedback.id, { microappLabels: labels });
    toast({
      title: "Microapp labels updated",
      description: labels.length > 0 
        ? `Linked to: ${labels.join(', ')}`
        : 'All microapp labels removed',
    });
  };

  const handleMicroappReferencesChange = (references: MicroappReference[]) => {
    onUpdate(feedback.id, { microappReferences: references });
  };

  return (
    <div className="animate-fade-in space-y-6">
      <div>
        <Button variant="ghost" onClick={onBack} className="gap-2 mb-4">
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Button>
        
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2 flex-wrap">
              <span className="text-sm font-medium text-muted-foreground">{feedback.id}</span>
              <StatusBadge status={feedback.status} />
              <PriorityBadge priority={feedback.priority} />
              {feedback.microappLabels && feedback.microappLabels.map(label => (
                <MicroappLabelBadge key={label} label={label} />
              ))}
            </div>
            <h1 className="text-2xl font-bold text-foreground">{feedback.title}</h1>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Description</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground whitespace-pre-wrap">{feedback.description}</p>
              
              {feedback.attachments && feedback.attachments.length > 0 && (
                <div className="pt-4 border-t">
                  <div className="flex items-center gap-2 mb-3">
                    <Paperclip className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium text-muted-foreground">
                      Attachments ({feedback.attachments.length})
                    </span>
                  </div>
                  <AttachmentList attachments={feedback.attachments} />
                </div>
              )}
            </CardContent>
          </Card>

          {/* Notes Section */}
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                Notes & Updates
              </CardTitle>
              <CardDescription>
                Add progress notes and communicate with the team
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                {feedback.notes && feedback.notes.length > 0 ? (
                  feedback.notes.map((note) => (
                    <div key={note.id} className="bg-muted/50 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">{note.author}</span>
                        <span className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(note.createdAt), { addSuffix: true })}
                        </span>
                      </div>
                      {note.content && (
                        <p className="text-sm text-foreground">{note.content}</p>
                      )}
                      {note.attachments && note.attachments.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-border/50">
                          <AttachmentList attachments={note.attachments} compact />
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground italic">No notes yet</p>
                )}
              </div>

              <Separator />

              <div className="space-y-3">
                <Label htmlFor="newNote">Add a Note</Label>
                <Textarea
                  id="newNote"
                  placeholder="Add progress updates, questions, or comments..."
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  className="min-h-[100px]"
                />
                
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Attach Files (optional)</Label>
                  <FileAttachmentUpload
                    attachments={noteAttachments}
                    onAttachmentsChange={setNoteAttachments}
                    maxFiles={3}
                  />
                </div>
                
                <Button onClick={handleAddNote} className="gap-2">
                  <MessageSquare className="h-4 w-4" />
                  Add Note
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Cross-Microapp References Card */}
          {isNotClosed && (
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ExternalLink className="h-5 w-5 text-primary" />
                  Cross-Microapp References
                </CardTitle>
                <CardDescription>
                  Link related items from other microapps for reference
                </CardDescription>
              </CardHeader>
              <CardContent>
                <MicroappReferenceManager
                  references={feedback.microappReferences || []}
                  onReferencesChange={handleMicroappReferencesChange}
                  disabled={false}
                />
              </CardContent>
            </Card>
          )}

          {/* Show references in read-only mode for closed items */}
          {!isNotClosed && feedback.microappReferences && feedback.microappReferences.length > 0 && (
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ExternalLink className="h-5 w-5 text-primary" />
                  Cross-Microapp References
                </CardTitle>
                <CardDescription>
                  Referenced items from other microapps
                </CardDescription>
              </CardHeader>
              <CardContent>
                <MicroappReferenceManager
                  references={feedback.microappReferences}
                  onReferencesChange={handleMicroappReferencesChange}
                  disabled={true}
                />
              </CardContent>
            </Card>
          )}

          {/* History */}
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5 text-primary" />
                Activity History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {feedback.history && feedback.history.length > 0 ? (
                  feedback.history.map((entry, index) => (
                    <div key={entry.id} className="flex gap-3">
                      <div className="relative">
                        <div className="h-2 w-2 rounded-full bg-primary mt-2" />
                        {index < feedback.history!.length - 1 && (
                          <div className="absolute left-1/2 top-4 -translate-x-1/2 w-px h-full bg-border" />
                        )}
                      </div>
                      <div className="flex-1 pb-4">
                        <p className="text-sm font-medium">{entry.action}</p>
                        <p className="text-xs text-muted-foreground">
                          {entry.actor} • {format(new Date(entry.timestamp), 'MMM d, yyyy h:mm a')}
                        </p>
                        {entry.details && (
                          <p className="text-sm text-muted-foreground mt-1">{entry.details}</p>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground italic">No history available</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Details Card */}
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <Building2 className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Department</p>
                  <p className="text-sm font-medium">{feedback.department}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <User className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Submitted By</p>
                  <p className="text-sm font-medium">{feedback.submittedBy}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Submitted</p>
                  <p className="text-sm font-medium">
                    {format(new Date(feedback.submittedAt), 'MMM d, yyyy')}
                  </p>
                </div>
              </div>

              {feedback.dueDate && (
                <div className="flex items-center gap-3">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Due Date</p>
                    <p className="text-sm font-medium">
                      {format(new Date(feedback.dueDate), 'MMM d, yyyy')}
                    </p>
                  </div>
                </div>
              )}

              {feedback.attachments && feedback.attachments.length > 0 && (
                <div className="flex items-center gap-3">
                  <Paperclip className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Attachments</p>
                    <p className="text-sm font-medium">{feedback.attachments.length} file(s)</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Actions Card */}
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Update Status</Label>
                <Select value={selectedStatus} onValueChange={handleStatusChange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {statusOptions.map((status) => (
                      <SelectItem key={status.value} value={status.value}>
                        {status.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              {isNotClosed && (
                <>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                      Update Due Date
                    </Label>
                    {isOverdue && (
                      <p className="text-xs text-destructive flex items-center gap-1">
                        <AlertTriangle className="h-3 w-3" />
                        This item is overdue
                      </p>
                    )}
                    <Popover open={dueDateOpen} onOpenChange={setDueDateOpen}>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !selectedDueDate && "text-muted-foreground",
                            isOverdue && "border-destructive text-destructive"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {selectedDueDate ? format(selectedDueDate, "PPP") : "Set due date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <CalendarComponent
                          mode="single"
                          selected={selectedDueDate}
                          onSelect={handleDueDateChange}
                          initialFocus
                          className="p-3 pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <Separator />
                </>
              )}

              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                  Update Priority
                </Label>
                <Select value={selectedPriority} onValueChange={handlePriorityChange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {priorityOptions.map((priority) => (
                      <SelectItem key={priority.value} value={priority.value}>
                        {priority.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Reassign To</Label>
                <Select value={selectedAssignee} onValueChange={setSelectedAssignee}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select team member" />
                  </SelectTrigger>
                  <SelectContent>
                    {teamMembers.map((member) => (
                      <SelectItem key={member} value={member}>
                        {member}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  variant="outline" 
                  className="w-full gap-2 mt-2"
                  onClick={handleReassign}
                >
                  <UserPlus className="h-4 w-4" />
                  Reassign Feedback
                </Button>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Link2 className="h-4 w-4 text-muted-foreground" />
                  Cross-Microapp Labels
                </Label>
                <p className="text-xs text-muted-foreground mb-2">
                  Link to other microapps based on issue type
                </p>
                <MicroappLabelSelect
                  selectedLabels={selectedMicroappLabels}
                  onLabelsChange={handleMicroappLabelsChange}
                />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
