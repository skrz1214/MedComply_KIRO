import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { FeedbackCategory, FeedbackPriority, Attachment, MicroappLabel, MicroappReference } from '@/types/feedback';
import { departments } from '@/data/mockFeedback';
import { ArrowLeft, Send, Link2, ExternalLink, CalendarIcon } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { FileAttachmentUpload } from './FileAttachment';
import { MicroappLabelSelect } from './MicroappLabelSelect';
import { MicroappLabelBadge } from './MicroappLabelBadge';
import { MicroappReferenceManager } from './MicroappReferenceManager';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface NewFeedbackFormProps {
  onSubmit: (data: NewFeedbackData) => void;
  onCancel: () => void;
}

export interface NewFeedbackData {
  title: string;
  description: string;
  category: FeedbackCategory;
  priority: FeedbackPriority;
  department: string;
  dueDate?: string;
  attachments: Attachment[];
  microappLabels: MicroappLabel[];
  microappReferences: MicroappReference[];
}

const categories: { value: FeedbackCategory; label: string }[] = [
  { value: 'compliance-issue', label: 'Compliance Issue' },
  { value: 'process-improvement', label: 'Process Improvement' },
  { value: 'safety-concern', label: 'Safety Concern' },
  { value: 'policy-question', label: 'Policy Question' },
  { value: 'training-request', label: 'Training Request' },
  { value: 'other', label: 'Other' },
];

const priorities: { value: FeedbackPriority; label: string; description: string }[] = [
  { value: 'low', label: 'Low', description: 'Can be addressed in regular workflow' },
  { value: 'medium', label: 'Medium', description: 'Should be addressed within a week' },
  { value: 'high', label: 'High', description: 'Requires attention within 48 hours' },
  { value: 'critical', label: 'Critical', description: 'Immediate attention required' },
];

export function NewFeedbackForm({ onSubmit, onCancel }: NewFeedbackFormProps) {
  const [formData, setFormData] = useState<NewFeedbackData>({
    title: '',
    description: '',
    category: 'compliance-issue',
    priority: 'medium',
    department: '',
    dueDate: undefined,
    attachments: [],
    microappLabels: [],
    microappReferences: [],
  });
  const [dueDateOpen, setDueDateOpen] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim()) {
      toast({
        title: "Title required",
        description: "Please enter a title for your feedback.",
        variant: "destructive"
      });
      return;
    }

    if (!formData.description.trim()) {
      toast({
        title: "Description required",
        description: "Please provide a description of your feedback.",
        variant: "destructive"
      });
      return;
    }

    if (!formData.department) {
      toast({
        title: "Department required",
        description: "Please select a department for routing.",
        variant: "destructive"
      });
      return;
    }

    onSubmit(formData);
  };

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <Button variant="ghost" onClick={onCancel} className="gap-2 mb-4">
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Button>
        <h1 className="text-2xl font-bold text-foreground">Submit New Feedback</h1>
        <p className="text-muted-foreground mt-1">
          Report compliance concerns, suggest improvements, or request assistance
        </p>
      </div>

      <form onSubmit={handleSubmit}>
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>Feedback Details</CardTitle>
            <CardDescription>
              Provide clear and specific information to help route your feedback to the right team
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">Title *</Label>
              <Input
                id="title"
                placeholder="Brief summary of your feedback"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="h-11"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="category">Category *</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value: FeedbackCategory) => 
                    setFormData({ ...formData, category: value })
                  }
                >
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="priority">Priority *</Label>
                <Select
                  value={formData.priority}
                  onValueChange={(value: FeedbackPriority) => 
                    setFormData({ ...formData, priority: value })
                  }
                >
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent>
                    {priorities.map((pri) => (
                      <SelectItem key={pri.value} value={pri.value}>
                        <div>
                          <span className="font-medium">{pri.label}</span>
                          <span className="text-muted-foreground text-xs ml-2">
                            {pri.description}
                          </span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="department">Route to Department *</Label>
                <Select
                  value={formData.department}
                  onValueChange={(value) => setFormData({ ...formData, department: value })}
                >
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    {departments.map((dept) => (
                      <SelectItem key={dept} value={dept}>
                        {dept}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Due Date (optional)</Label>
              <Popover open={dueDateOpen} onOpenChange={setDueDateOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full h-11 justify-start text-left font-normal",
                      !formData.dueDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.dueDate ? format(new Date(formData.dueDate), "PPP") : "Select due date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={formData.dueDate ? new Date(formData.dueDate) : undefined}
                    onSelect={(date) => {
                      setFormData({ ...formData, dueDate: date?.toISOString() });
                      setDueDateOpen(false);
                    }}
                    disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                    initialFocus
                    className="p-3 pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                placeholder="Provide detailed information about your feedback. Include relevant context, specific examples, and any supporting details that will help the team understand and address this item."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="min-h-[160px] resize-none"
              />
            </div>

            <div className="space-y-2">
              <Label>Attachments</Label>
              <FileAttachmentUpload
                attachments={formData.attachments}
                onAttachmentsChange={(attachments) => setFormData({ ...formData, attachments })}
              />
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Link2 className="h-4 w-4" />
                Cross-Microapp Labels
              </Label>
              <p className="text-xs text-muted-foreground mb-3">
                Tag this feedback if it relates to other microapps based on root cause or nature of the issue
              </p>
              <MicroappLabelSelect
                selectedLabels={formData.microappLabels}
                onLabelsChange={(microappLabels) => setFormData({ ...formData, microappLabels })}
              />
              {formData.microappLabels.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t">
                  <span className="text-xs text-muted-foreground">Selected:</span>
                  {formData.microappLabels.map(label => (
                    <MicroappLabelBadge key={label} label={label} />
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <ExternalLink className="h-4 w-4" />
                Cross-Microapp References
              </Label>
              <p className="text-xs text-muted-foreground mb-3">
                Link specific items from other microapps that are related to this feedback
              </p>
              <MicroappReferenceManager
                references={formData.microappReferences}
                onReferencesChange={(microappReferences) => setFormData({ ...formData, microappReferences })}
              />
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button type="button" variant="outline" onClick={onCancel}>
                Cancel
              </Button>
              <Button type="submit" className="gap-2">
                <Send className="h-4 w-4" />
                Submit Feedback
              </Button>
            </div>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}
