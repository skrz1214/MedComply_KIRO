import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Attachment } from '@/types/feedback';
import { Paperclip, X, FileText, Image, File, Download } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FileAttachmentUploadProps {
  attachments: Attachment[];
  onAttachmentsChange: (attachments: Attachment[]) => void;
  maxFiles?: number;
  maxSizeMB?: number;
}

const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

const getFileIcon = (type: string) => {
  if (type.startsWith('image/')) return Image;
  if (type.includes('pdf') || type.includes('document')) return FileText;
  return File;
};

export function FileAttachmentUpload({ 
  attachments, 
  onAttachmentsChange, 
  maxFiles = 5,
  maxSizeMB = 10 
}: FileAttachmentUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false);

  const handleFileSelect = (files: FileList | null) => {
    if (!files) return;

    const newAttachments: Attachment[] = [];
    const maxSize = maxSizeMB * 1024 * 1024;

    Array.from(files).forEach((file) => {
      if (attachments.length + newAttachments.length >= maxFiles) return;
      if (file.size > maxSize) return;

      const attachment: Attachment = {
        id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        name: file.name,
        size: file.size,
        type: file.type,
        url: URL.createObjectURL(file),
        uploadedAt: new Date().toISOString(),
        uploadedBy: 'Current User',
      };
      newAttachments.push(attachment);
    });

    onAttachmentsChange([...attachments, ...newAttachments]);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    handleFileSelect(e.dataTransfer.files);
  };

  const removeAttachment = (id: string) => {
    onAttachmentsChange(attachments.filter(a => a.id !== id));
  };

  return (
    <div className="space-y-3">
      <div
        className={cn(
          "border-2 border-dashed rounded-lg p-4 transition-colors cursor-pointer",
          "hover:border-primary/50 hover:bg-primary/5",
          dragActive && "border-primary bg-primary/10",
          attachments.length >= maxFiles && "opacity-50 pointer-events-none"
        )}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => handleFileSelect(e.target.files)}
          accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg,.gif,.txt"
        />
        <div className="flex flex-col items-center gap-2 text-center">
          <Paperclip className="h-6 w-6 text-muted-foreground" />
          <div>
            <p className="text-sm font-medium text-foreground">
              Drop files here or click to upload
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Max {maxFiles} files, {maxSizeMB}MB each
            </p>
          </div>
        </div>
      </div>

      {attachments.length > 0 && (
        <div className="space-y-2">
          {attachments.map((attachment) => {
            const FileIcon = getFileIcon(attachment.type);
            return (
              <div
                key={attachment.id}
                className="flex items-center gap-3 p-2 rounded-lg bg-muted/50 group"
              >
                <div className="p-2 rounded-md bg-primary/10">
                  <FileIcon className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{attachment.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatFileSize(attachment.size)}
                  </p>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={(e) => {
                    e.stopPropagation();
                    removeAttachment(attachment.id);
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

interface AttachmentListProps {
  attachments: Attachment[];
  compact?: boolean;
}

export function AttachmentList({ attachments, compact = false }: AttachmentListProps) {
  if (!attachments || attachments.length === 0) return null;

  return (
    <div className={cn("space-y-2", compact && "space-y-1")}>
      {attachments.map((attachment) => {
        const FileIcon = getFileIcon(attachment.type);
        return (
          <a
            key={attachment.id}
            href={attachment.url}
            target="_blank"
            rel="noopener noreferrer"
            className={cn(
              "flex items-center gap-2 rounded-lg transition-colors hover:bg-muted/50",
              compact ? "p-1.5" : "p-2 bg-muted/30"
            )}
          >
            <div className={cn("rounded-md bg-primary/10", compact ? "p-1" : "p-2")}>
              <FileIcon className={cn("text-primary", compact ? "h-3 w-3" : "h-4 w-4")} />
            </div>
            <div className="flex-1 min-w-0">
              <p className={cn("font-medium truncate", compact ? "text-xs" : "text-sm")}>
                {attachment.name}
              </p>
              {!compact && (
                <p className="text-xs text-muted-foreground">
                  {formatFileSize(attachment.size)}
                </p>
              )}
            </div>
            <Download className={cn("text-muted-foreground", compact ? "h-3 w-3" : "h-4 w-4")} />
          </a>
        );
      })}
    </div>
  );
}
