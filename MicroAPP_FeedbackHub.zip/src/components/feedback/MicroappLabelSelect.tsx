import { MicroappLabel } from '@/types/feedback';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { getMicroappLabelConfig, MicroappLabelBadge } from './MicroappLabelBadge';
import { cn } from '@/lib/utils';

interface MicroappLabelSelectProps {
  selectedLabels: MicroappLabel[];
  onLabelsChange: (labels: MicroappLabel[]) => void;
  className?: string;
}

const microappLabels: MicroappLabel[] = ['ComplianceConnect', 'RiskGuard', 'EnforcePoint', 'AuditPro'];

export function MicroappLabelSelect({ 
  selectedLabels, 
  onLabelsChange, 
  className 
}: MicroappLabelSelectProps) {
  const labelConfig = getMicroappLabelConfig();

  const handleToggle = (label: MicroappLabel) => {
    if (selectedLabels.includes(label)) {
      onLabelsChange(selectedLabels.filter(l => l !== label));
    } else {
      onLabelsChange([...selectedLabels, label]);
    }
  };

  return (
    <div className={cn('space-y-3', className)}>
      {microappLabels.map((label) => {
        const config = labelConfig[label];
        const isSelected = selectedLabels.includes(label);

        return (
          <div 
            key={label}
            className={cn(
              'flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors',
              isSelected 
                ? 'border-primary bg-primary/5' 
                : 'border-border hover:bg-muted/50'
            )}
            onClick={() => handleToggle(label)}
          >
            <Checkbox
              id={`microapp-${label}`}
              checked={isSelected}
              onCheckedChange={() => handleToggle(label)}
              onClick={(e) => e.stopPropagation()}
              className="mt-0.5"
            />
            <div className="flex-1 space-y-1">
              <div className="flex items-center gap-2">
                <MicroappLabelBadge label={label} />
              </div>
              <p className="text-xs text-muted-foreground">
                {config.description}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
