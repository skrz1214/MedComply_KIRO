import { Badge } from '@/components/ui/badge';
import { FeedbackPriority } from '@/types/feedback';

interface PriorityBadgeProps {
  priority: FeedbackPriority;
}

const priorityConfig: Record<FeedbackPriority, { label: string; variant: 'secondary' | 'info' | 'warning' | 'critical' }> = {
  'low': { label: 'Low', variant: 'secondary' },
  'medium': { label: 'Medium', variant: 'info' },
  'high': { label: 'High', variant: 'warning' },
  'critical': { label: 'Critical', variant: 'critical' },
};

export function PriorityBadge({ priority }: PriorityBadgeProps) {
  const config = priorityConfig[priority];

  return (
    <Badge variant={config.variant}>
      {config.label}
    </Badge>
  );
}
