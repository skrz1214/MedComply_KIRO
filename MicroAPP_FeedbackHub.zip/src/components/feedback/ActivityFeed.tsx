import { ActivityItem } from '@/types/feedback';
import { formatDistanceToNow } from 'date-fns';
import { 
  MessageSquarePlus, 
  RefreshCw, 
  UserPlus, 
  MessageCircle, 
  ArrowRightLeft, 
  CheckCircle2 
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface ActivityFeedProps {
  activities: ActivityItem[];
  onActivityClick?: (feedbackId: string) => void;
}

const activityIcons: Record<ActivityItem['type'], React.ElementType> = {
  'submission': MessageSquarePlus,
  'update': RefreshCw,
  'assignment': UserPlus,
  'comment': MessageCircle,
  'status-change': ArrowRightLeft,
  'resolution': CheckCircle2,
};

const activityColors: Record<ActivityItem['type'], string> = {
  'submission': 'bg-primary/10 text-primary',
  'update': 'bg-info/10 text-info',
  'assignment': 'bg-accent/10 text-accent',
  'comment': 'bg-secondary text-secondary-foreground',
  'status-change': 'bg-warning/10 text-warning',
  'resolution': 'bg-success/10 text-success',
};

export function ActivityFeed({ activities, onActivityClick }: ActivityFeedProps) {
  return (
    <div className="space-y-1">
      {activities.map((activity, index) => {
        const Icon = activityIcons[activity.type];
        return (
          <div
            key={activity.id}
            className={cn(
              "flex items-start gap-3 p-3 rounded-lg transition-colors cursor-pointer hover:bg-muted/50",
              "animate-fade-in"
            )}
            style={{ animationDelay: `${index * 50}ms` }}
            onClick={() => onActivityClick?.(activity.feedbackId)}
          >
            <div className={cn("p-2 rounded-lg flex-shrink-0", activityColors[activity.type])}>
              <Icon className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground line-clamp-1">
                {activity.feedbackTitle}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {activity.action} by {activity.actor}
              </p>
              <p className="text-xs text-muted-foreground/70 mt-1">
                {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
