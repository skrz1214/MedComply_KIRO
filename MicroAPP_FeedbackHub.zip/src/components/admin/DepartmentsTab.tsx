import { useState } from 'react';
import { useAdminConfig } from '@/contexts/AdminConfigContext';
import { useUser } from '@/contexts/UserContext';
import { Department } from '@/types/admin';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export function DepartmentsTab() {
  const { config, updateDepartments, addAuditLog } = useAdminConfig();
  const { currentUser } = useUser();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingDept, setEditingDept] = useState<Department | null>(null);
  const [formData, setFormData] = useState({ name: '', code: '', isActive: true });

  const handleOpenDialog = (dept?: Department) => {
    if (dept) {
      setEditingDept(dept);
      setFormData({ name: dept.name, code: dept.code, isActive: dept.isActive });
    } else {
      setEditingDept(null);
      setFormData({ name: '', code: '', isActive: true });
    }
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.name || !formData.code) {
      toast({ title: 'Error', description: 'Name and code are required', variant: 'destructive' });
      return;
    }

    if (editingDept) {
      const updated = config.departments.map(d =>
        d.id === editingDept.id ? { ...d, ...formData } : d
      );
      updateDepartments(updated);
      addAuditLog({
        action: 'Updated department',
        actor: currentUser.name,
        actorRole: currentUser.role,
        entityType: 'department',
        entityId: editingDept.id,
        changes: { name: { old: editingDept.name, new: formData.name } },
      });
      toast({ title: 'Department updated' });
    } else {
      const newDept: Department = {
        id: `dept-${Date.now()}`,
        name: formData.name,
        code: formData.code.toUpperCase(),
        isActive: formData.isActive,
        createdAt: new Date().toISOString(),
      };
      updateDepartments([...config.departments, newDept]);
      addAuditLog({
        action: 'Created department',
        actor: currentUser.name,
        actorRole: currentUser.role,
        entityType: 'department',
        entityId: newDept.id,
        changes: { name: { old: null, new: formData.name } },
      });
      toast({ title: 'Department created' });
    }
    setIsDialogOpen(false);
  };

  const handleDelete = (dept: Department) => {
    updateDepartments(config.departments.filter(d => d.id !== dept.id));
    addAuditLog({
      action: 'Deleted department',
      actor: currentUser.name,
      actorRole: currentUser.role,
      entityType: 'department',
      entityId: dept.id,
      changes: { name: { old: dept.name, new: null } },
    });
    toast({ title: 'Department deleted' });
  };

  const handleToggleActive = (dept: Department) => {
    const updated = config.departments.map(d =>
      d.id === dept.id ? { ...d, isActive: !d.isActive } : d
    );
    updateDepartments(updated);
    addAuditLog({
      action: `${dept.isActive ? 'Disabled' : 'Enabled'} department`,
      actor: currentUser.name,
      actorRole: currentUser.role,
      entityType: 'department',
      entityId: dept.id,
      changes: { isActive: { old: dept.isActive, new: !dept.isActive } },
    });
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Departments</CardTitle>
          <CardDescription>Manage organization departments for feedback routing</CardDescription>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()}>
              <Plus className="h-4 w-4 mr-2" />
              Add Department
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingDept ? 'Edit Department' : 'Add Department'}</DialogTitle>
              <DialogDescription>
                {editingDept ? 'Update department details' : 'Create a new department'}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., Nursing"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="code">Code</Label>
                <Input
                  id="code"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                  placeholder="e.g., NUR"
                  maxLength={5}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="active"
                  checked={formData.isActive}
                  onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                />
                <Label htmlFor="active">Active</Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleSave}>Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Code</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {config.departments.map((dept) => (
              <TableRow key={dept.id}>
                <TableCell className="font-medium">{dept.name}</TableCell>
                <TableCell>
                  <Badge variant="outline">{dept.code}</Badge>
                </TableCell>
                <TableCell>
                  <Switch
                    checked={dept.isActive}
                    onCheckedChange={() => handleToggleActive(dept)}
                  />
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(dept)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(dept)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
