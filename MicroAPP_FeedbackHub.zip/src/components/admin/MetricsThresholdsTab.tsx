import { useState } from 'react';
import { useAdminConfig } from '@/contexts/AdminConfigContext';
import { useUser } from '@/contexts/UserContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/hooks/use-toast';
import { Save, Clock, AlertTriangle, Target, TrendingUp } from 'lucide-react';
import { MetricsThresholds } from '@/types/admin';

export function MetricsThresholdsTab() {
  const { config, updateMetricsThresholds, addAuditLog } = useAdminConfig();
  const { currentUser } = useUser();
  const [thresholds, setThresholds] = useState<MetricsThresholds>(config.metricsThresholds);
  const [hasChanges, setHasChanges] = useState(false);

  const handleChange = (field: keyof MetricsThresholds, value: number) => {
    setThresholds(prev => ({ ...prev, [field]: value }));
    setHasChanges(true);
  };

  const handleSave = () => {
    updateMetricsThresholds(thresholds);
    addAuditLog({
      action: 'Updated metrics thresholds',
      actor: currentUser?.name || 'Unknown',
      actorRole: currentUser?.role || 'administrator',
      entityType: 'metrics_thresholds',
      entityId: 'thresholds',
      changes: {
        resolutionTimeTargetDays: { old: config.metricsThresholds.resolutionTimeTargetDays, new: thresholds.resolutionTimeTargetDays },
        overdueRateTargetPercent: { old: config.metricsThresholds.overdueRateTargetPercent, new: thresholds.overdueRateTargetPercent },
      },
    });
    setHasChanges(false);
    toast({
      title: 'Thresholds updated',
      description: 'Success metrics thresholds have been saved.',
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="h-5 w-5 text-primary" />
          Success Metrics Thresholds
        </CardTitle>
        <CardDescription>
          Configure target and warning thresholds for dashboard success metrics
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Resolution Time */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm font-medium text-foreground">
            <Clock className="h-4 w-4 text-primary" />
            Average Resolution Time
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-6">
            <div className="space-y-2">
              <Label htmlFor="resolutionTarget" className="text-sm text-muted-foreground flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-success" />
                Target (days)
              </Label>
              <Input
                id="resolutionTarget"
                type="number"
                min={0.5}
                max={30}
                step={0.5}
                value={thresholds.resolutionTimeTargetDays}
                onChange={(e) => handleChange('resolutionTimeTargetDays', parseFloat(e.target.value) || 2)}
              />
              <p className="text-xs text-muted-foreground">
                Resolution time below this is considered excellent (green)
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="resolutionWarning" className="text-sm text-muted-foreground flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-warning" />
                Warning (days)
              </Label>
              <Input
                id="resolutionWarning"
                type="number"
                min={1}
                max={60}
                step={0.5}
                value={thresholds.resolutionTimeWarningDays}
                onChange={(e) => handleChange('resolutionTimeWarningDays', parseFloat(e.target.value) || 4)}
              />
              <p className="text-xs text-muted-foreground">
                Above target but below this shows warning (amber), above shows critical (red)
              </p>
            </div>
          </div>
        </div>

        {/* Overdue Rate */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm font-medium text-foreground">
            <AlertTriangle className="h-4 w-4 text-warning" />
            Overdue Rate
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-6">
            <div className="space-y-2">
              <Label htmlFor="overdueTarget" className="text-sm text-muted-foreground flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-success" />
                Target (%)
              </Label>
              <Input
                id="overdueTarget"
                type="number"
                min={1}
                max={50}
                step={1}
                value={thresholds.overdueRateTargetPercent}
                onChange={(e) => handleChange('overdueRateTargetPercent', parseInt(e.target.value) || 10)}
              />
              <p className="text-xs text-muted-foreground">
                Overdue rate below this is considered excellent (green)
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="overdueWarning" className="text-sm text-muted-foreground flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-warning" />
                Warning (%)
              </Label>
              <Input
                id="overdueWarning"
                type="number"
                min={5}
                max={75}
                step={1}
                value={thresholds.overdueRateWarningPercent}
                onChange={(e) => handleChange('overdueRateWarningPercent', parseInt(e.target.value) || 20)}
              />
              <p className="text-xs text-muted-foreground">
                Above target but below this shows warning (amber), above shows critical (red)
              </p>
            </div>
          </div>
        </div>

        {/* Preview */}
        <div className="border-t pt-4">
          <div className="flex items-center gap-2 text-sm font-medium text-foreground mb-3">
            <TrendingUp className="h-4 w-4 text-primary" />
            Threshold Preview
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="p-3 rounded-lg bg-muted/50">
              <p className="text-muted-foreground mb-2">Resolution Time</p>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-success" />
                  <span>≤ {thresholds.resolutionTimeTargetDays} days</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-warning" />
                  <span>{thresholds.resolutionTimeTargetDays} - {thresholds.resolutionTimeWarningDays} days</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-destructive" />
                  <span>&gt; {thresholds.resolutionTimeWarningDays} days</span>
                </div>
              </div>
            </div>
            <div className="p-3 rounded-lg bg-muted/50">
              <p className="text-muted-foreground mb-2">Overdue Rate</p>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-success" />
                  <span>≤ {thresholds.overdueRateTargetPercent}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-warning" />
                  <span>{thresholds.overdueRateTargetPercent} - {thresholds.overdueRateWarningPercent}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-destructive" />
                  <span>&gt; {thresholds.overdueRateWarningPercent}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-4 border-t">
          <Button onClick={handleSave} disabled={!hasChanges}>
            <Save className="h-4 w-4 mr-2" />
            Save Thresholds
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
