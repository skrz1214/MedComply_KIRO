import { useAdminConfig } from '@/contexts/AdminConfigContext';
import { useUser } from '@/contexts/UserContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { toast } from '@/hooks/use-toast';

const eventTypes = [
  { id: 'submission', label: 'Submission', description: 'New feedback submitted' },
  { id: 'update', label: 'Update', description: 'Feedback details updated' },
  { id: 'assignment', label: 'Assignment', description: 'Feedback assigned/reassigned' },
  { id: 'comment', label: 'Comment', description: 'Note added' },
  { id: 'status-change', label: 'Status Change', description: 'Status updated' },
  { id: 'resolution', label: 'Resolution', description: 'Feedback resolved' },
];

export function ActivityFeedPolicyTab() {
  const { config, updateActivityFeedPolicy, addAuditLog } = useAdminConfig();
  const { currentUser } = useUser();
  const { activityFeedPolicy } = config;

  const handleUpdate = (key: keyof typeof activityFeedPolicy, value: unknown) => {
    updateActivityFeedPolicy({ ...activityFeedPolicy, [key]: value });
    addAuditLog({
      action: `Updated activity feed policy: ${key}`,
      actor: currentUser.name,
      actorRole: currentUser.role,
      entityType: 'activity_feed_policy',
      entityId: 'policy',
      changes: { [key]: { old: activityFeedPolicy[key], new: value } },
    });
    toast({ title: 'Policy updated' });
  };

  const toggleEventType = (eventType: string) => {
    const current = activityFeedPolicy.enabledEventTypes;
    const updated = current.includes(eventType)
      ? current.filter(e => e !== eventType)
      : [...current, eventType];
    handleUpdate('enabledEventTypes', updated);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Event Types</CardTitle>
          <CardDescription>Choose which events appear in the activity feed</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2">
            {eventTypes.map((event) => (
              <div key={event.id} className="flex items-start space-x-3">
                <Checkbox
                  id={event.id}
                  checked={activityFeedPolicy.enabledEventTypes.includes(event.id)}
                  onCheckedChange={() => toggleEventType(event.id)}
                />
                <div className="space-y-0.5">
                  <Label htmlFor={event.id} className="text-sm font-medium">
                    {event.label}
                  </Label>
                  <p className="text-xs text-muted-foreground">{event.description}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Visibility Settings</CardTitle>
          <CardDescription>Control who can see which activities</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Staff Sees Own Only</Label>
              <p className="text-sm text-muted-foreground">
                Healthcare staff can only see activities related to their submissions
              </p>
            </div>
            <Switch
              checked={activityFeedPolicy.staffSeesOwnOnly}
              onCheckedChange={(checked) => handleUpdate('staffSeesOwnOnly', checked)}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Manager Sees Department Only</Label>
              <p className="text-sm text-muted-foreground">
                Department managers can only see activities for their department
              </p>
            </div>
            <Switch
              checked={activityFeedPolicy.managerSeesDepartmentOnly}
              onCheckedChange={(checked) => handleUpdate('managerSeesDepartmentOnly', checked)}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Retention</CardTitle>
          <CardDescription>Configure how long activity data is kept</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="retentionDays">Retention Period (days)</Label>
            <Input
              id="retentionDays"
              type="number"
              min={30}
              max={365}
              value={activityFeedPolicy.retentionDays}
              onChange={(e) => handleUpdate('retentionDays', parseInt(e.target.value) || 90)}
              className="w-32"
            />
            <p className="text-xs text-muted-foreground">
              Activity events older than this will be archived
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
