import { useAdminConfig } from '@/contexts/AdminConfigContext';
import { useUser } from '@/contexts/UserContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { toast } from '@/hooks/use-toast';

export function WorkflowPolicyTab() {
  const { config, updateWorkflowPolicy, addAuditLog } = useAdminConfig();
  const { currentUser } = useUser();
  const { workflowPolicy } = config;

  const handleToggle = (key: keyof typeof workflowPolicy, value: boolean) => {
    updateWorkflowPolicy({ ...workflowPolicy, [key]: value });
    addAuditLog({
      action: `Updated workflow policy: ${key}`,
      actor: currentUser.name,
      actorRole: currentUser.role,
      entityType: 'workflow_policy',
      entityId: 'policy',
      changes: { [key]: { old: workflowPolicy[key], new: value } },
    });
    toast({ title: 'Policy updated' });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Status Workflow</CardTitle>
          <CardDescription>Configure how feedback items move through the workflow</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Allow Send-Back Transitions</Label>
              <p className="text-sm text-muted-foreground">
                Allow moving items backwards in the workflow (e.g., under-review → in-progress)
              </p>
            </div>
            <Switch
              checked={workflowPolicy.allowSendBack}
              onCheckedChange={(checked) => handleToggle('allowSendBack', checked)}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Require Resolution Note</Label>
              <p className="text-sm text-muted-foreground">
                Require a note when marking feedback as resolved
              </p>
            </div>
            <Switch
              checked={workflowPolicy.requireResolutionNote}
              onCheckedChange={(checked) => handleToggle('requireResolutionNote', checked)}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Require Closure Note</Label>
              <p className="text-sm text-muted-foreground">
                Require a note when closing feedback items
              </p>
            </div>
            <Switch
              checked={workflowPolicy.requireClosureNote}
              onCheckedChange={(checked) => handleToggle('requireClosureNote', checked)}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Role Permissions</CardTitle>
          <CardDescription>Configure what each role can do in the feedback lifecycle</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <h4 className="font-medium">Healthcare Staff</h4>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="staffNotes"
                checked={workflowPolicy.staffCanAddNotes}
                onCheckedChange={(checked) => handleToggle('staffCanAddNotes', checked as boolean)}
              />
              <Label htmlFor="staffNotes" className="text-sm font-normal">
                Can add notes/comments to their submitted feedback
              </Label>
            </div>
            <p className="text-xs text-muted-foreground ml-6">
              Staff always have read-only access after submission. They cannot change status, priority, or assignments.
            </p>
          </div>

          <Separator />

          <div className="space-y-4">
            <h4 className="font-medium">Department Managers</h4>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="managerStatus"
                  checked={workflowPolicy.managerCanChangeStatus}
                  onCheckedChange={(checked) => handleToggle('managerCanChangeStatus', checked as boolean)}
                />
                <Label htmlFor="managerStatus" className="text-sm font-normal">
                  Can change status of department feedback
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="managerReassign"
                  checked={workflowPolicy.managerCanReassign}
                  onCheckedChange={(checked) => handleToggle('managerCanReassign', checked as boolean)}
                />
                <Label htmlFor="managerReassign" className="text-sm font-normal">
                  Can reassign feedback within their department
                </Label>
              </div>
            </div>
            <p className="text-xs text-muted-foreground ml-6">
              Managers always have view access to their department feedback and can add internal notes.
            </p>
          </div>

          <Separator />

          <div className="space-y-2">
            <h4 className="font-medium">Compliance Officers & Administrators</h4>
            <p className="text-sm text-muted-foreground">
              Have full lifecycle control: change status, priority, reassign, add notes, resolve, and close feedback items.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
