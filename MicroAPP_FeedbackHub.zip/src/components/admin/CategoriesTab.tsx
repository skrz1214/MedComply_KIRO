import { useState } from 'react';
import { useAdminConfig } from '@/contexts/AdminConfigContext';
import { useUser } from '@/contexts/UserContext';
import { CategoryConfig } from '@/types/admin';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Pencil, Trash2, GripVertical } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export function CategoriesTab() {
  const { config, updateCategories, addAuditLog } = useAdminConfig();
  const { currentUser } = useUser();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<CategoryConfig | null>(null);
  const [formData, setFormData] = useState({ name: '', code: '', description: '', isActive: true });

  const handleOpenDialog = (cat?: CategoryConfig) => {
    if (cat) {
      setEditingCat(cat);
      setFormData({ name: cat.name, code: cat.code, description: cat.description || '', isActive: cat.isActive });
    } else {
      setEditingCat(null);
      setFormData({ name: '', code: '', description: '', isActive: true });
    }
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.name || !formData.code) {
      toast({ title: 'Error', description: 'Name and code are required', variant: 'destructive' });
      return;
    }

    if (editingCat) {
      const updated = config.categories.map(c =>
        c.id === editingCat.id ? { ...c, ...formData } : c
      );
      updateCategories(updated);
      addAuditLog({
        action: 'Updated category',
        actor: currentUser.name,
        actorRole: currentUser.role,
        entityType: 'category',
        entityId: editingCat.id,
        changes: { name: { old: editingCat.name, new: formData.name } },
      });
      toast({ title: 'Category updated' });
    } else {
      const newCat: CategoryConfig = {
        id: `cat-${Date.now()}`,
        name: formData.name,
        code: formData.code.toLowerCase().replace(/\s+/g, '-'),
        description: formData.description,
        isActive: formData.isActive,
        order: config.categories.length + 1,
      };
      updateCategories([...config.categories, newCat]);
      addAuditLog({
        action: 'Created category',
        actor: currentUser.name,
        actorRole: currentUser.role,
        entityType: 'category',
        entityId: newCat.id,
        changes: { name: { old: null, new: formData.name } },
      });
      toast({ title: 'Category created' });
    }
    setIsDialogOpen(false);
  };

  const handleDelete = (cat: CategoryConfig) => {
    updateCategories(config.categories.filter(c => c.id !== cat.id));
    addAuditLog({
      action: 'Deleted category',
      actor: currentUser.name,
      actorRole: currentUser.role,
      entityType: 'category',
      entityId: cat.id,
      changes: { name: { old: cat.name, new: null } },
    });
    toast({ title: 'Category deleted' });
  };

  const handleToggleActive = (cat: CategoryConfig) => {
    const updated = config.categories.map(c =>
      c.id === cat.id ? { ...c, isActive: !c.isActive } : c
    );
    updateCategories(updated);
    addAuditLog({
      action: `${cat.isActive ? 'Disabled' : 'Enabled'} category`,
      actor: currentUser.name,
      actorRole: currentUser.role,
      entityType: 'category',
      entityId: cat.id,
      changes: { isActive: { old: cat.isActive, new: !cat.isActive } },
    });
  };

  const sortedCategories = [...config.categories].sort((a, b) => a.order - b.order);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Categories</CardTitle>
          <CardDescription>Manage feedback categories and their display order</CardDescription>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()}>
              <Plus className="h-4 w-4 mr-2" />
              Add Category
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingCat ? 'Edit Category' : 'Add Category'}</DialogTitle>
              <DialogDescription>
                {editingCat ? 'Update category details' : 'Create a new feedback category'}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., Safety Concern"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="code">Code</Label>
                <Input
                  id="code"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                  placeholder="e.g., safety-concern"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Brief description of this category"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="active"
                  checked={formData.isActive}
                  onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                />
                <Label htmlFor="active">Active</Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleSave}>Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12"></TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Code</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedCategories.map((cat) => (
              <TableRow key={cat.id}>
                <TableCell>
                  <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
                </TableCell>
                <TableCell className="font-medium">{cat.name}</TableCell>
                <TableCell>
                  <Badge variant="outline">{cat.code}</Badge>
                </TableCell>
                <TableCell className="max-w-xs truncate text-muted-foreground">
                  {cat.description}
                </TableCell>
                <TableCell>
                  <Switch
                    checked={cat.isActive}
                    onCheckedChange={() => handleToggleActive(cat)}
                  />
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(cat)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(cat)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
