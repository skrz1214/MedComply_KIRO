import { useState } from 'react';
import { useAdminConfig } from '@/contexts/AdminConfigContext';
import { useUser } from '@/contexts/UserContext';
import { PriorityConfig } from '@/types/admin';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export function PrioritiesTab() {
  const { config, updatePriorities, addAuditLog } = useAdminConfig();
  const { currentUser } = useUser();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingPri, setEditingPri] = useState<PriorityConfig | null>(null);
  const [formData, setFormData] = useState({ name: '', code: '', dueDays: 7, color: '#6b7280', isActive: true });

  const handleOpenDialog = (pri?: PriorityConfig) => {
    if (pri) {
      setEditingPri(pri);
      setFormData({ name: pri.name, code: pri.code, dueDays: pri.dueDays, color: pri.color, isActive: pri.isActive });
    } else {
      setEditingPri(null);
      setFormData({ name: '', code: '', dueDays: 7, color: '#6b7280', isActive: true });
    }
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.name || !formData.code) {
      toast({ title: 'Error', description: 'Name and code are required', variant: 'destructive' });
      return;
    }

    if (editingPri) {
      const updated = config.priorities.map(p =>
        p.id === editingPri.id ? { ...p, ...formData } : p
      );
      updatePriorities(updated);
      addAuditLog({
        action: 'Updated priority',
        actor: currentUser.name,
        actorRole: currentUser.role,
        entityType: 'priority',
        entityId: editingPri.id,
        changes: { dueDays: { old: editingPri.dueDays, new: formData.dueDays } },
      });
      toast({ title: 'Priority updated' });
    } else {
      const newPri: PriorityConfig = {
        id: `pri-${Date.now()}`,
        name: formData.name,
        code: formData.code.toLowerCase(),
        dueDays: formData.dueDays,
        color: formData.color,
        isActive: formData.isActive,
        order: config.priorities.length + 1,
      };
      updatePriorities([...config.priorities, newPri]);
      addAuditLog({
        action: 'Created priority',
        actor: currentUser.name,
        actorRole: currentUser.role,
        entityType: 'priority',
        entityId: newPri.id,
        changes: { name: { old: null, new: formData.name } },
      });
      toast({ title: 'Priority created' });
    }
    setIsDialogOpen(false);
  };

  const handleDelete = (pri: PriorityConfig) => {
    updatePriorities(config.priorities.filter(p => p.id !== pri.id));
    addAuditLog({
      action: 'Deleted priority',
      actor: currentUser.name,
      actorRole: currentUser.role,
      entityType: 'priority',
      entityId: pri.id,
      changes: { name: { old: pri.name, new: null } },
    });
    toast({ title: 'Priority deleted' });
  };

  const sortedPriorities = [...config.priorities].sort((a, b) => a.order - b.order);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Priorities</CardTitle>
          <CardDescription>Configure priority levels and default due days</CardDescription>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()}>
              <Plus className="h-4 w-4 mr-2" />
              Add Priority
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingPri ? 'Edit Priority' : 'Add Priority'}</DialogTitle>
              <DialogDescription>
                {editingPri ? 'Update priority configuration' : 'Create a new priority level'}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., High"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="code">Code</Label>
                <Input
                  id="code"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                  placeholder="e.g., high"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dueDays">Default Due Days</Label>
                <Input
                  id="dueDays"
                  type="number"
                  min={1}
                  value={formData.dueDays}
                  onChange={(e) => setFormData({ ...formData, dueDays: parseInt(e.target.value) || 1 })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="color">Color</Label>
                <div className="flex gap-2">
                  <Input
                    id="color"
                    type="color"
                    value={formData.color}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                    className="w-16 h-10 p-1"
                  />
                  <Input
                    value={formData.color}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                    placeholder="#6b7280"
                  />
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="active"
                  checked={formData.isActive}
                  onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                />
                <Label htmlFor="active">Active</Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleSave}>Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Priority</TableHead>
              <TableHead>Code</TableHead>
              <TableHead>Due Days</TableHead>
              <TableHead>Color</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedPriorities.map((pri) => (
              <TableRow key={pri.id}>
                <TableCell className="font-medium">{pri.name}</TableCell>
                <TableCell>
                  <Badge variant="outline">{pri.code}</Badge>
                </TableCell>
                <TableCell>{pri.dueDays} days</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div
                      className="w-6 h-6 rounded border"
                      style={{ backgroundColor: pri.color }}
                    />
                    <span className="text-xs text-muted-foreground">{pri.color}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Switch checked={pri.isActive} disabled />
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(pri)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(pri)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
