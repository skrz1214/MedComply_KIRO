import { useState } from 'react';
import { useAdminConfig } from '@/contexts/AdminConfigContext';
import { useUser } from '@/contexts/UserContext';
import { RoutingRule, RoutingCondition } from '@/types/admin';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Pencil, Trash2, GripVertical, Play, X, CheckCircle2, AlertCircle } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export function RoutingRulesTab() {
  const { config, updateRoutingRules, addAuditLog } = useAdminConfig();
  const { currentUser } = useUser();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isTestDialogOpen, setIsTestDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<RoutingRule | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    conditions: [] as RoutingCondition[],
    assignTo: '',
    setDueDays: '',
    isActive: true,
  });
  const [testData, setTestData] = useState({
    category: '',
    priority: '',
    department: '',
  });
  const [testResult, setTestResult] = useState<{
    matchedRule: RoutingRule | null;
    assignTo: string;
    dueDays: number | null;
  } | null>(null);

  const handleOpenDialog = (rule?: RoutingRule) => {
    if (rule) {
      setEditingRule(rule);
      setFormData({
        name: rule.name,
        description: rule.description || '',
        conditions: [...rule.conditions],
        assignTo: rule.assignTo,
        setDueDays: rule.setDueDays?.toString() || '',
        isActive: rule.isActive,
      });
    } else {
      setEditingRule(null);
      setFormData({
        name: '',
        description: '',
        conditions: [],
        assignTo: '',
        setDueDays: '',
        isActive: true,
      });
    }
    setIsDialogOpen(true);
  };

  const handleAddCondition = () => {
    setFormData({
      ...formData,
      conditions: [...formData.conditions, { field: 'category', operator: 'equals', value: '' }],
    });
  };

  const handleRemoveCondition = (index: number) => {
    setFormData({
      ...formData,
      conditions: formData.conditions.filter((_, i) => i !== index),
    });
  };

  const handleConditionChange = (index: number, field: keyof RoutingCondition, value: string) => {
    const updated = [...formData.conditions];
    updated[index] = { ...updated[index], [field]: value };
    setFormData({ ...formData, conditions: updated });
  };

  const handleSave = () => {
    if (!formData.name || !formData.assignTo) {
      toast({ title: 'Error', description: 'Name and Assign To are required', variant: 'destructive' });
      return;
    }

    const maxOrder = Math.max(...config.routingRules.map(r => r.order), 0);

    if (editingRule) {
      const updated = config.routingRules.map(r =>
        r.id === editingRule.id
          ? {
              ...r,
              name: formData.name,
              description: formData.description,
              conditions: formData.conditions,
              assignTo: formData.assignTo,
              setDueDays: formData.setDueDays ? parseInt(formData.setDueDays) : undefined,
              isActive: formData.isActive,
            }
          : r
      );
      updateRoutingRules(updated);
      addAuditLog({
        action: 'Updated routing rule',
        actor: currentUser.name,
        actorRole: currentUser.role,
        entityType: 'routing_rule',
        entityId: editingRule.id,
        changes: { name: { old: editingRule.name, new: formData.name } },
      });
      toast({ title: 'Rule updated' });
    } else {
      const newRule: RoutingRule = {
        id: `rule-${Date.now()}`,
        name: formData.name,
        description: formData.description,
        conditions: formData.conditions,
        assignTo: formData.assignTo,
        setDueDays: formData.setDueDays ? parseInt(formData.setDueDays) : undefined,
        order: maxOrder + 1,
        isActive: formData.isActive,
      };
      updateRoutingRules([...config.routingRules, newRule]);
      addAuditLog({
        action: 'Created routing rule',
        actor: currentUser.name,
        actorRole: currentUser.role,
        entityType: 'routing_rule',
        entityId: newRule.id,
        changes: { name: { old: null, new: formData.name } },
      });
      toast({ title: 'Rule created' });
    }
    setIsDialogOpen(false);
  };

  const handleDelete = (rule: RoutingRule) => {
    updateRoutingRules(config.routingRules.filter(r => r.id !== rule.id));
    addAuditLog({
      action: 'Deleted routing rule',
      actor: currentUser.name,
      actorRole: currentUser.role,
      entityType: 'routing_rule',
      entityId: rule.id,
      changes: { name: { old: rule.name, new: null } },
    });
    toast({ title: 'Rule deleted' });
  };

  const handleToggleActive = (ruleId: string) => {
    const updated = config.routingRules.map(r =>
      r.id === ruleId ? { ...r, isActive: !r.isActive } : r
    );
    updateRoutingRules(updated);
    toast({ title: 'Rule updated' });
  };

  const evaluateCondition = (condition: RoutingCondition, feedbackData: typeof testData): boolean => {
    const fieldValue = feedbackData[condition.field as keyof typeof feedbackData];
    if (!fieldValue) return false;

    switch (condition.operator) {
      case 'equals':
        return fieldValue.toLowerCase() === (condition.value as string).toLowerCase();
      case 'not_equals':
        return fieldValue.toLowerCase() !== (condition.value as string).toLowerCase();
      case 'in':
        const values = Array.isArray(condition.value) ? condition.value : [condition.value];
        return values.some(v => v.toLowerCase() === fieldValue.toLowerCase());
      default:
        return false;
    }
  };

  const findMatchingRule = (feedbackData: typeof testData): RoutingRule | null => {
    const activeRules = config.routingRules
      .filter(r => r.isActive)
      .sort((a, b) => a.order - b.order);

    for (const rule of activeRules) {
      // Fallback rule (no conditions) matches everything
      if (rule.conditions.length === 0) {
        return rule;
      }

      // All conditions must match
      const allMatch = rule.conditions.every(cond => evaluateCondition(cond, feedbackData));
      if (allMatch) {
        return rule;
      }
    }

    return null;
  };

  const handleTestRules = () => {
    setTestData({ category: '', priority: '', department: '' });
    setTestResult(null);
    setIsTestDialogOpen(true);
  };

  const runTest = () => {
    const matchedRule = findMatchingRule(testData);
    
    if (matchedRule) {
      // Get due days from rule override or priority config
      let dueDays = matchedRule.setDueDays || null;
      if (!dueDays && testData.priority) {
        const priorityConfig = config.priorities.find(p => p.code === testData.priority.toLowerCase());
        dueDays = priorityConfig?.dueDays || null;
      }

      setTestResult({
        matchedRule,
        assignTo: matchedRule.assignTo,
        dueDays,
      });
    } else {
      setTestResult({
        matchedRule: null,
        assignTo: '',
        dueDays: null,
      });
    }
  };

  const sortedRules = [...config.routingRules].sort((a, b) => a.order - b.order);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Routing Rules</CardTitle>
          <CardDescription>
            Define rules for automatic feedback assignment. Rules are evaluated in order (first match wins).
          </CardDescription>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleTestRules}>
            <Play className="h-4 w-4 mr-2" />
            Test Rules
          </Button>
          <Button onClick={() => handleOpenDialog()}>
            <Plus className="h-4 w-4 mr-2" />
            Add Rule
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12">Order</TableHead>
              <TableHead>Rule Name</TableHead>
              <TableHead>Conditions</TableHead>
              <TableHead>Assign To</TableHead>
              <TableHead>Due Days</TableHead>
              <TableHead>Active</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedRules.map((rule) => (
              <TableRow key={rule.id} className={!rule.isActive ? 'opacity-50' : ''}>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
                    <span className="font-mono text-sm">{rule.order}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div>
                    <p className="font-medium">{rule.name}</p>
                    {rule.description && (
                      <p className="text-xs text-muted-foreground">{rule.description}</p>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-1">
                    {rule.conditions.length === 0 ? (
                      <Badge variant="secondary">Fallback (all)</Badge>
                    ) : (
                      rule.conditions.map((cond, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          {cond.field} {cond.operator} {Array.isArray(cond.value) ? cond.value.join(', ') : cond.value}
                        </Badge>
                      ))
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge>{rule.assignTo}</Badge>
                </TableCell>
                <TableCell>
                  {rule.setDueDays ? `${rule.setDueDays} days` : '—'}
                </TableCell>
                <TableCell>
                  <Switch
                    checked={rule.isActive}
                    onCheckedChange={() => handleToggleActive(rule.id)}
                  />
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(rule)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(rule)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <div className="mt-4 p-4 bg-muted/50 rounded-lg">
          <p className="text-sm text-muted-foreground">
            <strong>Note:</strong> A fallback rule is required. Rules with no conditions match all feedback items.
          </p>
        </div>
      </CardContent>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingRule ? 'Edit Routing Rule' : 'Add Routing Rule'}</DialogTitle>
            <DialogDescription>
              {editingRule ? 'Update rule configuration' : 'Create a new routing rule for automatic assignment'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Rule Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., Critical Safety Issues"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="assignTo">Assign To *</Label>
                <Input
                  id="assignTo"
                  value={formData.assignTo}
                  onChange={(e) => setFormData({ ...formData, assignTo: e.target.value })}
                  placeholder="e.g., Dr. James Wilson"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Brief description of when this rule applies"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dueDays">Override Due Days (optional)</Label>
              <Input
                id="dueDays"
                type="number"
                min={1}
                value={formData.setDueDays}
                onChange={(e) => setFormData({ ...formData, setDueDays: e.target.value })}
                placeholder="Leave empty to use priority defaults"
                className="w-40"
              />
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Conditions</Label>
                <Button type="button" variant="outline" size="sm" onClick={handleAddCondition}>
                  <Plus className="h-3 w-3 mr-1" />
                  Add Condition
                </Button>
              </div>
              {formData.conditions.length === 0 ? (
                <p className="text-sm text-muted-foreground p-3 bg-muted/50 rounded">
                  No conditions = Fallback rule (matches all feedback)
                </p>
              ) : (
                <div className="space-y-2">
                  {formData.conditions.map((cond, index) => (
                    <div key={index} className="flex items-center gap-2 p-2 border rounded">
                      <Select
                        value={cond.field}
                        onValueChange={(v) => handleConditionChange(index, 'field', v)}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="category">Category</SelectItem>
                          <SelectItem value="priority">Priority</SelectItem>
                          <SelectItem value="department">Department</SelectItem>
                        </SelectContent>
                      </Select>
                      <Select
                        value={cond.operator}
                        onValueChange={(v) => handleConditionChange(index, 'operator', v)}
                      >
                        <SelectTrigger className="w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="equals">equals</SelectItem>
                          <SelectItem value="not_equals">not equals</SelectItem>
                        </SelectContent>
                      </Select>
                      <Input
                        value={cond.value as string}
                        onChange={(e) => handleConditionChange(index, 'value', e.target.value)}
                        placeholder="Value"
                        className="flex-1"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveCondition(index)}
                      >
                        <X className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="active"
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
              />
              <Label htmlFor="active">Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>Save Rule</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Test Rules Dialog */}
      <Dialog open={isTestDialogOpen} onOpenChange={setIsTestDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Test Routing Rules</DialogTitle>
            <DialogDescription>
              Enter sample feedback data to see which rule would match
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="test-category">Category</Label>
              <Select
                value={testData.category}
                onValueChange={(v) => setTestData({ ...testData, category: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {config.categories.filter(c => c.isActive).map((cat) => (
                    <SelectItem key={cat.id} value={cat.code}>{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="test-priority">Priority</Label>
              <Select
                value={testData.priority}
                onValueChange={(v) => setTestData({ ...testData, priority: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent>
                  {config.priorities.filter(p => p.isActive).map((pri) => (
                    <SelectItem key={pri.id} value={pri.code}>{pri.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="test-department">Department</Label>
              <Select
                value={testData.department}
                onValueChange={(v) => setTestData({ ...testData, department: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {config.departments.filter(d => d.isActive).map((dept) => (
                    <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button onClick={runTest} className="w-full">
              <Play className="h-4 w-4 mr-2" />
              Run Test
            </Button>

            {testResult && (
              <div className={`p-4 rounded-lg border ${testResult.matchedRule ? 'bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800' : 'bg-amber-50 border-amber-200 dark:bg-amber-900/20 dark:border-amber-800'}`}>
                {testResult.matchedRule ? (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-green-700 dark:text-green-300">
                      <CheckCircle2 className="h-5 w-5" />
                      <span className="font-medium">Rule Matched!</span>
                    </div>
                    <div className="text-sm space-y-1">
                      <p><strong>Rule:</strong> {testResult.matchedRule.name}</p>
                      <p><strong>Assign To:</strong> {testResult.assignTo}</p>
                      {testResult.dueDays && (
                        <p><strong>Due in:</strong> {testResult.dueDays} days</p>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-amber-700 dark:text-amber-300">
                    <AlertCircle className="h-5 w-5" />
                    <span className="font-medium">No matching rule found. Add a fallback rule.</span>
                  </div>
                )}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsTestDialogOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
