import { useAdminConfig } from '@/contexts/AdminConfigContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { format } from 'date-fns';
import { UserRole } from '@/types/admin';

const roleBadgeColors: Record<UserRole, string> = {
  'healthcare-staff': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
  'compliance-officer': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
  'department-manager': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
  'administrator': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
};

const roleLabels: Record<UserRole, string> = {
  'healthcare-staff': 'Staff',
  'compliance-officer': 'Compliance',
  'department-manager': 'Manager',
  'administrator': 'Admin',
};

export function AuditLogTab() {
  const { auditLog } = useAdminConfig();

  return (
    <Card>
      <CardHeader>
        <CardTitle>Audit Log</CardTitle>
        <CardDescription>
          Immutable record of all administrative changes. This log cannot be modified or deleted.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Timestamp</TableHead>
              <TableHead>Action</TableHead>
              <TableHead>Actor</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Entity</TableHead>
              <TableHead>Changes</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {auditLog.map((entry) => (
              <TableRow key={entry.id}>
                <TableCell className="text-sm text-muted-foreground whitespace-nowrap">
                  {format(new Date(entry.timestamp), 'MMM d, yyyy HH:mm')}
                </TableCell>
                <TableCell className="font-medium">{entry.action}</TableCell>
                <TableCell>{entry.actor}</TableCell>
                <TableCell>
                  <Badge variant="secondary" className={roleBadgeColors[entry.actorRole]}>
                    {roleLabels[entry.actorRole]}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{entry.entityType}</Badge>
                </TableCell>
                <TableCell className="max-w-xs">
                  <div className="text-xs text-muted-foreground">
                    {Object.entries(entry.changes).map(([key, change]) => (
                      <div key={key}>
                        <span className="font-medium">{key}:</span>{' '}
                        <span className="text-destructive line-through">{String(change.old)}</span>{' '}
                        → <span className="text-primary">{String(change.new)}</span>
                      </div>
                    ))}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        {auditLog.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            No audit log entries yet
          </div>
        )}
      </CardContent>
    </Card>
  );
}
