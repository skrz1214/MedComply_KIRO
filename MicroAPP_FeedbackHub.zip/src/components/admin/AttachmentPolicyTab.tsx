import { useAdminConfig } from '@/contexts/AdminConfigContext';
import { useUser } from '@/contexts/UserContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { toast } from '@/hooks/use-toast';

export function AttachmentPolicyTab() {
  const { config, updateAttachmentPolicy, addAuditLog } = useAdminConfig();
  const { currentUser } = useUser();
  const { attachmentPolicy } = config;

  const handleUpdate = (key: keyof typeof attachmentPolicy, value: unknown) => {
    updateAttachmentPolicy({ ...attachmentPolicy, [key]: value });
    addAuditLog({
      action: `Updated attachment policy: ${key}`,
      actor: currentUser.name,
      actorRole: currentUser.role,
      entityType: 'attachment_policy',
      entityId: 'policy',
      changes: { [key]: { old: attachmentPolicy[key], new: value } },
    });
    toast({ title: 'Policy updated' });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Submission Attachments</CardTitle>
          <CardDescription>Configure file upload limits for initial feedback submission</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="submissionMaxFiles">Maximum Files</Label>
              <Input
                id="submissionMaxFiles"
                type="number"
                min={1}
                max={10}
                value={attachmentPolicy.submissionMaxFiles}
                onChange={(e) => handleUpdate('submissionMaxFiles', parseInt(e.target.value) || 1)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="submissionMaxSize">Maximum Size (MB)</Label>
              <Input
                id="submissionMaxSize"
                type="number"
                min={1}
                max={50}
                value={attachmentPolicy.submissionMaxSizeMB}
                onChange={(e) => handleUpdate('submissionMaxSizeMB', parseInt(e.target.value) || 1)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Note Attachments</CardTitle>
          <CardDescription>Configure file upload limits for notes and comments</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="noteMaxFiles">Maximum Files</Label>
              <Input
                id="noteMaxFiles"
                type="number"
                min={1}
                max={10}
                value={attachmentPolicy.noteMaxFiles}
                onChange={(e) => handleUpdate('noteMaxFiles', parseInt(e.target.value) || 1)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="noteMaxSize">Maximum Size (MB)</Label>
              <Input
                id="noteMaxSize"
                type="number"
                min={1}
                max={50}
                value={attachmentPolicy.noteMaxSizeMB}
                onChange={(e) => handleUpdate('noteMaxSizeMB', parseInt(e.target.value) || 1)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Upload Settings</CardTitle>
          <CardDescription>General file upload configuration</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Enable Drag & Drop</Label>
              <p className="text-sm text-muted-foreground">
                Allow users to drag and drop files for upload
              </p>
            </div>
            <Switch
              checked={attachmentPolicy.enableDragDrop}
              onCheckedChange={(checked) => handleUpdate('enableDragDrop', checked)}
            />
          </div>
          <Separator />
          <div className="space-y-2">
            <Label>Allowed File Types</Label>
            <div className="flex flex-wrap gap-2">
              {attachmentPolicy.allowedFileTypes.map((type, i) => (
                <Badge key={i} variant="secondary">{type}</Badge>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">
              Contact support to modify allowed file types
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
