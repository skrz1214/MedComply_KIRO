import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppSidebar } from '@/components/layout/AppSidebar';
import { Header } from '@/components/layout/Header';
import { DashboardStats } from '@/components/dashboard/DashboardStats';
import { DashboardAnalytics } from '@/components/dashboard/DashboardAnalytics';
import { TaskTabs } from '@/components/dashboard/TaskTabs';
import { ScopeToggle, FeedbackScope } from '@/components/dashboard/ScopeToggle';
import { FeedbackCard } from '@/components/feedback/FeedbackCard';
import { ActivityFeed } from '@/components/feedback/ActivityFeed';
import { NewFeedbackForm, NewFeedbackData } from '@/components/feedback/NewFeedbackForm';
import { FeedbackDetails } from '@/components/feedback/FeedbackDetails';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { mockFeedbacks, mockActivities } from '@/data/mockFeedback';
import { FeedbackItem } from '@/types/feedback';
import { toast } from '@/hooks/use-toast';
import { MessageSquareText, Clock, BarChart3 } from 'lucide-react';
import AdminSettings from '@/pages/AdminSettings';
import Documentation from '@/pages/Documentation';
import { useUser } from '@/contexts/UserContext';

type ViewState = 'dashboard' | 'my-feedbacks' | 'recent-activity' | 'new-feedback' | 'feedback-details' | 'documentation' | 'admin-settings';

export default function FeedbackHub() {
  const navigate = useNavigate();
  const { currentUser } = useUser();
  const [currentView, setCurrentView] = useState<ViewState>('dashboard');
  const [feedbacks, setFeedbacks] = useState<FeedbackItem[]>(mockFeedbacks);
  const [selectedFeedbackId, setSelectedFeedbackId] = useState<string | null>(null);
  const [scope, setScope] = useState<FeedbackScope>('personal');

  // Filter feedbacks based on scope and user role
  const filteredFeedbacks = useMemo(() => {
    const role = currentUser.role;
    
    if (role === 'healthcare-staff') {
      // Staff always sees only their own submissions
      return feedbacks.filter(f => f.submittedBy === currentUser.name || f.assignedTo === currentUser.name);
    }

    if (scope === 'personal') {
      // Personal: feedback submitted by or assigned to current user
      return feedbacks.filter(f => f.submittedBy === currentUser.name || f.assignedTo === currentUser.name);
    }

    if (scope === 'department' && role === 'department-manager') {
      // Department: feedback from user's department
      return feedbacks.filter(f => f.department === currentUser.department);
    }

    if (scope === 'organization' && (role === 'compliance-officer' || role === 'administrator')) {
      // Organization: all feedback
      return feedbacks;
    }

    return feedbacks;
  }, [feedbacks, scope, currentUser]);

  const handleNewFeedback = () => {
    setCurrentView('new-feedback');
  };

  const handleViewChange = (view: string) => {
    setCurrentView(view as ViewState);
    setSelectedFeedbackId(null);
  };

  const handleFeedbackClick = (feedbackId: string) => {
    setSelectedFeedbackId(feedbackId);
    setCurrentView('feedback-details');
  };

  const handleSubmitFeedback = (data: NewFeedbackData) => {
    const newFeedback: FeedbackItem = {
      id: `FB-${String(feedbacks.length + 1).padStart(3, '0')}`,
      title: data.title,
      description: data.description,
      category: data.category,
      priority: data.priority,
      department: data.department,
      dueDate: data.dueDate,
      attachments: data.attachments,
      microappLabels: data.microappLabels,
      microappReferences: data.microappReferences,
      status: 'in-progress',
      submittedBy: 'Current User',
      submittedAt: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
      notes: [],
      history: [
        {
          id: `H-${Date.now()}`,
          action: 'Feedback submitted',
          actor: 'Current User',
          timestamp: new Date().toISOString(),
        }
      ]
    };

    setFeedbacks([newFeedback, ...feedbacks]);
    setCurrentView('dashboard');
    toast({
      title: "Feedback submitted",
      description: `Your feedback has been routed to ${data.department}.`,
    });
  };

  const handleUpdateFeedback = (feedbackId: string, updates: Partial<FeedbackItem>) => {
    setFeedbacks(feedbacks.map(f => 
      f.id === feedbackId 
        ? { ...f, ...updates, lastUpdated: new Date().toISOString() }
        : f
    ));
  };

  const selectedFeedback = feedbacks.find(f => f.id === selectedFeedbackId);

  const renderContent = () => {
    if (currentView === 'admin-settings') {
      return (
        <AdminSettings onBack={() => setCurrentView('dashboard')} />
      );
    }

    if (currentView === 'documentation') {
      return (
        <Documentation onBack={() => setCurrentView('dashboard')} />
      );
    }

    if (currentView === 'new-feedback') {
      return (
        <NewFeedbackForm
          onSubmit={handleSubmitFeedback}
          onCancel={() => setCurrentView('dashboard')}
        />
      );
    }

    if (currentView === 'feedback-details' && selectedFeedback) {
      return (
        <FeedbackDetails
          feedback={selectedFeedback}
          onBack={() => setCurrentView('dashboard')}
          onUpdate={handleUpdateFeedback}
        />
      );
    }

    if (currentView === 'my-feedbacks') {
      return (
        <div className="space-y-6 animate-fade-in">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">My Feedbacks</h1>
              <p className="text-muted-foreground mt-1">
                View all feedbacks you've submitted, been assigned, or worked on
              </p>
            </div>
            <ScopeToggle scope={scope} onScopeChange={setScope} />
          </div>

          {filteredFeedbacks.length > 0 ? (
            <div className="grid gap-4">
              {filteredFeedbacks.map((feedback, index) => (
                <div 
                  key={feedback.id}
                  className="animate-slide-up"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <FeedbackCard
                    feedback={feedback}
                    onClick={() => handleFeedbackClick(feedback.id)}
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <MessageSquareText className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-lg text-muted-foreground">No feedbacks yet</p>
              <p className="text-sm text-muted-foreground/70 mt-1">
                Feedbacks you create or are assigned to will appear here
              </p>
            </div>
          )}
        </div>
      );
    }

    if (currentView === 'recent-activity') {
      return (
        <div className="space-y-6 animate-fade-in">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Recent Activity</h1>
            <p className="text-muted-foreground mt-1">
              Chronological view of all feedback actions across your engagements
            </p>
          </div>

          <Card className="shadow-card">
            <CardContent className="p-0">
              {mockActivities.length > 0 ? (
                <ActivityFeed 
                  activities={mockActivities}
                  onActivityClick={handleFeedbackClick}
                />
              ) : (
                <div className="text-center py-16">
                  <Clock className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
                  <p className="text-lg text-muted-foreground">No recent activity</p>
                  <p className="text-sm text-muted-foreground/70 mt-1">
                    Your feedback activity will be tracked here
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      );
    }

    // Default: Dashboard
    return (
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Welcome back!</h1>
            <p className="text-muted-foreground mt-1">
              Here's an overview of your compliance feedback tasks
            </p>
          </div>
          <ScopeToggle scope={scope} onScopeChange={setScope} />
        </div>

        {/* Success Metrics */}
        <div>
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2 mb-3">
            <BarChart3 className="h-5 w-5 text-primary" />
            Success Metrics
          </h2>
          <DashboardAnalytics feedbacks={filteredFeedbacks} />
        </div>

        <DashboardStats feedbacks={filteredFeedbacks} />

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="xl:col-span-2">
            <Card className="shadow-card">
              <CardHeader className="pb-4">
                <CardTitle>Your Tasks</CardTitle>
              </CardHeader>
              <CardContent>
                <TaskTabs 
                  feedbacks={filteredFeedbacks}
                  onFeedbackClick={handleFeedbackClick}
                />
              </CardContent>
            </Card>
          </div>

          <div>
            <Card className="shadow-card h-fit">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ActivityFeed 
                  activities={mockActivities.slice(0, 5)}
                  onActivityClick={handleFeedbackClick}
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen flex w-full bg-background">
      <AppSidebar currentView={currentView} onViewChange={handleViewChange} onNewFeedback={handleNewFeedback} />
      
      <div className="flex-1 flex flex-col min-w-0">
        <Header onNewFeedback={handleNewFeedback} />
        
        <main className="flex-1 p-6 overflow-auto">
          <div className="max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
}
