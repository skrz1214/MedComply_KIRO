import { useState } from 'react';
import { useAdminConfig } from '@/contexts/AdminConfigContext';
import { useUser } from '@/contexts/UserContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Settings, Building2, Tags, AlertTriangle, GitBranch, Workflow, Paperclip, Activity, ScrollText, Shield, Target } from 'lucide-react';
import { DepartmentsTab } from '@/components/admin/DepartmentsTab';
import { CategoriesTab } from '@/components/admin/CategoriesTab';
import { PrioritiesTab } from '@/components/admin/PrioritiesTab';
import { RoutingRulesTab } from '@/components/admin/RoutingRulesTab';
import { WorkflowPolicyTab } from '@/components/admin/WorkflowPolicyTab';
import { AttachmentPolicyTab } from '@/components/admin/AttachmentPolicyTab';
import { ActivityFeedPolicyTab } from '@/components/admin/ActivityFeedPolicyTab';
import { AuditLogTab } from '@/components/admin/AuditLogTab';
import { MetricsThresholdsTab } from '@/components/admin/MetricsThresholdsTab';

interface AdminSettingsProps {
  onBack: () => void;
}

export default function AdminSettings({ onBack }: AdminSettingsProps) {
  const { hasPermission } = useUser();
  const [activeTab, setActiveTab] = useState('general');

  if (!hasPermission('access_admin')) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center">
        <Shield className="h-16 w-16 text-muted-foreground/30 mb-4" />
        <h2 className="text-xl font-semibold text-foreground mb-2">Access Denied</h2>
        <p className="text-muted-foreground mb-4">You do not have permission to access Admin Settings.</p>
        <Button onClick={onBack} variant="outline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Go Back
        </Button>
      </div>
    );
  }

  const tabs = [
    { id: 'general', label: 'General', icon: Settings },
    { id: 'departments', label: 'Departments', icon: Building2 },
    { id: 'categories', label: 'Categories', icon: Tags },
    { id: 'priorities', label: 'Priorities', icon: AlertTriangle },
    { id: 'routing', label: 'Routing Rules', icon: GitBranch },
    { id: 'workflow', label: 'Workflow Policy', icon: Workflow },
    { id: 'attachments', label: 'Attachments', icon: Paperclip },
    { id: 'activity', label: 'Activity Feed', icon: Activity },
    { id: 'metrics', label: 'Metrics', icon: Target },
    { id: 'audit', label: 'Audit Log', icon: ScrollText },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-4">
        <Button onClick={onBack} variant="ghost" size="icon">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Admin Settings</h1>
          <p className="text-muted-foreground mt-1">
            Configure FeedbackHub settings, routing rules, and policies
          </p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="flex flex-wrap h-auto gap-1 bg-muted/50 p-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <TabsTrigger
                key={tab.id}
                value={tab.id}
                className="flex items-center gap-2 data-[state=active]:bg-background"
              >
                <Icon className="h-4 w-4" />
                <span className="hidden sm:inline">{tab.label}</span>
              </TabsTrigger>
            );
          })}
        </TabsList>

        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>
                Overview of your FeedbackHub configuration
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <Card className="border-dashed">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Building2 className="h-4 w-4 text-primary" />
                      Departments
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold">7</p>
                    <p className="text-xs text-muted-foreground">Active departments</p>
                  </CardContent>
                </Card>
                <Card className="border-dashed">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Tags className="h-4 w-4 text-primary" />
                      Categories
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold">6</p>
                    <p className="text-xs text-muted-foreground">Feedback categories</p>
                  </CardContent>
                </Card>
                <Card className="border-dashed">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <GitBranch className="h-4 w-4 text-primary" />
                      Routing Rules
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold">3</p>
                    <p className="text-xs text-muted-foreground">Active rules</p>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="departments">
          <DepartmentsTab />
        </TabsContent>

        <TabsContent value="categories">
          <CategoriesTab />
        </TabsContent>

        <TabsContent value="priorities">
          <PrioritiesTab />
        </TabsContent>

        <TabsContent value="routing">
          <RoutingRulesTab />
        </TabsContent>

        <TabsContent value="workflow">
          <WorkflowPolicyTab />
        </TabsContent>

        <TabsContent value="attachments">
          <AttachmentPolicyTab />
        </TabsContent>

        <TabsContent value="activity">
          <ActivityFeedPolicyTab />
        </TabsContent>

        <TabsContent value="metrics">
          <MetricsThresholdsTab />
        </TabsContent>

        <TabsContent value="audit">
          <AuditLogTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
