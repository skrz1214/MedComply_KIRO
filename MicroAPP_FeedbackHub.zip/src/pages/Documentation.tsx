import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Download, FileText, Terminal, ClipboardCheck, UserCheck } from 'lucide-react';

interface DocumentationProps {
  onBack?: () => void;
}

const systemPromptContent = `# FeedbackHub System Prompt

## System Overview

You are FeedbackHub, an intelligent compliance feedback management assistant for healthcare organizations. Your role is to help healthcare staff, department managers, compliance officers, and administrators manage, track, and resolve compliance-related feedback efficiently.

## Core Capabilities

### 1. Feedback Management
- Accept and categorize compliance feedback submissions
- Route feedback to appropriate departments based on category and content
- Track feedback status through the workflow: Pending → In Progress → Review → Resolved/Rejected
- Manage priority levels: Critical, High, Medium, Low

### 2. Role-Based Interactions

#### Healthcare Staff
- Submit new compliance feedback
- View personal submissions and assigned feedback
- Add notes and attachments to feedback items
- Track status of submitted feedback

#### Department Manager
- All Healthcare Staff capabilities
- View department-wide feedback (scope toggle: Personal/Department)
- Assign feedback to team members
- Update feedback status and priority
- Approve or escalate feedback items

#### Compliance Officer
- All Department Manager capabilities
- Organization-wide visibility (scope toggle: Personal/Organization)
- Access to analytics and metrics
- Generate compliance reports
- Configure workflow policies

#### Administrator
- Full system access
- Configure categories, priorities, and routing rules
- Manage department settings
- Access audit logs
- Set metrics thresholds and policies

### 3. Feedback Categories
- HIPAA Compliance
- Patient Safety
- Quality of Care
- Staff Training
- Documentation
- Equipment/Facility
- Policy Violation
- Process Improvement
- Other

### 4. Department Routing
- Nursing Department
- Pharmacy
- Laboratory
- Radiology
- Emergency Department
- Administration
- IT Department
- Facilities Management
- Human Resources

## Workflow Rules

### Status Transitions
1. **Pending** → In Progress (when assigned or work begins)
2. **In Progress** → Review (when ready for manager review)
3. **Review** → Resolved (when approved)
4. **Review** → In Progress (when changes needed)
5. Any status → Rejected (with justification)

### Priority Escalation
- Critical: Immediate attention, SLA < 4 hours
- High: Same day response, SLA < 24 hours
- Medium: Within 3 days, SLA < 72 hours
- Low: Within 1 week, SLA < 168 hours

### Overdue Handling
- Feedback items past due date are flagged as overdue
- Notifications sent at 75% and 100% of SLA time
- Escalation to next management level at 150% SLA

## Response Guidelines

### Tone & Style
- Professional and empathetic
- Clear and concise
- Action-oriented
- HIPAA-compliant (never expose PHI)

### When Receiving Feedback
1. Acknowledge the submission
2. Confirm category and priority
3. Identify appropriate department
4. Set realistic due date based on priority
5. Provide tracking reference (FB-XXX)

### When Providing Updates
1. Summarize current status
2. List recent actions taken
3. Identify next steps
4. Provide estimated completion time
5. Offer escalation options if delayed

## Integration Points

### Cross-Microapp Labels
- Link to related MedComply microapps
- Reference training modules, policies, incidents
- Enable cross-functional visibility

### Attachments
- Support for documents, images
- Size limits per admin configuration
- Allowed file types per policy

### Activity Feed
- Real-time updates on feedback actions
- Configurable visibility per role
- Audit trail for compliance

## Success Metrics

### Key Performance Indicators
- Average Resolution Time: Target < 72 hours
- First Response Time: Target < 4 hours
- Overdue Rate: Target < 5%
- User Satisfaction: Target > 90%

### Analytics Dashboard
- Status distribution charts
- Weekly trend analysis
- Department performance comparison
- Priority breakdown

## Error Handling

### Invalid Submissions
- Guide users to complete required fields
- Suggest appropriate categories
- Validate file attachments

### Access Denied
- Explain permission requirements
- Suggest appropriate contact
- Log attempt for audit

### System Errors
- Provide user-friendly message
- Log technical details
- Offer retry or alternative actions

---

Version: 1.3
Last Updated: December 2025
`;

const prdContent = `# Product Requirements Document: FeedbackHub

## Version 1.3 | December 2025

## 1. Overview

FeedbackHub is a compliance feedback management microapp within the MedComply healthcare platform. It enables healthcare staff to submit, track, and resolve compliance-related feedback through an intuitive, role-based interface.

## 2. Problem Statement

Healthcare organizations need a centralized system to collect, route, and track compliance feedback from staff. Current manual processes lead to delayed responses, lost feedback, and inadequate audit trails.

## 3. Target Users

- **Healthcare Staff**: Submit feedback, track status
- **Department Managers**: Manage department feedback, assign tasks
- **Compliance Officers**: Organization-wide oversight, analytics
- **Administrators**: System configuration, policy management

## 4. Core Features

### 4.1 Feedback Submission
- Multi-category selection
- Priority assignment
- Department routing
- File attachments
- Cross-microapp labels

### 4.2 Task Management Dashboard
- Role-based visibility
- Scope toggle (Personal/Department/Organization)
- Status-based task tabs
- Overdue indicators

### 4.3 Workflow Management
- Status transitions with validation
- Assignment tracking
- History and audit trail
- Note attachments

### 4.4 Analytics & Metrics
- Resolution time tracking
- Status distribution
- Weekly trends
- Department performance

## 5. Technical Requirements

- React with TypeScript
- Tailwind CSS for styling
- Role-based access control
- Real-time updates
- Mobile responsive

## 6. Success Metrics

- Average Resolution Time < 72 hours
- First Response Time < 4 hours
- Overdue Rate < 5%
- User Satisfaction > 90%

## 7. Future Enhancements

- Email notifications
- Mobile app
- AI-powered categorization
- Integration with external systems
`;

const qaTestPlanContent = `# FeedbackHub QA Test Plan

## Version 1.3 | December 2025

## 1. Test Environment & Setup

### 1.1 Prerequisites
- Application running with seeded mock data (mockFeedback dataset)
- All four roles available via Role Switcher: Healthcare Staff, Department Manager, Compliance Officer, Administrator
- Browser: latest Chrome, Edge, Firefox, Safari
- Viewport coverage: 1440px (desktop), 1024px (laptop), 768px (tablet), 375px (mobile)

### 1.2 Test Data
- At least 10 feedback items spanning all statuses, priorities, and departments
- At least 1 overdue item, 1 critical item, 1 resolved item, 1 rejected item
- Items submitted/assigned to the current user for "Personal" scope validation

### 1.3 Defect Severity Definitions
| Severity | Definition |
|----------|------------|
| S1 - Critical | Blocks core workflow; data loss; security exposure |
| S2 - High | Major feature broken; no workaround |
| S3 - Medium | Feature broken with workaround |
| S4 - Low | Cosmetic, copy, minor UX |

---

## 2. Functional Test Cases

### 2.1 Feedback Submission

**TC-FS-001 — Submit valid feedback (happy path)** — P1
- Pre: Logged in as Healthcare Staff
- Steps: Click "New Feedback" → fill title, description, category, priority, department, due date → Submit
- Expected: Toast confirmation; new item appears at top of dashboard; routed to selected department; status = In Progress

**TC-FS-002 — Required field validation** — P1
- Steps: Open form → Submit empty
- Expected: Inline errors on all required fields; form not submitted

**TC-FS-003 — Attachment upload within limits** — P2
- Steps: Attach file under admin-configured size limit and allowed type
- Expected: File chip appears; download icon works

**TC-FS-004 — Attachment rejected when over limit / wrong type** — P2
- Expected: Error message reflects admin policy; file not attached

**TC-FS-005 — Microapp labels and references** — P2
- Steps: Add 1+ microapp labels and 1+ microapp references
- Expected: Labels and references render on the feedback card and details view

**TC-FS-006 — Due date in the past** — P3
- Expected: Form validation prevents submission or warns the user

### 2.2 Dashboard & Scope Toggle

**TC-DS-001 — Healthcare Staff sees no scope toggle** — P1
- Expected: ScopeToggle hidden; list scoped to items submitted by or assigned to user

**TC-DS-002 — Department Manager toggle (Personal/Department)** — P1
- Steps: Switch to Department Manager → toggle Personal, then Department
- Expected: Personal = own submissions/assignments; Department = all items where department matches user.department

**TC-DS-003 — Compliance Officer toggle (Personal/Organization)** — P1
- Expected: Personal scope works; Organization scope shows all items regardless of department

**TC-DS-004 — Administrator toggle (Personal/Organization)** — P1
- Expected: Same as Compliance Officer

**TC-DS-005 — Scope toggle filters Success Metrics, Stats, and Task tabs** — P1
- Expected: All dashboard widgets (DashboardAnalytics, DashboardStats, TaskTabs) recompute with the filtered set

**TC-DS-006 — Scope toggle on My Feedbacks page** — P2
- Expected: Same filtering behavior as dashboard

### 2.3 Task Tabs

**TC-TT-001 — To Do tab** — P1
- Expected: Items with status Pending or In Progress assigned to or owned by viewing scope

**TC-TT-002 — To Review tab** — P1
- Expected: Items with status Review

**TC-TT-003 — Overdue tab** — P1
- Expected: Items with dueDate < today AND status not in [Resolved, Rejected]

**TC-TT-004 — Resolved tab** — P2

**TC-TT-005 — Closed tab** — P2
- Expected: Resolved + Rejected combined per filter definition

**TC-TT-006 — Tab counts match list contents** — P2

### 2.4 Feedback Details

**TC-FD-001 — Status transition Pending → In Progress** — P1
**TC-FD-002 — Status transition In Progress → Review** — P1
**TC-FD-003 — Status transition Review → Resolved** — P1
**TC-FD-004 — Status transition Review → In Progress (rework)** — P2
**TC-FD-005 — Rejection requires justification note** — P2
**TC-FD-006 — Reassign to another user** — P2
- Expected: History entry recorded; assignedTo updated

**TC-FD-007 — Priority change recorded in history** — P2
**TC-FD-008 — Add note** — P2
- Expected: Note appears in feed with author, timestamp
**TC-FD-009 — lastUpdated refreshes on any change** — P3

### 2.5 Admin Settings

**TC-AS-001 — Departments CRUD** — P1
**TC-AS-002 — Categories CRUD** — P1
**TC-AS-003 — Priorities CRUD with SLA hours** — P1
**TC-AS-004 — Routing Rules: create rule matching category/priority → department** — P1
**TC-AS-005 — Routing Rules: "Test Rules" panel** — P2
- Steps: Enter sample inputs in test panel → run
- Expected: Engine returns matched rule and resulting department

**TC-AS-006 — Workflow Policy: required-fields and transitions** — P2
**TC-AS-007 — Attachment Policy: size + types enforced on submission** — P2
**TC-AS-008 — Activity Feed Policy: visibility per role** — P2
**TC-AS-009 — Metrics Thresholds: edit Resolution / First Response / Overdue / Satisfaction** — P1
- Expected: Saved values drive color coding in DashboardAnalytics (good/warn/bad)

**TC-AS-010 — Audit Log records admin config changes** — P2

### 2.6 Role-Based Access

**TC-RBA-001 — Healthcare Staff cannot open Admin Settings** — P1
**TC-RBA-002 — Department Manager scoped to own department in Department mode** — P1
**TC-RBA-003 — Compliance Officer / Administrator can see Organization scope** — P1
**TC-RBA-004 — Role Switcher updates sidebar, scope toggle, and admin entry visibility** — P2

---

## 3. Cross-Microapp Integration

**TC-CMI-001 — Microapp label badge renders correct color and icon** — P3
**TC-CMI-002 — Microapp reference links display in details view** — P3
**TC-CMI-003 — Removing a label from a feedback updates the card** — P3

---

## 4. Analytics & Metrics

**TC-AN-001 — Status distribution chart sums to filtered total** — P2
**TC-AN-002 — Weekly trend chart shows the configured number of weeks** — P2
**TC-AN-003 — Trend chart tooltips and axis labels are descriptive** — P3
**TC-AN-004 — Threshold breach turns metric card warn/bad color** — P2
**TC-AN-005 — Metrics recompute when scope toggle changes** — P1

---

## 5. Negative & Edge Cases

**TC-NEG-001 — Submit feedback while offline (network failure)** — P2
**TC-NEG-002 — Extremely long title/description (boundary)** — P3
**TC-NEG-003 — Unicode and emoji in inputs** — P3
**TC-NEG-004 — Concurrent status updates by two roles** — P2
**TC-NEG-005 — Direct route to admin settings as Healthcare Staff** — P1
**TC-NEG-006 — Switching role mid-action preserves data integrity** — P2

---

## 6. Regression Checklist (run before each release)

- [ ] Submit feedback as each role
- [ ] Scope toggle behaves per role matrix
- [ ] All status transitions
- [ ] Admin CRUD on all configuration tabs
- [ ] Metrics thresholds editable and reflected in dashboard
- [ ] Audit log captures admin changes
- [ ] Documentation tab downloads all four documents (PRD, System Prompt, QA, UAT)
- [ ] Responsive layout at 375 / 768 / 1024 / 1440
- [ ] No console errors on any primary route

---

Version: 1.3
Last Updated: December 2025
`;

const uatTestPlanContent = `# FeedbackHub User Acceptance Test (UAT) Plan

## Version 1.3 | December 2025

## 1. UAT Overview

### 1.1 Purpose
Confirm that FeedbackHub meets the business needs of healthcare staff, department managers, compliance officers, and administrators for capturing, routing, and resolving compliance feedback.

### 1.2 Objectives
- Validate end-to-end compliance feedback workflows
- Confirm role-appropriate visibility and permissions
- Verify analytics support compliance reporting needs
- Ensure admin configuration supports policy and process changes without code

### 1.3 Participants
- 2+ Healthcare Staff representatives
- 1+ Department Manager per participating department
- 1+ Compliance Officer
- 1 Administrator

### 1.4 Sign-off Criteria
- 100% of P1 scenarios pass
- ≥ 95% of P2 scenarios pass
- No open S1/S2 defects
- All participating roles formally accept

---

## 2. Acceptance Scenarios

### 2.1 Healthcare Staff

**UAT-HS-01 — Submit a HIPAA concern** — P1
- Context: Staff member observes a possible HIPAA breach
- Steps: Log in → New Feedback → category HIPAA, priority High, attach photo of redacted note → submit
- Expected: Confirmation with tracking ID; item visible in "My Feedbacks"

**UAT-HS-02 — Track personal feedback** — P1
- Steps: Open My Feedbacks → filter by status
- Expected: Only items submitted by or assigned to the user are visible

**UAT-HS-03 — Add a follow-up note** — P2
- Expected: Note saved and visible to assigned reviewer

**UAT-HS-04 — Cannot access Admin Settings** — P1
- Expected: Admin entry is hidden / inaccessible

### 2.2 Department Manager

**UAT-DM-01 — Triage department backlog** — P1
- Steps: Switch scope to Department → review To Do tab → assign 3 items to team members
- Expected: Assignments persist; items show in assignees' personal views

**UAT-DM-02 — Move item from In Progress to Review** — P1

**UAT-DM-03 — Toggle Personal vs Department scope** — P1
- Expected: List recomputes immediately and matches expectations

**UAT-DM-04 — Department-scoped analytics** — P2
- Expected: Success Metrics reflect department subset only

### 2.3 Compliance Officer

**UAT-CO-01 — Organization-wide overview** — P1
- Steps: Set scope to Organization → review dashboard
- Expected: All departments represented; metric cards reflect org totals

**UAT-CO-02 — Resolve a Review item** — P1

**UAT-CO-03 — Reject with justification** — P2

**UAT-CO-04 — Identify overdue critical items** — P1
- Expected: Overdue tab surfaces them; trend chart shows escalation pattern

**UAT-CO-05 — Use weekly trend chart for reporting** — P2
- Expected: Chart legend, axes, and tooltips are self-explanatory and exportable in screenshot

### 2.4 Administrator

**UAT-AD-01 — Add a new department and routing rule** — P1
- Expected: New department appears in submission form; routing rule sends matching new feedback to it

**UAT-AD-02 — Edit Metrics Thresholds** — P1
- Steps: Lower Overdue threshold from 5% to 2% → save
- Expected: Overdue metric card color updates immediately on dashboard

**UAT-AD-03 — Update Attachment Policy** — P2
- Expected: New restrictions enforced on next submission

**UAT-AD-04 — Configure Workflow Policy required fields** — P2

**UAT-AD-05 — Review Audit Log** — P2
- Expected: All admin changes from prior scenarios listed with actor and timestamp

---

## 3. End-to-End Workflow Scenarios

**UAT-E2E-01 — Full lifecycle: submission to resolution**
- Staff submits Patient Safety feedback (P1) → Department Manager assigns it → assignee moves to In Progress → assignee moves to Review → Compliance Officer resolves
- Expected: History records every step; metrics reflect resolution time

**UAT-E2E-02 — Escalation of overdue critical item**
- Administrator sets aggressive SLA → staff submits Critical item → due date passes without resolution
- Expected: Item flagged Overdue; appears in Overdue tab for relevant roles

**UAT-E2E-03 — Policy change applied mid-flight**
- Administrator updates routing rule → new submissions matching the rule route to the new department; existing items unchanged

**UAT-E2E-04 — Cross-microapp linkage**
- Staff submits with a Policy microapp reference → reviewer opens reference from details view

---

## 4. Test Execution Log Template

| Scenario ID | Tester | Role | Date | Result (Pass/Fail) | Defect ID | Notes |
|-------------|--------|------|------|--------------------|-----------|-------|
| UAT-HS-01   |        |      |      |                    |           |       |
| UAT-DM-01   |        |      |      |                    |           |       |
| UAT-CO-01   |        |      |      |                    |           |       |
| UAT-AD-01   |        |      |      |                    |           |       |

---

## 5. Issue Reporting Template

- **Issue ID:**
- **Scenario ID:**
- **Reported by / Role:**
- **Date:**
- **Severity:** S1 / S2 / S3 / S4
- **Summary:**
- **Steps to reproduce:**
- **Expected result:**
- **Actual result:**
- **Screenshots / attachments:**
- **Workaround (if any):**

---

## 6. Sign-off

| Role | Name | Decision (Accept / Reject) | Date | Signature |
|------|------|----------------------------|------|-----------|
| Healthcare Staff Rep | | | | |
| Department Manager   | | | | |
| Compliance Officer   | | | | |
| Administrator        | | | | |
| Product Owner        | | | | |

---

Version: 1.3
Last Updated: December 2025
`;

type DocKey = 'prd' | 'system-prompt' | 'qa' | 'uat';

interface DocEntry {
  key: DocKey;
  label: string;
  icon: typeof FileText;
  title: string;
  description: string;
  filename: string;
  content: string;
}

const docs: DocEntry[] = [
  {
    key: 'prd',
    label: 'PRD Document',
    icon: FileText,
    title: 'Product Requirements Document',
    description: 'Complete PRD for FeedbackHub microapp - Version 1.3',
    filename: 'FeedbackHub-PRD.md',
    content: prdContent,
  },
  {
    key: 'system-prompt',
    label: 'System Prompt',
    icon: Terminal,
    title: 'System Prompt',
    description: 'AI assistant configuration and behavioral guidelines',
    filename: 'FeedbackHub-SystemPrompt.md',
    content: systemPromptContent,
  },
  {
    key: 'qa',
    label: 'QA Test Plan',
    icon: ClipboardCheck,
    title: 'QA Test Plan',
    description: 'Functional, negative, and regression test cases for QA engineers',
    filename: 'FeedbackHub-QA-TestPlan.md',
    content: qaTestPlanContent,
  },
  {
    key: 'uat',
    label: 'UAT Test Plan',
    icon: UserCheck,
    title: 'UAT Test Plan',
    description: 'Business acceptance scenarios, sign-off, and issue reporting templates',
    filename: 'FeedbackHub-UAT-TestPlan.md',
    content: uatTestPlanContent,
  },
];

export default function Documentation({ onBack }: DocumentationProps) {
  const [activeTab, setActiveTab] = useState<DocKey>('prd');

  const downloadDocument = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto p-8">
        {onBack && (
          <Button variant="ghost" onClick={onBack} className="mb-6 gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
        )}

        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Documentation</h1>
          <p className="text-muted-foreground mt-2">
            Access and download FeedbackHub documentation
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as DocKey)} className="w-full">
          <TabsList className="mb-6 flex flex-wrap h-auto">
            {docs.map((doc) => {
              const Icon = doc.icon;
              return (
                <TabsTrigger key={doc.key} value={doc.key} className="gap-2">
                  <Icon className="h-4 w-4" />
                  {doc.label}
                </TabsTrigger>
              );
            })}
          </TabsList>

          {docs.map((doc) => {
            const Icon = doc.icon;
            return (
              <TabsContent key={doc.key} value={doc.key}>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Icon className="h-5 w-5 text-primary" />
                        {doc.title}
                      </CardTitle>
                      <CardDescription className="mt-1.5">{doc.description}</CardDescription>
                    </div>
                    <Button
                      onClick={() => downloadDocument(doc.content, doc.filename)}
                      className="gap-2"
                    >
                      <Download className="h-4 w-4" />
                      Download
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <div className="prose prose-slate dark:prose-invert max-w-none">
                      <div className="bg-muted/50 rounded-lg p-6 max-h-[600px] overflow-y-auto">
                        <pre className="whitespace-pre-wrap text-sm font-mono text-foreground">
                          {doc.content}
                        </pre>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            );
          })}
        </Tabs>
      </div>
    </div>
  );
}
