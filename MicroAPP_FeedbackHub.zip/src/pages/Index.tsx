import FeedbackHub from './FeedbackHub';

const Index = () => {
  return <FeedbackHub />;
};

export default Index;
