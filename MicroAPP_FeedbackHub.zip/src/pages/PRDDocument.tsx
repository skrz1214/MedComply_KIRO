import { Button } from "@/components/ui/button";
import { Printer, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const PRDDocument = () => {
  const navigate = useNavigate();

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Print controls - hidden when printing */}
      <div className="print:hidden sticky top-0 z-10 bg-background border-b border-border p-4 flex items-center justify-between">
        <Button variant="ghost" onClick={() => navigate(-1)}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <Button onClick={handlePrint}>
          <Printer className="h-4 w-4 mr-2" />
          Print / Save as PDF
        </Button>
      </div>

      {/* Document content */}
      <div className="max-w-4xl mx-auto p-8 print:p-0 print:max-w-none">
        <article className="prose prose-slate dark:prose-invert max-w-none print:prose-sm">
          <h1 className="text-3xl font-bold mb-2">Product Requirements Document: FeedbackHub</h1>
          <p className="text-muted-foreground mb-8">Version 1.3 | December 15, 2025</p>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold border-b pb-2">Overview</h2>
            <p>
              FeedbackHub is a centralized compliance feedback management system designed for healthcare organizations. 
              It enables staff and compliance teams to submit, track, and resolve compliance-related feedback through a structured workflow.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold border-b pb-2">1. Problem Statement</h2>
            <p>
              Healthcare organizations struggle to efficiently collect, route, and resolve compliance-related feedback from staff. 
              Current processes often rely on fragmented communication channels (email, paper forms, verbal reports), leading to:
            </p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Lost or overlooked compliance concerns</li>
              <li>Inconsistent response times</li>
              <li>Lack of visibility into feedback status</li>
              <li>No audit trail for regulatory compliance</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold border-b pb-2">2. Target Users</h2>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-3 text-left font-semibold">User Role</th>
                    <th className="border border-border p-3 text-left font-semibold">Description</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-border p-3 font-medium">Healthcare Staff</td>
                    <td className="border border-border p-3">Submit compliance feedback, track their submissions (Read-only access)</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3 font-medium">Compliance Officers</td>
                    <td className="border border-border p-3">Review, triage, and resolve feedback items</td>
                  </tr>
                  <tr>
                    <td className="border border-border p-3 font-medium">Department Managers</td>
                    <td className="border border-border p-3">View feedback related to their department</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3 font-medium">Administrators</td>
                    <td className="border border-border p-3">Manage system settings, users, and workflows</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold border-b pb-2">3. Core Features</h2>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">3.1 Feedback Submission</h3>
            <p><strong>Description:</strong> Allow users to submit compliance-related feedback with supporting details and attachments.</p>
            <p><strong>Requirements:</strong></p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Form fields: Title, Description, Category, Priority, Department</li>
              <li>File attachments (max 5 files, 10MB each)</li>
              <li>Categories: Compliance Issue, Process Improvement, Safety Concern, Policy Question, Training Request, Other</li>
              <li>Priority levels: Low, Medium, High, Critical</li>
              <li>Auto-assignment based on department routing rules</li>
            </ul>

            <h3 className="text-xl font-semibold mt-6 mb-3">3.2 Task Management Dashboard</h3>
            <p><strong>Description:</strong> Role-aware dashboard displaying feedback items organized by status and assignment.</p>
            
            <p className="mt-4"><strong>Scope Toggle:</strong></p>
            <div className="overflow-x-auto mt-2">
              <table className="w-full border-collapse border border-border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-3 text-left font-semibold">Role</th>
                    <th className="border border-border p-3 text-left font-semibold">Toggle Options</th>
                    <th className="border border-border p-3 text-left font-semibold">Description</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-border p-3">Healthcare Staff</td>
                    <td className="border border-border p-3">None</td>
                    <td className="border border-border p-3">Always sees only personal submissions</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3">Department Manager</td>
                    <td className="border border-border p-3">Personal / Department</td>
                    <td className="border border-border p-3">Toggle between own feedback and department-wide view</td>
                  </tr>
                  <tr>
                    <td className="border border-border p-3">Compliance Officer</td>
                    <td className="border border-border p-3">Personal / Organization</td>
                    <td className="border border-border p-3">Toggle between own feedback and organization-wide view</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3">Administrator</td>
                    <td className="border border-border p-3">Personal / Organization</td>
                    <td className="border border-border p-3">Toggle between own feedback and organization-wide view</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <p className="mt-4"><strong>Task Views:</strong></p>
            <div className="overflow-x-auto mt-2">
              <table className="w-full border-collapse border border-border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-3 text-left font-semibold">Tab</th>
                    <th className="border border-border p-3 text-left font-semibold">Filter Logic</th>
                    <th className="border border-border p-3 text-left font-semibold">Icon</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-border p-3">To Do</td>
                    <td className="border border-border p-3">Status: pending, in-progress; Assigned to current user</td>
                    <td className="border border-border p-3">ListTodo</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3">To Review</td>
                    <td className="border border-border p-3">Status: under-review</td>
                    <td className="border border-border p-3">Eye</td>
                  </tr>
                  <tr>
                    <td className="border border-border p-3">Overdue</td>
                    <td className="border border-border p-3">Due date in past; Status not resolved/closed</td>
                    <td className="border border-border p-3">AlertTriangle</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3">Resolved</td>
                    <td className="border border-border p-3">Status: resolved</td>
                    <td className="border border-border p-3">CheckCircle</td>
                  </tr>
                  <tr>
                    <td className="border border-border p-3">Closed</td>
                    <td className="border border-border p-3">Status: closed</td>
                    <td className="border border-border p-3">XCircle</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <h3 className="text-xl font-semibold mt-6 mb-3">3.3 Feedback Detail View</h3>
            <p><strong>Description:</strong> Comprehensive view of a single feedback item with full lifecycle management.</p>
            <p><strong>Capabilities:</strong></p>
            <ul className="list-disc pl-6 space-y-1">
              <li>View complete feedback details and history</li>
              <li>Update status (pending → in-progress → under-review → resolved → closed)</li>
              <li>Adjust priority at any stage (Low, Medium, High, Critical)</li>
              <li>Reassign to different team members</li>
              <li>Add notes with file attachments (max 3 files per note)</li>
              <li>View activity timeline</li>
            </ul>

            <h3 className="text-xl font-semibold mt-6 mb-3">3.4 File Attachments</h3>
            <p><strong>Description:</strong> Support for file uploads throughout the feedback lifecycle.</p>
            <div className="overflow-x-auto mt-4">
              <table className="w-full border-collapse border border-border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-3 text-left font-semibold">Stage</th>
                    <th className="border border-border p-3 text-left font-semibold">Max Files</th>
                    <th className="border border-border p-3 text-left font-semibold">Max Size</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-border p-3">Initial Submission</td>
                    <td className="border border-border p-3">5 files</td>
                    <td className="border border-border p-3">10MB each</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3">Note/Comment</td>
                    <td className="border border-border p-3">3 files</td>
                    <td className="border border-border p-3">10MB each</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="mt-4"><strong>Supported Features:</strong></p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Drag-and-drop upload</li>
              <li>File type icons (image, PDF, document, spreadsheet, text)</li>
              <li>Download functionality</li>
              <li>File size display</li>
            </ul>

            <h3 className="text-xl font-semibold mt-6 mb-3">3.5 Activity Feed</h3>
            <p><strong>Description:</strong> Real-time activity stream showing recent actions across all feedback items.</p>
            <div className="overflow-x-auto mt-4">
              <table className="w-full border-collapse border border-border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-3 text-left font-semibold">Type</th>
                    <th className="border border-border p-3 text-left font-semibold">Icon</th>
                    <th className="border border-border p-3 text-left font-semibold">Description</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-border p-3">Submission</td>
                    <td className="border border-border p-3">MessageSquarePlus</td>
                    <td className="border border-border p-3">New feedback submitted</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3">Update</td>
                    <td className="border border-border p-3">RefreshCw</td>
                    <td className="border border-border p-3">Feedback details updated</td>
                  </tr>
                  <tr>
                    <td className="border border-border p-3">Assignment</td>
                    <td className="border border-border p-3">UserPlus</td>
                    <td className="border border-border p-3">Feedback assigned/reassigned</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3">Comment</td>
                    <td className="border border-border p-3">MessageCircle</td>
                    <td className="border border-border p-3">Note added</td>
                  </tr>
                  <tr>
                    <td className="border border-border p-3">Status Change</td>
                    <td className="border border-border p-3">ArrowRightLeft</td>
                    <td className="border border-border p-3">Status updated</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3">Resolution</td>
                    <td className="border border-border p-3">CheckCircle2</td>
                    <td className="border border-border p-3">Feedback resolved</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          <section className="mb-8 print:break-before-page">
            <h2 className="text-2xl font-semibold border-b pb-2">4. Data Model</h2>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">4.1 FeedbackItem Interface</h3>
            <pre className="bg-muted p-4 rounded-lg overflow-x-auto text-sm">
{`interface FeedbackItem {
  id: string;
  title: string;
  description: string;
  category: FeedbackCategory;
  priority: FeedbackPriority;
  status: FeedbackStatus;
  department: string;
  submittedBy: string;
  submittedAt: string;
  assignedTo?: string;
  dueDate?: string;
  lastUpdated: string;
  attachments?: Attachment[];
  notes?: FeedbackNote[];
  history?: FeedbackHistoryEntry[];
}`}
            </pre>

            <h3 className="text-xl font-semibold mt-6 mb-3">4.2 Status Workflow</h3>
            <div className="bg-muted p-4 rounded-lg text-center font-mono">
              pending → in-progress → under-review → resolved → closed
            </div>

            <h3 className="text-xl font-semibold mt-6 mb-3">4.3 Priority Levels</h3>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-3 text-left font-semibold">Priority</th>
                    <th className="border border-border p-3 text-left font-semibold">Use Case</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-border p-3 font-medium">Low</td>
                    <td className="border border-border p-3">Non-urgent improvements or suggestions</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3 font-medium">Medium</td>
                    <td className="border border-border p-3">Standard compliance concerns</td>
                  </tr>
                  <tr>
                    <td className="border border-border p-3 font-medium">High</td>
                    <td className="border border-border p-3">Significant compliance issues requiring prompt attention</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3 font-medium">Critical</td>
                    <td className="border border-border p-3">Urgent issues requiring immediate action</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <h3 className="text-xl font-semibold mt-6 mb-3">4.4 Categories</h3>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-3 text-left font-semibold">Category</th>
                    <th className="border border-border p-3 text-left font-semibold">Description</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-border p-3 font-medium">compliance-issue</td>
                    <td className="border border-border p-3">Regulatory or policy violations</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3 font-medium">process-improvement</td>
                    <td className="border border-border p-3">Workflow optimization suggestions</td>
                  </tr>
                  <tr>
                    <td className="border border-border p-3 font-medium">safety-concern</td>
                    <td className="border border-border p-3">Patient or staff safety issues</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3 font-medium">policy-question</td>
                    <td className="border border-border p-3">Questions about existing policies</td>
                  </tr>
                  <tr>
                    <td className="border border-border p-3 font-medium">training-request</td>
                    <td className="border border-border p-3">Requests for additional training</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3 font-medium">other</td>
                    <td className="border border-border p-3">Miscellaneous feedback</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold border-b pb-2">5. UI Components</h2>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">5.1 Navigation</h3>
            <ul className="list-disc pl-6 space-y-1">
              <li><strong>AppSidebar:</strong> Collapsible navigation with view switching</li>
              <li><strong>Header:</strong> App branding and user actions</li>
            </ul>

            <h3 className="text-xl font-semibold mt-6 mb-3">5.2 Dashboard Components</h3>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-3 text-left font-semibold">Component</th>
                    <th className="border border-border p-3 text-left font-semibold">Purpose</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-border p-3 font-medium">DashboardStats</td>
                    <td className="border border-border p-3">Summary cards (To Do, To Review, Resolved, Overdue counts)</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3 font-medium">DashboardAnalytics</td>
                    <td className="border border-border p-3">Success metrics with charts (resolution time, overdue rate, status distribution, weekly trends)</td>
                  </tr>
                  <tr>
                    <td className="border border-border p-3 font-medium">ScopeToggle</td>
                    <td className="border border-border p-3">Role-based toggle for Personal/Department/Organization view filtering</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3 font-medium">TaskTabs</td>
                    <td className="border border-border p-3">Tabbed view of feedback by status</td>
                  </tr>
                  <tr>
                    <td className="border border-border p-3 font-medium">ActivityFeed</td>
                    <td className="border border-border p-3">Recent activity stream</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <h3 className="text-xl font-semibold mt-6 mb-3">5.3 Feedback Components</h3>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-3 text-left font-semibold">Component</th>
                    <th className="border border-border p-3 text-left font-semibold">Purpose</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-border p-3 font-medium">FeedbackCard</td>
                    <td className="border border-border p-3">Compact feedback preview in lists</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3 font-medium">FeedbackDetails</td>
                    <td className="border border-border p-3">Full feedback view with actions</td>
                  </tr>
                  <tr>
                    <td className="border border-border p-3 font-medium">NewFeedbackForm</td>
                    <td className="border border-border p-3">Submission form</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3 font-medium">StatusBadge</td>
                    <td className="border border-border p-3">Visual status indicator</td>
                  </tr>
                  <tr>
                    <td className="border border-border p-3 font-medium">PriorityBadge</td>
                    <td className="border border-border p-3">Visual priority indicator</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3 font-medium">FileAttachment</td>
                    <td className="border border-border p-3">Upload and display attachments</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold border-b pb-2">6. Non-Functional Requirements</h2>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">6.1 Performance</h3>
            <ul className="list-disc pl-6 space-y-1">
              <li>Dashboard loads within 2 seconds</li>
              <li>Feedback list renders up to 100 items smoothly</li>
              <li>File uploads show progress indicator</li>
            </ul>

            <h3 className="text-xl font-semibold mt-6 mb-3">6.2 Accessibility</h3>
            <ul className="list-disc pl-6 space-y-1">
              <li>WCAG 2.1 AA compliance</li>
              <li>Keyboard navigation support</li>
              <li>Screen reader compatible</li>
            </ul>

            <h3 className="text-xl font-semibold mt-6 mb-3">6.3 Responsiveness</h3>
            <ul className="list-disc pl-6 space-y-1">
              <li>Desktop-first design</li>
              <li>Tablet and mobile support</li>
              <li>Collapsible sidebar for smaller screens</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold border-b pb-2">7. Future Enhancements</h2>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Phase 2</h3>
            <ul className="list-disc pl-6 space-y-1">
              <li>Cloud storage for attachments (Lovable Cloud)</li>
              <li>User authentication and role-based access</li>
              <li>Email notifications for status changes</li>
              <li>Overdue alerts and reminders</li>
            </ul>

            <h3 className="text-xl font-semibold mt-6 mb-3">Phase 3</h3>
            <ul className="list-disc pl-6 space-y-1">
              <li>Analytics dashboard with charts</li>
              <li>Bulk actions (status change, reassignment)</li>
              <li>Advanced filtering and search</li>
              <li>Export functionality (CSV, PDF)</li>
            </ul>

            <h3 className="text-xl font-semibold mt-6 mb-3">Phase 4</h3>
            <ul className="list-disc pl-6 space-y-1">
              <li>Integration with external systems</li>
              <li>Custom workflow configuration</li>
              <li>SLA tracking and reporting</li>
              <li>Audit log for compliance</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold border-b pb-2">8. Success Metrics</h2>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border border-border p-3 text-left font-semibold">Metric</th>
                    <th className="border border-border p-3 text-left font-semibold">Target</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-border p-3">Average resolution time</td>
                    <td className="border border-border p-3">&lt; 48 hours</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3">Overdue rate</td>
                    <td className="border border-border p-3">&lt; 10%</td>
                  </tr>
                  <tr>
                    <td className="border border-border p-3">User adoption rate</td>
                    <td className="border border-border p-3">&gt; 80% of staff</td>
                  </tr>
                  <tr className="bg-muted/50">
                    <td className="border border-border p-3">Feedback submission rate</td>
                    <td className="border border-border p-3">20% increase in first quarter</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          <footer className="mt-12 pt-6 border-t border-border text-sm text-muted-foreground">
            <p>Version 1.0 | Last Updated: December 11, 2025</p>
          </footer>
        </article>
      </div>
    </div>
  );
};

export default PRDDocument;
