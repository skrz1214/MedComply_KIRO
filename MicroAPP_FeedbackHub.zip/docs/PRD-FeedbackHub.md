# Product Requirements Document: FeedbackHub

## Overview

FeedbackHub is a centralized compliance feedback management system designed for healthcare organizations. It enables staff and compliance teams to submit, track, and resolve compliance-related feedback through a structured workflow.

---

## 1. Problem Statement

Healthcare organizations struggle to efficiently collect, route, and resolve compliance-related feedback from staff. Current processes often rely on fragmented communication channels (email, paper forms, verbal reports), leading to:

- Lost or overlooked compliance concerns
- Inconsistent response times
- Lack of visibility into feedback status
- No audit trail for regulatory compliance

---

## 2. Target Users

| User Role | Description |
|-----------|-------------|
| **Healthcare Staff** | Submit compliance feedback, track their submissions |
| **Compliance Officers** | Review, triage, and resolve feedback items |
| **Department Managers** | View feedback related to their department |
| **Administrators** | Manage system settings, users, and workflows |

---

## 3. Core Features

### 3.1 Feedback Submission

**Description:** Allow users to submit compliance-related feedback with supporting details and attachments.

**Requirements:**
- Form fields: Title, Description, Category, Priority, Department
- File attachments (max 5 files, 10MB each)
- Categories: Compliance Issue, Process Improvement, Safety Concern, Policy Question, Training Request, Other
- Priority levels: Low, Medium, High, Critical
- Auto-assignment based on department routing rules

### 3.2 Task Management Dashboard

**Description:** Role-aware dashboard displaying feedback items organized by status and assignment.

**Scope Toggle:**
| Role | Toggle Options | Description |
|------|----------------|-------------|
| Healthcare Staff | None | Always sees only personal submissions |
| Department Manager | Personal / Department | Toggle between own feedback and department-wide view |
| Compliance Officer | Personal / Organization | Toggle between own feedback and organization-wide view |
| Administrator | Personal / Organization | Toggle between own feedback and organization-wide view |

**Task Views:**
| Tab | Filter Logic | Icon |
|-----|--------------|------|
| To Do | Status: pending, in-progress; Assigned to current user | ListTodo |
| To Review | Status: under-review | Eye |
| Overdue | Due date in past; Status not resolved/closed | AlertTriangle |
| Resolved | Status: resolved | CheckCircle |
| Closed | Status: closed | XCircle |

### 3.3 Feedback Detail View

**Description:** Comprehensive view of a single feedback item with full lifecycle management.

**Capabilities:**
- View complete feedback details and history
- Update status (pending → in-progress → under-review → resolved → closed)
- Adjust priority at any stage (Low, Medium, High, Critical)
- Reassign to different team members
- Add notes with file attachments (max 3 files per note)
- View activity timeline

### 3.4 File Attachments

**Description:** Support for file uploads throughout the feedback lifecycle.

**Attachment Points:**
| Stage | Max Files | Max Size |
|-------|-----------|----------|
| Initial Submission | 5 files | 10MB each |
| Note/Comment | 3 files | 10MB each |

**Supported Features:**
- Drag-and-drop upload
- File type icons (image, PDF, document, spreadsheet, text)
- Download functionality
- File size display

### 3.5 Activity Feed

**Description:** Real-time activity stream showing recent actions across all feedback items.

**Activity Types:**
| Type | Icon | Description |
|------|------|-------------|
| Submission | MessageSquarePlus | New feedback submitted |
| Update | RefreshCw | Feedback details updated |
| Assignment | UserPlus | Feedback assigned/reassigned |
| Comment | MessageCircle | Note added |
| Status Change | ArrowRightLeft | Status updated |
| Resolution | CheckCircle2 | Feedback resolved |

### 3.6 Cross-Microapp Labels

**Description:** Tag feedback items with labels that route them to relevant microapps based on issue type.

**Available Labels:**
| Label | Use Case |
|-------|----------|
| ComplianceConnect | Process failure, repeat trends, high risk harm potential |
| RiskGuard | Risk-related items |
| EnforcePoint | Enforcement-related items |
| AuditPro | Audit-related items |

**Features:**
- Multiple labels can be applied to a single feedback item
- Labels can be assigned during submission and review stages
- Visual badge display on feedback cards

### 3.7 Cross-Microapp References

**Description:** Link existing items from other microapps as references to feedback items for cross-microapp traceability.

**Supported Microapps:**
- ComplianceConnect
- RiskGuard
- EnforcePoint
- AuditPro

**Features:**
- Available for non-closed feedback items
- Can be added during submission and review stages
- Displays linked item title and source microapp

### 3.8 Due Date Management

**Description:** Track feedback timelines with due date functionality.

**Features:**
- Set due date during feedback submission
- Update due date during review of in-progress items
- Automatic classification: Items with past due dates appear in "Overdue" tab
- Overdue items are distinct from In Progress items

---

## 4. Data Model

### 4.1 FeedbackItem

```typescript
interface FeedbackItem {
  id: string;
  title: string;
  description: string;
  category: FeedbackCategory;
  priority: FeedbackPriority;
  status: FeedbackStatus;
  department: string;
  submittedBy: string;
  submittedAt: string;
  assignedTo?: string;
  dueDate?: string;
  lastUpdated: string;
  attachments?: Attachment[];
  notes?: FeedbackNote[];
  history?: FeedbackHistoryEntry[];
  microappLabels?: MicroappLabel[];
  microappReferences?: MicroappReference[];
}
```

### 4.2 Status Workflow

```
pending → in-progress → under-review → resolved → closed
```

| Status | Description | Dashboard Tab |
|--------|-------------|---------------|
| pending | New feedback awaiting initial triage/assignment | To Do |
| in-progress | Actively being worked on | In Progress |
| under-review | Work complete, awaiting final approval | To Review |
| resolved | Issue addressed and verified | Resolved |
| closed | Feedback lifecycle complete | Closed |

### 4.3 Priority Levels

| Priority | Use Case |
|----------|----------|
| Low | Non-urgent improvements or suggestions |
| Medium | Standard compliance concerns |
| High | Significant compliance issues requiring prompt attention |
| Critical | Urgent issues requiring immediate action |

### 4.4 Categories

| Category | Description |
|----------|-------------|
| compliance-issue | Regulatory or policy violations |
| process-improvement | Workflow optimization suggestions |
| safety-concern | Patient or staff safety issues |
| policy-question | Questions about existing policies |
| training-request | Requests for additional training |
| other | Miscellaneous feedback |

### 4.5 Microapp Labels

```typescript
type MicroappLabel = 'ComplianceConnect' | 'RiskGuard' | 'EnforcePoint' | 'AuditPro';
```

### 4.6 Microapp References

```typescript
interface MicroappReference {
  id: string;
  microapp: MicroappLabel;
  itemId: string;
  itemTitle: string;
  addedBy: string;
  addedAt: string;
}
```

---

## 5. UI Components

### 5.1 Navigation

- **AppSidebar:** Collapsible navigation with view switching
- **Header:** App branding and user actions

### 5.2 Dashboard Components

| Component | Purpose |
|-----------|---------|
| DashboardStats | Summary cards (To Do, To Review, Resolved, Overdue counts) |
| DashboardAnalytics | Success metrics with charts (resolution time, overdue rate, status distribution, weekly trends) |
| ScopeToggle | Role-based toggle for Personal/Department/Organization view filtering |
| TaskTabs | Tabbed view of feedback by status |
| ActivityFeed | Recent activity stream |

### 5.3 Feedback Components

| Component | Purpose |
|-----------|---------|
| FeedbackCard | Compact feedback preview in lists |
| FeedbackDetails | Full feedback view with actions |
| NewFeedbackForm | Submission form |
| StatusBadge | Visual status indicator |
| PriorityBadge | Visual priority indicator |
| FileAttachment | Upload and display attachments |
| MicroappLabelBadge | Display microapp labels |
| MicroappLabelSelect | Select microapp labels |
| MicroappReferenceManager | Manage cross-microapp references |

### 5.4 Admin Components

| Component | Purpose |
|-----------|---------|
| MetricsThresholdsTab | Configure success metrics thresholds |
| DepartmentsTab | Manage departments |
| CategoriesTab | Manage feedback categories |
| PrioritiesTab | Configure priority levels |
| RoutingRulesTab | Define auto-assignment rules |
| WorkflowPolicyTab | Configure workflow permissions |
| AttachmentPolicyTab | Set file upload limits |
| ActivityFeedPolicyTab | Configure activity visibility |
| AuditLogTab | View system audit trail |

---

## 6. Non-Functional Requirements

### 6.1 Performance
- Dashboard loads within 2 seconds
- Feedback list renders up to 100 items smoothly
- File uploads show progress indicator

### 6.2 Accessibility
- WCAG 2.1 AA compliance
- Keyboard navigation support
- Screen reader compatible

### 6.3 Responsiveness
- Desktop-first design
- Tablet and mobile support
- Collapsible sidebar for smaller screens

---

## 7. Future Enhancements

### Phase 2
- [ ] Cloud storage for attachments (Lovable Cloud/Supabase)
- [ ] User authentication and role-based access
- [ ] Email notifications for status changes
- [ ] Overdue alerts and reminders

### Phase 3
- [x] ~~Analytics dashboard with charts~~ ✓ Implemented
- [ ] Bulk actions (status change, reassignment)
- [ ] Advanced filtering and search
- [ ] Export functionality (CSV, PDF)

### Phase 4
- [ ] Integration with external systems
- [ ] Custom workflow configuration
- [ ] SLA tracking and reporting
- [ ] Audit log for compliance

---

## 8. Success Metrics

### 8.1 Dashboard Analytics

The dashboard displays real-time success metrics with visual indicators:

| Metric | Description | Visualization |
|--------|-------------|---------------|
| Average Resolution Time | Days from submission to resolution | Progress bar with threshold coloring |
| Overdue Rate | Percentage of active items past due date | Progress bar with threshold coloring |
| Status Distribution | Breakdown of items by status | Donut chart |
| Weekly Activity | Submissions vs resolutions trend | Area chart with dual lines |

### 8.2 Configurable Thresholds

Administrators can configure metric thresholds via Admin Settings → Metrics:

| Threshold | Default | Description |
|-----------|---------|-------------|
| Resolution Time Target | 2 days | Green indicator when below |
| Resolution Time Warning | 4 days | Amber between target and warning, red above |
| Overdue Rate Target | 10% | Green indicator when below |
| Overdue Rate Warning | 20% | Amber between target and warning, red above |

### 8.3 Business Targets

| Metric | Target |
|--------|--------|
| Average resolution time | < 48 hours |
| Overdue rate | < 10% |
| User adoption rate | > 80% of staff |
| Feedback submission rate | 20% increase in first quarter |

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2025-12-11 | Initial PRD with core features |
| 1.1 | 2025-12-14 | Added cross-microapp labels, references, due date management, and status workflow details |
| 1.2 | 2025-12-14 | Added dashboard analytics with success metrics and admin-configurable thresholds |
| 1.3 | 2025-12-15 | Added scope toggle for role-based view filtering (Personal/Department/Organization) |
