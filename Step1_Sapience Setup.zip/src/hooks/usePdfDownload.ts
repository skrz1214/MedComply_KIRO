import { useCallback, useRef } from 'react';
import html2pdf from 'html2pdf.js';
import { toast } from '@/hooks/use-toast';
import medcomplyLogo from '@/assets/medcomply-logo.png';

interface PdfDownloadOptions {
  filename: string;
  title?: string;
  includeLogo?: boolean;
}

export const usePdfDownload = () => {
  const contentRef = useRef<HTMLDivElement>(null);

  const downloadPdf = useCallback(async (options: PdfDownloadOptions) => {
    if (!contentRef.current) {
      toast({
        title: "Error",
        description: "Could not generate PDF. Please try again.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Generating PDF",
      description: "Please wait while your document is being prepared...",
    });

    try {
      const element = contentRef.current;
      
      // Create a wrapper with logo header if requested
      let pdfElement = element;
      if (options.includeLogo !== false) {
        const wrapper = document.createElement('div');
        wrapper.innerHTML = `
          <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 2px solid #e5e7eb;">
            <img src="${medcomplyLogo}" alt="MedComply" style="height: 48px; width: auto;" />
            ${options.title ? `<h1 style="font-size: 20px; font-weight: 600; color: #1e3a5f; margin: 0;">${options.title}</h1>` : ''}
          </div>
        `;
        wrapper.appendChild(element.cloneNode(true));
        document.body.appendChild(wrapper);
        pdfElement = wrapper;
      }
      
      const opt = {
        margin: [10, 10, 10, 10],
        filename: options.filename,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { 
          scale: 2,
          useCORS: true,
          letterRendering: true,
        },
        jsPDF: { 
          unit: 'mm', 
          format: 'a4', 
          orientation: 'portrait' as const,
        },
        pagebreak: { mode: ['avoid-all', 'css', 'legacy'] },
      };

      await html2pdf().set(opt).from(pdfElement).save();
      
      // Clean up wrapper if created
      if (options.includeLogo !== false && pdfElement !== element) {
        document.body.removeChild(pdfElement);
      }

      toast({
        title: "PDF Downloaded",
        description: `${options.filename} has been downloaded successfully.`,
      });
    } catch (error) {
      console.error('PDF generation error:', error);
      toast({
        title: "Error",
        description: "Failed to generate PDF. Please try again.",
        variant: "destructive",
      });
    }
  }, []);

  return { contentRef, downloadPdf };
};
