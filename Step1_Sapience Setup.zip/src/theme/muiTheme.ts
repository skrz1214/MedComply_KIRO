import { createTheme } from '@mui/material/styles';

// Convert HSL CSS variables to usable colors
const getHSLValue = (h: number, s: number, l: number) => `hsl(${h}, ${s}%, ${l}%)`;

// Light theme colors based on index.css values
const lightPalette = {
  primary: {
    main: getHSLValue(213, 94, 30),
    light: getHSLValue(213, 94, 50),
    dark: getHSLValue(213, 94, 20),
    contrastText: getHSLValue(210, 40, 98),
  },
  secondary: {
    main: getHSLValue(210, 40, 96),
    light: getHSLValue(210, 40, 98),
    dark: getHSLValue(210, 40, 90),
    contrastText: getHSLValue(222, 47, 11),
  },
  error: {
    main: getHSLValue(0, 84, 60),
    contrastText: getHSLValue(210, 40, 98),
  },
  warning: {
    main: getHSLValue(38, 92, 50),
    contrastText: getHSLValue(0, 0, 100),
  },
  success: {
    main: getHSLValue(142, 71, 45),
    contrastText: getHSLValue(0, 0, 100),
  },
  info: {
    main: getHSLValue(172, 66, 40),
    contrastText: getHSLValue(0, 0, 100),
  },
  background: {
    default: getHSLValue(210, 20, 98),
    paper: getHSLValue(0, 0, 100),
  },
  text: {
    primary: getHSLValue(222, 47, 11),
    secondary: getHSLValue(215, 16, 47),
    disabled: getHSLValue(215, 16, 70),
  },
  divider: getHSLValue(214, 32, 91),
};

// Dark theme colors
const darkPalette = {
  primary: {
    main: getHSLValue(213, 94, 50),
    light: getHSLValue(213, 94, 60),
    dark: getHSLValue(213, 94, 40),
    contrastText: getHSLValue(0, 0, 100),
  },
  secondary: {
    main: getHSLValue(217, 33, 17),
    light: getHSLValue(217, 33, 27),
    dark: getHSLValue(217, 33, 12),
    contrastText: getHSLValue(210, 40, 98),
  },
  error: {
    main: getHSLValue(0, 63, 31),
    contrastText: getHSLValue(210, 40, 98),
  },
  warning: {
    main: getHSLValue(38, 92, 40),
    contrastText: getHSLValue(0, 0, 100),
  },
  success: {
    main: getHSLValue(142, 71, 35),
    contrastText: getHSLValue(0, 0, 100),
  },
  info: {
    main: getHSLValue(172, 66, 50),
    contrastText: getHSLValue(0, 0, 100),
  },
  background: {
    default: getHSLValue(222, 47, 6),
    paper: getHSLValue(222, 47, 9),
  },
  text: {
    primary: getHSLValue(210, 40, 98),
    secondary: getHSLValue(215, 20, 65),
    disabled: getHSLValue(215, 20, 45),
  },
  divider: getHSLValue(217, 33, 17),
};

export const lightTheme = createTheme({
  palette: {
    mode: 'light',
    ...lightPalette,
  },
  typography: {
    fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
    h1: {
      fontFamily: '"Plus Jakarta Sans", "Roboto", "Helvetica", "Arial", sans-serif',
      fontWeight: 600,
    },
    h2: {
      fontFamily: '"Plus Jakarta Sans", "Roboto", "Helvetica", "Arial", sans-serif',
      fontWeight: 600,
    },
    h3: {
      fontFamily: '"Plus Jakarta Sans", "Roboto", "Helvetica", "Arial", sans-serif',
      fontWeight: 600,
    },
    h4: {
      fontFamily: '"Plus Jakarta Sans", "Roboto", "Helvetica", "Arial", sans-serif',
      fontWeight: 600,
    },
    h5: {
      fontFamily: '"Plus Jakarta Sans", "Roboto", "Helvetica", "Arial", sans-serif',
      fontWeight: 600,
    },
    h6: {
      fontFamily: '"Plus Jakarta Sans", "Roboto", "Helvetica", "Arial", sans-serif',
      fontWeight: 600,
    },
    button: {
      textTransform: 'none',
      fontWeight: 500,
    },
  },
  shape: {
    borderRadius: 8,
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          padding: '8px 16px',
          fontSize: '0.875rem',
        },
        sizeLarge: {
          padding: '11px 24px',
        },
        sizeSmall: {
          padding: '6px 12px',
          fontSize: '0.8125rem',
        },
      },
      defaultProps: {
        disableElevation: true,
      },
    },
    MuiTextField: {
      defaultProps: {
        variant: 'outlined',
        size: 'small',
      },
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            borderRadius: 8,
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1)',
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: 'none',
        },
      },
    },
    MuiTooltip: {
      styleOverrides: {
        tooltip: {
          borderRadius: 6,
          fontSize: '0.75rem',
        },
      },
    },
    MuiSwitch: {
      styleOverrides: {
        root: {
          width: 44,
          height: 24,
          padding: 0,
        },
        switchBase: {
          padding: 2,
          '&.Mui-checked': {
            transform: 'translateX(20px)',
          },
        },
        thumb: {
          width: 20,
          height: 20,
        },
        track: {
          borderRadius: 12,
        },
      },
    },
    MuiCheckbox: {
      styleOverrides: {
        root: {
          borderRadius: 4,
        },
      },
    },
    MuiSelect: {
      defaultProps: {
        size: 'small',
      },
      styleOverrides: {
        root: {
          borderRadius: 8,
        },
      },
    },
    MuiDialog: {
      styleOverrides: {
        paper: {
          borderRadius: 12,
        },
      },
    },
    MuiAccordion: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          '&:before': {
            display: 'none',
          },
          '&.Mui-expanded': {
            margin: 0,
          },
        },
      },
    },
  },
});

export const darkTheme = createTheme({
  palette: {
    mode: 'dark',
    ...darkPalette,
  },
  typography: lightTheme.typography,
  shape: lightTheme.shape,
  components: lightTheme.components,
});
