// Branding Configuration Types for Onboarding
// Supports logo upload, theming, typography, app shell customization, and localization

export type ThemePreset = 'default' | 'healthcare_calm' | 'high_contrast' | 'custom';
export type NeutralMode = 'cool' | 'warm' | 'neutral';
export type BackgroundMode = 'light' | 'dark';
export type FontFamily = 'system' | 'modern_sans';
export type FontSize = 'normal' | 'large';
export type ButtonStyle = 'standard' | 'extra_rounded';
export type Density = 'comfortable' | 'compact';
export type DateFormat = 'MM/DD/YYYY' | 'DD/MM/YYYY' | 'YYYY-MM-DD';
export type TimeFormat = '12hour' | '24hour';
export type NumberFormat = 'us' | 'eu';
export type DomainStatus = 'not_verified' | 'pending' | 'verified';

// Logo configuration
export interface LogoConfig {
  primaryLogoUrl?: string;
  primaryLogoFile?: File;
  squareLogoUrl?: string;
  squareLogoFile?: File;
  faviconUrl?: string;
  faviconFile?: File;
}

// Theme configuration
export interface ThemeConfig {
  preset: ThemePreset;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  neutralMode: NeutralMode;
  backgroundMode: BackgroundMode;
  contrastOk: boolean;
}

// Typography configuration
export interface TypographyConfig {
  fontFamily: FontFamily;
  baseFontSize: FontSize;
}

// App shell configuration
export interface AppShellConfig {
  sidebarExpandedByDefault: boolean;
  sidebarShowLabels: boolean;
  headerShowOrgName: boolean;
  buttonStyle: ButtonStyle;
  density: Density;
}

// Login screen configuration
export interface LoginConfig {
  welcomeTitle: string;
  welcomeMessage: string;
  supportEmail: string;
  supportPhone: string;
  helpLinkLabel: string;
  helpLinkUrl: string;
  termsUrl: string;
  privacyUrl: string;
}

// Organization identity
export interface OrgIdentityConfig {
  displayName: string;
  shortName: string;
  appTitle: string;
}

// Localization configuration
export interface LocalizationConfig {
  defaultLanguage: string;
  dateFormat: DateFormat;
  timeFormat: TimeFormat;
  numberFormat: NumberFormat;
}

// Domain configuration
export interface DomainConfig {
  subdomain: string;
  customDomain: string;
  domainStatus: DomainStatus;
}

// Complete Branding Configuration
export interface BrandingConfig {
  // Status
  status: 'draft' | 'published' | 'skipped';
  publishedBy?: string;
  publishedAt?: string;
  versionId?: string;
  
  // Configuration sections
  orgIdentity: OrgIdentityConfig;
  logo: LogoConfig;
  theme: ThemeConfig;
  typography: TypographyConfig;
  appShell: AppShellConfig;
  login: LoginConfig;
  localization: LocalizationConfig;
  domain: DomainConfig;
}

// Validation result
export interface BrandingValidationResult {
  isValid: boolean;
  canPublish: boolean;
  errors: string[];
  warnings: string[];
}

// Theme preset definitions
export interface ThemePresetDefinition {
  id: ThemePreset;
  name: string;
  description: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
}

// Language options
export interface LanguageOption {
  code: string;
  name: string;
  nativeName: string;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'es', name: 'Spanish', nativeName: 'Español' },
  { code: 'fr', name: 'French', nativeName: 'Français' },
  { code: 'de', name: 'German', nativeName: 'Deutsch' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português' },
  { code: 'zh', name: 'Chinese', nativeName: '中文' },
  { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt' },
  { code: 'ko', name: 'Korean', nativeName: '한국어' },
  { code: 'tl', name: 'Tagalog', nativeName: 'Tagalog' },
];

// Logo requirements
export const LOGO_REQUIREMENTS = {
  primary: {
    maxSizeMB: 5,
    acceptedTypes: ['image/png', 'image/jpeg', 'image/svg+xml'],
    acceptedExtensions: '.png,.jpg,.jpeg,.svg',
    recommendedWidth: 300,
    recommendedHeight: 80,
  },
  square: {
    maxSizeMB: 2,
    acceptedTypes: ['image/png', 'image/jpeg', 'image/svg+xml'],
    acceptedExtensions: '.png,.jpg,.jpeg,.svg',
    recommendedSize: 128,
  },
  favicon: {
    maxSizeMB: 1,
    acceptedTypes: ['image/png', 'image/x-icon', 'image/ico'],
    acceptedExtensions: '.png,.ico',
    recommendedSize: 48,
  },
};
