// Onboarding Wizard Types

export interface Organization {
  // Identity
  name: string;
  legalEntityName?: string;
  orgType: string;
  industry: string;
  orgCode: string;
  npi?: string;
  taxId?: string;
  ccn?: string;
  accreditor?: string;
  accreditorOther?: string;
  
  // Primary Contact
  primaryContactName: string;
  primaryContactEmail: string;
  primaryContactPhone?: string;
  implementationOwner?: string;
  secondaryComplianceContact?: string;
  
  // Location & Time
  addressLine1: string;
  addressLine2?: string;
  city: string;
  stateProvince: string;
  country: string;
  zipPostal: string;
  timeZone: string;
  
  // Size & Structure
  singleFacilityMode: boolean;
  numberOfFacilities: string;
  numberOfDepartments: string;
  estimatedUsers: string;
  hasParentOrg: boolean;
  parentOrgName?: string;
  parentOrgCode?: string;
  
  // Compliance Scope
  coreComplianceTags: string[];
  advancedComplianceTags: string[];
  regulatoryBodies: string[];
  suggestedTagsApplied: boolean;
  
  // Status
  onboardingStatus: 'draft' | 'in_progress' | 'ready';
  status: 'draft' | 'active' | 'suspended' | 'archived';
  createdAt?: string;
  createdBy?: string;
}

export const ORG_TYPES = [
  'Nursing Home / Skilled Nursing Facility (SNF)',
  'Assisted Living Facility (ALF)',
  'Home Health',
  'Hospice',
  'Hospital',
  'Clinic / Ambulatory',
  'Multi-site Provider Network',
  'Other',
];

export const ACCREDITOR_OPTIONS = [
  'None / Not applicable',
  'The Joint Commission (TJC)',
  'DNV',
  'HFAP',
  'CARF',
  'ACHC',
  'Other',
];

export const FACILITY_COUNT_OPTIONS = ['1', '2-5', '6-25', '26+'];
export const DEPARTMENT_COUNT_OPTIONS = ['1-5', '6-15', '16+'];
export const USER_COUNT_OPTIONS = ['1-25', '26-100', '101-500', '500+'];

export const SERVICE_POPULATIONS = [
  'Seniors/LTC',
  'General Acute Care',
  'Behavioral Health',
  'Pediatrics',
  'Mixed',
];

export const PAYER_MIX_OPTIONS = [
  'Medicare',
  'Medicaid',
  'Commercial',
  'Private Pay',
  'Mixed',
];

// Core Compliance Tags - shown by default
export const CORE_COMPLIANCE_TAGS = [
  { id: 'hipaa', label: 'HIPAA Privacy & Security (incl. Breach Notification)', category: 'core' },
  { id: 'state_doh', label: 'State Department of Health / State Survey Agency', category: 'core' },
  { id: 'cms_general', label: 'CMS / Medicare & Medicaid Participation (general)', category: 'core' },
  { id: 'infection_control', label: 'Infection Prevention & Control', category: 'core' },
  { id: 'patient_rights', label: 'Patient/Resident Rights', category: 'core' },
  { id: 'osha', label: 'Workplace Safety (OSHA)', category: 'core' },
  { id: 'qapi', label: 'Quality Assurance / QAPI (QAA/QAPI)', category: 'core' },
];

// Advanced Compliance Tags - grouped by category
export const ADVANCED_COMPLIANCE_TAGS = {
  federal: {
    label: 'Federal Programs & Oversight',
    tags: [
      { id: 'cms_cops', label: 'CMS Conditions of Participation (CoPs)' },
      { id: 'cms_cfcs', label: 'CMS Conditions for Coverage (CfCs)' },
      { id: 'survey_cert', label: 'Survey & Certification (S&C)' },
      { id: 'oig', label: 'HHS OIG / Program Integrity' },
      { id: 'doj_fca', label: 'DOJ / FCA (False Claims) risk (governance tag)' },
    ],
  },
  ltc: {
    label: 'LTC / SNF / ALF-specific',
    tags: [
      { id: 'obra', label: 'Nursing Home Reform / LTC regulations (OBRA)' },
      { id: 'mds_rai', label: 'MDS / RAI (SNF)' },
      { id: 'life_safety', label: 'Life Safety / Fire Safety (NFPA / Life Safety Code)' },
      { id: 'abuse_reporting', label: 'Abuse/Neglect/Exploitation reporting' },
      { id: 'staffing_compliance', label: 'Staffing compliance (e.g., PBJ reporting)' },
    ],
  },
  clinical: {
    label: 'Clinical & Medication Safety',
    tags: [
      { id: 'medication_mgmt', label: 'Medication Management' },
      { id: 'dea_oversight', label: 'Controlled Substances / DEA oversight' },
      { id: 'antimicrobial', label: 'Antimicrobial Stewardship' },
    ],
  },
  privacy: {
    label: 'Privacy/Security Beyond HIPAA',
    tags: [
      { id: 'state_privacy', label: 'State privacy laws (state-dependent)' },
      { id: 'cures_act', label: '21st Century Cures Act / Information Blocking' },
    ],
  },
  accreditation: {
    label: 'Accreditation & Standards (optional)',
    tags: [
      { id: 'tjc_dnv', label: 'TJC / DNV / HFAP programs' },
      { id: 'carf_achc', label: 'CARF / ACHC (home health/hospice/rehab)' },
      { id: 'iso_nist', label: 'ISO/NIST internal frameworks (governance tags)' },
    ],
  },
  operational: {
    label: 'Operational/Financial Compliance (optional)',
    tags: [
      { id: 'billing_coding', label: 'Billing & Coding Compliance' },
      { id: 'cost_reporting', label: 'Cost reporting' },
      { id: 'anti_kickback', label: 'Anti-kickback/Stark awareness (governance tag)' },
    ],
  },
};

// Smart suggestions based on org type
export const COMPLIANCE_SUGGESTIONS: Record<string, { core: string[]; advanced: string[] }> = {
  'Nursing Home / Skilled Nursing Facility (SNF)': {
    core: ['hipaa', 'state_doh', 'cms_general', 'infection_control', 'patient_rights', 'osha', 'qapi'],
    advanced: ['survey_cert', 'obra', 'mds_rai', 'life_safety', 'abuse_reporting', 'staffing_compliance'],
  },
  'Assisted Living Facility (ALF)': {
    core: ['hipaa', 'state_doh', 'infection_control', 'patient_rights', 'osha'],
    advanced: ['life_safety', 'abuse_reporting'],
  },
  'Home Health': {
    core: ['hipaa', 'state_doh', 'infection_control', 'patient_rights', 'osha'],
    advanced: ['cms_cfcs', 'oig', 'carf_achc'],
  },
  'Hospice': {
    core: ['hipaa', 'state_doh', 'patient_rights', 'osha'],
    advanced: ['cms_cfcs', 'oig'],
  },
  'Hospital': {
    core: ['hipaa', 'state_doh', 'cms_general', 'infection_control', 'patient_rights', 'osha', 'qapi'],
    advanced: ['cms_cops', 'cures_act', 'tjc_dnv', 'medication_mgmt'],
  },
  'Clinic / Ambulatory': {
    core: ['hipaa', 'state_doh', 'infection_control', 'osha'],
    advanced: [],
  },
  'Multi-site Provider Network': {
    core: ['hipaa', 'state_doh', 'cms_general', 'infection_control', 'osha', 'qapi'],
    advanced: ['oig', 'billing_coding'],
  },
  'Other': {
    core: ['hipaa', 'osha'],
    advanced: [],
  },
};

export const US_STATES = [
  'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut',
  'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa',
  'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan',
  'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire',
  'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio',
  'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota',
  'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia',
  'Wisconsin', 'Wyoming',
];

export interface RegulatoryBody {
  id: string;
  name: string;
  abbreviation: string;
  description: string;
}

export interface ComplianceFramework {
  id: string;
  name: string;
  description: string;
}

export interface TenantSettings {
  orgType: 'standalone' | 'parent' | 'child';
  parentOrgId?: string;
  dataResidencyRegion: string;
  maxUsersAllowed: number;
  maxDepartmentsAllowed?: number;
  licenseTier: 'basic' | 'premium' | 'enterprise';
  licenseExpiry?: string;
  microappsEnabled: string[];
  storageQuotaGB?: number;
  adminDelegationAllowed: boolean;
  roleOverrideByParent: boolean;
  featureFlags?: Record<string, boolean>;
}

export interface Facility {
  id: string;
  name: string;
  code: string;
  type: string;
  sameAsOrgAddress: boolean;
  address?: string;
  city?: string;
  stateProvince?: string;
  country?: string;
  zipPostal?: string;
  timeZone: string;
  status: 'active' | 'inactive';
  // Parent-child hierarchy
  parentFacilityId?: string | null;
  isParent?: boolean;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  description?: string;
  status: 'active' | 'inactive';
  facilityIds: string[]; // 'all' means all facilities
}

export interface Microapp {
  id: string;
  name: string;
  code: string;
  description: string;
  modules: string[];
  owner?: string;
  status: 'enabled' | 'disabled';
  auditLoggingEnabled: boolean;
  integrationRequired: boolean;
  integrationDetails?: string;
  riskLevel: 'low' | 'medium' | 'high';
  departmentIds: string[];
  facilityIds: string[];
}

export type RoleType = 'staff' | 'department_head' | 'compliance_head' | 'org_admin';

export interface RoleEntitlement {
  objectArea: string;
  scope: 'self' | 'department' | 'org';
  capabilities: string[];
}

export interface Role {
  id: string;
  name: string;
  type: RoleType;
  isSystemRole: boolean;
  description: string;
  departmentIds: string[];
  microappIds: string[];
  entitlements: RoleEntitlement[];
}

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  departmentIds: string[];
  roleIds: string[];
  mfaEnabled: boolean;
  status: 'active' | 'inactive' | 'pending';
  jobTitle?: string;
  preferredLanguage?: string;
  timeZone?: string;
  notes?: string;
  tags?: string[];
  inviteSent: boolean;
}

export interface LOVCategory {
  id: string;
  name: string;
  description: string;
  values: LOVValue[];
  isLocked: boolean;
}

export interface LOVValue {
  id: string;
  value: string;
  label: string;
  sortOrder: number;
  isActive: boolean;
  isDefault?: boolean;
}

export interface SecuritySettings {
  auditLoggingEnabled: boolean;
  logRetentionDays: number;
  mfaEnforcement: 'optional' | 'required' | 'admin_only';
  sessionTimeoutMinutes: number;
  ipRestrictions?: string[];
  dataAccessScope: 'strict' | 'standard' | 'permissive';
  notificationsEnabled: boolean;
}

export interface BrandingSettings {
  logoUrl?: string;
  primaryColor: string;
  secondaryColor?: string;
  defaultLanguage: string;
  customLoginMessage?: string;
  customDomain?: string;
  applyToChildren?: boolean;
  allowChildOverride?: boolean;
}

// App Access Entitlements Types
export type AccessLevel = 'none' | 'view' | 'manage';
export type DataScope = 'self' | 'department' | 'org';
export type StandardRoleType = 'staff' | 'department_head' | 'compliance_head' | 'org_admin';

export interface AppAccessConfig {
  accessLevel: AccessLevel;
  scope: DataScope;
}

export interface DashboardFlags {
  canExportCsv: boolean;
  canViewCrossAppKpis: boolean;
}

export interface RoleAppEntitlements {
  apps: Record<string, AppAccessConfig>;
  dashboardFlags: DashboardFlags;
  exportsAllowed: boolean;
  exportScope: DataScope;
}

export interface AppAccessEntitlements {
  selectedPreset: 'recommended' | 'strict' | 'operational' | null;
  // Dynamic: keyed by role ID (not role type)
  roleEntitlements: Record<string, RoleAppEntitlements>;
  isCustomized: boolean;
}

// Standard apps and dashboards for entitlements
export const ENTITLEMENT_APPS = [
  // Dashboards
  { id: 'master_dashboard', name: 'Master Compliance Dashboard', code: 'MASTER_DASHBOARD', isCore: true, isDashboard: true },
  { id: 'department_dashboard', name: 'Department Dashboard', code: 'DEPT_DASHBOARD', isCore: false, isDashboard: true },
  { id: 'individual_dashboard', name: 'Individual User Dashboard', code: 'USER_DASHBOARD', isCore: false, isDashboard: true },
  // Microapps
  { id: 'compliance_connect', name: 'ComplianceConnect', code: 'COMPLIANCE', isCore: true, isDashboard: false },
  { id: 'audit_pro', name: 'AuditPro', code: 'AUDIT', isCore: true, isDashboard: false },
  { id: 'feedback_hub', name: 'FeedbackHub', code: 'FEEDBACK', isCore: true, isDashboard: false },
  { id: 'enforce_point', name: 'EnforcePoint', code: 'ENFORCE', isCore: true, isDashboard: false },
  { id: 'risk_guard', name: 'RiskGuard', code: 'RISK', isCore: true, isDashboard: false },
  { id: 'capa', name: 'CAPA/ActionGuard', code: 'CAPA', isCore: false, isDashboard: false },
  { id: 'citations', name: 'Citations Module', code: 'CITATIONS', isCore: false, isDashboard: false },
  { id: 'documents', name: 'Controlled Documents', code: 'DOCUMENTS', isCore: false, isDashboard: false },
] as const;

// Maps role types to their max allowed scope
export const ROLE_TYPE_MAX_SCOPE: Record<RoleType, DataScope> = {
  staff: 'self',
  department_head: 'department',
  compliance_head: 'org',
  org_admin: 'org',
};

export interface OnboardingData {
  organization: Partial<Organization>;
  regulatoryBodies: string[];
  complianceFrameworks: string[];
  tenantSettings: Partial<TenantSettings>;
  facilities: Facility[];
  singleFacilityMode: boolean;
  departments: Department[];
  microapps: Microapp[];
  roles: Role[];
  customRolesEnabled: boolean;
  users: User[];
  lovCategories: LOVCategory[];
  securitySettings: Partial<SecuritySettings>;
  brandingSettings: Partial<BrandingSettings>;
  appAccessEntitlements: AppAccessEntitlements;
  currentStep: number;
  completedSteps: number[];
  lastSavedAt?: string;
  isActivated: boolean;
}

export type WizardStep = {
  id: number;
  name: string;
  shortName: string;
  description: string;
  isRequired: boolean;
  isComplete: boolean;
};

export const WIZARD_STEPS: WizardStep[] = [
  { id: 1, name: 'Organization & Compliance Setup', shortName: 'Organization', description: 'Organization info, compliance scope & regulatory oversight', isRequired: true, isComplete: false },
  { id: 2, name: 'Recommended Setup', shortName: 'Setup Pack', description: 'Preview & apply recommended defaults', isRequired: true, isComplete: false },
  { id: 3, name: 'Tenant, Licensing & Access Controls', shortName: 'Licensing', description: 'License and access settings', isRequired: true, isComplete: false },
  { id: 4, name: 'Facilities & Departments', shortName: 'Facilities', description: 'Locations and departments', isRequired: true, isComplete: false },
  { id: 5, name: 'Apps & Dashboards', shortName: 'Apps', description: 'Enable microapps and configure dashboards', isRequired: true, isComplete: false },
  { id: 6, name: 'Roles & Permissions', shortName: 'Roles', description: 'Define user roles and permission levels', isRequired: true, isComplete: false },
  { id: 7, name: 'App & Dashboard Access', shortName: 'Access', description: 'Configure role-based access to apps and dashboards', isRequired: true, isComplete: false },
  { id: 8, name: 'Users & Invitations', shortName: 'Users', description: 'Add users and send invites', isRequired: true, isComplete: false },
  { id: 9, name: 'LOV / Value Sets', shortName: 'Value Sets', description: 'Dropdown configurations', isRequired: true, isComplete: false },
  { id: 10, name: 'Security & Audit Logging', shortName: 'Security', description: 'Security and compliance settings', isRequired: true, isComplete: false },
  { id: 11, name: 'Branding & Localization', shortName: 'Branding', description: 'Customize appearance', isRequired: false, isComplete: false },
  { id: 12, name: 'Review & Activate', shortName: 'Review & Activate', description: 'Final review and activation', isRequired: true, isComplete: false },
  { id: 13, name: 'Product Requirements Document', shortName: 'PRD', description: 'Comprehensive PRD with glossary', isRequired: false, isComplete: false },
  { id: 14, name: 'Technical Design Document', shortName: 'TDD', description: 'Technical specifications with glossary', isRequired: false, isComplete: false },
  { id: 15, name: 'QA Test Scenarios', shortName: 'QA Tests', description: 'Quality assurance test cases', isRequired: false, isComplete: false },
  { id: 16, name: 'UAT Test Scenarios', shortName: 'UAT Tests', description: 'User acceptance test cases', isRequired: false, isComplete: false },
  { id: 17, name: 'Configuration Prompt', shortName: 'Prompt', description: 'Downloadable configuration prompt', isRequired: false, isComplete: false },
];

export const REGULATORY_BODIES: RegulatoryBody[] = [
  { id: 'hhs', name: 'Health and Human Services', abbreviation: 'HHS', description: 'Department of Health and Human Services' },
  { id: 'ocr', name: 'Office for Civil Rights', abbreviation: 'OCR', description: 'HIPAA enforcement' },
  { id: 'cms', name: 'Centers for Medicare & Medicaid Services', abbreviation: 'CMS', description: 'Medicare and Medicaid oversight' },
  { id: 'oig', name: 'Office of Inspector General', abbreviation: 'OIG', description: 'Fraud and abuse prevention' },
  { id: 'fda', name: 'Food and Drug Administration', abbreviation: 'FDA', description: 'Drug and device regulation' },
  { id: 'dea', name: 'Drug Enforcement Administration', abbreviation: 'DEA', description: 'Controlled substances' },
  { id: 'ftc', name: 'Federal Trade Commission', abbreviation: 'FTC', description: 'Consumer protection' },
];

export const COMPLIANCE_FRAMEWORKS: ComplianceFramework[] = [
  { id: 'hipaa', name: 'HIPAA', description: 'Health Insurance Portability and Accountability Act' },
  { id: 'hitech', name: 'HITECH', description: 'Health Information Technology for Economic and Clinical Health Act' },
  { id: 'soc2', name: 'SOC 2', description: 'Service Organization Control 2' },
  { id: 'iso27001', name: 'ISO 27001', description: 'Information Security Management' },
  { id: 'iso27701', name: 'ISO 27701', description: 'Privacy Information Management' },
  { id: 'gdpr', name: 'GDPR', description: 'General Data Protection Regulation' },
  { id: 'nist', name: 'NIST 800-53', description: 'Security and Privacy Controls' },
];

export const DEFAULT_DEPARTMENTS = [
  { name: 'Human Resource Compliance', code: 'HR-COMP' },
  { name: 'Finance Compliance', code: 'FIN-COMP' },
  { name: 'Health and Life Safety', code: 'HLS' },
  { name: 'Patient Care', code: 'PAT-CARE' },
  { name: 'Quality Assurance', code: 'QA' },
  { name: 'Org Leadership', code: 'ORG-LEAD' },
  { name: 'ReadOnly Group', code: 'READONLY' },
];

export const FACILITY_TYPES = [
  'Nursing Home',
  'Assisted Living',
  'Clinic',
  'Hospital',
  'Outpatient Center',
  'Rehabilitation Center',
  'Other',
];

export const DEFAULT_MICROAPPS: Omit<Microapp, 'id' | 'departmentIds' | 'facilityIds'>[] = [
  {
    name: 'FeedbackHub',
    code: 'FEEDBACK',
    description: 'Capture staff and patient feedback, track responses, and generate satisfaction reports.',
    modules: ['Feedback Collection', 'Analytics', 'Response Management'],
    status: 'enabled',
    auditLoggingEnabled: true,
    integrationRequired: false,
    riskLevel: 'low',
  },
  {
    name: 'ComplianceConnect',
    code: 'COMPLIANCE',
    description: 'Track compliance issues, manage corrective actions (CAPA), and monitor citations in one place.',
    modules: ['Issue Tracking', 'CAPA Management', 'Citations', 'Reporting'],
    status: 'enabled',
    auditLoggingEnabled: true,
    integrationRequired: false,
    riskLevel: 'high',
  },
  {
    name: 'RiskGuard',
    code: 'RISK',
    description: 'Identify organizational risks, create mitigation plans, and manage SOPs and Job Aids through the Risk Management Program.',
    modules: ['Risk Assessment', 'Mitigation Plans', 'Thresholds', 'SOP Management', 'Job Aids'],
    status: 'enabled',
    auditLoggingEnabled: true,
    integrationRequired: false,
    riskLevel: 'high',
  },
  {
    name: 'EnforcePoint',
    code: 'ENFORCE',
    description: 'Monitor enforcement actions, track regulatory deadlines, and maintain a compliance calendar.',
    modules: ['Enforcement Library', 'Action Tracking', 'Compliance Calendar'],
    status: 'enabled',
    auditLoggingEnabled: true,
    integrationRequired: false,
    riskLevel: 'high',
  },
  {
    name: 'AuditPro',
    code: 'AUDIT',
    description: 'Plan audits, document findings, assign corrective actions, and generate audit reports.',
    modules: ['Audit Planning', 'Findings', 'Corrective Actions', 'Reports'],
    status: 'enabled',
    auditLoggingEnabled: true,
    integrationRequired: false,
    riskLevel: 'medium',
  },
];

export const DEFAULT_ROLES: Omit<Role, 'id' | 'departmentIds' | 'microappIds'>[] = [
  {
    name: 'Staff',
    type: 'staff',
    isSystemRole: true,
    description: 'Standard staff member with self-management and department view access',
    entitlements: [
      { objectArea: 'Issues', scope: 'self', capabilities: ['View', 'Create', 'Edit', 'Submit'] },
      { objectArea: 'Feedback', scope: 'self', capabilities: ['View', 'Create'] },
      { objectArea: 'Documents', scope: 'department', capabilities: ['View'] },
      { objectArea: 'Reports', scope: 'self', capabilities: ['View'] },
    ],
  },
  {
    name: 'Department Head',
    type: 'department_head',
    isSystemRole: true,
    description: 'Department manager with full department access and document management',
    entitlements: [
      { objectArea: 'Issues', scope: 'department', capabilities: ['View', 'Create', 'Edit', 'Submit', 'Approve'] },
      { objectArea: 'CAPA', scope: 'department', capabilities: ['View', 'Create', 'Edit', 'Submit'] },
      { objectArea: 'Feedback', scope: 'department', capabilities: ['View', 'Create', 'Edit'] },
      { objectArea: 'Documents', scope: 'department', capabilities: ['View', 'Create', 'Edit', 'Publish'] },
      { objectArea: 'Reports', scope: 'department', capabilities: ['View', 'Create'] },
      { objectArea: 'Risks', scope: 'department', capabilities: ['View', 'Create', 'Edit'] },
    ],
  },
  {
    name: 'Compliance Head',
    type: 'compliance_head',
    isSystemRole: true,
    description: 'Organization-wide compliance oversight with approval authority',
    entitlements: [
      { objectArea: 'Issues', scope: 'org', capabilities: ['View', 'Create', 'Edit', 'Submit', 'Approve', 'Close'] },
      { objectArea: 'CAPA', scope: 'org', capabilities: ['View', 'Create', 'Edit', 'Submit', 'Approve', 'Close'] },
      { objectArea: 'Enforcement', scope: 'org', capabilities: ['View', 'Create', 'Edit', 'Submit', 'Approve'] },
      { objectArea: 'Audits', scope: 'org', capabilities: ['View', 'Create', 'Edit', 'Submit', 'Approve'] },
      { objectArea: 'Feedback', scope: 'org', capabilities: ['View', 'Create', 'Edit', 'Close'] },
      { objectArea: 'Risks', scope: 'org', capabilities: ['View', 'Create', 'Edit', 'Submit', 'Approve'] },
      { objectArea: 'Documents', scope: 'org', capabilities: ['View', 'Create', 'Edit', 'Publish'] },
      { objectArea: 'Reports', scope: 'org', capabilities: ['View', 'Create'] },
    ],
  },
  {
    name: 'Org Admin',
    type: 'org_admin',
    isSystemRole: true,
    description: 'Full administrative access including system configuration',
    entitlements: [
      { objectArea: 'Issues', scope: 'org', capabilities: ['View', 'Create', 'Edit', 'Submit', 'Approve', 'Close'] },
      { objectArea: 'CAPA', scope: 'org', capabilities: ['View', 'Create', 'Edit', 'Submit', 'Approve', 'Close'] },
      { objectArea: 'Enforcement', scope: 'org', capabilities: ['View', 'Create', 'Edit', 'Submit', 'Approve', 'Close'] },
      { objectArea: 'Audits', scope: 'org', capabilities: ['View', 'Create', 'Edit', 'Submit', 'Approve', 'Close'] },
      { objectArea: 'Feedback', scope: 'org', capabilities: ['View', 'Create', 'Edit', 'Close'] },
      { objectArea: 'Risks', scope: 'org', capabilities: ['View', 'Create', 'Edit', 'Submit', 'Approve', 'Close'] },
      { objectArea: 'Documents', scope: 'org', capabilities: ['View', 'Create', 'Edit', 'Publish'] },
      { objectArea: 'Reports', scope: 'org', capabilities: ['View', 'Create'] },
      { objectArea: 'Admin Config', scope: 'org', capabilities: ['View', 'Configure'] },
    ],
  },
];

export const DEFAULT_LOV_CATEGORIES: Omit<LOVCategory, 'id'>[] = [
  {
    name: 'Facility Type',
    description: 'Types of healthcare facilities',
    isLocked: false,
    values: FACILITY_TYPES.map((type, index) => ({
      id: `facility-type-${index}`,
      value: type.toLowerCase().replace(/\s+/g, '_'),
      label: type,
      sortOrder: index,
      isActive: true,
    })),
  },
  {
    name: 'Priority',
    description: 'Priority levels for issues and tasks',
    isLocked: true,
    values: [
      { id: 'priority-1', value: 'critical', label: 'Critical', sortOrder: 0, isActive: true },
      { id: 'priority-2', value: 'high', label: 'High', sortOrder: 1, isActive: true },
      { id: 'priority-3', value: 'medium', label: 'Medium', sortOrder: 2, isActive: true, isDefault: true },
      { id: 'priority-4', value: 'low', label: 'Low', sortOrder: 3, isActive: true },
    ],
  },
  {
    name: 'Severity',
    description: 'Severity levels for incidents',
    isLocked: true,
    values: [
      { id: 'severity-1', value: 'severe', label: 'Severe', sortOrder: 0, isActive: true },
      { id: 'severity-2', value: 'major', label: 'Major', sortOrder: 1, isActive: true },
      { id: 'severity-3', value: 'moderate', label: 'Moderate', sortOrder: 2, isActive: true, isDefault: true },
      { id: 'severity-4', value: 'minor', label: 'Minor', sortOrder: 3, isActive: true },
    ],
  },
  {
    name: 'Issue Category',
    description: 'Categories for compliance issues',
    isLocked: false,
    values: [
      { id: 'issue-cat-1', value: 'policy_violation', label: 'Policy Violation', sortOrder: 0, isActive: true },
      { id: 'issue-cat-2', value: 'safety_concern', label: 'Safety Concern', sortOrder: 1, isActive: true },
      { id: 'issue-cat-3', value: 'documentation', label: 'Documentation Issue', sortOrder: 2, isActive: true },
      { id: 'issue-cat-4', value: 'training', label: 'Training Gap', sortOrder: 3, isActive: true },
      { id: 'issue-cat-5', value: 'other', label: 'Other', sortOrder: 4, isActive: true },
    ],
  },
  {
    name: 'Risk Category',
    description: 'Categories for risk assessments',
    isLocked: false,
    values: [
      { id: 'risk-cat-1', value: 'clinical', label: 'Clinical Risk', sortOrder: 0, isActive: true },
      { id: 'risk-cat-2', value: 'operational', label: 'Operational Risk', sortOrder: 1, isActive: true },
      { id: 'risk-cat-3', value: 'financial', label: 'Financial Risk', sortOrder: 2, isActive: true },
      { id: 'risk-cat-4', value: 'compliance', label: 'Compliance Risk', sortOrder: 3, isActive: true },
      { id: 'risk-cat-5', value: 'reputational', label: 'Reputational Risk', sortOrder: 4, isActive: true },
    ],
  },
  {
    name: 'Feedback Category',
    description: 'Categories for feedback submissions',
    isLocked: false,
    values: [
      { id: 'feedback-cat-1', value: 'suggestion', label: 'Suggestion', sortOrder: 0, isActive: true },
      { id: 'feedback-cat-2', value: 'complaint', label: 'Complaint', sortOrder: 1, isActive: true },
      { id: 'feedback-cat-3', value: 'compliment', label: 'Compliment', sortOrder: 2, isActive: true },
      { id: 'feedback-cat-4', value: 'question', label: 'Question', sortOrder: 3, isActive: true },
    ],
  },
];

export const TIMEZONES = [
  'America/New_York',
  'America/Chicago',
  'America/Denver',
  'America/Los_Angeles',
  'America/Anchorage',
  'Pacific/Honolulu',
  'America/Phoenix',
  'America/Puerto_Rico',
];

export const INDUSTRIES = [
  'Healthcare - Hospital',
  'Healthcare - Nursing Home',
  'Healthcare - Assisted Living',
  'Healthcare - Home Health',
  'Healthcare - Clinic',
  'Life Sciences - Pharmaceutical',
  'Life Sciences - Medical Device',
  'Life Sciences - Biotech',
  'Other',
];

export const LEGAL_ENTITY_TYPES = [
  'Corporation',
  'LLC',
  'Partnership',
  'Non-Profit',
  'Government',
  'Other',
];

export const DATA_RESIDENCY_REGIONS = [
  'US East',
  'US West',
  'US Central',
  'EU',
  'APAC',
];
