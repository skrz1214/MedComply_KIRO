// Security Baseline Types for HIPAA-Aligned Onboarding
// Maps to HIPAA Security Rule safeguard categories (admin/physical/technical)
// Aligns with NIST SP 800-63-4 digital identity guidance

export type SecurityPresetType = 'healthcare_baseline' | 'strict' | 'operational';
export type AuthMode = 'sso' | 'local';
export type IdpType = 'saml' | 'oidc';
export type MfaPolicy = 'admin_only' | 'all_users';
export type MfaMethod = 'authenticator' | 'sms' | 'email';
export type EncryptionKeyType = 'platform_managed' | 'customer_managed';
export type IdleTimeoutOption = 15 | 30 | 60 | 120;
export type SessionMaxDuration = 8 | 12 | 24;
export type InactiveDisableWindow = 30 | 60 | 90;
export type ActiveRetentionDays = 90 | 180 | 365;
export type ArchivedRetentionYears = 1 | 3 | 7;
export type TokenRotationDays = 30 | 60 | 90;

// Card 1: Identity & Authentication
export interface IdentityAuthConfig {
  // 3.1 Authentication Mode
  authMode: AuthMode;
  // SSO-specific
  idpType?: IdpType;
  allowedDomains: string[];
  jitProvisioningEnabled: boolean;
  roleMapping: 'scim' | 'idp_groups';
  // Local login-specific
  passwordMinLength: number;
  passwordRequireUppercase: boolean;
  passwordRequireLowercase: boolean;
  passwordRequireNumbers: boolean;
  passwordRequireSpecial: boolean;
  passwordLockoutAttempts: number;
  passwordLockoutDuration: number; // minutes
  passwordExpiryDays: number;
  
  // 3.2 MFA Policy
  mfaRequired: MfaPolicy;
  mfaAllowedMethods: MfaMethod[];
  recoveryCodesEnabled: boolean;
  
  // 3.3 Unique User Identification (always ON)
  uniqueUserIdEnabled: true;
  
  // 3.4 Break-glass admin access
  emergencyAccessEnabled: boolean;
  emergencyAccessApprovers: string[]; // role types
  emergencyAccessDuration: number; // hours
  emergencyAccessRequiresJustification: boolean;
}

// Card 2: Access Control Baseline
export interface AccessControlConfig {
  // 4.1 RBAC model (read-only summary, no config needed)
  
  // 4.2 Least privilege guardrails
  preventSelfApproval: boolean;
  adminChangesRequireReauth: boolean;
  
  // 4.3 Account lifecycle
  inactiveAccountDisableDays: InactiveDisableWindow;
  terminatedUserDisableImmediately: boolean;
  roleChangeAuditRequired: true; // system-enforced
}

// Card 3: Session & Device Controls
export interface SessionControlsConfig {
  // 5.1 Automatic logoff / session timeout
  idleTimeoutMinutes: IdleTimeoutOption;
  absoluteSessionMaxHours: SessionMaxDuration;
  
  // 5.2 Device / browser constraints
  restrictToManagedDevices: boolean;
  blockUnsupportedBrowsers: boolean;
}

// Card 4: Encryption & Transmission Security
export interface EncryptionConfig {
  // 6.1 Encryption in transit (always ON)
  tlsRequired: true;
  blockNonTlsCallbacks: boolean;
  
  // 6.2 Encryption at rest
  encryptionKeyType: EncryptionKeyType;
  
  // 6.3 Integrity protection
  integrityChecksEnabled: boolean;
  fileHashingEnabled: boolean;
  tamperEvidentAuditTrail: boolean;
}

// Card 5: Audit Logging & Retention
export interface AuditLoggingConfig {
  // 7.1 Audit logging (always ON)
  auditLoggingEnabled: true;
  eventCategories: {
    authentication: boolean;
    authorization: boolean;
    adminConfig: boolean;
    dataChanges: boolean;
    evidenceUploadDownload: boolean;
    exports: boolean;
    breakGlassAccess: boolean;
    apiTokens: boolean;
  };
  
  // 7.2 Retention policy
  activeRetentionDays: ActiveRetentionDays;
  archivedRetentionYears: ArchivedRetentionYears;
  exportAuditLogAllowed: 'admin_only' | 'compliance_head' | 'all';
  
  // 7.3 Audit access
  auditViewers: {
    orgAdmin: boolean;
    complianceHead: boolean;
    departmentHead: boolean;
    staff: boolean;
  };
}

// Card 6: Export Controls
export interface ExportControlsConfig {
  // Role-based export policy
  staffExportsAllowed: boolean;
  departmentHeadExportsAllowed: boolean;
  departmentHeadExportScope: 'department';
  complianceHeadExportsAllowed: boolean;
  complianceHeadExportScope: 'org';
  orgAdminExportsAllowed: boolean;
  orgAdminExportScope: 'org';
  
  // Export safeguards
  requireExportReason: boolean;
  watermarkExports: boolean;
}

// Card 7: Network Controls
export interface NetworkControlsConfig {
  // IP allowlist
  ipAllowlistEnabled: boolean;
  ipAllowlistCidrs: string[];
  lockoutPreventionContact: string;
  
  // API access controls
  apiTokensEnabled: boolean;
  tokenRotationReminderDays: TokenRotationDays;
}

// Card 8: Incident Contacts & Notifications
export interface IncidentContact {
  name: string;
  email: string;
  phone?: string;
}

export interface IncidentContactsConfig {
  securityContact: IncidentContact;
  complianceContact: IncidentContact;
  
  // Notification triggers
  notifyOnRepeatedFailedLogins: boolean;
  notifyOnAdminRoleChanges: boolean;
  notifyOnLargeExports: boolean;
  notifyOnBreakGlassUsage: boolean;
  
  // Delivery channels
  notifyViaEmail: boolean;
  notifyViaInApp: boolean;
}

// Card 9: Governance Attestations
export interface GovernanceAttestationsConfig {
  // Required attestations
  accessManagementAcknowledged: boolean;
  auditMonitoringAcknowledged: boolean;
  ssoMfaConfigAcknowledged: boolean;
  
  // Optional
  baaAcknowledged: boolean;
}

// Complete Security Baseline
export interface SecurityBaseline {
  // Preset selection
  selectedPreset: SecurityPresetType;
  isCustomized: boolean;
  
  // Status
  status: 'draft' | 'published';
  publishedBy?: string;
  publishedAt?: string;
  versionId?: string;
  
  // All configuration sections
  identityAuth: IdentityAuthConfig;
  accessControl: AccessControlConfig;
  sessionControls: SessionControlsConfig;
  encryption: EncryptionConfig;
  auditLogging: AuditLoggingConfig;
  exportControls: ExportControlsConfig;
  networkControls: NetworkControlsConfig;
  incidentContacts: IncidentContactsConfig;
  governanceAttestations: GovernanceAttestationsConfig;
}

// Validation result
export interface SecurityValidationResult {
  isValid: boolean;
  canPublish: boolean;
  errors: string[];
  warnings: string[];
}

// Audit log entry
export interface SecurityAuditEntry {
  id: string;
  action: 'draft_saved' | 'published' | 'updated';
  performedBy: string;
  performedAt: string;
  changes?: Record<string, { from: unknown; to: unknown }>;
  versionId: string;
}
