import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { WizardLayout } from "@/components/onboarding/WizardLayout";
import { OnboardingProvider } from "@/contexts/OnboardingContext";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

// Simulate first-time login check
const isFirstLogin = () => {
  return !localStorage.getItem('medcomply_onboarding_complete');
};

const App = () => (
  <OnboardingProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={
                isFirstLogin() ? (
                  <WizardLayout />
                ) : (
                  <Navigate to="/dashboard" replace />
                )
              } />
              <Route path="/onboarding" element={<WizardLayout />} />
              <Route path="/dashboard" element={
                <div className="min-h-screen bg-background flex items-center justify-center">
                  <div className="text-center">
                    <h1 className="text-3xl font-heading font-bold mb-4">Master Compliance Dashboard</h1>
                    <p className="text-muted-foreground">Your organization is active and ready.</p>
                  </div>
                </div>
              } />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </QueryClientProvider>
    </OnboardingProvider>
);

export default App;