import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { 
  OnboardingData, 
  WIZARD_STEPS,
  DEFAULT_MICROAPPS,
  DEFAULT_ROLES,
  DEFAULT_LOV_CATEGORIES,
  Facility,
  Department,
  Microapp,
  Role,
  User,
  LOVCategory,
  AppAccessEntitlements,
} from '@/types/onboarding';
import { getDefaultAppAccessEntitlements } from '@/data/appAccessPresets';
import { useToast } from '@/hooks/use-toast';

const STORAGE_KEY = 'medcomply_onboarding_draft';

const generateId = () => crypto.randomUUID();

const getInitialData = (): OnboardingData => ({
  organization: {
    status: 'draft',
    onboardingStatus: 'draft',
    industry: 'Healthcare Provider',
    country: 'United States',
    coreComplianceTags: [],
    advancedComplianceTags: [],
    regulatoryBodies: [],
    suggestedTagsApplied: false,
    hasParentOrg: false,
    singleFacilityMode: false,
  },
  regulatoryBodies: [],
  complianceFrameworks: [],
  tenantSettings: {
    orgType: 'standalone',
    licenseTier: 'premium',
    maxUsersAllowed: 50,
    adminDelegationAllowed: true,
    roleOverrideByParent: false,
    dataResidencyRegion: 'US East',
  },
  facilities: [],
  singleFacilityMode: false,
  departments: [],
  microapps: DEFAULT_MICROAPPS.map(app => ({
    ...app,
    id: generateId(),
    departmentIds: [],
    facilityIds: [],
  })),
  roles: DEFAULT_ROLES.map(role => ({
    ...role,
    id: generateId(),
    departmentIds: [],
    microappIds: [],
  })),
  customRolesEnabled: false,
  users: [],
  lovCategories: DEFAULT_LOV_CATEGORIES.map(cat => ({
    ...cat,
    id: generateId(),
  })),
  securitySettings: {
    auditLoggingEnabled: true,
    logRetentionDays: 365,
    mfaEnforcement: 'required',
    sessionTimeoutMinutes: 30,
    dataAccessScope: 'standard',
    notificationsEnabled: true,
  },
  brandingSettings: {
    primaryColor: '#1e3a5f',
    defaultLanguage: 'en',
  },
  appAccessEntitlements: getDefaultAppAccessEntitlements(),
  currentStep: 1,
  completedSteps: [],
  isActivated: false,
});

interface OnboardingContextType {
  data: OnboardingData;
  currentStep: number;
  steps: typeof WIZARD_STEPS;
  isStepComplete: (stepId: number) => boolean;
  goToStep: (stepId: number) => void;
  nextStep: () => void;
  prevStep: () => void;
  updateOrganization: (org: Partial<OnboardingData['organization']>) => void;
  updateRegulatoryBodies: (bodies: string[]) => void;
  updateComplianceFrameworks: (frameworks: string[]) => void;
  updateTenantSettings: (settings: Partial<OnboardingData['tenantSettings']>) => void;
  addFacility: (facility: Omit<Facility, 'id'>) => void;
  updateFacility: (id: string, facility: Partial<Facility>) => void;
  removeFacility: (id: string) => void;
  setSingleFacilityMode: (enabled: boolean) => void;
  addDepartment: (department: Omit<Department, 'id'>) => void;
  updateDepartment: (id: string, department: Partial<Department>) => void;
  removeDepartment: (id: string) => void;
  updateMicroapp: (id: string, microapp: Partial<Microapp>) => void;
  addRole: (role: Omit<Role, 'id'>) => void;
  updateRole: (id: string, role: Partial<Role>) => void;
  removeRole: (id: string) => void;
  setCustomRolesEnabled: (enabled: boolean) => void;
  addUser: (user: Omit<User, 'id'>) => void;
  updateUser: (id: string, user: Partial<User>) => void;
  removeUser: (id: string) => void;
  bulkAddUsers: (users: Omit<User, 'id'>[]) => void;
  updateLOVCategory: (id: string, category: Partial<LOVCategory>) => void;
  updateSecuritySettings: (settings: Partial<OnboardingData['securitySettings']>) => void;
  updateBrandingSettings: (settings: Partial<OnboardingData['brandingSettings']>) => void;
  updateAppAccessEntitlements: (entitlements: AppAccessEntitlements) => void;
  markStepComplete: (stepId: number) => void;
  saveDraft: () => void;
  loadDraft: () => boolean;
  clearDraft: () => void;
  activateOrganization: () => void;
  canActivate: () => { canActivate: boolean; issues: string[] };
  getCompletionPercentage: () => number;
}

const OnboardingContext = createContext<OnboardingContextType | null>(null);

export const OnboardingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = useState<OnboardingData>(getInitialData);
  const { toast } = useToast();

  const saveDraft = useCallback(() => {
    const dataToSave = { ...data, lastSavedAt: new Date().toISOString() };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave));
    setData(dataToSave);
    toast({
      title: 'Draft Saved',
      description: 'Your progress has been saved.',
    });
  }, [data, toast]);

  const loadDraft = useCallback((): boolean => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as OnboardingData;
        setData(parsed);
        return true;
      } catch {
        return false;
      }
    }
    return false;
  }, []);

  const clearDraft = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    setData(getInitialData());
  }, []);

  const goToStep = useCallback((stepId: number) => {
    if (stepId >= 1 && stepId <= WIZARD_STEPS.length) {
      setData(prev => ({ ...prev, currentStep: stepId }));
    }
  }, []);

  const nextStep = useCallback(() => {
    setData(prev => ({
      ...prev,
      currentStep: Math.min(prev.currentStep + 1, WIZARD_STEPS.length),
    }));
  }, []);

  const prevStep = useCallback(() => {
    setData(prev => ({
      ...prev,
      currentStep: Math.max(prev.currentStep - 1, 1),
    }));
  }, []);

  const isStepComplete = useCallback((stepId: number) => {
    return data.completedSteps.includes(stepId);
  }, [data.completedSteps]);

  const markStepComplete = useCallback((stepId: number) => {
    setData(prev => ({
      ...prev,
      completedSteps: prev.completedSteps.includes(stepId) 
        ? prev.completedSteps 
        : [...prev.completedSteps, stepId],
    }));
  }, []);

  const updateOrganization = useCallback((org: Partial<OnboardingData['organization']>) => {
    setData(prev => ({
      ...prev,
      organization: { ...prev.organization, ...org },
    }));
  }, []);

  const updateRegulatoryBodies = useCallback((bodies: string[]) => {
    setData(prev => ({ ...prev, regulatoryBodies: bodies }));
  }, []);

  const updateComplianceFrameworks = useCallback((frameworks: string[]) => {
    setData(prev => ({ ...prev, complianceFrameworks: frameworks }));
  }, []);

  const updateTenantSettings = useCallback((settings: Partial<OnboardingData['tenantSettings']>) => {
    setData(prev => ({
      ...prev,
      tenantSettings: { ...prev.tenantSettings, ...settings },
    }));
  }, []);

  const addFacility = useCallback((facility: Omit<Facility, 'id'>) => {
    setData(prev => ({
      ...prev,
      facilities: [...prev.facilities, { ...facility, id: generateId() }],
    }));
  }, []);

  const updateFacility = useCallback((id: string, facility: Partial<Facility>) => {
    setData(prev => ({
      ...prev,
      facilities: prev.facilities.map(f => f.id === id ? { ...f, ...facility } : f),
    }));
  }, []);

  const removeFacility = useCallback((id: string) => {
    setData(prev => ({
      ...prev,
      facilities: prev.facilities.filter(f => f.id !== id),
    }));
  }, []);

  const setSingleFacilityMode = useCallback((enabled: boolean) => {
    setData(prev => {
      if (enabled && prev.facilities.length === 0) {
        const defaultFacility: Facility = {
          id: generateId(),
          name: 'Main Facility',
          code: 'MAIN',
          type: 'Other',
          sameAsOrgAddress: true,
          timeZone: prev.organization.timeZone || 'America/New_York',
          status: 'active',
        };
        return { ...prev, singleFacilityMode: enabled, facilities: [defaultFacility] };
      }
      return { ...prev, singleFacilityMode: enabled };
    });
  }, []);

  const addDepartment = useCallback((department: Omit<Department, 'id'>) => {
    setData(prev => ({
      ...prev,
      departments: [...prev.departments, { ...department, id: generateId() }],
    }));
  }, []);

  const updateDepartment = useCallback((id: string, department: Partial<Department>) => {
    setData(prev => ({
      ...prev,
      departments: prev.departments.map(d => d.id === id ? { ...d, ...department } : d),
    }));
  }, []);

  const removeDepartment = useCallback((id: string) => {
    setData(prev => ({
      ...prev,
      departments: prev.departments.filter(d => d.id !== id),
    }));
  }, []);

  const updateMicroapp = useCallback((id: string, microapp: Partial<Microapp>) => {
    setData(prev => ({
      ...prev,
      microapps: prev.microapps.map(m => m.id === id ? { ...m, ...microapp } : m),
    }));
  }, []);

  const addRole = useCallback((role: Omit<Role, 'id'>) => {
    setData(prev => ({
      ...prev,
      roles: [...prev.roles, { ...role, id: generateId() }],
    }));
  }, []);

  const updateRole = useCallback((id: string, role: Partial<Role>) => {
    setData(prev => ({
      ...prev,
      roles: prev.roles.map(r => r.id === id ? { ...r, ...role } : r),
    }));
  }, []);

  const removeRole = useCallback((id: string) => {
    setData(prev => ({
      ...prev,
      roles: prev.roles.filter(r => r.id !== id),
    }));
  }, []);

  const setCustomRolesEnabled = useCallback((enabled: boolean) => {
    setData(prev => ({ ...prev, customRolesEnabled: enabled }));
  }, []);

  const addUser = useCallback((user: Omit<User, 'id'>) => {
    setData(prev => ({
      ...prev,
      users: [...prev.users, { ...user, id: generateId() }],
    }));
  }, []);

  const updateUser = useCallback((id: string, user: Partial<User>) => {
    setData(prev => ({
      ...prev,
      users: prev.users.map(u => u.id === id ? { ...u, ...user } : u),
    }));
  }, []);

  const removeUser = useCallback((id: string) => {
    setData(prev => ({
      ...prev,
      users: prev.users.filter(u => u.id !== id),
    }));
  }, []);

  const bulkAddUsers = useCallback((users: Omit<User, 'id'>[]) => {
    setData(prev => ({
      ...prev,
      users: [...prev.users, ...users.map(u => ({ ...u, id: generateId() }))],
    }));
  }, []);

  const updateLOVCategory = useCallback((id: string, category: Partial<LOVCategory>) => {
    setData(prev => ({
      ...prev,
      lovCategories: prev.lovCategories.map(c => c.id === id ? { ...c, ...category } : c),
    }));
  }, []);

  const updateSecuritySettings = useCallback((settings: Partial<OnboardingData['securitySettings']>) => {
    setData(prev => ({
      ...prev,
      securitySettings: { ...prev.securitySettings, ...settings },
    }));
  }, []);

  const updateBrandingSettings = useCallback((settings: Partial<OnboardingData['brandingSettings']>) => {
    setData(prev => ({
      ...prev,
      brandingSettings: { ...prev.brandingSettings, ...settings },
    }));
  }, []);

  const updateAppAccessEntitlements = useCallback((entitlements: AppAccessEntitlements) => {
    setData(prev => ({
      ...prev,
      appAccessEntitlements: entitlements,
    }));
  }, []);

  const canActivate = useCallback((): { canActivate: boolean; issues: string[] } => {
    const issues: string[] = [];

    if (!data.organization.name) issues.push('Organization name is required');
    if (!data.organization.orgCode) issues.push('Organization code is required');
    if (!data.organization.primaryContactEmail) issues.push('Primary contact email is required');
    if (data.regulatoryBodies.length === 0) issues.push('At least one regulatory body must be selected');
    if (data.facilities.length === 0) issues.push('At least one facility is required');
    if (data.departments.length === 0) issues.push('At least one department is required');
    if (!data.users.some(u => u.roleIds.some(r => data.roles.find(role => role.id === r)?.type === 'org_admin'))) {
      issues.push('At least one Org Admin user is required');
    }
    if (!data.users.some(u => u.roleIds.some(r => data.roles.find(role => role.id === r)?.type === 'compliance_head'))) {
      issues.push('At least one Compliance Head user is required');
    }

    return { canActivate: issues.length === 0, issues };
  }, [data]);

  const activateOrganization = useCallback(() => {
    const { canActivate: canAct, issues } = canActivate();
    if (!canAct) {
      toast({
        title: 'Cannot Activate',
        description: issues[0],
        variant: 'destructive',
      });
      return;
    }

    setData(prev => ({
      ...prev,
      isActivated: true,
      organization: { ...prev.organization, status: 'active' },
    }));

    localStorage.removeItem(STORAGE_KEY);

    toast({
      title: 'Organization Activated!',
      description: 'Your organization is now active and ready to use.',
    });
  }, [canActivate, toast]);

  const getCompletionPercentage = useCallback(() => {
    const requiredSteps = WIZARD_STEPS.filter(s => s.isRequired).length;
    const completedRequired = data.completedSteps.filter(id => 
      WIZARD_STEPS.find(s => s.id === id)?.isRequired
    ).length;
    return Math.round((completedRequired / requiredSteps) * 100);
  }, [data.completedSteps]);

  // Auto-save on data change (debounced)
  useEffect(() => {
    if (data.lastSavedAt) {
      const timeout = setTimeout(() => {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      }, 1000);
      return () => clearTimeout(timeout);
    }
  }, [data]);

  const value: OnboardingContextType = {
    data,
    currentStep: data.currentStep,
    steps: WIZARD_STEPS,
    isStepComplete,
    goToStep,
    nextStep,
    prevStep,
    updateOrganization,
    updateRegulatoryBodies,
    updateComplianceFrameworks,
    updateTenantSettings,
    addFacility,
    updateFacility,
    removeFacility,
    setSingleFacilityMode,
    addDepartment,
    updateDepartment,
    removeDepartment,
    updateMicroapp,
    addRole,
    updateRole,
    removeRole,
    setCustomRolesEnabled,
    addUser,
    updateUser,
    removeUser,
    bulkAddUsers,
    updateLOVCategory,
    updateSecuritySettings,
    updateBrandingSettings,
    updateAppAccessEntitlements,
    markStepComplete,
    saveDraft,
    loadDraft,
    clearDraft,
    activateOrganization,
    canActivate,
    getCompletionPercentage,
  };

  return (
    <OnboardingContext.Provider value={value}>
      {children}
    </OnboardingContext.Provider>
  );
};

export const useOnboarding = () => {
  const context = useContext(OnboardingContext);
  if (!context) {
    throw new Error('useOnboarding must be used within an OnboardingProvider');
  }
  return context;
};
