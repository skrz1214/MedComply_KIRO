import * as React from "react";
import { Avatar as MuiAvatar, AvatarProps as MuiAvatarProps } from "@mui/material";
import { cn } from "@/lib/utils";

interface AvatarProps extends React.HTMLAttributes<HTMLDivElement> {
  className?: string;
}

const Avatar = React.forwardRef<HTMLDivElement, AvatarProps>(({ className, children, ...props }, ref) => {
  // Extract src and alt from children if AvatarImage is present
  let src: string | undefined;
  let alt: string | undefined;
  let fallbackContent: React.ReactNode = null;

  React.Children.forEach(children, (child) => {
    if (React.isValidElement(child)) {
      if (child.type === AvatarImage) {
        src = child.props.src;
        alt = child.props.alt;
      } else if (child.type === AvatarFallback) {
        fallbackContent = child.props.children;
      }
    }
  });

  return (
    <MuiAvatar
      ref={ref as any}
      src={src}
      alt={alt}
      className={cn("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className)}
      sx={{
        width: 40,
        height: 40,
        bgcolor: src ? "transparent" : "action.selected",
      }}
      {...(props as any)}
    >
      {fallbackContent}
    </MuiAvatar>
  );
});
Avatar.displayName = "Avatar";

interface AvatarImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  className?: string;
}

const AvatarImage = React.forwardRef<HTMLImageElement, AvatarImageProps>(({ className, src, alt, ...props }, ref) => {
  // This component is mainly used for API compatibility
  // The actual image is rendered by the parent Avatar component
  return null;
});
AvatarImage.displayName = "AvatarImage";

interface AvatarFallbackProps extends React.HTMLAttributes<HTMLSpanElement> {
  className?: string;
  delayMs?: number;
}

const AvatarFallback = React.forwardRef<HTMLSpanElement, AvatarFallbackProps>(
  ({ className, children, delayMs, ...props }, ref) => {
    // This component is mainly used for API compatibility
    // The actual fallback is rendered by the parent Avatar component
    return null;
  }
);
AvatarFallback.displayName = "AvatarFallback";

export { Avatar, AvatarImage, AvatarFallback };
