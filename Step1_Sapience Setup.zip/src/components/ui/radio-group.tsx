import * as React from "react";
import {
  RadioGroup as MuiRadioGroup,
  Radio as MuiRadio,
  FormControlLabel,
} from "@mui/material";
import { cn } from "@/lib/utils";

interface RadioGroupContextValue {
  value: string;
  onValueChange: (value: string) => void;
}

const RadioGroupContext = React.createContext<RadioGroupContextValue>({
  value: "",
  onValueChange: () => {},
});

interface RadioGroupProps {
  children: React.ReactNode;
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
  className?: string;
  disabled?: boolean;
  name?: string;
  required?: boolean;
  orientation?: "horizontal" | "vertical";
}

const RadioGroup = React.forwardRef<HTMLDivElement, RadioGroupProps>(
  (
    {
      children,
      defaultValue = "",
      value: controlledValue,
      onValueChange,
      className,
      disabled,
      name,
      required,
      orientation = "vertical",
    },
    ref
  ) => {
    const [uncontrolledValue, setUncontrolledValue] = React.useState(defaultValue);
    const isControlled = controlledValue !== undefined;
    const value = isControlled ? controlledValue : uncontrolledValue;

    const handleValueChange = React.useCallback(
      (newValue: string) => {
        if (!isControlled) {
          setUncontrolledValue(newValue);
        }
        onValueChange?.(newValue);
      },
      [isControlled, onValueChange]
    );

    return (
      <RadioGroupContext.Provider value={{ value, onValueChange: handleValueChange }}>
        <MuiRadioGroup
          ref={ref}
          value={value}
          onChange={(e) => handleValueChange(e.target.value)}
          name={name}
          className={cn("grid gap-2", className)}
          row={orientation === "horizontal"}
          sx={{
            display: "grid",
            gap: 1,
          }}
        >
          {children}
        </MuiRadioGroup>
      </RadioGroupContext.Provider>
    );
  }
);
RadioGroup.displayName = "RadioGroup";

interface RadioGroupItemProps {
  value: string;
  id?: string;
  className?: string;
  disabled?: boolean;
}

const RadioGroupItem = React.forwardRef<HTMLButtonElement, RadioGroupItemProps>(
  ({ value, id, className, disabled }, ref) => {
    const { value: groupValue, onValueChange } = React.useContext(RadioGroupContext);
    const isChecked = groupValue === value;

    return (
      <MuiRadio
        ref={ref as any}
        value={value}
        id={id}
        checked={isChecked}
        disabled={disabled}
        onChange={() => onValueChange(value)}
        className={cn(
          "aspect-square h-4 w-4",
          className
        )}
        sx={{
          padding: 0,
          width: 16,
          height: 16,
          color: "primary.main",
          "&.Mui-checked": {
            color: "primary.main",
          },
          "&.Mui-disabled": {
            opacity: 0.5,
          },
          "& .MuiSvgIcon-root": {
            fontSize: 16,
          },
        }}
        size="small"
      />
    );
  }
);
RadioGroupItem.displayName = "RadioGroupItem";

export { RadioGroup, RadioGroupItem };
