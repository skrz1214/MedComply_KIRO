import * as React from "react";
import { Alert as MuiAlert, AlertTitle as MuiAlertTitle, Typography } from "@mui/material";
import { cn } from "@/lib/utils";

interface AlertProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "default" | "destructive";
}

const Alert = React.forwardRef<HTMLDivElement, AlertProps>(
  ({ className, variant = "default", children, ...props }, ref) => {
    const severity = variant === "destructive" ? "error" : "info";

    return (
      <MuiAlert
        ref={ref}
        severity={severity}
        icon={false}
        className={cn(
          "relative w-full rounded-lg border p-4 [&>svg~*]:pl-7 [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4",
          variant === "default" && "bg-background text-foreground",
          variant === "destructive" && "border-destructive/50 text-destructive",
          className
        )}
        sx={{
          bgcolor: variant === "default" ? "background.paper" : undefined,
          color: variant === "destructive" ? "error.main" : "text.primary",
          border: 1,
          borderColor: variant === "destructive" ? "error.main" : "divider",
          "& .MuiAlert-message": {
            padding: 0,
            width: "100%",
          },
        }}
        role="alert"
        {...(props as any)}
      >
        {children}
      </MuiAlert>
    );
  }
);
Alert.displayName = "Alert";

const AlertTitle = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLHeadingElement>>(
  ({ className, children, ...props }, ref) => (
    <Typography
      ref={ref}
      variant="subtitle2"
      component="h5"
      className={cn("mb-1 font-medium leading-none tracking-tight", className)}
      sx={{ fontWeight: 500, marginBottom: 0.5 }}
      {...props}
    >
      {children}
    </Typography>
  )
);
AlertTitle.displayName = "AlertTitle";

const AlertDescription = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLParagraphElement>>(
  ({ className, children, ...props }, ref) => (
    <Typography
      ref={ref}
      variant="body2"
      component="div"
      className={cn("text-sm [&_p]:leading-relaxed", className)}
      {...props}
    >
      {children}
    </Typography>
  )
);
AlertDescription.displayName = "AlertDescription";

export { Alert, AlertTitle, AlertDescription };
