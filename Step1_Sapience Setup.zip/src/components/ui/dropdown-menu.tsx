import * as React from "react";
import {
  Menu,
  MenuItem,
  MenuList,
  Divider,
  ListItemIcon,
  ListItemText,
  Typography,
  Checkbox as MuiCheckbox,
  Radio as MuiRadio,
  Paper,
  Popper,
  ClickAwayListener,
  Grow,
} from "@mui/material";
import { ChevronRight, Check } from "@mui/icons-material";
import { cn } from "@/lib/utils";

interface DropdownMenuContextValue {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  anchorEl: HTMLElement | null;
  setAnchorEl: (el: HTMLElement | null) => void;
}

const DropdownMenuContext = React.createContext<DropdownMenuContextValue>({
  open: false,
  onOpenChange: () => {},
  anchorEl: null,
  setAnchorEl: () => {},
});

interface DropdownMenuProps {
  children: React.ReactNode;
  open?: boolean;
  defaultOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
}

const DropdownMenu = ({ children, open: controlledOpen, defaultOpen = false, onOpenChange }: DropdownMenuProps) => {
  const [uncontrolledOpen, setUncontrolledOpen] = React.useState(defaultOpen);
  const [anchorEl, setAnchorEl] = React.useState<HTMLElement | null>(null);
  const isControlled = controlledOpen !== undefined;
  const open = isControlled ? controlledOpen : uncontrolledOpen;

  const handleOpenChange = React.useCallback(
    (newOpen: boolean) => {
      if (!isControlled) {
        setUncontrolledOpen(newOpen);
      }
      onOpenChange?.(newOpen);
    },
    [isControlled, onOpenChange]
  );

  return (
    <DropdownMenuContext.Provider value={{ open, onOpenChange: handleOpenChange, anchorEl, setAnchorEl }}>
      {children}
    </DropdownMenuContext.Provider>
  );
};

interface DropdownMenuTriggerProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  asChild?: boolean;
}

const DropdownMenuTrigger = React.forwardRef<HTMLButtonElement, DropdownMenuTriggerProps>(
  ({ children, asChild, onClick, ...props }, ref) => {
    const { onOpenChange, setAnchorEl } = React.useContext(DropdownMenuContext);

    const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
      onClick?.(e);
      setAnchorEl(e.currentTarget);
      onOpenChange(true);
    };

    if (asChild && React.isValidElement(children)) {
      return React.cloneElement(children as React.ReactElement<any>, {
        onClick: handleClick,
        ref,
      });
    }

    return (
      <button ref={ref} onClick={handleClick} {...props}>
        {children}
      </button>
    );
  }
);
DropdownMenuTrigger.displayName = "DropdownMenuTrigger";

const DropdownMenuGroup = ({ children }: { children: React.ReactNode }) => <>{children}</>;

const DropdownMenuPortal = ({ children }: { children: React.ReactNode }) => <>{children}</>;

const DropdownMenuSub = ({ children }: { children: React.ReactNode }) => <>{children}</>;

interface RadioGroupContextValue {
  value: string;
  onValueChange: (value: string) => void;
}

const RadioGroupContext = React.createContext<RadioGroupContextValue>({
  value: "",
  onValueChange: () => {},
});

interface DropdownMenuRadioGroupProps {
  children: React.ReactNode;
  value?: string;
  onValueChange?: (value: string) => void;
}

const DropdownMenuRadioGroup = ({ children, value = "", onValueChange }: DropdownMenuRadioGroupProps) => (
  <RadioGroupContext.Provider value={{ value, onValueChange: onValueChange || (() => {}) }}>
    {children}
  </RadioGroupContext.Provider>
);

interface DropdownMenuSubTriggerProps extends React.HTMLAttributes<HTMLLIElement> {
  inset?: boolean;
}

const DropdownMenuSubTrigger = React.forwardRef<HTMLLIElement, DropdownMenuSubTriggerProps>(
  ({ className, inset, children, ...props }, ref) => (
    <MenuItem
      ref={ref}
      className={cn(
        "flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none",
        inset && "pl-8",
        className
      )}
      sx={{
        fontSize: "0.875rem",
        borderRadius: "4px",
        "&:hover": { bgcolor: "action.hover" },
      }}
      {...(props as any)}
    >
      {children}
      <ChevronRight sx={{ ml: "auto", fontSize: "1rem" }} />
    </MenuItem>
  )
);
DropdownMenuSubTrigger.displayName = "DropdownMenuSubTrigger";

const DropdownMenuSubContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, children, ...props }, ref) => (
    <Paper
      ref={ref}
      elevation={8}
      className={cn("z-50 min-w-[8rem] overflow-hidden rounded-md border p-1", className)}
      sx={{
        bgcolor: "background.paper",
        border: 1,
        borderColor: "divider",
      }}
      {...props}
    >
      <MenuList sx={{ padding: 0 }}>{children}</MenuList>
    </Paper>
  )
);
DropdownMenuSubContent.displayName = "DropdownMenuSubContent";

interface DropdownMenuContentProps extends React.HTMLAttributes<HTMLDivElement> {
  sideOffset?: number;
  align?: "start" | "center" | "end";
}

const DropdownMenuContent = React.forwardRef<HTMLDivElement, DropdownMenuContentProps>(
  ({ className, children, sideOffset = 4, align = "start", ...props }, ref) => {
    const { open, onOpenChange, anchorEl } = React.useContext(DropdownMenuContext);

    return (
      <Popper
        open={open}
        anchorEl={anchorEl}
        placement={align === "end" ? "bottom-end" : align === "center" ? "bottom" : "bottom-start"}
        transition
        style={{ zIndex: 1300 }}
      >
        {({ TransitionProps }) => (
          <Grow {...TransitionProps}>
            <Paper
              ref={ref}
              elevation={8}
              className={cn("z-50 min-w-[8rem] overflow-hidden rounded-md border p-1", className)}
              sx={{
                bgcolor: "background.paper",
                border: 1,
                borderColor: "divider",
                mt: `${sideOffset}px`,
              }}
              {...props}
            >
              <ClickAwayListener onClickAway={() => onOpenChange(false)}>
                <MenuList sx={{ padding: 0 }}>{children}</MenuList>
              </ClickAwayListener>
            </Paper>
          </Grow>
        )}
      </Popper>
    );
  }
);
DropdownMenuContent.displayName = "DropdownMenuContent";

interface DropdownMenuItemProps extends React.HTMLAttributes<HTMLLIElement> {
  inset?: boolean;
  disabled?: boolean;
}

const DropdownMenuItem = React.forwardRef<HTMLLIElement, DropdownMenuItemProps>(
  ({ className, inset, disabled, onClick, ...props }, ref) => {
    const { onOpenChange } = React.useContext(DropdownMenuContext);

    const handleClick = (e: React.MouseEvent<HTMLLIElement>) => {
      if (!disabled) {
        onClick?.(e as any);
        onOpenChange(false);
      }
    };

    return (
      <MenuItem
        ref={ref}
        disabled={disabled}
        onClick={handleClick}
        className={cn(
          "relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none transition-colors",
          inset && "pl-8",
          className
        )}
        sx={{
          fontSize: "0.875rem",
          borderRadius: "4px",
          "&:hover": { bgcolor: "action.hover" },
          "&.Mui-disabled": { opacity: 0.5 },
        }}
        {...(props as any)}
      />
    );
  }
);
DropdownMenuItem.displayName = "DropdownMenuItem";

interface DropdownMenuCheckboxItemProps extends React.HTMLAttributes<HTMLLIElement> {
  checked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
  disabled?: boolean;
}

const DropdownMenuCheckboxItem = React.forwardRef<HTMLLIElement, DropdownMenuCheckboxItemProps>(
  ({ className, children, checked, onCheckedChange, disabled, ...props }, ref) => (
    <MenuItem
      ref={ref}
      disabled={disabled}
      onClick={() => onCheckedChange?.(!checked)}
      className={cn(
        "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors",
        className
      )}
      sx={{
        fontSize: "0.875rem",
        borderRadius: "4px",
        "&:hover": { bgcolor: "action.hover" },
      }}
      {...(props as any)}
    >
      <ListItemIcon sx={{ minWidth: 24, position: "absolute", left: 8 }}>
        {checked && <Check fontSize="small" />}
      </ListItemIcon>
      {children}
    </MenuItem>
  )
);
DropdownMenuCheckboxItem.displayName = "DropdownMenuCheckboxItem";

interface DropdownMenuRadioItemProps extends React.HTMLAttributes<HTMLLIElement> {
  value: string;
  disabled?: boolean;
}

const DropdownMenuRadioItem = React.forwardRef<HTMLLIElement, DropdownMenuRadioItemProps>(
  ({ className, children, value, disabled, ...props }, ref) => {
    const { value: groupValue, onValueChange } = React.useContext(RadioGroupContext);
    const isSelected = groupValue === value;

    return (
      <MenuItem
        ref={ref}
        disabled={disabled}
        onClick={() => onValueChange(value)}
        className={cn(
          "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors",
          className
        )}
        sx={{
          fontSize: "0.875rem",
          borderRadius: "4px",
          "&:hover": { bgcolor: "action.hover" },
        }}
        {...(props as any)}
      >
        <ListItemIcon sx={{ minWidth: 24, position: "absolute", left: 8 }}>
          {isSelected && (
            <span
              style={{
                width: 8,
                height: 8,
                borderRadius: "50%",
                backgroundColor: "currentColor",
              }}
            />
          )}
        </ListItemIcon>
        {children}
      </MenuItem>
    );
  }
);
DropdownMenuRadioItem.displayName = "DropdownMenuRadioItem";

interface DropdownMenuLabelProps extends React.HTMLAttributes<HTMLDivElement> {
  inset?: boolean;
}

const DropdownMenuLabel = React.forwardRef<HTMLDivElement, DropdownMenuLabelProps>(
  ({ className, inset, ...props }, ref) => (
    <Typography
      ref={ref}
      variant="caption"
      component="div"
      className={cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className)}
      sx={{ fontWeight: 600, fontSize: "0.875rem", color: "text.primary" }}
      {...props}
    />
  )
);
DropdownMenuLabel.displayName = "DropdownMenuLabel";

const DropdownMenuSeparator = React.forwardRef<HTMLHRElement, React.HTMLAttributes<HTMLHRElement>>(
  ({ className, ...props }, ref) => (
    <Divider ref={ref} className={cn("-mx-1 my-1", className)} sx={{ mx: -0.5, my: 0.5 }} {...props} />
  )
);
DropdownMenuSeparator.displayName = "DropdownMenuSeparator";

const DropdownMenuShortcut = ({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) => (
  <Typography
    component="span"
    variant="caption"
    className={cn("ml-auto text-xs tracking-widest opacity-60", className)}
    sx={{ ml: "auto", fontSize: "0.75rem", opacity: 0.6 }}
    {...props}
  />
);
DropdownMenuShortcut.displayName = "DropdownMenuShortcut";

export {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuGroup,
  DropdownMenuPortal,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuRadioGroup,
};
