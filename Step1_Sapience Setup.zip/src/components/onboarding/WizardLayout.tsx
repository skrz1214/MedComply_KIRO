import React from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { WizardSidebar } from './WizardSidebar';
import { WizardHeader } from './WizardHeader';
import { WizardStepContent } from './WizardStepContent';

export const WizardLayout: React.FC = () => {
  const { currentStep, data } = useOnboarding();

  if (data.isActivated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-8">
          <div className="w-20 h-20 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="text-3xl font-heading font-bold text-foreground mb-4">
            Organization Activated!
          </h1>
          <p className="text-muted-foreground mb-8">
            {data.organization.name} is now active and ready to use. You can access the Master Compliance Dashboard to get started.
          </p>
          <button
            onClick={() => window.location.href = '/dashboard'}
            className="inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground font-medium rounded-lg hover:bg-primary/90 transition-colors"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      <WizardSidebar />
      <div className="flex-1 flex flex-col min-h-screen">
        <WizardHeader />
        <main className="flex-1 overflow-auto p-6 lg:p-8">
          <div className="max-w-4xl mx-auto animate-fade-in">
            <WizardStepContent step={currentStep} />
          </div>
        </main>
      </div>
    </div>
  );
};
