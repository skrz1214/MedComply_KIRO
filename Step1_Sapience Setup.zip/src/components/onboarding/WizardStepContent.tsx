import React from 'react';
import { OrganizationStep } from './steps/OrganizationStep';
import { RecommendedSetupStep } from './steps/RecommendedSetupStep';
import { TenantStep } from './steps/TenantStep';
import { FacilitiesStep } from './steps/FacilitiesStep';
import { MicroappsStep } from './steps/MicroappsStep';
import { RolesStep } from './steps/RolesStep';
import { AppAccessStep } from './steps/AppAccessStep';
import { UsersStep } from './steps/UsersStep';
import { LOVStep } from './steps/LOVStep';
import { SecurityStep } from './steps/SecurityStep';
import { BrandingStep } from './steps/BrandingStep';
import { ReviewStep } from './steps/ReviewStep';
import { PRDStep } from './steps/PRDStep';
import { TDDStep } from './steps/TDDStep';
import { QATestStep } from './steps/QATestStep';
import { UATTestStep } from './steps/UATTestStep';
import { PromptStep } from './steps/PromptStep';

interface WizardStepContentProps {
  step: number;
}

export const WizardStepContent: React.FC<WizardStepContentProps> = ({ step }) => {
  switch (step) {
    case 1:
      return <OrganizationStep />;
    case 2:
      return <RecommendedSetupStep />;
    case 3:
      return <TenantStep />;
    case 4:
      return <FacilitiesStep />;
    case 5:
      return <MicroappsStep />;
    case 6:
      return <RolesStep />;
    case 7:
      return <AppAccessStep />;
    case 8:
      return <UsersStep />;
    case 9:
      return <LOVStep />;
    case 10:
      return <SecurityStep />;
    case 11:
      return <BrandingStep />;
    case 12:
      return <ReviewStep />;
    case 13:
      return <PRDStep />;
    case 14:
      return <TDDStep />;
    case 15:
      return <QATestStep />;
    case 16:
      return <UATTestStep />;
    case 17:
      return <PromptStep />;
    default:
      return <div>Unknown step</div>;
  }
};
