import React, { useState } from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Check, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import medcomplyLogo from '@/assets/medcomply-logo.png';

// Group steps into logical phases for pizza-tracker experience
const PHASES = [
  { 
    id: 'foundation', 
    name: 'Foundation', 
    steps: [1, 2, 3],
    description: 'Organization & licensing'
  },
  { 
    id: 'structure', 
    name: 'Structure', 
    steps: [4, 5, 6],
    description: 'Facilities, apps & roles'
  },
  { 
    id: 'people', 
    name: 'People & Data', 
    steps: [7, 8, 9],
    description: 'Access, users & values'
  },
  { 
    id: 'finalize', 
    name: 'Finalize', 
    steps: [10, 11, 12],
    description: 'Security, branding & review'
  },
  { 
    id: 'documentation', 
    name: 'Documentation', 
    steps: [13, 14, 15, 16, 17],
    description: 'PRD, TDD, tests & prompt'
  },
];

export const WizardSidebar: React.FC = () => {
  const { steps, currentStep, isStepComplete, goToStep, data, getCompletionPercentage } = useOnboarding();
  const [expandedPhases, setExpandedPhases] = useState<Set<string>>(() => {
    // Initially expand the phase containing current step
    const currentPhase = PHASES.find(p => p.steps.includes(currentStep));
    return new Set(currentPhase ? [currentPhase.id] : ['foundation']);
  });

  const getPhaseStatus = (phase: typeof PHASES[0]) => {
    const allComplete = phase.steps.every(stepId => isStepComplete(stepId));
    const anyComplete = phase.steps.some(stepId => isStepComplete(stepId));
    const isCurrent = phase.steps.includes(currentStep);
    
    if (allComplete) return 'complete';
    if (isCurrent) return 'current';
    if (anyComplete) return 'partial';
    return 'pending';
  };

  const getPhaseProgress = (phase: typeof PHASES[0]) => {
    const completed = phase.steps.filter(stepId => isStepComplete(stepId)).length;
    return Math.round((completed / phase.steps.length) * 100);
  };

  const togglePhase = (phaseId: string) => {
    setExpandedPhases(prev => {
      const next = new Set(prev);
      if (next.has(phaseId)) {
        next.delete(phaseId);
      } else {
        next.add(phaseId);
      }
      return next;
    });
  };

  const handleStepClick = (stepId: number) => {
    goToStep(stepId);
  };

  const completedStepsCount = steps.filter(s => isStepComplete(s.id)).length;

  return (
    <aside className="wizard-sidebar w-72 lg:w-80 flex-shrink-0 flex flex-col bg-sidebar">
      {/* Logo and Title */}
      <div className="p-5 border-b border-sidebar-border">
        <img 
          src={medcomplyLogo} 
          alt="MedComply Logo" 
          className="h-12 w-auto object-contain"
        />
      </div>

      {/* Pizza Tracker Progress */}
      <div className="px-5 py-4 border-b border-sidebar-border">
        {/* Overall Progress */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-sidebar-foreground">{completedStepsCount}</span>
            <span className="text-sm text-sidebar-foreground/60">of {steps.length} steps</span>
          </div>
          <div className="text-right">
            <span className="text-lg font-semibold text-sidebar-primary">{getCompletionPercentage()}%</span>
          </div>
        </div>

        {/* Phase Tracker - Horizontal Pills */}
        <div className="flex gap-1">
          {PHASES.map((phase) => {
            const status = getPhaseStatus(phase);
            const progress = getPhaseProgress(phase);
            
            return (
              <div 
                key={phase.id} 
                className="flex-1"
              >
                {/* Progress Bar Segment */}
                <div className="h-2 rounded-full overflow-hidden transition-all duration-300 bg-sidebar-accent">
                  <div 
                    className={cn(
                      "h-full transition-all duration-500 rounded-full bg-sidebar-primary",
                      status === 'pending' && "bg-transparent",
                    )}
                    style={{ width: status === 'pending' ? '0%' : `${progress}%` }}
                  />
                </div>
                
                {/* Phase Label */}
                <p className={cn(
                  "text-[10px] mt-1.5 text-center font-medium transition-colors",
                  status === 'current' && "text-sidebar-primary",
                  status === 'complete' && "text-sidebar-primary",
                  status === 'partial' && "text-sidebar-foreground/70",
                  status === 'pending' && "text-sidebar-foreground/40"
                )}>
                  {phase.name}
                </p>
              </div>
            );
          })}
        </div>

        {data.lastSavedAt && (
          <p className="text-[10px] text-sidebar-foreground/40 mt-3 text-center">
            Saved {new Date(data.lastSavedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </p>
        )}
      </div>

      {/* Steps by Phase */}
      <nav className="flex-1 overflow-y-auto scrollbar-thin">
        {PHASES.map((phase) => {
          const phaseStatus = getPhaseStatus(phase);
          const isExpanded = expandedPhases.has(phase.id);
          
          return (
            <div key={phase.id} className="border-b border-sidebar-border/50 last:border-b-0">
              {/* Phase Header - Clickable to toggle */}
              <button
                type="button"
                onClick={() => togglePhase(phase.id)}
                className={cn(
                  "w-full px-5 py-3 flex items-center gap-3 text-left transition-colors",
                  "hover:bg-sidebar-accent/30 cursor-pointer",
                  phaseStatus === 'current' && "bg-sidebar-primary/5"
                )}
              >
                <div className={cn(
                  "w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold transition-all flex-shrink-0",
                  phaseStatus === 'complete' && "bg-sidebar-primary text-sidebar-primary-foreground",
                  phaseStatus === 'current' && "bg-sidebar-primary text-sidebar-primary-foreground ring-2 ring-sidebar-primary/30 ring-offset-1 ring-offset-sidebar",
                  phaseStatus === 'partial' && "bg-sidebar-primary/20 text-sidebar-primary",
                  phaseStatus === 'pending' && "bg-sidebar-accent text-sidebar-foreground/50"
                )}>
                  {phaseStatus === 'complete' ? (
                    <Check className="w-3.5 h-3.5" />
                  ) : (
                    <span>{PHASES.indexOf(phase) + 1}</span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className={cn(
                    "text-sm font-medium",
                    phaseStatus === 'current' && "text-sidebar-foreground",
                    phaseStatus === 'complete' && "text-sidebar-foreground",
                    phaseStatus === 'partial' && "text-sidebar-foreground/80",
                    phaseStatus === 'pending' && "text-sidebar-foreground/50"
                  )}>
                    {phase.name}
                  </p>
                  <p className="text-[10px] text-sidebar-foreground/40">{phase.description}</p>
                </div>
                <ChevronDown className={cn(
                  "w-4 h-4 text-sidebar-foreground/40 transition-transform flex-shrink-0",
                  isExpanded && "rotate-180"
                )} />
              </button>

              {/* Phase Steps - Expandable */}
              {isExpanded && (
                <ul className="px-3 pb-3 space-y-1">
                  {phase.steps.map((stepId) => {
                    const step = steps.find(s => s.id === stepId);
                    if (!step) return null;
                    
                    const isComplete = isStepComplete(step.id);
                    const isCurrent = currentStep === step.id;

                    return (
                      <li key={step.id}>
                        <button
                          type="button"
                          onClick={() => handleStepClick(step.id)}
                          className={cn(
                            "w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-left transition-all duration-200 cursor-pointer",
                            isCurrent && "bg-sidebar-primary/15",
                            !isCurrent && "hover:bg-sidebar-accent/50"
                          )}
                        >
                          {/* Step Indicator */}
                          <div className={cn(
                            "w-5 h-5 rounded-full flex items-center justify-center transition-all flex-shrink-0",
                            isComplete && "bg-sidebar-primary text-sidebar-primary-foreground",
                            isCurrent && !isComplete && "border-2 border-sidebar-primary bg-sidebar-primary/10",
                            !isComplete && !isCurrent && "border border-sidebar-foreground/20"
                          )}>
                            {isComplete ? (
                              <Check className="w-3 h-3" />
                            ) : isCurrent ? (
                              <div className="w-2 h-2 rounded-full bg-sidebar-primary" />
                            ) : null}
                          </div>
                          
                          {/* Step Name */}
                          <span className={cn(
                            "flex-1 text-sm transition-colors",
                            isCurrent && "font-medium text-sidebar-foreground",
                            isComplete && !isCurrent && "text-sidebar-foreground/70",
                            !isComplete && !isCurrent && "text-sidebar-foreground/50"
                          )}>
                            {step.shortName}
                          </span>

                          {/* Optional Badge */}
                          {!step.isRequired && (
                            <span className="text-[9px] text-sidebar-foreground/40 bg-sidebar-accent px-1.5 py-0.5 rounded flex-shrink-0">
                              Optional
                            </span>
                          )}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-sidebar-border bg-sidebar-accent/30">
        <p className="text-[10px] text-sidebar-foreground/40 text-center">
          Sapience Technology • MedComply v1.0
        </p>
      </div>
    </aside>
  );
};
