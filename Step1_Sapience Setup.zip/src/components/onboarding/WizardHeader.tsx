import React from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Button } from '@/components/ui/button';
import { Save, ArrowLeft, ArrowRight, HelpCircle } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';

export const WizardHeader: React.FC = () => {
  const { 
    steps, 
    currentStep, 
    prevStep, 
    nextStep, 
    saveDraft,
    data 
  } = useOnboarding();

  const currentStepData = steps.find(s => s.id === currentStep);
  const isFirstStep = currentStep === 1;
  const isLastStep = currentStep === steps.length;

  return (
    <header className="bg-card border-b border-border px-6 lg:px-8 py-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between gap-4">
          {/* Step Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <span>Step {currentStep} of {steps.length}</span>
              {currentStepData && !currentStepData.isRequired && (
                <span className="px-2 py-0.5 rounded-full bg-muted text-xs">Optional</span>
              )}
            </div>
            <h2 className="text-xl lg:text-2xl font-heading font-semibold text-foreground truncate">
              {currentStepData?.name}
            </h2>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="text-muted-foreground">
                  <HelpCircle className="w-5 h-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom">
                <p className="max-w-xs">{currentStepData?.description}</p>
              </TooltipContent>
            </Tooltip>

            <Button
              variant="outline"
              onClick={saveDraft}
              className="hidden sm:flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              Save Draft
            </Button>

            <div className="flex items-center gap-1 ml-2">
              <Button
                variant="outline"
                size="icon"
                onClick={prevStep}
                disabled={isFirstStep}
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <Button
                variant={isLastStep ? "default" : "outline"}
                size="icon"
                onClick={nextStep}
                disabled={isLastStep}
              >
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
