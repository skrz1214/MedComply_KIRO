import React from 'react';
import { SecurityFormSection, SystemEnforcedBox } from './SecurityCard';
import { FieldTooltip, SECURITY_TOOLTIPS } from './SecurityTooltips';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { EncryptionConfig } from '@/types/securityBaseline';
import { Lock, Shield, FileCheck } from 'lucide-react';

interface EncryptionCardContentProps {
  config: EncryptionConfig;
  onChange: (updates: Partial<EncryptionConfig>) => void;
}

export const EncryptionCardContent: React.FC<EncryptionCardContentProps> = ({
  config,
  onChange,
}) => {
  const tips = SECURITY_TOOLTIPS.encryption;

  return (
    <div className="space-y-6">
      {/* 6.1 Encryption in Transit */}
      <SecurityFormSection 
        title="Encryption in Transit" 
        description="HIPAA: Transmission Security (164.312(e)(1))"
      >
        <div className="space-y-3">
          <div className="flex items-center gap-1 mb-2">
            <FieldTooltip content={tips.tlsRequired} />
          </div>
          <SystemEnforcedBox message="TLS required for all web and API traffic" />
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <Lock className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm font-medium">Block Non-TLS Callbacks/Webhooks</Label>
                  <FieldTooltip content={tips.blockNonTls} />
                </div>
                <p className="text-xs text-muted-foreground">
                  Reject any webhook or callback that doesn't use HTTPS
                </p>
              </div>
            </div>
            <Switch
              checked={config.blockNonTlsCallbacks}
              onCheckedChange={(v) => onChange({ blockNonTlsCallbacks: v })}
            />
          </div>
        </div>
      </SecurityFormSection>

      {/* 6.2 Encryption at Rest */}
      <SecurityFormSection 
        title="Encryption at Rest" 
        description="How stored data is encrypted"
      >
        <div className="flex items-center gap-1 mb-3">
          <FieldTooltip content={tips.encryptionAtRest} />
        </div>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 rounded-lg border-2 border-primary/30 bg-primary/5">
            <div className="flex items-start gap-3">
              <Shield className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <div className="flex items-center gap-2">
                  <Label className="text-sm font-medium">Platform-Managed Encryption Keys</Label>
                  <Badge variant="secondary" className="text-xs">Active</Badge>
                </div>
                <p className="text-xs text-muted-foreground">
                  Keys managed by the platform with automatic rotation
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between p-4 rounded-lg border border-border opacity-60">
            <div className="flex items-start gap-3">
              <Shield className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div>
                <div className="flex items-center gap-2">
                  <Label className="text-sm font-medium text-muted-foreground">Customer-Managed Keys (CMK)</Label>
                  <Badge variant="outline" className="text-xs">Enterprise</Badge>
                </div>
                <p className="text-xs text-muted-foreground">
                  Bring your own encryption keys (requires Enterprise license)
                </p>
              </div>
            </div>
          </div>
        </div>
      </SecurityFormSection>

      {/* 6.3 Integrity Protection */}
      <SecurityFormSection 
        title="Integrity Protection" 
        description="HIPAA: Integrity (164.312(c)(1))"
      >
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <FileCheck className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm font-medium">Integrity Checks for Uploaded Evidence</Label>
                  <FieldTooltip content={tips.integrityChecks} />
                </div>
                <p className="text-xs text-muted-foreground">
                  Verify uploaded files haven't been tampered with
                </p>
              </div>
            </div>
            <Switch
              checked={config.integrityChecksEnabled}
              onCheckedChange={(v) => onChange({ integrityChecksEnabled: v })}
            />
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <FileCheck className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm font-medium">File Hashing</Label>
                  <FieldTooltip content={tips.fileHashing} />
                </div>
                <p className="text-xs text-muted-foreground">
                  Generate cryptographic hashes for all uploaded files
                </p>
              </div>
            </div>
            <Switch
              checked={config.fileHashingEnabled}
              onCheckedChange={(v) => onChange({ fileHashingEnabled: v })}
            />
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <FileCheck className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm font-medium">Tamper-Evident Audit Trail</Label>
                  <FieldTooltip content={tips.tamperEvident} />
                </div>
                <p className="text-xs text-muted-foreground">
                  Track all changes to evidence with immutable logs
                </p>
              </div>
            </div>
            <Switch
              checked={config.tamperEvidentAuditTrail}
              onCheckedChange={(v) => onChange({ tamperEvidentAuditTrail: v })}
            />
          </div>
        </div>
      </SecurityFormSection>
    </div>
  );
};
