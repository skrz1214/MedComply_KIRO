import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ChevronDown, ChevronUp, Shield, Info } from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface SecurityCardProps {
  title: string;
  description: string;
  hipaaCategory?: string;
  hipaaStandards?: string[];
  isRequired?: boolean;
  isExpanded?: boolean;
  onToggle?: () => void;
  children: React.ReactNode;
  icon?: React.ReactNode;
}

export const SecurityCard: React.FC<SecurityCardProps> = ({
  title,
  description,
  hipaaCategory,
  hipaaStandards,
  isRequired = true,
  isExpanded = false,
  onToggle,
  children,
  icon,
}) => {
  return (
    <Card className={cn(
      "border transition-all duration-200",
      isExpanded ? "border-primary/30 shadow-md" : "border-border"
    )}>
      <Collapsible open={isExpanded} onOpenChange={onToggle}>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-primary/10 text-primary mt-0.5">
                  {icon || <Shield className="h-5 w-5" />}
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <CardTitle className="text-base font-semibold">{title}</CardTitle>
                    {isRequired && (
                      <Badge variant="secondary" className="text-xs">Required</Badge>
                    )}
                    {!isRequired && (
                      <Badge variant="outline" className="text-xs">Optional</Badge>
                    )}
                  </div>
                  <CardDescription className="text-sm">{description}</CardDescription>
                  {hipaaCategory && hipaaStandards && (
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <div className="flex items-center gap-1.5 mt-1">
                            <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800">
                              HIPAA: {hipaaCategory}
                            </Badge>
                            <Info className="h-3.5 w-3.5 text-muted-foreground" />
                          </div>
                        </TooltipTrigger>
                        <TooltipContent side="bottom" className="max-w-xs">
                          <p className="font-medium mb-1">HIPAA Standards:</p>
                          <ul className="text-xs space-y-0.5">
                            {hipaaStandards.map((std, i) => (
                              <li key={i}>• {std}</li>
                            ))}
                          </ul>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  )}
                </div>
              </div>
              <div className="p-1">
                {isExpanded ? (
                  <ChevronUp className="h-5 w-5 text-muted-foreground" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-muted-foreground" />
                )}
              </div>
            </div>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="pt-0 pb-6">
            <div className="border-t pt-4">
              {children}
            </div>
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
};

// Helper component for form sections within cards
interface SecurityFormSectionProps {
  title: string;
  description?: string;
  children: React.ReactNode;
}

export const SecurityFormSection: React.FC<SecurityFormSectionProps> = ({
  title,
  description,
  children,
}) => {
  return (
    <div className="space-y-3">
      <div>
        <h4 className="text-sm font-medium text-foreground">{title}</h4>
        {description && (
          <p className="text-xs text-muted-foreground mt-0.5">{description}</p>
        )}
      </div>
      {children}
    </div>
  );
};

// System-enforced info box
interface SystemEnforcedBoxProps {
  message: string;
}

export const SystemEnforcedBox: React.FC<SystemEnforcedBoxProps> = ({ message }) => {
  return (
    <div className="flex items-center gap-2 p-3 rounded-lg bg-green-50 border border-green-200 dark:bg-green-950 dark:border-green-800">
      <Shield className="h-4 w-4 text-green-600 dark:text-green-400 flex-shrink-0" />
      <span className="text-sm text-green-800 dark:text-green-200">{message}</span>
      <Badge variant="outline" className="ml-auto text-xs bg-green-100 text-green-700 border-green-300 dark:bg-green-900 dark:text-green-300 dark:border-green-700">
        Always ON
      </Badge>
    </div>
  );
};
