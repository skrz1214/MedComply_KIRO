import React from 'react';
import { SecurityFormSection } from './SecurityCard';
import { FieldTooltip, SECURITY_TOOLTIPS } from './SecurityTooltips';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { IncidentContactsConfig, IncidentContact } from '@/types/securityBaseline';
import { User, Bell, Mail, MessageSquare } from 'lucide-react';

interface IncidentContactsCardContentProps {
  config: IncidentContactsConfig;
  onChange: (updates: Partial<IncidentContactsConfig>) => void;
  complianceHeadEmail?: string;
}

export const IncidentContactsCardContent: React.FC<IncidentContactsCardContentProps> = ({
  config,
  onChange,
  complianceHeadEmail,
}) => {
  const tips = SECURITY_TOOLTIPS.incidentContacts;

  const updateSecurityContact = (updates: Partial<IncidentContact>) => {
    onChange({
      securityContact: { ...config.securityContact, ...updates },
    });
  };

  const updateComplianceContact = (updates: Partial<IncidentContact>) => {
    onChange({
      complianceContact: { ...config.complianceContact, ...updates },
    });
  };

  return (
    <div className="space-y-6">
      {/* Required Contacts */}
      <SecurityFormSection 
        title="Security & Compliance Contacts" 
        description="Primary contacts for security incidents"
      >
        <div className="space-y-4">
          {/* Security Contact */}
          <div className="p-4 rounded-lg border border-border space-y-3">
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-primary" />
              <Label className="text-sm font-medium">Security/Privacy Contact</Label>
              <FieldTooltip content={tips.securityContact} />
              <span className="text-xs text-destructive">*Required</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <Label className="text-xs text-muted-foreground">Name</Label>
                <Input 
                  placeholder="Contact name"
                  value={config.securityContact.name}
                  onChange={(e) => updateSecurityContact({ name: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Email</Label>
                <Input 
                  type="email"
                  placeholder="security@org.com"
                  value={config.securityContact.email}
                  onChange={(e) => updateSecurityContact({ email: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Phone (optional)</Label>
                <Input 
                  type="tel"
                  placeholder="+1-555-0123"
                  value={config.securityContact.phone || ''}
                  onChange={(e) => updateSecurityContact({ phone: e.target.value })}
                  className="mt-1"
                />
              </div>
            </div>
          </div>

          {/* Compliance Contact */}
          <div className="p-4 rounded-lg border border-border space-y-3">
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-primary" />
              <Label className="text-sm font-medium">Compliance Head Contact</Label>
              <FieldTooltip content={tips.complianceContact} />
              {complianceHeadEmail && (
                <span className="text-xs text-muted-foreground">(Pre-filled from Users step)</span>
              )}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <Label className="text-xs text-muted-foreground">Name</Label>
                <Input 
                  placeholder="Contact name"
                  value={config.complianceContact.name}
                  onChange={(e) => updateComplianceContact({ name: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Email</Label>
                <Input 
                  type="email"
                  placeholder="compliance@org.com"
                  value={config.complianceContact.email || complianceHeadEmail || ''}
                  onChange={(e) => updateComplianceContact({ email: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Phone (optional)</Label>
                <Input 
                  type="tel"
                  placeholder="+1-555-0123"
                  value={config.complianceContact.phone || ''}
                  onChange={(e) => updateComplianceContact({ phone: e.target.value })}
                  className="mt-1"
                />
              </div>
            </div>
          </div>
        </div>
      </SecurityFormSection>

      {/* Notification Triggers */}
      <SecurityFormSection 
        title="Security Notifications" 
        description="Automatic alerts for security events"
      >
        <div className="space-y-3">
          <div className="flex items-center gap-2 mb-2">
            <Bell className="h-4 w-4 text-muted-foreground" />
            <Label className="text-sm font-medium">Notify On</Label>
            <FieldTooltip content={tips.notifications} />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            <div className="flex items-center justify-between p-3 rounded-lg border border-border">
              <div className="flex items-center gap-1">
                <Label className="text-sm">Repeated Failed Logins</Label>
                <FieldTooltip content={tips.failedLogins} />
              </div>
              <Switch
                checked={config.notifyOnRepeatedFailedLogins}
                onCheckedChange={(v) => onChange({ notifyOnRepeatedFailedLogins: v })}
              />
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg border border-border">
              <div className="flex items-center gap-1">
                <Label className="text-sm">Admin Role Changes</Label>
                <FieldTooltip content={tips.roleChanges} />
              </div>
              <Switch
                checked={config.notifyOnAdminRoleChanges}
                onCheckedChange={(v) => onChange({ notifyOnAdminRoleChanges: v })}
              />
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg border border-border">
              <div className="flex items-center gap-1">
                <Label className="text-sm">Large Export Events</Label>
                <FieldTooltip content={tips.largeExports} />
              </div>
              <Switch
                checked={config.notifyOnLargeExports}
                onCheckedChange={(v) => onChange({ notifyOnLargeExports: v })}
              />
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg border border-border">
              <div className="flex items-center gap-1">
                <Label className="text-sm">Break-Glass Usage</Label>
                <FieldTooltip content={tips.breakGlassNotify} />
              </div>
              <Switch
                checked={config.notifyOnBreakGlassUsage}
                onCheckedChange={(v) => onChange({ notifyOnBreakGlassUsage: v })}
              />
            </div>
          </div>
        </div>
      </SecurityFormSection>

      {/* Delivery Channels */}
      <SecurityFormSection 
        title="Delivery Channels" 
        description="How notifications are delivered"
      >
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center space-x-2 p-3 rounded-lg border border-border">
            <Switch
              id="notify-email"
              checked={config.notifyViaEmail}
              onCheckedChange={(v) => onChange({ notifyViaEmail: v })}
            />
            <Mail className="h-4 w-4 text-muted-foreground" />
            <Label htmlFor="notify-email" className="text-sm cursor-pointer">Email</Label>
          </div>
          <div className="flex items-center space-x-2 p-3 rounded-lg border border-border">
            <Switch
              id="notify-inapp"
              checked={config.notifyViaInApp}
              onCheckedChange={(v) => onChange({ notifyViaInApp: v })}
            />
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
            <Label htmlFor="notify-inapp" className="text-sm cursor-pointer">In-App</Label>
          </div>
        </div>
      </SecurityFormSection>
    </div>
  );
};
