import React from 'react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { HelpCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FieldTooltipProps {
  content: string;
  side?: 'top' | 'right' | 'bottom' | 'left';
  className?: string;
}

export const FieldTooltip: React.FC<FieldTooltipProps> = ({ content, side = 'top', className }) => {
  return (
    <TooltipProvider>
      <Tooltip delayDuration={300}>
        <TooltipTrigger asChild>
          <HelpCircle className={cn("h-3.5 w-3.5 text-muted-foreground hover:text-foreground cursor-help inline-flex ml-1", className)} />
        </TooltipTrigger>
        <TooltipContent side={side} className="max-w-xs text-sm">
          <p>{content}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

// Security field tooltips organized by section
export const SECURITY_TOOLTIPS = {
  // Identity & Authentication
  identityAuth: {
    authMode: "Choose between Single Sign-On (SSO) using your organization's identity provider, or local login with email and password. SSO is recommended for better security and easier management.",
    idpType: "SAML 2.0 is the traditional enterprise standard. OpenID Connect (OIDC) is more modern and easier to configure with cloud providers.",
    allowedDomains: "Restrict which email domains can authenticate. Only users with email addresses matching these domains will be allowed to log in.",
    jitProvisioning: "Just-in-time provisioning automatically creates user accounts when someone logs in for the first time via SSO, eliminating manual user creation.",
    passwordMinLength: "NIST SP 800-63B recommends a minimum of 8 characters, but 12+ is preferred for better security against brute-force attacks.",
    passwordComplexity: "Requiring multiple character types (uppercase, lowercase, numbers, symbols) makes passwords harder to guess.",
    passwordLockout: "Temporarily locks accounts after failed attempts to prevent brute-force attacks. Balance security with user convenience.",
    passwordExpiry: "How often users must change passwords. NIST now recommends against forced rotation unless there's evidence of compromise.",
    mfaRequired: "Multi-factor authentication adds a second layer of security. 'Admin only' requires MFA for privileged accounts; 'All users' provides stronger protection.",
    mfaMethods: "Authenticator apps (TOTP) are more secure than SMS, which is vulnerable to SIM-swapping attacks.",
    recoveryCodes: "One-time backup codes allow account recovery if the primary MFA method is lost. Essential for preventing lockouts.",
    uniqueUserId: "HIPAA requires each user have a unique identifier. Shared accounts prevent proper audit trails and are not allowed.",
    emergencyAccess: "Break-glass procedures allow temporary elevated access during emergencies. All usage is logged and cannot be disabled.",
    emergencyDuration: "Shorter durations (1-2 hours) minimize risk exposure during emergency access.",
    emergencyJustification: "Requiring a reason creates accountability and helps with post-incident review.",
  },

  // Access Control
  accessControl: {
    rbac: "Role-Based Access Control assigns permissions based on job functions rather than individuals, simplifying management and improving security.",
    preventSelfApproval: "Separation of duties: users cannot approve their own work, reducing fraud risk and ensuring oversight.",
    adminReauth: "Requiring MFA for sensitive admin actions prevents unauthorized changes if a session is compromised.",
    inactiveDisable: "HIPAA requires disabling dormant accounts. 60 days is a common baseline; stricter environments use 30 days.",
    terminatedDisable: "Immediate access revocation when staff leave prevents unauthorized access to PHI.",
    roleChangeAudit: "All permission changes are logged for compliance and security investigations.",
  },

  // Session Controls
  sessionControls: {
    idleTimeout: "HIPAA Technical Safeguard: Automatic logoff after inactivity. 30 minutes is common; healthcare workstations may use 15 minutes.",
    absoluteSession: "Maximum session duration regardless of activity. Prevents indefinitely open sessions that could be exploited.",
    managedDevices: "Restricting access to organization-managed devices ensures proper security configurations and endpoint protection.",
    unsupportedBrowsers: "Blocking outdated browsers prevents exploitation of known security vulnerabilities.",
  },

  // Encryption
  encryption: {
    tlsRequired: "HIPAA Transmission Security: All data in transit must be encrypted using TLS 1.2 or higher.",
    blockNonTls: "Prevents integration with insecure external services that could expose PHI.",
    encryptionAtRest: "HIPAA requires PHI to be encrypted when stored. Platform-managed keys are simpler; customer-managed keys offer more control.",
    integrityChecks: "Verifies files haven't been modified since upload, detecting tampering or corruption.",
    fileHashing: "Creates a cryptographic fingerprint of each file for integrity verification.",
    tamperEvident: "Immutable audit trail that cannot be altered, providing evidence of any unauthorized changes.",
  },

  // Audit Logging
  auditLogging: {
    eventCategories: "Select which types of activities to log. More categories provide better visibility but increase storage costs.",
    authentication: "Login attempts, logouts, MFA events, and password changes.",
    authorization: "Permission grants, role changes, and access modifications.",
    adminConfig: "System settings changes, policy updates, and configuration modifications.",
    dataChanges: "Create, update, and delete operations on records containing PHI.",
    evidenceHandling: "Upload, download, and access of attached documents and files.",
    exports: "Data exports in any format, critical for tracking potential data exfiltration.",
    breakGlass: "Emergency access usage - always logged regardless of settings.",
    apiTokens: "Token creation, rotation, and revocation for programmatic access.",
    activeRetention: "How long logs are searchable in real-time. Longer retention aids investigations but costs more.",
    archivedRetention: "Total retention period including cold storage. HIPAA requires 6 years; some organizations keep 7.",
    exportAuditLog: "Who can export audit data. Restrict to prevent unauthorized access to sensitive activity records.",
    auditViewers: "Which roles can view the audit trail. Balance transparency with need-to-know.",
  },

  // Export Controls
  exportControls: {
    roleExports: "Control which roles can export data and their scope. Staff typically have no export rights; managers have department-level access.",
    exportReason: "Requiring a justification creates accountability and helps detect unauthorized data extraction.",
    watermark: "Adding user/timestamp watermarks to exports helps trace the source of any leaked documents.",
  },

  // Network Controls
  networkControls: {
    ipAllowlist: "Restrict access to specific IP ranges. Useful for office-only access but can lock out remote workers.",
    lockoutPrevention: "Emergency contact method to regain access if all admins are locked out by IP restrictions.",
    apiTokens: "Enable programmatic access for integrations. Disable if not needed to reduce attack surface.",
    tokenRotation: "Regular key rotation limits the impact of compromised credentials.",
  },

  // Incident Contacts
  incidentContacts: {
    securityContact: "Primary contact for security incidents, breach notifications, and vulnerability reports. Required for HIPAA compliance.",
    complianceContact: "Compliance officer contact for regulatory inquiries and audit coordination.",
    notifications: "Automated alerts for security events help detect and respond to incidents quickly.",
    failedLogins: "Alert on repeated failures which may indicate brute-force attacks.",
    roleChanges: "Alert on privilege changes which could indicate unauthorized access.",
    largeExports: "Alert on bulk data exports which could indicate data theft.",
    breakGlassNotify: "Alert when emergency access is used for immediate review.",
  },

  // Governance Attestations
  governanceAttestations: {
    accessManagement: "Commitment to properly manage user lifecycle, including prompt access revocation when staff leave.",
    auditMonitoring: "Acknowledgment that all system activity is logged and may be reviewed.",
    ssoMfaConfig: "Commitment to configure authentication consistent with organizational security policies.",
    baa: "Business Associate Agreement - required contract between covered entities and their service providers under HIPAA.",
  },
};
