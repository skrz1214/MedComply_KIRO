import React from 'react';
import { SecurityFormSection } from './SecurityCard';
import { FieldTooltip, SECURITY_TOOLTIPS } from './SecurityTooltips';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { ExportControlsConfig } from '@/types/securityBaseline';
import { Download, FileText } from 'lucide-react';

interface ExportControlsCardContentProps {
  config: ExportControlsConfig;
  onChange: (updates: Partial<ExportControlsConfig>) => void;
}

export const ExportControlsCardContent: React.FC<ExportControlsCardContentProps> = ({
  config,
  onChange,
}) => {
  const tips = SECURITY_TOOLTIPS.exportControls;

  const roleExports = [
    { 
      key: 'staff', 
      name: 'Staff', 
      enabled: config.staffExportsAllowed, 
      scope: 'N/A',
      setEnabled: (v: boolean) => onChange({ staffExportsAllowed: v }),
    },
    { 
      key: 'deptHead', 
      name: 'Department Head', 
      enabled: config.departmentHeadExportsAllowed, 
      scope: 'Department',
      setEnabled: (v: boolean) => onChange({ departmentHeadExportsAllowed: v }),
    },
    { 
      key: 'complianceHead', 
      name: 'Compliance Head', 
      enabled: config.complianceHeadExportsAllowed, 
      scope: 'Organization',
      setEnabled: (v: boolean) => onChange({ complianceHeadExportsAllowed: v }),
    },
    { 
      key: 'orgAdmin', 
      name: 'Org Admin', 
      enabled: config.orgAdminExportsAllowed, 
      scope: 'Organization',
      setEnabled: (v: boolean) => onChange({ orgAdminExportsAllowed: v }),
    },
  ];

  return (
    <div className="space-y-6">
      {/* Role-based Export Policy */}
      <SecurityFormSection 
        title="Role-Based Export Policy" 
        description="Control which roles can export data and their scope"
      >
        <div className="flex items-center gap-1 mb-3">
          <FieldTooltip content={tips.roleExports} />
        </div>
        <div className="space-y-2">
          {roleExports.map((role) => (
            <div 
              key={role.key}
              className="flex items-center justify-between p-3 rounded-lg border border-border"
            >
              <div className="flex items-center gap-3">
                <Download className="h-4 w-4 text-muted-foreground" />
                <div>
                  <Label className="text-sm font-medium">{role.name}</Label>
                  {role.enabled && (
                    <Badge variant="secondary" className="ml-2 text-xs">{role.scope}</Badge>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">
                  {role.enabled ? 'Allowed' : 'Disabled'}
                </span>
                <Switch
                  checked={role.enabled}
                  onCheckedChange={role.setEnabled}
                />
              </div>
            </div>
          ))}
        </div>
      </SecurityFormSection>

      {/* Export Safeguards */}
      <SecurityFormSection 
        title="Export Safeguards" 
        description="Additional controls for data exports"
      >
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <FileText className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm font-medium">Require Export Reason</Label>
                  <FieldTooltip content={tips.exportReason} />
                </div>
                <p className="text-xs text-muted-foreground">
                  Users must provide a reason for org-scoped exports
                </p>
              </div>
            </div>
            <Switch
              checked={config.requireExportReason}
              onCheckedChange={(v) => onChange({ requireExportReason: v })}
            />
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <FileText className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm font-medium">Watermark Exports</Label>
                  <FieldTooltip content={tips.watermark} />
                </div>
                <p className="text-xs text-muted-foreground">
                  Add user/timestamp watermark to exported files
                </p>
              </div>
            </div>
            <Switch
              checked={config.watermarkExports}
              onCheckedChange={(v) => onChange({ watermarkExports: v })}
            />
          </div>
        </div>
      </SecurityFormSection>
    </div>
  );
};
