import React from 'react';
import { SecurityFormSection } from './SecurityCard';
import { FieldTooltip, SECURITY_TOOLTIPS } from './SecurityTooltips';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { SessionControlsConfig, IdleTimeoutOption, SessionMaxDuration } from '@/types/securityBaseline';
import { Clock, Monitor } from 'lucide-react';

interface SessionControlsCardContentProps {
  config: SessionControlsConfig;
  onChange: (updates: Partial<SessionControlsConfig>) => void;
}

export const SessionControlsCardContent: React.FC<SessionControlsCardContentProps> = ({
  config,
  onChange,
}) => {
  const tips = SECURITY_TOOLTIPS.sessionControls;

  return (
    <div className="space-y-6">
      {/* 5.1 Automatic Logoff / Session Timeout */}
      <SecurityFormSection 
        title="Automatic Logoff" 
        description="HIPAA Technical Safeguard: Automatic session termination"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <Label className="text-sm">Idle Timeout</Label>
              <FieldTooltip content={tips.idleTimeout} />
            </div>
            <Select 
              value={config.idleTimeoutMinutes.toString()}
              onValueChange={(v) => onChange({ idleTimeoutMinutes: parseInt(v) as IdleTimeoutOption })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="15">15 minutes (Strict)</SelectItem>
                <SelectItem value="30">30 minutes (Default)</SelectItem>
                <SelectItem value="60">60 minutes</SelectItem>
                <SelectItem value="120">120 minutes</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-1">
              Logout after this period of inactivity
            </p>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <Label className="text-sm">Absolute Session Max</Label>
              <FieldTooltip content={tips.absoluteSession} />
            </div>
            <Select 
              value={config.absoluteSessionMaxHours.toString()}
              onValueChange={(v) => onChange({ absoluteSessionMaxHours: parseInt(v) as SessionMaxDuration })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="8">8 hours (Strict)</SelectItem>
                <SelectItem value="12">12 hours (Default)</SelectItem>
                <SelectItem value="24">24 hours</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-1">
              Force logout after this duration regardless of activity
            </p>
          </div>
        </div>
      </SecurityFormSection>

      {/* 5.2 Device / Browser Constraints */}
      <SecurityFormSection 
        title="Device & Browser Constraints" 
        description="Optional restrictions for enhanced security"
      >
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <Monitor className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm font-medium">Restrict to Managed Devices</Label>
                  <FieldTooltip content={tips.managedDevices} />
                </div>
                <p className="text-xs text-muted-foreground">
                  Only allow access from organization-managed devices (Enterprise)
                </p>
              </div>
            </div>
            <Switch
              checked={config.restrictToManagedDevices}
              onCheckedChange={(v) => onChange({ restrictToManagedDevices: v })}
              disabled
            />
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <Monitor className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm font-medium">Block Unsupported Browsers</Label>
                  <FieldTooltip content={tips.unsupportedBrowsers} />
                </div>
                <p className="text-xs text-muted-foreground">
                  Deny access from outdated or unsupported web browsers
                </p>
              </div>
            </div>
            <Switch
              checked={config.blockUnsupportedBrowsers}
              onCheckedChange={(v) => onChange({ blockUnsupportedBrowsers: v })}
            />
          </div>
        </div>
      </SecurityFormSection>
    </div>
  );
};
