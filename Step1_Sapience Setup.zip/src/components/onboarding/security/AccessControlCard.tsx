import React from 'react';
import { SecurityFormSection, SystemEnforcedBox } from './SecurityCard';
import { FieldTooltip, SECURITY_TOOLTIPS } from './SecurityTooltips';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { AccessControlConfig, InactiveDisableWindow } from '@/types/securityBaseline';
import { ShieldCheck, Users } from 'lucide-react';

interface AccessControlCardContentProps {
  config: AccessControlConfig;
  onChange: (updates: Partial<AccessControlConfig>) => void;
  roles?: Array<{ name: string; type: string }>;
}

export const AccessControlCardContent: React.FC<AccessControlCardContentProps> = ({
  config,
  onChange,
}) => {
  const tips = SECURITY_TOOLTIPS.accessControl;
  
  const systemRoles = [
    { name: 'Staff', type: 'staff', scope: 'Self' },
    { name: 'Department Head', type: 'department_head', scope: 'Department' },
    { name: 'Compliance Head', type: 'compliance_head', scope: 'Organization' },
    { name: 'Org Admin', type: 'org_admin', scope: 'Organization + Config' },
  ];

  return (
    <div className="space-y-6">
      {/* 4.1 RBAC Model Summary (read-only) */}
      <SecurityFormSection 
        title="Role-Based Access Control (RBAC)" 
        description="Summary of configured roles and their scope"
      >
        <div className="p-4 rounded-lg bg-muted/30 border border-border">
          <div className="flex items-center gap-2 mb-3">
            <Users className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium">System Roles</span>
            <FieldTooltip content={tips.rbac} />
            <Badge variant="outline" className="text-xs">Read-only</Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {systemRoles.map((role) => (
              <div 
                key={role.type}
                className="flex items-center justify-between p-2 rounded bg-background border border-border"
              >
                <span className="text-sm">{role.name}</span>
                <Badge variant="secondary" className="text-xs">{role.scope}</Badge>
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-3">
            App access and dashboard entitlements are configured in the App Access step.
          </p>
        </div>
      </SecurityFormSection>

      {/* 4.2 Least Privilege Guardrails */}
      <SecurityFormSection 
        title="Least Privilege Guardrails" 
        description="Controls to prevent privilege escalation"
      >
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <ShieldCheck className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm font-medium">Prevent Self-Approval</Label>
                  <FieldTooltip content={tips.preventSelfApproval} />
                </div>
                <p className="text-xs text-muted-foreground">
                  Users cannot approve their own submissions or changes
                </p>
              </div>
            </div>
            <Switch
              checked={config.preventSelfApproval}
              onCheckedChange={(v) => onChange({ preventSelfApproval: v })}
            />
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <ShieldCheck className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm font-medium">Admin Changes Require Re-auth</Label>
                  <FieldTooltip content={tips.adminReauth} />
                </div>
                <p className="text-xs text-muted-foreground">
                  MFA prompt required for sensitive admin operations
                </p>
              </div>
            </div>
            <Switch
              checked={config.adminChangesRequireReauth}
              onCheckedChange={(v) => onChange({ adminChangesRequireReauth: v })}
            />
          </div>
        </div>
      </SecurityFormSection>

      {/* 4.3 Account Lifecycle */}
      <SecurityFormSection 
        title="Account Lifecycle" 
        description="Automatic handling of inactive and terminated accounts"
      >
        <div className="space-y-4">
          <div>
            <div className="flex items-center gap-1 mb-2">
              <Label className="text-sm">Disable Inactive Accounts After</Label>
              <FieldTooltip content={tips.inactiveDisable} />
            </div>
            <Select 
              value={config.inactiveAccountDisableDays.toString()}
              onValueChange={(v) => onChange({ inactiveAccountDisableDays: parseInt(v) as InactiveDisableWindow })}
            >
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30">30 days</SelectItem>
                <SelectItem value="60">60 days (Default)</SelectItem>
                <SelectItem value="90">90 days</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div>
              <div className="flex items-center gap-1">
                <Label className="text-sm font-medium">Disable Terminated Users Immediately</Label>
                <FieldTooltip content={tips.terminatedDisable} />
              </div>
              <p className="text-xs text-muted-foreground">
                Automatically disable access when user status is set to terminated
              </p>
            </div>
            <Switch
              checked={config.terminatedUserDisableImmediately}
              onCheckedChange={(v) => onChange({ terminatedUserDisableImmediately: v })}
            />
          </div>
          <div className="flex items-center gap-1">
            <FieldTooltip content={tips.roleChangeAudit} />
          </div>
          <SystemEnforcedBox message="All role changes are automatically logged in the audit trail." />
        </div>
      </SecurityFormSection>
    </div>
  );
};
