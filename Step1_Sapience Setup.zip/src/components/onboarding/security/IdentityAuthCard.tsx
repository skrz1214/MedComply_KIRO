import React from 'react';
import { SecurityFormSection, SystemEnforcedBox } from './SecurityCard';
import { FieldTooltip, SECURITY_TOOLTIPS } from './SecurityTooltips';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { IdentityAuthConfig, AuthMode, MfaPolicy, MfaMethod } from '@/types/securityBaseline';

interface IdentityAuthCardContentProps {
  config: IdentityAuthConfig;
  onChange: (updates: Partial<IdentityAuthConfig>) => void;
}

export const IdentityAuthCardContent: React.FC<IdentityAuthCardContentProps> = ({
  config,
  onChange,
}) => {
  const tips = SECURITY_TOOLTIPS.identityAuth;

  return (
    <div className="space-y-6">
      {/* 3.1 Authentication Mode */}
      <SecurityFormSection 
        title="Authentication Mode" 
        description="Choose how users will authenticate to the system"
      >
        <div className="flex items-center gap-1 mb-2">
          <span className="text-sm font-medium">Select authentication method</span>
          <FieldTooltip content={tips.authMode} />
        </div>
        <RadioGroup
          value={config.authMode}
          onValueChange={(v) => onChange({ authMode: v as AuthMode })}
          className="space-y-3"
        >
          <div className="flex items-start space-x-3 p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors">
            <RadioGroupItem value="sso" id="auth-sso" className="mt-1" />
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <Label htmlFor="auth-sso" className="font-medium cursor-pointer">SSO (SAML/OIDC)</Label>
                <Badge variant="secondary" className="text-xs">Recommended</Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">
                Single Sign-On via your organization's identity provider
              </p>
            </div>
          </div>
          <div className="flex items-start space-x-3 p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors">
            <RadioGroupItem value="local" id="auth-local" className="mt-1" />
            <div className="flex-1">
              <Label htmlFor="auth-local" className="font-medium cursor-pointer">Local Login (Email + Password)</Label>
              <p className="text-xs text-muted-foreground mt-0.5">
                Users create accounts with email and password
              </p>
            </div>
          </div>
        </RadioGroup>

        {/* SSO-specific options */}
        {config.authMode === 'sso' && (
          <div className="mt-4 p-4 rounded-lg bg-muted/50 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm">IdP Type</Label>
                  <FieldTooltip content={tips.idpType} />
                </div>
                <Select 
                  value={config.idpType || 'saml'} 
                  onValueChange={(v) => onChange({ idpType: v as 'saml' | 'oidc' })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="saml">SAML 2.0</SelectItem>
                    <SelectItem value="oidc">OpenID Connect (OIDC)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm">Allowed Domain(s)</Label>
                  <FieldTooltip content={tips.allowedDomains} />
                </div>
                <Input 
                  placeholder="e.g., org.com, health.org"
                  value={config.allowedDomains.join(', ')}
                  onChange={(e) => onChange({ 
                    allowedDomains: e.target.value.split(',').map(d => d.trim()).filter(Boolean) 
                  })}
                  className="mt-1"
                />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1">
                <Label className="text-sm">Just-in-time Provisioning</Label>
                <FieldTooltip content={tips.jitProvisioning} />
                <p className="text-xs text-muted-foreground ml-2">Auto-create accounts on first login</p>
              </div>
              <Switch
                checked={config.jitProvisioningEnabled}
                onCheckedChange={(v) => onChange({ jitProvisioningEnabled: v })}
              />
            </div>
          </div>
        )}

        {/* Local login-specific options */}
        {config.authMode === 'local' && (
          <div className="mt-4 p-4 rounded-lg bg-muted/50 space-y-4">
            <div className="flex items-center gap-1">
              <p className="text-sm font-medium">Password Policy</p>
              <FieldTooltip content={tips.passwordComplexity} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm">Minimum Length</Label>
                  <FieldTooltip content={tips.passwordMinLength} />
                </div>
                <Input 
                  type="number" 
                  min={8} 
                  max={32}
                  value={config.passwordMinLength}
                  onChange={(e) => onChange({ passwordMinLength: parseInt(e.target.value) || 12 })}
                  className="mt-1"
                />
              </div>
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm">Password Expiry (days)</Label>
                  <FieldTooltip content={tips.passwordExpiry} />
                </div>
                <Input 
                  type="number" 
                  min={30} 
                  max={365}
                  value={config.passwordExpiryDays}
                  onChange={(e) => onChange({ passwordExpiryDays: parseInt(e.target.value) || 90 })}
                  className="mt-1"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="pw-upper"
                  checked={config.passwordRequireUppercase}
                  onCheckedChange={(v) => onChange({ passwordRequireUppercase: !!v })}
                />
                <Label htmlFor="pw-upper" className="text-xs cursor-pointer">Uppercase</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="pw-lower"
                  checked={config.passwordRequireLowercase}
                  onCheckedChange={(v) => onChange({ passwordRequireLowercase: !!v })}
                />
                <Label htmlFor="pw-lower" className="text-xs cursor-pointer">Lowercase</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="pw-number"
                  checked={config.passwordRequireNumbers}
                  onCheckedChange={(v) => onChange({ passwordRequireNumbers: !!v })}
                />
                <Label htmlFor="pw-number" className="text-xs cursor-pointer">Numbers</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="pw-special"
                  checked={config.passwordRequireSpecial}
                  onCheckedChange={(v) => onChange({ passwordRequireSpecial: !!v })}
                />
                <Label htmlFor="pw-special" className="text-xs cursor-pointer">Special</Label>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm">Lockout after failed attempts</Label>
                  <FieldTooltip content={tips.passwordLockout} />
                </div>
                <Input 
                  type="number" 
                  min={3} 
                  max={10}
                  value={config.passwordLockoutAttempts}
                  onChange={(e) => onChange({ passwordLockoutAttempts: parseInt(e.target.value) || 5 })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label className="text-sm">Lockout Duration (minutes)</Label>
                <Input 
                  type="number" 
                  min={5} 
                  max={60}
                  value={config.passwordLockoutDuration}
                  onChange={(e) => onChange({ passwordLockoutDuration: parseInt(e.target.value) || 30 })}
                  className="mt-1"
                />
              </div>
            </div>
          </div>
        )}
      </SecurityFormSection>

      {/* 3.2 MFA Policy */}
      <SecurityFormSection 
        title="Multi-Factor Authentication (MFA)" 
        description="Require additional verification for enhanced security"
      >
        <div className="space-y-4">
          <div>
            <div className="flex items-center gap-1 mb-2">
              <Label className="text-sm">MFA Required For</Label>
              <FieldTooltip content={tips.mfaRequired} />
            </div>
            <RadioGroup
              value={config.mfaRequired}
              onValueChange={(v) => onChange({ mfaRequired: v as MfaPolicy })}
              className="flex flex-wrap gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="admin_only" id="mfa-admin" />
                <Label htmlFor="mfa-admin" className="text-sm cursor-pointer">Admin roles only</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="all_users" id="mfa-all" />
                <Label htmlFor="mfa-all" className="text-sm cursor-pointer">All users</Label>
                <Badge variant="outline" className="text-xs">Strict</Badge>
              </div>
            </RadioGroup>
          </div>
          <div>
            <div className="flex items-center gap-1 mb-2">
              <Label className="text-sm">Allowed MFA Methods</Label>
              <FieldTooltip content={tips.mfaMethods} />
            </div>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="mfa-auth"
                  checked={config.mfaAllowedMethods.includes('authenticator')}
                  onCheckedChange={(v) => {
                    const methods = v 
                      ? [...config.mfaAllowedMethods, 'authenticator' as MfaMethod]
                      : config.mfaAllowedMethods.filter(m => m !== 'authenticator');
                    onChange({ mfaAllowedMethods: methods });
                  }}
                />
                <Label htmlFor="mfa-auth" className="text-sm cursor-pointer">Authenticator App</Label>
                <Badge variant="secondary" className="text-xs">Recommended</Badge>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="mfa-sms"
                  checked={config.mfaAllowedMethods.includes('sms')}
                  onCheckedChange={(v) => {
                    const methods = v 
                      ? [...config.mfaAllowedMethods, 'sms' as MfaMethod]
                      : config.mfaAllowedMethods.filter(m => m !== 'sms');
                    onChange({ mfaAllowedMethods: methods });
                  }}
                />
                <Label htmlFor="mfa-sms" className="text-sm cursor-pointer">SMS</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="mfa-email"
                  checked={config.mfaAllowedMethods.includes('email')}
                  onCheckedChange={(v) => {
                    const methods = v 
                      ? [...config.mfaAllowedMethods, 'email' as MfaMethod]
                      : config.mfaAllowedMethods.filter(m => m !== 'email');
                    onChange({ mfaAllowedMethods: methods });
                  }}
                />
                <Label htmlFor="mfa-email" className="text-sm cursor-pointer">Email</Label>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div className="flex items-center gap-1">
              <Label className="text-sm">Recovery Codes</Label>
              <FieldTooltip content={tips.recoveryCodes} />
              <p className="text-xs text-muted-foreground ml-2">Enable backup codes for admin users</p>
            </div>
            <Switch
              checked={config.recoveryCodesEnabled}
              onCheckedChange={(v) => onChange({ recoveryCodesEnabled: v })}
            />
          </div>
        </div>
      </SecurityFormSection>

      {/* 3.3 Unique User Identification */}
      <SecurityFormSection title="Unique User Identification">
        <div className="flex items-center gap-1 mb-2">
          <FieldTooltip content={tips.uniqueUserId} />
        </div>
        <SystemEnforcedBox message="Each user must have a unique identity; shared accounts are not allowed." />
      </SecurityFormSection>

      {/* 3.4 Break-glass Admin Access */}
      <SecurityFormSection 
        title="Emergency Access Procedure" 
        description="Break-glass access for critical situations"
      >
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div className="flex items-center gap-1">
              <Label className="text-sm">Enable Emergency Access</Label>
              <FieldTooltip content={tips.emergencyAccess} />
              <p className="text-xs text-muted-foreground ml-2">Allow time-bound emergency admin access</p>
            </div>
            <Switch
              checked={config.emergencyAccessEnabled}
              onCheckedChange={(v) => onChange({ emergencyAccessEnabled: v })}
            />
          </div>
          {config.emergencyAccessEnabled && (
            <div className="p-4 rounded-lg bg-muted/50 space-y-4">
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm">Time-bound Access Duration (hours)</Label>
                  <FieldTooltip content={tips.emergencyDuration} />
                </div>
                <Select 
                  value={config.emergencyAccessDuration.toString()}
                  onValueChange={(v) => onChange({ emergencyAccessDuration: parseInt(v) })}
                >
                  <SelectTrigger className="mt-1 w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 hour</SelectItem>
                    <SelectItem value="2">2 hours</SelectItem>
                    <SelectItem value="4">4 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Label className="text-sm">Require Justification</Label>
                  <FieldTooltip content={tips.emergencyJustification} />
                  <p className="text-xs text-muted-foreground ml-2">Users must provide a reason for emergency access</p>
                </div>
                <Switch
                  checked={config.emergencyAccessRequiresJustification}
                  onCheckedChange={(v) => onChange({ emergencyAccessRequiresJustification: v })}
                />
              </div>
              <div className="p-2 rounded bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800">
                <p className="text-xs text-amber-800 dark:text-amber-200">
                  ⚠️ Break-glass access is always audited and cannot be disabled.
                </p>
              </div>
            </div>
          )}
        </div>
      </SecurityFormSection>
    </div>
  );
};
