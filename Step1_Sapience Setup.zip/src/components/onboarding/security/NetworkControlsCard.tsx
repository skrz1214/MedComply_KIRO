import React from 'react';
import { SecurityFormSection } from './SecurityCard';
import { FieldTooltip, SECURITY_TOOLTIPS } from './SecurityTooltips';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { NetworkControlsConfig, TokenRotationDays } from '@/types/securityBaseline';
import { Globe, Key, AlertTriangle } from 'lucide-react';

interface NetworkControlsCardContentProps {
  config: NetworkControlsConfig;
  onChange: (updates: Partial<NetworkControlsConfig>) => void;
}

export const NetworkControlsCardContent: React.FC<NetworkControlsCardContentProps> = ({
  config,
  onChange,
}) => {
  const tips = SECURITY_TOOLTIPS.networkControls;

  return (
    <div className="space-y-6">
      {/* IP Allowlist */}
      <SecurityFormSection 
        title="IP Allowlist" 
        description="Restrict access to specific IP ranges"
      >
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <Globe className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm font-medium">Enable IP Allowlist</Label>
                  <FieldTooltip content={tips.ipAllowlist} />
                </div>
                <p className="text-xs text-muted-foreground">
                  Only allow access from specified IP addresses
                </p>
              </div>
            </div>
            <Switch
              checked={config.ipAllowlistEnabled}
              onCheckedChange={(v) => onChange({ ipAllowlistEnabled: v })}
            />
          </div>
          
          {config.ipAllowlistEnabled && (
            <div className="p-4 rounded-lg bg-muted/50 space-y-4">
              <div className="p-3 rounded bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-amber-800 dark:text-amber-200">Admin Lockout Prevention</p>
                    <p className="text-xs text-amber-700 dark:text-amber-300 mt-0.5">
                      Ensure you have a recovery method if you're locked out due to IP restrictions.
                    </p>
                  </div>
                </div>
              </div>
              <div>
                <Label className="text-sm">Allowed IP Ranges (CIDR notation)</Label>
                <Input 
                  placeholder="e.g., 192.168.1.0/24, 10.0.0.0/8"
                  value={config.ipAllowlistCidrs.join(', ')}
                  onChange={(e) => onChange({ 
                    ipAllowlistCidrs: e.target.value.split(',').map(ip => ip.trim()).filter(Boolean) 
                  })}
                  className="mt-1"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Comma-separated list of IP ranges
                </p>
              </div>
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm">Lockout Prevention Contact</Label>
                  <FieldTooltip content={tips.lockoutPrevention} />
                </div>
                <Input 
                  placeholder="e.g., admin@org.com or +1-555-0123"
                  value={config.lockoutPreventionContact}
                  onChange={(e) => onChange({ lockoutPreventionContact: e.target.value })}
                  className="mt-1"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Emergency contact method to regain access
                </p>
              </div>
            </div>
          )}
        </div>
      </SecurityFormSection>

      {/* API Access Controls */}
      <SecurityFormSection 
        title="API Access Controls" 
        description="Manage programmatic access to the system"
      >
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <Key className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div>
                <div className="flex items-center gap-2">
                  <Label className="text-sm font-medium">Enable API Tokens</Label>
                  <FieldTooltip content={tips.apiTokens} />
                  <Badge variant="outline" className="text-xs">Optional</Badge>
                </div>
                <p className="text-xs text-muted-foreground">
                  Allow creation of API tokens for integrations
                </p>
              </div>
            </div>
            <Switch
              checked={config.apiTokensEnabled}
              onCheckedChange={(v) => onChange({ apiTokensEnabled: v })}
            />
          </div>
          
          {config.apiTokensEnabled && (
            <div className="p-4 rounded-lg bg-muted/50">
              <div>
                <div className="flex items-center gap-1">
                  <Label className="text-sm">Token Rotation Reminder</Label>
                  <FieldTooltip content={tips.tokenRotation} />
                </div>
                <Select 
                  value={config.tokenRotationReminderDays.toString()}
                  onValueChange={(v) => onChange({ tokenRotationReminderDays: parseInt(v) as TokenRotationDays })}
                >
                  <SelectTrigger className="mt-1 w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 days</SelectItem>
                    <SelectItem value="60">60 days</SelectItem>
                    <SelectItem value="90">90 days</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground mt-1">
                  Remind admins to rotate tokens after this period
                </p>
              </div>
            </div>
          )}
        </div>
      </SecurityFormSection>
    </div>
  );
};
