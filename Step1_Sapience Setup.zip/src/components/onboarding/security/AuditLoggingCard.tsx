import React from 'react';
import { SecurityFormSection, SystemEnforcedBox } from './SecurityCard';
import { FieldTooltip, SECURITY_TOOLTIPS } from './SecurityTooltips';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AuditLoggingConfig, ActiveRetentionDays, ArchivedRetentionYears } from '@/types/securityBaseline';
import { ScrollText, Clock, Eye } from 'lucide-react';

interface AuditLoggingCardContentProps {
  config: AuditLoggingConfig;
  onChange: (updates: Partial<AuditLoggingConfig>) => void;
}

export const AuditLoggingCardContent: React.FC<AuditLoggingCardContentProps> = ({
  config,
  onChange,
}) => {
  const tips = SECURITY_TOOLTIPS.auditLogging;

  const updateEventCategory = (key: keyof AuditLoggingConfig['eventCategories'], value: boolean) => {
    onChange({
      eventCategories: {
        ...config.eventCategories,
        [key]: value,
      },
    });
  };

  const updateAuditViewer = (key: keyof AuditLoggingConfig['auditViewers'], value: boolean) => {
    onChange({
      auditViewers: {
        ...config.auditViewers,
        [key]: value,
      },
    });
  };

  const eventCategories = [
    { key: 'authentication', label: 'Authentication Events', description: 'Login, logout, failed login, MFA', tooltip: tips.authentication },
    { key: 'authorization', label: 'Authorization/Role Changes', description: 'Permission and role modifications', tooltip: tips.authorization },
    { key: 'adminConfig', label: 'Admin Configuration Changes', description: 'System settings modifications', tooltip: tips.adminConfig },
    { key: 'dataChanges', label: 'Data Create/Update/Delete', description: 'Record-level changes', tooltip: tips.dataChanges },
    { key: 'evidenceUploadDownload', label: 'Evidence Upload/Download', description: 'File handling activities', tooltip: tips.evidenceHandling },
    { key: 'exports', label: 'Exports (CSV/PDF/JSON)', description: 'Data export events', tooltip: tips.exports },
    { key: 'breakGlassAccess', label: 'Break-Glass Access Usage', description: 'Emergency access events', tooltip: tips.breakGlass },
    { key: 'apiTokens', label: 'API Token Events', description: 'Token creation and rotation', tooltip: tips.apiTokens },
  ] as const;

  return (
    <div className="space-y-6">
      {/* 7.1 Audit Logging */}
      <SecurityFormSection 
        title="Audit Logging" 
        description="HIPAA: Audit Controls (164.312(b))"
      >
        <div className="space-y-4">
          <SystemEnforcedBox message="Audit logging is always enabled and cannot be disabled" />
          
          <div>
            <div className="flex items-center gap-2 mb-3">
              <ScrollText className="h-4 w-4 text-muted-foreground" />
              <Label className="text-sm font-medium">Event Categories to Log</Label>
              <FieldTooltip content={tips.eventCategories} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {eventCategories.map((cat) => (
                <div 
                  key={cat.key}
                  className="flex items-start space-x-3 p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors"
                >
                  <Checkbox 
                    id={`audit-${cat.key}`}
                    checked={config.eventCategories[cat.key]}
                    onCheckedChange={(v) => updateEventCategory(cat.key, !!v)}
                    className="mt-0.5"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-1">
                      <Label htmlFor={`audit-${cat.key}`} className="text-sm cursor-pointer">{cat.label}</Label>
                      <FieldTooltip content={cat.tooltip} />
                    </div>
                    <p className="text-xs text-muted-foreground">{cat.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </SecurityFormSection>

      {/* 7.2 Retention Policy */}
      <SecurityFormSection 
        title="Retention Policy" 
        description="How long audit logs are kept"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <Label className="text-sm">Active Searchable Retention</Label>
              <FieldTooltip content={tips.activeRetention} />
            </div>
            <Select 
              value={config.activeRetentionDays.toString()}
              onValueChange={(v) => onChange({ activeRetentionDays: parseInt(v) as ActiveRetentionDays })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="90">90 days</SelectItem>
                <SelectItem value="180">180 days (Default)</SelectItem>
                <SelectItem value="365">365 days</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-1">
              Logs searchable in real-time
            </p>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <Label className="text-sm">Archived Retention</Label>
              <FieldTooltip content={tips.archivedRetention} />
            </div>
            <Select 
              value={config.archivedRetentionYears.toString()}
              onValueChange={(v) => onChange({ archivedRetentionYears: parseInt(v) as ArchivedRetentionYears })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 year</SelectItem>
                <SelectItem value="3">3 years (Default)</SelectItem>
                <SelectItem value="7">7 years</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-1">
              Total retention in cold storage
            </p>
          </div>
        </div>
        <div className="mt-4">
          <div className="flex items-center gap-1 mb-2">
            <Label className="text-sm">Export Audit Log Allowed</Label>
            <FieldTooltip content={tips.exportAuditLog} />
          </div>
          <Select 
            value={config.exportAuditLogAllowed}
            onValueChange={(v) => onChange({ exportAuditLogAllowed: v as typeof config.exportAuditLogAllowed })}
          >
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="admin_only">Admin Only</SelectItem>
              <SelectItem value="compliance_head">Compliance Head & Admin</SelectItem>
              <SelectItem value="all">All Viewers</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </SecurityFormSection>

      {/* 7.3 Audit Access */}
      <SecurityFormSection 
        title="Audit Log Viewers" 
        description="Who can view audit logs"
      >
        <div className="flex items-center gap-2 mb-3">
          <Eye className="h-4 w-4 text-muted-foreground" />
          <Label className="text-sm font-medium">Roles with View Access</Label>
          <FieldTooltip content={tips.auditViewers} />
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="flex items-center space-x-2 p-3 rounded-lg border border-border">
            <Switch
              id="view-admin"
              checked={config.auditViewers.orgAdmin}
              onCheckedChange={(v) => updateAuditViewer('orgAdmin', v)}
              disabled
            />
            <Label htmlFor="view-admin" className="text-sm cursor-pointer">Org Admin</Label>
          </div>
          <div className="flex items-center space-x-2 p-3 rounded-lg border border-border">
            <Switch
              id="view-compliance"
              checked={config.auditViewers.complianceHead}
              onCheckedChange={(v) => updateAuditViewer('complianceHead', v)}
            />
            <Label htmlFor="view-compliance" className="text-sm cursor-pointer">Compliance Head</Label>
          </div>
          <div className="flex items-center space-x-2 p-3 rounded-lg border border-border">
            <Switch
              id="view-dept"
              checked={config.auditViewers.departmentHead}
              onCheckedChange={(v) => updateAuditViewer('departmentHead', v)}
            />
            <Label htmlFor="view-dept" className="text-sm cursor-pointer">Dept Head</Label>
          </div>
          <div className="flex items-center space-x-2 p-3 rounded-lg border border-border">
            <Switch
              id="view-staff"
              checked={config.auditViewers.staff}
              onCheckedChange={(v) => updateAuditViewer('staff', v)}
            />
            <Label htmlFor="view-staff" className="text-sm cursor-pointer">Staff</Label>
          </div>
        </div>
      </SecurityFormSection>
    </div>
  );
};
