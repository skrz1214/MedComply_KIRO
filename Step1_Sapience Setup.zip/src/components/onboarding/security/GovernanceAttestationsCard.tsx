import React from 'react';
import { SecurityFormSection } from './SecurityCard';
import { FieldTooltip, SECURITY_TOOLTIPS } from './SecurityTooltips';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { GovernanceAttestationsConfig } from '@/types/securityBaseline';
import { CheckCircle2, FileText, ExternalLink } from 'lucide-react';

interface GovernanceAttestationsCardContentProps {
  config: GovernanceAttestationsConfig;
  onChange: (updates: Partial<GovernanceAttestationsConfig>) => void;
}

export const GovernanceAttestationsCardContent: React.FC<GovernanceAttestationsCardContentProps> = ({
  config,
  onChange,
}) => {
  const tips = SECURITY_TOOLTIPS.governanceAttestations;

  const requiredAttestations = [
    {
      key: 'accessManagementAcknowledged',
      label: 'Access Management Commitment',
      description: 'We will manage user access and remove access promptly when staff leave.',
      checked: config.accessManagementAcknowledged,
      tooltip: tips.accessManagement,
    },
    {
      key: 'auditMonitoringAcknowledged',
      label: 'Audit Monitoring Acknowledgment',
      description: 'We understand audit logs and exports are monitored.',
      checked: config.auditMonitoringAcknowledged,
      tooltip: tips.auditMonitoring,
    },
    {
      key: 'ssoMfaConfigAcknowledged',
      label: 'SSO/MFA Configuration Commitment',
      description: 'We will configure SSO/MFA consistent with our organizational policies.',
      checked: config.ssoMfaConfigAcknowledged,
      tooltip: tips.ssoMfaConfig,
    },
  ] as const;

  return (
    <div className="space-y-6">
      {/* Required Attestations */}
      <SecurityFormSection 
        title="Required Attestations" 
        description="You must acknowledge these statements to publish your security baseline"
      >
        <div className="space-y-3">
          {requiredAttestations.map((att) => (
            <div 
              key={att.key}
              className={`flex items-start space-x-3 p-4 rounded-lg border transition-colors ${
                att.checked 
                  ? 'border-green-300 bg-green-50 dark:border-green-800 dark:bg-green-950' 
                  : 'border-border hover:bg-muted/50'
              }`}
            >
              <Checkbox 
                id={att.key}
                checked={att.checked}
                onCheckedChange={(v) => onChange({ [att.key]: !!v })}
                className="mt-1"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <Label htmlFor={att.key} className="text-sm font-medium cursor-pointer">
                    {att.label}
                  </Label>
                  <FieldTooltip content={att.tooltip} />
                  <span className="text-xs text-destructive">*Required</span>
                </div>
                <p className="text-sm text-muted-foreground mt-1">{att.description}</p>
              </div>
              {att.checked && (
                <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400 flex-shrink-0" />
              )}
            </div>
          ))}
        </div>
      </SecurityFormSection>

      {/* Optional Attestation */}
      <SecurityFormSection 
        title="Optional Attestations" 
        description="Additional acknowledgments for your records"
      >
        <div 
          className={`flex items-start space-x-3 p-4 rounded-lg border transition-colors ${
            config.baaAcknowledged 
              ? 'border-green-300 bg-green-50 dark:border-green-800 dark:bg-green-950' 
              : 'border-border hover:bg-muted/50'
          }`}
        >
          <Checkbox 
            id="baa"
            checked={config.baaAcknowledged}
            onCheckedChange={(v) => onChange({ baaAcknowledged: !!v })}
            className="mt-1"
          />
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <Label htmlFor="baa" className="text-sm font-medium cursor-pointer">
                Business Associate Agreement (BAA)
              </Label>
              <FieldTooltip content={tips.baa} />
              <span className="text-xs text-muted-foreground">Optional</span>
            </div>
            <p className="text-sm text-muted-foreground mt-1">
              We acknowledge that a Business Associate Agreement is in place.
            </p>
            <a 
              href="#" 
              className="inline-flex items-center gap-1 text-xs text-primary hover:underline mt-2"
              onClick={(e) => e.preventDefault()}
            >
              <FileText className="h-3 w-3" />
              View BAA Template
              <ExternalLink className="h-3 w-3" />
            </a>
          </div>
          {config.baaAcknowledged && (
            <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400 flex-shrink-0" />
          )}
        </div>
      </SecurityFormSection>
    </div>
  );
};
