import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { LoginConfig } from '@/types/brandingConfig';
import { MessageSquare, Mail, Phone, HelpCircle, FileText } from 'lucide-react';
import { FieldTooltip, BRANDING_TOOLTIPS } from './BrandingTooltips';

interface LoginCardContentProps {
  config: LoginConfig;
  onChange: (updates: Partial<LoginConfig>) => void;
}

export const LoginCardContent: React.FC<LoginCardContentProps> = ({
  config,
  onChange,
}) => {
  return (
    <div className="space-y-6">
      {/* Welcome Message */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <MessageSquare className="h-4 w-4 text-muted-foreground" />
          <Label className="text-sm font-medium">Welcome Message</Label>
        </div>
        <div className="space-y-3">
          <div>
            <Label className="text-sm">
              Welcome Title
              <FieldTooltip content={BRANDING_TOOLTIPS.login.welcomeTitle} />
            </Label>
            <Input
              value={config.welcomeTitle}
              onChange={(e) => onChange({ welcomeTitle: e.target.value })}
              placeholder="Welcome to Compliance Portal"
              className="mt-1"
            />
          </div>
          <div>
            <Label className="text-sm">
              Welcome Message (optional)
              <FieldTooltip content={BRANDING_TOOLTIPS.login.welcomeMessage} />
            </Label>
            <Textarea
              value={config.welcomeMessage}
              onChange={(e) => onChange({ welcomeMessage: e.target.value })}
              placeholder="Sign in to access your compliance dashboard..."
              className="mt-1"
              rows={2}
            />
            <p className="text-xs text-muted-foreground mt-1">
              1-2 lines shown below the title on login screen
            </p>
          </div>
        </div>
      </div>

      {/* Support Contact */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Mail className="h-4 w-4 text-muted-foreground" />
          <Label className="text-sm font-medium">Support Contact</Label>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <Label className="text-sm">
              Support Email
              <FieldTooltip content={BRANDING_TOOLTIPS.login.supportEmail} />
            </Label>
            <Input
              type="email"
              value={config.supportEmail}
              onChange={(e) => onChange({ supportEmail: e.target.value })}
              placeholder="support@example.com"
              className="mt-1"
            />
          </div>
          <div>
            <Label className="text-sm">
              Support Phone
              <FieldTooltip content={BRANDING_TOOLTIPS.login.supportPhone} />
            </Label>
            <div className="flex items-center gap-2 mt-1">
              <Phone className="h-4 w-4 text-muted-foreground" />
              <Input
                type="tel"
                value={config.supportPhone}
                onChange={(e) => onChange({ supportPhone: e.target.value })}
                placeholder="+1-555-0123"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Help Link */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <HelpCircle className="h-4 w-4 text-muted-foreground" />
          <Label className="text-sm font-medium">Help Link</Label>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <Label className="text-sm">
              Link Label
              <FieldTooltip content={BRANDING_TOOLTIPS.login.helpLinkLabel} />
            </Label>
            <Input
              value={config.helpLinkLabel}
              onChange={(e) => onChange({ helpLinkLabel: e.target.value })}
              placeholder="Need Help?"
              className="mt-1"
            />
          </div>
          <div>
            <Label className="text-sm">
              Link URL
              <FieldTooltip content={BRANDING_TOOLTIPS.login.helpLinkUrl} />
            </Label>
            <Input
              type="url"
              value={config.helpLinkUrl}
              onChange={(e) => onChange({ helpLinkUrl: e.target.value })}
              placeholder="https://help.example.com"
              className="mt-1"
            />
          </div>
        </div>
      </div>

      {/* Legal Links */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <FileText className="h-4 w-4 text-muted-foreground" />
          <Label className="text-sm font-medium">Legal Links (Optional)</Label>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <Label className="text-sm">
              Terms of Service URL
              <FieldTooltip content={BRANDING_TOOLTIPS.login.termsUrl} />
            </Label>
            <Input
              type="url"
              value={config.termsUrl}
              onChange={(e) => onChange({ termsUrl: e.target.value })}
              placeholder="https://example.com/terms"
              className="mt-1"
            />
          </div>
          <div>
            <Label className="text-sm">
              Privacy Policy URL
              <FieldTooltip content={BRANDING_TOOLTIPS.login.privacyUrl} />
            </Label>
            <Input
              type="url"
              value={config.privacyUrl}
              onChange={(e) => onChange({ privacyUrl: e.target.value })}
              placeholder="https://example.com/privacy"
              className="mt-1"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
