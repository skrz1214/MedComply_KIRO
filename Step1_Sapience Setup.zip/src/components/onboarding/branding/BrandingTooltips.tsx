import React from 'react';
import { HelpCircle } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface FieldTooltipProps {
  content: string;
}

export const FieldTooltip: React.FC<FieldTooltipProps> = ({ content }) => (
  <TooltipProvider>
    <Tooltip>
      <TooltipTrigger asChild>
        <HelpCircle className="h-3.5 w-3.5 text-muted-foreground hover:text-foreground cursor-help inline-block ml-1" />
      </TooltipTrigger>
      <TooltipContent className="max-w-xs text-sm" side="top">
        <p>{content}</p>
      </TooltipContent>
    </Tooltip>
  </TooltipProvider>
);

export const BRANDING_TOOLTIPS = {
  orgIdentity: {
    displayName: "The full name of your organization shown in headers, email communications, and user-facing screens. This is how users will see your organization referenced throughout the platform.",
    shortName: "A shortened version or abbreviation of your organization name. Used in tight UI spaces like the collapsed sidebar or mobile navigation where full names won't fit.",
    appTitle: "The title shown in the browser tab when users access the platform. Defaults to 'MedComply' if not specified.",
  },
  
  logo: {
    primaryLogo: "Your main organization logo displayed in the header and login screen. Use a high-quality image with transparent background for best results. Recommended width: 200-400px.",
    squareLogo: "A square version of your logo used when the sidebar is collapsed or on mobile devices. Should be recognizable even at small sizes (48x48px displayed).",
    favicon: "The small icon shown in browser tabs. Should be a simple, recognizable symbol that works at very small sizes (32x32 or 48x48 pixels).",
  },
  
  theme: {
    themePreset: "Choose a pre-designed color scheme or customize your own. 'Default MedComply' is recommended for most organizations. 'High Contrast' is optimized for accessibility.",
    primaryColor: "The main brand color used for buttons, links, and key interactive elements. Choose a color that represents your brand and has good contrast with white text.",
    secondaryColor: "A complementary color used for secondary buttons and UI elements. Auto-generated based on your primary color but can be customized.",
    accentColor: "Used for highlights, notifications, and attention-grabbing elements. Should contrast with both primary and secondary colors.",
    neutralMode: "Affects the tone of gray colors throughout the UI. 'Cool' has a blue undertone, 'Warm' has a beige undertone, 'Neutral' is pure gray.",
    backgroundMode: "Choose between light or dark mode as the default appearance. Users may be able to override this based on system settings.",
    contrastCheck: "Indicates whether your primary color meets WCAG accessibility standards for text readability. 'Contrast OK' means text on buttons will be readable.",
  },
  
  typography: {
    fontFamily: "The typeface used throughout the application. 'System Default' uses the device's native fonts for optimal performance. 'Modern Sans' provides a consistent look across devices.",
    baseFontSize: "The base size for text throughout the application. 'Large' is recommended for users who need improved readability or accessibility accommodations.",
  },
  
  appShell: {
    sidebarExpandedByDefault: "When enabled, the navigation sidebar starts in expanded mode showing full labels. When disabled, it starts collapsed showing only icons.",
    sidebarShowLabels: "Show text labels next to navigation icons. Helpful for users unfamiliar with the platform. Disable for a more compact interface.",
    headerShowOrgName: "Display your organization name in the main header bar. Useful for reinforcing brand presence; disable if your logo is sufficient.",
    buttonStyle: "Choose the corner style for buttons. 'Standard' uses subtle rounded corners; 'Extra Rounded' uses pill-shaped buttons for a softer look.",
    density: "'Comfortable' provides more whitespace for easier reading. 'Compact' fits more content on screen, useful for power users or smaller screens.",
  },
  
  login: {
    welcomeTitle: "The main heading shown on the login page. Personalize this to welcome users to your specific compliance portal.",
    welcomeMessage: "Optional text shown below the title on the login screen. Use this for a brief greeting or instructions.",
    supportEmail: "Email address shown on the login page for users who need help signing in. This should reach your IT help desk or support team.",
    supportPhone: "Phone number for login support. Shown alongside the email for users who prefer phone assistance.",
    helpLinkLabel: "The text for the help link button. Examples: 'Need Help?', 'Contact Support', 'Having Trouble?'",
    helpLinkUrl: "URL where users are directed when clicking the help link. Can be a knowledge base, contact form, or support page.",
    termsUrl: "Link to your organization's Terms of Service. Shown as a footer link on the login page.",
    privacyUrl: "Link to your organization's Privacy Policy. Required for compliance and shown as a footer link on the login page.",
  },
  
  localization: {
    defaultLanguage: "The primary language for the platform interface. New users will see the platform in this language by default. Users may change their individual preference.",
    dateFormat: "How dates are displayed throughout the platform. Choose based on your region's conventions (US uses MM/DD/YYYY, most other countries use DD/MM/YYYY).",
    timeFormat: "12-hour format shows AM/PM (common in US), 24-hour format uses military time (common internationally and in healthcare settings).",
    numberFormat: "Affects decimal separators and thousand groupings. US uses '1,234.56' while EU uses '1.234,56'. Choose based on your region.",
  },
  
  domain: {
    subdomain: "Your default platform URL using the MedComply domain. This is automatically created based on your organization code.",
    customDomain: "Use your own domain (e.g., compliance.yourcompany.com) for a fully branded experience. Requires DNS configuration and is available on Enterprise plans.",
    domainStatus: "Verification status of your custom domain. 'Pending' means DNS records are being checked. 'Verified' means the domain is active and working.",
  },
};
