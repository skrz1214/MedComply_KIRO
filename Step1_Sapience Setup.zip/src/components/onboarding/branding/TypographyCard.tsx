import React from 'react';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { TypographyConfig, FontFamily, FontSize } from '@/types/brandingConfig';
import { FONT_FAMILY_OPTIONS } from '@/data/brandingPresets';
import { FieldTooltip, BRANDING_TOOLTIPS } from './BrandingTooltips';

interface TypographyCardContentProps {
  config: TypographyConfig;
  onChange: (updates: Partial<TypographyConfig>) => void;
}

export const TypographyCardContent: React.FC<TypographyCardContentProps> = ({
  config,
  onChange,
}) => {
  return (
    <div className="space-y-6">
      {/* Font Family */}
      <div>
        <Label className="text-sm font-medium mb-3 block">
          Font Family
          <FieldTooltip content={BRANDING_TOOLTIPS.typography.fontFamily} />
        </Label>
        <RadioGroup
          value={config.fontFamily}
          onValueChange={(v) => onChange({ fontFamily: v as FontFamily })}
          className="space-y-2"
        >
          {FONT_FAMILY_OPTIONS.map((font) => (
            <div
              key={font.id}
              className={`flex items-center space-x-3 p-3 rounded-lg border transition-colors ${
                config.fontFamily === font.id
                  ? 'border-primary bg-primary/5'
                  : 'border-border hover:bg-muted/50'
              }`}
            >
              <RadioGroupItem value={font.id} id={`font-${font.id}`} />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <Label htmlFor={`font-${font.id}`} className="font-medium cursor-pointer">
                    {font.name}
                  </Label>
                  {font.id === 'system' && (
                    <Badge variant="secondary" className="text-xs">Recommended</Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">{font.description}</p>
              </div>
              <div 
                className="text-lg px-3"
                style={{ 
                  fontFamily: font.id === 'system' 
                    ? 'system-ui, -apple-system, sans-serif' 
                    : '"Inter", "Helvetica Neue", sans-serif'
                }}
              >
                Aa
              </div>
            </div>
          ))}
        </RadioGroup>
      </div>

      {/* Base Font Size */}
      <div>
        <Label className="text-sm font-medium mb-3 block">
          Base Font Size
          <FieldTooltip content={BRANDING_TOOLTIPS.typography.baseFontSize} />
        </Label>
        <RadioGroup
          value={config.baseFontSize}
          onValueChange={(v) => onChange({ baseFontSize: v as FontSize })}
          className="space-y-2"
        >
          <div
            className={`flex items-center space-x-3 p-3 rounded-lg border transition-colors ${
              config.baseFontSize === 'normal'
                ? 'border-primary bg-primary/5'
                : 'border-border hover:bg-muted/50'
            }`}
          >
            <RadioGroupItem value="normal" id="size-normal" />
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <Label htmlFor="size-normal" className="font-medium cursor-pointer">Normal</Label>
                <Badge variant="secondary" className="text-xs">Default</Badge>
              </div>
              <p className="text-xs text-muted-foreground">Standard text size (14-16px base)</p>
            </div>
            <span className="text-sm">Sample text</span>
          </div>
          <div
            className={`flex items-center space-x-3 p-3 rounded-lg border transition-colors ${
              config.baseFontSize === 'large'
                ? 'border-primary bg-primary/5'
                : 'border-border hover:bg-muted/50'
            }`}
          >
            <RadioGroupItem value="large" id="size-large" />
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <Label htmlFor="size-large" className="font-medium cursor-pointer">Large</Label>
                <Badge variant="outline" className="text-xs">Accessibility</Badge>
              </div>
              <p className="text-xs text-muted-foreground">Larger text for improved readability (16-18px base)</p>
            </div>
            <span className="text-base">Sample text</span>
          </div>
        </RadioGroup>
      </div>
    </div>
  );
};
