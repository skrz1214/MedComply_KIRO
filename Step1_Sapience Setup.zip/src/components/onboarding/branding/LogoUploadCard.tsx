import React, { useCallback, useState } from 'react';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { LogoConfig, LOGO_REQUIREMENTS } from '@/types/brandingConfig';
import { Upload, X, Image, Square, Star } from 'lucide-react';
import { FieldTooltip, BRANDING_TOOLTIPS } from './BrandingTooltips';

interface LogoUploadCardContentProps {
  config: LogoConfig;
  onChange: (updates: Partial<LogoConfig>) => void;
}

interface LogoUploadProps {
  label: string;
  description: string;
  logoUrl?: string;
  logoFile?: File;
  onUpload: (file: File) => void;
  onRemove: () => void;
  requirements: { maxSizeMB: number; acceptedTypes: string[]; acceptedExtensions: string };
  icon: React.ReactNode;
  isRequired?: boolean;
  tooltip: string;
}

const LogoUpload: React.FC<LogoUploadProps> = ({
  label,
  description,
  logoUrl,
  logoFile,
  onUpload,
  onRemove,
  requirements,
  icon,
  isRequired,
  tooltip,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFile = useCallback((file: File) => {
    setError(null);
    
    // Validate file type
    if (!requirements.acceptedTypes.includes(file.type)) {
      setError(`Invalid file type. Accepted: ${requirements.acceptedExtensions}`);
      return;
    }
    
    // Validate file size
    if (file.size > requirements.maxSizeMB * 1024 * 1024) {
      setError(`File too large. Maximum size: ${requirements.maxSizeMB}MB`);
      return;
    }
    
    onUpload(file);
  }, [requirements, onUpload]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files.length > 0) {
      handleFile(e.dataTransfer.files[0]);
    }
  }, [handleFile]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setIsDragging(false);
  }, []);

  const previewUrl = logoFile ? URL.createObjectURL(logoFile) : logoUrl;

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        {icon}
        <Label className="text-sm font-medium">
          {label}
          {isRequired && <span className="text-destructive ml-1">*</span>}
          <FieldTooltip content={tooltip} />
        </Label>
      </div>
      <p className="text-xs text-muted-foreground">{description}</p>
      
      {previewUrl ? (
        <div className="relative p-4 border rounded-lg bg-muted/30">
          <img 
            src={previewUrl} 
            alt={label} 
            className="max-h-20 max-w-full object-contain mx-auto"
          />
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-2 right-2 h-6 w-6"
            onClick={onRemove}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      ) : (
        <div
          className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
            isDragging 
              ? 'border-primary bg-primary/5' 
              : 'border-border hover:border-primary/50'
          }`}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
        >
          <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
          <p className="text-sm text-muted-foreground mb-2">
            Drag & drop or{' '}
            <label className="text-primary cursor-pointer hover:underline">
              browse
              <input
                type="file"
                className="hidden"
                accept={requirements.acceptedExtensions}
                onChange={(e) => {
                  if (e.target.files?.[0]) {
                    handleFile(e.target.files[0]);
                  }
                }}
              />
            </label>
          </p>
          <p className="text-xs text-muted-foreground">
            {requirements.acceptedExtensions.toUpperCase()} • Max {requirements.maxSizeMB}MB
          </p>
        </div>
      )}
      
      {error && (
        <p className="text-xs text-destructive">{error}</p>
      )}
    </div>
  );
};

export const LogoUploadCardContent: React.FC<LogoUploadCardContentProps> = ({
  config,
  onChange,
}) => {
  return (
    <div className="space-y-6">
      <LogoUpload
        label="Primary Logo"
        description="Main logo for headers and login screen. Transparent background recommended."
        logoUrl={config.primaryLogoUrl}
        logoFile={config.primaryLogoFile}
        onUpload={(file) => onChange({ primaryLogoFile: file, primaryLogoUrl: undefined })}
        onRemove={() => onChange({ primaryLogoFile: undefined, primaryLogoUrl: undefined })}
        requirements={LOGO_REQUIREMENTS.primary}
        icon={<Image className="h-4 w-4 text-primary" />}
        isRequired
        tooltip={BRANDING_TOOLTIPS.logo.primaryLogo}
      />
      
      <LogoUpload
        label="Square Logo"
        description="Used in collapsed sidebar and mobile. Recommended for responsive design."
        logoUrl={config.squareLogoUrl}
        logoFile={config.squareLogoFile}
        onUpload={(file) => onChange({ squareLogoFile: file, squareLogoUrl: undefined })}
        onRemove={() => onChange({ squareLogoFile: undefined, squareLogoUrl: undefined })}
        requirements={LOGO_REQUIREMENTS.square}
        icon={<Square className="h-4 w-4 text-primary" />}
        tooltip={BRANDING_TOOLTIPS.logo.squareLogo}
      />
      
      <LogoUpload
        label="Favicon"
        description="Browser tab icon. 48x48 pixels recommended."
        logoUrl={config.faviconUrl}
        logoFile={config.faviconFile}
        onUpload={(file) => onChange({ faviconFile: file, faviconUrl: undefined })}
        onRemove={() => onChange({ faviconFile: undefined, faviconUrl: undefined })}
        requirements={LOGO_REQUIREMENTS.favicon}
        icon={<Star className="h-4 w-4 text-primary" />}
        tooltip={BRANDING_TOOLTIPS.logo.favicon}
      />
    </div>
  );
};
