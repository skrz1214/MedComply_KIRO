import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { cn } from '@/lib/utils';

interface BrandingCardProps {
  title: string;
  description: string;
  isRequired?: boolean;
  isExpanded?: boolean;
  onToggle?: () => void;
  children: React.ReactNode;
  icon?: React.ReactNode;
}

export const BrandingCard: React.FC<BrandingCardProps> = ({
  title,
  description,
  isRequired = false,
  isExpanded = false,
  onToggle,
  children,
  icon,
}) => {
  return (
    <Card className={cn(
      "border transition-all duration-200",
      isExpanded ? "border-primary/30 shadow-md" : "border-border"
    )}>
      <Collapsible open={isExpanded} onOpenChange={onToggle}>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                {icon && (
                  <div className="p-2 rounded-lg bg-primary/10 text-primary mt-0.5">
                    {icon}
                  </div>
                )}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <CardTitle className="text-base font-semibold">{title}</CardTitle>
                    {isRequired && (
                      <Badge variant="secondary" className="text-xs">Required</Badge>
                    )}
                  </div>
                  <CardDescription className="text-sm">{description}</CardDescription>
                </div>
              </div>
              <div className="p-1">
                {isExpanded ? (
                  <ChevronUp className="h-5 w-5 text-muted-foreground" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-muted-foreground" />
                )}
              </div>
            </div>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="pt-0 pb-6">
            <div className="border-t pt-4">
              {children}
            </div>
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
};
