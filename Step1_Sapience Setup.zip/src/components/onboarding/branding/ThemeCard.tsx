import React, { useState } from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ThemeConfig, ThemePreset, NeutralMode, BackgroundMode } from '@/types/brandingConfig';
import { THEME_PRESETS, generateComplementaryColors, checkContrastRatio } from '@/data/brandingPresets';
import { ChevronDown, CheckCircle2, AlertTriangle } from 'lucide-react';
import { FieldTooltip, BRANDING_TOOLTIPS } from './BrandingTooltips';

interface ThemeCardContentProps {
  config: ThemeConfig;
  onChange: (updates: Partial<ThemeConfig>) => void;
}

export const ThemeCardContent: React.FC<ThemeCardContentProps> = ({
  config,
  onChange,
}) => {
  const [advancedOpen, setAdvancedOpen] = useState(false);
  
  const handlePresetChange = (presetId: ThemePreset) => {
    if (presetId === 'custom') {
      onChange({ preset: 'custom' });
      return;
    }
    
    const preset = THEME_PRESETS.find(p => p.id === presetId);
    if (preset) {
      const contrastResult = checkContrastRatio('#ffffff', preset.primaryColor);
      onChange({
        preset: presetId,
        primaryColor: preset.primaryColor,
        secondaryColor: preset.secondaryColor,
        accentColor: preset.accentColor,
        contrastOk: contrastResult.passes,
      });
    }
  };
  
  const handlePrimaryColorChange = (color: string) => {
    const { secondary, accent } = generateComplementaryColors(color);
    const contrastResult = checkContrastRatio('#ffffff', color);
    
    onChange({
      preset: 'custom',
      primaryColor: color,
      secondaryColor: secondary,
      accentColor: accent,
      contrastOk: contrastResult.passes,
    });
  };

  const contrastResult = checkContrastRatio('#ffffff', config.primaryColor);

  return (
    <div className="space-y-6">
      {/* Theme Presets */}
      <div>
        <Label className="text-sm font-medium mb-3 block">
          Theme Preset
          <FieldTooltip content={BRANDING_TOOLTIPS.theme.themePreset} />
        </Label>
        <RadioGroup
          value={config.preset}
          onValueChange={(v) => handlePresetChange(v as ThemePreset)}
          className="space-y-2"
        >
          {THEME_PRESETS.map((preset) => (
            <div
              key={preset.id}
              className={`flex items-center space-x-3 p-3 rounded-lg border transition-colors ${
                config.preset === preset.id
                  ? 'border-primary bg-primary/5'
                  : 'border-border hover:bg-muted/50'
              }`}
            >
              <RadioGroupItem value={preset.id} id={`preset-${preset.id}`} />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <Label htmlFor={`preset-${preset.id}`} className="font-medium cursor-pointer">
                    {preset.name}
                  </Label>
                  {preset.id === 'default' && (
                    <Badge variant="secondary" className="text-xs">Recommended</Badge>
                  )}
                  {preset.id === 'high_contrast' && (
                    <Badge variant="outline" className="text-xs">WCAG AAA</Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">{preset.description}</p>
              </div>
              <div className="flex gap-1">
                <div 
                  className="w-6 h-6 rounded-full border border-border"
                  style={{ backgroundColor: preset.primaryColor }}
                />
                <div 
                  className="w-6 h-6 rounded-full border border-border"
                  style={{ backgroundColor: preset.secondaryColor }}
                />
                <div 
                  className="w-6 h-6 rounded-full border border-border"
                  style={{ backgroundColor: preset.accentColor }}
                />
              </div>
            </div>
          ))}
        </RadioGroup>
      </div>

      {/* Primary Color Picker */}
      <div>
        <Label className="text-sm font-medium mb-2 block">
          Primary Color
          <FieldTooltip content={BRANDING_TOOLTIPS.theme.primaryColor} />
        </Label>
        <div className="flex items-center gap-3">
          <Input
            type="color"
            value={config.primaryColor}
            onChange={(e) => handlePrimaryColorChange(e.target.value)}
            className="w-14 h-10 p-1 cursor-pointer"
          />
          <Input
            value={config.primaryColor}
            onChange={(e) => handlePrimaryColorChange(e.target.value)}
            className="w-28 font-mono text-sm"
            maxLength={7}
          />
          <div className="flex-1" />
          {/* Contrast indicator */}
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm ${
            contrastResult.passes 
              ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
              : 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200'
          }`}>
            {contrastResult.passes ? (
              <>
                <CheckCircle2 className="h-4 w-4" />
                Contrast OK
              </>
            ) : (
              <>
                <AlertTriangle className="h-4 w-4" />
                Low Contrast
              </>
            )}
            <FieldTooltip content={BRANDING_TOOLTIPS.theme.contrastCheck} />
          </div>
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          Secondary and accent colors are auto-generated. Customize in Advanced options.
        </p>
      </div>

      {/* Advanced Options */}
      <Collapsible open={advancedOpen} onOpenChange={setAdvancedOpen}>
        <CollapsibleTrigger className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ChevronDown className={`h-4 w-4 transition-transform ${advancedOpen ? 'rotate-180' : ''}`} />
          Advanced Color Options
        </CollapsibleTrigger>
        <CollapsibleContent className="mt-4 space-y-4 p-4 rounded-lg bg-muted/30 border border-border">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-sm">
                Secondary Color
                <FieldTooltip content={BRANDING_TOOLTIPS.theme.secondaryColor} />
              </Label>
              <div className="flex items-center gap-2 mt-1">
                <Input
                  type="color"
                  value={config.secondaryColor}
                  onChange={(e) => onChange({ secondaryColor: e.target.value, preset: 'custom' })}
                  className="w-12 h-9 p-1 cursor-pointer"
                />
                <Input
                  value={config.secondaryColor}
                  onChange={(e) => onChange({ secondaryColor: e.target.value, preset: 'custom' })}
                  className="flex-1 font-mono text-sm"
                  maxLength={7}
                />
              </div>
            </div>
            <div>
              <Label className="text-sm">
                Accent Color
                <FieldTooltip content={BRANDING_TOOLTIPS.theme.accentColor} />
              </Label>
              <div className="flex items-center gap-2 mt-1">
                <Input
                  type="color"
                  value={config.accentColor}
                  onChange={(e) => onChange({ accentColor: e.target.value, preset: 'custom' })}
                  className="w-12 h-9 p-1 cursor-pointer"
                />
                <Input
                  value={config.accentColor}
                  onChange={(e) => onChange({ accentColor: e.target.value, preset: 'custom' })}
                  className="flex-1 font-mono text-sm"
                  maxLength={7}
                />
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-sm mb-2 block">
                Neutral Mode
                <FieldTooltip content={BRANDING_TOOLTIPS.theme.neutralMode} />
              </Label>
              <RadioGroup
                value={config.neutralMode}
                onValueChange={(v) => onChange({ neutralMode: v as NeutralMode })}
                className="flex gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="cool" id="neutral-cool" />
                  <Label htmlFor="neutral-cool" className="text-sm cursor-pointer">Cool</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="neutral" id="neutral-neutral" />
                  <Label htmlFor="neutral-neutral" className="text-sm cursor-pointer">Neutral</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="warm" id="neutral-warm" />
                  <Label htmlFor="neutral-warm" className="text-sm cursor-pointer">Warm</Label>
                </div>
              </RadioGroup>
            </div>
            
            <div>
              <Label className="text-sm mb-2 block">
                Background Mode
                <FieldTooltip content={BRANDING_TOOLTIPS.theme.backgroundMode} />
              </Label>
              <div className="flex items-center justify-between p-3 rounded-lg border border-border">
                <div className="flex items-center gap-2">
                  <span className="text-sm">Light</span>
                  <Switch
                    checked={config.backgroundMode === 'dark'}
                    onCheckedChange={(v) => onChange({ backgroundMode: v ? 'dark' : 'light' as BackgroundMode })}
                  />
                  <span className="text-sm">Dark</span>
                </div>
              </div>
            </div>
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
};
