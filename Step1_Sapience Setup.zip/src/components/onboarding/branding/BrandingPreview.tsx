import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BrandingConfig } from '@/types/brandingConfig';
import { Monitor, LogIn, LayoutDashboard } from 'lucide-react';

interface BrandingPreviewProps {
  config: BrandingConfig;
}

export const BrandingPreview: React.FC<BrandingPreviewProps> = ({ config }) => {
  const [activeTab, setActiveTab] = useState('login');
  const logoUrl = config.logo.primaryLogoFile 
    ? URL.createObjectURL(config.logo.primaryLogoFile) 
    : config.logo.primaryLogoUrl;

  return (
    <div className="h-full flex flex-col">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="login" className="text-xs"><LogIn className="h-3 w-3 mr-1" />Login</TabsTrigger>
          <TabsTrigger value="shell" className="text-xs"><Monitor className="h-3 w-3 mr-1" />App Shell</TabsTrigger>
          <TabsTrigger value="dashboard" className="text-xs"><LayoutDashboard className="h-3 w-3 mr-1" />Dashboard</TabsTrigger>
        </TabsList>
        
        <TabsContent value="login" className="flex-1 mt-2">
          <div 
            className="h-full rounded-lg border overflow-hidden"
            style={{ backgroundColor: config.theme.backgroundMode === 'dark' ? '#1a1a2e' : '#f8fafc' }}
          >
            <div className="h-full flex items-center justify-center p-4">
              <div className="w-full max-w-xs space-y-4 p-6 rounded-lg bg-white dark:bg-gray-900 shadow-lg">
                {logoUrl && <img src={logoUrl} alt="Logo" className="h-8 mx-auto object-contain" />}
                <h2 className="text-center text-sm font-semibold" style={{ color: config.theme.primaryColor }}>
                  {config.login.welcomeTitle || 'Welcome'}
                </h2>
                {config.login.welcomeMessage && (
                  <p className="text-xs text-center text-muted-foreground">{config.login.welcomeMessage}</p>
                )}
                <div className="space-y-2">
                  <div className="h-8 rounded bg-gray-100 dark:bg-gray-800" />
                  <div className="h-8 rounded bg-gray-100 dark:bg-gray-800" />
                  <div 
                    className="h-8 rounded text-white text-xs flex items-center justify-center"
                    style={{ 
                      backgroundColor: config.theme.primaryColor,
                      borderRadius: config.appShell.buttonStyle === 'extra_rounded' ? '9999px' : '6px'
                    }}
                  >
                    Sign In
                  </div>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="shell" className="flex-1 mt-2">
          <div className="h-full rounded-lg border overflow-hidden flex" style={{ backgroundColor: config.theme.backgroundMode === 'dark' ? '#1a1a2e' : '#f8fafc' }}>
            <div className="w-12 border-r p-2 flex flex-col gap-2" style={{ backgroundColor: config.theme.primaryColor }}>
              {[1,2,3,4].map(i => <div key={i} className="h-6 w-6 rounded bg-white/20 mx-auto" />)}
            </div>
            <div className="flex-1 flex flex-col">
              <div className="h-10 border-b flex items-center px-3 bg-white dark:bg-gray-900">
                {config.appShell.headerShowOrgName && (
                  <span className="text-xs font-medium" style={{ color: config.theme.primaryColor }}>
                    {config.orgIdentity.displayName || 'Organization'}
                  </span>
                )}
              </div>
              <div className="flex-1 p-3">
                <div className="text-xs text-muted-foreground">App content area</div>
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="dashboard" className="flex-1 mt-2">
          <div className="h-full rounded-lg border overflow-hidden p-3 grid grid-cols-2 gap-2" style={{ backgroundColor: config.theme.backgroundMode === 'dark' ? '#1a1a2e' : '#f8fafc' }}>
            {[1,2,3,4].map(i => (
              <div key={i} className="rounded-lg border bg-white dark:bg-gray-900 p-2">
                <div className="h-2 w-12 rounded mb-2" style={{ backgroundColor: config.theme.primaryColor }} />
                <div className="h-8 rounded bg-gray-100 dark:bg-gray-800" />
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};
