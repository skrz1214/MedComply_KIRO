import React from 'react';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { AppShellConfig, ButtonStyle, Density } from '@/types/brandingConfig';
import { PanelLeft, LayoutDashboard, RectangleHorizontal, Maximize2 } from 'lucide-react';
import { FieldTooltip, BRANDING_TOOLTIPS } from './BrandingTooltips';

interface AppShellCardContentProps {
  config: AppShellConfig;
  onChange: (updates: Partial<AppShellConfig>) => void;
}

export const AppShellCardContent: React.FC<AppShellCardContentProps> = ({
  config,
  onChange,
}) => {
  return (
    <div className="space-y-6">
      {/* Sidebar Settings */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <PanelLeft className="h-4 w-4 text-muted-foreground" />
          <Label className="text-sm font-medium">Sidebar</Label>
        </div>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div>
              <Label className="text-sm">
                Expanded by Default
                <FieldTooltip content={BRANDING_TOOLTIPS.appShell.sidebarExpandedByDefault} />
              </Label>
              <p className="text-xs text-muted-foreground">Sidebar starts in expanded state</p>
            </div>
            <Switch
              checked={config.sidebarExpandedByDefault}
              onCheckedChange={(v) => onChange({ sidebarExpandedByDefault: v })}
            />
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg border border-border">
            <div>
              <Label className="text-sm">
                Show Labels with Icons
                <FieldTooltip content={BRANDING_TOOLTIPS.appShell.sidebarShowLabels} />
              </Label>
              <p className="text-xs text-muted-foreground">Display text labels next to navigation icons</p>
            </div>
            <Switch
              checked={config.sidebarShowLabels}
              onCheckedChange={(v) => onChange({ sidebarShowLabels: v })}
            />
          </div>
        </div>
      </div>

      {/* Header Settings */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <LayoutDashboard className="h-4 w-4 text-muted-foreground" />
          <Label className="text-sm font-medium">Header</Label>
        </div>
        <div className="flex items-center justify-between p-3 rounded-lg border border-border">
          <div>
            <Label className="text-sm">
              Show Organization Name
              <FieldTooltip content={BRANDING_TOOLTIPS.appShell.headerShowOrgName} />
            </Label>
            <p className="text-xs text-muted-foreground">Display org name in the main header</p>
          </div>
          <Switch
            checked={config.headerShowOrgName}
            onCheckedChange={(v) => onChange({ headerShowOrgName: v })}
          />
        </div>
      </div>

      {/* Button Style */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <RectangleHorizontal className="h-4 w-4 text-muted-foreground" />
          <Label className="text-sm font-medium">
            Button Style
            <FieldTooltip content={BRANDING_TOOLTIPS.appShell.buttonStyle} />
          </Label>
        </div>
        <RadioGroup
          value={config.buttonStyle}
          onValueChange={(v) => onChange({ buttonStyle: v as ButtonStyle })}
          className="grid grid-cols-2 gap-3"
        >
          <div
            className={`flex flex-col items-center p-4 rounded-lg border transition-colors cursor-pointer ${
              config.buttonStyle === 'standard'
                ? 'border-primary bg-primary/5'
                : 'border-border hover:bg-muted/50'
            }`}
            onClick={() => onChange({ buttonStyle: 'standard' })}
          >
            <RadioGroupItem value="standard" id="btn-standard" className="sr-only" />
            <div className="w-full px-4 py-2 bg-primary text-primary-foreground text-center text-sm rounded-md mb-2">
              Standard
            </div>
            <Label htmlFor="btn-standard" className="text-xs text-muted-foreground cursor-pointer">
              Standard corners
            </Label>
          </div>
          <div
            className={`flex flex-col items-center p-4 rounded-lg border transition-colors cursor-pointer ${
              config.buttonStyle === 'extra_rounded'
                ? 'border-primary bg-primary/5'
                : 'border-border hover:bg-muted/50'
            }`}
            onClick={() => onChange({ buttonStyle: 'extra_rounded' })}
          >
            <RadioGroupItem value="extra_rounded" id="btn-rounded" className="sr-only" />
            <div className="w-full px-4 py-2 bg-primary text-primary-foreground text-center text-sm rounded-full mb-2">
              Rounded
            </div>
            <Label htmlFor="btn-rounded" className="text-xs text-muted-foreground cursor-pointer">
              Extra rounded
            </Label>
          </div>
        </RadioGroup>
      </div>

      {/* Density */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Maximize2 className="h-4 w-4 text-muted-foreground" />
          <Label className="text-sm font-medium">
            Density
            <FieldTooltip content={BRANDING_TOOLTIPS.appShell.density} />
          </Label>
        </div>
        <RadioGroup
          value={config.density}
          onValueChange={(v) => onChange({ density: v as Density })}
          className="grid grid-cols-2 gap-3"
        >
          <div
            className={`flex items-center space-x-3 p-3 rounded-lg border transition-colors ${
              config.density === 'comfortable'
                ? 'border-primary bg-primary/5'
                : 'border-border hover:bg-muted/50'
            }`}
          >
            <RadioGroupItem value="comfortable" id="density-comfortable" />
            <div>
              <Label htmlFor="density-comfortable" className="font-medium cursor-pointer">Comfortable</Label>
              <p className="text-xs text-muted-foreground">More spacing (default)</p>
            </div>
          </div>
          <div
            className={`flex items-center space-x-3 p-3 rounded-lg border transition-colors ${
              config.density === 'compact'
                ? 'border-primary bg-primary/5'
                : 'border-border hover:bg-muted/50'
            }`}
          >
            <RadioGroupItem value="compact" id="density-compact" />
            <div>
              <Label htmlFor="density-compact" className="font-medium cursor-pointer">Compact</Label>
              <p className="text-xs text-muted-foreground">Tighter spacing</p>
            </div>
          </div>
        </RadioGroup>
      </div>
    </div>
  );
};
