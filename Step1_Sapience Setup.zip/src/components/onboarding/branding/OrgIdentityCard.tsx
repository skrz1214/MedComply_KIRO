import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { OrgIdentityConfig } from '@/types/brandingConfig';
import { FieldTooltip, BRANDING_TOOLTIPS } from './BrandingTooltips';

interface OrgIdentityCardContentProps {
  config: OrgIdentityConfig;
  onChange: (updates: Partial<OrgIdentityConfig>) => void;
  defaultOrgName?: string;
}

export const OrgIdentityCardContent: React.FC<OrgIdentityCardContentProps> = ({
  config,
  onChange,
  defaultOrgName,
}) => {
  return (
    <div className="space-y-4">
      <div>
        <Label className="text-sm">
          Display Name <span className="text-destructive">*</span>
          <FieldTooltip content={BRANDING_TOOLTIPS.orgIdentity.displayName} />
        </Label>
        <Input
          value={config.displayName}
          onChange={(e) => onChange({ displayName: e.target.value })}
          placeholder={defaultOrgName || 'Organization display name'}
          className="mt-1"
        />
        <p className="text-xs text-muted-foreground mt-1">
          Shown in headers, emails, and user-facing screens
        </p>
      </div>
      
      <div>
        <Label className="text-sm">
          Short Name / Abbreviation
          <FieldTooltip content={BRANDING_TOOLTIPS.orgIdentity.shortName} />
        </Label>
        <Input
          value={config.shortName}
          onChange={(e) => onChange({ shortName: e.target.value })}
          placeholder="e.g., ACME Health"
          className="mt-1"
          maxLength={20}
        />
        <p className="text-xs text-muted-foreground mt-1">
          Used in tight UI spaces like collapsed sidebar
        </p>
      </div>
      
      <div>
        <Label className="text-sm">
          App Title
          <FieldTooltip content={BRANDING_TOOLTIPS.orgIdentity.appTitle} />
        </Label>
        <Input
          value={config.appTitle}
          onChange={(e) => onChange({ appTitle: e.target.value })}
          placeholder="MedComply"
          className="mt-1"
        />
        <p className="text-xs text-muted-foreground mt-1">
          Browser tab title (defaults to "MedComply")
        </p>
      </div>
    </div>
  );
};
