import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { DomainConfig, DomainStatus } from '@/types/brandingConfig';
import { Globe, CheckCircle2, Clock, XCircle } from 'lucide-react';
import { FieldTooltip, BRANDING_TOOLTIPS } from './BrandingTooltips';

interface DomainCardContentProps {
  config: DomainConfig;
  onChange: (updates: Partial<DomainConfig>) => void;
  orgCode?: string;
}

export const DomainCardContent: React.FC<DomainCardContentProps> = ({
  config,
  onChange,
  orgCode,
}) => {
  const getStatusIcon = (status: DomainStatus) => {
    switch (status) {
      case 'verified':
        return <CheckCircle2 className="h-4 w-4 text-green-600" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-amber-600" />;
      default:
        return <XCircle className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: DomainStatus) => {
    switch (status) {
      case 'verified':
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Verified</Badge>;
      case 'pending':
        return <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">Pending</Badge>;
      default:
        return <Badge variant="secondary">Not Verified</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Default Subdomain */}
      <div>
        <Label className="text-sm font-medium">
          Default Subdomain
          <FieldTooltip content={BRANDING_TOOLTIPS.domain.subdomain} />
        </Label>
        <div className="mt-1 p-3 rounded-lg bg-muted/50 border border-border">
          <div className="flex items-center gap-2">
            <Globe className="h-4 w-4 text-muted-foreground" />
            <code className="text-sm">{config.subdomain || `${orgCode || 'org'}.medcomply.example`}</code>
            <Badge variant="secondary" className="ml-auto">Default</Badge>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            This is your default access URL
          </p>
        </div>
      </div>

      {/* Custom Domain */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Label className="text-sm font-medium">
            Custom Domain
            <FieldTooltip content={BRANDING_TOOLTIPS.domain.customDomain} />
          </Label>
          <Badge variant="outline" className="text-xs">Enterprise</Badge>
        </div>
        <Input
          value={config.customDomain}
          onChange={(e) => onChange({ customDomain: e.target.value, domainStatus: 'not_verified' })}
          placeholder="compliance.yourcompany.com"
        />
        <p className="text-xs text-muted-foreground mt-1">
          Use your own domain for branded access
        </p>
        
        {config.customDomain && (
          <div className="mt-3 p-3 rounded-lg border border-border">
            <div className="flex items-center gap-2">
              {getStatusIcon(config.domainStatus)}
              <span className="text-sm font-medium">
                Domain Status
                <FieldTooltip content={BRANDING_TOOLTIPS.domain.domainStatus} />
              </span>
              {getStatusBadge(config.domainStatus)}
            </div>
            
            {config.domainStatus !== 'verified' && (
              <div className="mt-3 p-3 rounded bg-muted/50">
                <p className="text-sm font-medium mb-2">DNS Configuration Required</p>
                <p className="text-xs text-muted-foreground mb-2">
                  Add the following DNS records to verify your domain:
                </p>
                <div className="space-y-2 font-mono text-xs">
                  <div className="p-2 rounded bg-background border">
                    <span className="text-muted-foreground">Type:</span> CNAME<br />
                    <span className="text-muted-foreground">Name:</span> {config.customDomain.split('.')[0]}<br />
                    <span className="text-muted-foreground">Value:</span> proxy.medcomply.example
                  </div>
                  <div className="p-2 rounded bg-background border">
                    <span className="text-muted-foreground">Type:</span> TXT<br />
                    <span className="text-muted-foreground">Name:</span> _medcomply-verify<br />
                    <span className="text-muted-foreground">Value:</span> verify-{orgCode || 'org'}-{Date.now().toString(36)}
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  DNS changes may take up to 48 hours to propagate.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
