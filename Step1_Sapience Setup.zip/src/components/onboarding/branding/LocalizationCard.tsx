import React from 'react';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LocalizationConfig, DateFormat, TimeFormat, NumberFormat, SUPPORTED_LANGUAGES } from '@/types/brandingConfig';
import { DATE_FORMAT_OPTIONS, TIME_FORMAT_OPTIONS, NUMBER_FORMAT_OPTIONS } from '@/data/brandingPresets';
import { Globe, Calendar, Clock, Hash } from 'lucide-react';
import { FieldTooltip, BRANDING_TOOLTIPS } from './BrandingTooltips';

interface LocalizationCardContentProps {
  config: LocalizationConfig;
  onChange: (updates: Partial<LocalizationConfig>) => void;
}

export const LocalizationCardContent: React.FC<LocalizationCardContentProps> = ({
  config,
  onChange,
}) => {
  return (
    <div className="space-y-6">
      {/* Default Language */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Globe className="h-4 w-4 text-muted-foreground" />
          <Label className="text-sm font-medium">
            Default Language
            <FieldTooltip content={BRANDING_TOOLTIPS.localization.defaultLanguage} />
          </Label>
        </div>
        <Select
          value={config.defaultLanguage}
          onValueChange={(v) => onChange({ defaultLanguage: v })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {SUPPORTED_LANGUAGES.map((lang) => (
              <SelectItem key={lang.code} value={lang.code}>
                {lang.name} ({lang.nativeName})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <p className="text-xs text-muted-foreground mt-1">
          Default language for new users
        </p>
      </div>

      {/* Date Format */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Calendar className="h-4 w-4 text-muted-foreground" />
          <Label className="text-sm font-medium">
            Date Format
            <FieldTooltip content={BRANDING_TOOLTIPS.localization.dateFormat} />
          </Label>
        </div>
        <Select
          value={config.dateFormat}
          onValueChange={(v) => onChange({ dateFormat: v as DateFormat })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {DATE_FORMAT_OPTIONS.map((opt) => (
              <SelectItem key={opt.id} value={opt.id}>
                <div className="flex items-center justify-between gap-4">
                  <span>{opt.label}</span>
                  <span className="text-muted-foreground text-xs">e.g., {opt.example}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Time Format */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Clock className="h-4 w-4 text-muted-foreground" />
          <Label className="text-sm font-medium">
            Time Format
            <FieldTooltip content={BRANDING_TOOLTIPS.localization.timeFormat} />
          </Label>
        </div>
        <Select
          value={config.timeFormat}
          onValueChange={(v) => onChange({ timeFormat: v as TimeFormat })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {TIME_FORMAT_OPTIONS.map((opt) => (
              <SelectItem key={opt.id} value={opt.id}>
                <div className="flex items-center justify-between gap-4">
                  <span>{opt.label}</span>
                  <span className="text-muted-foreground text-xs">e.g., {opt.example}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Number Format */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Hash className="h-4 w-4 text-muted-foreground" />
          <Label className="text-sm font-medium">
            Number Format
            <FieldTooltip content={BRANDING_TOOLTIPS.localization.numberFormat} />
          </Label>
        </div>
        <Select
          value={config.numberFormat}
          onValueChange={(v) => onChange({ numberFormat: v as NumberFormat })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {NUMBER_FORMAT_OPTIONS.map((opt) => (
              <SelectItem key={opt.id} value={opt.id}>
                <div className="flex items-center justify-between gap-4">
                  <span>{opt.label}</span>
                  <span className="text-muted-foreground text-xs">{opt.example}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};
