import React, { useState, useEffect } from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Key, Users, Clock, Lock, ScrollText, Download, Globe, Bell, FileCheck, AlertTriangle, CheckCircle2, Save } from 'lucide-react';
import { SecurityCard } from '../security/SecurityCard';
import { IdentityAuthCardContent } from '../security/IdentityAuthCard';
import { AccessControlCardContent } from '../security/AccessControlCard';
import { SessionControlsCardContent } from '../security/SessionControlsCard';
import { EncryptionCardContent } from '../security/EncryptionCard';
import { AuditLoggingCardContent } from '../security/AuditLoggingCard';
import { ExportControlsCardContent } from '../security/ExportControlsCard';
import { NetworkControlsCardContent } from '../security/NetworkControlsCard';
import { IncidentContactsCardContent } from '../security/IncidentContactsCard';
import { GovernanceAttestationsCardContent } from '../security/GovernanceAttestationsCard';
import { SecurityBaseline, SecurityPresetType } from '@/types/securityBaseline';
import { SECURITY_PRESETS, getPresetConfig, validateSecurityBaseline, CARD_HIPAA_MAPPING, HIPAA_CATEGORIES } from '@/data/securityPresets';
import { useToast } from '@/hooks/use-toast';

export const SecurityStep: React.FC = () => {
  const { markStepComplete, nextStep } = useOnboarding();
  const { toast } = useToast();
  
  const [config, setConfig] = useState<SecurityBaseline>(() => getPresetConfig('healthcare_baseline'));
  const [expandedCards, setExpandedCards] = useState<Set<string>>(new Set(['identityAuth']));
  const [validation, setValidation] = useState(() => validateSecurityBaseline(config));

  useEffect(() => {
    setValidation(validateSecurityBaseline(config));
  }, [config]);

  const handlePresetChange = (presetId: SecurityPresetType) => {
    const newConfig = getPresetConfig(presetId);
    // Preserve contacts if already filled
    if (config.incidentContacts.securityContact.email) {
      newConfig.incidentContacts.securityContact = config.incidentContacts.securityContact;
    }
    if (config.incidentContacts.complianceContact.email) {
      newConfig.incidentContacts.complianceContact = config.incidentContacts.complianceContact;
    }
    setConfig(newConfig);
    toast({ title: 'Preset Applied', description: `Applied ${SECURITY_PRESETS.find(p => p.id === presetId)?.name} preset` });
  };

  const updateConfig = (key: keyof SecurityBaseline, updates: Record<string, unknown>) => {
    setConfig(prev => {
      const currentValue = prev[key];
      if (typeof currentValue === 'object' && currentValue !== null) {
        return {
          ...prev,
          [key]: { ...currentValue, ...updates },
          isCustomized: true,
        };
      }
      return prev;
    });
  };

  const toggleCard = (cardId: string) => {
    setExpandedCards(prev => {
      const next = new Set(prev);
      if (next.has(cardId)) next.delete(cardId);
      else next.add(cardId);
      return next;
    });
  };

  const handleSaveDraft = () => {
    setConfig(prev => ({ ...prev, status: 'draft' }));
    toast({ title: 'Draft Saved', description: 'Your security baseline has been saved as draft.' });
  };

  const handlePublish = () => {
    if (!validation.canPublish) {
      toast({ title: 'Cannot Publish', description: validation.errors[0], variant: 'destructive' });
      return;
    }
    setConfig(prev => ({
      ...prev,
      status: 'published',
      publishedAt: new Date().toISOString(),
      versionId: `v1-${Date.now()}`,
    }));
    toast({ title: 'Security Baseline Published', description: 'Your security configuration is now active.' });
  };

  const handleContinue = () => {
    if (config.status !== 'published') {
      toast({ title: 'Publish Required', description: 'Please publish your security baseline before continuing.', variant: 'destructive' });
      return;
    }
    markStepComplete(10);
    nextStep();
  };

  const currentPreset = SECURITY_PRESETS.find(p => p.id === config.selectedPreset);

  const cards = [
    { id: 'identityAuth', title: 'Identity & Authentication', icon: <Key className="h-5 w-5" />, required: true },
    { id: 'accessControl', title: 'Access Control Baseline', icon: <Users className="h-5 w-5" />, required: true },
    { id: 'sessionControls', title: 'Session & Device Controls', icon: <Clock className="h-5 w-5" />, required: true },
    { id: 'encryption', title: 'Encryption & Transmission Security', icon: <Lock className="h-5 w-5" />, required: true },
    { id: 'auditLogging', title: 'Audit Logging & Retention', icon: <ScrollText className="h-5 w-5" />, required: true },
    { id: 'exportControls', title: 'Export Controls', icon: <Download className="h-5 w-5" />, required: true },
    { id: 'networkControls', title: 'Network Controls', icon: <Globe className="h-5 w-5" />, required: false },
    { id: 'incidentContacts', title: 'Incident Contacts & Notifications', icon: <Bell className="h-5 w-5" />, required: true },
    { id: 'governanceAttestations', title: 'Governance Attestations', icon: <FileCheck className="h-5 w-5" />, required: true },
  ];

  return (
    <div className="space-y-6">
      {/* Header with Preset Selector */}
      <div className="p-4 rounded-lg border border-border bg-card">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Shield className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold">Security Baseline Configuration</h3>
              <p className="text-sm text-muted-foreground">HIPAA-aligned security controls</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant={config.status === 'published' ? 'default' : 'secondary'}>
              {config.status === 'published' ? 'Published' : 'Draft'}
            </Badge>
            <Select value={config.selectedPreset} onValueChange={(v) => handlePresetChange(v as SecurityPresetType)}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Select preset" />
              </SelectTrigger>
              <SelectContent>
                {SECURITY_PRESETS.map((preset) => (
                  <SelectItem key={preset.id} value={preset.id}>
                    <div className="flex items-center gap-2">
                      {preset.name}
                      {preset.badge && <Badge variant="outline" className="text-xs">{preset.badge}</Badge>}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        {currentPreset && (
          <p className="text-sm text-muted-foreground mt-3 pl-12">{currentPreset.description}</p>
        )}
      </div>

      {/* Validation Alerts */}
      {validation.errors.length > 0 && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{validation.errors[0]}</AlertDescription>
        </Alert>
      )}
      {validation.warnings.length > 0 && validation.errors.length === 0 && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{validation.warnings[0]}</AlertDescription>
        </Alert>
      )}

      {/* Security Cards */}
      <div className="space-y-3">
        {cards.map((card) => {
          const hipaa = CARD_HIPAA_MAPPING[card.id];
          return (
            <SecurityCard
              key={card.id}
              title={card.title}
              description={`Configure ${card.title.toLowerCase()} settings`}
              icon={card.icon}
              isRequired={card.required}
              isExpanded={expandedCards.has(card.id)}
              onToggle={() => toggleCard(card.id)}
              hipaaCategory={hipaa ? HIPAA_CATEGORIES[hipaa.category] : undefined}
              hipaaStandards={hipaa?.standards}
            >
              {card.id === 'identityAuth' && (
                <IdentityAuthCardContent config={config.identityAuth} onChange={(u) => updateConfig('identityAuth', u)} />
              )}
              {card.id === 'accessControl' && (
                <AccessControlCardContent config={config.accessControl} onChange={(u) => updateConfig('accessControl', u)} />
              )}
              {card.id === 'sessionControls' && (
                <SessionControlsCardContent config={config.sessionControls} onChange={(u) => updateConfig('sessionControls', u)} />
              )}
              {card.id === 'encryption' && (
                <EncryptionCardContent config={config.encryption} onChange={(u) => updateConfig('encryption', u)} />
              )}
              {card.id === 'auditLogging' && (
                <AuditLoggingCardContent config={config.auditLogging} onChange={(u) => updateConfig('auditLogging', u)} />
              )}
              {card.id === 'exportControls' && (
                <ExportControlsCardContent config={config.exportControls} onChange={(u) => updateConfig('exportControls', u)} />
              )}
              {card.id === 'networkControls' && (
                <NetworkControlsCardContent config={config.networkControls} onChange={(u) => updateConfig('networkControls', u)} />
              )}
              {card.id === 'incidentContacts' && (
                <IncidentContactsCardContent config={config.incidentContacts} onChange={(u) => updateConfig('incidentContacts', u)} />
              )}
              {card.id === 'governanceAttestations' && (
                <GovernanceAttestationsCardContent config={config.governanceAttestations} onChange={(u) => updateConfig('governanceAttestations', u)} />
              )}
            </SecurityCard>
          );
        })}
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row justify-between gap-3 pt-4 border-t">
        <Button variant="outline" onClick={handleSaveDraft}>
          <Save className="h-4 w-4 mr-2" />
          Save Draft
        </Button>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={handlePublish} disabled={!validation.canPublish}>
            <CheckCircle2 className="h-4 w-4 mr-2" />
            Publish Security Baseline
          </Button>
          <Button onClick={handleContinue} disabled={config.status !== 'published'}>
            Continue
          </Button>
        </div>
      </div>
    </div>
  );
};
