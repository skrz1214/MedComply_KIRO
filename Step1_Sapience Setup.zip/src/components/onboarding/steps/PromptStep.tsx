import React from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { usePdfDownload } from '@/hooks/usePdfDownload';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, FileText, Copy, Check } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export const PromptStep: React.FC = () => {
  const { data, nextStep, prevStep, markStepComplete } = useOnboarding();
  const { contentRef, downloadPdf } = usePdfDownload();
  const [copied, setCopied] = React.useState(false);

  const handleDownload = () => {
    const orgName = data.organization.name || 'Organization';
    downloadPdf({
      filename: `${orgName.replace(/\s+/g, '_')}_Configuration_Prompt.pdf`,
      title: 'Configuration Prompt Document',
    });
  };

  const generatePromptContent = () => {
    const org = data.organization;
    const facilities = data.facilities;
    const departments = data.departments;
    const microapps = data.microapps.filter(m => m.status === 'enabled');
    const roles = data.roles;
    const users = data.users;
    const lovCategories = data.lovCategories;
    const security = data.securitySettings;
    const branding = data.brandingSettings;
    const tenant = data.tenantSettings;
    const appAccess = data.appAccessEntitlements;

    return `
# MedComply Configuration Prompt

## Document Purpose
This document serves as a comprehensive configuration prompt that captures all setup parameters, organizational structure, and system configurations for the MedComply platform. This prompt can be used to replicate the environment, serve as a reference for system administrators, or provide context for AI-assisted support and development.

---

## 1. Organization Configuration

### 1.1 Organization Identity
- **Organization Name:** ${org.name || 'Not specified'}
- **Legal Entity Name:** ${org.legalEntityName || 'Same as organization name'}
- **Organization Code:** ${org.orgCode || 'Not specified'}
- **Organization Type:** ${org.orgType || 'Not specified'}
- **Industry:** ${org.industry || 'Healthcare Provider'}
- **NPI Number:** ${org.npi || 'Not provided'}
- **Tax ID:** ${org.taxId || 'Not provided'}
- **CCN (CMS Certification Number):** ${org.ccn || 'Not provided'}
- **Accreditor:** ${org.accreditor || 'None'}

### 1.2 Primary Contact Information
- **Contact Name:** ${org.primaryContactName || 'Not specified'}
- **Contact Email:** ${org.primaryContactEmail || 'Not specified'}
- **Contact Phone:** ${org.primaryContactPhone || 'Not provided'}
- **Implementation Owner:** ${org.implementationOwner || 'Not specified'}
- **Secondary Compliance Contact:** ${org.secondaryComplianceContact || 'Not provided'}

### 1.3 Location & Time
- **Address Line 1:** ${org.addressLine1 || 'Not specified'}
- **Address Line 2:** ${org.addressLine2 || 'N/A'}
- **City:** ${org.city || 'Not specified'}
- **State/Province:** ${org.stateProvince || 'Not specified'}
- **Country:** ${org.country || 'United States'}
- **ZIP/Postal Code:** ${org.zipPostal || 'Not specified'}
- **Time Zone:** ${org.timeZone || 'Not specified'}

### 1.4 Organization Structure
- **Single Facility Mode:** ${org.singleFacilityMode ? 'Yes' : 'No'}
- **Number of Facilities:** ${org.numberOfFacilities || 'Not specified'}
- **Number of Departments:** ${org.numberOfDepartments || 'Not specified'}
- **Estimated Users:** ${org.estimatedUsers || 'Not specified'}
- **Has Parent Organization:** ${org.hasParentOrg ? 'Yes' : 'No'}
${org.hasParentOrg ? `- **Parent Organization Name:** ${org.parentOrgName || 'Not specified'}
- **Parent Organization Code:** ${org.parentOrgCode || 'Not specified'}` : ''}

### 1.5 Compliance Scope
- **Core Compliance Tags:** ${org.coreComplianceTags?.join(', ') || 'None selected'}
- **Advanced Compliance Tags:** ${org.advancedComplianceTags?.join(', ') || 'None selected'}
- **Regulatory Bodies:** ${data.regulatoryBodies?.join(', ') || 'None selected'}
- **Compliance Frameworks:** ${data.complianceFrameworks?.join(', ') || 'None selected'}

---

## 2. Tenant & Licensing Configuration

### 2.1 Tenant Settings
- **Organization Type:** ${tenant.orgType || 'standalone'}
- **License Tier:** ${tenant.licenseTier || 'premium'}
- **Data Residency Region:** ${tenant.dataResidencyRegion || 'US East'}
- **Maximum Users Allowed:** ${tenant.maxUsersAllowed || 50}
- **Maximum Departments Allowed:** ${tenant.maxDepartmentsAllowed || 'Unlimited'}
- **Storage Quota (GB):** ${tenant.storageQuotaGB || 'Default'}
- **Admin Delegation Allowed:** ${tenant.adminDelegationAllowed ? 'Yes' : 'No'}
- **Role Override by Parent:** ${tenant.roleOverrideByParent ? 'Yes' : 'No'}
- **License Expiry:** ${tenant.licenseExpiry || 'Not set'}

---

## 3. Facilities Configuration

### 3.1 Facilities List
${facilities.length > 0 ? facilities.map((f, i) => `
#### Facility ${i + 1}: ${f.name}
- **Code:** ${f.code}
- **Type:** ${f.type}
- **Status:** ${f.status}
- **Time Zone:** ${f.timeZone}
- **Same as Org Address:** ${f.sameAsOrgAddress ? 'Yes' : 'No'}
${!f.sameAsOrgAddress ? `- **Address:** ${f.address || 'Not specified'}, ${f.city || ''}, ${f.stateProvince || ''} ${f.zipPostal || ''}, ${f.country || ''}` : ''}
- **Is Parent Facility:** ${f.isParent ? 'Yes' : 'No'}
${f.parentFacilityId ? `- **Parent Facility ID:** ${f.parentFacilityId}` : ''}
`).join('\n') : 'No facilities configured.'}

**Total Facilities:** ${facilities.length}

---

## 4. Departments Configuration

### 4.1 Departments List
${departments.length > 0 ? departments.map((d, i) => `
#### Department ${i + 1}: ${d.name}
- **Code:** ${d.code}
- **Description:** ${d.description || 'No description'}
- **Status:** ${d.status}
- **Assigned Facilities:** ${d.facilityIds.length > 0 ? d.facilityIds.map(fid => facilities.find(f => f.id === fid)?.name || fid).join(', ') : 'All facilities'}
`).join('\n') : 'No departments configured.'}

**Total Departments:** ${departments.length}

---

## 5. Microapps Configuration

### 5.1 Enabled Microapps
${microapps.length > 0 ? microapps.map((m, i) => `
#### Microapp ${i + 1}: ${m.name}
- **Code:** ${m.code}
- **Description:** ${m.description}
- **Status:** ${m.status}
- **Modules:** ${m.modules?.join(', ') || 'All modules'}
- **Risk Level:** ${m.riskLevel}
- **Audit Logging Enabled:** ${m.auditLoggingEnabled ? 'Yes' : 'No'}
- **Integration Required:** ${m.integrationRequired ? 'Yes' : 'No'}
${m.integrationDetails ? `- **Integration Details:** ${m.integrationDetails}` : ''}
`).join('\n') : 'No microapps enabled.'}

**Total Enabled Microapps:** ${microapps.length}

---

## 6. Roles & Permissions Configuration

### 6.1 Roles List
${roles.length > 0 ? roles.map((r, i) => `
#### Role ${i + 1}: ${r.name}
- **Type:** ${r.type}
- **System Role:** ${r.isSystemRole ? 'Yes' : 'No'}
- **Description:** ${r.description}
- **Assigned Departments:** ${r.departmentIds.length > 0 ? r.departmentIds.map(did => departments.find(d => d.id === did)?.name || did).join(', ') : 'All departments'}
- **Assigned Microapps:** ${r.microappIds.length > 0 ? r.microappIds.map(mid => data.microapps.find(m => m.id === mid)?.name || mid).join(', ') : 'All microapps'}
${r.entitlements?.length > 0 ? `- **Entitlements:**
${r.entitlements.map(e => `  - ${e.objectArea}: ${e.scope} scope, capabilities: ${e.capabilities.join(', ')}`).join('\n')}` : ''}
`).join('\n') : 'No roles configured.'}

**Total Roles:** ${roles.length}

---

## 7. App Access Entitlements

### 7.1 Access Configuration
- **Selected Preset:** ${appAccess.selectedPreset || 'None'}
- **Is Customized:** ${appAccess.isCustomized ? 'Yes' : 'No'}

### 7.2 Role Entitlements Summary
${Object.entries(appAccess.roleEntitlements || {}).map(([roleId, entitlements]) => {
  const role = roles.find(r => r.id === roleId);
  return `
#### ${role?.name || roleId}
- **Exports Allowed:** ${entitlements.exportsAllowed ? 'Yes' : 'No'}
- **Export Scope:** ${entitlements.exportScope}
- **Dashboard Flags:**
  - Can Export CSV: ${entitlements.dashboardFlags?.canExportCsv ? 'Yes' : 'No'}
  - Can View Cross-App KPIs: ${entitlements.dashboardFlags?.canViewCrossAppKpis ? 'Yes' : 'No'}
`;
}).join('\n')}

---

## 8. Users Configuration

### 8.1 Users List
${users.length > 0 ? users.map((u, i) => `
#### User ${i + 1}: ${u.firstName} ${u.lastName}
- **Email:** ${u.email}
- **Job Title:** ${u.jobTitle || 'Not specified'}
- **Status:** ${u.status}
- **MFA Enabled:** ${u.mfaEnabled ? 'Yes' : 'No'}
- **Preferred Language:** ${u.preferredLanguage || 'English'}
- **Time Zone:** ${u.timeZone || 'Default'}
- **Assigned Departments:** ${u.departmentIds.length > 0 ? u.departmentIds.map(did => departments.find(d => d.id === did)?.name || did).join(', ') : 'None'}
- **Assigned Roles:** ${u.roleIds.length > 0 ? u.roleIds.map(rid => roles.find(r => r.id === rid)?.name || rid).join(', ') : 'None'}
- **Invite Sent:** ${u.inviteSent ? 'Yes' : 'No'}
${u.notes ? `- **Notes:** ${u.notes}` : ''}
${u.tags?.length ? `- **Tags:** ${u.tags.join(', ')}` : ''}
`).join('\n') : 'No users configured.'}

**Total Users:** ${users.length}

---

## 9. LOV / Value Sets Configuration

### 9.1 Value Set Categories
${lovCategories.length > 0 ? lovCategories.map((cat, i) => `
#### Category ${i + 1}: ${cat.name}
- **Description:** ${cat.description}
- **Is Locked:** ${cat.isLocked ? 'Yes' : 'No'}
- **Values:** ${cat.values?.length || 0} configured
${cat.values?.length > 0 ? `  - ${cat.values.slice(0, 10).map(v => `${v.label} (${v.value})`).join(', ')}${cat.values.length > 10 ? ` ... and ${cat.values.length - 10} more` : ''}` : ''}
`).join('\n') : 'No value sets configured.'}

**Total Categories:** ${lovCategories.length}

---

## 10. Security & Audit Configuration

### 10.1 Security Settings
- **Audit Logging Enabled:** ${security.auditLoggingEnabled ? 'Yes' : 'No'}
- **Log Retention (Days):** ${security.logRetentionDays || 365}
- **MFA Enforcement:** ${security.mfaEnforcement || 'required'}
- **Session Timeout (Minutes):** ${security.sessionTimeoutMinutes || 30}
- **Data Access Scope:** ${security.dataAccessScope || 'standard'}
- **Notifications Enabled:** ${security.notificationsEnabled ? 'Yes' : 'No'}
${security.ipRestrictions?.length ? `- **IP Restrictions:** ${security.ipRestrictions.join(', ')}` : '- **IP Restrictions:** None configured'}

---

## 11. Branding & Localization Configuration

### 11.1 Branding Settings
- **Primary Color:** ${branding.primaryColor || '#1e3a5f'}
- **Secondary Color:** ${branding.secondaryColor || 'Not set'}
- **Default Language:** ${branding.defaultLanguage || 'en'}
- **Custom Domain:** ${branding.customDomain || 'Not configured'}
- **Custom Login Message:** ${branding.customLoginMessage || 'None'}
- **Logo URL:** ${branding.logoUrl || 'Default logo'}
- **Apply to Children:** ${branding.applyToChildren ? 'Yes' : 'No'}
- **Allow Child Override:** ${branding.allowChildOverride ? 'Yes' : 'No'}

---

## 12. Configuration Summary

### 12.1 Quick Stats
| Metric | Value |
|--------|-------|
| Total Facilities | ${facilities.length} |
| Total Departments | ${departments.length} |
| Total Users | ${users.length} |
| Total Roles | ${roles.length} |
| Enabled Microapps | ${microapps.length} |
| Value Set Categories | ${lovCategories.length} |
| Regulatory Bodies | ${data.regulatoryBodies?.length || 0} |
| Compliance Frameworks | ${data.complianceFrameworks?.length || 0} |

### 12.2 Activation Status
- **Is Activated:** ${data.isActivated ? 'Yes' : 'No'}
- **Last Saved:** ${data.lastSavedAt ? new Date(data.lastSavedAt).toLocaleString() : 'Never'}
- **Completed Steps:** ${data.completedSteps.length} / 17

---

## 13. AI Assistant Context

This configuration prompt provides complete context for AI-assisted support. When using this document with an AI assistant:

1. **Environment Replication:** Use sections 1-11 to recreate this exact configuration
2. **Troubleshooting:** Reference specific sections when diagnosing issues
3. **Customization:** Identify current settings before suggesting changes
4. **Compliance Verification:** Validate settings against regulatory requirements
5. **User Support:** Understand role-based access when assisting users

---

## Document Metadata

- **Generated:** ${new Date().toLocaleString()}
- **Organization:** ${org.name || 'Draft Configuration'}
- **Document Version:** 1.0
- **Platform:** MedComply by Sapience Technology
    `.trim();
  };

  const promptContent = generatePromptContent();

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(promptContent);
      setCopied(true);
      toast({
        title: 'Copied to Clipboard',
        description: 'The configuration prompt has been copied.',
      });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({
        title: 'Copy Failed',
        description: 'Could not copy to clipboard. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Configuration Prompt</h2>
          <p className="text-muted-foreground">
            Comprehensive configuration document for system replication and AI assistance
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleCopy}>
            {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
            {copied ? 'Copied!' : 'Copy'}
          </Button>
          <Button onClick={handleDownload}>
            <Download className="w-4 h-4 mr-2" />
            Download PDF
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Configuration Prompt Document
          </CardTitle>
          <CardDescription>
            This document contains all configuration parameters and can be used to replicate the environment or provide context for AI-assisted support.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div 
            ref={contentRef}
            className="bg-muted/30 rounded-lg p-6 max-h-[600px] overflow-y-auto"
          >
            <div className="prose prose-sm dark:prose-invert max-w-none">
              <pre className="whitespace-pre-wrap font-mono text-xs leading-relaxed text-foreground">
                {promptContent}
              </pre>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between pt-4">
        <Button variant="outline" onClick={prevStep}>
          Back
        </Button>
        <Button onClick={() => { markStepComplete(17); nextStep(); }}>
          Complete
        </Button>
      </div>
    </div>
  );
};
