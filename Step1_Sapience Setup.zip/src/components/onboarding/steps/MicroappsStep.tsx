import React from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { 
  LayoutDashboard, 
  Building, 
  User, 
  Shield,
  ClipboardCheck,
  MessageSquare,
  Gavel,
  AlertTriangle,
  Info,
} from 'lucide-react';

const APP_ICONS: Record<string, React.ElementType> = {
  FEEDBACK: MessageSquare,
  COMPLIANCE: Shield,
  RISK: AlertTriangle,
  ENFORCE: Gavel,
  AUDIT: ClipboardCheck,
};

interface DashboardSettings {
  masterDashboardEnabled: boolean;
  departmentDashboardEnabled: boolean;
  individualDashboardEnabled: boolean;
}

export const MicroappsStep: React.FC = () => {
  const { data, updateMicroapp, updateTenantSettings, markStepComplete, nextStep } = useOnboarding();

  // Get dashboard settings from tenant settings or use defaults
  const dashboardSettings: DashboardSettings = {
    masterDashboardEnabled: data.tenantSettings.featureFlags?.masterDashboard ?? true,
    departmentDashboardEnabled: data.tenantSettings.featureFlags?.departmentDashboard ?? true,
    individualDashboardEnabled: data.tenantSettings.featureFlags?.individualDashboard ?? true,
  };

  const updateDashboardSetting = (key: keyof DashboardSettings, value: boolean) => {
    const featureFlagKey = key === 'masterDashboardEnabled' ? 'masterDashboard' 
      : key === 'departmentDashboardEnabled' ? 'departmentDashboard' 
      : 'individualDashboard';
    
    updateTenantSettings({
      featureFlags: {
        ...data.tenantSettings.featureFlags,
        [featureFlagKey]: value,
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Dashboards Section */}
      <div className="form-section">
        <h3 className="form-section-title flex items-center gap-2">
          <LayoutDashboard className="w-5 h-5" />
          Dashboards
        </h3>
        <p className="text-sm text-muted-foreground mb-4">
          Configure which dashboard views are available in your organization.
        </p>

        <div className="space-y-4">
          {/* Master Compliance Dashboard */}
          <div className="flex items-start justify-between p-4 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <LayoutDashboard className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium">Master Compliance Dashboard</span>
                  <Badge variant="secondary" className="text-xs">Required</Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Organization-wide compliance overview with KPIs, trends, and cross-app insights. 
                  Available to Compliance Heads and Org Admins.
                </p>
              </div>
            </div>
            <Switch 
              checked={dashboardSettings.masterDashboardEnabled} 
              onCheckedChange={v => updateDashboardSetting('masterDashboardEnabled', v)}
              disabled={true} // Master dashboard is always enabled
            />
          </div>

          {/* Department Dashboard */}
          <div className="flex items-start justify-between p-4 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-secondary/50 flex items-center justify-center">
                <Building className="w-5 h-5 text-muted-foreground" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium">Department Dashboard</span>
                  <Badge variant="outline" className="text-xs">Recommended</Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Department-scoped view showing team compliance status, pending tasks, and department-level metrics. 
                  Available to Department Heads.
                </p>
              </div>
            </div>
            <Switch 
              checked={dashboardSettings.departmentDashboardEnabled} 
              onCheckedChange={v => updateDashboardSetting('departmentDashboardEnabled', v)}
            />
          </div>

          {/* Individual User Dashboard */}
          <div className="flex items-start justify-between p-4 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-secondary/50 flex items-center justify-center">
                <User className="w-5 h-5 text-muted-foreground" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium">Individual User Dashboard</span>
                  <Badge variant="outline" className="text-xs">Recommended</Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Personal dashboard showing assigned tasks, training status, and individual compliance items. 
                  Available to all Staff members.
                </p>
              </div>
            </div>
            <Switch 
              checked={dashboardSettings.individualDashboardEnabled} 
              onCheckedChange={v => updateDashboardSetting('individualDashboardEnabled', v)}
            />
          </div>
        </div>
      </div>

      {/* Microapps Section */}
      <div className="form-section">
        <h3 className="form-section-title flex items-center gap-2">
          <Shield className="w-5 h-5" />
          Microapps
        </h3>
        <p className="text-sm text-muted-foreground mb-4">
          Enable the compliance modules your organization needs. Disabled apps won't appear in the suite.
        </p>

        <div className="space-y-4">
          {data.microapps.map(app => {
            const Icon = APP_ICONS[app.code] || Shield;
            return (
              <div key={app.id} className="flex items-start justify-between p-4 rounded-lg border border-border">
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    app.status === 'enabled' ? 'bg-primary/10' : 'bg-muted'
                  }`}>
                    <Icon className={`w-5 h-5 ${app.status === 'enabled' ? 'text-primary' : 'text-muted-foreground'}`} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium">{app.name}</span>
                      {app.riskLevel === 'high' && (
                        <Badge variant="destructive" className="text-xs">High Risk</Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{app.description}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {app.modules.map(m => (
                        <Badge key={m} variant="secondary" className="text-xs">{m}</Badge>
                      ))}
                    </div>
                  </div>
                </div>
                <Switch 
                  checked={app.status === 'enabled'} 
                  onCheckedChange={v => updateMicroapp(app.id, { status: v ? 'enabled' : 'disabled' })} 
                />
              </div>
            );
          })}
        </div>
      </div>

      {/* Info Note */}
      <div className="p-4 rounded-lg bg-muted/50 border border-border text-sm text-muted-foreground flex items-start gap-3">
        <Info className="w-5 h-5 mt-0.5 flex-shrink-0" />
        <div>
          <p className="font-medium text-foreground mb-1">Access Configuration</p>
          <p>
            After enabling apps and dashboards here, you'll configure which roles can access them 
            in the "App & Dashboard Access" step.
          </p>
        </div>
      </div>

      <div className="flex justify-end">
        <Button onClick={() => { markStepComplete(5); nextStep(); }}>Continue</Button>
      </div>
    </div>
  );
};
