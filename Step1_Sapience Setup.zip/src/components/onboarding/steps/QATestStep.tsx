import React from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { usePdfDownload } from '@/hooks/usePdfDownload';
import { 
  TestTube2, 
  Shield, 
  Users, 
  Building2, 
  Layers,
  Database,
  Lock,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Download
} from 'lucide-react';

interface TestCase {
  id: string;
  category: string;
  title: string;
  description: string;
  steps: string[];
  expectedResult: string;
  priority: 'critical' | 'high' | 'medium' | 'low';
}

export const QATestStep: React.FC = () => {
  const { data } = useOnboarding();
  const org = data.organization;
  const { contentRef, downloadPdf } = usePdfDownload();

  const handleDownload = () => {
    const orgName = org.name || 'Organization';
    const filename = `QA_Test_Scenarios_${orgName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;
    downloadPdf({ filename, title: 'QA Test Scenarios' });
  };

  const testCases: TestCase[] = [
    // Authentication Tests
    {
      id: 'AUTH-001',
      category: 'Authentication',
      title: 'Valid User Login',
      description: 'Verify that users can log in with valid credentials',
      steps: [
        'Navigate to login page',
        'Enter valid email address',
        'Enter valid password',
        'Click Login button'
      ],
      expectedResult: 'User is authenticated and redirected to dashboard',
      priority: 'critical'
    },
    {
      id: 'AUTH-002',
      category: 'Authentication',
      title: 'Invalid Credentials Rejection',
      description: 'Verify that invalid credentials are rejected',
      steps: [
        'Navigate to login page',
        'Enter valid email address',
        'Enter incorrect password',
        'Click Login button'
      ],
      expectedResult: 'Error message displayed, user remains on login page',
      priority: 'critical'
    },
    {
      id: 'AUTH-003',
      category: 'Authentication',
      title: 'MFA Verification',
      description: 'Verify MFA flow works correctly',
      steps: [
        'Log in with valid credentials',
        'Receive MFA code via configured method',
        'Enter valid MFA code',
        'Submit verification'
      ],
      expectedResult: 'User completes MFA and accesses the application',
      priority: 'critical'
    },
    {
      id: 'AUTH-004',
      category: 'Authentication',
      title: 'Session Timeout',
      description: `Verify session expires after ${data.securitySettings.sessionTimeoutMinutes || 30} minutes of inactivity`,
      steps: [
        'Log in successfully',
        `Wait for ${data.securitySettings.sessionTimeoutMinutes || 30} minutes without activity`,
        'Attempt to perform any action'
      ],
      expectedResult: 'User is logged out and redirected to login page',
      priority: 'high'
    },
    // Role-Based Access Tests
    {
      id: 'RBAC-001',
      category: 'Access Control',
      title: 'Org Admin Full Access',
      description: 'Verify Org Admin can access all system features',
      steps: [
        'Log in as Org Admin user',
        'Navigate to Organization Settings',
        'Navigate to User Management',
        'Navigate to Security Settings',
        'Navigate to all microapps'
      ],
      expectedResult: 'All navigation items accessible, all actions permitted',
      priority: 'critical'
    },
    {
      id: 'RBAC-002',
      category: 'Access Control',
      title: 'Staff Limited Access',
      description: 'Verify Staff role has limited access scope',
      steps: [
        'Log in as Staff user',
        'Attempt to access Organization Settings',
        'Attempt to modify other users',
        'Access assigned tasks only'
      ],
      expectedResult: 'Admin features hidden/blocked, only personal scope visible',
      priority: 'critical'
    },
    {
      id: 'RBAC-003',
      category: 'Access Control',
      title: 'Department Head Scope',
      description: 'Verify Department Head sees department-level data only',
      steps: [
        'Log in as Department Head',
        'View department dashboard',
        'Attempt to access other departments',
        'Manage department users'
      ],
      expectedResult: 'Only assigned department data visible and manageable',
      priority: 'high'
    },
    // Facility Management Tests
    {
      id: 'FAC-001',
      category: 'Facility Management',
      title: 'Create New Facility',
      description: 'Verify facility creation with all required fields',
      steps: [
        'Navigate to Facilities section',
        'Click Add Facility',
        'Fill in all required fields',
        'Save facility'
      ],
      expectedResult: 'Facility created and appears in facility list',
      priority: 'high'
    },
    {
      id: 'FAC-002',
      category: 'Facility Management',
      title: 'Facility Data Isolation',
      description: 'Verify data isolation between facilities',
      steps: [
        'Create records in Facility A',
        'Switch context to Facility B',
        'Query for Facility A records'
      ],
      expectedResult: 'Facility A records not visible in Facility B context',
      priority: 'critical'
    },
    // Microapp Tests
    ...data.microapps.filter(m => m.status === 'enabled').slice(0, 3).map((app, idx) => ({
      id: `APP-00${idx + 1}`,
      category: 'Microapps',
      title: `${app.name} Core Functions`,
      description: `Verify ${app.name} primary functionality works correctly`,
      steps: [
        `Navigate to ${app.name}`,
        'Verify dashboard loads',
        'Create new record',
        'Edit existing record',
        'Delete record'
      ],
      expectedResult: 'All CRUD operations complete successfully with audit logging',
      priority: 'high' as const
    })),
    // Audit Logging Tests
    {
      id: 'AUDIT-001',
      category: 'Audit Logging',
      title: 'Login Events Logged',
      description: 'Verify all login attempts are logged',
      steps: [
        'Perform successful login',
        'Perform failed login attempt',
        'Query audit logs'
      ],
      expectedResult: 'Both login events appear in audit log with timestamps and details',
      priority: 'critical'
    },
    {
      id: 'AUDIT-002',
      category: 'Audit Logging',
      title: 'Data Changes Logged',
      description: 'Verify all data modifications are logged',
      steps: [
        'Create new record',
        'Update record',
        'Delete record',
        'Query audit logs'
      ],
      expectedResult: 'All CRUD operations logged with before/after values',
      priority: 'critical'
    },
    // Data Validation Tests
    {
      id: 'VAL-001',
      category: 'Data Validation',
      title: 'Required Field Validation',
      description: 'Verify required fields cannot be empty',
      steps: [
        'Open any form with required fields',
        'Leave required fields empty',
        'Attempt to submit form'
      ],
      expectedResult: 'Validation error displayed, form not submitted',
      priority: 'high'
    },
    {
      id: 'VAL-002',
      category: 'Data Validation',
      title: 'Email Format Validation',
      description: 'Verify email fields accept only valid formats',
      steps: [
        'Enter invalid email format (e.g., "notanemail")',
        'Enter email without domain',
        'Enter valid email format'
      ],
      expectedResult: 'Invalid formats rejected, valid format accepted',
      priority: 'medium'
    },
    // Security Tests
    {
      id: 'SEC-001',
      category: 'Security',
      title: 'SQL Injection Prevention',
      description: 'Verify application is protected against SQL injection',
      steps: [
        'Enter SQL injection payload in text fields',
        'Submit form',
        'Check for unexpected behavior'
      ],
      expectedResult: 'Input sanitized, no SQL executed, normal error handling',
      priority: 'critical'
    },
    {
      id: 'SEC-002',
      category: 'Security',
      title: 'XSS Prevention',
      description: 'Verify application is protected against XSS attacks',
      steps: [
        'Enter script tags in text fields',
        'Submit and view rendered content',
        'Check for script execution'
      ],
      expectedResult: 'Scripts not executed, content properly escaped',
      priority: 'critical'
    },
    // Performance Tests
    {
      id: 'PERF-001',
      category: 'Performance',
      title: 'Dashboard Load Time',
      description: 'Verify dashboard loads within acceptable time',
      steps: [
        'Log in to application',
        'Navigate to main dashboard',
        'Measure load time'
      ],
      expectedResult: 'Dashboard fully loads within 3 seconds',
      priority: 'high'
    },
    {
      id: 'PERF-002',
      category: 'Performance',
      title: 'Large Data Set Handling',
      description: 'Verify application handles large data sets',
      steps: [
        'Query list with 1000+ records',
        'Apply filters and sorting',
        'Verify pagination works'
      ],
      expectedResult: 'Data loads with pagination, no timeout or crash',
      priority: 'medium'
    },
  ];

  const groupedTests = testCases.reduce((acc, test) => {
    if (!acc[test.category]) {
      acc[test.category] = [];
    }
    acc[test.category].push(test);
    return acc;
  }, {} as Record<string, TestCase[]>);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Authentication': return <Lock className="w-4 h-4" />;
      case 'Access Control': return <Shield className="w-4 h-4" />;
      case 'Facility Management': return <Building2 className="w-4 h-4" />;
      case 'Microapps': return <Layers className="w-4 h-4" />;
      case 'Audit Logging': return <Database className="w-4 h-4" />;
      case 'Data Validation': return <CheckCircle2 className="w-4 h-4" />;
      case 'Security': return <AlertTriangle className="w-4 h-4" />;
      case 'Performance': return <TestTube2 className="w-4 h-4" />;
      default: return <TestTube2 className="w-4 h-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'destructive';
      case 'high': return 'default';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-heading font-bold text-foreground flex items-center gap-2">
            <TestTube2 className="w-6 h-6 text-primary" />
            QA Test Scenarios
          </h2>
          <p className="text-muted-foreground mt-1">
            Quality assurance test cases for {org.name || 'your organization'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleDownload} className="gap-2">
            <Download className="w-4 h-4" />
            Download PDF
          </Button>
          <Badge variant="outline" className="text-xs">
            {testCases.length} Test Cases
          </Badge>
          <Badge variant="outline" className="text-xs">
            Auto-Generated
          </Badge>
        </div>
      </div>

      {/* Summary Cards */}
      <div ref={contentRef}>
        <div className="grid grid-cols-4 gap-4 mb-6">
        <Card className="bg-red-500/10 border-red-500/20">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-red-600">{testCases.filter(t => t.priority === 'critical').length}</p>
            <p className="text-xs text-muted-foreground">Critical</p>
          </CardContent>
        </Card>
        <Card className="bg-orange-500/10 border-orange-500/20">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-orange-600">{testCases.filter(t => t.priority === 'high').length}</p>
            <p className="text-xs text-muted-foreground">High</p>
          </CardContent>
        </Card>
        <Card className="bg-blue-500/10 border-blue-500/20">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-blue-600">{testCases.filter(t => t.priority === 'medium').length}</p>
            <p className="text-xs text-muted-foreground">Medium</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-500/10 border-gray-500/20">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-gray-600">{testCases.filter(t => t.priority === 'low').length}</p>
            <p className="text-xs text-muted-foreground">Low</p>
          </CardContent>
        </Card>
      </div>

      <ScrollArea className="h-[calc(100vh-400px)]">
        <div className="space-y-6 pr-4">
          {Object.entries(groupedTests).map(([category, tests]) => (
            <Card key={category}>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  {getCategoryIcon(category)}
                  {category}
                  <Badge variant="secondary" className="ml-2 text-xs">{tests.length} tests</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {tests.map((test) => (
                  <div key={test.id} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <Checkbox id={test.id} />
                        <div>
                          <div className="flex items-center gap-2">
                            <code className="text-xs text-muted-foreground">{test.id}</code>
                            <span className="font-medium text-sm">{test.title}</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">{test.description}</p>
                        </div>
                      </div>
                      <Badge variant={getPriorityColor(test.priority) as any} className="text-xs capitalize">
                        {test.priority}
                      </Badge>
                    </div>
                    
                    <div className="ml-7 space-y-3">
                      <div>
                        <p className="text-xs font-medium text-muted-foreground mb-1">Test Steps:</p>
                        <ol className="text-xs text-muted-foreground space-y-1 list-decimal list-inside">
                          {test.steps.map((step, idx) => (
                            <li key={idx}>{step}</li>
                          ))}
                        </ol>
                      </div>
                      <div className="flex items-start gap-2 bg-green-500/10 p-2 rounded">
                        <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="text-xs font-medium text-green-700">Expected Result:</p>
                          <p className="text-xs text-green-600">{test.expectedResult}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>
      </ScrollArea>
      </div>
    </div>
  );
};
