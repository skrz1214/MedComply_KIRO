import React from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { usePdfDownload } from '@/hooks/usePdfDownload';
import { 
  FileText, 
  Target, 
  Users, 
  Shield, 
  Building2, 
  Layers, 
  Database,
  BookOpen,
  CheckCircle2,
  AlertTriangle,
  Info,
  Download
} from 'lucide-react';

export const PRDStep: React.FC = () => {
  const { data } = useOnboarding();
  const org = data.organization;
  const { contentRef, downloadPdf } = usePdfDownload();

  const handleDownload = () => {
    const orgName = org.name || 'Organization';
    const filename = `PRD_${orgName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;
    downloadPdf({ filename, title: 'Product Requirements Document' });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-heading font-bold text-foreground flex items-center gap-2">
            <FileText className="w-6 h-6 text-primary" />
            Product Requirements Document (PRD)
          </h2>
          <p className="text-muted-foreground mt-1">
            Comprehensive product requirements for {org.name || 'your organization'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleDownload} className="gap-2">
            <Download className="w-4 h-4" />
            Download PDF
          </Button>
          <Badge variant="outline" className="text-xs">
            Auto-Generated
          </Badge>
        </div>
      </div>

      <ScrollArea className="h-[calc(100vh-280px)]">
        <div ref={contentRef} className="space-y-6 pr-4">
          {/* Executive Summary */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                1. Executive Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-sm mb-2">1.1 Product Vision</h4>
                <p className="text-sm text-muted-foreground">
                  MedComply is a comprehensive healthcare compliance management platform designed to streamline 
                  regulatory adherence, audit management, and risk mitigation for {org.orgType || 'healthcare organizations'}. 
                  The platform provides end-to-end compliance lifecycle management with real-time monitoring, 
                  automated workflows, and comprehensive reporting capabilities.
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-2">1.2 Target Organization</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="bg-muted/50 p-3 rounded-lg">
                    <span className="text-muted-foreground">Organization:</span>
                    <p className="font-medium">{org.name || 'Not specified'}</p>
                  </div>
                  <div className="bg-muted/50 p-3 rounded-lg">
                    <span className="text-muted-foreground">Type:</span>
                    <p className="font-medium">{org.orgType || 'Not specified'}</p>
                  </div>
                  <div className="bg-muted/50 p-3 rounded-lg">
                    <span className="text-muted-foreground">Facilities:</span>
                    <p className="font-medium">{data.facilities.length} configured</p>
                  </div>
                  <div className="bg-muted/50 p-3 rounded-lg">
                    <span className="text-muted-foreground">Users:</span>
                    <p className="font-medium">{org.estimatedUsers || 'Not specified'}</p>
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-2">1.3 Business Objectives</h4>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  <li>Reduce compliance-related incidents by 80% within the first year</li>
                  <li>Automate 90% of routine compliance documentation tasks</li>
                  <li>Achieve real-time visibility into organizational compliance posture</li>
                  <li>Streamline audit preparation reducing time-to-audit by 60%</li>
                  <li>Ensure continuous regulatory readiness across all facilities</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Stakeholders & Users */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                2. Stakeholders & User Personas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-sm mb-3">2.1 Primary Stakeholders</h4>
                <div className="space-y-3">
                  {data.roles.map((role, idx) => (
                    <div key={role.id} className="border rounded-lg p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">{role.name}</span>
                        <Badge variant="secondary" className="text-xs capitalize">{role.type.replace('_', ' ')}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">{role.description}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-2">2.2 User Journey Overview</h4>
                <p className="text-sm text-muted-foreground">
                  Users interact with the system based on their role-based access levels. Organization Admins 
                  configure system-wide settings, Compliance Heads oversee compliance activities, Department 
                  Heads manage their respective areas, and Staff members execute day-to-day compliance tasks.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Functional Requirements */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Layers className="w-5 h-5 text-primary" />
                3. Functional Requirements
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-sm mb-3">3.1 Core Microapps</h4>
                <div className="grid gap-3">
                  {data.microapps.filter(app => app.status === 'enabled').map((app) => (
                    <div key={app.id} className="border rounded-lg p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">{app.name}</span>
                        <Badge variant={app.riskLevel === 'high' ? 'destructive' : app.riskLevel === 'medium' ? 'default' : 'secondary'} className="text-xs">
                          {app.riskLevel} risk
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mb-2">{app.description}</p>
                      <div className="flex flex-wrap gap-1">
                        {app.modules.map((module, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">{module}</Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-2">3.2 Dashboard Requirements</h4>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  <li>Master Compliance Dashboard with organization-wide KPIs</li>
                  <li>Department-level dashboards with filtered metrics</li>
                  <li>Individual user dashboards showing assigned tasks and deadlines</li>
                  <li>Real-time compliance score visualization</li>
                  <li>Trend analysis and predictive compliance indicators</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-2">3.3 Workflow Requirements</h4>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  <li>Configurable approval workflows for compliance documents</li>
                  <li>Automated task assignment based on roles and departments</li>
                  <li>Escalation paths for overdue items</li>
                  <li>Notification system for deadlines and status changes</li>
                  <li>Audit trail for all compliance activities</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Compliance Requirements */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                4. Compliance & Regulatory Requirements
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-sm mb-3">4.1 Core Compliance Tags</h4>
                <div className="flex flex-wrap gap-2">
                  {org.coreComplianceTags?.map((tag) => (
                    <Badge key={tag} variant="default" className="text-xs">{tag}</Badge>
                  )) || <span className="text-sm text-muted-foreground">No tags configured</span>}
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-3">4.2 Advanced Compliance Tags</h4>
                <div className="flex flex-wrap gap-2">
                  {org.advancedComplianceTags?.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                  )) || <span className="text-sm text-muted-foreground">No advanced tags configured</span>}
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-2">4.3 Regulatory Bodies</h4>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  {data.regulatoryBodies.length > 0 ? 
                    data.regulatoryBodies.map((body) => <li key={body}>{body}</li>) :
                    <li>No regulatory bodies specified</li>
                  }
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-2">4.4 Data Protection Requirements</h4>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  <li>HIPAA-compliant data storage and transmission</li>
                  <li>Role-based access control (RBAC) with least privilege principle</li>
                  <li>Audit logging with {data.securitySettings.logRetentionDays || 365}-day retention</li>
                  <li>MFA enforcement: {data.securitySettings.mfaEnforcement || 'Required'}</li>
                  <li>Session timeout: {data.securitySettings.sessionTimeoutMinutes || 30} minutes</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Non-Functional Requirements */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Database className="w-5 h-5 text-primary" />
                5. Non-Functional Requirements
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-sm mb-2 flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    Performance
                  </h4>
                  <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                    <li>Page load time &lt; 3 seconds</li>
                    <li>API response time &lt; 500ms</li>
                    <li>Support 500+ concurrent users</li>
                    <li>99.9% uptime SLA</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-sm mb-2 flex items-center gap-1">
                    <Shield className="w-4 h-4 text-blue-500" />
                    Security
                  </h4>
                  <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                    <li>End-to-end encryption (TLS 1.3)</li>
                    <li>SOC 2 Type II compliance</li>
                    <li>Regular penetration testing</li>
                    <li>Data residency: {data.tenantSettings.dataResidencyRegion || 'US East'}</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-sm mb-2 flex items-center gap-1">
                    <Building2 className="w-4 h-4 text-purple-500" />
                    Scalability
                  </h4>
                  <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                    <li>Multi-tenant architecture</li>
                    <li>Horizontal scaling capability</li>
                    <li>Support for {data.facilities.length || 1}+ facilities</li>
                    <li>Unlimited document storage</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-sm mb-2 flex items-center gap-1">
                    <AlertTriangle className="w-4 h-4 text-orange-500" />
                    Availability
                  </h4>
                  <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                    <li>24/7 system availability</li>
                    <li>Automatic failover</li>
                    <li>Daily automated backups</li>
                    <li>Disaster recovery &lt; 4 hours</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Data Dictionary */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Database className="w-5 h-5 text-primary" />
                6. Data Dictionary & Field Specifications
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Organization Entity */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-blue-500" />
                  6.1 Organization Entity
                </h4>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-2 font-medium">Field Name</th>
                        <th className="text-left p-2 font-medium">Data Type</th>
                        <th className="text-left p-2 font-medium">Required</th>
                        <th className="text-left p-2 font-medium">Validation</th>
                        <th className="text-left p-2 font-medium">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {[
                        { field: 'name', type: 'string', required: true, validation: 'Max 100 chars', desc: 'Organization display name' },
                        { field: 'legalEntityName', type: 'string', required: false, validation: 'Max 150 chars', desc: 'Legal entity name for contracts' },
                        { field: 'orgType', type: 'enum', required: true, validation: 'From ORG_TYPES list', desc: 'Type of healthcare organization' },
                        { field: 'industry', type: 'enum', required: true, validation: 'From INDUSTRIES list', desc: 'Industry classification' },
                        { field: 'orgCode', type: 'string', required: true, validation: 'Alphanumeric, 3-20 chars, unique', desc: 'Unique organization identifier code' },
                        { field: 'npi', type: 'string', required: false, validation: '10 digits', desc: 'National Provider Identifier' },
                        { field: 'taxId', type: 'string', required: false, validation: 'XX-XXXXXXX format', desc: 'Federal Tax ID (EIN)' },
                        { field: 'ccn', type: 'string', required: false, validation: '6 chars', desc: 'CMS Certification Number' },
                        { field: 'accreditor', type: 'enum', required: false, validation: 'From ACCREDITOR_OPTIONS', desc: 'Accreditation body' },
                        { field: 'accreditorOther', type: 'string', required: false, validation: 'Max 100 chars', desc: 'Other accreditor name if not listed' },
                        { field: 'primaryContactName', type: 'string', required: true, validation: 'Max 100 chars', desc: 'Primary contact full name' },
                        { field: 'primaryContactEmail', type: 'string', required: true, validation: 'Valid email format', desc: 'Primary contact email address' },
                        { field: 'primaryContactPhone', type: 'string', required: false, validation: 'E.164 format', desc: 'Primary contact phone number' },
                        { field: 'implementationOwner', type: 'string', required: false, validation: 'Max 100 chars', desc: 'Implementation project owner' },
                        { field: 'secondaryComplianceContact', type: 'string', required: false, validation: 'Valid email', desc: 'Secondary compliance contact email' },
                        { field: 'addressLine1', type: 'string', required: true, validation: 'Max 200 chars', desc: 'Street address line 1' },
                        { field: 'addressLine2', type: 'string', required: false, validation: 'Max 200 chars', desc: 'Street address line 2' },
                        { field: 'city', type: 'string', required: true, validation: 'Max 100 chars', desc: 'City name' },
                        { field: 'stateProvince', type: 'enum', required: true, validation: 'From US_STATES list', desc: 'State or province' },
                        { field: 'country', type: 'string', required: true, validation: 'ISO 3166-1 alpha-2', desc: 'Country code' },
                        { field: 'zipPostal', type: 'string', required: true, validation: '5 or 9 digits (US)', desc: 'ZIP or postal code' },
                        { field: 'timeZone', type: 'enum', required: true, validation: 'IANA timezone', desc: 'Organization timezone' },
                        { field: 'singleFacilityMode', type: 'boolean', required: true, validation: 'true/false', desc: 'Single vs multi-facility mode' },
                        { field: 'numberOfFacilities', type: 'enum', required: true, validation: '1, 2-5, 6-25, 26+', desc: 'Facility count range' },
                        { field: 'numberOfDepartments', type: 'enum', required: true, validation: '1-5, 6-15, 16+', desc: 'Department count range' },
                        { field: 'estimatedUsers', type: 'enum', required: true, validation: '1-25, 26-100, 101-500, 500+', desc: 'Estimated user count' },
                        { field: 'hasParentOrg', type: 'boolean', required: true, validation: 'true/false', desc: 'Has parent organization' },
                        { field: 'parentOrgName', type: 'string', required: false, validation: 'Max 100 chars', desc: 'Parent organization name' },
                        { field: 'parentOrgCode', type: 'string', required: false, validation: 'Valid org code', desc: 'Parent organization code' },
                        { field: 'coreComplianceTags', type: 'array[string]', required: true, validation: 'From CORE_COMPLIANCE_TAGS', desc: 'Selected core compliance tags' },
                        { field: 'advancedComplianceTags', type: 'array[string]', required: false, validation: 'From ADVANCED_COMPLIANCE_TAGS', desc: 'Selected advanced compliance tags' },
                        { field: 'regulatoryBodies', type: 'array[string]', required: false, validation: 'From REGULATORY_BODIES', desc: 'Applicable regulatory bodies' },
                        { field: 'onboardingStatus', type: 'enum', required: true, validation: 'draft|in_progress|ready', desc: 'Onboarding workflow status' },
                        { field: 'status', type: 'enum', required: true, validation: 'draft|active|suspended|archived', desc: 'Organization lifecycle status' },
                        { field: 'createdAt', type: 'timestamp', required: false, validation: 'ISO 8601', desc: 'Record creation timestamp' },
                        { field: 'createdBy', type: 'string', required: false, validation: 'User ID', desc: 'Creating user identifier' },
                      ].map((row, idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? 'bg-background' : 'bg-muted/20'}>
                          <td className="p-2 font-mono text-xs">{row.field}</td>
                          <td className="p-2"><Badge variant="outline" className="text-xs">{row.type}</Badge></td>
                          <td className="p-2">{row.required ? <Badge variant="destructive" className="text-xs">Required</Badge> : <Badge variant="secondary" className="text-xs">Optional</Badge>}</td>
                          <td className="p-2 text-muted-foreground">{row.validation}</td>
                          <td className="p-2 text-muted-foreground">{row.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Facility Entity */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-green-500" />
                  6.2 Facility Entity
                </h4>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-2 font-medium">Field Name</th>
                        <th className="text-left p-2 font-medium">Data Type</th>
                        <th className="text-left p-2 font-medium">Required</th>
                        <th className="text-left p-2 font-medium">Validation</th>
                        <th className="text-left p-2 font-medium">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {[
                        { field: 'id', type: 'uuid', required: true, validation: 'Auto-generated', desc: 'Unique facility identifier' },
                        { field: 'name', type: 'string', required: true, validation: 'Max 100 chars', desc: 'Facility display name' },
                        { field: 'code', type: 'string', required: true, validation: 'Alphanumeric, 2-20 chars, unique', desc: 'Facility code identifier' },
                        { field: 'type', type: 'enum', required: true, validation: 'From FACILITY_TYPES', desc: 'Type of facility' },
                        { field: 'sameAsOrgAddress', type: 'boolean', required: true, validation: 'true/false', desc: 'Uses organization address' },
                        { field: 'address', type: 'string', required: false, validation: 'Max 200 chars', desc: 'Street address' },
                        { field: 'city', type: 'string', required: false, validation: 'Max 100 chars', desc: 'City name' },
                        { field: 'stateProvince', type: 'string', required: false, validation: 'Max 50 chars', desc: 'State or province' },
                        { field: 'country', type: 'string', required: false, validation: 'ISO 3166-1', desc: 'Country code' },
                        { field: 'zipPostal', type: 'string', required: false, validation: '5-10 chars', desc: 'ZIP/postal code' },
                        { field: 'timeZone', type: 'enum', required: true, validation: 'IANA timezone', desc: 'Facility timezone' },
                        { field: 'status', type: 'enum', required: true, validation: 'active|inactive', desc: 'Facility status' },
                        { field: 'parentFacilityId', type: 'uuid', required: false, validation: 'Valid facility ID', desc: 'Parent facility reference' },
                        { field: 'isParent', type: 'boolean', required: false, validation: 'true/false', desc: 'Is parent facility flag' },
                      ].map((row, idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? 'bg-background' : 'bg-muted/20'}>
                          <td className="p-2 font-mono text-xs">{row.field}</td>
                          <td className="p-2"><Badge variant="outline" className="text-xs">{row.type}</Badge></td>
                          <td className="p-2">{row.required ? <Badge variant="destructive" className="text-xs">Required</Badge> : <Badge variant="secondary" className="text-xs">Optional</Badge>}</td>
                          <td className="p-2 text-muted-foreground">{row.validation}</td>
                          <td className="p-2 text-muted-foreground">{row.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Department Entity */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-purple-500" />
                  6.3 Department Entity
                </h4>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-2 font-medium">Field Name</th>
                        <th className="text-left p-2 font-medium">Data Type</th>
                        <th className="text-left p-2 font-medium">Required</th>
                        <th className="text-left p-2 font-medium">Validation</th>
                        <th className="text-left p-2 font-medium">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {[
                        { field: 'id', type: 'uuid', required: true, validation: 'Auto-generated', desc: 'Unique department identifier' },
                        { field: 'name', type: 'string', required: true, validation: 'Max 100 chars', desc: 'Department display name' },
                        { field: 'code', type: 'string', required: true, validation: 'Alphanumeric, 2-20 chars', desc: 'Department code' },
                        { field: 'description', type: 'string', required: false, validation: 'Max 500 chars', desc: 'Department description' },
                        { field: 'status', type: 'enum', required: true, validation: 'active|inactive', desc: 'Department status' },
                        { field: 'facilityIds', type: 'array[uuid]', required: true, validation: 'Valid facility IDs', desc: 'Associated facility IDs' },
                      ].map((row, idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? 'bg-background' : 'bg-muted/20'}>
                          <td className="p-2 font-mono text-xs">{row.field}</td>
                          <td className="p-2"><Badge variant="outline" className="text-xs">{row.type}</Badge></td>
                          <td className="p-2">{row.required ? <Badge variant="destructive" className="text-xs">Required</Badge> : <Badge variant="secondary" className="text-xs">Optional</Badge>}</td>
                          <td className="p-2 text-muted-foreground">{row.validation}</td>
                          <td className="p-2 text-muted-foreground">{row.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* User Entity */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Users className="w-4 h-4 text-orange-500" />
                  6.4 User Entity
                </h4>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-2 font-medium">Field Name</th>
                        <th className="text-left p-2 font-medium">Data Type</th>
                        <th className="text-left p-2 font-medium">Required</th>
                        <th className="text-left p-2 font-medium">Validation</th>
                        <th className="text-left p-2 font-medium">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {[
                        { field: 'id', type: 'uuid', required: true, validation: 'Auto-generated', desc: 'Unique user identifier' },
                        { field: 'firstName', type: 'string', required: true, validation: 'Max 50 chars', desc: 'User first name' },
                        { field: 'lastName', type: 'string', required: true, validation: 'Max 50 chars', desc: 'User last name' },
                        { field: 'email', type: 'string', required: true, validation: 'Valid email, unique', desc: 'User email address' },
                        { field: 'departmentIds', type: 'array[uuid]', required: true, validation: 'Valid department IDs', desc: 'Assigned department IDs' },
                        { field: 'roleIds', type: 'array[uuid]', required: true, validation: 'Valid role IDs', desc: 'Assigned role IDs' },
                        { field: 'mfaEnabled', type: 'boolean', required: true, validation: 'true/false', desc: 'MFA enabled for user' },
                        { field: 'status', type: 'enum', required: true, validation: 'active|inactive|pending', desc: 'User account status' },
                        { field: 'jobTitle', type: 'string', required: false, validation: 'Max 100 chars', desc: 'User job title' },
                        { field: 'preferredLanguage', type: 'enum', required: false, validation: 'ISO 639-1 code', desc: 'Preferred language' },
                        { field: 'timeZone', type: 'enum', required: false, validation: 'IANA timezone', desc: 'User timezone override' },
                        { field: 'notes', type: 'string', required: false, validation: 'Max 1000 chars', desc: 'Admin notes about user' },
                        { field: 'tags', type: 'array[string]', required: false, validation: 'Max 10 tags', desc: 'User classification tags' },
                        { field: 'inviteSent', type: 'boolean', required: true, validation: 'true/false', desc: 'Invitation email sent' },
                      ].map((row, idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? 'bg-background' : 'bg-muted/20'}>
                          <td className="p-2 font-mono text-xs">{row.field}</td>
                          <td className="p-2"><Badge variant="outline" className="text-xs">{row.type}</Badge></td>
                          <td className="p-2">{row.required ? <Badge variant="destructive" className="text-xs">Required</Badge> : <Badge variant="secondary" className="text-xs">Optional</Badge>}</td>
                          <td className="p-2 text-muted-foreground">{row.validation}</td>
                          <td className="p-2 text-muted-foreground">{row.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Role Entity */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-red-500" />
                  6.5 Role Entity
                </h4>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-2 font-medium">Field Name</th>
                        <th className="text-left p-2 font-medium">Data Type</th>
                        <th className="text-left p-2 font-medium">Required</th>
                        <th className="text-left p-2 font-medium">Validation</th>
                        <th className="text-left p-2 font-medium">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {[
                        { field: 'id', type: 'uuid', required: true, validation: 'Auto-generated', desc: 'Unique role identifier' },
                        { field: 'name', type: 'string', required: true, validation: 'Max 100 chars, unique', desc: 'Role display name' },
                        { field: 'type', type: 'enum', required: true, validation: 'staff|department_head|compliance_head|org_admin', desc: 'Role type classification' },
                        { field: 'isSystemRole', type: 'boolean', required: true, validation: 'true/false', desc: 'System-defined role flag' },
                        { field: 'description', type: 'string', required: true, validation: 'Max 500 chars', desc: 'Role description' },
                        { field: 'departmentIds', type: 'array[uuid]', required: true, validation: 'Valid department IDs', desc: 'Applicable departments' },
                        { field: 'microappIds', type: 'array[uuid]', required: true, validation: 'Valid microapp IDs', desc: 'Accessible microapps' },
                        { field: 'entitlements', type: 'array[RoleEntitlement]', required: true, validation: 'See RoleEntitlement', desc: 'Permission entitlements' },
                      ].map((row, idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? 'bg-background' : 'bg-muted/20'}>
                          <td className="p-2 font-mono text-xs">{row.field}</td>
                          <td className="p-2"><Badge variant="outline" className="text-xs">{row.type}</Badge></td>
                          <td className="p-2">{row.required ? <Badge variant="destructive" className="text-xs">Required</Badge> : <Badge variant="secondary" className="text-xs">Optional</Badge>}</td>
                          <td className="p-2 text-muted-foreground">{row.validation}</td>
                          <td className="p-2 text-muted-foreground">{row.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-3 p-3 bg-muted/30 rounded-lg">
                  <p className="text-xs font-medium mb-2">RoleEntitlement Sub-Entity:</p>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div><span className="font-mono">objectArea</span>: Target module (Issues, CAPA, Audits, etc.)</div>
                    <div><span className="font-mono">scope</span>: Data scope (self | department | org)</div>
                    <div><span className="font-mono">capabilities</span>: Actions (View, Create, Edit, Submit, Approve, Close)</div>
                  </div>
                </div>
              </div>

              {/* Microapp Entity */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-cyan-500" />
                  6.6 Microapp Entity
                </h4>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-2 font-medium">Field Name</th>
                        <th className="text-left p-2 font-medium">Data Type</th>
                        <th className="text-left p-2 font-medium">Required</th>
                        <th className="text-left p-2 font-medium">Validation</th>
                        <th className="text-left p-2 font-medium">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {[
                        { field: 'id', type: 'uuid', required: true, validation: 'Auto-generated', desc: 'Unique microapp identifier' },
                        { field: 'name', type: 'string', required: true, validation: 'Max 100 chars', desc: 'Microapp display name' },
                        { field: 'code', type: 'string', required: true, validation: 'Uppercase, 2-20 chars', desc: 'Microapp code identifier' },
                        { field: 'description', type: 'string', required: true, validation: 'Max 500 chars', desc: 'Microapp description' },
                        { field: 'modules', type: 'array[string]', required: true, validation: 'Min 1 module', desc: 'Included module names' },
                        { field: 'owner', type: 'string', required: false, validation: 'Max 100 chars', desc: 'Business owner name' },
                        { field: 'status', type: 'enum', required: true, validation: 'enabled|disabled', desc: 'Microapp status' },
                        { field: 'auditLoggingEnabled', type: 'boolean', required: true, validation: 'true/false', desc: 'Audit logging enabled' },
                        { field: 'integrationRequired', type: 'boolean', required: true, validation: 'true/false', desc: 'External integration needed' },
                        { field: 'integrationDetails', type: 'string', required: false, validation: 'Max 1000 chars', desc: 'Integration specifications' },
                        { field: 'riskLevel', type: 'enum', required: true, validation: 'low|medium|high', desc: 'Compliance risk level' },
                        { field: 'departmentIds', type: 'array[uuid]', required: true, validation: 'Valid department IDs', desc: 'Assigned departments' },
                        { field: 'facilityIds', type: 'array[uuid]', required: true, validation: 'Valid facility IDs', desc: 'Assigned facilities' },
                      ].map((row, idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? 'bg-background' : 'bg-muted/20'}>
                          <td className="p-2 font-mono text-xs">{row.field}</td>
                          <td className="p-2"><Badge variant="outline" className="text-xs">{row.type}</Badge></td>
                          <td className="p-2">{row.required ? <Badge variant="destructive" className="text-xs">Required</Badge> : <Badge variant="secondary" className="text-xs">Optional</Badge>}</td>
                          <td className="p-2 text-muted-foreground">{row.validation}</td>
                          <td className="p-2 text-muted-foreground">{row.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Tenant Settings Entity */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Database className="w-4 h-4 text-indigo-500" />
                  6.7 Tenant Settings Entity
                </h4>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-2 font-medium">Field Name</th>
                        <th className="text-left p-2 font-medium">Data Type</th>
                        <th className="text-left p-2 font-medium">Required</th>
                        <th className="text-left p-2 font-medium">Validation</th>
                        <th className="text-left p-2 font-medium">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {[
                        { field: 'orgType', type: 'enum', required: true, validation: 'standalone|parent|child', desc: 'Tenant hierarchy type' },
                        { field: 'parentOrgId', type: 'uuid', required: false, validation: 'Valid org ID', desc: 'Parent organization reference' },
                        { field: 'dataResidencyRegion', type: 'enum', required: true, validation: 'US East|US West|EU|APAC', desc: 'Data residency region' },
                        { field: 'maxUsersAllowed', type: 'integer', required: true, validation: 'Min 1, Max 10000', desc: 'Maximum allowed users' },
                        { field: 'maxDepartmentsAllowed', type: 'integer', required: false, validation: 'Min 1, Max 500', desc: 'Maximum departments limit' },
                        { field: 'licenseTier', type: 'enum', required: true, validation: 'basic|premium|enterprise', desc: 'License tier' },
                        { field: 'licenseExpiry', type: 'date', required: false, validation: 'ISO 8601 date', desc: 'License expiration date' },
                        { field: 'microappsEnabled', type: 'array[string]', required: true, validation: 'Valid microapp codes', desc: 'Enabled microapp codes' },
                        { field: 'storageQuotaGB', type: 'integer', required: false, validation: 'Min 1', desc: 'Storage quota in GB' },
                        { field: 'adminDelegationAllowed', type: 'boolean', required: true, validation: 'true/false', desc: 'Allow admin delegation' },
                        { field: 'roleOverrideByParent', type: 'boolean', required: true, validation: 'true/false', desc: 'Parent can override roles' },
                        { field: 'featureFlags', type: 'object', required: false, validation: 'Key-value boolean', desc: 'Feature toggle flags' },
                      ].map((row, idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? 'bg-background' : 'bg-muted/20'}>
                          <td className="p-2 font-mono text-xs">{row.field}</td>
                          <td className="p-2"><Badge variant="outline" className="text-xs">{row.type}</Badge></td>
                          <td className="p-2">{row.required ? <Badge variant="destructive" className="text-xs">Required</Badge> : <Badge variant="secondary" className="text-xs">Optional</Badge>}</td>
                          <td className="p-2 text-muted-foreground">{row.validation}</td>
                          <td className="p-2 text-muted-foreground">{row.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Security Settings Entity */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-yellow-500" />
                  6.8 Security Settings Entity
                </h4>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-2 font-medium">Field Name</th>
                        <th className="text-left p-2 font-medium">Data Type</th>
                        <th className="text-left p-2 font-medium">Required</th>
                        <th className="text-left p-2 font-medium">Validation</th>
                        <th className="text-left p-2 font-medium">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {[
                        { field: 'auditLoggingEnabled', type: 'boolean', required: true, validation: 'true/false', desc: 'Enable audit logging' },
                        { field: 'logRetentionDays', type: 'integer', required: true, validation: 'Min 30, Max 2555', desc: 'Log retention period (days)' },
                        { field: 'mfaEnforcement', type: 'enum', required: true, validation: 'optional|required|admin_only', desc: 'MFA enforcement policy' },
                        { field: 'sessionTimeoutMinutes', type: 'integer', required: true, validation: 'Min 5, Max 480', desc: 'Session timeout (minutes)' },
                        { field: 'ipRestrictions', type: 'array[string]', required: false, validation: 'Valid CIDR notation', desc: 'Allowed IP ranges' },
                        { field: 'dataAccessScope', type: 'enum', required: true, validation: 'strict|standard|permissive', desc: 'Default data access scope' },
                        { field: 'notificationsEnabled', type: 'boolean', required: true, validation: 'true/false', desc: 'Enable security notifications' },
                      ].map((row, idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? 'bg-background' : 'bg-muted/20'}>
                          <td className="p-2 font-mono text-xs">{row.field}</td>
                          <td className="p-2"><Badge variant="outline" className="text-xs">{row.type}</Badge></td>
                          <td className="p-2">{row.required ? <Badge variant="destructive" className="text-xs">Required</Badge> : <Badge variant="secondary" className="text-xs">Optional</Badge>}</td>
                          <td className="p-2 text-muted-foreground">{row.validation}</td>
                          <td className="p-2 text-muted-foreground">{row.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* LOV Category Entity */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-pink-500" />
                  6.9 LOV Category Entity
                </h4>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-2 font-medium">Field Name</th>
                        <th className="text-left p-2 font-medium">Data Type</th>
                        <th className="text-left p-2 font-medium">Required</th>
                        <th className="text-left p-2 font-medium">Validation</th>
                        <th className="text-left p-2 font-medium">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {[
                        { field: 'id', type: 'uuid', required: true, validation: 'Auto-generated', desc: 'Unique category identifier' },
                        { field: 'name', type: 'string', required: true, validation: 'Max 100 chars, unique', desc: 'Category display name' },
                        { field: 'description', type: 'string', required: true, validation: 'Max 500 chars', desc: 'Category description' },
                        { field: 'values', type: 'array[LOVValue]', required: true, validation: 'See LOVValue', desc: 'Category values list' },
                        { field: 'isLocked', type: 'boolean', required: true, validation: 'true/false', desc: 'System-locked category' },
                      ].map((row, idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? 'bg-background' : 'bg-muted/20'}>
                          <td className="p-2 font-mono text-xs">{row.field}</td>
                          <td className="p-2"><Badge variant="outline" className="text-xs">{row.type}</Badge></td>
                          <td className="p-2">{row.required ? <Badge variant="destructive" className="text-xs">Required</Badge> : <Badge variant="secondary" className="text-xs">Optional</Badge>}</td>
                          <td className="p-2 text-muted-foreground">{row.validation}</td>
                          <td className="p-2 text-muted-foreground">{row.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-3 p-3 bg-muted/30 rounded-lg">
                  <p className="text-xs font-medium mb-2">LOVValue Sub-Entity:</p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div><span className="font-mono">id</span>: Unique value identifier (uuid)</div>
                    <div><span className="font-mono">value</span>: Internal value (snake_case)</div>
                    <div><span className="font-mono">label</span>: Display label (string)</div>
                    <div><span className="font-mono">sortOrder</span>: Display order (integer)</div>
                    <div><span className="font-mono">isActive</span>: Value is active (boolean)</div>
                    <div><span className="font-mono">isDefault</span>: Default selection (boolean)</div>
                  </div>
                </div>
              </div>

              {/* Branding Settings Entity */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Target className="w-4 h-4 text-teal-500" />
                  6.10 Branding Settings Entity
                </h4>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-2 font-medium">Field Name</th>
                        <th className="text-left p-2 font-medium">Data Type</th>
                        <th className="text-left p-2 font-medium">Required</th>
                        <th className="text-left p-2 font-medium">Validation</th>
                        <th className="text-left p-2 font-medium">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {[
                        { field: 'logoUrl', type: 'string', required: false, validation: 'Valid URL, max 2048 chars', desc: 'Organization logo URL' },
                        { field: 'primaryColor', type: 'string', required: true, validation: 'Hex color (#XXXXXX)', desc: 'Primary brand color' },
                        { field: 'secondaryColor', type: 'string', required: false, validation: 'Hex color (#XXXXXX)', desc: 'Secondary brand color' },
                        { field: 'defaultLanguage', type: 'enum', required: true, validation: 'ISO 639-1 code', desc: 'Default UI language' },
                        { field: 'customLoginMessage', type: 'string', required: false, validation: 'Max 500 chars', desc: 'Custom login page message' },
                        { field: 'customDomain', type: 'string', required: false, validation: 'Valid domain name', desc: 'Custom domain URL' },
                        { field: 'applyToChildren', type: 'boolean', required: false, validation: 'true/false', desc: 'Apply to child orgs' },
                        { field: 'allowChildOverride', type: 'boolean', required: false, validation: 'true/false', desc: 'Allow child branding override' },
                      ].map((row, idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? 'bg-background' : 'bg-muted/20'}>
                          <td className="p-2 font-mono text-xs">{row.field}</td>
                          <td className="p-2"><Badge variant="outline" className="text-xs">{row.type}</Badge></td>
                          <td className="p-2">{row.required ? <Badge variant="destructive" className="text-xs">Required</Badge> : <Badge variant="secondary" className="text-xs">Optional</Badge>}</td>
                          <td className="p-2 text-muted-foreground">{row.validation}</td>
                          <td className="p-2 text-muted-foreground">{row.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* App Access Entitlements Entity */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-emerald-500" />
                  6.11 App Access Entitlements Entity
                </h4>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-2 font-medium">Field Name</th>
                        <th className="text-left p-2 font-medium">Data Type</th>
                        <th className="text-left p-2 font-medium">Required</th>
                        <th className="text-left p-2 font-medium">Validation</th>
                        <th className="text-left p-2 font-medium">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {[
                        { field: 'selectedPreset', type: 'enum', required: false, validation: 'recommended|strict|operational|null', desc: 'Applied preset template' },
                        { field: 'roleEntitlements', type: 'object', required: true, validation: 'Record<roleId, RoleAppEntitlements>', desc: 'Role-based app access config' },
                        { field: 'isCustomized', type: 'boolean', required: true, validation: 'true/false', desc: 'Has custom modifications' },
                      ].map((row, idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? 'bg-background' : 'bg-muted/20'}>
                          <td className="p-2 font-mono text-xs">{row.field}</td>
                          <td className="p-2"><Badge variant="outline" className="text-xs">{row.type}</Badge></td>
                          <td className="p-2">{row.required ? <Badge variant="destructive" className="text-xs">Required</Badge> : <Badge variant="secondary" className="text-xs">Optional</Badge>}</td>
                          <td className="p-2 text-muted-foreground">{row.validation}</td>
                          <td className="p-2 text-muted-foreground">{row.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-3 p-3 bg-muted/30 rounded-lg">
                  <p className="text-xs font-medium mb-2">RoleAppEntitlements Sub-Entity:</p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div><span className="font-mono">apps</span>: Record&lt;appId, AppAccessConfig&gt;</div>
                    <div><span className="font-mono">dashboardFlags</span>: canExportCsv, canViewCrossAppKpis</div>
                    <div><span className="font-mono">exportsAllowed</span>: boolean</div>
                    <div><span className="font-mono">exportScope</span>: self | department | org</div>
                  </div>
                  <p className="text-xs font-medium mt-3 mb-2">AppAccessConfig Sub-Entity:</p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div><span className="font-mono">accessLevel</span>: none | view | manage</div>
                    <div><span className="font-mono">scope</span>: self | department | org</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Glossary */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-primary" />
                7. Glossary of Terms
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3">
                {[
                  { term: 'HIPAA', definition: 'Health Insurance Portability and Accountability Act - Federal law protecting patient health information privacy and security.' },
                  { term: 'PHI', definition: 'Protected Health Information - Any health information that can identify an individual patient.' },
                  { term: 'RBAC', definition: 'Role-Based Access Control - Security model restricting system access based on user roles.' },
                  { term: 'MFA', definition: 'Multi-Factor Authentication - Security mechanism requiring multiple verification methods.' },
                  { term: 'QAPI', definition: 'Quality Assurance and Performance Improvement - CMS-mandated quality program for healthcare facilities.' },
                  { term: 'CMS', definition: 'Centers for Medicare & Medicaid Services - Federal agency administering Medicare and Medicaid.' },
                  { term: 'SNF', definition: 'Skilled Nursing Facility - Healthcare facility providing 24-hour nursing care.' },
                  { term: 'ALF', definition: 'Assisted Living Facility - Residential facility providing personal care services.' },
                  { term: 'CAPA', definition: 'Corrective and Preventive Action - Process for addressing and preventing compliance issues.' },
                  { term: 'LOV', definition: 'List of Values - Configurable dropdown options for standardizing data entry.' },
                  { term: 'SLA', definition: 'Service Level Agreement - Contract defining expected service performance metrics.' },
                  { term: 'Microapp', definition: 'Modular application component providing specific functionality within the platform.' },
                  { term: 'Tenant', definition: 'Isolated instance of the application for a specific organization.' },
                  { term: 'Audit Trail', definition: 'Chronological record of system activities for compliance and security review.' },
                  { term: 'Entitlement', definition: 'Permission or access right granted to a user or role.' },
                ].map((item, idx) => (
                  <div key={idx} className="border-b last:border-b-0 pb-2 last:pb-0">
                    <div className="flex items-start gap-2">
                      <Badge variant="outline" className="text-xs font-mono shrink-0">{item.term}</Badge>
                      <p className="text-sm text-muted-foreground">{item.definition}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Appendix */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Info className="w-5 h-5 text-primary" />
                8. Appendix
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-sm mb-2">7.1 Document Version</h4>
                <p className="text-sm text-muted-foreground">
                  Version 1.0 - Auto-generated based on onboarding configuration
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-2">7.2 Configuration Summary</h4>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="bg-muted/50 p-3 rounded-lg">
                    <p className="text-2xl font-bold text-primary">{data.facilities.length}</p>
                    <p className="text-xs text-muted-foreground">Facilities</p>
                  </div>
                  <div className="bg-muted/50 p-3 rounded-lg">
                    <p className="text-2xl font-bold text-primary">{data.departments.length}</p>
                    <p className="text-xs text-muted-foreground">Departments</p>
                  </div>
                  <div className="bg-muted/50 p-3 rounded-lg">
                    <p className="text-2xl font-bold text-primary">{data.users.length}</p>
                    <p className="text-xs text-muted-foreground">Users</p>
                  </div>
                  <div className="bg-muted/50 p-3 rounded-lg">
                    <p className="text-2xl font-bold text-primary">{data.roles.length}</p>
                    <p className="text-xs text-muted-foreground">Roles</p>
                  </div>
                  <div className="bg-muted/50 p-3 rounded-lg">
                    <p className="text-2xl font-bold text-primary">{data.microapps.filter(m => m.status === 'enabled').length}</p>
                    <p className="text-xs text-muted-foreground">Active Apps</p>
                  </div>
                  <div className="bg-muted/50 p-3 rounded-lg">
                    <p className="text-2xl font-bold text-primary">{data.lovCategories.length}</p>
                    <p className="text-xs text-muted-foreground">Value Sets</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </ScrollArea>
    </div>
  );
};
