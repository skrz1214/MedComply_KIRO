import React, { useState, useRef } from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, AlertCircle, Upload, Download, FileSpreadsheet, CheckCircle2, XCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface CSVRow {
  firstName: string;
  lastName: string;
  email: string;
  isValid: boolean;
  errors: string[];
  lineNumber: number;
}

export const UsersStep: React.FC = () => {
  const { data, addUser, removeUser, updateUser, markStepComplete, nextStep } = useOnboarding();
  const { toast } = useToast();
  const [newUser, setNewUser] = useState({ firstName: '', lastName: '', email: '' });
  const [errors, setErrors] = useState<{ firstName?: string; email?: string }>({});
  const [csvPreview, setCsvPreview] = useState<CSVRow[]>([]);
  const [showCsvDialog, setShowCsvDialog] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const downloadTemplate = () => {
    const csvContent = 'First Name,Last Name,Email\nJohn,Doe,john.doe@example.com\nJane,Smith,jane.smith@example.com';
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'users_template.csv';
    link.click();
    URL.revokeObjectURL(link.href);
    toast({
      title: 'Template downloaded',
      description: 'Fill in the template and upload it to bulk add users.',
    });
  };

  const parseCSV = (text: string): CSVRow[] => {
    const lines = text.trim().split('\n');
    if (lines.length < 2) return [];

    const existingEmails = new Set(data.users.map(u => u.email.toLowerCase()));
    const seenEmails = new Set<string>();
    const rows: CSVRow[] = [];

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      // Handle both comma and tab separation, with optional quotes
      const parts = line.match(/(".*?"|[^",\t]+)(?=\s*[,\t]|\s*$)/g) || [];
      const cleanParts = parts.map(p => p.replace(/^"|"$/g, '').trim());

      const firstName = cleanParts[0] || '';
      const lastName = cleanParts[1] || '';
      const email = (cleanParts[2] || '').toLowerCase();

      const rowErrors: string[] = [];

      if (!firstName) {
        rowErrors.push('First name is required');
      }

      if (!email) {
        rowErrors.push('Email is required');
      } else if (!validateEmail(email)) {
        rowErrors.push('Invalid email format');
      } else if (existingEmails.has(email)) {
        rowErrors.push('Email already exists in user list');
      } else if (seenEmails.has(email)) {
        rowErrors.push('Duplicate email in CSV');
      }

      if (email) seenEmails.add(email);

      rows.push({
        firstName,
        lastName,
        email,
        isValid: rowErrors.length === 0,
        errors: rowErrors,
        lineNumber: i + 1,
      });
    }

    return rows;
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.csv')) {
      toast({
        title: 'Invalid file type',
        description: 'Please upload a CSV file.',
        variant: 'destructive',
      });
      return;
    }

    setIsProcessing(true);
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const parsedRows = parseCSV(text);
      
      if (parsedRows.length === 0) {
        toast({
          title: 'No data found',
          description: 'The CSV file appears to be empty or incorrectly formatted.',
          variant: 'destructive',
        });
        setIsProcessing(false);
        return;
      }

      setCsvPreview(parsedRows);
      setShowCsvDialog(true);
      setIsProcessing(false);
    };
    reader.onerror = () => {
      toast({
        title: 'Error reading file',
        description: 'Could not read the CSV file. Please try again.',
        variant: 'destructive',
      });
      setIsProcessing(false);
    };
    reader.readAsText(file);
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const importValidUsers = () => {
    const validRows = csvPreview.filter(row => row.isValid);
    
    validRows.forEach(row => {
      addUser({
        firstName: row.firstName,
        lastName: row.lastName,
        email: row.email,
        departmentIds: [],
        roleIds: [],
        mfaEnabled: true,
        status: 'pending',
        inviteSent: false,
      });
    });

    setShowCsvDialog(false);
    setCsvPreview([]);
    
    toast({
      title: 'Users imported',
      description: `Successfully added ${validRows.length} user${validRows.length !== 1 ? 's' : ''}.`,
    });
  };

  const handleAddUser = () => {
    const newErrors: { firstName?: string; email?: string } = {};
    
    if (!newUser.firstName.trim()) {
      newErrors.firstName = 'First name is required';
    }
    
    if (!newUser.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!validateEmail(newUser.email.trim())) {
      newErrors.email = 'Please enter a valid email address';
    } else if (data.users.some(u => u.email.toLowerCase() === newUser.email.trim().toLowerCase())) {
      newErrors.email = 'This email is already added';
    }

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) {
      toast({
        title: 'Please fix the errors',
        description: Object.values(newErrors).join('. '),
        variant: 'destructive',
      });
      return;
    }

    addUser({ 
      firstName: newUser.firstName.trim(), 
      lastName: newUser.lastName.trim(), 
      email: newUser.email.trim().toLowerCase(),
      departmentIds: [], 
      roleIds: [], 
      mfaEnabled: true, 
      status: 'pending', 
      inviteSent: false 
    });
    
    setNewUser({ firstName: '', lastName: '', email: '' });
    setErrors({});
    
    toast({
      title: 'User added',
      description: `${newUser.firstName.trim()} has been added to the list.`,
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddUser();
    }
  };

  const hasOrgAdmin = data.users.some(u => u.roleIds.some(r => data.roles.find(role => role.id === r)?.type === 'org_admin'));
  const hasComplianceHead = data.users.some(u => u.roleIds.some(r => data.roles.find(role => role.id === r)?.type === 'compliance_head'));

  const validCount = csvPreview.filter(r => r.isValid).length;
  const invalidCount = csvPreview.filter(r => !r.isValid).length;

  return (
    <div className="space-y-6">
      <div className="form-section">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="form-section-title">Add Users</h3>
            <p className="text-sm text-muted-foreground">
              Add team members individually or bulk upload via CSV.
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={downloadTemplate}>
              <Download className="w-4 h-4 mr-2" />
              Download Template
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => fileInputRef.current?.click()}
              disabled={isProcessing}
            >
              <Upload className="w-4 h-4 mr-2" />
              {isProcessing ? 'Processing...' : 'Upload CSV'}
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-4">
          <div className="space-y-1">
            <Input 
              placeholder="First Name *" 
              value={newUser.firstName} 
              onChange={e => {
                setNewUser(p => ({ ...p, firstName: e.target.value }));
                if (errors.firstName) setErrors(p => ({ ...p, firstName: undefined }));
              }}
              onKeyPress={handleKeyPress}
              className={errors.firstName ? 'border-destructive' : ''}
            />
            {errors.firstName && (
              <p className="text-xs text-destructive flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {errors.firstName}
              </p>
            )}
          </div>
          <div>
            <Input 
              placeholder="Last Name" 
              value={newUser.lastName} 
              onChange={e => setNewUser(p => ({ ...p, lastName: e.target.value }))}
              onKeyPress={handleKeyPress}
            />
          </div>
          <div className="space-y-1">
            <Input 
              placeholder="Email *" 
              type="email" 
              value={newUser.email} 
              onChange={e => {
                setNewUser(p => ({ ...p, email: e.target.value }));
                if (errors.email) setErrors(p => ({ ...p, email: undefined }));
              }}
              onKeyPress={handleKeyPress}
              className={errors.email ? 'border-destructive' : ''}
            />
            {errors.email && (
              <p className="text-xs text-destructive flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {errors.email}
              </p>
            )}
          </div>
          <Button onClick={handleAddUser}>
            <Plus className="w-4 h-4 mr-2" />
            Add User
          </Button>
        </div>

        {data.users.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground border border-dashed border-border rounded-lg">
            <FileSpreadsheet className="w-10 h-10 mx-auto mb-3 opacity-50" />
            <p>No users added yet.</p>
            <p className="text-xs mt-1">Add users individually above or upload a CSV file.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {data.users.map(user => (
              <div key={user.id} className="flex items-center justify-between p-4 rounded-lg border border-border">
                <div className="flex-1">
                  <p className="font-medium">{user.firstName} {user.lastName}</p>
                  <p className="text-sm text-muted-foreground">{user.email}</p>
                </div>
                <div className="flex items-center gap-3">
                  <Select value={user.roleIds[0] || ''} onValueChange={v => updateUser(user.id, { roleIds: [v] })}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      {data.roles.map(r => (
                        <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button variant="ghost" size="icon" onClick={() => removeUser(user.id)}>
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {(!hasOrgAdmin || !hasComplianceHead) && data.users.length > 0 && (
          <div className="mt-4 p-3 rounded-lg bg-warning/10 border border-warning/20 text-sm flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-warning mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-medium">Required roles not assigned: </span>
              {!hasOrgAdmin && <Badge variant="outline" className="mr-1">Org Admin</Badge>}
              {!hasComplianceHead && <Badge variant="outline">Compliance Head</Badge>}
            </div>
          </div>
        )}
      </div>
      
      <div className="flex justify-end">
        <Button onClick={() => { markStepComplete(8); nextStep(); }}>
          Continue
        </Button>
      </div>

      {/* CSV Preview Dialog */}
      <Dialog open={showCsvDialog} onOpenChange={setShowCsvDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5" />
              CSV Import Preview
            </DialogTitle>
            <DialogDescription>
              Review the users before importing. Only valid entries will be added.
            </DialogDescription>
          </DialogHeader>

          <div className="flex gap-4 py-2">
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle2 className="w-4 h-4 text-green-500" />
              <span className="text-muted-foreground">Valid:</span>
              <Badge variant="secondary" className="bg-green-500/10 text-green-600">{validCount}</Badge>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <XCircle className="w-4 h-4 text-destructive" />
              <span className="text-muted-foreground">Invalid:</span>
              <Badge variant="secondary" className="bg-destructive/10 text-destructive">{invalidCount}</Badge>
            </div>
          </div>

          <div className="flex-1 overflow-auto border border-border rounded-lg">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 sticky top-0">
                <tr>
                  <th className="text-left p-3 font-medium">Row</th>
                  <th className="text-left p-3 font-medium">First Name</th>
                  <th className="text-left p-3 font-medium">Last Name</th>
                  <th className="text-left p-3 font-medium">Email</th>
                  <th className="text-left p-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {csvPreview.map((row, idx) => (
                  <tr 
                    key={idx} 
                    className={`border-t border-border ${!row.isValid ? 'bg-destructive/5' : ''}`}
                  >
                    <td className="p-3 text-muted-foreground">{row.lineNumber}</td>
                    <td className="p-3">{row.firstName || <span className="text-muted-foreground italic">empty</span>}</td>
                    <td className="p-3">{row.lastName || <span className="text-muted-foreground italic">—</span>}</td>
                    <td className="p-3">{row.email || <span className="text-muted-foreground italic">empty</span>}</td>
                    <td className="p-3">
                      {row.isValid ? (
                        <span className="flex items-center gap-1 text-green-600">
                          <CheckCircle2 className="w-4 h-4" />
                          Valid
                        </span>
                      ) : (
                        <span className="text-destructive text-xs">
                          {row.errors.join(', ')}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setShowCsvDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={importValidUsers} 
              disabled={validCount === 0}
            >
              Import {validCount} User{validCount !== 1 ? 's' : ''}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
