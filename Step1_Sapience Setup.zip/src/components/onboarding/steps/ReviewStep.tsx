import React, { useState } from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { 
  Check, AlertCircle, Download, Building, Shield, Users, Settings, Palette, 
  ChevronDown, Edit2, Globe, Layout, Key, FileText, Database, Layers,
  CheckCircle2, AlertTriangle, Rocket
} from 'lucide-react';

interface ReviewSectionProps {
  title: string;
  icon: React.ReactNode;
  stepId: number;
  isComplete: boolean;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

const ReviewSection: React.FC<ReviewSectionProps> = ({ 
  title, icon, stepId, isComplete, children, defaultOpen = false 
}) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  const { goToStep } = useOnboarding();

  return (
    <Card className={`border ${isComplete ? 'border-border' : 'border-amber-300 dark:border-amber-700'}`}>
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CardHeader className="py-3 px-4">
          <div className="flex items-center justify-between">
            <CollapsibleTrigger className="flex items-center gap-3 flex-1 hover:opacity-80">
              <div className={`p-1.5 rounded ${isComplete ? 'bg-primary/10' : 'bg-amber-100 dark:bg-amber-900/30'}`}>
                {icon}
              </div>
              <CardTitle className="text-base font-medium">{title}</CardTitle>
              {isComplete ? (
                <Badge variant="secondary" className="ml-2 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                  <CheckCircle2 className="w-3 h-3 mr-1" /> Complete
                </Badge>
              ) : (
                <Badge variant="secondary" className="ml-2 bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">
                  <AlertTriangle className="w-3 h-3 mr-1" /> Needs Review
                </Badge>
              )}
              <ChevronDown className={`h-4 w-4 ml-auto transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </CollapsibleTrigger>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="sm" className="ml-2" onClick={() => goToStep(stepId)}>
                    <Edit2 className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Edit this section</TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </CardHeader>
        <CollapsibleContent>
          <CardContent className="pt-0 pb-4 px-4">
            {children}
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
};

const SummaryItem: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
  <div className="flex justify-between py-1.5 border-b border-border/50 last:border-0">
    <span className="text-sm text-muted-foreground">{label}</span>
    <span className="text-sm font-medium text-right max-w-[60%]">{value || '-'}</span>
  </div>
);

const StatCard: React.FC<{ count: number; label: string; icon?: React.ReactNode }> = ({ count, label, icon }) => (
  <div className="p-3 rounded-lg bg-muted text-center">
    {icon && <div className="mb-1 flex justify-center text-muted-foreground">{icon}</div>}
    <div className="text-2xl font-bold">{count}</div>
    <div className="text-xs text-muted-foreground">{label}</div>
  </div>
);

export const ReviewStep: React.FC = () => {
  const { data, canActivate, activateOrganization, goToStep, isStepComplete } = useOnboarding();
  const { canActivate: canAct, issues } = canActivate();

  const handleDownload = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${data.organization.name || 'organization'}-config.json`;
    a.click();
  };

  const enabledMicroapps = data.microapps.filter(m => m.status === 'enabled');
  const adminUsers = data.users.filter(u => 
    u.roleIds.some(r => data.roles.find(role => role.id === r)?.type === 'org_admin')
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between p-4 rounded-lg border bg-card">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <Rocket className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold">Review & Activate</h3>
            <p className="text-sm text-muted-foreground">Review all settings before activating your organization</p>
          </div>
        </div>
        <Badge variant={canAct ? 'default' : 'secondary'}>
          {canAct ? 'Ready to Activate' : 'Review Required'}
        </Badge>
      </div>

      {/* Issues Alert */}
      {!canAct && (
        <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/20">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="w-5 h-5 text-destructive" />
            <span className="font-medium text-destructive">Issues to Resolve Before Activation</span>
          </div>
          <ul className="list-disc list-inside text-sm text-destructive space-y-1">
            {issues.map((issue, i) => <li key={i}>{issue}</li>)}
          </ul>
        </div>
      )}

      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <StatCard count={data.facilities.length} label="Facilities" icon={<Building className="h-4 w-4" />} />
        <StatCard count={data.departments.length} label="Departments" icon={<Layers className="h-4 w-4" />} />
        <StatCard count={enabledMicroapps.length} label="Apps Enabled" icon={<Layout className="h-4 w-4" />} />
        <StatCard count={data.roles.length} label="Roles" icon={<Key className="h-4 w-4" />} />
        <StatCard count={data.users.length} label="Users" icon={<Users className="h-4 w-4" />} />
        <StatCard count={data.lovCategories.length} label="Value Sets" icon={<Database className="h-4 w-4" />} />
      </div>

      {/* Section Reviews */}
      <div className="space-y-3">
        {/* 1. Organization */}
        <ReviewSection 
          title="Organization & Compliance" 
          icon={<Building className="h-4 w-4 text-primary" />}
          stepId={1}
          isComplete={isStepComplete(1)}
          defaultOpen
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-2">Organization Details</h4>
              <SummaryItem label="Name" value={data.organization.name} />
              <SummaryItem label="Code" value={data.organization.orgCode} />
              <SummaryItem label="Type" value={data.organization.orgType} />
              <SummaryItem label="Industry" value={data.organization.industry} />
              <SummaryItem label="Contact" value={data.organization.primaryContactEmail} />
            </div>
            <div>
              <h4 className="text-sm font-medium mb-2">Compliance Scope</h4>
              <div className="flex flex-wrap gap-1 mb-2">
                {data.regulatoryBodies.map(b => (
                  <Badge key={b} variant="secondary" className="text-xs">{b.toUpperCase()}</Badge>
                ))}
              </div>
              <div className="flex flex-wrap gap-1">
                {data.complianceFrameworks.map(f => (
                  <Badge key={f} variant="outline" className="text-xs">{f.toUpperCase()}</Badge>
                ))}
              </div>
              {data.organization.coreComplianceTags && data.organization.coreComplianceTags.length > 0 && (
                <p className="text-xs text-muted-foreground mt-2">
                  {data.organization.coreComplianceTags.length} compliance tags applied
                </p>
              )}
            </div>
          </div>
        </ReviewSection>

        {/* 2. Recommended Setup */}
        <ReviewSection 
          title="Setup Pack Applied" 
          icon={<Settings className="h-4 w-4 text-primary" />}
          stepId={2}
          isComplete={isStepComplete(2)}
        >
          <SummaryItem label="Setup Pack" value="Based on organization type and compliance needs" />
          <SummaryItem label="Suggested Tags Applied" value={data.organization.suggestedTagsApplied ? 'Yes' : 'No'} />
        </ReviewSection>

        {/* 3. Tenant & Licensing */}
        <ReviewSection 
          title="Tenant & Licensing" 
          icon={<Key className="h-4 w-4 text-primary" />}
          stepId={3}
          isComplete={isStepComplete(3)}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <SummaryItem label="Organization Type" value={data.tenantSettings.orgType} />
              <SummaryItem label="License Tier" value={data.tenantSettings.licenseTier} />
              <SummaryItem label="Max Users" value={data.tenantSettings.maxUsersAllowed} />
            </div>
            <div>
              <SummaryItem label="Data Residency" value={data.tenantSettings.dataResidencyRegion} />
              <SummaryItem label="Admin Delegation" value={data.tenantSettings.adminDelegationAllowed ? 'Allowed' : 'Not Allowed'} />
            </div>
          </div>
        </ReviewSection>

        {/* 4. Facilities & Departments */}
        <ReviewSection 
          title="Facilities & Departments" 
          icon={<Building className="h-4 w-4 text-primary" />}
          stepId={4}
          isComplete={isStepComplete(4)}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-2">Facilities ({data.facilities.length})</h4>
              {data.facilities.slice(0, 5).map(f => (
                <div key={f.id} className="text-sm py-1 flex justify-between">
                  <span>{f.name}</span>
                  <Badge variant="outline" className="text-xs">{f.code}</Badge>
                </div>
              ))}
              {data.facilities.length > 5 && (
                <p className="text-xs text-muted-foreground mt-1">+{data.facilities.length - 5} more</p>
              )}
            </div>
            <div>
              <h4 className="text-sm font-medium mb-2">Departments ({data.departments.length})</h4>
              {data.departments.slice(0, 5).map(d => (
                <div key={d.id} className="text-sm py-1 flex justify-between">
                  <span>{d.name}</span>
                  <Badge variant="outline" className="text-xs">{d.code}</Badge>
                </div>
              ))}
              {data.departments.length > 5 && (
                <p className="text-xs text-muted-foreground mt-1">+{data.departments.length - 5} more</p>
              )}
            </div>
          </div>
        </ReviewSection>

        {/* 5. Apps & Dashboards */}
        <ReviewSection 
          title="Apps & Dashboards" 
          icon={<Layout className="h-4 w-4 text-primary" />}
          stepId={5}
          isComplete={isStepComplete(5)}
        >
          <div>
            <h4 className="text-sm font-medium mb-2">Enabled Microapps ({enabledMicroapps.length})</h4>
            <div className="flex flex-wrap gap-1">
              {enabledMicroapps.map(app => (
                <Badge key={app.id} variant="secondary" className="text-xs">{app.name}</Badge>
              ))}
            </div>
          </div>
        </ReviewSection>

        {/* 6. Roles */}
        <ReviewSection 
          title="Roles & Permissions" 
          icon={<Key className="h-4 w-4 text-primary" />}
          stepId={6}
          isComplete={isStepComplete(6)}
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {data.roles.map(role => (
              <div key={role.id} className="p-2 rounded bg-muted text-center">
                <p className="text-sm font-medium truncate">{role.name}</p>
                <p className="text-xs text-muted-foreground">{role.type.replace('_', ' ')}</p>
              </div>
            ))}
          </div>
          <SummaryItem label="Custom Roles" value={data.customRolesEnabled ? 'Enabled' : 'Disabled'} />
        </ReviewSection>

        {/* 7. App Access */}
        <ReviewSection 
          title="App & Dashboard Access" 
          icon={<Shield className="h-4 w-4 text-primary" />}
          stepId={7}
          isComplete={isStepComplete(7)}
        >
          <SummaryItem label="Access Preset" value={data.appAccessEntitlements.selectedPreset || 'Custom'} />
          <SummaryItem label="Customized" value={data.appAccessEntitlements.isCustomized ? 'Yes' : 'No'} />
        </ReviewSection>

        {/* 8. Users */}
        <ReviewSection 
          title="Users & Invitations" 
          icon={<Users className="h-4 w-4 text-primary" />}
          stepId={8}
          isComplete={isStepComplete(8)}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <SummaryItem label="Total Users" value={data.users.length} />
              <SummaryItem label="Org Admins" value={adminUsers.length} />
              <SummaryItem label="Pending Invites" value={data.users.filter(u => !u.inviteSent).length} />
            </div>
            <div>
              <h4 className="text-sm font-medium mb-2">Admin Users</h4>
              {adminUsers.slice(0, 3).map(u => (
                <p key={u.id} className="text-sm py-0.5">{u.firstName} {u.lastName} ({u.email})</p>
              ))}
              {adminUsers.length > 3 && (
                <p className="text-xs text-muted-foreground">+{adminUsers.length - 3} more</p>
              )}
            </div>
          </div>
        </ReviewSection>

        {/* 9. LOV / Value Sets */}
        <ReviewSection 
          title="Value Sets (LOV)" 
          icon={<Database className="h-4 w-4 text-primary" />}
          stepId={9}
          isComplete={isStepComplete(9)}
        >
          <SummaryItem label="Categories Configured" value={data.lovCategories.length} />
          <div className="flex flex-wrap gap-1 mt-2">
            {data.lovCategories.slice(0, 6).map(cat => (
              <Badge key={cat.id} variant="outline" className="text-xs">{cat.name}</Badge>
            ))}
            {data.lovCategories.length > 6 && (
              <Badge variant="secondary" className="text-xs">+{data.lovCategories.length - 6} more</Badge>
            )}
          </div>
        </ReviewSection>

        {/* 10. Security */}
        <ReviewSection 
          title="Security & Audit Logging" 
          icon={<Shield className="h-4 w-4 text-primary" />}
          stepId={10}
          isComplete={isStepComplete(10)}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <SummaryItem label="MFA Enforcement" value={data.securitySettings.mfaEnforcement} />
              <SummaryItem label="Session Timeout" value={`${data.securitySettings.sessionTimeoutMinutes} min`} />
              <SummaryItem label="Data Access Scope" value={data.securitySettings.dataAccessScope} />
            </div>
            <div>
              <SummaryItem label="Audit Logging" value={data.securitySettings.auditLoggingEnabled ? 'Enabled' : 'Disabled'} />
              <SummaryItem label="Log Retention" value={`${data.securitySettings.logRetentionDays} days`} />
              <SummaryItem label="Notifications" value={data.securitySettings.notificationsEnabled ? 'Enabled' : 'Disabled'} />
            </div>
          </div>
        </ReviewSection>

        {/* 11. Branding */}
        <ReviewSection 
          title="Branding & Localization" 
          icon={<Palette className="h-4 w-4 text-primary" />}
          stepId={11}
          isComplete={isStepComplete(11)}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <SummaryItem label="Primary Color" value={
                <div className="flex items-center gap-2">
                  <div 
                    className="w-4 h-4 rounded border border-border" 
                    style={{ backgroundColor: data.brandingSettings.primaryColor }}
                  />
                  {data.brandingSettings.primaryColor}
                </div>
              } />
              <SummaryItem label="Default Language" value={data.brandingSettings.defaultLanguage?.toUpperCase()} />
            </div>
            <div>
              <SummaryItem label="Custom Domain" value={data.brandingSettings.customDomain || 'Not configured'} />
              <SummaryItem label="Logo" value={data.brandingSettings.logoUrl ? 'Uploaded' : 'Not uploaded'} />
            </div>
          </div>
        </ReviewSection>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center justify-between pt-4 border-t">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline" onClick={handleDownload}>
                <Download className="w-4 h-4 mr-2" />Download Config
              </Button>
            </TooltipTrigger>
            <TooltipContent>Download your configuration as a JSON file for backup or review</TooltipContent>
          </Tooltip>
        </TooltipProvider>
        
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <span>
                <Button onClick={activateOrganization} disabled={!canAct} size="lg">
                  <Rocket className="w-4 h-4 mr-2" />Activate Organization
                </Button>
              </span>
            </TooltipTrigger>
            <TooltipContent className="max-w-xs">
              {canAct 
                ? 'Finalize setup and activate your organization. This will enable all configured features and send pending invitations.'
                : 'Resolve all issues above before activating your organization.'}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
    </div>
  );
};
