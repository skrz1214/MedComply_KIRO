import React, { useState, useMemo, useEffect } from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import {
  ChevronDown,
  ChevronRight,
  Sparkles,
  Check,
  AlertCircle,
  Info,
  LayoutDashboard,
  List,
  FileWarning,
  Scale,
  ClipboardCheck,
  Shield,
  AlertTriangle,
  FileText,
  CheckCircle2,
  Building2,
  Eye,
  Settings,
  Zap,
  HelpCircle,
} from 'lucide-react';
import {
  generateChangePlan,
  ChangePlan,
  PackSection,
  getOversightBodyName,
  getComplianceTagName,
} from '@/data/recommendedSetupPacks';
import { useToast } from '@/hooks/use-toast';

// Tooltip helper component
const GuidanceTooltip: React.FC<{ content: string; children?: React.ReactNode }> = ({ content, children }) => (
  <TooltipProvider delayDuration={200}>
    <Tooltip>
      <TooltipTrigger asChild>
        {children || (
          <HelpCircle className="h-4 w-4 text-muted-foreground hover:text-primary cursor-help transition-colors" />
        )}
      </TooltipTrigger>
      <TooltipContent side="top" className="max-w-xs text-sm">
        <p>{content}</p>
      </TooltipContent>
    </Tooltip>
  </TooltipProvider>
);

// Section tooltips mapping
const SECTION_TOOLTIPS: Record<string, string> = {
  dashboard: 'Dashboard widgets show real-time compliance metrics. These KPIs and widgets will appear on your home dashboard after activation.',
  lovs: 'List of Values (LOVs) are dropdown options used throughout the system. These ensure consistent data entry across your organization.',
  citations: 'Citation libraries contain pre-defined regulatory citations and deficiency tags, making it faster to document survey findings.',
  enforcement: 'Enforcement templates include deadline rules and remedy templates for responding to regulatory actions within required timeframes.',
  audit: 'Audit templates provide standardized checklists for internal audits, aligned with your selected compliance areas.',
  risk: 'Risk defaults include likelihood/impact scales and risk categories for consistent risk assessment across your organization.',
  capa: 'CAPA (Corrective and Preventive Action) defaults establish workflow statuses and root cause analysis methods.',
  documents: 'Document control defaults set up document types, statuses, and review schedules for policy and procedure management.',
};

interface AppliedSetup {
  appliedAt: string;
  appliedBy: string;
  configVersion: string;
  sections: string[];
  itemCounts: Record<string, number>;
}

export const RecommendedSetupStep: React.FC = () => {
  const { data, nextStep, prevStep } = useOnboarding();
  const { toast } = useToast();
  
  const [applyDefaults, setApplyDefaults] = useState(true);
  const [isApplying, setIsApplying] = useState(false);
  const [appliedSetup, setAppliedSetup] = useState<AppliedSetup | null>(null);
  const [expandedSections, setExpandedSections] = useState<string[]>(['dashboard', 'lovs']);
  const [selectionsChanged, setSelectionsChanged] = useState(false);

  // Get inputs from organization data
  const providerType = data.organization.orgType || '';
  const oversightBodies = data.organization.regulatoryBodies || [];
  const complianceTags = [
    ...(data.organization.coreComplianceTags || []),
    ...(data.organization.advancedComplianceTags || []),
  ];
  const enabledMicroapps = data.microapps.filter(m => m.status === 'enabled').map(m => m.code);

  // Generate the change plan
  const changePlan = useMemo(() => {
    return generateChangePlan(providerType, oversightBodies, complianceTags, enabledMicroapps);
  }, [providerType, oversightBodies, complianceTags, enabledMicroapps]);

  // Check if selections have changed after applying
  useEffect(() => {
    if (appliedSetup) {
      // Simple check - in real app would compare actual values
      setSelectionsChanged(false);
    }
  }, [providerType, oversightBodies, complianceTags, appliedSetup]);

  const toggleSection = (sectionId: string) => {
    setExpandedSections(prev =>
      prev.includes(sectionId)
        ? prev.filter(id => id !== sectionId)
        : [...prev, sectionId]
    );
  };

  const getSectionIcon = (sectionId: string) => {
    const icons: Record<string, React.ReactNode> = {
      dashboard: <LayoutDashboard className="h-5 w-5" />,
      lovs: <List className="h-5 w-5" />,
      citations: <FileWarning className="h-5 w-5" />,
      enforcement: <Scale className="h-5 w-5" />,
      audit: <ClipboardCheck className="h-5 w-5" />,
      risk: <AlertTriangle className="h-5 w-5" />,
      capa: <Shield className="h-5 w-5" />,
      documents: <FileText className="h-5 w-5" />,
    };
    return icons[sectionId] || <Settings className="h-5 w-5" />;
  };

  const handleApply = async () => {
    if (!applyDefaults) {
      nextStep();
      return;
    }

    setIsApplying(true);
    
    // Simulate apply process
    await new Promise(resolve => setTimeout(resolve, 1500));

    const sections: string[] = [];
    const itemCounts: Record<string, number> = {};

    if (changePlan.dashboard) {
      sections.push('Dashboard');
      itemCounts['Dashboard'] = changePlan.dashboard.addCount;
    }
    if (changePlan.lovDefaults) {
      sections.push('LOV/Value Sets');
      itemCounts['LOV/Value Sets'] = changePlan.lovDefaults.addCount;
    }
    if (changePlan.citationsDefaults) {
      sections.push('Citations');
      itemCounts['Citations'] = changePlan.citationsDefaults.addCount;
    }
    if (changePlan.enforcementDefaults) {
      sections.push('Enforcement');
      itemCounts['Enforcement'] = changePlan.enforcementDefaults.addCount;
    }
    if (changePlan.auditDefaults) {
      sections.push('Audit Templates');
      itemCounts['Audit Templates'] = changePlan.auditDefaults.addCount;
    }
    if (changePlan.riskDefaults) {
      sections.push('Risk');
      itemCounts['Risk'] = changePlan.riskDefaults.addCount;
    }
    if (changePlan.capaDefaults) {
      sections.push('CAPA');
      itemCounts['CAPA'] = changePlan.capaDefaults.addCount;
    }
    if (changePlan.documentsDefaults) {
      sections.push('Documents');
      itemCounts['Documents'] = changePlan.documentsDefaults.addCount;
    }

    const applied: AppliedSetup = {
      appliedAt: new Date().toISOString(),
      appliedBy: 'Current User',
      configVersion: 'v1',
      sections,
      itemCounts,
    };

    setAppliedSetup(applied);
    setIsApplying(false);

    toast({
      title: 'Recommended Defaults Applied',
      description: `Successfully configured ${sections.length} areas with ${Object.values(itemCounts).reduce((a, b) => a + b, 0)} items.`,
    });
  };

  const handleSkip = () => {
    toast({
      title: 'Skipped Recommended Setup',
      description: 'You can configure these settings manually in later onboarding steps.',
      variant: 'default',
    });
    nextStep();
  };

  const handleRecalculate = () => {
    setAppliedSetup(null);
    setSelectionsChanged(false);
    toast({
      title: 'Recommendations Recalculated',
      description: 'The change plan has been updated based on your new selections.',
    });
  };

  const totalAddCount = useMemo(() => {
    let count = 0;
    if (changePlan.dashboard) count += changePlan.dashboard.addCount;
    if (changePlan.lovDefaults) count += changePlan.lovDefaults.addCount;
    if (changePlan.citationsDefaults) count += changePlan.citationsDefaults.addCount;
    if (changePlan.enforcementDefaults) count += changePlan.enforcementDefaults.addCount;
    if (changePlan.auditDefaults) count += changePlan.auditDefaults.addCount;
    if (changePlan.riskDefaults) count += changePlan.riskDefaults.addCount;
    if (changePlan.capaDefaults) count += changePlan.capaDefaults.addCount;
    if (changePlan.documentsDefaults) count += changePlan.documentsDefaults.addCount;
    return count;
  }, [changePlan]);

  const renderSectionPreview = (section: PackSection | null) => {
    if (!section) return null;

    const isExpanded = expandedSections.includes(section.id);
    const previewItems = section.items.slice(0, 10);
    const hasMore = section.items.length > 10;

    return (
      <Collapsible
        key={section.id}
        open={isExpanded}
        onOpenChange={() => toggleSection(section.id)}
      >
        <Card className="border-border/50">
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10 text-primary">
                    {getSectionIcon(section.id)}
                  </div>
                  <div className="flex items-center gap-2">
                    <div>
                      <CardTitle className="text-base font-semibold">{section.title}</CardTitle>
                      <CardDescription className="text-sm mt-0.5">{section.description}</CardDescription>
                    </div>
                    <GuidanceTooltip content={SECTION_TOOLTIPS[section.id] || section.description} />
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <GuidanceTooltip content={`${section.addCount} new items will be added. These are additive changes - no existing data will be modified or deleted.`}>
                    <div className="text-right cursor-help">
                      <Badge variant="secondary" className="font-mono">
                        +{section.addCount} items
                      </Badge>
                      {section.updateCount > 0 && (
                        <Badge variant="outline" className="ml-2 font-mono">
                          ~{section.updateCount} updates
                        </Badge>
                      )}
                    </div>
                  </GuidanceTooltip>
                  {isExpanded ? (
                    <ChevronDown className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>
              </div>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="pt-0">
              <div className="bg-muted/30 rounded-lg p-3 mb-4">
                <div className="flex items-start gap-2">
                  <Info className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <p className="text-sm text-muted-foreground">{section.whyRecommended}</p>
                </div>
              </div>
              <div className="space-y-2">
                {previewItems.map((item, idx) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between py-2 px-3 rounded-md bg-background border border-border/50"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-medium">
                        {idx + 1}
                      </div>
                      <div>
                        <p className="text-sm font-medium">{item.name}</p>
                        {item.description && (
                          <p className="text-xs text-muted-foreground">{item.description}</p>
                        )}
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs font-mono">
                      {item.code}
                    </Badge>
                  </div>
                ))}
                {hasMore && (
                  <div className="text-center py-2">
                    <Button variant="ghost" size="sm" className="text-muted-foreground">
                      <Eye className="h-4 w-4 mr-2" />
                      View all {section.items.length} items
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>
    );
  };

  // Check if we have minimum required selections
  const hasMinimumSelections = providerType && oversightBodies.length > 0 && complianceTags.length > 0;

  if (!hasMinimumSelections) {
    return (
      <div className="space-y-6">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-amber-100 text-amber-600 mb-4">
            <AlertCircle className="h-8 w-8" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-2">Complete Previous Steps First</h2>
          <p className="text-muted-foreground max-w-md mx-auto">
            To generate recommended setup defaults, please complete the Organization Setup step with:
          </p>
        </div>

        <Card className="max-w-md mx-auto">
          <CardContent className="pt-6">
            <ul className="space-y-3">
              <li className="flex items-center gap-3">
                {providerType ? (
                  <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-amber-500" />
                )}
                <span className={providerType ? 'text-muted-foreground' : 'font-medium'}>
                  Provider Type selection
                </span>
              </li>
              <li className="flex items-center gap-3">
                {oversightBodies.length > 0 ? (
                  <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-amber-500" />
                )}
                <span className={oversightBodies.length > 0 ? 'text-muted-foreground' : 'font-medium'}>
                  At least one Regulatory Oversight body
                </span>
              </li>
              <li className="flex items-center gap-3">
                {complianceTags.length > 0 ? (
                  <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-amber-500" />
                )}
                <span className={complianceTags.length > 0 ? 'text-muted-foreground' : 'font-medium'}>
                  At least one Compliance Scope tag
                </span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <div className="flex justify-center">
          <Button onClick={prevStep} variant="outline">
            Go Back to Complete Setup
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 text-primary mb-4">
          <Sparkles className="h-8 w-8" />
        </div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Recommended Setup</h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Based on your selections, we've prepared a configuration plan to get you started quickly.
          Preview what will be configured and apply with one click.
        </p>
      </div>

      {/* Selections Changed Warning */}
      {selectionsChanged && (
        <Alert className="border-amber-200 bg-amber-50">
          <AlertCircle className="h-4 w-4 text-amber-600" />
          <AlertTitle className="text-amber-800">Selections Changed</AlertTitle>
          <AlertDescription className="text-amber-700">
            Your provider type, oversight bodies, or compliance scope has changed since applying defaults.
            <Button variant="link" className="p-0 h-auto ml-2 text-amber-800 font-medium" onClick={handleRecalculate}>
              Recalculate & Apply Differences
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Applied Success Banner */}
      {appliedSetup && !selectionsChanged && (
        <Alert className="border-emerald-200 bg-emerald-50">
          <CheckCircle2 className="h-4 w-4 text-emerald-600" />
          <AlertTitle className="text-emerald-800">Recommended Defaults Applied</AlertTitle>
          <AlertDescription className="text-emerald-700">
            Applied at {new Date(appliedSetup.appliedAt).toLocaleString()} • Configuration version: {appliedSetup.configVersion}
            <div className="flex gap-2 mt-2 flex-wrap">
              {appliedSetup.sections.map(section => (
                <Badge key={section} variant="outline" className="bg-emerald-100 text-emerald-700 border-emerald-300">
                  {section}: {appliedSetup.itemCounts[section]} items
                </Badge>
              ))}
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Selections Summary Card */}
      <Card className="bg-muted/30">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              Your Selections Summary
            </CardTitle>
            <GuidanceTooltip content="These are the selections you made in the Organization step. They determine which recommended defaults are generated for your organization." />
          </div>
          <CardDescription>These selections drive the recommended configuration</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-3">
          <div>
            <div className="flex items-center gap-1 mb-1">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Provider Type</p>
              <GuidanceTooltip content="Your facility type determines which regulatory packs and compliance templates are recommended. Different provider types have different survey and compliance requirements." />
            </div>
            <Badge variant="secondary" className="text-sm font-medium">
              {providerType || 'Not selected'}
            </Badge>
          </div>
          <div>
            <div className="flex items-center gap-1 mb-1">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Oversight Bodies</p>
              <GuidanceTooltip content="Regulatory bodies that oversee your organization. Each selected body adds specific citation libraries, enforcement templates, and audit checklists." />
            </div>
            <div className="flex flex-wrap gap-1">
              {oversightBodies.slice(0, 3).map(body => (
                <Badge key={body} variant="outline" className="text-xs">
                  {getOversightBodyName(body).split('(')[0].trim()}
                </Badge>
              ))}
              {oversightBodies.length > 3 && (
                <Badge variant="outline" className="text-xs">+{oversightBodies.length - 3} more</Badge>
              )}
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1 mb-1">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Compliance Scope</p>
              <GuidanceTooltip content="Compliance areas your organization focuses on. Each tag adds relevant LOVs, audit templates, and risk categories specific to that compliance domain." />
            </div>
            <div className="flex flex-wrap gap-1">
              {complianceTags.slice(0, 3).map(tag => (
                <Badge key={tag} variant="outline" className="text-xs">
                  {getComplianceTagName(tag).split('(')[0].trim()}
                </Badge>
              ))}
              {complianceTags.length > 3 && (
                <Badge variant="outline" className="text-xs">+{complianceTags.length - 3} more</Badge>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Change Plan Preview */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div>
              <h3 className="text-lg font-semibold text-foreground">Configuration Preview</h3>
              <p className="text-sm text-muted-foreground">
                {totalAddCount} items will be added across {Object.values(changePlan).filter(Boolean).length} areas
              </p>
            </div>
            <GuidanceTooltip content="Click on any section below to expand and see the specific items that will be configured. All changes are additive and safe - nothing will be deleted." />
          </div>
          <GuidanceTooltip content="Smart Defaults are automatically generated based on your provider type, regulatory oversight, and compliance scope selections.">
            <Badge className="bg-primary/10 text-primary border-primary/20 cursor-help">
              <Zap className="h-3 w-3 mr-1" />
              Smart Defaults
            </Badge>
          </GuidanceTooltip>
        </div>

        <ScrollArea className="h-[500px] pr-4">
          <div className="space-y-3">
            {renderSectionPreview(changePlan.dashboard)}
            {renderSectionPreview(changePlan.lovDefaults)}
            {renderSectionPreview(changePlan.citationsDefaults)}
            {renderSectionPreview(changePlan.enforcementDefaults)}
            {renderSectionPreview(changePlan.auditDefaults)}
            {renderSectionPreview(changePlan.riskDefaults)}
            {renderSectionPreview(changePlan.capaDefaults)}
            {renderSectionPreview(changePlan.documentsDefaults)}
          </div>
        </ScrollArea>
      </div>

      <Separator />

      {/* Apply Controls */}
      {!appliedSetup && (
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <Checkbox
                id="applyDefaults"
                checked={applyDefaults}
                onCheckedChange={(checked) => setApplyDefaults(checked === true)}
                className="mt-1"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <label htmlFor="applyDefaults" className="text-base font-medium cursor-pointer">
                    Apply recommended defaults now
                  </label>
                  <GuidanceTooltip content="When checked, clicking 'Apply & Continue' will configure all the items shown in the preview above. This is recommended for faster setup. You can always modify settings later." />
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  This will configure your organization with the recommended settings shown above.
                  All changes are additive and safe – no existing data will be deleted.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex items-center justify-between pt-4">
        <GuidanceTooltip content="Go back to modify your organization details, compliance scope, or regulatory oversight selections.">
          <Button variant="outline" onClick={prevStep}>
            Back
          </Button>
        </GuidanceTooltip>
        <div className="flex gap-3">
          {!appliedSetup && (
            <GuidanceTooltip content="Skip applying defaults now. You'll need to manually configure LOVs, templates, and settings in later steps.">
              <Button
                variant="ghost"
                onClick={handleSkip}
                className="text-muted-foreground"
              >
                Skip for now
              </Button>
            </GuidanceTooltip>
          )}
          <GuidanceTooltip content={appliedSetup ? "Proceed to the next onboarding step." : applyDefaults ? "Apply all recommended defaults and proceed to the next step." : "Proceed without applying defaults."}>
            <Button
              onClick={appliedSetup ? nextStep : handleApply}
              disabled={isApplying}
              className="min-w-[140px]"
            >
              {isApplying ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-background border-t-transparent mr-2" />
                  Applying...
                </>
              ) : appliedSetup ? (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  Continue
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  {applyDefaults ? 'Apply & Continue' : 'Continue'}
                </>
              )}
            </Button>
          </GuidanceTooltip>
        </div>
      </div>

      {/* Skip Warning */}
      {!appliedSetup && !applyDefaults && (
        <Alert variant="default" className="mt-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Manual Configuration Required</AlertTitle>
          <AlertDescription>
            If you skip, you'll need to manually configure LOVs, templates, and dashboard settings
            in the respective onboarding steps.
          </AlertDescription>
        </Alert>
      )}

      {/* View Applied Items Links */}
      {appliedSetup && (
        <Card className="mt-4">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">View Applied Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm" disabled>
                <List className="h-4 w-4 mr-2" />
                LOV Catalog
              </Button>
              <Button variant="outline" size="sm" disabled>
                <FileWarning className="h-4 w-4 mr-2" />
                Citations Library
              </Button>
              <Button variant="outline" size="sm" disabled>
                <Scale className="h-4 w-4 mr-2" />
                Enforcement Library
              </Button>
              <Button variant="outline" size="sm" disabled>
                <ClipboardCheck className="h-4 w-4 mr-2" />
                Audit Templates
              </Button>
              <Button variant="outline" size="sm" disabled>
                <LayoutDashboard className="h-4 w-4 mr-2" />
                Dashboard Settings
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-3">
              These links will become active after activation. You can review and modify settings in post-onboarding admin.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
