import React, { useState } from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Shield, Users, Building, Crown, Plus, Pencil, Trash2, X, Check } from 'lucide-react';
import { Role, RoleType, ROLE_TYPE_MAX_SCOPE } from '@/types/onboarding';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const ROLE_ICONS: Record<string, React.ElementType> = { 
  staff: Users, 
  department_head: Building, 
  compliance_head: Shield, 
  org_admin: Crown 
};

const ROLE_TYPE_LABELS: Record<RoleType, string> = {
  staff: 'Staff',
  department_head: 'Department Head',
  compliance_head: 'Compliance Head',
  org_admin: 'Org Admin',
};

const SCOPE_LABELS: Record<string, string> = {
  self: 'Self',
  department: 'Department',
  org: 'Organization',
};

interface RoleFormProps {
  role?: Role;
  onSave: (role: Omit<Role, 'id'>) => void;
  onCancel: () => void;
  isSystemRole?: boolean;
}

const RoleForm: React.FC<RoleFormProps> = ({ role, onSave, onCancel, isSystemRole = false }) => {
  const [name, setName] = useState(role?.name || '');
  const [description, setDescription] = useState(role?.description || '');
  const [roleType, setRoleType] = useState<RoleType>(role?.type || 'staff');

  const handleSave = () => {
    if (!name.trim()) return;
    onSave({
      name: name.trim(),
      description: description.trim(),
      type: roleType,
      isSystemRole,
      departmentIds: role?.departmentIds || [],
      microappIds: role?.microappIds || [],
      entitlements: [], // Entitlements are now managed in App Access step
    });
  };

  return (
    <div className="p-4 rounded-lg border border-primary/30 bg-primary/5 space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="font-medium">{role ? 'Edit Role' : 'New Role'}</h4>
        <Button variant="ghost" size="icon" onClick={onCancel}>
          <X className="w-4 h-4" />
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label>Role Name</Label>
          <Input 
            value={name} 
            onChange={e => setName(e.target.value)} 
            placeholder="e.g., Quality Coordinator"
          />
        </div>
        <div className="space-y-2">
          <Label>Role Type</Label>
          <Select value={roleType} onValueChange={(v: RoleType) => setRoleType(v)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="staff">Staff (Max: Self)</SelectItem>
              <SelectItem value="department_head">Department Head (Max: Dept)</SelectItem>
              <SelectItem value="compliance_head">Compliance Head (Max: Org)</SelectItem>
              <SelectItem value="org_admin">Org Admin (Max: Org)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Description</Label>
          <Input 
            value={description} 
            onChange={e => setDescription(e.target.value)} 
            placeholder="Brief description of this role"
          />
        </div>
      </div>

      <p className="text-xs text-muted-foreground">
        App access permissions for this role will be configured in the next step (App Access & Entitlements).
      </p>

      <div className="flex justify-end gap-2 pt-2">
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
        <Button onClick={handleSave} disabled={!name.trim()}>
          <Check className="w-4 h-4 mr-1" /> {role ? 'Update Role' : 'Create Role'}
        </Button>
      </div>
    </div>
  );
};

export const RolesStep: React.FC = () => {
  const { data, addRole, updateRole, removeRole, setCustomRolesEnabled, markStepComplete, nextStep } = useOnboarding();
  const [showForm, setShowForm] = useState(false);
  const [editingRole, setEditingRole] = useState<Role | null>(null);
  const [showAddStandardRole, setShowAddStandardRole] = useState(false);

  const customRoles = data.roles.filter(r => !r.isSystemRole);
  const systemRoles = data.roles.filter(r => r.isSystemRole);

  // Critical roles that cannot be deleted
  const criticalRoleTypes: RoleType[] = ['org_admin', 'compliance_head'];

  const handleCreateRole = (role: Omit<Role, 'id'>) => {
    addRole(role);
    setShowForm(false);
    setShowAddStandardRole(false);
  };

  const handleUpdateRole = (role: Omit<Role, 'id'>) => {
    if (editingRole) {
      updateRole(editingRole.id, { ...role, isSystemRole: editingRole.isSystemRole });
      setEditingRole(null);
    }
  };

  const handleDeleteRole = (role: Role) => {
    if (criticalRoleTypes.includes(role.type)) {
      alert(`Cannot delete ${role.name} - this role is required for system operation.`);
      return;
    }
    if (confirm(`Are you sure you want to delete "${role.name}"?`)) {
      removeRole(role.id);
    }
  };

  return (
    <div className="space-y-6">
      {/* System Roles Section */}
      <div className="form-section">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="form-section-title mb-0">Standard Roles</h3>
            <p className="text-sm text-muted-foreground">Core roles for your organization. Org Admin and Compliance Head are required.</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Label className="text-sm">Allow Custom Roles</Label>
              <Switch checked={data.customRolesEnabled} onCheckedChange={setCustomRolesEnabled} />
            </div>
            {!showAddStandardRole && !editingRole && (
              <Button variant="outline" size="sm" onClick={() => setShowAddStandardRole(true)}>
                <Plus className="w-4 h-4 mr-1" /> Add Standard Role
              </Button>
            )}
          </div>
        </div>

        {/* Add Standard Role Form */}
        {showAddStandardRole && (
          <div className="mb-4">
            <RoleForm 
              onSave={(role) => handleCreateRole({ ...role, isSystemRole: true })} 
              onCancel={() => setShowAddStandardRole(false)}
              isSystemRole={true}
            />
          </div>
        )}

        {/* Edit Role Form (for system roles) */}
        {editingRole && editingRole.isSystemRole && (
          <div className="mb-4">
            <RoleForm 
              role={editingRole}
              onSave={handleUpdateRole} 
              onCancel={() => setEditingRole(null)}
              isSystemRole={true}
            />
          </div>
        )}

        <div className="space-y-3">
          {systemRoles.map(role => {
            const Icon = ROLE_ICONS[role.type] || Users;
            const isCritical = criticalRoleTypes.includes(role.type);
            const isEditing = editingRole?.id === role.id;
            
            if (isEditing) return null;
            
            return (
              <div key={role.id} className="p-4 rounded-lg border border-border flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{role.name}</p>
                      {isCritical && <Badge variant="destructive" className="text-xs">Required</Badge>}
                    </div>
                    <p className="text-sm text-muted-foreground">{role.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right mr-2">
                    <Badge variant="secondary" className="text-xs">
                      {ROLE_TYPE_LABELS[role.type]}
                    </Badge>
                    <p className="text-xs text-muted-foreground mt-1">
                      Max Scope: {SCOPE_LABELS[ROLE_TYPE_MAX_SCOPE[role.type]]}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" onClick={() => setEditingRole(role)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleDeleteRole(role)}
                      disabled={isCritical}
                      title={isCritical ? 'This role is required and cannot be deleted' : 'Delete role'}
                    >
                      <Trash2 className={`w-4 h-4 ${isCritical ? 'text-muted-foreground' : 'text-destructive'}`} />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Custom Roles Section */}
      {data.customRolesEnabled && (
        <div className="form-section">
          <div className="flex items-center justify-between mb-4">
            <h3 className="form-section-title mb-0">Custom Roles</h3>
            {!showForm && !editingRole && (
              <Button variant="outline" size="sm" onClick={() => setShowForm(true)}>
                <Plus className="w-4 h-4 mr-1" /> Add Custom Role
              </Button>
            )}
          </div>

          {/* Create Form */}
          {showForm && (
            <RoleForm 
              onSave={handleCreateRole} 
              onCancel={() => setShowForm(false)}
              isSystemRole={false}
            />
          )}

          {/* Edit Form for Custom Role */}
          {editingRole && !editingRole.isSystemRole && (
            <RoleForm 
              role={editingRole}
              onSave={handleUpdateRole} 
              onCancel={() => setEditingRole(null)}
              isSystemRole={false}
            />
          )}

          {/* Custom Roles List */}
          {!showForm && !(editingRole && !editingRole.isSystemRole) && (
            <div className="space-y-3">
              {customRoles.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8 border border-dashed rounded-lg">
                  No custom roles yet. Click "Add Custom Role" to create one.
                </p>
              ) : (
                customRoles.map(role => {
                  const Icon = ROLE_ICONS[role.type] || Users;
                  return (
                    <div key={role.id} className="p-4 rounded-lg border border-border flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-secondary/50 flex items-center justify-center">
                          <Icon className="w-5 h-5 text-muted-foreground" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-medium">{role.name}</p>
                            <Badge variant="outline" className="text-xs">Custom</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{role.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right mr-2">
                          <Badge variant="secondary" className="text-xs">
                            {ROLE_TYPE_LABELS[role.type]}
                          </Badge>
                          <p className="text-xs text-muted-foreground mt-1">
                            Max Scope: {SCOPE_LABELS[ROLE_TYPE_MAX_SCOPE[role.type]]}
                          </p>
                        </div>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" onClick={() => setEditingRole(role)}>
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDeleteRole(role)}>
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      )}

      {/* Info Note */}
      <div className="p-4 rounded-lg bg-muted/50 border border-border text-sm text-muted-foreground">
        <p>
          <strong>Next Step:</strong> After defining roles here, you'll configure what each role can access 
          (apps, dashboard features, exports) in the App Access & Entitlements step.
        </p>
      </div>

      <div className="flex justify-end">
        <Button onClick={() => { markStepComplete(6); nextStep(); }}>Continue</Button>
      </div>
    </div>
  );
};
