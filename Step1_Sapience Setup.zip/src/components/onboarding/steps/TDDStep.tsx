import React from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { usePdfDownload } from '@/hooks/usePdfDownload';
import { 
  Code2, 
  Database, 
  Shield, 
  Server, 
  Layers, 
  Lock,
  Network,
  BookOpen,
  Cpu,
  Globe,
  Key,
  FileCode,
  Download
} from 'lucide-react';

export const TDDStep: React.FC = () => {
  const { data } = useOnboarding();
  const org = data.organization;
  const { contentRef, downloadPdf } = usePdfDownload();

  const handleDownload = () => {
    const orgName = org.name || 'Organization';
    const filename = `TDD_${orgName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;
    downloadPdf({ filename, title: 'Technical Design Document' });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-heading font-bold text-foreground flex items-center gap-2">
            <Code2 className="w-6 h-6 text-primary" />
            Technical Design Document (TDD)
          </h2>
          <p className="text-muted-foreground mt-1">
            Technical specifications and architecture for {org.name || 'your organization'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleDownload} className="gap-2">
            <Download className="w-4 h-4" />
            Download PDF
          </Button>
          <Badge variant="outline" className="text-xs">
            Auto-Generated
          </Badge>
        </div>
      </div>

      <ScrollArea className="h-[calc(100vh-280px)]">
        <div ref={contentRef} className="space-y-6 pr-4">
          {/* System Architecture */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Server className="w-5 h-5 text-primary" />
                1. System Architecture Overview
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-sm mb-2">1.1 Architecture Pattern</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  MedComply follows a multi-tenant SaaS architecture with microservices-based backend 
                  and a modern React-based single-page application (SPA) frontend.
                </p>
                <div className="bg-muted/50 p-4 rounded-lg font-mono text-xs">
                  <pre className="whitespace-pre-wrap text-muted-foreground">
{`┌─────────────────────────────────────────────────────────┐
│                    CLIENT LAYER                          │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐      │
│  │   React     │  │   Mobile    │  │   Admin     │      │
│  │   Web App   │  │   PWA       │  │   Console   │      │
│  └─────────────┘  └─────────────┘  └─────────────┘      │
├─────────────────────────────────────────────────────────┤
│                    API GATEWAY                           │
│  ┌─────────────────────────────────────────────────┐    │
│  │  Authentication │ Rate Limiting │ Load Balancer │    │
│  └─────────────────────────────────────────────────┘    │
├─────────────────────────────────────────────────────────┤
│                  MICROSERVICES LAYER                     │
│  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐ ┌───────┐ │
│  │ Auth   │ │Complnce│ │ Audit  │ │ Report │ │Notific│ │
│  │Service │ │Service │ │Service │ │Service │ │Service│ │
│  └────────┘ └────────┘ └────────┘ └────────┘ └───────┘ │
├─────────────────────────────────────────────────────────┤
│                    DATA LAYER                            │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐      │
│  │  PostgreSQL │  │    Redis    │  │ S3 Storage  │      │
│  │  (Primary)  │  │   (Cache)   │  │  (Documents)│      │
│  └─────────────┘  └─────────────┘  └─────────────┘      │
└─────────────────────────────────────────────────────────┘`}
                  </pre>
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-2">1.2 Technology Stack</h4>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground mb-2">Frontend</p>
                    <div className="flex flex-wrap gap-1">
                      {['React 18', 'TypeScript', 'Vite', 'Tailwind CSS', 'Shadcn/UI', 'React Query', 'React Router'].map(tech => (
                        <Badge key={tech} variant="secondary" className="text-xs">{tech}</Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-2">Backend</p>
                    <div className="flex flex-wrap gap-1">
                      {['Node.js', 'Express', 'PostgreSQL', 'Redis', 'Supabase', 'Edge Functions'].map(tech => (
                        <Badge key={tech} variant="secondary" className="text-xs">{tech}</Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-2">Infrastructure</p>
                    <div className="flex flex-wrap gap-1">
                      {['AWS/GCP', 'Docker', 'Kubernetes', 'CloudFlare', 'S3'].map(tech => (
                        <Badge key={tech} variant="secondary" className="text-xs">{tech}</Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-2">DevOps</p>
                    <div className="flex flex-wrap gap-1">
                      {['GitHub Actions', 'Terraform', 'Datadog', 'Sentry'].map(tech => (
                        <Badge key={tech} variant="secondary" className="text-xs">{tech}</Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Database Design */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Database className="w-5 h-5 text-primary" />
                2. Database Design
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-sm mb-2">2.1 Entity Relationship Overview</h4>
                <div className="bg-muted/50 p-4 rounded-lg font-mono text-xs">
                  <pre className="whitespace-pre-wrap text-muted-foreground">
{`┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│ Organization │────<│   Facility   │────<│  Department  │
└──────────────┘     └──────────────┘     └──────────────┘
       │                    │                    │
       │                    │                    │
       ▼                    ▼                    ▼
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│     User     │────<│     Role     │────<│  Entitlement │
└──────────────┘     └──────────────┘     └──────────────┘
       │
       ▼
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│  AuditLog    │     │  Microapp    │     │   LOVItem    │
└──────────────┘     └──────────────┘     └──────────────┘`}
                  </pre>
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-3">2.2 Core Tables</h4>
                <div className="space-y-3">
                  {[
                    { table: 'organizations', cols: 'id, name, code, type, status, settings_json, created_at' },
                    { table: 'facilities', cols: 'id, org_id, name, code, address, timezone, status' },
                    { table: 'departments', cols: 'id, org_id, name, code, facility_ids, status' },
                    { table: 'users', cols: 'id, org_id, email, name, role_ids, mfa_enabled, status' },
                    { table: 'roles', cols: 'id, org_id, name, type, entitlements_json, is_system' },
                    { table: 'audit_logs', cols: 'id, org_id, user_id, action, resource, details_json, timestamp' },
                    { table: 'microapps', cols: 'id, org_id, code, name, config_json, status' },
                  ].map((item, idx) => (
                    <div key={idx} className="border rounded-lg p-3">
                      <code className="text-sm font-mono text-primary">{item.table}</code>
                      <p className="text-xs text-muted-foreground mt-1">{item.cols}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-2">2.3 Data Partitioning Strategy</h4>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  <li>Tenant-based partitioning using org_id</li>
                  <li>Time-based partitioning for audit_logs (monthly)</li>
                  <li>Row-level security (RLS) for multi-tenant isolation</li>
                  <li>Read replicas for reporting queries</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Security Architecture */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                3. Security Architecture
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-sm mb-2">3.1 Authentication Flow</h4>
                <div className="bg-muted/50 p-4 rounded-lg font-mono text-xs">
                  <pre className="whitespace-pre-wrap text-muted-foreground">
{`User Login Request
       │
       ▼
┌─────────────────┐
│ Validate Creds  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐    ┌─────────────────┐
│  MFA Required?  │───>│  Verify MFA     │
└────────┬────────┘    └────────┬────────┘
         │                      │
         ▼                      ▼
┌─────────────────┐    ┌─────────────────┐
│ Generate JWT    │<───│  MFA Success    │
└────────┬────────┘    └─────────────────┘
         │
         ▼
┌─────────────────┐
│ Return Tokens   │
│ (Access+Refresh)│
└─────────────────┘`}
                  </pre>
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-3">3.2 Security Controls</h4>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Lock className="w-4 h-4 text-green-500" />
                      <span className="text-sm">Encryption at Rest (AES-256)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Lock className="w-4 h-4 text-green-500" />
                      <span className="text-sm">Encryption in Transit (TLS 1.3)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Key className="w-4 h-4 text-blue-500" />
                      <span className="text-sm">MFA: {data.securitySettings.mfaEnforcement || 'Required'}</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Network className="w-4 h-4 text-purple-500" />
                      <span className="text-sm">Session Timeout: {data.securitySettings.sessionTimeoutMinutes}min</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Database className="w-4 h-4 text-orange-500" />
                      <span className="text-sm">Log Retention: {data.securitySettings.logRetentionDays} days</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Globe className="w-4 h-4 text-cyan-500" />
                      <span className="text-sm">Data Residency: {data.tenantSettings.dataResidencyRegion}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* API Design - Comprehensive */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Layers className="w-5 h-5 text-primary" />
                4. API Design - Complete Endpoint Catalog
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Authentication APIs */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Key className="w-4 h-4 text-primary" />
                  4.1 Authentication & Session APIs
                </h4>
                <div className="space-y-2 font-mono text-xs">
                  {[
                    { method: 'POST', path: '/api/v1/auth/login', desc: 'Authenticate user with credentials' },
                    { method: 'POST', path: '/api/v1/auth/logout', desc: 'Invalidate current session' },
                    { method: 'POST', path: '/api/v1/auth/refresh', desc: 'Refresh access token using refresh token' },
                    { method: 'POST', path: '/api/v1/auth/mfa/setup', desc: 'Initialize MFA setup for user' },
                    { method: 'POST', path: '/api/v1/auth/mfa/verify', desc: 'Verify MFA code during login' },
                    { method: 'POST', path: '/api/v1/auth/mfa/disable', desc: 'Disable MFA for user (admin only)' },
                    { method: 'POST', path: '/api/v1/auth/password/reset', desc: 'Request password reset email' },
                    { method: 'PUT', path: '/api/v1/auth/password/change', desc: 'Change password with current password' },
                    { method: 'POST', path: '/api/v1/auth/sso/saml/callback', desc: 'SAML SSO callback handler' },
                    { method: 'GET', path: '/api/v1/auth/sso/saml/metadata', desc: 'Get SAML service provider metadata' },
                    { method: 'POST', path: '/api/v1/auth/sso/oidc/callback', desc: 'OIDC SSO callback handler' },
                    { method: 'GET', path: '/api/v1/auth/sessions', desc: 'List active sessions for current user' },
                    { method: 'DELETE', path: '/api/v1/auth/sessions/:id', desc: 'Terminate specific session' },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                      <Badge variant={api.method === 'GET' ? 'secondary' : api.method === 'POST' ? 'default' : api.method === 'DELETE' ? 'destructive' : 'outline'} className="w-16 justify-center text-xs">
                        {api.method}
                      </Badge>
                      <code className="text-primary flex-1 truncate">{api.path}</code>
                      <span className="text-muted-foreground text-xs hidden md:block">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Organization APIs */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Server className="w-4 h-4 text-primary" />
                  4.2 Organization & Tenant APIs
                </h4>
                <div className="space-y-2 font-mono text-xs">
                  {[
                    { method: 'GET', path: '/api/v1/organizations/:id', desc: 'Get organization details' },
                    { method: 'PUT', path: '/api/v1/organizations/:id', desc: 'Update organization settings' },
                    { method: 'GET', path: '/api/v1/organizations/:id/settings', desc: 'Get organization configuration' },
                    { method: 'PUT', path: '/api/v1/organizations/:id/settings', desc: 'Update organization configuration' },
                    { method: 'GET', path: '/api/v1/organizations/:id/branding', desc: 'Get branding configuration' },
                    { method: 'PUT', path: '/api/v1/organizations/:id/branding', desc: 'Update branding (logos, colors, theme)' },
                    { method: 'POST', path: '/api/v1/organizations/:id/branding/logo', desc: 'Upload organization logo' },
                    { method: 'GET', path: '/api/v1/organizations/:id/subscription', desc: 'Get subscription/license details' },
                    { method: 'GET', path: '/api/v1/organizations/:id/usage', desc: 'Get usage metrics and limits' },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                      <Badge variant={api.method === 'GET' ? 'secondary' : api.method === 'POST' ? 'default' : 'outline'} className="w-16 justify-center text-xs">
                        {api.method}
                      </Badge>
                      <code className="text-primary flex-1 truncate">{api.path}</code>
                      <span className="text-muted-foreground text-xs hidden md:block">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Facility APIs */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Globe className="w-4 h-4 text-primary" />
                  4.3 Facility & Location APIs
                </h4>
                <div className="space-y-2 font-mono text-xs">
                  {[
                    { method: 'GET', path: '/api/v1/facilities', desc: 'List all facilities (paginated)' },
                    { method: 'POST', path: '/api/v1/facilities', desc: 'Create new facility' },
                    { method: 'GET', path: '/api/v1/facilities/:id', desc: 'Get facility details' },
                    { method: 'PUT', path: '/api/v1/facilities/:id', desc: 'Update facility information' },
                    { method: 'DELETE', path: '/api/v1/facilities/:id', desc: 'Deactivate facility' },
                    { method: 'GET', path: '/api/v1/facilities/:id/departments', desc: 'List departments in facility' },
                    { method: 'POST', path: '/api/v1/facilities/:id/departments', desc: 'Create department in facility' },
                    { method: 'GET', path: '/api/v1/facilities/:id/users', desc: 'List users assigned to facility' },
                    { method: 'GET', path: '/api/v1/facilities/:id/compliance-status', desc: 'Get facility compliance summary' },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                      <Badge variant={api.method === 'GET' ? 'secondary' : api.method === 'POST' ? 'default' : api.method === 'DELETE' ? 'destructive' : 'outline'} className="w-16 justify-center text-xs">
                        {api.method}
                      </Badge>
                      <code className="text-primary flex-1 truncate">{api.path}</code>
                      <span className="text-muted-foreground text-xs hidden md:block">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Department APIs */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-primary" />
                  4.4 Department APIs
                </h4>
                <div className="space-y-2 font-mono text-xs">
                  {[
                    { method: 'GET', path: '/api/v1/departments', desc: 'List all departments' },
                    { method: 'POST', path: '/api/v1/departments', desc: 'Create new department' },
                    { method: 'GET', path: '/api/v1/departments/:id', desc: 'Get department details' },
                    { method: 'PUT', path: '/api/v1/departments/:id', desc: 'Update department' },
                    { method: 'DELETE', path: '/api/v1/departments/:id', desc: 'Deactivate department' },
                    { method: 'GET', path: '/api/v1/departments/:id/users', desc: 'List users in department' },
                    { method: 'POST', path: '/api/v1/departments/:id/users', desc: 'Assign user to department' },
                    { method: 'DELETE', path: '/api/v1/departments/:id/users/:userId', desc: 'Remove user from department' },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                      <Badge variant={api.method === 'GET' ? 'secondary' : api.method === 'POST' ? 'default' : api.method === 'DELETE' ? 'destructive' : 'outline'} className="w-16 justify-center text-xs">
                        {api.method}
                      </Badge>
                      <code className="text-primary flex-1 truncate">{api.path}</code>
                      <span className="text-muted-foreground text-xs hidden md:block">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* User Management APIs */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-primary" />
                  4.5 User Management APIs
                </h4>
                <div className="space-y-2 font-mono text-xs">
                  {[
                    { method: 'GET', path: '/api/v1/users', desc: 'List all users (paginated, filterable)' },
                    { method: 'POST', path: '/api/v1/users', desc: 'Create new user' },
                    { method: 'GET', path: '/api/v1/users/:id', desc: 'Get user details' },
                    { method: 'PUT', path: '/api/v1/users/:id', desc: 'Update user information' },
                    { method: 'DELETE', path: '/api/v1/users/:id', desc: 'Deactivate user account' },
                    { method: 'POST', path: '/api/v1/users/:id/activate', desc: 'Activate user account' },
                    { method: 'POST', path: '/api/v1/users/:id/suspend', desc: 'Suspend user account' },
                    { method: 'GET', path: '/api/v1/users/:id/roles', desc: 'Get user role assignments' },
                    { method: 'PUT', path: '/api/v1/users/:id/roles', desc: 'Update user role assignments' },
                    { method: 'GET', path: '/api/v1/users/:id/permissions', desc: 'Get effective permissions' },
                    { method: 'GET', path: '/api/v1/users/:id/facilities', desc: 'Get user facility assignments' },
                    { method: 'PUT', path: '/api/v1/users/:id/facilities', desc: 'Update facility assignments' },
                    { method: 'POST', path: '/api/v1/users/bulk-import', desc: 'Bulk import users from CSV' },
                    { method: 'GET', path: '/api/v1/users/export', desc: 'Export user list to CSV' },
                    { method: 'POST', path: '/api/v1/users/:id/reset-password', desc: 'Admin-initiated password reset' },
                    { method: 'GET', path: '/api/v1/users/me', desc: 'Get current user profile' },
                    { method: 'PUT', path: '/api/v1/users/me', desc: 'Update current user profile' },
                    { method: 'PUT', path: '/api/v1/users/me/preferences', desc: 'Update user preferences' },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                      <Badge variant={api.method === 'GET' ? 'secondary' : api.method === 'POST' ? 'default' : api.method === 'DELETE' ? 'destructive' : 'outline'} className="w-16 justify-center text-xs">
                        {api.method}
                      </Badge>
                      <code className="text-primary flex-1 truncate">{api.path}</code>
                      <span className="text-muted-foreground text-xs hidden md:block">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Role & Permission APIs */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-primary" />
                  4.6 Role & Permission APIs
                </h4>
                <div className="space-y-2 font-mono text-xs">
                  {[
                    { method: 'GET', path: '/api/v1/roles', desc: 'List all roles' },
                    { method: 'POST', path: '/api/v1/roles', desc: 'Create custom role' },
                    { method: 'GET', path: '/api/v1/roles/:id', desc: 'Get role details' },
                    { method: 'PUT', path: '/api/v1/roles/:id', desc: 'Update role' },
                    { method: 'DELETE', path: '/api/v1/roles/:id', desc: 'Delete custom role' },
                    { method: 'GET', path: '/api/v1/roles/:id/entitlements', desc: 'Get role entitlements' },
                    { method: 'PUT', path: '/api/v1/roles/:id/entitlements', desc: 'Update role entitlements' },
                    { method: 'GET', path: '/api/v1/roles/:id/users', desc: 'List users with this role' },
                    { method: 'GET', path: '/api/v1/entitlements', desc: 'List all available entitlements' },
                    { method: 'GET', path: '/api/v1/permissions/matrix', desc: 'Get full permission matrix' },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                      <Badge variant={api.method === 'GET' ? 'secondary' : api.method === 'POST' ? 'default' : api.method === 'DELETE' ? 'destructive' : 'outline'} className="w-16 justify-center text-xs">
                        {api.method}
                      </Badge>
                      <code className="text-primary flex-1 truncate">{api.path}</code>
                      <span className="text-muted-foreground text-xs hidden md:block">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Microapp APIs */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-primary" />
                  4.7 Microapp & Module APIs
                </h4>
                <div className="space-y-2 font-mono text-xs">
                  {[
                    { method: 'GET', path: '/api/v1/microapps', desc: 'List all microapps' },
                    { method: 'GET', path: '/api/v1/microapps/:code', desc: 'Get microapp configuration' },
                    { method: 'PUT', path: '/api/v1/microapps/:code', desc: 'Update microapp settings' },
                    { method: 'POST', path: '/api/v1/microapps/:code/enable', desc: 'Enable microapp' },
                    { method: 'POST', path: '/api/v1/microapps/:code/disable', desc: 'Disable microapp' },
                    { method: 'GET', path: '/api/v1/microapps/:code/access', desc: 'Get microapp access rules' },
                    { method: 'PUT', path: '/api/v1/microapps/:code/access', desc: 'Update microapp access rules' },
                    { method: 'GET', path: '/api/v1/microapps/available', desc: 'List available microapps for license' },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                      <Badge variant={api.method === 'GET' ? 'secondary' : api.method === 'POST' ? 'default' : 'outline'} className="w-16 justify-center text-xs">
                        {api.method}
                      </Badge>
                      <code className="text-primary flex-1 truncate">{api.path}</code>
                      <span className="text-muted-foreground text-xs hidden md:block">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* LOV APIs */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Database className="w-4 h-4 text-primary" />
                  4.8 List of Values (LOV) APIs
                </h4>
                <div className="space-y-2 font-mono text-xs">
                  {[
                    { method: 'GET', path: '/api/v1/lov', desc: 'List all LOV sets' },
                    { method: 'GET', path: '/api/v1/lov/:setId', desc: 'Get LOV set details' },
                    { method: 'PUT', path: '/api/v1/lov/:setId', desc: 'Update LOV set' },
                    { method: 'GET', path: '/api/v1/lov/:setId/items', desc: 'List items in LOV set' },
                    { method: 'POST', path: '/api/v1/lov/:setId/items', desc: 'Add item to LOV set' },
                    { method: 'PUT', path: '/api/v1/lov/:setId/items/:itemId', desc: 'Update LOV item' },
                    { method: 'DELETE', path: '/api/v1/lov/:setId/items/:itemId', desc: 'Remove LOV item' },
                    { method: 'PUT', path: '/api/v1/lov/:setId/items/reorder', desc: 'Reorder LOV items' },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                      <Badge variant={api.method === 'GET' ? 'secondary' : api.method === 'POST' ? 'default' : api.method === 'DELETE' ? 'destructive' : 'outline'} className="w-16 justify-center text-xs">
                        {api.method}
                      </Badge>
                      <code className="text-primary flex-1 truncate">{api.path}</code>
                      <span className="text-muted-foreground text-xs hidden md:block">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Compliance APIs */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-primary" />
                  4.9 Compliance & Assessment APIs
                </h4>
                <div className="space-y-2 font-mono text-xs">
                  {[
                    { method: 'GET', path: '/api/v1/compliance/frameworks', desc: 'List compliance frameworks' },
                    { method: 'GET', path: '/api/v1/compliance/frameworks/:id', desc: 'Get framework details' },
                    { method: 'GET', path: '/api/v1/compliance/assessments', desc: 'List assessments' },
                    { method: 'POST', path: '/api/v1/compliance/assessments', desc: 'Create new assessment' },
                    { method: 'GET', path: '/api/v1/compliance/assessments/:id', desc: 'Get assessment details' },
                    { method: 'PUT', path: '/api/v1/compliance/assessments/:id', desc: 'Update assessment' },
                    { method: 'POST', path: '/api/v1/compliance/assessments/:id/submit', desc: 'Submit assessment for review' },
                    { method: 'POST', path: '/api/v1/compliance/assessments/:id/approve', desc: 'Approve assessment' },
                    { method: 'GET', path: '/api/v1/compliance/controls', desc: 'List compliance controls' },
                    { method: 'GET', path: '/api/v1/compliance/controls/:id', desc: 'Get control details' },
                    { method: 'GET', path: '/api/v1/compliance/controls/:id/evidence', desc: 'List control evidence' },
                    { method: 'POST', path: '/api/v1/compliance/controls/:id/evidence', desc: 'Upload control evidence' },
                    { method: 'GET', path: '/api/v1/compliance/dashboard', desc: 'Get compliance dashboard data' },
                    { method: 'GET', path: '/api/v1/compliance/gaps', desc: 'List compliance gaps' },
                    { method: 'GET', path: '/api/v1/compliance/score', desc: 'Get overall compliance score' },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                      <Badge variant={api.method === 'GET' ? 'secondary' : api.method === 'POST' ? 'default' : 'outline'} className="w-16 justify-center text-xs">
                        {api.method}
                      </Badge>
                      <code className="text-primary flex-1 truncate">{api.path}</code>
                      <span className="text-muted-foreground text-xs hidden md:block">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Audit APIs */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-primary" />
                  4.10 Audit & Logging APIs
                </h4>
                <div className="space-y-2 font-mono text-xs">
                  {[
                    { method: 'GET', path: '/api/v1/audit-logs', desc: 'Query audit logs (filterable)' },
                    { method: 'GET', path: '/api/v1/audit-logs/:id', desc: 'Get audit log entry details' },
                    { method: 'GET', path: '/api/v1/audit-logs/export', desc: 'Export audit logs' },
                    { method: 'GET', path: '/api/v1/audit-logs/summary', desc: 'Get audit summary statistics' },
                    { method: 'GET', path: '/api/v1/audit-logs/users/:userId', desc: 'Get audit logs for user' },
                    { method: 'GET', path: '/api/v1/audit-logs/resources/:type/:id', desc: 'Get audit logs for resource' },
                    { method: 'GET', path: '/api/v1/security-events', desc: 'List security events' },
                    { method: 'GET', path: '/api/v1/security-events/:id', desc: 'Get security event details' },
                    { method: 'POST', path: '/api/v1/security-events/:id/acknowledge', desc: 'Acknowledge security event' },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                      <Badge variant={api.method === 'GET' ? 'secondary' : api.method === 'POST' ? 'default' : 'outline'} className="w-16 justify-center text-xs">
                        {api.method}
                      </Badge>
                      <code className="text-primary flex-1 truncate">{api.path}</code>
                      <span className="text-muted-foreground text-xs hidden md:block">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Notification APIs */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Network className="w-4 h-4 text-primary" />
                  4.11 Notification & Communication APIs
                </h4>
                <div className="space-y-2 font-mono text-xs">
                  {[
                    { method: 'GET', path: '/api/v1/notifications', desc: 'List user notifications' },
                    { method: 'GET', path: '/api/v1/notifications/:id', desc: 'Get notification details' },
                    { method: 'PUT', path: '/api/v1/notifications/:id/read', desc: 'Mark notification as read' },
                    { method: 'PUT', path: '/api/v1/notifications/read-all', desc: 'Mark all notifications as read' },
                    { method: 'DELETE', path: '/api/v1/notifications/:id', desc: 'Delete notification' },
                    { method: 'GET', path: '/api/v1/notifications/preferences', desc: 'Get notification preferences' },
                    { method: 'PUT', path: '/api/v1/notifications/preferences', desc: 'Update notification preferences' },
                    { method: 'POST', path: '/api/v1/notifications/send', desc: 'Send notification (admin)' },
                    { method: 'GET', path: '/api/v1/notifications/templates', desc: 'List notification templates' },
                    { method: 'PUT', path: '/api/v1/notifications/templates/:id', desc: 'Update notification template' },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                      <Badge variant={api.method === 'GET' ? 'secondary' : api.method === 'POST' ? 'default' : api.method === 'DELETE' ? 'destructive' : 'outline'} className="w-16 justify-center text-xs">
                        {api.method}
                      </Badge>
                      <code className="text-primary flex-1 truncate">{api.path}</code>
                      <span className="text-muted-foreground text-xs hidden md:block">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Document & File APIs */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-primary" />
                  4.12 Document & File Storage APIs
                </h4>
                <div className="space-y-2 font-mono text-xs">
                  {[
                    { method: 'GET', path: '/api/v1/documents', desc: 'List documents' },
                    { method: 'POST', path: '/api/v1/documents', desc: 'Upload document' },
                    { method: 'GET', path: '/api/v1/documents/:id', desc: 'Get document metadata' },
                    { method: 'GET', path: '/api/v1/documents/:id/download', desc: 'Download document' },
                    { method: 'DELETE', path: '/api/v1/documents/:id', desc: 'Delete document' },
                    { method: 'GET', path: '/api/v1/documents/:id/versions', desc: 'List document versions' },
                    { method: 'POST', path: '/api/v1/documents/:id/versions', desc: 'Upload new version' },
                    { method: 'GET', path: '/api/v1/documents/search', desc: 'Search documents' },
                    { method: 'POST', path: '/api/v1/documents/bulk-upload', desc: 'Bulk upload documents' },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                      <Badge variant={api.method === 'GET' ? 'secondary' : api.method === 'POST' ? 'default' : api.method === 'DELETE' ? 'destructive' : 'outline'} className="w-16 justify-center text-xs">
                        {api.method}
                      </Badge>
                      <code className="text-primary flex-1 truncate">{api.path}</code>
                      <span className="text-muted-foreground text-xs hidden md:block">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Report APIs */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-primary" />
                  4.13 Reporting & Analytics APIs
                </h4>
                <div className="space-y-2 font-mono text-xs">
                  {[
                    { method: 'GET', path: '/api/v1/reports', desc: 'List available reports' },
                    { method: 'GET', path: '/api/v1/reports/:id', desc: 'Get report configuration' },
                    { method: 'POST', path: '/api/v1/reports/:id/generate', desc: 'Generate report' },
                    { method: 'GET', path: '/api/v1/reports/:id/download', desc: 'Download generated report' },
                    { method: 'POST', path: '/api/v1/reports/custom', desc: 'Create custom report' },
                    { method: 'GET', path: '/api/v1/reports/scheduled', desc: 'List scheduled reports' },
                    { method: 'POST', path: '/api/v1/reports/scheduled', desc: 'Schedule report' },
                    { method: 'DELETE', path: '/api/v1/reports/scheduled/:id', desc: 'Cancel scheduled report' },
                    { method: 'GET', path: '/api/v1/analytics/dashboard', desc: 'Get dashboard analytics' },
                    { method: 'GET', path: '/api/v1/analytics/trends', desc: 'Get trend data' },
                    { method: 'GET', path: '/api/v1/analytics/widgets/:type', desc: 'Get widget data' },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                      <Badge variant={api.method === 'GET' ? 'secondary' : api.method === 'POST' ? 'default' : api.method === 'DELETE' ? 'destructive' : 'outline'} className="w-16 justify-center text-xs">
                        {api.method}
                      </Badge>
                      <code className="text-primary flex-1 truncate">{api.path}</code>
                      <span className="text-muted-foreground text-xs hidden md:block">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* System & Admin APIs */}
              <div>
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Server className="w-4 h-4 text-primary" />
                  4.14 System & Administration APIs
                </h4>
                <div className="space-y-2 font-mono text-xs">
                  {[
                    { method: 'GET', path: '/api/v1/system/health', desc: 'System health check' },
                    { method: 'GET', path: '/api/v1/system/version', desc: 'Get system version' },
                    { method: 'GET', path: '/api/v1/system/config', desc: 'Get system configuration' },
                    { method: 'PUT', path: '/api/v1/system/config', desc: 'Update system configuration' },
                    { method: 'GET', path: '/api/v1/system/features', desc: 'Get feature flags' },
                    { method: 'PUT', path: '/api/v1/system/features/:flag', desc: 'Toggle feature flag' },
                    { method: 'POST', path: '/api/v1/system/cache/clear', desc: 'Clear system cache' },
                    { method: 'GET', path: '/api/v1/system/jobs', desc: 'List background jobs' },
                    { method: 'POST', path: '/api/v1/system/jobs/:id/retry', desc: 'Retry failed job' },
                    { method: 'GET', path: '/api/v1/system/integrations', desc: 'List active integrations' },
                    { method: 'POST', path: '/api/v1/system/integrations/:id/test', desc: 'Test integration connection' },
                  ].map((api, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                      <Badge variant={api.method === 'GET' ? 'secondary' : api.method === 'POST' ? 'default' : 'outline'} className="w-16 justify-center text-xs">
                        {api.method}
                      </Badge>
                      <code className="text-primary flex-1 truncate">{api.path}</code>
                      <span className="text-muted-foreground text-xs hidden md:block">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* API Standards */}
              <div className="border-t pt-4">
                <h4 className="font-semibold text-sm mb-3">4.15 API Standards & Conventions</h4>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground mb-2 font-medium">Request/Response Format</p>
                    <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                      <li>RESTful design with JSON payloads</li>
                      <li>JWT Bearer token authentication</li>
                      <li>Rate limiting: 1000 req/min per tenant</li>
                      <li>Cursor-based pagination</li>
                      <li>OpenAPI 3.0 specification</li>
                    </ul>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-2 font-medium">Error Response Format</p>
                    <div className="bg-muted/50 p-3 rounded font-mono text-xs">
                      <pre className="whitespace-pre-wrap text-muted-foreground">
{`{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Description",
    "details": [...],
    "requestId": "uuid"
  }
}`}
                      </pre>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Integration Specifications */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Cpu className="w-5 h-5 text-primary" />
                5. Integration Specifications
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-sm mb-2">5.1 External Integrations</h4>
                <div className="grid gap-3">
                  {[
                    { name: 'SSO/SAML', desc: 'Enterprise single sign-on integration', status: 'Supported' },
                    { name: 'LDAP/AD', desc: 'Active Directory user sync', status: 'Supported' },
                    { name: 'EHR Systems', desc: 'HL7 FHIR-based data exchange', status: 'Roadmap' },
                    { name: 'Email (SMTP)', desc: 'Notification and alert delivery', status: 'Required' },
                    { name: 'Document Storage', desc: 'S3-compatible object storage', status: 'Required' },
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between border rounded-lg p-3">
                      <div>
                        <p className="font-medium text-sm">{item.name}</p>
                        <p className="text-xs text-muted-foreground">{item.desc}</p>
                      </div>
                      <Badge variant={item.status === 'Required' ? 'default' : item.status === 'Supported' ? 'secondary' : 'outline'} className="text-xs">
                        {item.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Glossary */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-primary" />
                6. Technical Glossary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3">
                {[
                  { term: 'API Gateway', definition: 'Entry point for all client requests, handling authentication, rate limiting, and request routing.' },
                  { term: 'JWT', definition: 'JSON Web Token - Compact, URL-safe token format for securely transmitting claims between parties.' },
                  { term: 'RLS', definition: 'Row-Level Security - PostgreSQL feature enabling fine-grained access control at the database row level.' },
                  { term: 'Multi-tenant', definition: 'Architecture where a single instance serves multiple organizations with data isolation.' },
                  { term: 'Edge Function', definition: 'Serverless functions running at the network edge for low-latency processing.' },
                  { term: 'Microservice', definition: 'Independently deployable service handling a specific business capability.' },
                  { term: 'SPA', definition: 'Single Page Application - Web app loading a single HTML page and dynamically updating content.' },
                  { term: 'RBAC', definition: 'Role-Based Access Control - Access control model based on user roles and permissions.' },
                  { term: 'Idempotent', definition: 'Operation that produces the same result regardless of how many times it is executed.' },
                  { term: 'FHIR', definition: 'Fast Healthcare Interoperability Resources - Standard for healthcare data exchange.' },
                  { term: 'SAML', definition: 'Security Assertion Markup Language - XML-based standard for exchanging authentication data.' },
                  { term: 'TLS', definition: 'Transport Layer Security - Cryptographic protocol for secure network communication.' },
                ].map((item, idx) => (
                  <div key={idx} className="border-b last:border-b-0 pb-2 last:pb-0">
                    <div className="flex items-start gap-2">
                      <Badge variant="outline" className="text-xs font-mono shrink-0">{item.term}</Badge>
                      <p className="text-sm text-muted-foreground">{item.definition}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Deployment */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <FileCode className="w-5 h-5 text-primary" />
                7. Deployment Specifications
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-sm mb-2">7.1 Environment Configuration</h4>
                <div className="grid md:grid-cols-3 gap-4">
                  {[
                    { env: 'Development', replicas: 1, db: 'Shared', cdn: 'No' },
                    { env: 'Staging', replicas: 2, db: 'Dedicated', cdn: 'Yes' },
                    { env: 'Production', replicas: '3+', db: 'Dedicated HA', cdn: 'Yes' },
                  ].map((item, idx) => (
                    <div key={idx} className="bg-muted/50 p-3 rounded-lg">
                      <p className="font-semibold text-sm mb-2">{item.env}</p>
                      <div className="space-y-1 text-xs text-muted-foreground">
                        <p>Replicas: {item.replicas}</p>
                        <p>Database: {item.db}</p>
                        <p>CDN: {item.cdn}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-2">7.2 CI/CD Pipeline</h4>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  <li>Automated testing on pull requests</li>
                  <li>Staging deployment on merge to main</li>
                  <li>Production deployment with manual approval</li>
                  <li>Automated rollback on failure detection</li>
                  <li>Blue-green deployment strategy</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </ScrollArea>
    </div>
  );
};
