import React from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { usePdfDownload } from '@/hooks/usePdfDownload';
import { 
  UserCheck, 
  ClipboardList, 
  Shield, 
  Building2, 
  FileText,
  Users,
  Bell,
  Search,
  Download,
  Settings,
  CheckCircle2,
  Target
} from 'lucide-react';

interface UATScenario {
  id: string;
  persona: string;
  category: string;
  title: string;
  businessGoal: string;
  preconditions: string[];
  steps: string[];
  acceptanceCriteria: string[];
  priority: 'must-have' | 'should-have' | 'nice-to-have';
}

export const UATTestStep: React.FC = () => {
  const { data } = useOnboarding();
  const org = data.organization;
  const { contentRef, downloadPdf } = usePdfDownload();

  const handleDownload = () => {
    const orgName = org.name || 'Organization';
    const filename = `UAT_Test_Scenarios_${orgName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;
    downloadPdf({ filename, title: 'UAT Test Scenarios' });
  };

  const uatScenarios: UATScenario[] = [
    // Org Admin Scenarios
    {
      id: 'UAT-ADMIN-001',
      persona: 'Organization Administrator',
      category: 'System Setup',
      title: 'Complete Organization Onboarding',
      businessGoal: 'Set up the organization with all required configurations',
      preconditions: ['Admin account created', 'License activated'],
      steps: [
        'Log in as Organization Administrator',
        'Complete organization profile setup',
        'Configure facilities and departments',
        'Set up user roles and permissions',
        'Configure security settings',
        'Apply branding customizations',
        'Review and activate organization'
      ],
      acceptanceCriteria: [
        'All required fields are completed',
        'Facilities are properly configured',
        'Departments are assigned to facilities',
        'Roles reflect organizational structure',
        'Security policies match requirements',
        'Organization status shows as Active'
      ],
      priority: 'must-have'
    },
    {
      id: 'UAT-ADMIN-002',
      persona: 'Organization Administrator',
      category: 'User Management',
      title: 'Onboard New Staff Member',
      businessGoal: 'Add a new employee to the system with appropriate access',
      preconditions: ['Organization is active', 'Roles are configured'],
      steps: [
        'Navigate to User Management',
        'Click Add New User',
        'Enter employee details',
        'Assign appropriate role(s)',
        'Assign to department(s)',
        'Send invitation email',
        'Verify user receives invitation'
      ],
      acceptanceCriteria: [
        'User record created successfully',
        'Correct roles assigned',
        'Department assignment correct',
        'Invitation email sent',
        'User can complete registration',
        'User can log in with assigned permissions'
      ],
      priority: 'must-have'
    },
    // Compliance Head Scenarios
    {
      id: 'UAT-COMP-001',
      persona: 'Compliance Head',
      category: 'Compliance Monitoring',
      title: 'Review Organization Compliance Dashboard',
      businessGoal: 'Get a complete view of organizational compliance status',
      preconditions: ['Compliance data exists', 'User has Compliance Head role'],
      steps: [
        'Log in as Compliance Head',
        'Navigate to Master Compliance Dashboard',
        'Review overall compliance score',
        'Check compliance by facility',
        'Identify areas needing attention',
        'Drill down into specific issues',
        'Export compliance report'
      ],
      acceptanceCriteria: [
        'Dashboard displays current compliance score',
        'All facilities are represented',
        'Risk areas are clearly highlighted',
        'Drill-down shows detailed information',
        'Report exports in expected format',
        'Data is accurate and up-to-date'
      ],
      priority: 'must-have'
    },
    {
      id: 'UAT-COMP-002',
      persona: 'Compliance Head',
      category: 'Audit Management',
      title: 'Prepare for Regulatory Audit',
      businessGoal: 'Compile all required documentation for upcoming audit',
      preconditions: ['Compliance records exist', 'Audit is scheduled'],
      steps: [
        'Navigate to AuditPro module',
        'Create new audit preparation checklist',
        'Assign tasks to department heads',
        'Track completion status',
        'Review submitted documentation',
        'Generate audit readiness report',
        'Share report with stakeholders'
      ],
      acceptanceCriteria: [
        'Checklist covers all audit requirements',
        'Tasks are assigned with due dates',
        'Progress is visible in real-time',
        'Documents can be reviewed and approved',
        'Report shows readiness status',
        'Stakeholders can access shared report'
      ],
      priority: 'must-have'
    },
    // Department Head Scenarios
    {
      id: 'UAT-DEPT-001',
      persona: 'Department Head',
      category: 'Department Management',
      title: 'Manage Department Compliance Tasks',
      businessGoal: 'Ensure department meets all compliance requirements',
      preconditions: ['Tasks assigned to department', 'User has Department Head role'],
      steps: [
        'Log in as Department Head',
        'View department dashboard',
        'Review pending compliance tasks',
        'Assign tasks to staff members',
        'Monitor task completion',
        'Review and approve completed tasks',
        'Escalate overdue items'
      ],
      acceptanceCriteria: [
        'Only department tasks are visible',
        'Tasks can be assigned to team members',
        'Progress updates reflect immediately',
        'Approval workflow functions correctly',
        'Escalation notifies appropriate parties',
        'Department metrics update accordingly'
      ],
      priority: 'must-have'
    },
    {
      id: 'UAT-DEPT-002',
      persona: 'Department Head',
      category: 'Reporting',
      title: 'Generate Department Performance Report',
      businessGoal: 'Create monthly compliance performance report for department',
      preconditions: ['Month of data exists', 'Report templates configured'],
      steps: [
        'Navigate to Reports section',
        'Select Department Performance Report',
        'Set date range for previous month',
        'Select metrics to include',
        'Generate report preview',
        'Export report as PDF',
        'Share with relevant stakeholders'
      ],
      acceptanceCriteria: [
        'Date range filters work correctly',
        'Metrics accurately reflect department data',
        'Report layout is professional',
        'PDF export is properly formatted',
        'Charts and graphs render correctly',
        'Sharing permissions are respected'
      ],
      priority: 'should-have'
    },
    // Staff Scenarios
    {
      id: 'UAT-STAFF-001',
      persona: 'Staff Member',
      category: 'Daily Operations',
      title: 'Complete Assigned Compliance Task',
      businessGoal: 'Complete daily compliance checklist items',
      preconditions: ['Tasks assigned to user', 'User has Staff role'],
      steps: [
        'Log in as Staff member',
        'View personal task dashboard',
        'Select task to complete',
        'Review task requirements',
        'Complete required actions',
        'Attach supporting evidence if required',
        'Submit task for review'
      ],
      acceptanceCriteria: [
        'Only personal tasks are visible',
        'Task instructions are clear',
        'File attachments upload successfully',
        'Task status updates to Submitted',
        'Notification sent to supervisor',
        'Task appears in completed list'
      ],
      priority: 'must-have'
    },
    {
      id: 'UAT-STAFF-002',
      persona: 'Staff Member',
      category: 'Feedback',
      title: 'Submit Compliance Concern',
      businessGoal: 'Report a potential compliance issue',
      preconditions: ['FeedbackHub is enabled', 'User has Staff role'],
      steps: [
        'Navigate to FeedbackHub',
        'Click Submit New Feedback',
        'Select concern category',
        'Describe the issue',
        'Add supporting details or photos',
        'Choose anonymous or attributed',
        'Submit feedback'
      ],
      acceptanceCriteria: [
        'Feedback form is easy to understand',
        'Categories are relevant',
        'File uploads work correctly',
        'Anonymous option truly anonymizes',
        'Confirmation message displayed',
        'Feedback routed to appropriate team'
      ],
      priority: 'should-have'
    },
    // Cross-functional Scenarios
    {
      id: 'UAT-CROSS-001',
      persona: 'All Users',
      category: 'Search & Navigation',
      title: 'Find Specific Compliance Document',
      businessGoal: 'Quickly locate a specific policy or procedure document',
      preconditions: ['Documents exist in system', 'User has appropriate access'],
      steps: [
        'Use global search feature',
        'Enter document name or keywords',
        'Review search results',
        'Apply filters if needed',
        'Open desired document',
        'Verify document is correct'
      ],
      acceptanceCriteria: [
        'Search returns relevant results',
        'Results load within 2 seconds',
        'Filters narrow results appropriately',
        'Document opens without error',
        'User can only see authorized documents',
        'Search history is maintained'
      ],
      priority: 'should-have'
    },
    {
      id: 'UAT-CROSS-002',
      persona: 'All Users',
      category: 'Notifications',
      title: 'Receive and Act on Notification',
      businessGoal: 'Stay informed of important compliance deadlines',
      preconditions: ['Notifications are configured', 'User has notification preferences set'],
      steps: [
        'Receive notification (email or in-app)',
        'Read notification content',
        'Click action link in notification',
        'Complete required action',
        'Notification marked as read',
        'Check notification history'
      ],
      acceptanceCriteria: [
        'Notification delivered promptly',
        'Content is clear and actionable',
        'Links navigate to correct location',
        'Action can be completed from context',
        'Read status syncs across devices',
        'History shows all past notifications'
      ],
      priority: 'should-have'
    },
    // Mobile/Accessibility Scenarios
    {
      id: 'UAT-MOB-001',
      persona: 'All Users',
      category: 'Mobile Access',
      title: 'Complete Task on Mobile Device',
      businessGoal: 'Use the application on mobile while in the field',
      preconditions: ['Mobile-responsive app', 'User logged in on mobile'],
      steps: [
        'Open application on mobile browser',
        'Navigate to task list',
        'View task details',
        'Complete task steps',
        'Upload photo from device',
        'Submit completed task'
      ],
      acceptanceCriteria: [
        'Application is responsive on mobile',
        'Navigation is touch-friendly',
        'Forms are usable on small screens',
        'Camera integration works for uploads',
        'Task submits successfully',
        'Data syncs with desktop view'
      ],
      priority: 'should-have'
    },
  ];

  const groupedScenarios = uatScenarios.reduce((acc, scenario) => {
    if (!acc[scenario.persona]) {
      acc[scenario.persona] = [];
    }
    acc[scenario.persona].push(scenario);
    return acc;
  }, {} as Record<string, UATScenario[]>);

  const getPersonaIcon = (persona: string) => {
    switch (persona) {
      case 'Organization Administrator': return <Settings className="w-4 h-4" />;
      case 'Compliance Head': return <Shield className="w-4 h-4" />;
      case 'Department Head': return <Building2 className="w-4 h-4" />;
      case 'Staff Member': return <Users className="w-4 h-4" />;
      case 'All Users': return <UserCheck className="w-4 h-4" />;
      default: return <UserCheck className="w-4 h-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'must-have': return 'destructive';
      case 'should-have': return 'default';
      case 'nice-to-have': return 'secondary';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-heading font-bold text-foreground flex items-center gap-2">
            <UserCheck className="w-6 h-6 text-primary" />
            UAT Test Scenarios
          </h2>
          <p className="text-muted-foreground mt-1">
            User acceptance test scenarios for {org.name || 'your organization'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleDownload} className="gap-2">
            <Download className="w-4 h-4" />
            Download PDF
          </Button>
          <Badge variant="outline" className="text-xs">
            {uatScenarios.length} Scenarios
          </Badge>
          <Badge variant="outline" className="text-xs">
            Auto-Generated
          </Badge>
        </div>
      </div>

      {/* Summary Cards */}
      <div ref={contentRef}>
        <div className="grid grid-cols-3 gap-4 mb-6">
        <Card className="bg-red-500/10 border-red-500/20">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-red-600">{uatScenarios.filter(s => s.priority === 'must-have').length}</p>
            <p className="text-xs text-muted-foreground">Must Have</p>
          </CardContent>
        </Card>
        <Card className="bg-blue-500/10 border-blue-500/20">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-blue-600">{uatScenarios.filter(s => s.priority === 'should-have').length}</p>
            <p className="text-xs text-muted-foreground">Should Have</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-500/10 border-gray-500/20">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-gray-600">{uatScenarios.filter(s => s.priority === 'nice-to-have').length}</p>
            <p className="text-xs text-muted-foreground">Nice to Have</p>
          </CardContent>
        </Card>
      </div>

      {/* Persona Legend */}
      <div className="flex flex-wrap gap-2">
        {Object.keys(groupedScenarios).map(persona => (
          <Badge key={persona} variant="outline" className="text-xs flex items-center gap-1">
            {getPersonaIcon(persona)}
            {persona}: {groupedScenarios[persona].length}
          </Badge>
        ))}
      </div>

      <ScrollArea className="h-[calc(100vh-480px)]">
        <div className="space-y-6 pr-4">
          {Object.entries(groupedScenarios).map(([persona, scenarios]) => (
            <Card key={persona}>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  {getPersonaIcon(persona)}
                  {persona}
                  <Badge variant="secondary" className="ml-2 text-xs">{scenarios.length} scenarios</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {scenarios.map((scenario) => (
                  <div key={scenario.id} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <Checkbox id={scenario.id} />
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <code className="text-xs text-muted-foreground">{scenario.id}</code>
                            <Badge variant="outline" className="text-xs">{scenario.category}</Badge>
                            <span className="font-medium text-sm">{scenario.title}</span>
                          </div>
                        </div>
                      </div>
                      <Badge variant={getPriorityColor(scenario.priority) as any} className="text-xs capitalize shrink-0">
                        {scenario.priority.replace('-', ' ')}
                      </Badge>
                    </div>
                    
                    <div className="ml-7 space-y-4">
                      {/* Business Goal */}
                      <div className="flex items-start gap-2 bg-primary/5 p-2 rounded">
                        <Target className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                        <div>
                          <p className="text-xs font-medium">Business Goal:</p>
                          <p className="text-xs text-muted-foreground">{scenario.businessGoal}</p>
                        </div>
                      </div>

                      {/* Preconditions */}
                      <div>
                        <p className="text-xs font-medium text-muted-foreground mb-1">Preconditions:</p>
                        <ul className="text-xs text-muted-foreground space-y-0.5 list-disc list-inside">
                          {scenario.preconditions.map((pre, idx) => (
                            <li key={idx}>{pre}</li>
                          ))}
                        </ul>
                      </div>

                      {/* Test Steps */}
                      <div>
                        <p className="text-xs font-medium text-muted-foreground mb-1">Test Steps:</p>
                        <ol className="text-xs text-muted-foreground space-y-1 list-decimal list-inside">
                          {scenario.steps.map((step, idx) => (
                            <li key={idx}>{step}</li>
                          ))}
                        </ol>
                      </div>

                      {/* Acceptance Criteria */}
                      <div className="bg-green-500/10 p-3 rounded">
                        <div className="flex items-center gap-2 mb-2">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <p className="text-xs font-medium text-green-700">Acceptance Criteria:</p>
                        </div>
                        <ul className="text-xs text-green-600 space-y-1">
                          {scenario.acceptanceCriteria.map((criteria, idx) => (
                            <li key={idx} className="flex items-start gap-2">
                              <CheckCircle2 className="w-3 h-3 shrink-0 mt-0.5" />
                              {criteria}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>
      </ScrollArea>
      </div>
    </div>
  );
};
