import React, { useState, useMemo } from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { 
  Lock, Unlock, Search, Download, Check, ChevronRight, ChevronUp, ChevronDown,
  Globe, LayoutDashboard, FileCheck, FileWarning, Target, Shield,
  AlertTriangle, ClipboardCheck, MessageSquare, FileText, Plus, Pencil, Trash2, Star,
  HelpCircle, Info, Building2, User
} from 'lucide-react';
import { 
  LOV_PACKS, 
  LOV_GROUPS, 
  DEFAULT_LOV_VALUE_SETS,
  LOVValueSet,
  LOVValueItem,
  getGroupCounts
} from '@/data/lovValueSets';
import { useToast } from '@/hooks/use-toast';

// Tooltip wrapper component for cleaner code
const ActionTooltip: React.FC<{ children: React.ReactNode; label: string }> = ({ children, label }) => (
  <Tooltip>
    <TooltipTrigger asChild>{children}</TooltipTrigger>
    <TooltipContent side="top" className="text-xs">{label}</TooltipContent>
  </Tooltip>
);

const GROUP_ICONS: Record<string, React.ElementType> = {
  shared: Globe,
  compliance_dashboard: LayoutDashboard,
  dept_dashboard: Building2,
  user_dashboard: User,
  compliance_connect: FileCheck,
  citations: FileWarning,
  capa: Target,
  enforce_point: Shield,
  risk_guard: AlertTriangle,
  audit_pro: ClipboardCheck,
  feedback_hub: MessageSquare,
  documents: FileText,
};

type LOVStatus = 'draft' | 'published';
type DialogMode = 'add' | 'edit' | null;

export const LOVStep: React.FC = () => {
  const { markStepComplete, nextStep } = useOnboarding();
  const { toast } = useToast();

  // State
  const [selectedPack, setSelectedPack] = useState('provider_recommended');
  const [applyDefaults, setApplyDefaults] = useState(true);
  const [status, setStatus] = useState<LOVStatus>('draft');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGroupId, setSelectedGroupId] = useState<string>('shared');
  const [selectedSetId, setSelectedSetId] = useState<string | null>(null);
  const [valueSets, setValueSets] = useState<LOVValueSet[]>(DEFAULT_LOV_VALUE_SETS);
  
  // CRUD Dialog state
  const [dialogMode, setDialogMode] = useState<DialogMode>(null);
  const [editingValue, setEditingValue] = useState<LOVValueItem | null>(null);
  const [formLabel, setFormLabel] = useState('');
  const [formCode, setFormCode] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formIsDefault, setFormIsDefault] = useState(false);
  
  // Delete confirmation
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [valueToDelete, setValueToDelete] = useState<LOVValueItem | null>(null);

  // Filters
  const [filterAppliesTo, setFilterAppliesTo] = useState<string>('all');
  const [filterLocked, setFilterLocked] = useState<string>('all');

  const groupCounts = useMemo(() => getGroupCounts(), []);

  // Filter value sets
  const filteredSets = useMemo(() => {
    return valueSets.filter(set => {
      if (set.groupId !== selectedGroupId) return false;
      if (searchQuery && !set.setName.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      if (filterAppliesTo !== 'all' && set.appliesTo !== filterAppliesTo) return false;
      if (filterLocked === 'locked' && !set.isLocked) return false;
      if (filterLocked === 'editable' && set.isLocked) return false;
      return true;
    });
  }, [valueSets, selectedGroupId, searchQuery, filterAppliesTo, filterLocked]);

  const selectedSet = useMemo(() => 
    valueSets.find(s => s.id === selectedSetId), 
    [valueSets, selectedSetId]
  );

  // Reset form
  const resetForm = () => {
    setFormLabel('');
    setFormCode('');
    setFormDescription('');
    setFormIsDefault(false);
    setEditingValue(null);
  };

  // Open Add dialog
  const handleOpenAdd = () => {
    resetForm();
    setDialogMode('add');
  };

  // Open Edit dialog
  const handleOpenEdit = (value: LOVValueItem) => {
    setEditingValue(value);
    setFormLabel(value.label);
    setFormCode(value.code);
    setFormDescription(value.description || '');
    setFormIsDefault(value.isDefault || false);
    setDialogMode('edit');
  };

  // Create new value
  const handleCreate = () => {
    if (!selectedSetId || !formLabel.trim() || !formCode.trim()) return;
    const code = formCode.toUpperCase().replace(/\s+/g, '_');
    
    const set = valueSets.find(s => s.id === selectedSetId);
    if (set?.values.some(v => v.code === code)) {
      toast({ title: 'Duplicate code', description: 'A value with this code already exists.', variant: 'destructive' });
      return;
    }

    setValueSets(prev => prev.map(s => {
      if (s.id !== selectedSetId) return s;
      
      // If setting as default, remove default from others
      let updatedValues = s.values;
      if (formIsDefault) {
        updatedValues = s.values.map(v => ({ ...v, isDefault: false }));
      }
      
      return {
        ...s,
        values: [...updatedValues, {
          id: `custom-${Date.now()}`,
          code,
          label: formLabel.trim(),
          description: formDescription.trim() || undefined,
          sortOrder: s.values.length,
          isActive: true,
          isDefault: formIsDefault,
        }]
      };
    }));
    
    toast({ title: 'Value added', description: `"${formLabel}" has been added to the value set.` });
    setDialogMode(null);
    resetForm();
  };

  // Update existing value
  const handleUpdate = () => {
    if (!selectedSetId || !editingValue || !formLabel.trim() || !formCode.trim()) return;
    const code = formCode.toUpperCase().replace(/\s+/g, '_');
    
    const set = valueSets.find(s => s.id === selectedSetId);
    if (set?.values.some(v => v.code === code && v.id !== editingValue.id)) {
      toast({ title: 'Duplicate code', description: 'A value with this code already exists.', variant: 'destructive' });
      return;
    }

    setValueSets(prev => prev.map(s => {
      if (s.id !== selectedSetId) return s;
      
      return {
        ...s,
        values: s.values.map(v => {
          // If setting new default, remove from others
          if (formIsDefault && v.id !== editingValue.id) {
            return { ...v, isDefault: false };
          }
          if (v.id === editingValue.id) {
            return {
              ...v,
              code,
              label: formLabel.trim(),
              description: formDescription.trim() || undefined,
              isDefault: formIsDefault,
            };
          }
          return v;
        })
      };
    }));
    
    toast({ title: 'Value updated', description: `"${formLabel}" has been updated.` });
    setDialogMode(null);
    resetForm();
  };

  // Toggle active status (soft delete)
  const handleToggleActive = (value: LOVValueItem) => {
    if (!selectedSetId) return;
    
    if (value.isSystemRequired && value.isActive) {
      toast({ title: 'Cannot deactivate', description: 'This value is required by the system.', variant: 'destructive' });
      return;
    }

    setValueSets(prev => prev.map(set => {
      if (set.id !== selectedSetId) return set;
      return {
        ...set,
        values: set.values.map(v => v.id === value.id ? { ...v, isActive: !v.isActive } : v)
      };
    }));
    
    toast({ 
      title: value.isActive ? 'Value deactivated' : 'Value reactivated', 
      description: `"${value.label}" has been ${value.isActive ? 'deactivated' : 'reactivated'}.` 
    });
  };

  // Confirm delete (for custom values only)
  const handleConfirmDelete = (value: LOVValueItem) => {
    if (value.isSystemRequired) {
      toast({ title: 'Cannot delete', description: 'System values can only be deactivated.', variant: 'destructive' });
      return;
    }
    setValueToDelete(value);
    setDeleteConfirmOpen(true);
  };

  // Execute delete
  const handleDelete = () => {
    if (!selectedSetId || !valueToDelete) return;
    
    setValueSets(prev => prev.map(s => {
      if (s.id !== selectedSetId) return s;
      return {
        ...s,
        values: s.values.filter(v => v.id !== valueToDelete.id)
      };
    }));
    
    toast({ title: 'Value deleted', description: `"${valueToDelete.label}" has been permanently removed.` });
    setDeleteConfirmOpen(false);
    setValueToDelete(null);
  };

  // Reorder - Move Up
  const handleMoveUp = (value: LOVValueItem) => {
    if (!selectedSetId) return;
    
    setValueSets(prev => prev.map(s => {
      if (s.id !== selectedSetId) return s;
      const idx = s.values.findIndex(v => v.id === value.id);
      if (idx <= 0) return s;
      
      const newValues = [...s.values];
      [newValues[idx - 1], newValues[idx]] = [newValues[idx], newValues[idx - 1]];
      return { ...s, values: newValues.map((v, i) => ({ ...v, sortOrder: i })) };
    }));
  };

  // Reorder - Move Down
  const handleMoveDown = (value: LOVValueItem) => {
    if (!selectedSetId) return;
    
    setValueSets(prev => prev.map(s => {
      if (s.id !== selectedSetId) return s;
      const idx = s.values.findIndex(v => v.id === value.id);
      if (idx < 0 || idx >= s.values.length - 1) return s;
      
      const newValues = [...s.values];
      [newValues[idx], newValues[idx + 1]] = [newValues[idx + 1], newValues[idx]];
      return { ...s, values: newValues.map((v, i) => ({ ...v, sortOrder: i })) };
    }));
  };

  // Set as default
  const handleSetDefault = (value: LOVValueItem) => {
    if (!selectedSetId) return;
    
    setValueSets(prev => prev.map(s => {
      if (s.id !== selectedSetId) return s;
      return {
        ...s,
        values: s.values.map(v => ({ ...v, isDefault: v.id === value.id }))
      };
    }));
    
    toast({ title: 'Default updated', description: `"${value.label}" is now the default value.` });
  };

  const handleExportCSV = () => {
    const rows = [['Group', 'Set Name', 'Set Code', 'Value Code', 'Value Label', 'Description', 'Active', 'Default', 'System Required']];
    valueSets.forEach(set => {
      const group = LOV_GROUPS.find(g => g.id === set.groupId);
      set.values.forEach(val => {
        rows.push([
          group?.name || set.groupId,
          set.setName,
          set.setCode,
          val.code,
          val.label,
          val.description || '',
          val.isActive ? 'Yes' : 'No',
          val.isDefault ? 'Yes' : 'No',
          val.isSystemRequired ? 'Yes' : 'No',
        ]);
      });
    });
    const csv = rows.map(r => r.map(c => `"${c}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'lov_configuration.csv';
    a.click();
  };

  const handlePublish = () => {
    setStatus('published');
    toast({
      title: 'LOVs Published',
      description: 'Onboarding LOV Baseline v1 has been created.',
    });
  };

  const handleContinue = () => {
    if (status === 'draft') {
      toast({
        title: 'Publish Required',
        description: 'Please publish your LOV configuration before continuing.',
        variant: 'destructive',
      });
      return;
    }
    markStepComplete(9);
    nextStep();
  };

  return (
    <TooltipProvider delayDuration={200}>
      <div className="space-y-6">
        {/* Step Description */}
        <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-sm mb-1">Configure Value Sets (LOVs)</h3>
              <p className="text-sm text-muted-foreground">
                Value sets define the dropdown options used throughout MedComply. Choose a configuration pack to start with recommended defaults, 
                then customize individual values as needed. Changes are saved as a draft until you publish.
              </p>
            </div>
          </div>
        </div>

        {/* Header Controls */}
        <div className="flex flex-wrap items-center gap-4 p-4 bg-muted/30 rounded-lg border border-border">
          <div className="flex-1 min-w-[200px]">
            <div className="flex items-center gap-1 mb-1">
              <Label className="text-xs text-muted-foreground">Configuration Pack</Label>
              <Tooltip>
                <TooltipTrigger asChild>
                  <HelpCircle className="w-3 h-3 text-muted-foreground cursor-help" />
                </TooltipTrigger>
                <TooltipContent side="top" className="max-w-[250px]">
                  <p className="text-xs">Packs provide pre-configured value sets. Choose based on your organization type and compliance needs.</p>
                </TooltipContent>
              </Tooltip>
            </div>
            <Select value={selectedPack} onValueChange={setSelectedPack}>
              <SelectTrigger className="bg-background">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover z-50">
                {LOV_PACKS.map(pack => (
                  <SelectItem key={pack.id} value={pack.id}>
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        {pack.name}
                        {pack.isDefault && <Badge variant="secondary" className="text-xs">Default</Badge>}
                      </div>
                      <span className="text-xs text-muted-foreground">{pack.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2">
            <Switch id="apply-defaults" checked={applyDefaults} onCheckedChange={setApplyDefaults} />
            <Label htmlFor="apply-defaults" className="text-sm">Apply recommended defaults</Label>
            <Tooltip>
              <TooltipTrigger asChild>
                <HelpCircle className="w-3 h-3 text-muted-foreground cursor-help" />
              </TooltipTrigger>
              <TooltipContent side="top" className="max-w-[200px]">
                <p className="text-xs">When enabled, values are pre-populated based on your organization type and selected pack.</p>
              </TooltipContent>
            </Tooltip>
          </div>
          <Tooltip>
            <TooltipTrigger asChild>
              <Badge variant={status === 'draft' ? 'outline' : 'default'} className="ml-auto cursor-help">
                {status === 'draft' ? 'Draft' : 'Published'}
              </Badge>
            </TooltipTrigger>
            <TooltipContent side="left">
              <p className="text-xs">{status === 'draft' ? 'Changes will be saved but not applied until published' : 'LOV Baseline v1 is active'}</p>
            </TooltipContent>
          </Tooltip>
        </div>

      {/* Main Layout */}
      <div className="grid grid-cols-12 gap-4 min-h-[500px]">
        {/* Left Panel - Group Navigation */}
        <div className="col-span-3 border border-border rounded-lg bg-card">
          <div className="p-3 border-b border-border">
            <div className="flex items-center gap-1">
              <h3 className="font-semibold text-sm">Value Set Groups</h3>
              <Tooltip>
                <TooltipTrigger asChild>
                  <HelpCircle className="w-3 h-3 text-muted-foreground cursor-help" />
                </TooltipTrigger>
                <TooltipContent side="right" className="max-w-[200px]">
                  <p className="text-xs">Groups organize value sets by module. Select a group to see its value sets.</p>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>
          <ScrollArea className="h-[450px]">
            <div className="p-2 space-y-1">
              {LOV_GROUPS.map(group => {
                const Icon = GROUP_ICONS[group.id] || Globe;
                const isSelected = selectedGroupId === group.id;
                return (
                  <Tooltip key={group.id}>
                    <TooltipTrigger asChild>
                      <button
                        onClick={() => { setSelectedGroupId(group.id); setSelectedSetId(null); }}
                        className={`w-full flex items-center gap-2 px-3 py-2 rounded-md text-left text-sm transition-colors ${
                          isSelected ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
                        }`}
                      >
                        <Icon className="w-4 h-4 flex-shrink-0" />
                        <span className="flex-1 truncate">{group.name}</span>
                        <Badge variant={isSelected ? 'secondary' : 'outline'} className="text-xs">
                          {groupCounts[group.id] || 0}
                        </Badge>
                      </button>
                    </TooltipTrigger>
                    <TooltipContent side="right" className="max-w-[200px]">
                      <p className="text-xs font-medium">{group.name}</p>
                      <p className="text-xs text-muted-foreground">{group.description}</p>
                    </TooltipContent>
                  </Tooltip>
                );
              })}
            </div>
          </ScrollArea>
        </div>

        {/* Center Panel - Value Sets List */}
        <div className="col-span-4 border border-border rounded-lg bg-card flex flex-col">
          <div className="p-3 border-b border-border space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search value sets..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              <Select value={filterAppliesTo} onValueChange={setFilterAppliesTo}>
                <SelectTrigger className="w-[130px] h-8 text-xs bg-background">
                  <SelectValue placeholder="Applies to" />
                </SelectTrigger>
                <SelectContent className="bg-popover z-50">
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="shared">Shared</SelectItem>
                  <SelectItem value="dashboard">Dashboard</SelectItem>
                  <SelectItem value="microapp">Microapp</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterLocked} onValueChange={setFilterLocked}>
                <SelectTrigger className="w-[120px] h-8 text-xs bg-background">
                  <SelectValue placeholder="Lock status" />
                </SelectTrigger>
                <SelectContent className="bg-popover z-50">
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="locked">Locked</SelectItem>
                  <SelectItem value="editable">Editable</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <ScrollArea className="flex-1">
            <div className="p-2 space-y-1">
              {filteredSets.map(set => (
                <button
                  key={set.id}
                  onClick={() => setSelectedSetId(set.id)}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded-md text-left text-sm transition-colors ${
                    selectedSetId === set.id ? 'bg-accent' : 'hover:bg-muted'
                  }`}
                >
                  {set.isLocked ? <Lock className="w-3.5 h-3.5 text-muted-foreground" /> : <Unlock className="w-3.5 h-3.5 text-muted-foreground" />}
                  <span className="flex-1 truncate">{set.setName}</span>
                  <Badge variant="outline" className="text-xs">{set.values.filter(v => v.isActive).length}</Badge>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </button>
              ))}
              {filteredSets.length === 0 && (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  No value sets match your filters
                </div>
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Right Panel - Values Editor */}
        <div className="col-span-5 border border-border rounded-lg bg-card flex flex-col">
          {selectedSet ? (
            <>
              <div className="p-3 border-b border-border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {selectedSet.isLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                    <h3 className="font-semibold text-sm">{selectedSet.setName}</h3>
                  </div>
                  {selectedSet.isEditable && (
                    <Button size="sm" variant="outline" onClick={handleOpenAdd}>
                      <Plus className="w-3 h-3 mr-1" /> Add
                    </Button>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-1">{selectedSet.description}</p>
                <div className="flex gap-1 mt-2 flex-wrap">
                  <Badge variant="secondary" className="text-xs">{selectedSet.appliesTo}</Badge>
                  {selectedSet.microappTags.slice(0, 3).map(tag => (
                    <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                  ))}
                  {selectedSet.microappTags.length > 3 && (
                    <Badge variant="outline" className="text-xs">+{selectedSet.microappTags.length - 3}</Badge>
                  )}
                </div>
              </div>
              
              <ScrollArea className="flex-1">
                <div className="divide-y divide-border">
                  {selectedSet.values.map((val, idx) => (
                    <div
                      key={val.id}
                      className={`flex items-center gap-2 px-3 py-2 group ${
                        !val.isActive ? 'opacity-50 bg-muted/30' : ''
                      }`}
                    >
                      {/* Reorder buttons */}
                      <div className="flex flex-col">
                        <button 
                          onClick={() => handleMoveUp(val)} 
                          disabled={idx === 0}
                          className="p-0.5 hover:bg-muted rounded disabled:opacity-30"
                        >
                          <ChevronUp className="w-3 h-3" />
                        </button>
                        <button 
                          onClick={() => handleMoveDown(val)} 
                          disabled={idx === selectedSet.values.length - 1}
                          className="p-0.5 hover:bg-muted rounded disabled:opacity-30"
                        >
                          <ChevronDown className="w-3 h-3" />
                        </button>
                      </div>
                      
                      {/* Value info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium truncate">{val.label}</span>
                          {val.isDefault && (
                            <Badge variant="default" className="text-xs h-4 px-1">Default</Badge>
                          )}
                          {val.isSystemRequired && (
                            <Lock className="w-3 h-3 text-muted-foreground" />
                          )}
                          {!val.isActive && (
                            <Badge variant="outline" className="text-xs h-4 px-1 text-destructive border-destructive">Inactive</Badge>
                          )}
                        </div>
                        <span className="text-xs text-muted-foreground font-mono">{val.code}</span>
                      </div>
                      
                      {/* Actions - always visible */}
                      <div className="flex items-center gap-0.5">
                        {!val.isDefault && val.isActive && (
                          <ActionTooltip label="Set as default value for this dropdown">
                            <button 
                              onClick={() => handleSetDefault(val)}
                              className="p-1.5 hover:bg-muted rounded text-muted-foreground hover:text-foreground"
                            >
                              <Star className="w-3.5 h-3.5" />
                            </button>
                          </ActionTooltip>
                        )}
                        {selectedSet.isEditable && (
                          <ActionTooltip label="Edit label, code, and description">
                            <button 
                              onClick={() => handleOpenEdit(val)}
                              className="p-1.5 hover:bg-muted rounded text-muted-foreground hover:text-foreground"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                          </ActionTooltip>
                        )}
                        {selectedSet.isEditable && (
                          <ActionTooltip label={val.isActive ? 'Deactivate - hide from dropdowns but keep in history' : 'Reactivate - show in dropdowns again'}>
                            <button 
                              onClick={() => handleToggleActive(val)}
                              className="p-1.5 hover:bg-muted rounded text-muted-foreground hover:text-foreground disabled:opacity-30"
                              disabled={val.isSystemRequired && val.isActive}
                            >
                              {val.isActive ? (
                                <Unlock className="w-3.5 h-3.5" />
                              ) : (
                                <Lock className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </ActionTooltip>
                        )}
                        {selectedSet.isEditable && !val.isSystemRequired && (
                          <ActionTooltip label="Permanently delete this value">
                            <button 
                              onClick={() => handleConfirmDelete(val)}
                              className="p-1.5 hover:bg-destructive/10 rounded text-destructive/70 hover:text-destructive"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </ActionTooltip>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
              
              <div className="p-3 border-t border-border bg-muted/30">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{selectedSet.values.filter(v => v.isActive).length} active / {selectedSet.values.length} total</span>
                  <span>{selectedSet.isLocked ? 'System locked' : 'Editable'}</span>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground text-sm p-4 text-center">
              <div>
                <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
                Select a value set to view and edit its values
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between pt-4 border-t border-border">
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="outline" onClick={handleExportCSV}>
              <Download className="w-4 h-4 mr-2" /> Export CSV
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs">Download all value sets as a CSV file for review or backup</p>
          </TooltipContent>
        </Tooltip>
        <div className="flex gap-2">
          {status === 'draft' && (
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="secondary" onClick={handlePublish}>
                  <Check className="w-4 h-4 mr-2" /> Publish LOVs
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">Create the Onboarding LOV Baseline v1 and make changes active</p>
              </TooltipContent>
            </Tooltip>
          )}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button onClick={handleContinue}>
                Continue
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs">{status === 'draft' ? 'Publish required before continuing' : 'Proceed to next step'}</p>
            </TooltipContent>
          </Tooltip>
        </div>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogMode !== null} onOpenChange={(open) => !open && setDialogMode(null)}>
        <DialogContent className="bg-background">
          <DialogHeader>
            <DialogTitle>{dialogMode === 'add' ? 'Add New Value' : 'Edit Value'}</DialogTitle>
            <DialogDescription>
              {dialogMode === 'add' 
                ? 'Add a new value to this value set.' 
                : 'Update the value details below.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="label">Label *</Label>
              <Input 
                id="label"
                value={formLabel} 
                onChange={e => setFormLabel(e.target.value)} 
                placeholder="Display label" 
              />
            </div>
            <div>
              <Label htmlFor="code">Code *</Label>
              <Input 
                id="code"
                value={formCode} 
                onChange={e => setFormCode(e.target.value)} 
                placeholder="UNIQUE_CODE"
                className="font-mono"
              />
              <p className="text-xs text-muted-foreground mt-1">Uppercase, underscores only. Must be unique.</p>
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea 
                id="description"
                value={formDescription} 
                onChange={e => setFormDescription(e.target.value)} 
                placeholder="Optional description..."
                rows={2}
              />
            </div>
            <div className="flex items-center gap-2">
              <Switch 
                id="isDefault" 
                checked={formIsDefault} 
                onCheckedChange={setFormIsDefault} 
              />
              <Label htmlFor="isDefault">Set as default value</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogMode(null)}>Cancel</Button>
            <Button 
              onClick={dialogMode === 'add' ? handleCreate : handleUpdate} 
              disabled={!formLabel.trim() || !formCode.trim()}
            >
              {dialogMode === 'add' ? 'Add Value' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <DialogContent className="bg-background">
          <DialogHeader>
            <DialogTitle>Delete Value</DialogTitle>
            <DialogDescription>
              Are you sure you want to permanently delete "{valueToDelete?.label}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteConfirmOpen(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDelete}>
              <Trash2 className="w-4 h-4 mr-2" /> Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      </div>
    </TooltipProvider>
  );
};
