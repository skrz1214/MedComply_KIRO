import React, { useState, useMemo, useEffect } from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  LayoutDashboard,
  Shield,
  ClipboardCheck,
  MessageSquare,
  Gavel,
  AlertTriangle,
  FileCheck,
  FileWarning,
  FileText,
  Info,
  RotateCcw,
  ChevronDown,
  ChevronUp,
  Download,
  Eye,
  Users,
  Building,
  Crown,
  User,
  HelpCircle,
} from 'lucide-react';
import {
  ENTITLEMENT_APPS,
  ROLE_TYPE_MAX_SCOPE,
  AccessLevel,
  DataScope,
  AppAccessEntitlements,
  Role,
  RoleType,
} from '@/types/onboarding';
import { 
  APP_ACCESS_PRESETS, 
  PresetId, 
  applyPresetToRoles,
  createEmptyRoleEntitlements,
} from '@/data/appAccessPresets';

const APP_ICONS: Record<string, React.ElementType> = {
  master_dashboard: LayoutDashboard,
  department_dashboard: Building,
  individual_dashboard: User,
  compliance_connect: Shield,
  audit_pro: ClipboardCheck,
  feedback_hub: MessageSquare,
  enforce_point: Gavel,
  risk_guard: AlertTriangle,
  capa: FileCheck,
  citations: FileWarning,
  documents: FileText,
};

const ROLE_ICONS: Record<RoleType, React.ElementType> = {
  staff: Users,
  department_head: Building,
  compliance_head: Shield,
  org_admin: Crown,
};

const SCOPE_LABELS: Record<DataScope, string> = {
  self: 'Self',
  department: 'Dept',
  org: 'Org',
};

// Tooltip content for various elements
const TOOLTIPS = {
  accessLevel: {
    none: 'No access to this app/dashboard',
    view: 'Can view data but cannot make changes',
    manage: 'Can create, edit, and manage records within their allowed scope',
  },
  scope: {
    self: 'Can only see their own records and data',
    department: 'Can see all records within their assigned department(s)',
    org: 'Can see all records across the entire organization',
  },
  maxScope: 'Maximum data visibility allowed for this role type. Users cannot exceed this scope.',
  preset: {
    recommended: 'Balanced access for most organizations. Staff can view & submit, managers see their department, leadership sees everything.',
    strict: 'Minimal access by default. Staff can only submit, limited visibility. Best for highly regulated environments.',
    operational: 'Wider access for staff. Allows more self-service and visibility. Good for smaller, collaborative teams.',
  },
  dashboardExport: 'Allow this role to export dashboard data as CSV files',
  crossAppKpis: 'Allow this role to see aggregated KPIs that combine data from multiple apps',
  exportsAllowed: 'Allow this role to export data from any app in the suite',
  apps: {
    master_dashboard: 'Organization-wide compliance metrics and KPIs visible to leadership',
    department_dashboard: 'Department-level metrics and tasks for department managers',
    individual_dashboard: 'Personal tasks, notifications, and compliance items for individual users',
    compliance_connect: 'Core compliance management - policies, tasks, and regulatory requirements',
    audit_pro: 'Internal and external audit management, findings, and corrective actions',
    feedback_hub: 'Collect and manage feedback, grievances, and suggestions from staff',
    enforce_point: 'Policy enforcement, incident management, and disciplinary tracking',
    risk_guard: 'Risk assessment, mitigation tracking, and risk scoring',
    capa: 'Corrective and Preventive Actions management',
    citations: 'Regulatory citations, deficiencies, and survey findings',
    documents: 'Controlled document management with version control and approvals',
  },
};

export const AppAccessStep: React.FC = () => {
  const { data, updateAppAccessEntitlements, markStepComplete, nextStep } = useOnboarding();
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);

  const entitlements = data.appAccessEntitlements;

  // Get roles from step 6 (dynamic)
  const configuredRoles = useMemo(() => {
    return data.roles.filter(r => r.isSystemRole || data.customRolesEnabled);
  }, [data.roles, data.customRolesEnabled]);

  // Initialize entitlements for any new roles that don't have entitlements yet
  useEffect(() => {
    const missingRoles = configuredRoles.filter(
      role => !entitlements.roleEntitlements[role.id]
    );
    
    if (missingRoles.length > 0 && entitlements.selectedPreset) {
      // Re-apply preset to include new roles
      const newEntitlements = applyPresetToRoles(entitlements.selectedPreset, configuredRoles);
      // Preserve existing customizations
      Object.keys(entitlements.roleEntitlements).forEach(roleId => {
        if (newEntitlements.roleEntitlements[roleId]) {
          newEntitlements.roleEntitlements[roleId] = entitlements.roleEntitlements[roleId];
        }
      });
      newEntitlements.isCustomized = entitlements.isCustomized;
      updateAppAccessEntitlements(newEntitlements);
    }
  }, [configuredRoles, entitlements, updateAppAccessEntitlements]);

  // Filter apps to show based on enabled microapps and dashboards
  const visibleApps = useMemo(() => {
    return ENTITLEMENT_APPS.filter(app => {
      // Check if it's a dashboard
      if (app.isDashboard) {
        if (app.id === 'master_dashboard') return true; // Always show master dashboard
        if (app.id === 'department_dashboard') {
          return data.tenantSettings.featureFlags?.departmentDashboard !== false;
        }
        if (app.id === 'individual_dashboard') {
          return data.tenantSettings.featureFlags?.individualDashboard !== false;
        }
        return true;
      }
      // For microapps, check if enabled
      const matchingMicroapp = data.microapps.find(
        m => m.code === app.code && m.status === 'enabled'
      );
      return !!matchingMicroapp || app.isCore;
    });
  }, [data.microapps, data.tenantSettings.featureFlags]);

  const handlePresetSelect = (presetId: PresetId) => {
    const newEntitlements = applyPresetToRoles(presetId, configuredRoles);
    updateAppAccessEntitlements(newEntitlements);
    setValidationErrors([]);
  };

  const handleResetToPreset = () => {
    if (entitlements.selectedPreset) {
      handlePresetSelect(entitlements.selectedPreset);
    }
  };

  const updateAppAccess = (
    roleId: string,
    appId: string,
    field: 'accessLevel' | 'scope',
    value: AccessLevel | DataScope
  ) => {
    const currentRoleEntitlements = entitlements.roleEntitlements[roleId] || createEmptyRoleEntitlements();
    const newEntitlements: AppAccessEntitlements = {
      ...entitlements,
      isCustomized: true,
      roleEntitlements: {
        ...entitlements.roleEntitlements,
        [roleId]: {
          ...currentRoleEntitlements,
          apps: {
            ...currentRoleEntitlements.apps,
            [appId]: {
              ...currentRoleEntitlements.apps[appId],
              [field]: value,
            },
          },
        },
      },
    };
    updateAppAccessEntitlements(newEntitlements);
  };

  const updateDashboardFlag = (
    roleId: string,
    flag: 'canExportCsv' | 'canViewCrossAppKpis',
    value: boolean
  ) => {
    const currentRoleEntitlements = entitlements.roleEntitlements[roleId] || createEmptyRoleEntitlements();
    const newEntitlements: AppAccessEntitlements = {
      ...entitlements,
      isCustomized: true,
      roleEntitlements: {
        ...entitlements.roleEntitlements,
        [roleId]: {
          ...currentRoleEntitlements,
          dashboardFlags: {
            ...currentRoleEntitlements.dashboardFlags,
            [flag]: value,
          },
        },
      },
    };
    updateAppAccessEntitlements(newEntitlements);
  };

  const updateExportPermission = (roleId: string, allowed: boolean) => {
    const currentRoleEntitlements = entitlements.roleEntitlements[roleId] || createEmptyRoleEntitlements();
    const newEntitlements: AppAccessEntitlements = {
      ...entitlements,
      isCustomized: true,
      roleEntitlements: {
        ...entitlements.roleEntitlements,
        [roleId]: {
          ...currentRoleEntitlements,
          exportsAllowed: allowed,
        },
      },
    };
    updateAppAccessEntitlements(newEntitlements);
  };

  const getMaxScope = (role: Role): DataScope => {
    return ROLE_TYPE_MAX_SCOPE[role.type] || 'self';
  };

  const getScopeOptions = (role: Role): DataScope[] => {
    const maxScope = getMaxScope(role);
    if (maxScope === 'org') return ['self', 'department', 'org'];
    if (maxScope === 'department') return ['self', 'department'];
    return ['self'];
  };

  const validate = (): boolean => {
    const errors: string[] = [];

    if (!entitlements.selectedPreset) {
      errors.push('Please select an access preset');
    }

    // Check Compliance Head and Org Admin roles have dashboard access
    const complianceHeadRole = configuredRoles.find(r => r.type === 'compliance_head');
    const orgAdminRole = configuredRoles.find(r => r.type === 'org_admin');

    if (complianceHeadRole) {
      const complianceHeadDashboard = entitlements.roleEntitlements[complianceHeadRole.id]?.apps?.dashboard;
      if (complianceHeadDashboard?.accessLevel === 'none') {
        errors.push('Compliance Head must have Dashboard access');
      }
    }

    if (orgAdminRole) {
      const orgAdminDashboard = entitlements.roleEntitlements[orgAdminRole.id]?.apps?.dashboard;
      if (orgAdminDashboard?.accessLevel === 'none') {
        errors.push('Org Admin must have Dashboard access');
      }
    }

    // Check Staff roles have at least one operational app
    const staffRoles = configuredRoles.filter(r => r.type === 'staff');
    staffRoles.forEach(staffRole => {
      const staffApps = entitlements.roleEntitlements[staffRole.id]?.apps || {};
      const hasOperationalAccess =
        staffApps.compliance_connect?.accessLevel !== 'none' ||
        staffApps.feedback_hub?.accessLevel !== 'none';

      if (!hasOperationalAccess && entitlements.selectedPreset) {
        errors.push(`${staffRole.name} must have access to at least ComplianceConnect or FeedbackHub`);
      }
    });

    setValidationErrors(errors);
    return errors.length === 0;
  };

  const handleContinue = () => {
    if (validate()) {
      markStepComplete(7);
      nextStep();
    }
  };

  const getRoleIcon = (role: Role) => {
    return ROLE_ICONS[role.type] || Users;
  };

  return (
    <div className="space-y-6">
      {/* Info Banner */}
      <div className="p-4 rounded-lg bg-primary/5 border border-primary/20 flex items-start gap-3">
        <Info className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
        <div className="text-sm">
          <p className="font-medium text-foreground mb-1">Onboarding Baseline Configuration</p>
          <p className="text-muted-foreground">
            Configuring access for <strong>{configuredRoles.length} roles</strong> defined in the previous step.
            Detailed capability permissions can be configured later in Admin Configuration.
          </p>
        </div>
      </div>

      {/* Preset Selection */}
      <div className="form-section">
        <div className="flex items-center gap-2 mb-1">
          <h3 className="form-section-title mb-0">Choose an Access Preset</h3>
          <Tooltip>
            <TooltipTrigger asChild>
              <HelpCircle className="w-4 h-4 text-muted-foreground cursor-help" />
            </TooltipTrigger>
            <TooltipContent className="max-w-xs">
              <p>Presets provide a starting point for access configuration. Choose one that matches your organization's philosophy, then customize as needed.</p>
            </TooltipContent>
          </Tooltip>
        </div>
        <p className="text-sm text-muted-foreground mb-4">
          Select a preset that best matches your organization's access control philosophy. 
          You can customize it after selection.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {(Object.keys(APP_ACCESS_PRESETS) as PresetId[]).map(presetId => {
            const preset = APP_ACCESS_PRESETS[presetId];
            const isSelected = entitlements.selectedPreset === presetId;

            return (
              <Tooltip key={presetId}>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => handlePresetSelect(presetId)}
                    className={`p-4 rounded-lg border text-left transition-all ${
                      isSelected
                        ? 'border-primary bg-primary/5 ring-2 ring-primary/20'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-foreground">{preset.name}</span>
                      {presetId === 'recommended' && (
                        <Badge variant="secondary" className="text-xs">Default</Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{preset.description}</p>
                    <p className="text-xs text-muted-foreground italic">{preset.summary}</p>
                  </button>
                </TooltipTrigger>
                <TooltipContent side="bottom" className="max-w-xs">
                  <p>{TOOLTIPS.preset[presetId]}</p>
                </TooltipContent>
              </Tooltip>
            );
          })}
        </div>

        {entitlements.isCustomized && entitlements.selectedPreset && (
          <div className="mt-4 flex items-center gap-2">
            <Badge variant="outline" className="text-xs">Customized</Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleResetToPreset}
              className="text-xs"
            >
              <RotateCcw className="w-3 h-3 mr-1" />
              Reset to preset defaults
            </Button>
          </div>
        )}
      </div>

      {/* Access Grid */}
      {entitlements.selectedPreset && (
        <div className="form-section">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="form-section-title mb-0">App Access Configuration</h3>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <HelpCircle className="w-4 h-4 text-muted-foreground cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p className="font-medium mb-1">How access works:</p>
                    <ul className="text-xs space-y-1">
                      <li><strong>Access Level:</strong> What actions users can perform (None, View, Manage)</li>
                      <li><strong>Scope:</strong> What data they can see (Self, Department, Org)</li>
                    </ul>
                  </TooltipContent>
                </Tooltip>
              </div>
              <p className="text-sm text-muted-foreground">
                Configure access level and data scope for each role.
              </p>
            </div>
          </div>

          {/* Legend */}
          <div className="mb-4 p-3 rounded-lg bg-muted/30 border border-border/50">
            <div className="flex flex-wrap gap-4 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-medium text-foreground">Access Levels:</span>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className="px-2 py-0.5 rounded bg-muted text-muted-foreground cursor-help">None</span>
                  </TooltipTrigger>
                  <TooltipContent><p>{TOOLTIPS.accessLevel.none}</p></TooltipContent>
                </Tooltip>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-700 cursor-help">View</span>
                  </TooltipTrigger>
                  <TooltipContent><p>{TOOLTIPS.accessLevel.view}</p></TooltipContent>
                </Tooltip>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className="px-2 py-0.5 rounded bg-green-100 text-green-700 cursor-help">Manage</span>
                  </TooltipTrigger>
                  <TooltipContent><p>{TOOLTIPS.accessLevel.manage}</p></TooltipContent>
                </Tooltip>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium text-foreground">Scopes:</span>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className="px-2 py-0.5 rounded bg-muted text-muted-foreground cursor-help">Self</span>
                  </TooltipTrigger>
                  <TooltipContent><p>{TOOLTIPS.scope.self}</p></TooltipContent>
                </Tooltip>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className="px-2 py-0.5 rounded bg-muted text-muted-foreground cursor-help">Dept</span>
                  </TooltipTrigger>
                  <TooltipContent><p>{TOOLTIPS.scope.department}</p></TooltipContent>
                </Tooltip>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className="px-2 py-0.5 rounded bg-muted text-muted-foreground cursor-help">Org</span>
                  </TooltipTrigger>
                  <TooltipContent><p>{TOOLTIPS.scope.org}</p></TooltipContent>
                </Tooltip>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-2 text-sm font-medium text-muted-foreground w-48">
                    <div className="flex items-center gap-1">
                      Application
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <HelpCircle className="w-3 h-3 cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p>Hover over any app name to see what it does</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                  </th>
                  {configuredRoles.map(role => {
                    const RoleIcon = getRoleIcon(role);
                    return (
                      <th key={role.id} className="text-center py-3 px-2 text-sm font-medium min-w-[120px]">
                        <div className="flex flex-col items-center gap-1">
                          <div className="flex items-center gap-1">
                            <RoleIcon className="w-4 h-4 text-muted-foreground" />
                            <span className="truncate max-w-[100px]">{role.name}</span>
                          </div>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Badge variant="outline" className="text-xs font-normal cursor-help">
                                Max: {SCOPE_LABELS[getMaxScope(role)]}
                              </Badge>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{TOOLTIPS.maxScope}</p>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                      </th>
                    );
                  })}
                </tr>
              </thead>
              <tbody>
                {visibleApps.map(app => {
                  const Icon = APP_ICONS[app.id] || Shield;
                  const appTooltip = TOOLTIPS.apps[app.id as keyof typeof TOOLTIPS.apps];
                  return (
                    <tr key={app.id} className="border-b border-border/50">
                      <td className="py-3 px-2">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="flex items-center gap-2 cursor-help">
                              <Icon className="w-4 h-4 text-muted-foreground" />
                              <span className="text-sm font-medium">{app.name}</span>
                            </div>
                          </TooltipTrigger>
                          <TooltipContent side="right" className="max-w-xs">
                            <p>{appTooltip || app.name}</p>
                          </TooltipContent>
                        </Tooltip>
                      </td>
                      {configuredRoles.map(role => {
                        const roleEntitlements = entitlements.roleEntitlements[role.id] || createEmptyRoleEntitlements();
                        const config = roleEntitlements.apps[app.id];
                        const scopeOptions = getScopeOptions(role);

                        return (
                          <td key={role.id} className="py-3 px-2">
                            <div className="flex flex-col gap-2 items-center">
                              {/* Access Level Row */}
                              <div className="flex items-center gap-1.5">
                                <span className="text-[10px] text-muted-foreground font-medium w-10 text-right">Access</span>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <div>
                                      <Select
                                        value={config?.accessLevel || 'none'}
                                        onValueChange={(v: AccessLevel) =>
                                          updateAppAccess(role.id, app.id, 'accessLevel', v)
                                        }
                                      >
                                        <SelectTrigger className="w-20 h-7 text-xs">
                                          <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                          <SelectItem value="none">None</SelectItem>
                                          <SelectItem value="view">View</SelectItem>
                                          <SelectItem value="manage">Manage</SelectItem>
                                        </SelectContent>
                                      </Select>
                                    </div>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p className="font-medium mb-1">Access Level</p>
                                    <p className="text-xs">{TOOLTIPS.accessLevel[config?.accessLevel || 'none']}</p>
                                  </TooltipContent>
                                </Tooltip>
                              </div>
                              
                              {/* Scope Row - only shown when access is not 'none' */}
                              {config?.accessLevel && config.accessLevel !== 'none' && (
                                <div className="flex items-center gap-1.5">
                                  <span className="text-[10px] text-muted-foreground font-medium w-10 text-right">Scope</span>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <div>
                                        <Select
                                          value={config?.scope || 'self'}
                                          onValueChange={(v: DataScope) =>
                                            updateAppAccess(role.id, app.id, 'scope', v)
                                          }
                                        >
                                          <SelectTrigger className="w-20 h-7 text-xs">
                                            <SelectValue />
                                          </SelectTrigger>
                                          <SelectContent>
                                            {scopeOptions.map(scope => (
                                              <SelectItem key={scope} value={scope}>
                                                {SCOPE_LABELS[scope]}
                                              </SelectItem>
                                            ))}
                                          </SelectContent>
                                        </Select>
                                      </div>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p className="font-medium mb-1">Data Scope</p>
                                      <p className="text-xs">{TOOLTIPS.scope[config?.scope || 'self']}</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </div>
                              )}
                            </div>
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Guardrail note */}
          <div className="mt-4 p-3 rounded bg-muted/50 text-sm text-muted-foreground flex items-start gap-2">
            <Info className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <span>
              <strong>Tip:</strong> "Manage" allows create/update within the role's allowed scope. 
              Advanced approvals and workflow controls are configured in Admin Configuration.
            </span>
          </div>
        </div>
      )}

      {/* Advanced Options (Collapsible) */}
      {entitlements.selectedPreset && (
        <div className="form-section">
          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="flex items-center gap-2 text-sm font-medium text-foreground w-full"
          >
            {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            Advanced Options (Optional)
            <Tooltip>
              <TooltipTrigger asChild>
                <HelpCircle className="w-3.5 h-3.5 text-muted-foreground cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p>Additional permissions for dashboards and data exports. These are optional and can be configured later.</p>
              </TooltipContent>
            </Tooltip>
          </button>

          {showAdvanced && (
            <div className="mt-4 space-y-6">
              {/* Dashboard Entitlements */}
              <div>
                <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
                  <LayoutDashboard className="w-4 h-4" />
                  Dashboard Entitlements
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="w-3.5 h-3.5 text-muted-foreground cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <p>Control what users can do within dashboards beyond viewing data.</p>
                    </TooltipContent>
                  </Tooltip>
                </h4>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-2 px-2 text-xs font-medium text-muted-foreground">
                          Permission
                        </th>
                        {configuredRoles.map(role => (
                          <th key={role.id} className="text-center py-2 px-4 text-xs font-medium">
                            {role.name}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b border-border/50">
                        <td className="py-2 px-2 text-sm">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="flex items-center gap-2 cursor-help">
                                <Download className="w-4 h-4 text-muted-foreground" />
                                Export Dashboard CSV
                              </div>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{TOOLTIPS.dashboardExport}</p>
                            </TooltipContent>
                          </Tooltip>
                        </td>
                        {configuredRoles.map(role => {
                          const roleEntitlements = entitlements.roleEntitlements[role.id] || createEmptyRoleEntitlements();
                          return (
                            <td key={role.id} className="text-center py-2 px-4">
                              <Switch
                                checked={roleEntitlements.dashboardFlags.canExportCsv}
                                onCheckedChange={(v) => updateDashboardFlag(role.id, 'canExportCsv', v)}
                              />
                            </td>
                          );
                        })}
                      </tr>
                      <tr className="border-b border-border/50">
                        <td className="py-2 px-2 text-sm">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="flex items-center gap-2 cursor-help">
                                <Eye className="w-4 h-4 text-muted-foreground" />
                                View Cross-App KPIs
                              </div>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{TOOLTIPS.crossAppKpis}</p>
                            </TooltipContent>
                          </Tooltip>
                        </td>
                        {configuredRoles.map(role => {
                          const roleEntitlements = entitlements.roleEntitlements[role.id] || createEmptyRoleEntitlements();
                          return (
                            <td key={role.id} className="text-center py-2 px-4">
                              <Switch
                                checked={roleEntitlements.dashboardFlags.canViewCrossAppKpis}
                                onCheckedChange={(v) => updateDashboardFlag(role.id, 'canViewCrossAppKpis', v)}
                              />
                            </td>
                          );
                        })}
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Export Permissions */}
              <div>
                <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
                  <Download className="w-4 h-4" />
                  Export Permissions (Suite-wide)
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="w-3.5 h-3.5 text-muted-foreground cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <p>Control whether users can export data from any app in the suite. Export scope follows their access scope.</p>
                    </TooltipContent>
                  </Tooltip>
                </h4>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-2 px-2 text-xs font-medium text-muted-foreground">
                          Permission
                        </th>
                        {configuredRoles.map(role => (
                          <th key={role.id} className="text-center py-2 px-4 text-xs font-medium">
                            {role.name}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b border-border/50">
                        <td className="py-2 px-2 text-sm">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span className="cursor-help">Exports Allowed</span>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{TOOLTIPS.exportsAllowed}</p>
                            </TooltipContent>
                          </Tooltip>
                        </td>
                        {configuredRoles.map(role => {
                          const roleEntitlements = entitlements.roleEntitlements[role.id] || createEmptyRoleEntitlements();
                          return (
                            <td key={role.id} className="text-center py-2 px-4">
                              <div className="flex flex-col items-center gap-1">
                                <Switch
                                  checked={roleEntitlements.exportsAllowed}
                                  onCheckedChange={(v) => updateExportPermission(role.id, v)}
                                />
                                {roleEntitlements.exportsAllowed && (
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Badge variant="outline" className="text-xs cursor-help">
                                        {SCOPE_LABELS[roleEntitlements.exportScope]}
                                      </Badge>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>Can export data within {SCOPE_LABELS[roleEntitlements.exportScope].toLowerCase()} scope</p>
                                    </TooltipContent>
                                  </Tooltip>
                                )}
                              </div>
                            </td>
                          );
                        })}
                      </tr>
                    </tbody>
                  </table>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Fine-grained export controls per report type are configured in Admin Configuration.
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Validation Errors */}
      {validationErrors.length > 0 && (
        <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/30">
          <p className="text-sm font-medium text-destructive mb-2">Please fix the following:</p>
          <ul className="text-sm text-destructive list-disc list-inside">
            {validationErrors.map((error, i) => (
              <li key={i}>{error}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Continue Button */}
      <div className="flex justify-end">
        <Button onClick={handleContinue} disabled={!entitlements.selectedPreset}>
          Continue
        </Button>
      </div>
    </div>
  );
};
