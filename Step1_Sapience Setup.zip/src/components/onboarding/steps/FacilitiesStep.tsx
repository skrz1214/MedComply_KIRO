import React, { useState, useMemo } from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Building, Users, HelpCircle, Info, ChevronDown, ChevronUp, GitBranch, Network, AlertCircle } from 'lucide-react';
import { FACILITY_TYPES, DEFAULT_DEPARTMENTS, Facility } from '@/types/onboarding';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { cn } from '@/lib/utils';

const GuidanceTooltip: React.FC<{ content: string }> = ({ content }) => (
  <TooltipProvider>
    <Tooltip>
      <TooltipTrigger asChild>
        <HelpCircle className="w-4 h-4 text-muted-foreground hover:text-primary cursor-help inline ml-1" />
      </TooltipTrigger>
      <TooltipContent className="max-w-xs">
        <p className="text-sm">{content}</p>
      </TooltipContent>
    </Tooltip>
  </TooltipProvider>
);

export const FacilitiesStep: React.FC = () => {
  const { data, addFacility, removeFacility, updateFacility, setSingleFacilityMode, addDepartment, removeDepartment, markStepComplete, nextStep } = useOnboarding();
  const [newDeptName, setNewDeptName] = useState('');
  const [showGuide, setShowGuide] = useState(false);
  const [enableHierarchy, setEnableHierarchy] = useState(() => data.facilities.some(f => f.parentFacilityId || f.isParent));

  // Get parent facilities (facilities marked as parent or have no parent themselves)
  const parentFacilities = useMemo(() => {
    return data.facilities.filter(f => f.isParent || (!f.parentFacilityId && data.facilities.some(child => child.parentFacilityId === f.id)));
  }, [data.facilities]);

  // Get standalone facilities (not parent, not child)
  const standaloneFacilities = useMemo(() => {
    if (!enableHierarchy) return data.facilities;
    return data.facilities.filter(f => !f.isParent && !f.parentFacilityId);
  }, [data.facilities, enableHierarchy]);

  // Get child facilities for a parent
  const getChildFacilities = (parentId: string) => {
    return data.facilities.filter(f => f.parentFacilityId === parentId);
  };

  const handleAddFacility = (parentId?: string) => {
    addFacility({ 
      name: '', 
      code: '', 
      type: 'Other', 
      sameAsOrgAddress: true, 
      timeZone: data.organization.timeZone || 'America/New_York', 
      status: 'active',
      parentFacilityId: parentId || null,
      isParent: false
    });
  };

  const handleAddParentFacility = () => {
    addFacility({ 
      name: '', 
      code: '', 
      type: 'Hospital', 
      sameAsOrgAddress: true, 
      timeZone: data.organization.timeZone || 'America/New_York', 
      status: 'active',
      parentFacilityId: null,
      isParent: true
    });
  };

  const handleToggleParent = (facilityId: string, isParent: boolean) => {
    updateFacility(facilityId, { isParent });
    // If making it a non-parent, also remove any children's parent reference
    if (!isParent) {
      data.facilities.forEach(f => {
        if (f.parentFacilityId === facilityId) {
          updateFacility(f.id, { parentFacilityId: null });
        }
      });
    }
  };

  const handleSetParent = (childId: string, parentId: string | null) => {
    updateFacility(childId, { parentFacilityId: parentId, isParent: false });
  };

  const handleAddDepartment = () => {
    if (newDeptName.trim()) {
      addDepartment({ name: newDeptName, code: newDeptName.toUpperCase().replace(/\s+/g, '-').slice(0, 10), status: 'active', facilityIds: [] });
      setNewDeptName('');
    }
  };

  const handleQuickAddDept = (dept: typeof DEFAULT_DEPARTMENTS[0]) => {
    if (!data.departments.find(d => d.code === dept.code)) {
      addDepartment({ name: dept.name, code: dept.code, status: 'active', facilityIds: [] });
    }
  };

  const canContinue = data.facilities.length > 0 && data.departments.length > 0;

  // Get available parents for a facility (can't be itself or its children)
  const getAvailableParents = (facilityId: string) => {
    return data.facilities.filter(f => 
      f.id !== facilityId && 
      f.parentFacilityId !== facilityId &&
      (f.isParent || !f.parentFacilityId)
    );
  };

  const renderFacilityCard = (facility: Facility, isChild: boolean = false) => (
    <div 
      key={facility.id} 
      className={cn(
        "p-4 rounded-lg border bg-muted/30",
        facility.isParent ? "border-primary/40 bg-primary/5" : "border-border",
        isChild && "ml-8 border-l-4 border-l-primary/30"
      )}
    >
      <div className="space-y-3">
        {/* Header row with parent indicator */}
        {enableHierarchy && (
          <div className="flex items-center justify-between pb-2 border-b border-border/50">
            <div className="flex items-center gap-2">
              {facility.isParent ? (
                <div className="flex items-center gap-1.5 text-xs font-medium text-primary">
                  <Network className="w-3.5 h-3.5" />
                  Parent Facility
                </div>
              ) : facility.parentFacilityId ? (
                <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                  <GitBranch className="w-3.5 h-3.5" />
                  Child of: {data.facilities.find(f => f.id === facility.parentFacilityId)?.name || 'Unknown'}
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Building className="w-3.5 h-3.5" />
                  Standalone
                </div>
              )}
            </div>
            
            {/* Hierarchy controls */}
            <div className="flex items-center gap-2">
              {!facility.parentFacilityId && (
                <div className="flex items-center gap-1.5">
                  <Label className="text-xs">Parent</Label>
                  <Switch 
                    checked={facility.isParent || false}
                    onCheckedChange={(checked) => handleToggleParent(facility.id, checked)}
                  />
                </div>
              )}
              {!facility.isParent && (
                <Select 
                  value={facility.parentFacilityId || 'none'} 
                  onValueChange={v => handleSetParent(facility.id, v === 'none' ? null : v)}
                >
                  <SelectTrigger className="h-7 text-xs w-[140px]">
                    <SelectValue placeholder="Set parent..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No parent</SelectItem>
                    {getAvailableParents(facility.id).map(p => (
                      <SelectItem key={p.id} value={p.id}>{p.name || `Facility ${p.code}`}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>
        )}
        
        {/* Main fields */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <Input 
            placeholder="Facility Name" 
            value={facility.name} 
            onChange={e => updateFacility(facility.id, { name: e.target.value })} 
          />
          <Input 
            placeholder="Code" 
            value={facility.code} 
            onChange={e => updateFacility(facility.id, { code: e.target.value })} 
          />
          <div className="flex gap-2">
            <Select value={facility.type} onValueChange={v => updateFacility(facility.id, { type: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{FACILITY_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
            </Select>
            {!data.singleFacilityMode && (
              <Button variant="ghost" size="icon" onClick={() => removeFacility(facility.id)}>
                <Trash2 className="w-4 h-4 text-destructive" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Guidance Section */}
      <Collapsible open={showGuide} onOpenChange={setShowGuide}>
        <div className="p-4 rounded-lg border border-primary/20 bg-primary/5">
          <CollapsibleTrigger asChild>
            <button className="flex items-center justify-between w-full text-left">
              <div className="flex items-center gap-2">
                <Info className="w-5 h-5 text-primary" />
                <span className="font-medium text-primary">Understanding Facilities/Branches & Structure</span>
              </div>
              {showGuide ? <ChevronUp className="w-4 h-4 text-primary" /> : <ChevronDown className="w-4 h-4 text-primary" />}
            </button>
          </CollapsibleTrigger>
          <CollapsibleContent className="mt-4 space-y-4">
            {/* Org vs Facility hierarchy note */}
            {data.organization.hasParentOrg && (
              <div className="flex items-start gap-2 p-3 rounded bg-blue-500/10 border border-blue-500/20">
                <Info className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                <div className="text-xs text-muted-foreground">
                  <strong className="text-foreground">Your org belongs to: {data.organization.parentOrgName || 'Parent Organization'}</strong>
                  <p className="mt-1">That's your <em>corporate</em> hierarchy. Below, you're configuring <em>facility</em> hierarchy within your own organization — these are independent concepts that can work together.</p>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* What is a Facility/Branch */}
              <div className="p-4 rounded-lg bg-background border border-border">
                <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                  <Building className="w-4 h-4 text-primary" />
                  What is a Facility/Branch?
                </h4>
                <ul className="text-sm text-muted-foreground space-y-1.5">
                  <li>• A physical location with its own license/certification</li>
                  <li>• Subject to separate regulatory surveys</li>
                  <li>• Has its own address and operational identity</li>
                  <li>• Examples: Hospital campus, SNF building, outpatient clinic, home health branch</li>
                </ul>
              </div>

              {/* Why Facilities/Branches Matter */}
              <div className="p-4 rounded-lg bg-background border border-border">
                <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                  <Info className="w-4 h-4 text-amber-500" />
                  Why Facilities/Branches Matter
                </h4>
                <ul className="text-sm text-muted-foreground space-y-1.5">
                  <li>• <strong>Regulatory scope:</strong> Citations & audits are facility/branch-specific</li>
                  <li>• <strong>Access control:</strong> Users can be assigned per-facility/branch</li>
                  <li>• <strong>Reporting:</strong> Dashboards filter by facility/branch</li>
                  <li>• <strong>Audit trails:</strong> Actions tagged with facility/branch context</li>
                </ul>
              </div>
            </div>

            {/* Structure Comparison */}
            <div className="p-4 rounded-lg bg-background border border-border">
              <h4 className="font-semibold text-sm mb-3">Choosing Your Structure</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className={cn(
                  "p-3 rounded border",
                  data.singleFacilityMode ? "border-primary/30 bg-primary/5" : "border-border bg-muted/30"
                )}>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <Building className="w-4 h-4 text-primary" />
                    </div>
                    <span className="font-medium text-sm">Single Facility/Branch</span>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">One location, one license</p>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>✓ Simplest setup</li>
                    <li>✓ All data unified</li>
                    <li>✓ Best for standalone clinics</li>
                  </ul>
                </div>

                <div className={cn(
                  "p-3 rounded border",
                  !data.singleFacilityMode && !enableHierarchy ? "border-primary/30 bg-primary/5" : "border-border bg-muted/30"
                )}>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex -space-x-1">
                      <div className="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center border-2 border-background">
                        <Building className="w-3 h-3 text-blue-500" />
                      </div>
                      <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center border-2 border-background">
                        <Building className="w-3 h-3 text-green-500" />
                      </div>
                      <div className="w-6 h-6 rounded-full bg-amber-500/20 flex items-center justify-center border-2 border-background">
                        <Building className="w-3 h-3 text-amber-500" />
                      </div>
                    </div>
                    <span className="font-medium text-sm">Multiple Facilities/Branches</span>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">Peer locations, same level</p>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>✓ Each has own surveys/citations</li>
                    <li>✓ Shared org-level reporting</li>
                    <li>✓ Best for multi-site systems</li>
                  </ul>
                </div>

                <div className={cn(
                  "p-3 rounded border",
                  enableHierarchy ? "border-primary/30 bg-primary/5" : "border-border bg-muted/30"
                )}>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex flex-col items-center">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                        <Building className="w-3 h-3 text-primary" />
                      </div>
                      <div className="w-px h-2 bg-primary/30" />
                      <div className="flex -space-x-1">
                        <div className="w-4 h-4 rounded-full bg-primary/10 border border-primary/20" />
                        <div className="w-4 h-4 rounded-full bg-primary/10 border border-primary/20" />
                      </div>
                    </div>
                    <span className="font-medium text-sm">Parent-Child</span>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">Hierarchical structure</p>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>✓ Parent aggregates child data</li>
                    <li>✓ Inherited policies/settings</li>
                    <li>✓ Best for health systems with regional hubs</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Quick Tips */}
            <div className="flex items-start gap-2 p-3 rounded bg-amber-500/10 border border-amber-500/20">
              <Info className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
              <div className="text-xs text-muted-foreground">
                <strong className="text-foreground">Tip:</strong> Start simple! You can add more facilities/branches later. Each facility/branch you add will appear in your dashboard filters, user assignments, and compliance reports.
              </div>
            </div>
          </CollapsibleContent>
        </div>
      </Collapsible>

      <div className="form-section">
        <div className="flex items-center justify-between mb-4">
          <h3 className="form-section-title mb-0">
            <Building className="w-5 h-5" /> Facilities/Branches
            <GuidanceTooltip content="Each facility/branch represents a licensed location subject to its own regulatory surveys. Citations, audits, and CAPAs are scoped to specific facilities/branches." />
          </h3>
          <div className="flex items-center gap-4">
            {!data.singleFacilityMode && data.facilities.length > 1 && (
              <div className="flex items-center gap-2">
                <Label className="text-sm">Enable Hierarchy</Label>
                <GuidanceTooltip content="Enable to create parent-child relationships between facilities. Parent facilities aggregate data from children and can share policies." />
                <Switch checked={enableHierarchy} onCheckedChange={setEnableHierarchy} />
              </div>
            )}
            <div className="flex items-center gap-2">
              <Label className="text-sm">Single Facility/Branch Mode</Label>
              <GuidanceTooltip content="Enable if your organization operates from one location only. This simplifies the interface by removing multi-facility/branch options." />
              <Switch checked={data.singleFacilityMode} onCheckedChange={setSingleFacilityMode} />
            </div>
          </div>
        </div>

        {/* Hierarchy explanation when enabled */}
        {enableHierarchy && !data.singleFacilityMode && (
          <div className="flex items-start gap-2 p-3 rounded bg-primary/5 border border-primary/20 mb-4">
            <Network className="w-4 h-4 text-primary mt-0.5 shrink-0" />
            <div className="text-xs text-muted-foreground">
              <strong className="text-foreground">Parent-Child Mode Active:</strong> Mark facilities/branches as "Parent" to create hubs. Assign other facilities/branches as children to roll up data and inherit settings. Each facility/branch card has controls for managing hierarchy.
            </div>
          </div>
        )}

        <div className="space-y-3">
          {/* Render parent facilities with their children */}
          {enableHierarchy && parentFacilities.map(parent => (
            <div key={parent.id} className="space-y-2">
              {renderFacilityCard(parent, false)}
              {/* Children */}
              {getChildFacilities(parent.id).map(child => renderFacilityCard(child, true))}
              {/* Add child button */}
              <Button 
                variant="ghost" 
                size="sm" 
                className="ml-8 text-xs"
                onClick={() => handleAddFacility(parent.id)}
              >
                <Plus className="w-3 h-3 mr-1" />
                Add child facility
              </Button>
            </div>
          ))}
          
          {/* Standalone facilities */}
          {enableHierarchy && standaloneFacilities.map(facility => renderFacilityCard(facility, false))}
          
          {/* Non-hierarchy mode */}
          {!enableHierarchy && data.facilities.map(facility => renderFacilityCard(facility, false))}
          
          {/* Add buttons */}
          {!data.singleFacilityMode && (
            <div className="flex gap-2 flex-wrap">
              <Button variant="outline" onClick={() => handleAddFacility()}>
                <Plus className="w-4 h-4 mr-2" />Add Facility/Branch
              </Button>
              {enableHierarchy && (
                <Button variant="outline" onClick={handleAddParentFacility}>
                  <Network className="w-4 h-4 mr-2" />Add Parent Facility/Branch
                </Button>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="form-section">
        <h3 className="form-section-title">
          <Users className="w-5 h-5" /> Departments
          <GuidanceTooltip content="Departments organize staff and workflows within facilities. Deficiencies and CAPAs can be assigned to specific departments for accountability." />
        </h3>
        <div className="flex flex-wrap gap-2 mb-4">
          {DEFAULT_DEPARTMENTS.map(dept => (
            <Button key={dept.code} variant="outline" size="sm" onClick={() => handleQuickAddDept(dept)} disabled={!!data.departments.find(d => d.code === dept.code)}>{dept.name}</Button>
          ))}
        </div>
        <div className="space-y-2">
          {data.departments.map(dept => (
            <div key={dept.id} className="flex items-center justify-between p-3 rounded-lg border border-border">
              <span>{dept.name} <span className="text-muted-foreground text-sm">({dept.code})</span></span>
              <Button variant="ghost" size="icon" onClick={() => removeDepartment(dept.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
            </div>
          ))}
        </div>
        <div className="flex gap-2 mt-4">
          <Input placeholder="New department name" value={newDeptName} onChange={e => setNewDeptName(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleAddDepartment()} />
          <Button onClick={handleAddDepartment}><Plus className="w-4 h-4" /></Button>
        </div>
      </div>

      <div className="flex flex-col items-end gap-2">
        {!canContinue && (
          <div className="flex items-center gap-2 text-sm text-amber-600 dark:text-amber-400">
            <AlertCircle className="w-4 h-4" />
            <span>
              {data.facilities.length === 0 && data.departments.length === 0
                ? "Please add at least one facility/branch and one department to continue"
                : data.facilities.length === 0
                ? "Please add at least one facility/branch to continue"
                : "Please select at least one department to continue"}
            </span>
          </div>
        )}
        <Button onClick={() => { markStepComplete(4); nextStep(); }} disabled={!canContinue}>Continue</Button>
      </div>
    </div>
  );
};
