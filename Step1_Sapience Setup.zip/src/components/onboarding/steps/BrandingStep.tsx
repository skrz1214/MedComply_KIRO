import React, { useState, useEffect } from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Palette, Building2, Image, Type, Layout, MessageSquare, Globe, Link, AlertTriangle, Save, SkipForward, ArrowRight } from 'lucide-react';
import { BrandingCard } from '../branding/BrandingCard';
import { OrgIdentityCardContent } from '../branding/OrgIdentityCard';
import { LogoUploadCardContent } from '../branding/LogoUploadCard';
import { ThemeCardContent } from '../branding/ThemeCard';
import { TypographyCardContent } from '../branding/TypographyCard';
import { AppShellCardContent } from '../branding/AppShellCard';
import { LoginCardContent } from '../branding/LoginCard';
import { LocalizationCardContent } from '../branding/LocalizationCard';
import { DomainCardContent } from '../branding/DomainCard';
import { BrandingPreview } from '../branding/BrandingPreview';
import { BrandingConfig } from '@/types/brandingConfig';
import { getDefaultBrandingConfig, validateBrandingConfig } from '@/data/brandingPresets';
import { useToast } from '@/hooks/use-toast';

export const BrandingStep: React.FC = () => {
  const { data, markStepComplete, nextStep } = useOnboarding();
  const { toast } = useToast();
  
  const [config, setConfig] = useState<BrandingConfig>(() => 
    getDefaultBrandingConfig(data.organization.name, data.organization.orgCode)
  );
  const [expandedCards, setExpandedCards] = useState<Set<string>>(new Set(['orgIdentity']));
  const [validation, setValidation] = useState(() => validateBrandingConfig(config));

  useEffect(() => {
    setValidation(validateBrandingConfig(config));
  }, [config]);

  const updateConfig = (key: keyof BrandingConfig, updates: Record<string, unknown>) => {
    setConfig(prev => {
      const currentValue = prev[key];
      if (typeof currentValue === 'object' && currentValue !== null) {
        return { ...prev, [key]: { ...currentValue, ...updates } };
      }
      return prev;
    });
  };

  const toggleCard = (cardId: string) => {
    setExpandedCards(prev => {
      const next = new Set(prev);
      if (next.has(cardId)) next.delete(cardId);
      else next.add(cardId);
      return next;
    });
  };

  const handleSaveDraft = () => {
    setConfig(prev => ({ ...prev, status: 'draft' }));
    toast({ title: 'Draft Saved', description: 'Your branding configuration has been saved.' });
  };

  const handleSkipBranding = () => {
    setConfig(prev => ({ ...prev, status: 'skipped' }));
    toast({ title: 'Branding Skipped', description: 'Default branding will be used.' });
    markStepComplete(11);
    nextStep();
  };

  const handleContinue = () => {
    // Apply branding and continue in one step
    setConfig(prev => ({ 
      ...prev, 
      status: 'published', 
      publishedAt: new Date().toISOString(), 
      versionId: `v1-${Date.now()}` 
    }));
    toast({ title: 'Branding Applied', description: 'Your branding configuration is now active.' });
    markStepComplete(11);
    nextStep();
  };

  const cards = [
    { id: 'orgIdentity', title: 'Organization Display Identity', icon: <Building2 className="h-5 w-5" />, required: true },
    { id: 'logo', title: 'Logo & Icons', icon: <Image className="h-5 w-5" />, required: false },
    { id: 'theme', title: 'Color Theme', icon: <Palette className="h-5 w-5" />, required: false },
    { id: 'typography', title: 'Typography', icon: <Type className="h-5 w-5" />, required: false },
    { id: 'appShell', title: 'App Shell Style', icon: <Layout className="h-5 w-5" />, required: false },
    { id: 'login', title: 'Login & Support Messaging', icon: <MessageSquare className="h-5 w-5" />, required: false },
    { id: 'localization', title: 'Localization', icon: <Globe className="h-5 w-5" />, required: false },
    { id: 'domain', title: 'Domain Settings', icon: <Link className="h-5 w-5" />, required: false },
  ];

  return (
    <div className="flex gap-6">
      {/* Left: Configuration Cards */}
      <div className="flex-1 space-y-4">
        <div className="flex items-center justify-between p-4 rounded-lg border bg-card">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10"><Palette className="h-6 w-6 text-primary" /></div>
            <div>
              <h3 className="font-semibold">Branding & Localization</h3>
              <p className="text-sm text-muted-foreground">Customize your portal appearance</p>
            </div>
          </div>
          <Badge variant={config.status === 'published' ? 'default' : config.status === 'skipped' ? 'outline' : 'secondary'}>
            {config.status === 'published' ? 'Published' : config.status === 'skipped' ? 'Skipped' : 'Draft'}
          </Badge>
        </div>

        {validation.warnings.length > 0 && (
          <Alert><AlertTriangle className="h-4 w-4" /><AlertDescription>{validation.warnings[0]}</AlertDescription></Alert>
        )}

        <div className="space-y-3">
          {cards.map((card) => (
            <BrandingCard key={card.id} title={card.title} description={`Configure ${card.title.toLowerCase()}`} icon={card.icon} isRequired={card.required} isExpanded={expandedCards.has(card.id)} onToggle={() => toggleCard(card.id)}>
              {card.id === 'orgIdentity' && <OrgIdentityCardContent config={config.orgIdentity} onChange={(u) => updateConfig('orgIdentity', u)} defaultOrgName={data.organization.name} />}
              {card.id === 'logo' && <LogoUploadCardContent config={config.logo} onChange={(u) => updateConfig('logo', u)} />}
              {card.id === 'theme' && <ThemeCardContent config={config.theme} onChange={(u) => updateConfig('theme', u)} />}
              {card.id === 'typography' && <TypographyCardContent config={config.typography} onChange={(u) => updateConfig('typography', u)} />}
              {card.id === 'appShell' && <AppShellCardContent config={config.appShell} onChange={(u) => updateConfig('appShell', u)} />}
              {card.id === 'login' && <LoginCardContent config={config.login} onChange={(u) => updateConfig('login', u)} />}
              {card.id === 'localization' && <LocalizationCardContent config={config.localization} onChange={(u) => updateConfig('localization', u)} />}
              {card.id === 'domain' && <DomainCardContent config={config.domain} onChange={(u) => updateConfig('domain', u)} orgCode={data.organization.orgCode} />}
            </BrandingCard>
          ))}
        </div>

        <div className="flex flex-wrap justify-between gap-3 pt-4 border-t">
          <div className="flex gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" onClick={handleSaveDraft}><Save className="h-4 w-4 mr-2" />Save Draft</Button>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p>Temporarily save your work-in-progress without leaving this step. You can return and continue editing later.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" onClick={handleSkipBranding}><SkipForward className="h-4 w-4 mr-2" />Skip Branding</Button>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p>Use default MedComply branding instead of custom branding. You can configure branding later from the Admin settings.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button onClick={handleContinue}><ArrowRight className="h-4 w-4 mr-2" />Continue</Button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p>Apply your branding configuration and proceed to the next onboarding step.</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      {/* Right: Live Preview */}
      <div className="w-80 shrink-0">
        <div className="sticky top-4 p-4 rounded-lg border bg-card">
          <h4 className="font-medium mb-3">Live Preview</h4>
          <div className="h-80"><BrandingPreview config={config} /></div>
        </div>
      </div>
    </div>
  );
};
