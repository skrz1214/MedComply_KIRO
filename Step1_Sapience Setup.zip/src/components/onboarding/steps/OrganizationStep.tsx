import React, { useState, useMemo, useEffect } from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { 
  ORG_TYPES, 
  TIMEZONES, 
  FACILITY_COUNT_OPTIONS,
  DEPARTMENT_COUNT_OPTIONS,
  USER_COUNT_OPTIONS,
  ACCREDITOR_OPTIONS,
  CORE_COMPLIANCE_TAGS,
  ADVANCED_COMPLIANCE_TAGS,
  COMPLIANCE_SUGGESTIONS,
  REGULATORY_BODIES,
  US_STATES,
} from '@/types/onboarding';
import { 
  Building2, 
  User, 
  MapPin, 
  Users, 
  Shield, 
  ChevronDown, 
  ChevronUp,
  HelpCircle,
  CheckCircle2,
  AlertCircle,
  Info,
  Lightbulb,
  Sparkles,
  Zap
} from 'lucide-react';
import { cn } from '@/lib/utils';

// Field Label with Tooltip Component
interface FieldLabelProps {
  label: string;
  required?: boolean;
  optional?: boolean;
  recommended?: boolean;
  tooltip: string;
}

const FieldLabel: React.FC<FieldLabelProps> = ({ label, required, optional, recommended, tooltip }) => (
  <div className="flex items-center gap-1.5 mb-1">
    <Label className="mb-0">
      {label}
      {required && <span className="text-destructive ml-1">*</span>}
      {optional && <span className="text-muted-foreground text-xs ml-1">(optional)</span>}
      {recommended && <span className="text-muted-foreground text-xs ml-1">(recommended)</span>}
    </Label>
    <TooltipProvider>
      <Tooltip delayDuration={300}>
        <TooltipTrigger asChild>
          <button type="button" className="text-muted-foreground hover:text-foreground transition-colors">
            <HelpCircle className="w-3.5 h-3.5" />
          </button>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-xs text-xs">
          <p>{tooltip}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  </div>
);

// Smart suggestion component
interface SmartSuggestionProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  variant?: 'info' | 'suggestion' | 'tip';
}

const SmartSuggestion: React.FC<SmartSuggestionProps> = ({ 
  icon, 
  title, 
  description, 
  action,
  variant = 'suggestion'
}) => {
  const variants = {
    info: {
      bg: 'bg-blue-500/10',
      border: 'border-blue-500/30',
      iconColor: 'text-blue-600',
      titleColor: 'text-blue-800',
      descColor: 'text-blue-700/80',
      btnBorder: 'border-blue-500/50',
      btnText: 'text-blue-700',
      btnHover: 'hover:bg-blue-500/10',
    },
    suggestion: {
      bg: 'bg-amber-500/10',
      border: 'border-amber-500/30',
      iconColor: 'text-amber-600',
      titleColor: 'text-amber-800',
      descColor: 'text-amber-700/80',
      btnBorder: 'border-amber-500/50',
      btnText: 'text-amber-700',
      btnHover: 'hover:bg-amber-500/10',
    },
    tip: {
      bg: 'bg-green-500/10',
      border: 'border-green-500/30',
      iconColor: 'text-green-600',
      titleColor: 'text-green-800',
      descColor: 'text-green-700/80',
      btnBorder: 'border-green-500/50',
      btnText: 'text-green-700',
      btnHover: 'hover:bg-green-500/10',
    },
  };

  const v = variants[variant];

  return (
    <div className={cn("p-4 rounded-lg", v.bg, "border", v.border)}>
      <div className="flex items-start gap-3">
        <div className={cn("mt-0.5", v.iconColor)}>
          {icon || <Lightbulb className="w-5 h-5" />}
        </div>
        <div className="flex-1">
          <p className={cn("font-medium", v.titleColor)}>{title}</p>
          <p className={cn("text-sm mt-1", v.descColor)}>{description}</p>
          {action && (
            <Button 
              variant="outline" 
              size="sm" 
              className={cn("mt-3", v.btnBorder, v.btnText, v.btnHover)}
              onClick={action.onClick}
            >
              <Zap className="w-4 h-4 mr-2" />
              {action.label}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

interface SectionProps {
  title: string;
  icon: React.ReactNode;
  isOpen: boolean;
  onToggle: () => void;
  isComplete: boolean;
  children: React.ReactNode;
}

const CollapsibleSection: React.FC<SectionProps> = ({ 
  title, 
  icon, 
  isOpen, 
  onToggle, 
  isComplete,
  children 
}) => (
  <Collapsible open={isOpen} onOpenChange={onToggle}>
    <div className="border border-border rounded-lg overflow-hidden bg-card">
      <CollapsibleTrigger asChild>
        <button className="w-full flex items-center justify-between p-4 hover:bg-muted/50 transition-colors">
          <div className="flex items-center gap-3">
            <div className={cn(
              "w-10 h-10 rounded-lg flex items-center justify-center",
              isComplete ? "bg-green-500/10 text-green-600" : "bg-primary/10 text-primary"
            )}>
              {isComplete ? <CheckCircle2 className="w-5 h-5" /> : icon}
            </div>
            <span className="font-medium text-foreground">{title}</span>
          </div>
          <div className="flex items-center gap-2">
            {isComplete && <span className="text-xs text-green-600 font-medium">Complete</span>}
            {isOpen ? <ChevronUp className="w-5 h-5 text-muted-foreground" /> : <ChevronDown className="w-5 h-5 text-muted-foreground" />}
          </div>
        </button>
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="p-4 pt-0 border-t border-border">
          {children}
        </div>
      </CollapsibleContent>
    </div>
  </Collapsible>
);

interface HelpItemProps {
  field: string;
  description: string;
  example?: string;
}

const HelpItem: React.FC<HelpItemProps> = ({ field, description, example }) => (
  <div className="p-3 rounded-lg bg-muted/30 border border-border/50">
    <p className="font-medium text-sm text-foreground">{field}</p>
    <p className="text-xs text-muted-foreground mt-1">{description}</p>
    {example && (
      <p className="text-xs text-primary mt-1 font-mono">Example: {example}</p>
    )}
  </div>
);

const validateEmail = (email: string): boolean => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};

const validateNPI = (npi: string): boolean => {
  return /^\d{10}$/.test(npi);
};

const validatePhone = (phone: string): boolean => {
  const cleaned = phone.replace(/\D/g, '');
  return cleaned.length >= 10 && cleaned.length <= 15;
};

const validateZip = (zip: string): boolean => {
  return /^\d{5}(-\d{4})?$/.test(zip);
};

// State to timezone mapping
const STATE_TIMEZONE_MAP: Record<string, string> = {
  'Alabama': 'America/Chicago',
  'Alaska': 'America/Anchorage',
  'Arizona': 'America/Phoenix',
  'Arkansas': 'America/Chicago',
  'California': 'America/Los_Angeles',
  'Colorado': 'America/Denver',
  'Connecticut': 'America/New_York',
  'Delaware': 'America/New_York',
  'Florida': 'America/New_York',
  'Georgia': 'America/New_York',
  'Hawaii': 'Pacific/Honolulu',
  'Idaho': 'America/Boise',
  'Illinois': 'America/Chicago',
  'Indiana': 'America/Indiana/Indianapolis',
  'Iowa': 'America/Chicago',
  'Kansas': 'America/Chicago',
  'Kentucky': 'America/Kentucky/Louisville',
  'Louisiana': 'America/Chicago',
  'Maine': 'America/New_York',
  'Maryland': 'America/New_York',
  'Massachusetts': 'America/New_York',
  'Michigan': 'America/Detroit',
  'Minnesota': 'America/Chicago',
  'Mississippi': 'America/Chicago',
  'Missouri': 'America/Chicago',
  'Montana': 'America/Denver',
  'Nebraska': 'America/Chicago',
  'Nevada': 'America/Los_Angeles',
  'New Hampshire': 'America/New_York',
  'New Jersey': 'America/New_York',
  'New Mexico': 'America/Denver',
  'New York': 'America/New_York',
  'North Carolina': 'America/New_York',
  'North Dakota': 'America/Chicago',
  'Ohio': 'America/New_York',
  'Oklahoma': 'America/Chicago',
  'Oregon': 'America/Los_Angeles',
  'Pennsylvania': 'America/New_York',
  'Rhode Island': 'America/New_York',
  'South Carolina': 'America/New_York',
  'South Dakota': 'America/Chicago',
  'Tennessee': 'America/Chicago',
  'Texas': 'America/Chicago',
  'Utah': 'America/Denver',
  'Vermont': 'America/New_York',
  'Virginia': 'America/New_York',
  'Washington': 'America/Los_Angeles',
  'West Virginia': 'America/New_York',
  'Wisconsin': 'America/Chicago',
  'Wyoming': 'America/Denver',
};

// Org type to suggested org code prefix
const ORG_CODE_SUGGESTIONS: Record<string, string> = {
  'Nursing Home / Skilled Nursing Facility (SNF)': 'SNF',
  'Assisted Living Facility (ALF)': 'ALF',
  'Home Health': 'HH',
  'Hospice': 'HSP',
  'Hospital': 'HOSP',
  'Clinic / Ambulatory': 'CLN',
  'Multi-site Provider Network': 'NET',
  'Other': 'ORG',
};

// Org type to size recommendations
const SIZE_RECOMMENDATIONS: Record<string, { facilities: string; departments: string; users: string }> = {
  'Nursing Home / Skilled Nursing Facility (SNF)': { facilities: '1', departments: '6-15', users: '26-100' },
  'Assisted Living Facility (ALF)': { facilities: '1', departments: '1-5', users: '1-25' },
  'Home Health': { facilities: '1', departments: '1-5', users: '26-100' },
  'Hospice': { facilities: '1', departments: '1-5', users: '1-25' },
  'Hospital': { facilities: '2-5', departments: '16+', users: '500+' },
  'Clinic / Ambulatory': { facilities: '1', departments: '1-5', users: '1-25' },
  'Multi-site Provider Network': { facilities: '6-25', departments: '16+', users: '101-500' },
  'Other': { facilities: '1', departments: '1-5', users: '1-25' },
};

// Regulatory body suggestions based on compliance tags
const REGULATORY_SUGGESTIONS: Record<string, string[]> = {
  'hipaa': ['hhs', 'ocr'],
  'cms_general': ['cms'],
  'cms_cops': ['cms'],
  'cms_cfcs': ['cms'],
  'oig': ['oig'],
  'dea_oversight': ['dea'],
  'medication_mgmt': ['fda'],
};

// State-specific DOH regulatory requirements
const STATE_REGULATORY_INFO: Record<string, { dohName: string; dohCode: string; additionalBodies?: string[]; notes?: string }> = {
  'Alabama': { dohName: 'Alabama Department of Public Health', dohCode: 'ADPH', notes: 'Requires state licensure for all healthcare facilities' },
  'Alaska': { dohName: 'Alaska DHSS', dohCode: 'AK-DHSS', notes: 'Remote facility considerations apply' },
  'Arizona': { dohName: 'Arizona DHS', dohCode: 'AZDHS', notes: 'AHCCCS oversight for Medicaid providers' },
  'Arkansas': { dohName: 'Arkansas Department of Health', dohCode: 'ADH' },
  'California': { dohName: 'California DHCS', dohCode: 'CDPH', additionalBodies: ['cal_osha'], notes: 'Cal/OSHA has stricter requirements than federal OSHA' },
  'Colorado': { dohName: 'Colorado CDPHE', dohCode: 'CDPHE', notes: 'PACE program oversight available' },
  'Connecticut': { dohName: 'Connecticut DPH', dohCode: 'CT-DPH', notes: 'Strong patient rights protections' },
  'Delaware': { dohName: 'Delaware DHSS', dohCode: 'DE-DHSS' },
  'Florida': { dohName: 'Florida AHCA', dohCode: 'FL-AHCA', notes: 'Agency for Health Care Administration oversees licensure' },
  'Georgia': { dohName: 'Georgia DCH', dohCode: 'GA-DCH', notes: 'Healthcare Facility Regulation Division' },
  'Hawaii': { dohName: 'Hawaii DOH', dohCode: 'HI-DOH', notes: 'Island-specific facility requirements' },
  'Idaho': { dohName: 'Idaho DHW', dohCode: 'ID-DHW' },
  'Illinois': { dohName: 'Illinois DPH', dohCode: 'IDPH', notes: 'Health Facilities & Services Review Board oversight' },
  'Indiana': { dohName: 'Indiana ISDH', dohCode: 'ISDH' },
  'Iowa': { dohName: 'Iowa DIA', dohCode: 'IA-DIA', notes: 'Health Facilities Division' },
  'Kansas': { dohName: 'Kansas KDHE', dohCode: 'KDHE' },
  'Kentucky': { dohName: 'Kentucky CHFS', dohCode: 'KY-CHFS', notes: 'Office of Inspector General oversight' },
  'Louisiana': { dohName: 'Louisiana LDH', dohCode: 'LDH', notes: 'Health Standards Section' },
  'Maine': { dohName: 'Maine DHHS', dohCode: 'ME-DHHS' },
  'Maryland': { dohName: 'Maryland OHCQ', dohCode: 'MD-OHCQ', notes: 'Office of Health Care Quality' },
  'Massachusetts': { dohName: 'Massachusetts DPH', dohCode: 'MA-DPH', notes: 'Division of Health Care Facility Licensure' },
  'Michigan': { dohName: 'Michigan LARA', dohCode: 'MI-LARA', notes: 'Bureau of Health Care Services' },
  'Minnesota': { dohName: 'Minnesota MDH', dohCode: 'MDH', notes: 'Health Regulation Division' },
  'Mississippi': { dohName: 'Mississippi MSDH', dohCode: 'MSDH' },
  'Missouri': { dohName: 'Missouri DHSS', dohCode: 'MO-DHSS', notes: 'Section for Long Term Care Regulation' },
  'Montana': { dohName: 'Montana DPHHS', dohCode: 'MT-DPHHS' },
  'Nebraska': { dohName: 'Nebraska DHHS', dohCode: 'NE-DHHS' },
  'Nevada': { dohName: 'Nevada DPBH', dohCode: 'NV-DPBH', notes: 'Bureau of Health Care Quality and Compliance' },
  'New Hampshire': { dohName: 'New Hampshire DHHS', dohCode: 'NH-DHHS' },
  'New Jersey': { dohName: 'New Jersey DOH', dohCode: 'NJ-DOH', notes: 'Division of Health Facilities Evaluation and Licensing' },
  'New Mexico': { dohName: 'New Mexico DOH', dohCode: 'NM-DOH' },
  'New York': { dohName: 'New York DOH', dohCode: 'NY-DOH', additionalBodies: ['ny_omig'], notes: 'Office of Medicaid Inspector General (OMIG) oversight' },
  'North Carolina': { dohName: 'North Carolina DHHS', dohCode: 'NC-DHHS', notes: 'Division of Health Service Regulation' },
  'North Dakota': { dohName: 'North Dakota DOH', dohCode: 'ND-DOH' },
  'Ohio': { dohName: 'Ohio ODH', dohCode: 'ODH', notes: 'Division of Quality Assurance' },
  'Oklahoma': { dohName: 'Oklahoma OSDH', dohCode: 'OSDH' },
  'Oregon': { dohName: 'Oregon OHA', dohCode: 'OR-OHA', notes: 'Health Care Regulation and Quality Improvement' },
  'Pennsylvania': { dohName: 'Pennsylvania DOH', dohCode: 'PA-DOH', notes: 'Division of Nursing Care Facilities' },
  'Rhode Island': { dohName: 'Rhode Island DOH', dohCode: 'RI-DOH' },
  'South Carolina': { dohName: 'South Carolina DHEC', dohCode: 'SC-DHEC', notes: 'Healthcare Quality Division' },
  'South Dakota': { dohName: 'South Dakota DOH', dohCode: 'SD-DOH' },
  'Tennessee': { dohName: 'Tennessee TDH', dohCode: 'TN-TDH', notes: 'Division of Health Care Facilities' },
  'Texas': { dohName: 'Texas HHSC', dohCode: 'TX-HHSC', notes: 'Health and Human Services Commission - Long-term Care Regulation' },
  'Utah': { dohName: 'Utah DHHS', dohCode: 'UT-DHHS' },
  'Vermont': { dohName: 'Vermont DVHA', dohCode: 'VT-DVHA' },
  'Virginia': { dohName: 'Virginia VDH', dohCode: 'VA-VDH', notes: 'Office of Licensure and Certification' },
  'Washington': { dohName: 'Washington DOH', dohCode: 'WA-DOH', notes: 'Residential Care Services' },
  'West Virginia': { dohName: 'West Virginia DHHR', dohCode: 'WV-DHHR' },
  'Wisconsin': { dohName: 'Wisconsin DHS', dohCode: 'WI-DHS', notes: 'Division of Quality Assurance' },
  'Wyoming': { dohName: 'Wyoming WDH', dohCode: 'WY-WDH' },
};

export const OrganizationStep: React.FC = () => {
  const { data, updateOrganization, markStepComplete, nextStep, saveDraft } = useOnboarding();
  const org = data.organization;

  const [openSections, setOpenSections] = useState({
    identity: true,
    contact: false,
    location: false,
    size: false,
    compliance: false,
  });

  const [showAdvancedCompliance, setShowAdvancedCompliance] = useState(false);
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const toggleSection = (section: keyof typeof openSections) => {
    setOpenSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const markTouched = (field: string) => {
    setTouched(prev => ({ ...prev, [field]: true }));
  };

  // Get suggested tags based on org type
  const suggestedTags = useMemo(() => {
    if (!org.orgType) return { core: [], advanced: [] };
    return COMPLIANCE_SUGGESTIONS[org.orgType] || { core: [], advanced: [] };
  }, [org.orgType]);

  // Get state-specific DOH info
  const stateRegulatoryInfo = useMemo(() => {
    if (!org.stateProvince) return null;
    return STATE_REGULATORY_INFO[org.stateProvince] || null;
  }, [org.stateProvince]);

  // Get suggested regulatory bodies based on selected compliance tags AND state
  const suggestedRegulatoryBodies = useMemo(() => {
    const allTags = [...(org.coreComplianceTags || []), ...(org.advancedComplianceTags || [])];
    const suggested = new Set<string>();
    
    // Add suggestions based on compliance tags
    allTags.forEach(tag => {
      const bodies = REGULATORY_SUGGESTIONS[tag];
      if (bodies) bodies.forEach(b => suggested.add(b));
    });
    
    // Always suggest HHS and CMS for healthcare providers
    suggested.add('hhs');
    suggested.add('cms');
    
    // Add state-specific suggestions
    if (org.stateProvince) {
      // Always add state DOH
      suggested.add('state_doh');
      
      // Add any additional state-specific bodies
      const stateInfo = STATE_REGULATORY_INFO[org.stateProvince];
      if (stateInfo?.additionalBodies) {
        stateInfo.additionalBodies.forEach(b => suggested.add(b));
      }
    }
    
    return Array.from(suggested);
  }, [org.coreComplianceTags, org.advancedComplianceTags, org.stateProvince]);

  // Apply smart suggestions when org type changes
  useEffect(() => {
    if (org.orgType && !org.suggestedTagsApplied) {
      const suggestions = COMPLIANCE_SUGGESTIONS[org.orgType];
      if (suggestions) {
        updateOrganization({
          coreComplianceTags: suggestions.core,
          advancedComplianceTags: suggestions.advanced,
          suggestedTagsApplied: true,
        });
      }
    }
  }, [org.orgType, org.suggestedTagsApplied, updateOrganization]);

  // Generate suggested org code
  const suggestedOrgCode = useMemo(() => {
    if (!org.orgType || !org.name) return null;
    const prefix = ORG_CODE_SUGGESTIONS[org.orgType] || 'ORG';
    const namePart = org.name.split(' ').slice(0, 2).map(w => w.charAt(0).toUpperCase()).join('');
    return `${prefix}-${namePart}-001`;
  }, [org.orgType, org.name]);

  const toggleCoreTag = (tagId: string) => {
    const currentTags = org.coreComplianceTags || [];
    const updated = currentTags.includes(tagId)
      ? currentTags.filter(t => t !== tagId)
      : [...currentTags, tagId];
    updateOrganization({ coreComplianceTags: updated });
  };

  const toggleAdvancedTag = (tagId: string) => {
    const currentTags = org.advancedComplianceTags || [];
    const updated = currentTags.includes(tagId)
      ? currentTags.filter(t => t !== tagId)
      : [...currentTags, tagId];
    updateOrganization({ advancedComplianceTags: updated });
  };

  const applyAllComplianceSuggestions = () => {
    if (suggestedTags) {
      updateOrganization({
        coreComplianceTags: suggestedTags.core,
        advancedComplianceTags: suggestedTags.advanced,
        suggestedTagsApplied: true,
      });
    }
  };

  const applyRegulatoryBodySuggestions = () => {
    updateOrganization({ regulatoryBodies: suggestedRegulatoryBodies });
  };

  const applySizeRecommendations = () => {
    if (org.orgType) {
      const rec = SIZE_RECOMMENDATIONS[org.orgType];
      if (rec) {
        updateOrganization({
          numberOfFacilities: rec.facilities,
          numberOfDepartments: rec.departments,
          estimatedUsers: rec.users,
          singleFacilityMode: rec.facilities === '1',
        });
      }
    }
  };

  const validation = useMemo(() => {
    const errors: Record<string, string> = {};
    
    // Identity
    if (!org.name?.trim()) errors.name = 'Organization name is required';
    if (!org.orgType) errors.orgType = 'Organization type is required';
    if (!org.orgCode?.trim()) errors.orgCode = 'Org code is required';
    if (org.npi && !validateNPI(org.npi)) errors.npi = 'NPI must be 10 digits';
    
    // Contact
    if (!org.primaryContactName?.trim()) errors.primaryContactName = 'Contact name is required';
    if (!org.primaryContactEmail?.trim()) errors.primaryContactEmail = 'Contact email is required';
    else if (!validateEmail(org.primaryContactEmail)) errors.primaryContactEmail = 'Invalid email format';
    if (org.primaryContactPhone && !validatePhone(org.primaryContactPhone)) {
      errors.primaryContactPhone = 'Invalid phone format';
    }
    
    // Location
    if (!org.addressLine1?.trim()) errors.addressLine1 = 'Address is required';
    if (!org.city?.trim()) errors.city = 'City is required';
    if (!org.stateProvince) errors.stateProvince = 'State is required';
    if (!org.country?.trim()) errors.country = 'Country is required';
    if (!org.zipPostal?.trim()) errors.zipPostal = 'ZIP code is required';
    else if (!validateZip(org.zipPostal)) errors.zipPostal = 'Invalid ZIP format (12345 or 12345-6789)';
    if (!org.timeZone) errors.timeZone = 'Time zone is required';
    
    // Size
    if (!org.numberOfFacilities) errors.numberOfFacilities = 'Number of facilities is required';
    if (!org.numberOfDepartments) errors.numberOfDepartments = 'Number of departments is required';
    if (!org.estimatedUsers) errors.estimatedUsers = 'Estimated users is required';
    
    return errors;
  }, [org]);

  const sectionCompletion = useMemo(() => ({
    identity: !!(org.name && org.orgType && org.orgCode && (!org.npi || validateNPI(org.npi))),
    contact: !!(org.primaryContactName && org.primaryContactEmail && validateEmail(org.primaryContactEmail)),
    location: !!(org.addressLine1 && org.city && org.stateProvince && org.country && org.zipPostal && validateZip(org.zipPostal) && org.timeZone),
    size: !!(org.numberOfFacilities && org.numberOfDepartments && org.estimatedUsers),
    compliance: (org.coreComplianceTags || []).length > 0,
  }), [org]);

  const isFormValid = sectionCompletion.identity && sectionCompletion.contact && sectionCompletion.location && sectionCompletion.size;

  const handleContinue = () => {
    if (isFormValid) {
      updateOrganization({ onboardingStatus: 'in_progress' });
      markStepComplete(1);
      nextStep();
    }
  };

  const getFieldError = (field: string) => {
    if (touched[field] && validation[field]) {
      return validation[field];
    }
    return null;
  };

  // Handle single facility mode toggle
  const handleSingleFacilityToggle = (checked: boolean) => {
    updateOrganization({ 
      singleFacilityMode: checked,
      numberOfFacilities: checked ? '1' : org.numberOfFacilities 
    });
  };

  // Handle state change - auto-suggest timezone
  const handleStateChange = (state: string) => {
    updateOrganization({ stateProvince: state });
    const suggestedTz = STATE_TIMEZONE_MAP[state];
    if (suggestedTz && !org.timeZone) {
      updateOrganization({ timeZone: suggestedTz });
    }
  };

  return (
    <div className="flex gap-6">
      {/* Main Form */}
      <div className="flex-1 space-y-4">
        {/* Identity Section */}
        <CollapsibleSection
          title="Organization Identity"
          icon={<Building2 className="w-5 h-5" />}
          isOpen={openSections.identity}
          onToggle={() => toggleSection('identity')}
          isComplete={sectionCompletion.identity}
        >
          <div className="space-y-4 pt-4">
            {/* Identity Section Guidance */}
            <SmartSuggestion
              icon={<Info className="w-5 h-5" />}
              variant="info"
              title="Getting Started"
              description="Start by selecting your Organization Type. This will automatically configure compliance areas, recommended settings, and suggested values throughout the wizard."
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <FieldLabel 
                  label="Organization Name" 
                  required 
                  tooltip="The official name of your healthcare organization as it appears on legal documents and licenses. This will be displayed throughout the system and on reports."
                />
                <Input 
                  value={org.name || ''} 
                  onChange={e => updateOrganization({ name: e.target.value })}
                  onBlur={() => markTouched('name')}
                  placeholder="Sunrise Senior Living"
                  className={cn(getFieldError('name') && 'border-destructive')}
                />
                {getFieldError('name') && <p className="text-xs text-destructive mt-1">{getFieldError('name')}</p>}
              </div>
              
              <div>
                <FieldLabel 
                  label="Legal Entity Name" 
                  optional 
                  tooltip="The full legal name of your organization if different from the display name (e.g., includes LLC, Inc., Corp.). Used for contracts and legal documents."
                />
                <Input 
                  value={org.legalEntityName || ''} 
                  onChange={e => updateOrganization({ legalEntityName: e.target.value })}
                  placeholder="Sunrise Senior Living, LLC"
                />
              </div>

              <div className="md:col-span-2">
                <FieldLabel 
                  label="Organization Type" 
                  required 
                  tooltip="Select the type that best describes your organization. This drives smart suggestions for compliance areas, regulatory bodies, facility structure, and default configurations throughout the wizard."
                />
                <Select 
                  value={org.orgType || ''} 
                  onValueChange={v => {
                    updateOrganization({ orgType: v, suggestedTagsApplied: false });
                  }}
                >
                  <SelectTrigger className={cn(getFieldError('orgType') && 'border-destructive')}>
                    <SelectValue placeholder="Select your organization type to unlock smart suggestions" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border border-border z-50">
                    {ORG_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
                {getFieldError('orgType') && <p className="text-xs text-destructive mt-1">{getFieldError('orgType')}</p>}
                {org.orgType && (
                  <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    Smart suggestions activated for {org.orgType}
                  </p>
                )}
              </div>

              <div>
                <FieldLabel 
                  label="Industry" 
                  tooltip="Pre-set to Healthcare Provider. This determines the base compliance framework and regulatory context for your organization."
                />
                <Input 
                  value="Healthcare Provider" 
                  disabled 
                  className="bg-muted text-muted-foreground"
                />
              </div>

              <div>
                <FieldLabel 
                  label="Org Code" 
                  required 
                  tooltip="A unique internal identifier for your organization in MedComply. Used for system integrations, reporting, and multi-tenant management. Use uppercase letters, numbers, and hyphens."
                />
                <Input 
                  value={org.orgCode || ''} 
                  onChange={e => updateOrganization({ orgCode: e.target.value.toUpperCase() })}
                  onBlur={() => markTouched('orgCode')}
                  placeholder={suggestedOrgCode || "ABC-SNF-01"}
                  className={cn(getFieldError('orgCode') && 'border-destructive')}
                />
                {getFieldError('orgCode') && <p className="text-xs text-destructive mt-1">{getFieldError('orgCode')}</p>}
                {suggestedOrgCode && !org.orgCode && (
                  <button 
                    type="button"
                    onClick={() => updateOrganization({ orgCode: suggestedOrgCode })}
                    className="text-xs text-primary mt-1 hover:underline flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3" />
                    Use suggested: {suggestedOrgCode}
                  </button>
                )}
              </div>

              <div>
                <FieldLabel 
                  label="NPI" 
                  recommended 
                  tooltip="National Provider Identifier - a 10-digit unique number assigned by CMS. Required for Medicare/Medicaid billing and used in regulatory reporting. You can find your NPI at nppes.cms.hhs.gov."
                />
                <Input 
                  value={org.npi || ''} 
                  onChange={e => updateOrganization({ npi: e.target.value.replace(/\D/g, '').slice(0, 10) })}
                  onBlur={() => markTouched('npi')}
                  placeholder="1234567890"
                  className={cn(getFieldError('npi') && 'border-destructive')}
                />
                {getFieldError('npi') && <p className="text-xs text-destructive mt-1">{getFieldError('npi')}</p>}
              </div>

              <div>
                <FieldLabel 
                  label="Tax ID / EIN" 
                  optional 
                  tooltip="Employer Identification Number assigned by the IRS. Used for tax reporting and some regulatory filings. Stored securely and masked for privacy."
                />
                <Input 
                  type="password"
                  value={org.taxId || ''} 
                  onChange={e => updateOrganization({ taxId: e.target.value })}
                  placeholder="XX-XXXXXXX"
                />
              </div>

              <div>
                <FieldLabel 
                  label="CMS Certification Number (CCN)" 
                  optional 
                  tooltip="A unique identifier assigned by CMS to Medicare/Medicaid certified facilities. Required for SNF/Nursing Homes participating in federal healthcare programs. Format: 6 alphanumeric characters."
                />
                <Input 
                  value={org.ccn || ''} 
                  onChange={e => updateOrganization({ ccn: e.target.value })}
                  placeholder="12A345"
                />
                {org.orgType?.includes('SNF') || org.orgType?.includes('Nursing') ? (
                  <p className="text-xs text-amber-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    Recommended for SNF/Nursing Home facilities
                  </p>
                ) : (
                  <p className="text-xs text-muted-foreground mt-1">Common for SNF/NH facilities</p>
                )}
              </div>

              <div className="md:col-span-2">
                <FieldLabel 
                  label="Accreditor" 
                  optional 
                  tooltip="The organization that provides your facility's accreditation, if applicable. Accreditation demonstrates compliance with quality standards and may be required for certain payer contracts or state requirements."
                />
                <Select 
                  value={org.accreditor || ''} 
                  onValueChange={v => updateOrganization({ accreditor: v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select accreditor if applicable" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border border-border z-50">
                    {ACCREDITOR_OPTIONS.map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}
                  </SelectContent>
                </Select>
                {org.accreditor === 'Other' && (
                  <Input 
                    className="mt-2"
                    value={org.accreditorOther || ''} 
                    onChange={e => updateOrganization({ accreditorOther: e.target.value })}
                    placeholder="Specify accreditor"
                  />
                )}
              </div>
            </div>
          </div>
        </CollapsibleSection>

        {/* Primary Contact Section */}
        <CollapsibleSection
          title="Primary Contact"
          icon={<User className="w-5 h-5" />}
          isOpen={openSections.contact}
          onToggle={() => toggleSection('contact')}
          isComplete={sectionCompletion.contact}
        >
          <div className="space-y-4 pt-4">
            {/* Contact Section Guidance */}
            <SmartSuggestion
              icon={<User className="w-5 h-5" />}
              variant="tip"
              title="Who should be the primary contact?"
              description="The primary contact should be an Org Admin or Compliance Head who will receive system notifications, account updates, and be the main point of contact for MedComply support."
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <FieldLabel 
                  label="Contact Name" 
                  required 
                  tooltip="The primary point of contact for your organization in MedComply. This person will receive system notifications, account updates, and be the main liaison with MedComply support."
                />
                <Input 
                  value={org.primaryContactName || ''} 
                  onChange={e => updateOrganization({ primaryContactName: e.target.value })}
                  onBlur={() => markTouched('primaryContactName')}
                  placeholder="Jane Smith"
                  className={cn(getFieldError('primaryContactName') && 'border-destructive')}
                />
                {getFieldError('primaryContactName') && <p className="text-xs text-destructive mt-1">{getFieldError('primaryContactName')}</p>}
              </div>

              <div>
                <FieldLabel 
                  label="Contact Email" 
                  required 
                  tooltip="Email address for the primary contact. Used for system notifications, password resets, and important account communications. Ensure this is a monitored inbox."
                />
                <Input 
                  type="email"
                  value={org.primaryContactEmail || ''} 
                  onChange={e => updateOrganization({ primaryContactEmail: e.target.value })}
                  onBlur={() => markTouched('primaryContactEmail')}
                  placeholder="jane.smith@sunrise.com"
                  className={cn(getFieldError('primaryContactEmail') && 'border-destructive')}
                />
                {getFieldError('primaryContactEmail') && <p className="text-xs text-destructive mt-1">{getFieldError('primaryContactEmail')}</p>}
              </div>

              <div>
                <FieldLabel 
                  label="Contact Phone" 
                  optional 
                  tooltip="Phone number for the primary contact. Used for urgent support escalations and verification purposes."
                />
                <Input 
                  type="tel"
                  value={org.primaryContactPhone || ''} 
                  onChange={e => updateOrganization({ primaryContactPhone: e.target.value })}
                  onBlur={() => markTouched('primaryContactPhone')}
                  placeholder="(555) 123-4567"
                  className={cn(getFieldError('primaryContactPhone') && 'border-destructive')}
                />
                {getFieldError('primaryContactPhone') && <p className="text-xs text-destructive mt-1">{getFieldError('primaryContactPhone')}</p>}
              </div>

              <div>
                <FieldLabel 
                  label="Implementation Owner" 
                  optional 
                  tooltip="The Sapience team member assigned to help with your implementation. Leave blank if not yet assigned - this can be updated later."
                />
                <Input 
                  value={org.implementationOwner || ''} 
                  onChange={e => updateOrganization({ implementationOwner: e.target.value })}
                  placeholder="Sapience team member"
                />
              </div>

              <div className="md:col-span-2">
                <FieldLabel 
                  label="Secondary Compliance Contact" 
                  optional 
                  tooltip="A backup contact for compliance-related communications. This person will receive copies of important compliance alerts and can act as a backup administrator."
                />
                <Input 
                  value={org.secondaryComplianceContact || ''} 
                  onChange={e => updateOrganization({ secondaryComplianceContact: e.target.value })}
                  placeholder="Secondary contact name and email"
                />
              </div>
            </div>
          </div>
        </CollapsibleSection>

        {/* Location & Time Section */}
        <CollapsibleSection
          title="Address & Time Zone"
          icon={<MapPin className="w-5 h-5" />}
          isOpen={openSections.location}
          onToggle={() => toggleSection('location')}
          isComplete={sectionCompletion.location}
        >
          <div className="space-y-4 pt-4">
            {/* Location Section Guidance */}
            <SmartSuggestion
              icon={<MapPin className="w-5 h-5" />}
              variant="info"
              title="Headquarters Location"
              description="Enter your organization's main headquarters address. Individual facility addresses can be added in Step 3 (Facilities). Selecting a state will auto-suggest the appropriate timezone."
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <FieldLabel 
                  label="HQ Address Line 1" 
                  required 
                  tooltip="The street address of your organization's main headquarters. This is used for official correspondence and regulatory documentation."
                />
                <Input 
                  value={org.addressLine1 || ''} 
                  onChange={e => updateOrganization({ addressLine1: e.target.value })}
                  onBlur={() => markTouched('addressLine1')}
                  placeholder="123 Healthcare Drive"
                  className={cn(getFieldError('addressLine1') && 'border-destructive')}
                />
                {getFieldError('addressLine1') && <p className="text-xs text-destructive mt-1">{getFieldError('addressLine1')}</p>}
              </div>

              <div className="md:col-span-2">
                <FieldLabel 
                  label="Address Line 2" 
                  optional 
                  tooltip="Additional address information like suite number, building name, or floor. Leave blank if not applicable."
                />
                <Input 
                  value={org.addressLine2 || ''} 
                  onChange={e => updateOrganization({ addressLine2: e.target.value })}
                  placeholder="Suite 100"
                />
              </div>

              <div>
                <FieldLabel 
                  label="City" 
                  required 
                  tooltip="The city where your headquarters is located."
                />
                <Input 
                  value={org.city || ''} 
                  onChange={e => updateOrganization({ city: e.target.value })}
                  onBlur={() => markTouched('city')}
                  placeholder="Austin"
                  className={cn(getFieldError('city') && 'border-destructive')}
                />
                {getFieldError('city') && <p className="text-xs text-destructive mt-1">{getFieldError('city')}</p>}
              </div>

              <div>
                <FieldLabel 
                  label="State/Province" 
                  required 
                  tooltip="Select your state. This determines which state-specific regulations apply to your organization and will auto-suggest the appropriate timezone."
                />
                <Select 
                  value={org.stateProvince || ''} 
                  onValueChange={handleStateChange}
                >
                  <SelectTrigger className={cn(getFieldError('stateProvince') && 'border-destructive')}>
                    <SelectValue placeholder="Select state" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border border-border z-50 max-h-[200px]">
                    {US_STATES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
                {getFieldError('stateProvince') && <p className="text-xs text-destructive mt-1">{getFieldError('stateProvince')}</p>}
              </div>

              <div>
                <FieldLabel 
                  label="Country" 
                  required 
                  tooltip="The country where your organization is located. Currently optimized for US healthcare regulations."
                />
                <Input 
                  value={org.country || 'United States'} 
                  onChange={e => updateOrganization({ country: e.target.value })}
                  onBlur={() => markTouched('country')}
                  className={cn(getFieldError('country') && 'border-destructive')}
                />
                {getFieldError('country') && <p className="text-xs text-destructive mt-1">{getFieldError('country')}</p>}
              </div>

              <div>
                <FieldLabel 
                  label="ZIP/Postal Code" 
                  required 
                  tooltip="Your 5-digit ZIP code (or ZIP+4 format). Used for geographic reporting and state-specific compliance requirements."
                />
                <Input 
                  value={org.zipPostal || ''} 
                  onChange={e => updateOrganization({ zipPostal: e.target.value })}
                  onBlur={() => markTouched('zipPostal')}
                  placeholder="78701"
                  className={cn(getFieldError('zipPostal') && 'border-destructive')}
                />
                {getFieldError('zipPostal') && <p className="text-xs text-destructive mt-1">{getFieldError('zipPostal')}</p>}
              </div>

              <div className="md:col-span-2">
                <FieldLabel 
                  label="Time Zone" 
                  required 
                  tooltip="Your organization's primary timezone. Used for scheduling, deadlines, audit timestamps, and report generation. Auto-suggested based on your state selection."
                />
                <Select 
                  value={org.timeZone || ''} 
                  onValueChange={v => updateOrganization({ timeZone: v })}
                >
                  <SelectTrigger className={cn(getFieldError('timeZone') && 'border-destructive')}>
                    <SelectValue placeholder="Select timezone" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border border-border z-50">
                    {TIMEZONES.map(tz => <SelectItem key={tz} value={tz}>{tz}</SelectItem>)}
                  </SelectContent>
                </Select>
                {getFieldError('timeZone') && <p className="text-xs text-destructive mt-1">{getFieldError('timeZone')}</p>}
                {org.stateProvince && org.timeZone && (
                  <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    Timezone set for {org.stateProvince}
                  </p>
                )}
              </div>
            </div>
          </div>
        </CollapsibleSection>

        {/* Size & Structure Section */}
        <CollapsibleSection
          title="Size & Structure"
          icon={<Users className="w-5 h-5" />}
          isOpen={openSections.size}
          onToggle={() => toggleSection('size')}
          isComplete={sectionCompletion.size}
        >
          <div className="space-y-6 pt-4">
            {/* Size Section Guidance with Smart Apply */}
            {org.orgType && (
              <SmartSuggestion
                icon={<Sparkles className="w-5 h-5" />}
                variant="suggestion"
                title={`Recommended settings for ${org.orgType}`}
                description={`Based on typical ${org.orgType} organizations, we recommend: ${SIZE_RECOMMENDATIONS[org.orgType]?.facilities || '1'} facility, ${SIZE_RECOMMENDATIONS[org.orgType]?.departments || '1-5'} departments, and ${SIZE_RECOMMENDATIONS[org.orgType]?.users || '1-25'} users.`}
                action={{
                  label: 'Apply Recommendations',
                  onClick: applySizeRecommendations,
                }}
              />
            )}

            {!org.orgType && (
              <SmartSuggestion
                icon={<Info className="w-5 h-5" />}
                variant="info"
                title="Select Organization Type First"
                description="Go back to the Identity section and select your Organization Type to receive personalized size recommendations."
              />
            )}

            {/* Single Facility Mode Toggle */}
            <div className="flex items-start gap-4 p-4 rounded-lg bg-primary/5 border border-primary/20">
              <Switch 
                checked={org.singleFacilityMode || false}
                onCheckedChange={handleSingleFacilityToggle}
              />
              <div className="flex-1">
                <Label className="mb-0 font-medium">Single Facility Mode</Label>
                <p className="text-sm text-muted-foreground mt-1">
                  Enable this if your organization has only one physical location.
                </p>
                {org.singleFacilityMode && (
                  <div className="flex items-start gap-2 mt-2 p-2 rounded bg-blue-500/10 text-blue-700">
                    <Info className="w-4 h-4 mt-0.5 shrink-0" />
                    <p className="text-xs">
                      We will auto-create a default facility in Step 3. You can rename it later.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Size Fields */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <FieldLabel 
                  label="Number of Facilities" 
                  required 
                  tooltip="How many physical locations does your organization operate? This determines how facilities will be configured in Step 3 and affects routing for issues, audits, and reports."
                />
                <Select 
                  value={org.numberOfFacilities || ''} 
                  onValueChange={v => updateOrganization({ numberOfFacilities: v, singleFacilityMode: v === '1' })}
                  disabled={org.singleFacilityMode}
                >
                  <SelectTrigger className={cn(getFieldError('numberOfFacilities') && 'border-destructive')}>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border border-border z-50">
                    {FACILITY_COUNT_OPTIONS.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <FieldLabel 
                  label="Number of Departments" 
                  required 
                  tooltip="How many departments will use MedComply? Departments are used to organize users, assign responsibilities, and route compliance items. Common examples: Nursing, Dietary, HR, Maintenance."
                />
                <Select 
                  value={org.numberOfDepartments || ''} 
                  onValueChange={v => updateOrganization({ numberOfDepartments: v })}
                >
                  <SelectTrigger className={cn(getFieldError('numberOfDepartments') && 'border-destructive')}>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border border-border z-50">
                    {DEPARTMENT_COUNT_OPTIONS.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <FieldLabel 
                  label="Estimated Users" 
                  required 
                  tooltip="Approximately how many staff members will access MedComply? This helps configure license requirements and determine appropriate access levels. You can add more users later."
                />
                <Select 
                  value={org.estimatedUsers || ''} 
                  onValueChange={v => updateOrganization({ estimatedUsers: v })}
                >
                  <SelectTrigger className={cn(getFieldError('estimatedUsers') && 'border-destructive')}>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border border-border z-50">
                    {USER_COUNT_OPTIONS.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Parent Organization */}
            <div className="p-4 rounded-lg bg-muted/30 border border-border/50 space-y-4">
              <div className="flex items-start gap-4">
                <Switch 
                  checked={org.hasParentOrg || false}
                  onCheckedChange={v => updateOrganization({ hasParentOrg: v, parentOrgName: v ? org.parentOrgName : '' })}
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <Label className="mb-0 font-medium">Has Parent Organization?</Label>
                    <TooltipProvider>
                      <Tooltip delayDuration={300}>
                        <TooltipTrigger asChild>
                          <button type="button" className="text-muted-foreground hover:text-foreground transition-colors">
                            <HelpCircle className="w-3.5 h-3.5" />
                          </button>
                        </TooltipTrigger>
                        <TooltipContent side="top" className="max-w-xs text-xs">
                          <p>Enable if your organization belongs to a larger health system or corporate parent. This is different from having multiple facilities within your own organization.</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    Enable if your org belongs to a larger health system or corporate entity.
                  </p>
                </div>
              </div>
              
              {org.hasParentOrg && (
                <div className="pl-12 space-y-4 pt-2 border-t border-border/50">
                  <div className="flex items-start gap-2 p-3 rounded bg-blue-500/10 border border-blue-500/20">
                    <Info className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                    <div className="text-xs text-muted-foreground">
                      <strong className="text-foreground">Organization Hierarchy:</strong> Your org belongs to a parent system. This enables:
                      <ul className="mt-1 space-y-0.5">
                        <li>• Aggregated compliance reporting to parent</li>
                        <li>• Shared policies and templates (if configured)</li>
                        <li>• Cross-org benchmarking dashboards</li>
                      </ul>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <FieldLabel 
                        label="Parent Organization Name" 
                        required 
                        tooltip="The name of the health system or corporate parent that your organization reports to."
                      />
                      <Input 
                        value={org.parentOrgName || ''} 
                        onChange={e => updateOrganization({ parentOrgName: e.target.value })}
                        placeholder="e.g., National Care Corporation"
                      />
                    </div>
                    <div>
                      <FieldLabel 
                        label="Parent Org Code" 
                        optional 
                        tooltip="If known, the system code for the parent organization. This enables automatic linking if the parent is already in MedComply."
                      />
                      <Input 
                        value={org.parentOrgCode || ''} 
                        onChange={e => updateOrganization({ parentOrgCode: e.target.value })}
                        placeholder="e.g., NCC-001"
                      />
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 p-2 rounded bg-amber-500/10 border border-amber-500/20">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                    <p className="text-xs text-muted-foreground">
                      <strong className="text-foreground">Note:</strong> This defines your org's place in a <em>corporate</em> hierarchy. You can still have multiple facilities with parent-child relationships <em>within</em> your organization — configure that in Step 4 (Facilities).
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </CollapsibleSection>

        {/* Compliance Scope Section */}
        <CollapsibleSection
          title="Compliance Scope & Regulatory Oversight"
          icon={<Shield className="w-5 h-5" />}
          isOpen={openSections.compliance}
          onToggle={() => toggleSection('compliance')}
          isComplete={sectionCompletion.compliance}
        >
          <div className="space-y-6 pt-4">
            {/* Smart Suggestions Banner */}
            {org.orgType && suggestedTags.core.length > 0 && (
              <SmartSuggestion
                icon={<Sparkles className="w-5 h-5" />}
                variant="suggestion"
                title={`Suggested compliance areas for ${org.orgType}`}
                description="Based on your organization type, we have pre-selected relevant compliance areas and regulatory bodies. Review and adjust as needed."
                action={{
                  label: 'Apply All Suggestions',
                  onClick: () => {
                    applyAllComplianceSuggestions();
                    applyRegulatoryBodySuggestions();
                  },
                }}
              />
            )}

            {!org.orgType && (
              <SmartSuggestion
                icon={<Info className="w-5 h-5" />}
                variant="info"
                title="Select Organization Type First"
                description="Go back to the Identity section and select your Organization Type to receive smart compliance suggestions."
              />
            )}

            {/* Core Compliance Tags */}
            <div>
              <h4 className="text-sm font-medium text-foreground mb-3 flex items-center gap-2">
                <Shield className="w-4 h-4 text-primary" />
                Core Compliance Areas
              </h4>
              <p className="text-xs text-muted-foreground mb-3">
                These tags drive default libraries, dashboards, and reporting filters later.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {CORE_COMPLIANCE_TAGS.map(tag => (
                  <div 
                    key={tag.id} 
                    className={cn(
                      "flex items-center gap-3 p-3 rounded-lg border transition-colors cursor-pointer",
                      (org.coreComplianceTags || []).includes(tag.id)
                        ? "bg-primary/10 border-primary/30"
                        : "bg-muted/30 border-border/50 hover:bg-muted/50"
                    )}
                    onClick={() => toggleCoreTag(tag.id)}
                  >
                    <Checkbox 
                      checked={(org.coreComplianceTags || []).includes(tag.id)}
                      onCheckedChange={() => toggleCoreTag(tag.id)}
                    />
                    <Label className="mb-0 cursor-pointer font-normal text-sm">{tag.label}</Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Advanced Compliance Tags */}
            <Collapsible open={showAdvancedCompliance} onOpenChange={setShowAdvancedCompliance}>
              <CollapsibleTrigger asChild>
                <button className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                  {showAdvancedCompliance ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  More compliance areas (Advanced)
                </button>
              </CollapsibleTrigger>
              <CollapsibleContent className="mt-4">
                <div className="space-y-6">
                  {Object.entries(ADVANCED_COMPLIANCE_TAGS).map(([key, group]) => (
                    <div key={key}>
                      <h5 className="text-sm font-medium text-foreground mb-2">{group.label}</h5>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {group.tags.map(tag => (
                          <div 
                            key={tag.id} 
                            className={cn(
                              "flex items-center gap-3 p-3 rounded-lg border transition-colors cursor-pointer",
                              (org.advancedComplianceTags || []).includes(tag.id)
                                ? "bg-primary/10 border-primary/30"
                                : "bg-muted/30 border-border/50 hover:bg-muted/50"
                            )}
                            onClick={() => toggleAdvancedTag(tag.id)}
                          >
                            <Checkbox 
                              checked={(org.advancedComplianceTags || []).includes(tag.id)}
                              onCheckedChange={() => toggleAdvancedTag(tag.id)}
                            />
                            <Label className="mb-0 cursor-pointer font-normal text-sm">{tag.label}</Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CollapsibleContent>
            </Collapsible>

            {/* Regulatory Oversight Section */}
            <div className="pt-4 border-t border-border">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="text-sm font-medium text-foreground flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-primary" />
                    Regulatory Oversight
                  </h4>
                  <p className="text-xs text-muted-foreground mt-1">
                    Select the regulatory bodies that oversee your organization.
                  </p>
                </div>
                {suggestedRegulatoryBodies.length > 0 && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={applyRegulatoryBodySuggestions}
                    className="text-xs"
                  >
                    <Sparkles className="w-3 h-3 mr-1" />
                    Apply Suggested ({suggestedRegulatoryBodies.length})
                  </Button>
                )}
              </div>

              {/* State-Specific DOH Info */}
              {stateRegulatoryInfo && (
                <div className="mb-4 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-blue-600 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-blue-700">
                        {org.stateProvince} State Oversight: {stateRegulatoryInfo.dohName}
                      </p>
                      <p className="text-xs text-blue-600 mt-1">
                        Code: {stateRegulatoryInfo.dohCode}
                        {stateRegulatoryInfo.notes && ` • ${stateRegulatoryInfo.notes}`}
                      </p>
                      {stateRegulatoryInfo.additionalBodies && stateRegulatoryInfo.additionalBodies.length > 0 && (
                        <p className="text-xs text-blue-600 mt-1">
                          Additional state agencies: {stateRegulatoryInfo.additionalBodies.map(b => 
                            b === 'cal_osha' ? 'Cal/OSHA' : 
                            b === 'ny_omig' ? 'NY OMIG' : b
                          ).join(', ')}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {REGULATORY_BODIES.map(body => (
                  <div 
                    key={body.id} 
                    className={cn(
                      "flex items-center gap-3 p-3 rounded-lg border transition-colors cursor-pointer",
                      (org.regulatoryBodies || []).includes(body.id)
                        ? "bg-primary/10 border-primary/30"
                        : suggestedRegulatoryBodies.includes(body.id)
                          ? "bg-amber-500/5 border-amber-500/20 hover:bg-amber-500/10"
                          : "bg-muted/30 border-border/50 hover:bg-muted/50"
                    )}
                    onClick={() => {
                      const currentBodies = org.regulatoryBodies || [];
                      const updated = currentBodies.includes(body.id)
                        ? currentBodies.filter(b => b !== body.id)
                        : [...currentBodies, body.id];
                      updateOrganization({ regulatoryBodies: updated });
                    }}
                  >
                    <Checkbox 
                      checked={(org.regulatoryBodies || []).includes(body.id)}
                      onCheckedChange={() => {
                        const currentBodies = org.regulatoryBodies || [];
                        const updated = currentBodies.includes(body.id)
                          ? currentBodies.filter(b => b !== body.id)
                          : [...currentBodies, body.id];
                        updateOrganization({ regulatoryBodies: updated });
                      }}
                    />
                    <div>
                      <Label className="mb-0 cursor-pointer font-medium text-sm">{body.abbreviation}</Label>
                      <p className="text-xs text-muted-foreground">{body.name}</p>
                    </div>
                    {suggestedRegulatoryBodies.includes(body.id) && !(org.regulatoryBodies || []).includes(body.id) && (
                      <span className="ml-auto text-xs text-amber-600 flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        Suggested
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Selected Tags Summary */}
            {((org.coreComplianceTags || []).length > 0 || (org.advancedComplianceTags || []).length > 0 || (org.regulatoryBodies || []).length > 0) && (
              <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                <p className="text-sm font-medium text-green-700 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  {(org.coreComplianceTags || []).length + (org.advancedComplianceTags || []).length} compliance areas & {(org.regulatoryBodies || []).length} regulatory bodies selected
                </p>
              </div>
            )}
          </div>
        </CollapsibleSection>

        {/* Form Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-border">
          <div className="text-sm text-muted-foreground">
            {Object.values(sectionCompletion).filter(Boolean).length} of 5 sections complete
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={saveDraft}>
              Save Draft
            </Button>
            <Button 
              onClick={handleContinue}
              disabled={!isFormValid}
            >
              Continue
            </Button>
          </div>
        </div>
      </div>

      {/* Help Panel */}
      <div className="hidden xl:block w-80 shrink-0">
        <div className="sticky top-4 p-4 rounded-lg border border-border bg-card">
          <div className="flex items-center gap-2 mb-4">
            <HelpCircle className="w-5 h-5 text-primary" />
            <h3 className="font-semibold text-foreground">Help & Examples</h3>
          </div>
          
          <div className="space-y-3">
            <HelpItem 
              field="Organization Name"
              description="The public-facing name of your healthcare organization."
              example="Sunrise Senior Living Center"
            />
            <HelpItem 
              field="Org Code"
              description="A unique internal identifier for this tenant in MedComply. Use alphanumeric characters and hyphens."
              example="SUN-SNF-001"
            />
            <HelpItem 
              field="NPI (National Provider Identifier)"
              description="10-digit unique identifier for healthcare providers. Required for billing and regulatory reporting."
              example="1234567890"
            />
            <HelpItem 
              field="CCN (CMS Certification Number)"
              description="Identifier assigned by CMS for certified providers. Common for SNF/NH facilities."
              example="12A345"
            />
            <HelpItem 
              field="Accreditor"
              description="The organization that provides your facility accreditation, if applicable."
            />
            <HelpItem 
              field="Compliance Scope Tags"
              description="Select the regulatory frameworks your organization must comply with. Smart suggestions are provided based on your organization type."
            />
          </div>

          <div className="mt-4 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-amber-700">Required Fields</p>
                <p className="text-xs text-amber-600/80 mt-1">
                  Fields marked with * must be completed before continuing to the next step.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
