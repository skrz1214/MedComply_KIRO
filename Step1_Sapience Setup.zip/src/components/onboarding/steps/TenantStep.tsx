import React from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronDown } from 'lucide-react';
import { DATA_RESIDENCY_REGIONS } from '@/types/onboarding';

export const TenantStep: React.FC = () => {
  const { data, updateTenantSettings, markStepComplete, nextStep } = useOnboarding();
  const settings = data.tenantSettings;

  return (
    <div className="space-y-6">
      <div className="form-section">
        <h3 className="form-section-title">Licensing & Access</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label>License Tier <span className="required-indicator">*</span></Label>
            <Select value={settings.licenseTier || 'premium'} onValueChange={v => updateTenantSettings({ licenseTier: v as any })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="basic">Basic</SelectItem>
                <SelectItem value="premium">Premium</SelectItem>
                <SelectItem value="enterprise">Enterprise</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Max Users Allowed <span className="required-indicator">*</span></Label>
            <Input type="number" value={settings.maxUsersAllowed || 50} onChange={e => updateTenantSettings({ maxUsersAllowed: parseInt(e.target.value) })} />
          </div>
          <div>
            <Label>Data Residency Region <span className="required-indicator">*</span></Label>
            <Select value={settings.dataResidencyRegion || ''} onValueChange={v => updateTenantSettings({ dataResidencyRegion: v })}>
              <SelectTrigger><SelectValue placeholder="Select region" /></SelectTrigger>
              <SelectContent>{DATA_RESIDENCY_REGIONS.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>
      </div>
      <Collapsible>
        <div className="form-section">
          <CollapsibleTrigger className="flex items-center justify-between w-full">
            <h3 className="form-section-title mb-0">Advanced: Parent/Child Hierarchy</h3>
            <ChevronDown className="w-5 h-5 text-muted-foreground" />
          </CollapsibleTrigger>
          <CollapsibleContent className="pt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Organization Type</Label>
                <Select value={settings.orgType || 'standalone'} onValueChange={v => updateTenantSettings({ orgType: v as any })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standalone">Standalone</SelectItem>
                    <SelectItem value="parent">Parent</SelectItem>
                    <SelectItem value="child">Child</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg border border-border">
                <Label>Admin Delegation Allowed</Label>
                <Switch checked={settings.adminDelegationAllowed} onCheckedChange={v => updateTenantSettings({ adminDelegationAllowed: v })} />
              </div>
            </div>
          </CollapsibleContent>
        </div>
      </Collapsible>
      <div className="flex justify-end"><Button onClick={() => { markStepComplete(3); nextStep(); }}>Continue</Button></div>
    </div>
  );
};
