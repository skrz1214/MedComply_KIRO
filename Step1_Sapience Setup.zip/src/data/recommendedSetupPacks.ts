// Recommended Setup Packs for Onboarding
// Deterministic mapping based on provider type, oversight bodies, and compliance tags

export interface RecommendedItem {
  id: string;
  code: string;
  name: string;
  description?: string;
  category?: string;
}

export interface PackSection {
  id: string;
  title: string;
  description: string;
  whyRecommended: string;
  items: RecommendedItem[];
  addCount: number;
  updateCount: number;
}

export interface ChangePlan {
  dashboard: PackSection;
  lovDefaults: PackSection;
  citationsDefaults: PackSection | null;
  enforcementDefaults: PackSection | null;
  auditDefaults: PackSection | null;
  riskDefaults: PackSection | null;
  capaDefaults: PackSection | null;
  documentsDefaults: PackSection | null;
}

// Base Provider Pack - applied to all organizations
export const BASE_PROVIDER_PACK = {
  dashboard: {
    kpiTiles: [
      { id: 'open_issues', code: 'OPEN_ISSUES', name: 'Open Issues', description: 'Count of open compliance issues' },
      { id: 'overdue_actions', code: 'OVERDUE_ACTIONS', name: 'Overdue Actions', description: 'Actions past their due date' },
      { id: 'pending_reviews', code: 'PENDING_REVIEWS', name: 'Pending Reviews', description: 'Items awaiting review' },
      { id: 'completion_rate', code: 'COMPLETION_RATE', name: 'Completion Rate', description: 'Overall task completion %' },
    ],
    widgets: [
      { id: 'at_risk_now', code: 'AT_RISK_NOW', name: 'At Risk Now', description: 'Critical items requiring attention' },
      { id: 'upcoming_deadlines', code: 'UPCOMING_DEADLINES', name: 'Upcoming Deadlines', description: '7-day deadline view' },
      { id: 'recent_activity', code: 'RECENT_ACTIVITY', name: 'Recent Activity', description: 'Activity feed' },
    ],
  },
  lovs: {
    shared: [
      { id: 'severity', code: 'SEVERITY', name: 'Severity Levels', description: 'Critical, Major, Moderate, Minor' },
      { id: 'priority', code: 'PRIORITY', name: 'Priority Levels', description: 'Critical, High, Medium, Low' },
      { id: 'evidence_types', code: 'EVIDENCE_TYPES', name: 'Evidence Types', description: 'Document, Photo, Video, etc.' },
      { id: 'closure_reasons', code: 'CLOSURE_REASONS', name: 'Closure Reasons', description: 'Resolved, Not Applicable, etc.' },
      { id: 'status_general', code: 'STATUS_GENERAL', name: 'General Status', description: 'Open, In Progress, Closed' },
    ],
  },
};

// Provider Type Packs
export const PROVIDER_TYPE_PACKS: Record<string, {
  dashboard: RecommendedItem[];
  lovs: RecommendedItem[];
  citations: RecommendedItem[];
  enforcement: RecommendedItem[];
  audit: RecommendedItem[];
  risk: RecommendedItem[];
  capa: RecommendedItem[];
}> = {
  'Nursing Home / Skilled Nursing Facility (SNF)': {
    dashboard: [
      { id: 'snf_survey_tracker', code: 'SURVEY_TRACKER', name: 'Survey Readiness Tracker' },
      { id: 'snf_staffing_compliance', code: 'STAFFING_COMPLIANCE', name: 'Staffing Compliance Widget' },
      { id: 'snf_infection_dashboard', code: 'INFECTION_DASHBOARD', name: 'Infection Control Dashboard' },
    ],
    lovs: [
      { id: 'snf_deficiency_tags', code: 'DEFICIENCY_TAGS', name: 'F-Tag Deficiency Categories', description: 'CMS F-Tag based deficiencies' },
      { id: 'snf_resident_rights', code: 'RESIDENT_RIGHTS_CATS', name: 'Resident Rights Categories' },
      { id: 'snf_care_areas', code: 'CARE_AREAS', name: 'Care Area Categories' },
    ],
    citations: [
      { id: 'snf_ftag_library', code: 'FTAG_LIBRARY', name: 'F-Tag Citation Library', category: 'Federal' },
      { id: 'snf_state_citations', code: 'STATE_CITATIONS', name: 'State Survey Citations', category: 'State' },
      { id: 'snf_iij_citations', code: 'IIJ_CITATIONS', name: 'IIJ Citations', category: 'Serious Deficiency' },
    ],
    enforcement: [
      { id: 'snf_cms_deadlines', code: 'CMS_DEADLINES', name: 'CMS Remedy Deadline Templates' },
      { id: 'snf_pod_templates', code: 'POD_TEMPLATES', name: 'Plan of Correction Templates' },
    ],
    audit: [
      { id: 'snf_infection_audit', code: 'INFECTION_AUDIT', name: 'Infection Control Audit Template' },
      { id: 'snf_life_safety_audit', code: 'LIFE_SAFETY_AUDIT', name: 'Life Safety Audit Template' },
      { id: 'snf_resident_rights_audit', code: 'RESIDENT_RIGHTS_AUDIT', name: 'Resident Rights Audit Template' },
      { id: 'snf_qapi_audit', code: 'QAPI_AUDIT', name: 'QAPI Audit Template' },
    ],
    risk: [
      { id: 'snf_fall_risk', code: 'FALL_RISK', name: 'Fall Risk Categories' },
      { id: 'snf_pressure_ulcer', code: 'PRESSURE_ULCER', name: 'Pressure Ulcer Risk' },
    ],
    capa: [
      { id: 'snf_capa_statuses', code: 'CAPA_STATUSES', name: 'CAPA Status Values' },
      { id: 'snf_rca_methods', code: 'RCA_METHODS', name: 'Root Cause Analysis Methods' },
    ],
  },
  'Assisted Living Facility (ALF)': {
    dashboard: [
      { id: 'alf_state_compliance', code: 'STATE_COMPLIANCE', name: 'State Compliance Tracker' },
      { id: 'alf_resident_safety', code: 'RESIDENT_SAFETY', name: 'Resident Safety Widget' },
    ],
    lovs: [
      { id: 'alf_deficiency_cats', code: 'ALF_DEFICIENCY_CATS', name: 'ALF Deficiency Categories' },
      { id: 'alf_resident_cats', code: 'ALF_RESIDENT_CATS', name: 'Resident Service Categories' },
    ],
    citations: [
      { id: 'alf_state_citations', code: 'ALF_STATE_CITATIONS', name: 'State ALF Citations Library' },
    ],
    enforcement: [
      { id: 'alf_state_deadlines', code: 'ALF_STATE_DEADLINES', name: 'State Compliance Deadline Templates' },
    ],
    audit: [
      { id: 'alf_safety_audit', code: 'ALF_SAFETY_AUDIT', name: 'Safety Audit Template' },
      { id: 'alf_rights_audit', code: 'ALF_RIGHTS_AUDIT', name: 'Resident Rights Audit' },
    ],
    risk: [
      { id: 'alf_risk_cats', code: 'ALF_RISK_CATS', name: 'ALF Risk Categories' },
    ],
    capa: [
      { id: 'alf_capa_statuses', code: 'ALF_CAPA_STATUSES', name: 'CAPA Status Values' },
    ],
  },
  'Hospital': {
    dashboard: [
      { id: 'hospital_accreditation', code: 'ACCREDITATION_TRACKER', name: 'Accreditation Readiness Tracker' },
      { id: 'hospital_sentinel', code: 'SENTINEL_EVENTS', name: 'Sentinel Events Widget' },
      { id: 'hospital_quality', code: 'QUALITY_METRICS', name: 'Quality Metrics Dashboard' },
    ],
    lovs: [
      { id: 'hospital_cop_tags', code: 'COP_TAGS', name: 'Conditions of Participation Tags' },
      { id: 'hospital_quality_cats', code: 'QUALITY_CATS', name: 'Quality Measure Categories' },
      { id: 'hospital_event_types', code: 'EVENT_TYPES', name: 'Event Type Categories' },
    ],
    citations: [
      { id: 'hospital_cop_citations', code: 'COP_CITATIONS', name: 'CoP Citation Library' },
      { id: 'hospital_tjc_citations', code: 'TJC_CITATIONS', name: 'TJC Standards Citations' },
    ],
    enforcement: [
      { id: 'hospital_cms_deadlines', code: 'CMS_DEADLINES', name: 'CMS Hospital Deadlines' },
      { id: 'hospital_tjc_deadlines', code: 'TJC_DEADLINES', name: 'TJC Standards Deadlines' },
    ],
    audit: [
      { id: 'hospital_infection_audit', code: 'HOSPITAL_INFECTION', name: 'Infection Control Audit' },
      { id: 'hospital_medication_audit', code: 'MEDICATION_AUDIT', name: 'Medication Management Audit' },
      { id: 'hospital_patient_safety', code: 'PATIENT_SAFETY_AUDIT', name: 'Patient Safety Audit' },
    ],
    risk: [
      { id: 'hospital_risk_cats', code: 'HOSPITAL_RISK_CATS', name: 'Hospital Risk Categories' },
      { id: 'hospital_harm_scale', code: 'HARM_SCALE', name: 'Patient Harm Scale' },
    ],
    capa: [
      { id: 'hospital_capa', code: 'HOSPITAL_CAPA', name: 'Hospital CAPA Templates' },
    ],
  },
  'Home Health': {
    dashboard: [
      { id: 'hh_cfc_tracker', code: 'CFC_TRACKER', name: 'CfC Compliance Tracker' },
      { id: 'hh_visit_compliance', code: 'VISIT_COMPLIANCE', name: 'Visit Compliance Widget' },
    ],
    lovs: [
      { id: 'hh_cfc_tags', code: 'CFC_TAGS', name: 'Conditions for Coverage Tags' },
      { id: 'hh_service_cats', code: 'HH_SERVICE_CATS', name: 'Service Categories' },
    ],
    citations: [
      { id: 'hh_cfc_citations', code: 'CFC_CITATIONS', name: 'CfC Citation Library' },
    ],
    enforcement: [
      { id: 'hh_cfc_deadlines', code: 'CFC_DEADLINES', name: 'CfC Compliance Deadlines' },
    ],
    audit: [
      { id: 'hh_clinical_audit', code: 'HH_CLINICAL_AUDIT', name: 'Clinical Care Audit' },
      { id: 'hh_documentation_audit', code: 'HH_DOC_AUDIT', name: 'Documentation Audit' },
    ],
    risk: [
      { id: 'hh_risk_cats', code: 'HH_RISK_CATS', name: 'Home Health Risk Categories' },
    ],
    capa: [
      { id: 'hh_capa', code: 'HH_CAPA', name: 'Home Health CAPA Templates' },
    ],
  },
  'Hospice': {
    dashboard: [
      { id: 'hospice_cfc_tracker', code: 'HOSPICE_CFC_TRACKER', name: 'Hospice CfC Tracker' },
      { id: 'hospice_quality', code: 'HOSPICE_QUALITY', name: 'Hospice Quality Metrics' },
    ],
    lovs: [
      { id: 'hospice_cfc_tags', code: 'HOSPICE_CFC_TAGS', name: 'Hospice CfC Tags' },
      { id: 'hospice_care_levels', code: 'HOSPICE_CARE_LEVELS', name: 'Care Level Categories' },
    ],
    citations: [
      { id: 'hospice_cfc_citations', code: 'HOSPICE_CFC_CITATIONS', name: 'Hospice CfC Citations' },
    ],
    enforcement: [
      { id: 'hospice_deadlines', code: 'HOSPICE_DEADLINES', name: 'Hospice Compliance Deadlines' },
    ],
    audit: [
      { id: 'hospice_care_audit', code: 'HOSPICE_CARE_AUDIT', name: 'End-of-Life Care Audit' },
    ],
    risk: [
      { id: 'hospice_risk', code: 'HOSPICE_RISK', name: 'Hospice Risk Categories' },
    ],
    capa: [
      { id: 'hospice_capa', code: 'HOSPICE_CAPA', name: 'Hospice CAPA Templates' },
    ],
  },
  'Clinic / Ambulatory': {
    dashboard: [
      { id: 'clinic_compliance', code: 'CLINIC_COMPLIANCE', name: 'Clinic Compliance Tracker' },
      { id: 'clinic_quality', code: 'CLINIC_QUALITY', name: 'Quality Metrics Widget' },
    ],
    lovs: [
      { id: 'clinic_cats', code: 'CLINIC_CATS', name: 'Clinic Service Categories' },
    ],
    citations: [
      { id: 'clinic_citations', code: 'CLINIC_CITATIONS', name: 'Ambulatory Citations Library' },
    ],
    enforcement: [
      { id: 'clinic_deadlines', code: 'CLINIC_DEADLINES', name: 'Clinic Compliance Deadlines' },
    ],
    audit: [
      { id: 'clinic_audit', code: 'CLINIC_AUDIT', name: 'Clinic Safety Audit' },
    ],
    risk: [
      { id: 'clinic_risk', code: 'CLINIC_RISK', name: 'Clinic Risk Categories' },
    ],
    capa: [
      { id: 'clinic_capa', code: 'CLINIC_CAPA', name: 'Clinic CAPA Templates' },
    ],
  },
  'Multi-site Provider Network': {
    dashboard: [
      { id: 'network_rollup', code: 'NETWORK_ROLLUP', name: 'Network Compliance Rollup' },
      { id: 'network_benchmark', code: 'NETWORK_BENCHMARK', name: 'Cross-Site Benchmarking' },
    ],
    lovs: [
      { id: 'network_cats', code: 'NETWORK_CATS', name: 'Network-Wide Categories' },
    ],
    citations: [
      { id: 'network_citations', code: 'NETWORK_CITATIONS', name: 'Multi-Site Citations Library' },
    ],
    enforcement: [
      { id: 'network_deadlines', code: 'NETWORK_DEADLINES', name: 'Network Compliance Deadlines' },
    ],
    audit: [
      { id: 'network_audit', code: 'NETWORK_AUDIT', name: 'Network-Wide Audit Template' },
    ],
    risk: [
      { id: 'network_risk', code: 'NETWORK_RISK', name: 'Enterprise Risk Categories' },
    ],
    capa: [
      { id: 'network_capa', code: 'NETWORK_CAPA', name: 'Enterprise CAPA Templates' },
    ],
  },
  'Other': {
    dashboard: [],
    lovs: [],
    citations: [],
    enforcement: [],
    audit: [],
    risk: [],
    capa: [],
  },
};

// Oversight Body Packs
export const OVERSIGHT_PACKS: Record<string, {
  citations: RecommendedItem[];
  enforcement: RecommendedItem[];
  audit: RecommendedItem[];
}> = {
  'cms': {
    citations: [
      { id: 'cms_cop_lib', code: 'CMS_COP_LIB', name: 'CMS CoP Citation Library' },
      { id: 'cms_deficiency_lib', code: 'CMS_DEFICIENCY_LIB', name: 'CMS Deficiency Tag Library' },
    ],
    enforcement: [
      { id: 'cms_remedy_templates', code: 'CMS_REMEDY', name: 'CMS Remedy Templates' },
      { id: 'cms_deadline_rules', code: 'CMS_DEADLINES', name: 'CMS Deadline Rule Templates' },
    ],
    audit: [
      { id: 'cms_survey_prep', code: 'CMS_SURVEY_PREP', name: 'CMS Survey Prep Checklist' },
    ],
  },
  'state_doh': {
    citations: [
      { id: 'state_citation_lib', code: 'STATE_CITATION_LIB', name: 'State Survey Citation Library' },
    ],
    enforcement: [
      { id: 'state_enforcement', code: 'STATE_ENFORCEMENT', name: 'State Enforcement Templates' },
    ],
    audit: [
      { id: 'state_survey_prep', code: 'STATE_SURVEY_PREP', name: 'State Survey Prep Checklist' },
    ],
  },
  'ocr': {
    citations: [
      { id: 'hipaa_citation_lib', code: 'HIPAA_CITATIONS', name: 'HIPAA Violation Categories' },
    ],
    enforcement: [
      { id: 'hipaa_enforcement', code: 'HIPAA_ENFORCEMENT', name: 'OCR Enforcement Templates' },
    ],
    audit: [
      { id: 'hipaa_audit', code: 'HIPAA_AUDIT', name: 'HIPAA Privacy/Security Audit' },
    ],
  },
  'osha': {
    citations: [
      { id: 'osha_citation_lib', code: 'OSHA_CITATIONS', name: 'OSHA Violation Categories' },
    ],
    enforcement: [
      { id: 'osha_enforcement', code: 'OSHA_ENFORCEMENT', name: 'OSHA Penalty Templates' },
    ],
    audit: [
      { id: 'osha_audit', code: 'OSHA_AUDIT', name: 'Workplace Safety Audit' },
    ],
  },
  'oig': {
    citations: [
      { id: 'oig_citation_lib', code: 'OIG_CITATIONS', name: 'OIG Exclusion Categories' },
    ],
    enforcement: [
      { id: 'oig_enforcement', code: 'OIG_ENFORCEMENT', name: 'OIG Enforcement Templates' },
    ],
    audit: [
      { id: 'oig_audit', code: 'OIG_AUDIT', name: 'Program Integrity Audit' },
    ],
  },
  'tjc': {
    citations: [
      { id: 'tjc_standard_lib', code: 'TJC_STANDARDS', name: 'TJC Standards Library' },
    ],
    enforcement: [
      { id: 'tjc_rfi', code: 'TJC_RFI', name: 'TJC RFI Response Templates' },
    ],
    audit: [
      { id: 'tjc_tracer', code: 'TJC_TRACER', name: 'TJC Tracer Audit Template' },
    ],
  },
};

// Compliance Scope Packs
export const SCOPE_PACKS: Record<string, {
  lovs: RecommendedItem[];
  audit: RecommendedItem[];
  risk: RecommendedItem[];
}> = {
  'infection_control': {
    lovs: [
      { id: 'infection_types', code: 'INFECTION_TYPES', name: 'Infection Type Categories' },
      { id: 'hai_categories', code: 'HAI_CATS', name: 'HAI Categories' },
      { id: 'transmission_routes', code: 'TRANSMISSION', name: 'Transmission Route Categories' },
    ],
    audit: [
      { id: 'infection_audit', code: 'INFECTION_AUDIT', name: 'Infection Prevention Audit' },
      { id: 'hand_hygiene_audit', code: 'HAND_HYGIENE', name: 'Hand Hygiene Audit' },
      { id: 'ppe_audit', code: 'PPE_AUDIT', name: 'PPE Compliance Audit' },
    ],
    risk: [
      { id: 'outbreak_risk', code: 'OUTBREAK_RISK', name: 'Outbreak Risk Categories' },
    ],
  },
  'life_safety': {
    lovs: [
      { id: 'life_safety_cats', code: 'LIFE_SAFETY_CATS', name: 'Life Safety Code Categories' },
      { id: 'fire_drill_types', code: 'FIRE_DRILLS', name: 'Fire Drill Types' },
    ],
    audit: [
      { id: 'fire_safety_audit', code: 'FIRE_SAFETY', name: 'Fire Safety Audit' },
      { id: 'egress_audit', code: 'EGRESS_AUDIT', name: 'Egress Compliance Audit' },
      { id: 'emergency_prep_audit', code: 'EMERGENCY_PREP', name: 'Emergency Preparedness Audit' },
    ],
    risk: [
      { id: 'fire_risk', code: 'FIRE_RISK', name: 'Fire Safety Risk Categories' },
    ],
  },
  'hipaa': {
    lovs: [
      { id: 'phi_categories', code: 'PHI_CATS', name: 'PHI Categories' },
      { id: 'breach_types', code: 'BREACH_TYPES', name: 'Breach Type Categories' },
      { id: 'access_levels', code: 'ACCESS_LEVELS', name: 'Access Level Categories' },
    ],
    audit: [
      { id: 'privacy_audit', code: 'PRIVACY_AUDIT', name: 'Privacy Rule Audit' },
      { id: 'security_audit', code: 'SECURITY_AUDIT', name: 'Security Rule Audit' },
      { id: 'breach_response_audit', code: 'BREACH_AUDIT', name: 'Breach Response Audit' },
    ],
    risk: [
      { id: 'privacy_risk', code: 'PRIVACY_RISK', name: 'Privacy Risk Categories' },
      { id: 'security_risk', code: 'SECURITY_RISK', name: 'Security Risk Categories' },
    ],
  },
  'qapi': {
    lovs: [
      { id: 'quality_indicators', code: 'QI_CATS', name: 'Quality Indicator Categories' },
      { id: 'performance_measures', code: 'PERF_MEASURES', name: 'Performance Measure Categories' },
    ],
    audit: [
      { id: 'qapi_program_audit', code: 'QAPI_PROGRAM', name: 'QAPI Program Audit' },
      { id: 'quality_metrics_audit', code: 'QUALITY_METRICS', name: 'Quality Metrics Audit' },
    ],
    risk: [
      { id: 'quality_risk', code: 'QUALITY_RISK', name: 'Quality Risk Categories' },
    ],
  },
  'patient_rights': {
    lovs: [
      { id: 'rights_categories', code: 'RIGHTS_CATS', name: 'Patient/Resident Rights Categories' },
      { id: 'grievance_types', code: 'GRIEVANCE_TYPES', name: 'Grievance Type Categories' },
    ],
    audit: [
      { id: 'rights_audit', code: 'RIGHTS_AUDIT', name: 'Patient Rights Audit' },
      { id: 'grievance_audit', code: 'GRIEVANCE_AUDIT', name: 'Grievance Process Audit' },
    ],
    risk: [
      { id: 'rights_risk', code: 'RIGHTS_RISK', name: 'Rights Violation Risk Categories' },
    ],
  },
  'billing_coding': {
    lovs: [
      { id: 'billing_cats', code: 'BILLING_CATS', name: 'Billing Category Types' },
      { id: 'coding_issues', code: 'CODING_ISSUES', name: 'Coding Issue Categories' },
    ],
    audit: [
      { id: 'billing_audit', code: 'BILLING_AUDIT', name: 'Billing Compliance Audit' },
      { id: 'coding_audit', code: 'CODING_AUDIT', name: 'Coding Accuracy Audit' },
    ],
    risk: [
      { id: 'billing_risk', code: 'BILLING_RISK', name: 'Billing Risk Categories' },
    ],
  },
  'cures_act': {
    lovs: [
      { id: 'info_blocking_cats', code: 'INFO_BLOCKING', name: 'Information Blocking Categories' },
    ],
    audit: [
      { id: 'interop_audit', code: 'INTEROP_AUDIT', name: 'Interoperability Audit' },
    ],
    risk: [
      { id: 'info_blocking_risk', code: 'INFO_BLOCK_RISK', name: 'Info Blocking Risk Categories' },
    ],
  },
};

// CAPA Defaults (always applied when CAPA module enabled)
export const CAPA_DEFAULTS = {
  statuses: [
    { id: 'capa_open', code: 'OPEN', name: 'Open', description: 'CAPA newly created' },
    { id: 'capa_investigating', code: 'INVESTIGATING', name: 'Investigating', description: 'RCA in progress' },
    { id: 'capa_planning', code: 'PLANNING', name: 'Planning Actions', description: 'Developing action plan' },
    { id: 'capa_implementing', code: 'IMPLEMENTING', name: 'Implementing', description: 'Actions underway' },
    { id: 'capa_verifying', code: 'VERIFYING', name: 'Verifying Effectiveness', description: 'Checking results' },
    { id: 'capa_closed', code: 'CLOSED', name: 'Closed', description: 'CAPA completed' },
  ],
  rcaMethods: [
    { id: 'rca_5why', code: '5_WHY', name: '5 Whys', description: 'Root cause drill-down' },
    { id: 'rca_fishbone', code: 'FISHBONE', name: 'Fishbone / Ishikawa', description: 'Cause-and-effect diagram' },
    { id: 'rca_fmea', code: 'FMEA', name: 'FMEA', description: 'Failure Mode Effects Analysis' },
    { id: 'rca_pareto', code: 'PARETO', name: 'Pareto Analysis', description: '80/20 analysis' },
  ],
  actionTypes: [
    { id: 'action_immediate', code: 'IMMEDIATE', name: 'Immediate Containment' },
    { id: 'action_corrective', code: 'CORRECTIVE', name: 'Corrective Action' },
    { id: 'action_preventive', code: 'PREVENTIVE', name: 'Preventive Action' },
  ],
  effectivenessResults: [
    { id: 'eff_effective', code: 'EFFECTIVE', name: 'Effective', description: 'Issue resolved' },
    { id: 'eff_partial', code: 'PARTIAL', name: 'Partially Effective', description: 'Needs refinement' },
    { id: 'eff_ineffective', code: 'INEFFECTIVE', name: 'Ineffective', description: 'Requires new approach' },
  ],
};

// Risk Defaults
export const RISK_DEFAULTS = {
  likelihoodScale: [
    { id: 'likelihood_rare', code: 'RARE', name: 'Rare', description: '< 5% chance' },
    { id: 'likelihood_unlikely', code: 'UNLIKELY', name: 'Unlikely', description: '5-25% chance' },
    { id: 'likelihood_possible', code: 'POSSIBLE', name: 'Possible', description: '25-50% chance' },
    { id: 'likelihood_likely', code: 'LIKELY', name: 'Likely', description: '50-75% chance' },
    { id: 'likelihood_certain', code: 'ALMOST_CERTAIN', name: 'Almost Certain', description: '> 75% chance' },
  ],
  impactScale: [
    { id: 'impact_negligible', code: 'NEGLIGIBLE', name: 'Negligible', description: 'Minimal impact' },
    { id: 'impact_minor', code: 'MINOR', name: 'Minor', description: 'Limited impact' },
    { id: 'impact_moderate', code: 'MODERATE', name: 'Moderate', description: 'Significant impact' },
    { id: 'impact_major', code: 'MAJOR', name: 'Major', description: 'Serious impact' },
    { id: 'impact_catastrophic', code: 'CATASTROPHIC', name: 'Catastrophic', description: 'Severe impact' },
  ],
  statusValues: [
    { id: 'risk_identified', code: 'IDENTIFIED', name: 'Identified' },
    { id: 'risk_assessing', code: 'ASSESSING', name: 'Assessing' },
    { id: 'risk_mitigating', code: 'MITIGATING', name: 'Mitigating' },
    { id: 'risk_monitoring', code: 'MONITORING', name: 'Monitoring' },
    { id: 'risk_closed', code: 'CLOSED', name: 'Closed' },
  ],
};

// Documents Defaults
export const DOCUMENTS_DEFAULTS = {
  docTypes: [
    { id: 'doc_policy', code: 'POLICY', name: 'Policy' },
    { id: 'doc_procedure', code: 'PROCEDURE', name: 'Procedure' },
    { id: 'doc_guideline', code: 'GUIDELINE', name: 'Guideline' },
    { id: 'doc_form', code: 'FORM', name: 'Form/Template' },
    { id: 'doc_record', code: 'RECORD', name: 'Record' },
  ],
  docStatuses: [
    { id: 'doc_draft', code: 'DRAFT', name: 'Draft' },
    { id: 'doc_review', code: 'IN_REVIEW', name: 'In Review' },
    { id: 'doc_approved', code: 'APPROVED', name: 'Approved' },
    { id: 'doc_published', code: 'PUBLISHED', name: 'Published' },
    { id: 'doc_archived', code: 'ARCHIVED', name: 'Archived' },
  ],
  reviewCadence: [
    { id: 'review_annual', code: 'ANNUAL', name: 'Annual Review' },
    { id: 'review_biannual', code: 'BIANNUAL', name: 'Biannual Review' },
    { id: 'review_quarterly', code: 'QUARTERLY', name: 'Quarterly Review' },
  ],
};

// Helper function to generate a ChangePlan based on selections
export function generateChangePlan(
  providerType: string,
  oversightBodies: string[],
  complianceTags: string[],
  enabledMicroapps: string[]
): ChangePlan {
  const providerPack = PROVIDER_TYPE_PACKS[providerType] || PROVIDER_TYPE_PACKS['Other'];
  
  // Check which modules are enabled
  const hasCitations = enabledMicroapps.includes('COMPLIANCE') || enabledMicroapps.includes('Citations');
  const hasEnforcement = enabledMicroapps.includes('ENFORCE') || enabledMicroapps.includes('EnforcePoint');
  const hasAudit = enabledMicroapps.includes('AUDIT') || enabledMicroapps.includes('AuditPro');
  const hasRisk = enabledMicroapps.includes('RISK') || enabledMicroapps.includes('RiskGuard');
  const hasCapa = enabledMicroapps.includes('COMPLIANCE') || enabledMicroapps.includes('CAPA');
  const hasDocs = enabledMicroapps.includes('COMPLIANCE') || enabledMicroapps.includes('Documents');

  // Aggregate citations from oversight packs
  const oversightCitations: RecommendedItem[] = [];
  const oversightEnforcement: RecommendedItem[] = [];
  const oversightAudit: RecommendedItem[] = [];
  
  oversightBodies.forEach(body => {
    const pack = OVERSIGHT_PACKS[body];
    if (pack) {
      oversightCitations.push(...pack.citations);
      oversightEnforcement.push(...pack.enforcement);
      oversightAudit.push(...pack.audit);
    }
  });

  // Aggregate from scope packs
  const scopeLovs: RecommendedItem[] = [];
  const scopeAudit: RecommendedItem[] = [];
  const scopeRisk: RecommendedItem[] = [];

  complianceTags.forEach(tag => {
    const pack = SCOPE_PACKS[tag];
    if (pack) {
      scopeLovs.push(...pack.lovs);
      scopeAudit.push(...pack.audit);
      scopeRisk.push(...pack.risk);
    }
  });

  // Build the change plan
  const changePlan: ChangePlan = {
    dashboard: {
      id: 'dashboard',
      title: 'Dashboard Defaults',
      description: 'KPI tiles, widgets, and threshold rules for your dashboard',
      whyRecommended: `Based on your ${providerType} setting, these dashboard components will help you monitor key compliance metrics.`,
      items: [
        ...BASE_PROVIDER_PACK.dashboard.kpiTiles,
        ...BASE_PROVIDER_PACK.dashboard.widgets,
        ...providerPack.dashboard,
      ],
      addCount: BASE_PROVIDER_PACK.dashboard.kpiTiles.length + BASE_PROVIDER_PACK.dashboard.widgets.length + providerPack.dashboard.length,
      updateCount: 0,
    },
    lovDefaults: {
      id: 'lovs',
      title: 'LOV / Value Set Defaults',
      description: 'Taxonomy and dropdown value sets for your organization',
      whyRecommended: 'Standard value sets ensure consistent data entry across your organization and align with regulatory requirements.',
      items: [
        ...BASE_PROVIDER_PACK.lovs.shared,
        ...providerPack.lovs,
        ...scopeLovs,
      ],
      addCount: BASE_PROVIDER_PACK.lovs.shared.length + providerPack.lovs.length + scopeLovs.length,
      updateCount: 0,
    },
    citationsDefaults: hasCitations ? {
      id: 'citations',
      title: 'Citations Library Defaults',
      description: 'Citation categories, deficiency tags, and evidence templates',
      whyRecommended: 'Pre-loaded citation libraries help you quickly categorize and respond to survey findings.',
      items: [
        ...providerPack.citations,
        ...oversightCitations,
      ],
      addCount: providerPack.citations.length + oversightCitations.length,
      updateCount: 0,
    } : null,
    enforcementDefaults: hasEnforcement ? {
      id: 'enforcement',
      title: 'Enforcement Defaults',
      description: 'Deadline rules, remedy templates, and correspondence templates',
      whyRecommended: 'Enforcement templates ensure timely responses to regulatory actions.',
      items: [
        ...providerPack.enforcement,
        ...oversightEnforcement,
      ],
      addCount: providerPack.enforcement.length + oversightEnforcement.length,
      updateCount: 0,
    } : null,
    auditDefaults: hasAudit ? {
      id: 'audit',
      title: 'Audit Template Defaults',
      description: 'Pre-built audit templates and evidence checklists',
      whyRecommended: 'Audit templates aligned with your compliance scope ensure comprehensive internal reviews.',
      items: [
        ...providerPack.audit,
        ...oversightAudit,
        ...scopeAudit,
      ],
      addCount: providerPack.audit.length + oversightAudit.length + scopeAudit.length,
      updateCount: 0,
    } : null,
    riskDefaults: hasRisk ? {
      id: 'risk',
      title: 'Risk Defaults',
      description: 'Risk categories, likelihood/impact scales, and default thresholds',
      whyRecommended: 'Standardized risk scales enable consistent risk assessment across your organization.',
      items: [
        ...RISK_DEFAULTS.likelihoodScale,
        ...RISK_DEFAULTS.impactScale,
        ...RISK_DEFAULTS.statusValues,
        ...providerPack.risk,
        ...scopeRisk,
      ],
      addCount: RISK_DEFAULTS.likelihoodScale.length + RISK_DEFAULTS.impactScale.length + RISK_DEFAULTS.statusValues.length + providerPack.risk.length + scopeRisk.length,
      updateCount: 0,
    } : null,
    capaDefaults: hasCapa ? {
      id: 'capa',
      title: 'CAPA Defaults',
      description: 'CAPA statuses, RCA methods, action types, and effectiveness results',
      whyRecommended: 'CAPA workflow defaults ensure a structured approach to corrective and preventive actions.',
      items: [
        ...CAPA_DEFAULTS.statuses,
        ...CAPA_DEFAULTS.rcaMethods,
        ...CAPA_DEFAULTS.actionTypes,
        ...CAPA_DEFAULTS.effectivenessResults,
        ...providerPack.capa,
      ],
      addCount: CAPA_DEFAULTS.statuses.length + CAPA_DEFAULTS.rcaMethods.length + CAPA_DEFAULTS.actionTypes.length + CAPA_DEFAULTS.effectivenessResults.length + providerPack.capa.length,
      updateCount: 0,
    } : null,
    documentsDefaults: hasDocs ? {
      id: 'documents',
      title: 'Controlled Documents Defaults',
      description: 'Document types, statuses, and review cadence settings',
      whyRecommended: 'Document control defaults ensure proper governance of policies and procedures.',
      items: [
        ...DOCUMENTS_DEFAULTS.docTypes,
        ...DOCUMENTS_DEFAULTS.docStatuses,
        ...DOCUMENTS_DEFAULTS.reviewCadence,
      ],
      addCount: DOCUMENTS_DEFAULTS.docTypes.length + DOCUMENTS_DEFAULTS.docStatuses.length + DOCUMENTS_DEFAULTS.reviewCadence.length,
      updateCount: 0,
    } : null,
  };

  return changePlan;
}

// Get friendly name for oversight body
export function getOversightBodyName(id: string): string {
  const names: Record<string, string> = {
    'cms': 'CMS (Centers for Medicare & Medicaid Services)',
    'state_doh': 'State Department of Health',
    'ocr': 'OCR (Office for Civil Rights)',
    'osha': 'OSHA (Workplace Safety)',
    'oig': 'OIG (Office of Inspector General)',
    'tjc': 'The Joint Commission',
    'hhs': 'HHS (Department of Health and Human Services)',
    'fda': 'FDA (Food and Drug Administration)',
    'dea': 'DEA (Drug Enforcement Administration)',
  };
  return names[id] || id;
}

// Get friendly name for compliance tag
export function getComplianceTagName(id: string): string {
  const names: Record<string, string> = {
    'hipaa': 'HIPAA Privacy & Security',
    'state_doh': 'State DOH Requirements',
    'cms_general': 'CMS Participation',
    'infection_control': 'Infection Prevention & Control',
    'patient_rights': 'Patient/Resident Rights',
    'osha': 'Workplace Safety (OSHA)',
    'qapi': 'Quality Assurance (QAPI)',
    'life_safety': 'Life Safety Code',
    'billing_coding': 'Billing & Coding Compliance',
    'cures_act': 'Information Blocking (21st Century Cures)',
  };
  return names[id] || id;
}
