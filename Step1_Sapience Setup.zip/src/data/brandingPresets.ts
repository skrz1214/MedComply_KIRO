// Branding Presets and Default Configurations

import { 
  BrandingConfig, 
  ThemePresetDefinition, 
  ThemePreset,
  BrandingValidationResult 
} from '@/types/brandingConfig';

// Theme Presets
export const THEME_PRESETS: ThemePresetDefinition[] = [
  {
    id: 'default',
    name: 'Default MedComply',
    description: 'Professional blue theme optimized for healthcare compliance',
    primaryColor: '#1e3a5f',
    secondaryColor: '#3b82f6',
    accentColor: '#10b981',
  },
  {
    id: 'healthcare_calm',
    name: 'Healthcare Calm',
    description: 'Soft, calming colors ideal for patient-facing areas',
    primaryColor: '#0d9488',
    secondaryColor: '#06b6d4',
    accentColor: '#8b5cf6',
  },
  {
    id: 'high_contrast',
    name: 'High Contrast (Accessibility)',
    description: 'WCAG AAA compliant colors for maximum readability',
    primaryColor: '#000000',
    secondaryColor: '#1a1a1a',
    accentColor: '#0066cc',
  },
];

// Generate complementary colors from primary
export const generateComplementaryColors = (primaryColor: string): { secondary: string; accent: string } => {
  // Simple color manipulation - in production, use a proper color library
  const hex = primaryColor.replace('#', '');
  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);
  
  // Generate a lighter secondary
  const secondaryR = Math.min(255, r + 60);
  const secondaryG = Math.min(255, g + 60);
  const secondaryB = Math.min(255, b + 60);
  const secondary = `#${secondaryR.toString(16).padStart(2, '0')}${secondaryG.toString(16).padStart(2, '0')}${secondaryB.toString(16).padStart(2, '0')}`;
  
  // Generate a complementary accent (shift hue)
  const accent = `#10b981`; // Default to a green accent
  
  return { secondary, accent };
};

// Check color contrast ratio
export const checkContrastRatio = (foreground: string, background: string): { ratio: number; passes: boolean } => {
  const getLuminance = (hex: string): number => {
    const rgb = hex.replace('#', '').match(/.{2}/g)?.map(x => {
      const c = parseInt(x, 16) / 255;
      return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    }) || [0, 0, 0];
    return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];
  };
  
  const l1 = getLuminance(foreground);
  const l2 = getLuminance(background);
  const ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
  
  return { ratio, passes: ratio >= 4.5 }; // WCAG AA standard
};

// Get default branding configuration
export const getDefaultBrandingConfig = (orgName?: string, orgCode?: string): BrandingConfig => {
  const preset = THEME_PRESETS[0];
  
  return {
    status: 'draft',
    
    orgIdentity: {
      displayName: orgName || '',
      shortName: '',
      appTitle: 'MedComply',
    },
    
    logo: {
      primaryLogoUrl: undefined,
      squareLogoUrl: undefined,
      faviconUrl: undefined,
    },
    
    theme: {
      preset: 'default',
      primaryColor: preset.primaryColor,
      secondaryColor: preset.secondaryColor,
      accentColor: preset.accentColor,
      neutralMode: 'neutral',
      backgroundMode: 'light',
      contrastOk: true,
    },
    
    typography: {
      fontFamily: 'system',
      baseFontSize: 'normal',
    },
    
    appShell: {
      sidebarExpandedByDefault: true,
      sidebarShowLabels: true,
      headerShowOrgName: true,
      buttonStyle: 'standard',
      density: 'comfortable',
    },
    
    login: {
      welcomeTitle: orgName ? `Welcome to ${orgName} Compliance Portal` : 'Welcome to Compliance Portal',
      welcomeMessage: '',
      supportEmail: '',
      supportPhone: '',
      helpLinkLabel: 'Need Help?',
      helpLinkUrl: '',
      termsUrl: '',
      privacyUrl: '',
    },
    
    localization: {
      defaultLanguage: 'en',
      dateFormat: 'MM/DD/YYYY',
      timeFormat: '12hour',
      numberFormat: 'us',
    },
    
    domain: {
      subdomain: orgCode ? `${orgCode.toLowerCase()}.medcomply.example` : 'org.medcomply.example',
      customDomain: '',
      domainStatus: 'not_verified',
    },
  };
};

// Apply theme preset
export const applyThemePreset = (presetId: ThemePreset, currentConfig: BrandingConfig): BrandingConfig => {
  if (presetId === 'custom') {
    return {
      ...currentConfig,
      theme: {
        ...currentConfig.theme,
        preset: 'custom',
      },
    };
  }
  
  const preset = THEME_PRESETS.find(p => p.id === presetId);
  if (!preset) return currentConfig;
  
  return {
    ...currentConfig,
    theme: {
      ...currentConfig.theme,
      preset: presetId,
      primaryColor: preset.primaryColor,
      secondaryColor: preset.secondaryColor,
      accentColor: preset.accentColor,
      contrastOk: checkContrastRatio('#ffffff', preset.primaryColor).passes,
    },
  };
};

// Validate branding configuration
export const validateBrandingConfig = (config: BrandingConfig): BrandingValidationResult => {
  const errors: string[] = [];
  const warnings: string[] = [];
  
  // Check required fields
  if (!config.orgIdentity.displayName) {
    errors.push('Display name is required');
  }
  
  // Check logo (required unless skipping branding)
  if (config.status !== 'skipped' && !config.logo.primaryLogoUrl && !config.logo.primaryLogoFile) {
    warnings.push('Primary logo not uploaded - you can skip branding or upload a logo to publish');
  }
  
  // Check contrast
  if (!config.theme.contrastOk) {
    warnings.push('Primary color may have low contrast with white text - consider adjusting for accessibility');
  }
  
  // Check dark mode logo compatibility
  if (config.theme.backgroundMode === 'dark' && config.logo.primaryLogoUrl) {
    warnings.push('Review logo visibility on dark backgrounds');
  }
  
  // Validate URLs
  if (config.login.helpLinkUrl && !isValidUrl(config.login.helpLinkUrl)) {
    errors.push('Help link URL is not valid');
  }
  if (config.login.termsUrl && !isValidUrl(config.login.termsUrl)) {
    errors.push('Terms URL is not valid');
  }
  if (config.login.privacyUrl && !isValidUrl(config.login.privacyUrl)) {
    errors.push('Privacy URL is not valid');
  }
  
  const canPublish = errors.length === 0 && (
    config.logo.primaryLogoUrl !== undefined || 
    config.logo.primaryLogoFile !== undefined ||
    config.status === 'skipped'
  );
  
  return {
    isValid: errors.length === 0,
    canPublish,
    errors,
    warnings,
  };
};

// URL validation helper
const isValidUrl = (url: string): boolean => {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
};

// Font family display names
export const FONT_FAMILY_OPTIONS = [
  { id: 'system', name: 'System Default', description: 'Uses device native fonts for best performance' },
  { id: 'modern_sans', name: 'Modern Sans', description: 'Clean, contemporary sans-serif typeface' },
];

// Date format display
export const DATE_FORMAT_OPTIONS = [
  { id: 'MM/DD/YYYY', label: 'MM/DD/YYYY', example: '12/25/2024' },
  { id: 'DD/MM/YYYY', label: 'DD/MM/YYYY', example: '25/12/2024' },
  { id: 'YYYY-MM-DD', label: 'ISO (YYYY-MM-DD)', example: '2024-12-25' },
];

// Time format display
export const TIME_FORMAT_OPTIONS = [
  { id: '12hour', label: '12-hour', example: '2:30 PM' },
  { id: '24hour', label: '24-hour', example: '14:30' },
];

// Number format display
export const NUMBER_FORMAT_OPTIONS = [
  { id: 'us', label: 'US (1,234.56)', example: '1,234.56' },
  { id: 'eu', label: 'EU (1.234,56)', example: '1.234,56' },
];
