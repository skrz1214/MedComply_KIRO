// Security Presets for Onboarding
// Aligned with HIPAA Security Rule and NIST SP 800-63-4

import { SecurityBaseline, SecurityPresetType } from '@/types/securityBaseline';

export interface SecurityPresetMeta {
  id: SecurityPresetType;
  name: string;
  description: string;
  isDefault: boolean;
  badge?: string;
}

export const SECURITY_PRESETS: SecurityPresetMeta[] = [
  {
    id: 'healthcare_baseline',
    name: 'Healthcare Provider Baseline',
    description: 'Balanced defaults optimized for healthcare providers with standard regulatory requirements. Recommended for most organizations.',
    isDefault: true,
    badge: 'Recommended',
  },
  {
    id: 'strict',
    name: 'Strict / Least Privilege',
    description: 'Enhanced security controls for high-compliance environments. Shorter timeouts, MFA for all users, tighter export restrictions.',
    isDefault: false,
    badge: 'High Security',
  },
  {
    id: 'operational',
    name: 'Operational / Flexible',
    description: 'Relaxed controls for organizations prioritizing operational efficiency. Longer timeouts, more permissive exports.',
    isDefault: false,
  },
];

// Healthcare Provider Baseline Preset
const healthcareBaselineConfig: Omit<SecurityBaseline, 'selectedPreset' | 'isCustomized' | 'status' | 'publishedBy' | 'publishedAt' | 'versionId'> = {
  identityAuth: {
    authMode: 'sso',
    idpType: 'saml',
    allowedDomains: [],
    jitProvisioningEnabled: true,
    roleMapping: 'idp_groups',
    passwordMinLength: 12,
    passwordRequireUppercase: true,
    passwordRequireLowercase: true,
    passwordRequireNumbers: true,
    passwordRequireSpecial: true,
    passwordLockoutAttempts: 5,
    passwordLockoutDuration: 30,
    passwordExpiryDays: 90,
    mfaRequired: 'admin_only',
    mfaAllowedMethods: ['authenticator'],
    recoveryCodesEnabled: true,
    uniqueUserIdEnabled: true,
    emergencyAccessEnabled: true,
    emergencyAccessApprovers: ['org_admin', 'compliance_head'],
    emergencyAccessDuration: 1,
    emergencyAccessRequiresJustification: true,
  },
  accessControl: {
    preventSelfApproval: true,
    adminChangesRequireReauth: true,
    inactiveAccountDisableDays: 60,
    terminatedUserDisableImmediately: true,
    roleChangeAuditRequired: true,
  },
  sessionControls: {
    idleTimeoutMinutes: 30,
    absoluteSessionMaxHours: 12,
    restrictToManagedDevices: false,
    blockUnsupportedBrowsers: false,
  },
  encryption: {
    tlsRequired: true,
    blockNonTlsCallbacks: true,
    encryptionKeyType: 'platform_managed',
    integrityChecksEnabled: true,
    fileHashingEnabled: true,
    tamperEvidentAuditTrail: true,
  },
  auditLogging: {
    auditLoggingEnabled: true,
    eventCategories: {
      authentication: true,
      authorization: true,
      adminConfig: true,
      dataChanges: true,
      evidenceUploadDownload: true,
      exports: true,
      breakGlassAccess: true,
      apiTokens: true,
    },
    activeRetentionDays: 180,
    archivedRetentionYears: 3,
    exportAuditLogAllowed: 'admin_only',
    auditViewers: {
      orgAdmin: true,
      complianceHead: true,
      departmentHead: false,
      staff: false,
    },
  },
  exportControls: {
    staffExportsAllowed: false,
    departmentHeadExportsAllowed: true,
    departmentHeadExportScope: 'department',
    complianceHeadExportsAllowed: true,
    complianceHeadExportScope: 'org',
    orgAdminExportsAllowed: true,
    orgAdminExportScope: 'org',
    requireExportReason: true,
    watermarkExports: false,
  },
  networkControls: {
    ipAllowlistEnabled: false,
    ipAllowlistCidrs: [],
    lockoutPreventionContact: '',
    apiTokensEnabled: false,
    tokenRotationReminderDays: 90,
  },
  incidentContacts: {
    securityContact: { name: '', email: '', phone: '' },
    complianceContact: { name: '', email: '', phone: '' },
    notifyOnRepeatedFailedLogins: true,
    notifyOnAdminRoleChanges: true,
    notifyOnLargeExports: true,
    notifyOnBreakGlassUsage: true,
    notifyViaEmail: true,
    notifyViaInApp: true,
  },
  governanceAttestations: {
    accessManagementAcknowledged: false,
    auditMonitoringAcknowledged: false,
    ssoMfaConfigAcknowledged: false,
    baaAcknowledged: false,
  },
};

// Strict Preset - Enhanced security
const strictConfig: typeof healthcareBaselineConfig = {
  ...healthcareBaselineConfig,
  identityAuth: {
    ...healthcareBaselineConfig.identityAuth,
    mfaRequired: 'all_users',
    passwordMinLength: 14,
    passwordLockoutAttempts: 3,
    emergencyAccessDuration: 1,
  },
  sessionControls: {
    idleTimeoutMinutes: 15,
    absoluteSessionMaxHours: 8,
    restrictToManagedDevices: false,
    blockUnsupportedBrowsers: true,
  },
  accessControl: {
    ...healthcareBaselineConfig.accessControl,
    inactiveAccountDisableDays: 30,
  },
  exportControls: {
    ...healthcareBaselineConfig.exportControls,
    departmentHeadExportsAllowed: false,
    watermarkExports: true,
  },
  auditLogging: {
    ...healthcareBaselineConfig.auditLogging,
    activeRetentionDays: 365,
    archivedRetentionYears: 7,
  },
};

// Operational Preset - More permissive
const operationalConfig: typeof healthcareBaselineConfig = {
  ...healthcareBaselineConfig,
  identityAuth: {
    ...healthcareBaselineConfig.identityAuth,
    mfaRequired: 'admin_only',
    mfaAllowedMethods: ['authenticator', 'sms'],
  },
  sessionControls: {
    idleTimeoutMinutes: 60,
    absoluteSessionMaxHours: 24,
    restrictToManagedDevices: false,
    blockUnsupportedBrowsers: false,
  },
  accessControl: {
    ...healthcareBaselineConfig.accessControl,
    inactiveAccountDisableDays: 90,
  },
  exportControls: {
    ...healthcareBaselineConfig.exportControls,
    staffExportsAllowed: true,
    requireExportReason: false,
  },
  auditLogging: {
    ...healthcareBaselineConfig.auditLogging,
    activeRetentionDays: 90,
    archivedRetentionYears: 1,
  },
};

export const getPresetConfig = (presetId: SecurityPresetType): SecurityBaseline => {
  const configs: Record<SecurityPresetType, typeof healthcareBaselineConfig> = {
    healthcare_baseline: healthcareBaselineConfig,
    strict: strictConfig,
    operational: operationalConfig,
  };

  return {
    ...configs[presetId],
    selectedPreset: presetId,
    isCustomized: false,
    status: 'draft',
  };
};

export const getDefaultSecurityBaseline = (): SecurityBaseline => {
  return getPresetConfig('healthcare_baseline');
};

// Validation logic
export const validateSecurityBaseline = (config: SecurityBaseline): { isValid: boolean; canPublish: boolean; errors: string[]; warnings: string[] } => {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Required validations
  if (config.identityAuth.authMode === 'local') {
    if (config.identityAuth.passwordMinLength < 8) {
      errors.push('Password minimum length must be at least 8 characters');
    }
  }

  if (config.identityAuth.authMode === 'sso' && config.identityAuth.allowedDomains.length === 0) {
    warnings.push('No SSO domains configured - users will need to configure this before login');
  }

  if (!config.incidentContacts.securityContact.email) {
    errors.push('Security/Privacy contact email is required');
  }

  if (!config.incidentContacts.complianceContact.email) {
    warnings.push('Compliance Head contact not configured - will use onboarding user data if available');
  }

  // Attestation checks
  if (!config.governanceAttestations.accessManagementAcknowledged) {
    errors.push('Access management attestation is required');
  }
  if (!config.governanceAttestations.auditMonitoringAcknowledged) {
    errors.push('Audit monitoring attestation is required');
  }
  if (!config.governanceAttestations.ssoMfaConfigAcknowledged) {
    errors.push('SSO/MFA configuration attestation is required');
  }

  // Warnings
  if (config.identityAuth.mfaRequired === 'admin_only') {
    warnings.push('MFA is only required for admin roles - consider enabling for all users for enhanced security');
  }

  if (config.auditLogging.activeRetentionDays < 90) {
    warnings.push('Active retention period is below recommended minimum of 90 days');
  }

  if (config.networkControls.ipAllowlistEnabled && !config.networkControls.lockoutPreventionContact) {
    warnings.push('IP allowlist is enabled without a lockout prevention contact method');
  }

  return {
    isValid: errors.length === 0,
    canPublish: errors.length === 0,
    errors,
    warnings,
  };
};

// HIPAA Safeguard category labels
export const HIPAA_CATEGORIES = {
  administrative: 'Administrative Safeguards',
  physical: 'Physical Safeguards',
  technical: 'Technical Safeguards',
};

export const CARD_HIPAA_MAPPING: Record<string, { category: keyof typeof HIPAA_CATEGORIES; standards: string[] }> = {
  identityAuth: {
    category: 'technical',
    standards: ['Access Control (164.312(a)(1))', 'Person/Entity Authentication (164.312(d))'],
  },
  accessControl: {
    category: 'administrative',
    standards: ['Access Authorization (164.308(a)(4))', 'Workforce Security (164.308(a)(3))'],
  },
  sessionControls: {
    category: 'technical',
    standards: ['Automatic Logoff (164.312(a)(2)(iii))'],
  },
  encryption: {
    category: 'technical',
    standards: ['Transmission Security (164.312(e)(1))', 'Integrity (164.312(c)(1))'],
  },
  auditLogging: {
    category: 'technical',
    standards: ['Audit Controls (164.312(b))'],
  },
  exportControls: {
    category: 'administrative',
    standards: ['Information Access Management (164.308(a)(4))'],
  },
  networkControls: {
    category: 'technical',
    standards: ['Access Control (164.312(a)(1))'],
  },
  incidentContacts: {
    category: 'administrative',
    standards: ['Security Incident Procedures (164.308(a)(6))'],
  },
  governanceAttestations: {
    category: 'administrative',
    standards: ['Security Management Process (164.308(a)(1))'],
  },
};
