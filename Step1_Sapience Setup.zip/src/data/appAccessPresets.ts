import { AppAccessEntitlements, RoleType, RoleAppEntitlements, Role, ROLE_TYPE_MAX_SCOPE } from '@/types/onboarding';

// Default entitlements for a role when no preset is selected
export const createEmptyRoleEntitlements = (): RoleAppEntitlements => ({
  apps: {},
  dashboardFlags: { canExportCsv: false, canViewCrossAppKpis: false },
  exportsAllowed: false,
  exportScope: 'self',
});

// Preset templates by role TYPE (not ID)
const PRESET_TEMPLATES: Record<string, Record<RoleType, RoleAppEntitlements>> = {
  recommended: {
    staff: {
      apps: {
        // Dashboards
        master_dashboard: { accessLevel: 'none', scope: 'self' },
        department_dashboard: { accessLevel: 'none', scope: 'self' },
        individual_dashboard: { accessLevel: 'view', scope: 'self' },
        // Microapps
        compliance_connect: { accessLevel: 'manage', scope: 'self' },
        feedback_hub: { accessLevel: 'manage', scope: 'self' },
        audit_pro: { accessLevel: 'view', scope: 'department' },
        enforce_point: { accessLevel: 'view', scope: 'department' },
        risk_guard: { accessLevel: 'view', scope: 'department' },
        capa: { accessLevel: 'manage', scope: 'self' },
        citations: { accessLevel: 'view', scope: 'department' },
        documents: { accessLevel: 'view', scope: 'department' },
      },
      dashboardFlags: { canExportCsv: false, canViewCrossAppKpis: true },
      exportsAllowed: false,
      exportScope: 'self',
    },
    department_head: {
      apps: {
        // Dashboards
        master_dashboard: { accessLevel: 'none', scope: 'department' },
        department_dashboard: { accessLevel: 'view', scope: 'department' },
        individual_dashboard: { accessLevel: 'view', scope: 'self' },
        // Microapps
        compliance_connect: { accessLevel: 'manage', scope: 'department' },
        feedback_hub: { accessLevel: 'manage', scope: 'department' },
        audit_pro: { accessLevel: 'manage', scope: 'department' },
        enforce_point: { accessLevel: 'manage', scope: 'department' },
        risk_guard: { accessLevel: 'manage', scope: 'department' },
        capa: { accessLevel: 'manage', scope: 'department' },
        citations: { accessLevel: 'manage', scope: 'department' },
        documents: { accessLevel: 'manage', scope: 'department' },
      },
      dashboardFlags: { canExportCsv: true, canViewCrossAppKpis: true },
      exportsAllowed: true,
      exportScope: 'department',
    },
    compliance_head: {
      apps: {
        // Dashboards
        master_dashboard: { accessLevel: 'view', scope: 'org' },
        department_dashboard: { accessLevel: 'view', scope: 'org' },
        individual_dashboard: { accessLevel: 'view', scope: 'org' },
        // Microapps
        compliance_connect: { accessLevel: 'manage', scope: 'org' },
        feedback_hub: { accessLevel: 'manage', scope: 'org' },
        audit_pro: { accessLevel: 'manage', scope: 'org' },
        enforce_point: { accessLevel: 'manage', scope: 'org' },
        risk_guard: { accessLevel: 'manage', scope: 'org' },
        capa: { accessLevel: 'manage', scope: 'org' },
        citations: { accessLevel: 'manage', scope: 'org' },
        documents: { accessLevel: 'manage', scope: 'org' },
      },
      dashboardFlags: { canExportCsv: true, canViewCrossAppKpis: true },
      exportsAllowed: true,
      exportScope: 'org',
    },
    org_admin: {
      apps: {
        // Dashboards
        master_dashboard: { accessLevel: 'view', scope: 'org' },
        department_dashboard: { accessLevel: 'view', scope: 'org' },
        individual_dashboard: { accessLevel: 'view', scope: 'org' },
        // Microapps
        compliance_connect: { accessLevel: 'manage', scope: 'org' },
        feedback_hub: { accessLevel: 'manage', scope: 'org' },
        audit_pro: { accessLevel: 'manage', scope: 'org' },
        enforce_point: { accessLevel: 'manage', scope: 'org' },
        risk_guard: { accessLevel: 'manage', scope: 'org' },
        capa: { accessLevel: 'manage', scope: 'org' },
        citations: { accessLevel: 'manage', scope: 'org' },
        documents: { accessLevel: 'manage', scope: 'org' },
      },
      dashboardFlags: { canExportCsv: true, canViewCrossAppKpis: true },
      exportsAllowed: true,
      exportScope: 'org',
    },
  },
  strict: {
    staff: {
      apps: {
        master_dashboard: { accessLevel: 'none', scope: 'self' },
        department_dashboard: { accessLevel: 'none', scope: 'self' },
        individual_dashboard: { accessLevel: 'view', scope: 'self' },
        compliance_connect: { accessLevel: 'manage', scope: 'self' },
        feedback_hub: { accessLevel: 'manage', scope: 'self' },
        audit_pro: { accessLevel: 'view', scope: 'self' },
        enforce_point: { accessLevel: 'view', scope: 'self' },
        risk_guard: { accessLevel: 'view', scope: 'self' },
        capa: { accessLevel: 'view', scope: 'self' },
        citations: { accessLevel: 'view', scope: 'self' },
        documents: { accessLevel: 'view', scope: 'self' },
      },
      dashboardFlags: { canExportCsv: false, canViewCrossAppKpis: false },
      exportsAllowed: false,
      exportScope: 'self',
    },
    department_head: {
      apps: {
        master_dashboard: { accessLevel: 'none', scope: 'department' },
        department_dashboard: { accessLevel: 'view', scope: 'department' },
        individual_dashboard: { accessLevel: 'view', scope: 'self' },
        compliance_connect: { accessLevel: 'manage', scope: 'department' },
        feedback_hub: { accessLevel: 'view', scope: 'department' },
        audit_pro: { accessLevel: 'manage', scope: 'department' },
        enforce_point: { accessLevel: 'view', scope: 'department' },
        risk_guard: { accessLevel: 'view', scope: 'department' },
        capa: { accessLevel: 'manage', scope: 'department' },
        citations: { accessLevel: 'view', scope: 'department' },
        documents: { accessLevel: 'view', scope: 'department' },
      },
      dashboardFlags: { canExportCsv: true, canViewCrossAppKpis: true },
      exportsAllowed: true,
      exportScope: 'department',
    },
    compliance_head: {
      apps: {
        master_dashboard: { accessLevel: 'view', scope: 'org' },
        department_dashboard: { accessLevel: 'view', scope: 'org' },
        individual_dashboard: { accessLevel: 'view', scope: 'org' },
        compliance_connect: { accessLevel: 'manage', scope: 'org' },
        feedback_hub: { accessLevel: 'manage', scope: 'org' },
        audit_pro: { accessLevel: 'manage', scope: 'org' },
        enforce_point: { accessLevel: 'manage', scope: 'org' },
        risk_guard: { accessLevel: 'manage', scope: 'org' },
        capa: { accessLevel: 'manage', scope: 'org' },
        citations: { accessLevel: 'manage', scope: 'org' },
        documents: { accessLevel: 'manage', scope: 'org' },
      },
      dashboardFlags: { canExportCsv: true, canViewCrossAppKpis: true },
      exportsAllowed: true,
      exportScope: 'org',
    },
    org_admin: {
      apps: {
        master_dashboard: { accessLevel: 'view', scope: 'org' },
        department_dashboard: { accessLevel: 'view', scope: 'org' },
        individual_dashboard: { accessLevel: 'view', scope: 'org' },
        compliance_connect: { accessLevel: 'manage', scope: 'org' },
        feedback_hub: { accessLevel: 'manage', scope: 'org' },
        audit_pro: { accessLevel: 'manage', scope: 'org' },
        enforce_point: { accessLevel: 'manage', scope: 'org' },
        risk_guard: { accessLevel: 'manage', scope: 'org' },
        capa: { accessLevel: 'manage', scope: 'org' },
        citations: { accessLevel: 'manage', scope: 'org' },
        documents: { accessLevel: 'manage', scope: 'org' },
      },
      dashboardFlags: { canExportCsv: true, canViewCrossAppKpis: true },
      exportsAllowed: true,
      exportScope: 'org',
    },
  },
  operational: {
    staff: {
      apps: {
        master_dashboard: { accessLevel: 'none', scope: 'self' },
        department_dashboard: { accessLevel: 'none', scope: 'self' },
        individual_dashboard: { accessLevel: 'view', scope: 'self' },
        compliance_connect: { accessLevel: 'manage', scope: 'self' },
        feedback_hub: { accessLevel: 'manage', scope: 'self' },
        audit_pro: { accessLevel: 'manage', scope: 'self' },
        enforce_point: { accessLevel: 'view', scope: 'self' },
        risk_guard: { accessLevel: 'manage', scope: 'self' },
        capa: { accessLevel: 'manage', scope: 'self' },
        citations: { accessLevel: 'view', scope: 'self' },
        documents: { accessLevel: 'view', scope: 'department' },
      },
      dashboardFlags: { canExportCsv: false, canViewCrossAppKpis: true },
      exportsAllowed: false,
      exportScope: 'self',
    },
    department_head: {
      apps: {
        master_dashboard: { accessLevel: 'none', scope: 'department' },
        department_dashboard: { accessLevel: 'manage', scope: 'department' },
        individual_dashboard: { accessLevel: 'view', scope: 'self' },
        compliance_connect: { accessLevel: 'manage', scope: 'department' },
        feedback_hub: { accessLevel: 'manage', scope: 'department' },
        audit_pro: { accessLevel: 'manage', scope: 'department' },
        enforce_point: { accessLevel: 'manage', scope: 'department' },
        risk_guard: { accessLevel: 'manage', scope: 'department' },
        capa: { accessLevel: 'manage', scope: 'department' },
        citations: { accessLevel: 'manage', scope: 'department' },
        documents: { accessLevel: 'manage', scope: 'department' },
      },
      dashboardFlags: { canExportCsv: true, canViewCrossAppKpis: true },
      exportsAllowed: true,
      exportScope: 'department',
    },
    compliance_head: {
      apps: {
        master_dashboard: { accessLevel: 'view', scope: 'org' },
        department_dashboard: { accessLevel: 'view', scope: 'org' },
        individual_dashboard: { accessLevel: 'view', scope: 'org' },
        compliance_connect: { accessLevel: 'manage', scope: 'org' },
        feedback_hub: { accessLevel: 'manage', scope: 'org' },
        audit_pro: { accessLevel: 'manage', scope: 'org' },
        enforce_point: { accessLevel: 'manage', scope: 'org' },
        risk_guard: { accessLevel: 'manage', scope: 'org' },
        capa: { accessLevel: 'manage', scope: 'org' },
        citations: { accessLevel: 'manage', scope: 'org' },
        documents: { accessLevel: 'manage', scope: 'org' },
      },
      dashboardFlags: { canExportCsv: true, canViewCrossAppKpis: true },
      exportsAllowed: true,
      exportScope: 'org',
    },
    org_admin: {
      apps: {
        master_dashboard: { accessLevel: 'view', scope: 'org' },
        department_dashboard: { accessLevel: 'view', scope: 'org' },
        individual_dashboard: { accessLevel: 'view', scope: 'org' },
        compliance_connect: { accessLevel: 'manage', scope: 'org' },
        feedback_hub: { accessLevel: 'manage', scope: 'org' },
        audit_pro: { accessLevel: 'manage', scope: 'org' },
        enforce_point: { accessLevel: 'manage', scope: 'org' },
        risk_guard: { accessLevel: 'manage', scope: 'org' },
        capa: { accessLevel: 'manage', scope: 'org' },
        citations: { accessLevel: 'manage', scope: 'org' },
        documents: { accessLevel: 'manage', scope: 'org' },
      },
      dashboardFlags: { canExportCsv: true, canViewCrossAppKpis: true },
      exportsAllowed: true,
      exportScope: 'org',
    },
  },
};

export const APP_ACCESS_PRESETS = {
  recommended: {
    id: 'recommended',
    name: 'Provider Org Recommended',
    description: 'Balanced access for healthcare providers. Staff can manage their own work, Department Heads oversee their teams, and leadership has org-wide visibility.',
    summary: 'Staff: Individual dashboard + self-manage • Dept Heads: Department dashboard + team control • Leadership: Full access',
  },
  strict: {
    id: 'strict',
    name: 'Strict Least Privilege',
    description: 'Minimal access by default. Staff can only view most areas. Best for highly regulated environments requiring tight access control.',
    summary: 'Staff: Individual dashboard only • Dept Heads: Limited manage • Leadership: Full access',
  },
  operational: {
    id: 'operational',
    name: 'Operational (Dept Heads Empowered)',
    description: 'Department Heads have strong control. Staff can contribute to audits and risk updates. Good for organizations with empowered middle management.',
    summary: 'Staff: Can manage audits & risks • Dept Heads: Full department control • Leadership: Full access',
  },
} as const;

export type PresetId = keyof typeof APP_ACCESS_PRESETS;

export const getDefaultAppAccessEntitlements = (): AppAccessEntitlements => ({
  selectedPreset: null,
  roleEntitlements: {},
  isCustomized: false,
});

// Apply a preset to the given roles (dynamically based on configured roles)
export const applyPresetToRoles = (presetId: PresetId, roles: Role[]): AppAccessEntitlements => {
  const template = PRESET_TEMPLATES[presetId];
  const roleEntitlements: Record<string, RoleAppEntitlements> = {};

  roles.forEach(role => {
    // Use the role's type to get the template, or fall back to staff for custom roles
    const templateForType = template[role.type] || template.staff;
    roleEntitlements[role.id] = JSON.parse(JSON.stringify(templateForType));
  });

  return {
    selectedPreset: presetId,
    roleEntitlements,
    isCustomized: false,
  };
};

// Get the preset template for a specific role type
export const getPresetForRoleType = (presetId: PresetId, roleType: RoleType): RoleAppEntitlements => {
  return JSON.parse(JSON.stringify(PRESET_TEMPLATES[presetId][roleType] || PRESET_TEMPLATES[presetId].staff));
};
