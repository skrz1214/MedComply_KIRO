## Goal

The in-app `Download PDF` buttons use `html2pdf.js`, which rasterizes the on-screen card layout and clips content that overflows page boundaries (especially long tables and multi-page sections). I'll bypass that by generating three clean, paginated PDFs server-side from the same source content and deliver them as artifacts.

## What I'll deliver

Three PDFs in `/mnt/documents/`:

1. `PRD_Organization.pdf` — Product Requirements Document (Executive Summary, Stakeholders, Functional Requirements, Compliance, Non-Functional Requirements, Data Dictionary, etc., pulled from `PRDStep.tsx`).
2. `QA_Test_Scenarios.pdf` — All ~18 QA test cases grouped by category (Authentication, Access Control, Facility Management, Audit Logging, Data Validation, Security, Performance), with steps, expected result, and priority.
3. `UAT_Test_Scenarios.pdf` — All ~11 UAT scenarios grouped by persona (Org Admin, Compliance Head, Department Head, Staff, All Users), with business goal, preconditions, steps, acceptance criteria, and priority.

Since this is a generic export (not tied to a specific saved org), placeholders like organization name will use a generic "Organization" label.

## Approach

- Use Python + ReportLab (Platypus) for proper pagination, page breaks, headers, and table flow — no clipping.
- Translate the static content in `PRDStep.tsx`, `QATestStep.tsx`, `UATTestStep.tsx` into ReportLab flowables (headings, paragraphs, tables, bullet lists).
- A4 portrait, MedComply-style header on each page, priority badges as colored cells.
- QA after generation: convert each page to image and visually inspect for clipping/overflow before delivering.

## Out of scope

- Not modifying the in-app `usePdfDownload` hook (that's a separate fix — happy to follow up if you want the in-app downloads fixed too).
