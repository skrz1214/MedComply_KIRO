## Goal

Rename the title "HR Compliance Master Dashboard" → "Organizational Leadership Compliance Dashboard" everywhere it appears in the UI and docs. Also update the subtitle "HR Compliance Dashboard" to match the new wording.

## Changes

1. **`src/pages/Index.tsx`** (dashboard header)
   - H1: `HR Compliance Master Dashboard` → `Organizational Leadership Compliance Dashboard`
   - Subtitle: `HR Compliance Dashboard` → `Organizational Leadership Compliance Dashboard`

2. **`src/pages/compliance/Documentation.tsx`** (6 occurrences)
   - Print header `<h1>`: `MedComply - HR Compliance Master Dashboard` → `MedComply - Organizational Leadership Compliance Dashboard`
   - Five `Product:` lines (PRD, TDD, QA, UAT, System Prompt documents): same rename

## Out of scope

- `index.html` `<title>` ("MedComply - Healthcare Management System") and meta descriptions — no "HR Compliance Master Dashboard" string present there, so untouched unless requested.
- `docs/PRD.md` — references "ComplianceMaster Leadership Dashboard", not the HR title, so untouched.
- Sidebar branding ("MedComply / Leadership Dashboard") — untouched.
