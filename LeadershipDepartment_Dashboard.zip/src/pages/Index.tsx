import { useState } from "react";
import DashboardSidebar from "@/components/layout/DashboardSidebar";
import ActionCenter from "@/components/dashboard/ActionCenter";
import ReviewQueue from "@/components/dashboard/ReviewQueue";
import AddTaskModal from "@/components/dashboard/AddTaskModal";
import QuickStats from "@/components/dashboard/QuickStats";
import QualityKpis from "@/components/dashboard/QualityKpis";
import QuickAccess from "@/components/dashboard/QuickAccess";
import RoleImpersonation, { UserRole } from "@/components/dashboard/RoleImpersonation";

const Index = () => {
  const [isAddTaskOpen, setIsAddTaskOpen] = useState(false);
  const [currentRole, setCurrentRole] = useState<UserRole>("compliance-head");

  return (
    <div className="flex min-h-screen bg-background">
      {/* Skip Link for Accessibility */}
      <a 
        href="#main-content" 
        className="skip-link"
      >
        Skip to main content
      </a>

      <DashboardSidebar />
      
      <main id="main-content" className="flex-1 p-4 lg:p-6 overflow-auto" tabIndex={-1}>
        {/* Header */}
        <header className="mb-6 animate-fade-in lg:pl-0 pl-12">
          <h1 className="text-foreground mb-1">Organizational Leadership Compliance Dashboard</h1>
          <p className="text-muted-foreground text-sm">Leadership Dashboard</p>
        </header>

        {/* Main Grid: Left Column (Action Center + Review Queue + Quick Access) | Right Column (Role + Stats + KPIs) */}
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">
          {/* Left Column - Main Content */}
          <div className="space-y-4">
            {/* Action Center */}
            <ActionCenter onAddTask={() => setIsAddTaskOpen(true)} />
            
            {/* Review Queue */}
            <ReviewQueue />

            {/* Quick Access - Micro Apps */}
            <QuickAccess />
          </div>
          
          {/* Right Column - Role Impersonation + Quick Stats + Quality KPIs */}
          <div className="space-y-4 order-first lg:order-last">
            <RoleImpersonation 
              currentRole={currentRole} 
              onRoleChange={setCurrentRole} 
            />
            <QuickStats />
            <QualityKpis />
          </div>
        </div>

        {/* Add Task Modal */}
        <AddTaskModal 
          open={isAddTaskOpen} 
          onOpenChange={setIsAddTaskOpen} 
        />
      </main>
    </div>
  );
};

export default Index;
