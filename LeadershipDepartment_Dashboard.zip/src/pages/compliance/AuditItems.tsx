import { useState } from "react";
import DashboardSidebar from "@/components/layout/DashboardSidebar";
import PageHeader from "@/components/compliance/PageHeader";
import { DataTable, Column } from "@/components/ui/data-table";
import FilterBar from "@/components/compliance/FilterBar";
import MetricsTile from "@/components/compliance/MetricsTile";
import UpcomingDeadlines from "@/components/compliance/UpcomingDeadlines";
import StatusBadge from "@/components/compliance/StatusBadge";
import PriorityBadge from "@/components/compliance/PriorityBadge";
import { toast } from "@/hooks/use-toast";
import { ClipboardCheck, Clock, CheckCircle, AlertTriangle } from "lucide-react";

interface AuditItem {
  id: string;
  title: string;
  status: "pending" | "completed" | "overdue" | "in-review";
  deadline: string;
  owner: string;
  priority: "high" | "medium" | "low";
}

const mockAudits: AuditItem[] = [
  { id: "AUD-001", title: "Annual HIPAA Compliance Audit", status: "pending", deadline: "2024-12-31", owner: "Patricia Williams", priority: "high" },
  { id: "AUD-002", title: "Quarterly Financial Review", status: "completed", deadline: "2024-09-30", owner: "Michael Chen", priority: "medium" },
  { id: "AUD-003", title: "Security Infrastructure Assessment", status: "in-review", deadline: "2024-11-15", owner: "David Thompson", priority: "high" },
  { id: "AUD-004", title: "Clinical Documentation Review", status: "overdue", deadline: "2024-10-01", owner: "Jennifer Lee", priority: "high" },
  { id: "AUD-005", title: "Vendor Compliance Check", status: "pending", deadline: "2024-12-15", owner: "Robert Martinez", priority: "medium" },
  { id: "AUD-006", title: "Staff Training Audit", status: "completed", deadline: "2024-08-31", owner: "Dr. Sarah Johnson", priority: "low" },
];

const AuditItems = () => {
  const [audits] = useState<AuditItem[]>(mockAudits);
  const [searchValue, setSearchValue] = useState("");
  const [activeFilter, setActiveFilter] = useState<string | null>(null);

  const metrics = {
    total: audits.length,
    pending: audits.filter((a) => a.status === "pending" || a.status === "in-review").length,
    completed: audits.filter((a) => a.status === "completed").length,
    overdue: audits.filter((a) => a.status === "overdue").length,
  };

  const filteredAudits = audits.filter((a) => {
    const matchesSearch =
      a.title.toLowerCase().includes(searchValue.toLowerCase()) ||
      a.id.toLowerCase().includes(searchValue.toLowerCase());
    const matchesFilter =
      !activeFilter ||
      (activeFilter === "total") ||
      (activeFilter === "pending" && (a.status === "pending" || a.status === "in-review")) ||
      (activeFilter === "completed" && a.status === "completed") ||
      (activeFilter === "overdue" && a.status === "overdue");
    return matchesSearch && matchesFilter;
  });

  const upcomingDeadlines = audits
    .filter((a) => a.status !== "completed")
    .sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime())
    .slice(0, 5)
    .map((a) => ({
      id: a.id,
      title: a.title,
      dueDate: a.deadline,
      priority: a.priority,
    }));

  const columns: Column<AuditItem>[] = [
    { key: "id", header: "Audit ID", className: "font-mono text-sm" },
    { key: "title", header: "Title", render: (item) => <span className="font-medium">{item.title}</span> },
    { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
    { key: "deadline", header: "Deadline" },
    { key: "owner", header: "Owner" },
    { key: "priority", header: "Priority", render: (item) => <PriorityBadge priority={item.priority} /> },
  ];

  const handleView = (audit: AuditItem) => {
    toast({ title: "Opening AuditPro", description: `Viewing ${audit.title}...` });
  };

  const handleEdit = (audit: AuditItem) => {
    toast({ title: "Opening AuditPro", description: `Editing ${audit.title}...` });
  };

  const handleDelete = (audit: AuditItem) => {
    toast({ title: "Audit Deleted", description: `${audit.title} has been removed.`, variant: "destructive" });
  };

  const handleAddNew = () => {
    toast({ title: "Opening AuditPro", description: "Creating new audit item..." });
  };

  const handleDeadlineClick = (item: { id: string }) => {
    const audit = audits.find((a) => a.id === item.id);
    if (audit) handleView(audit);
  };

  return (
    <div className="flex min-h-screen w-full bg-background">
      <DashboardSidebar />

      <main className="flex-1 overflow-auto">
        <PageHeader
          title="Audit Items"
          description="Manage and track all audit activities"
          breadcrumbs={[
            { label: "Management Hub", href: "/" },
            { label: "Audit Items" },
          ]}
          onAddNew={handleAddNew}
          addNewLabel="Add Audit"
        />

        <div className="p-8 max-w-7xl space-y-6">
          {/* Metrics Tiles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricsTile
              title="Total Audits"
              value={metrics.total}
              icon={ClipboardCheck}
              variant="default"
              onClick={() => setActiveFilter(activeFilter === "total" ? null : "total")}
              active={activeFilter === "total"}
            />
            <MetricsTile
              title="Pending Review"
              value={metrics.pending}
              icon={Clock}
              variant="warning"
              onClick={() => setActiveFilter(activeFilter === "pending" ? null : "pending")}
              active={activeFilter === "pending"}
            />
            <MetricsTile
              title="Completed"
              value={metrics.completed}
              icon={CheckCircle}
              variant="success"
              onClick={() => setActiveFilter(activeFilter === "completed" ? null : "completed")}
              active={activeFilter === "completed"}
            />
            <MetricsTile
              title="Overdue"
              value={metrics.overdue}
              icon={AlertTriangle}
              variant="destructive"
              onClick={() => setActiveFilter(activeFilter === "overdue" ? null : "overdue")}
              active={activeFilter === "overdue"}
            />
          </div>

          {/* Filter and Table */}
          <FilterBar
            searchPlaceholder="Search by audit title or ID..."
            searchValue={searchValue}
            onSearchChange={setSearchValue}
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <DataTable
                columns={columns}
                data={filteredAudits}
                onView={handleView}
                onEdit={handleEdit}
                onDelete={handleDelete}
                emptyMessage="No audits found"
              />
            </div>
            <div>
              <UpcomingDeadlines
                deadlines={upcomingDeadlines}
                onItemClick={handleDeadlineClick}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AuditItems;
