import { useState } from "react";
import DashboardSidebar from "@/components/layout/DashboardSidebar";
import PageHeader from "@/components/compliance/PageHeader";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { FileText, Download, Printer } from "lucide-react";

interface DocumentSection {
  id: string;
  title: string;
  content: React.ReactNode;
}

const Documentation = () => {
  const [activeTab, setActiveTab] = useState("prd");

  const handlePrint = (docId: string) => {
    const printContent = document.getElementById(`doc-${docId}`);
    if (printContent) {
      const printWindow = window.open("", "_blank");
      if (printWindow) {
        printWindow.document.write(`
          <!DOCTYPE html>
          <html>
          <head>
            <title>${documents.find(d => d.id === docId)?.title || "Document"}</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 40px; line-height: 1.6; color: #333; }
              h1 { color: #1B58A0; border-bottom: 2px solid #1B58A0; padding-bottom: 10px; }
              h2 { color: #0B3571; margin-top: 30px; }
              h3 { color: #5476A4; margin-top: 20px; }
              h4 { color: #666; margin-top: 15px; }
              table { width: 100%; border-collapse: collapse; margin: 20px 0; }
              th, td { border: 1px solid #E2E8F0; padding: 12px; text-align: left; }
              th { background: #F1F5F9; font-weight: 600; }
              ul, ol { margin: 10px 0; padding-left: 25px; }
              pre { background: #f4f4f4; padding: 15px; border-radius: 5px; overflow-x: auto; font-size: 12px; }
              code { background: #f4f4f4; padding: 2px 6px; border-radius: 3px; }
              .header { text-align: center; margin-bottom: 40px; }
              .footer { margin-top: 40px; text-align: center; font-size: 12px; color: #666; }
              @media print { body { padding: 20px; } }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>MedComply - Organizational Leadership Compliance Dashboard</h1>
              <p>Generated: ${new Date().toLocaleDateString()}</p>
            </div>
            ${printContent.innerHTML}
            <div class="footer">
              <p>© ${new Date().getFullYear()} MedComply. All rights reserved.</p>
            </div>
          </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  const documents: DocumentSection[] = [
    {
      id: "prd",
      title: "Product Requirements Document (PRD)",
      content: (
        <div className="prose prose-sm max-w-none">
          <h1>Product Requirements Document</h1>
          <p><strong>Product:</strong> MedComply - Organizational Leadership Compliance Dashboard</p>
          <p><strong>Version:</strong> 2.0</p>
          <p><strong>Last Updated:</strong> {new Date().toLocaleDateString()}</p>

          <h2>1. Executive Summary</h2>
          <p>MedComply is a comprehensive healthcare compliance management system designed for leadership teams to monitor, track, and manage organizational compliance activities. The platform provides real-time visibility into compliance status, risk management, regulatory requirements, and meeting governance with full CRUD operations.</p>

          <h2>2. Product Vision</h2>
          <p>To provide healthcare organizations with a centralized, intuitive platform that simplifies compliance management, reduces regulatory risk, and enables proactive decision-making through actionable insights and comprehensive audit trails.</p>

          <h2>3. Target Users</h2>
          <table>
            <thead>
              <tr><th>Role</th><th>Description</th><th>Primary Needs</th><th>Access Level</th></tr>
            </thead>
            <tbody>
              <tr><td>Compliance Head</td><td>Chief Compliance Officer or equivalent</td><td>Full visibility, reporting, strategic oversight</td><td>Full CRUD access</td></tr>
              <tr><td>Department Head</td><td>Department managers and supervisors</td><td>Department-specific tasks and metrics</td><td>Limited CRUD access</td></tr>
              <tr><td>View Only (Staff)</td><td>General staff members</td><td>Read-only access to relevant information</td><td>Read-only access</td></tr>
            </tbody>
          </table>

          <h2>4. Core Features</h2>
          <h3>4.1 Dashboard Home</h3>
          <ul>
            <li><strong>Action Center:</strong> Today Board with tabs (Today, This Week, Overdue), quick filters, progress tracking, task CRUD operations</li>
            <li><strong>Review Queue:</strong> Pending items requiring review and sign-off</li>
            <li><strong>Quick Stats:</strong> Real-time KPIs (Total, Completed, Pending, Overdue)</li>
            <li><strong>Quality KPIs:</strong> Compliance metrics with formulas, targets, and inline editing</li>
            <li><strong>Quick Access:</strong> Micro applications for specialized functions</li>
            <li><strong>Role Impersonation:</strong> Switch between Compliance Head, Department Head, and View Only roles</li>
          </ul>

          <h3>4.2 Management Hub</h3>
          <ul>
            <li>Governing Body Org Chart</li>
            <li>Audit Items Management</li>
            <li>Citations Tracking</li>
            <li>Enforcements Tracking</li>
            <li>Risk Management (Risks & Thresholds, Policies & Procedures)</li>
            <li>Compliance Tracking (Compliance Items, Meeting Minutes with Full CRUD)</li>
            <li>Documentation Center (PRD, TDD, QA, UAT, System Prompt)</li>
          </ul>

          <h3>4.3 Meeting Minutes Module (New in v2.0)</h3>
          <ul>
            <li><strong>Create:</strong> Comprehensive form with meeting details, attendees, agenda, discussion notes, decisions, action items</li>
            <li><strong>Read:</strong> Detailed view dialog with all meeting information</li>
            <li><strong>Update:</strong> Edit form with version control and audit trail</li>
            <li><strong>Delete:</strong> Soft delete with confirmation dialog</li>
            <li><strong>Version History:</strong> Track all changes with editor, date, and change description</li>
            <li><strong>Action Items:</strong> Assign tasks with due dates and status tracking</li>
            <li><strong>Next Meeting:</strong> Schedule follow-up with preliminary agenda</li>
          </ul>

          <h3>4.4 Micro Applications</h3>
          <ul>
            <li>ComplianceConnect - Compliance management hub</li>
            <li>FeedbackHub - Stakeholder feedback system</li>
            <li>RiskGuard - Risk assessment platform</li>
            <li>AuditPro - Audit management system</li>
            <li>EnforcePoint - Enforcement tracking</li>
          </ul>

          <h2>5. Non-Functional Requirements</h2>
          <table>
            <thead>
              <tr><th>Requirement</th><th>Specification</th></tr>
            </thead>
            <tbody>
              <tr><td>Accessibility</td><td>WCAG 2.1 AA Compliant</td></tr>
              <tr><td>Responsiveness</td><td>Desktop, Tablet, Mobile support</td></tr>
              <tr><td>Performance</td><td>Page load under 3 seconds</td></tr>
              <tr><td>Browser Support</td><td>Chrome, Firefox, Safari, Edge (latest 2 versions)</td></tr>
              <tr><td>Security</td><td>Role-based access control, data encryption, audit logging</td></tr>
              <tr><td>Data Integrity</td><td>Version control for all compliance artifacts</td></tr>
            </tbody>
          </table>

          <h2>6. Success Metrics</h2>
          <ul>
            <li>90% reduction in manual compliance tracking time</li>
            <li>95% user satisfaction score</li>
            <li>100% regulatory audit pass rate</li>
            <li>50% reduction in overdue compliance items</li>
            <li>100% meeting minutes captured and approved within 5 business days</li>
          </ul>
        </div>
      ),
    },
    {
      id: "tdd",
      title: "Technical Design Document (TDD)",
      content: (
        <div className="prose prose-sm max-w-none">
          <h1>Technical Design Document</h1>
          <p><strong>Product:</strong> MedComply - Organizational Leadership Compliance Dashboard</p>
          <p><strong>Version:</strong> 2.0</p>
          <p><strong>Last Updated:</strong> {new Date().toLocaleDateString()}</p>

          <h2>1. System Architecture</h2>
          <h3>1.1 Technology Stack</h3>
          <table>
            <thead>
              <tr><th>Layer</th><th>Technology</th><th>Purpose</th></tr>
            </thead>
            <tbody>
              <tr><td>Frontend</td><td>React 18, TypeScript</td><td>UI Development</td></tr>
              <tr><td>Styling</td><td>Tailwind CSS, shadcn/ui</td><td>Component styling and design system</td></tr>
              <tr><td>Forms</td><td>React Hook Form, Zod</td><td>Form handling and validation</td></tr>
              <tr><td>State Management</td><td>React Query, React State</td><td>Data fetching, caching, and state</td></tr>
              <tr><td>Routing</td><td>React Router v6</td><td>Client-side routing</td></tr>
              <tr><td>Build Tool</td><td>Vite</td><td>Development and bundling</td></tr>
              <tr><td>Backend</td><td>Supabase (Lovable Cloud)</td><td>Database, Auth, Edge Functions</td></tr>
              <tr><td>Date Handling</td><td>date-fns</td><td>Date formatting and manipulation</td></tr>
            </tbody>
          </table>

          <h3>1.2 Component Architecture</h3>
          <pre>{`
src/
├── components/
│   ├── ui/                    # shadcn/ui base components
│   ├── dashboard/             # Dashboard-specific components
│   │   ├── ActionCenter.tsx
│   │   ├── AddTaskModal.tsx
│   │   ├── KpiChips.tsx
│   │   ├── QualityKpis.tsx
│   │   ├── QuickAccess.tsx
│   │   ├── QuickStats.tsx
│   │   ├── ReviewQueue.tsx
│   │   ├── RoleImpersonation.tsx
│   │   ├── StatCard.tsx
│   │   └── TaskDetailDrawer.tsx
│   ├── compliance/            # Compliance module components
│   │   ├── FilterBar.tsx
│   │   ├── MeetingMinuteForm.tsx
│   │   ├── MeetingMinuteViewDialog.tsx
│   │   ├── MetricsTile.tsx
│   │   ├── PageHeader.tsx
│   │   ├── PriorityBadge.tsx
│   │   ├── StatusBadge.tsx
│   │   └── UpcomingDeadlines.tsx
│   └── layout/
│       └── DashboardSidebar.tsx
├── pages/
│   ├── Index.tsx              # Main dashboard
│   └── compliance/
│       ├── AuditItems.tsx
│       ├── Citations.tsx
│       ├── ComplianceItems.tsx
│       ├── ComplianceTracking.tsx
│       ├── Documentation.tsx
│       ├── Enforcements.tsx
│       ├── GoverningBodyOrgChart.tsx
│       ├── MeetingMinutes.tsx
│       ├── PoliciesProcedures.tsx
│       ├── RiskManagement.tsx
│       └── RisksThresholds.tsx
├── hooks/
│   ├── use-mobile.tsx
│   └── use-toast.ts
└── lib/
    └── utils.ts
          `}</pre>

          <h2>2. Database Schema</h2>
          <h3>2.1 Core Tables</h3>
          <table>
            <thead>
              <tr><th>Table</th><th>Purpose</th><th>Key Fields</th></tr>
            </thead>
            <tbody>
              <tr><td>users</td><td>User authentication</td><td>id, email, role</td></tr>
              <tr><td>user_roles</td><td>Role management</td><td>id, user_id, role (enum)</td></tr>
              <tr><td>tasks</td><td>Action center tasks</td><td>id, title, status, priority, due_date, owner_id</td></tr>
              <tr><td>compliance_items</td><td>Compliance tracking</td><td>id, description, status, category, deadline</td></tr>
              <tr><td>risks</td><td>Risk management</td><td>id, description, level, mitigation_type</td></tr>
              <tr><td>policies</td><td>Policies and procedures</td><td>id, name, category, status, version</td></tr>
              <tr><td>meeting_minutes</td><td>Meeting records</td><td>id, title, date, location, meeting_type, status, version</td></tr>
              <tr><td>meeting_attendees</td><td>Meeting attendees</td><td>id, meeting_id, name, role, present</td></tr>
              <tr><td>meeting_action_items</td><td>Action items from meetings</td><td>id, meeting_id, description, assignee, due_date, status</td></tr>
              <tr><td>meeting_versions</td><td>Version history</td><td>id, meeting_id, version, editor, changes, created_at</td></tr>
              <tr><td>kpis</td><td>Quality metrics</td><td>id, name, value, target, formula</td></tr>
            </tbody>
          </table>

          <h3>2.2 Meeting Minutes Schema Detail</h3>
          <pre>{`
CREATE TABLE meeting_minutes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(200) NOT NULL,
  date DATE NOT NULL,
  location VARCHAR(100) NOT NULL,
  meeting_type VARCHAR(50) NOT NULL,
  chairperson VARCHAR(100) NOT NULL,
  secretary VARCHAR(100) NOT NULL,
  status VARCHAR(20) DEFAULT 'draft',
  agenda TEXT NOT NULL,
  discussion_notes TEXT,
  decisions TEXT,
  next_meeting_date DATE,
  next_meeting_agenda TEXT,
  version INTEGER DEFAULT 1,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE meeting_attendees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id UUID REFERENCES meeting_minutes(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  role VARCHAR(100) NOT NULL,
  present BOOLEAN DEFAULT true
);

CREATE TABLE meeting_action_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id UUID REFERENCES meeting_minutes(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  assignee VARCHAR(100) NOT NULL,
  due_date DATE,
  status VARCHAR(20) DEFAULT 'pending'
);
          `}</pre>

          <h2>3. API Design</h2>
          <h3>3.1 Meeting Minutes Endpoints</h3>
          <table>
            <thead>
              <tr><th>Endpoint</th><th>Method</th><th>Description</th></tr>
            </thead>
            <tbody>
              <tr><td>/api/meeting-minutes</td><td>GET</td><td>List all meeting minutes with pagination</td></tr>
              <tr><td>/api/meeting-minutes</td><td>POST</td><td>Create new meeting minute</td></tr>
              <tr><td>/api/meeting-minutes/:id</td><td>GET</td><td>Get meeting minute details</td></tr>
              <tr><td>/api/meeting-minutes/:id</td><td>PUT</td><td>Update meeting minute (creates new version)</td></tr>
              <tr><td>/api/meeting-minutes/:id</td><td>DELETE</td><td>Delete meeting minute</td></tr>
              <tr><td>/api/meeting-minutes/:id/versions</td><td>GET</td><td>Get version history</td></tr>
              <tr><td>/api/meeting-minutes/:id/attendees</td><td>GET, POST</td><td>Manage attendees</td></tr>
              <tr><td>/api/meeting-minutes/:id/action-items</td><td>GET, POST, PUT</td><td>Manage action items</td></tr>
            </tbody>
          </table>

          <h2>4. Security Design</h2>
          <h3>4.1 Authentication</h3>
          <ul>
            <li>JWT-based authentication via Supabase Auth</li>
            <li>Session management with refresh tokens</li>
            <li>Password requirements: minimum 8 characters, mixed case, numbers</li>
          </ul>

          <h3>4.2 Authorization (RBAC)</h3>
          <table>
            <thead>
              <tr><th>Role</th><th>Permissions</th></tr>
            </thead>
            <tbody>
              <tr><td>Compliance Head</td><td>Full CRUD on all resources, approve meeting minutes, manage users</td></tr>
              <tr><td>Department Head</td><td>CRUD on department resources, create/edit meeting minutes</td></tr>
              <tr><td>View Only</td><td>Read-only access to all resources, download documents</td></tr>
            </tbody>
          </table>

          <h2>5. Form Validation Schema</h2>
          <h3>5.1 Meeting Minute Form</h3>
          <pre>{`
const meetingMinuteSchema = z.object({
  title: z.string().min(1).max(200),
  date: z.date(),
  location: z.string().min(1).max(100),
  meetingType: z.string().min(1),
  chairperson: z.string().min(1).max(100),
  secretary: z.string().min(1).max(100),
  status: z.enum(["draft", "pending", "approved"]),
  agenda: z.string().min(1).max(2000),
  discussionNotes: z.string().max(5000).optional(),
  decisions: z.string().max(2000).optional(),
  nextMeetingDate: z.date().optional(),
  nextMeetingAgenda: z.string().max(1000).optional(),
});
          `}</pre>
        </div>
      ),
    },
    {
      id: "qa",
      title: "QA Test Cases",
      content: (
        <div className="prose prose-sm max-w-none">
          <h1>QA Test Cases Document</h1>
          <p><strong>Product:</strong> MedComply - Organizational Leadership Compliance Dashboard</p>
          <p><strong>Version:</strong> 2.0</p>
          <p><strong>Last Updated:</strong> {new Date().toLocaleDateString()}</p>

          <h2>1. Dashboard Module Test Cases</h2>
          <table>
            <thead>
              <tr><th>TC ID</th><th>Test Case</th><th>Steps</th><th>Expected Result</th><th>Priority</th></tr>
            </thead>
            <tbody>
              <tr>
                <td>TC-DASH-001</td>
                <td>Dashboard loads correctly</td>
                <td>1. Navigate to dashboard<br/>2. Wait for page load</td>
                <td>All components render without errors</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-DASH-002</td>
                <td>Action Center tabs switch</td>
                <td>1. Click Today tab<br/>2. Click This Week tab<br/>3. Click Overdue tab</td>
                <td>Tasks filter based on selected tab</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-DASH-003</td>
                <td>Quick Stats display correct values</td>
                <td>1. Load dashboard<br/>2. Verify stat counts</td>
                <td>Stats match actual data counts</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-DASH-004</td>
                <td>Add Task modal opens</td>
                <td>1. Click Add Action Item button<br/>2. Modal appears</td>
                <td>Modal opens with form fields</td>
                <td>Medium</td>
              </tr>
              <tr>
                <td>TC-DASH-005</td>
                <td>Role impersonation works</td>
                <td>1. Click role dropdown<br/>2. Select different role</td>
                <td>Role changes and UI updates accordingly</td>
                <td>High</td>
              </tr>
            </tbody>
          </table>

          <h2>2. Meeting Minutes Module Test Cases</h2>
          <table>
            <thead>
              <tr><th>TC ID</th><th>Test Case</th><th>Steps</th><th>Expected Result</th><th>Priority</th></tr>
            </thead>
            <tbody>
              <tr>
                <td>TC-MTG-001</td>
                <td>Meeting Minutes page loads</td>
                <td>1. Navigate to Meeting Minutes page</td>
                <td>Page loads with data table and summary cards</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-MTG-002</td>
                <td>Create new meeting minutes</td>
                <td>1. Click Add Minutes<br/>2. Fill required fields<br/>3. Add attendees<br/>4. Submit form</td>
                <td>New meeting created with success toast</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-MTG-003</td>
                <td>Form validation</td>
                <td>1. Open form<br/>2. Submit without filling fields</td>
                <td>Validation errors shown for required fields</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-MTG-004</td>
                <td>Add attendees</td>
                <td>1. Enter attendee name and role<br/>2. Click add button</td>
                <td>Attendee badge appears in list</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-MTG-005</td>
                <td>Toggle attendee presence</td>
                <td>1. Click on attendee badge</td>
                <td>Presence status toggles (visual change)</td>
                <td>Medium</td>
              </tr>
              <tr>
                <td>TC-MTG-006</td>
                <td>Remove attendee</td>
                <td>1. Click X button on attendee badge</td>
                <td>Attendee removed from list</td>
                <td>Medium</td>
              </tr>
              <tr>
                <td>TC-MTG-007</td>
                <td>Add action items</td>
                <td>1. Enter description, assignee, due date<br/>2. Click add button</td>
                <td>Action item appears in list</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-MTG-008</td>
                <td>View meeting details</td>
                <td>1. Click view icon on table row</td>
                <td>View dialog opens with all meeting details</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-MTG-009</td>
                <td>Edit meeting minutes</td>
                <td>1. Click edit icon<br/>2. Modify fields<br/>3. Save</td>
                <td>Meeting updated with incremented version</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-MTG-010</td>
                <td>Delete meeting minutes</td>
                <td>1. Click delete icon<br/>2. Confirm deletion</td>
                <td>Meeting removed from list</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-MTG-011</td>
                <td>View version history</td>
                <td>1. Click version link in table</td>
                <td>Version history dialog opens</td>
                <td>Medium</td>
              </tr>
              <tr>
                <td>TC-MTG-012</td>
                <td>Search meeting minutes</td>
                <td>1. Enter search term<br/>2. Results filter</td>
                <td>Table shows matching results</td>
                <td>Medium</td>
              </tr>
              <tr>
                <td>TC-MTG-013</td>
                <td>Date picker functionality</td>
                <td>1. Click date field<br/>2. Select date from calendar</td>
                <td>Date selected and displayed correctly</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-MTG-014</td>
                <td>Meeting type dropdown</td>
                <td>1. Click meeting type select<br/>2. Choose option</td>
                <td>Selected type displays in field</td>
                <td>Medium</td>
              </tr>
              <tr>
                <td>TC-MTG-015</td>
                <td>Status change</td>
                <td>1. Edit meeting<br/>2. Change status to approved<br/>3. Save</td>
                <td>Status updates in table display</td>
                <td>High</td>
              </tr>
            </tbody>
          </table>

          <h2>3. KPI Module Test Cases</h2>
          <table>
            <thead>
              <tr><th>TC ID</th><th>Test Case</th><th>Steps</th><th>Expected Result</th><th>Priority</th></tr>
            </thead>
            <tbody>
              <tr>
                <td>TC-KPI-001</td>
                <td>KPI values display correctly</td>
                <td>1. Load dashboard<br/>2. Check KPI section</td>
                <td>All KPIs show values and targets</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-KPI-002</td>
                <td>Add new KPI</td>
                <td>1. Click + button<br/>2. Fill form<br/>3. Submit</td>
                <td>New KPI appears in list</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-KPI-003</td>
                <td>Edit existing KPI</td>
                <td>1. Click KPI name<br/>2. Modify values<br/>3. Save</td>
                <td>KPI updates with new values</td>
                <td>Medium</td>
              </tr>
              <tr>
                <td>TC-KPI-004</td>
                <td>Delete KPI</td>
                <td>1. Hover over KPI<br/>2. Click delete icon<br/>3. Confirm</td>
                <td>KPI removed from list</td>
                <td>Medium</td>
              </tr>
            </tbody>
          </table>

          <h2>4. Compliance Tracking Test Cases</h2>
          <table>
            <thead>
              <tr><th>TC ID</th><th>Test Case</th><th>Steps</th><th>Expected Result</th><th>Priority</th></tr>
            </thead>
            <tbody>
              <tr>
                <td>TC-COMP-001</td>
                <td>Compliance Tracking page loads</td>
                <td>1. Navigate to Compliance Tracking</td>
                <td>Page loads with tabs visible</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-COMP-002</td>
                <td>Tab switching works</td>
                <td>1. Click Meeting Minutes tab</td>
                <td>Meeting minutes data displays with CRUD options</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-COMP-003</td>
                <td>Metrics tiles clickable</td>
                <td>1. Click on metrics tile</td>
                <td>Data filters based on selected metric</td>
                <td>Medium</td>
              </tr>
            </tbody>
          </table>

          <h2>5. Accessibility Test Cases</h2>
          <table>
            <thead>
              <tr><th>TC ID</th><th>Test Case</th><th>Steps</th><th>Expected Result</th><th>Priority</th></tr>
            </thead>
            <tbody>
              <tr>
                <td>TC-A11Y-001</td>
                <td>Keyboard navigation</td>
                <td>1. Tab through page elements</td>
                <td>All interactive elements focusable</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-A11Y-002</td>
                <td>Form field labels</td>
                <td>1. Check all form fields have labels</td>
                <td>All fields properly labeled</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-A11Y-003</td>
                <td>Color contrast</td>
                <td>1. Run contrast checker</td>
                <td>All text meets WCAG AA ratio</td>
                <td>High</td>
              </tr>
              <tr>
                <td>TC-A11Y-004</td>
                <td>Screen reader compatibility</td>
                <td>1. Enable screen reader<br/>2. Navigate form</td>
                <td>All content announced properly</td>
                <td>High</td>
              </tr>
            </tbody>
          </table>
        </div>
      ),
    },
    {
      id: "uat",
      title: "UAT Test Cases",
      content: (
        <div className="prose prose-sm max-w-none">
          <h1>User Acceptance Test Cases</h1>
          <p><strong>Product:</strong> MedComply - Organizational Leadership Compliance Dashboard</p>
          <p><strong>Version:</strong> 2.0</p>
          <p><strong>Last Updated:</strong> {new Date().toLocaleDateString()}</p>

          <h2>1. Introduction</h2>
          <p>This document outlines the User Acceptance Testing (UAT) scenarios to validate that the MedComply system meets business requirements and user expectations, with special focus on the new Meeting Minutes CRUD functionality.</p>

          <h2>2. UAT Scenarios - Meeting Minutes Management</h2>
          <table>
            <thead>
              <tr><th>UAT ID</th><th>Scenario</th><th>Steps</th><th>Acceptance Criteria</th><th>Status</th></tr>
            </thead>
            <tbody>
              <tr>
                <td>UAT-MTG-001</td>
                <td>Create meeting minutes with full details</td>
                <td>1. Click Add Minutes<br/>2. Enter title, date, location<br/>3. Select meeting type<br/>4. Enter chairperson and secretary<br/>5. Add 3+ attendees<br/>6. Enter agenda and notes<br/>7. Add 2 action items<br/>8. Set next meeting date<br/>9. Submit</td>
                <td>Meeting created with all fields saved correctly</td>
                <td>☐</td>
              </tr>
              <tr>
                <td>UAT-MTG-002</td>
                <td>Edit and version meeting minutes</td>
                <td>1. Select existing meeting<br/>2. Click Edit<br/>3. Modify discussion notes<br/>4. Add new action item<br/>5. Save changes</td>
                <td>Version increments, changes saved, audit trail updated</td>
                <td>☐</td>
              </tr>
              <tr>
                <td>UAT-MTG-003</td>
                <td>Approve meeting minutes workflow</td>
                <td>1. Edit meeting<br/>2. Change status from draft to pending<br/>3. Save<br/>4. Edit again<br/>5. Change to approved<br/>6. Save</td>
                <td>Status workflow completes, version history tracks approver</td>
                <td>☐</td>
              </tr>
              <tr>
                <td>UAT-MTG-004</td>
                <td>Track action items from meetings</td>
                <td>1. View meeting details<br/>2. Review action items list<br/>3. Verify assignees and due dates</td>
                <td>All action items visible with correct details</td>
                <td>☐</td>
              </tr>
              <tr>
                <td>UAT-MTG-005</td>
                <td>View meeting version history</td>
                <td>1. Click version number in table<br/>2. Review all version entries</td>
                <td>Complete history with editor, date, and changes shown</td>
                <td>☐</td>
              </tr>
            </tbody>
          </table>

          <h2>3. UAT Scenarios - Compliance Head Role</h2>
          <table>
            <thead>
              <tr><th>UAT ID</th><th>Scenario</th><th>Steps</th><th>Acceptance Criteria</th><th>Status</th></tr>
            </thead>
            <tbody>
              <tr>
                <td>UAT-CH-001</td>
                <td>View organization-wide compliance status</td>
                <td>1. Login as Compliance Head<br/>2. Navigate to Dashboard<br/>3. Review Quick Stats</td>
                <td>Can see total, completed, pending, overdue counts</td>
                <td>☐</td>
              </tr>
              <tr>
                <td>UAT-CH-002</td>
                <td>Monitor Quality KPIs</td>
                <td>1. View Quality KPIs section<br/>2. Review each metric</td>
                <td>All KPIs display with values, targets, and formulas</td>
                <td>☐</td>
              </tr>
              <tr>
                <td>UAT-CH-003</td>
                <td>Full meeting minutes management</td>
                <td>1. Navigate to Meeting Minutes<br/>2. Create, edit, delete meetings</td>
                <td>Full CRUD access available</td>
                <td>☐</td>
              </tr>
              <tr>
                <td>UAT-CH-004</td>
                <td>Access documentation</td>
                <td>1. Navigate to Documentation<br/>2. View and download all docs</td>
                <td>All documents accessible and downloadable</td>
                <td>☐</td>
              </tr>
            </tbody>
          </table>

          <h2>4. UAT Scenarios - Department Head Role</h2>
          <table>
            <thead>
              <tr><th>UAT ID</th><th>Scenario</th><th>Steps</th><th>Acceptance Criteria</th><th>Status</th></tr>
            </thead>
            <tbody>
              <tr>
                <td>UAT-DH-001</td>
                <td>View department compliance status</td>
                <td>1. Login as Department Head<br/>2. Navigate to Dashboard</td>
                <td>Department-specific data visible</td>
                <td>☐</td>
              </tr>
              <tr>
                <td>UAT-DH-002</td>
                <td>Create meeting minutes</td>
                <td>1. Navigate to Meeting Minutes<br/>2. Create new meeting</td>
                <td>Can create meetings with draft status</td>
                <td>☐</td>
              </tr>
              <tr>
                <td>UAT-DH-003</td>
                <td>Edit own meeting minutes</td>
                <td>1. Select meeting created by self<br/>2. Edit and save</td>
                <td>Can edit own meetings</td>
                <td>☐</td>
              </tr>
            </tbody>
          </table>

          <h2>5. UAT Scenarios - View Only (Staff) Role</h2>
          <table>
            <thead>
              <tr><th>UAT ID</th><th>Scenario</th><th>Steps</th><th>Acceptance Criteria</th><th>Status</th></tr>
            </thead>
            <tbody>
              <tr>
                <td>UAT-VO-001</td>
                <td>View meeting minutes read-only</td>
                <td>1. Login as Staff<br/>2. Navigate to Meeting Minutes</td>
                <td>Can view meetings, no edit/delete buttons visible</td>
                <td>☐</td>
              </tr>
              <tr>
                <td>UAT-VO-002</td>
                <td>Access documentation</td>
                <td>1. Navigate to Documentation<br/>2. Download documents</td>
                <td>Can view and download all documentation</td>
                <td>☐</td>
              </tr>
              <tr>
                <td>UAT-VO-003</td>
                <td>View assigned action items</td>
                <td>1. View meeting with assigned action items</td>
                <td>Can see action items assigned to self</td>
                <td>☐</td>
              </tr>
            </tbody>
          </table>

          <h2>6. UAT Scenarios - Cross-Functional</h2>
          <table>
            <thead>
              <tr><th>UAT ID</th><th>Scenario</th><th>Steps</th><th>Acceptance Criteria</th><th>Status</th></tr>
            </thead>
            <tbody>
              <tr>
                <td>UAT-CF-001</td>
                <td>Mobile responsiveness</td>
                <td>1. Access on mobile device<br/>2. Navigate Meeting Minutes</td>
                <td>Forms and tables usable on mobile</td>
                <td>☐</td>
              </tr>
              <tr>
                <td>UAT-CF-002</td>
                <td>Role switching</td>
                <td>1. Use role impersonation<br/>2. Switch between all roles</td>
                <td>UI updates correctly for each role</td>
                <td>☐</td>
              </tr>
              <tr>
                <td>UAT-CF-003</td>
                <td>Search functionality</td>
                <td>1. Search in Meeting Minutes<br/>2. Search in Compliance Tracking</td>
                <td>Search returns relevant results</td>
                <td>☐</td>
              </tr>
              <tr>
                <td>UAT-CF-004</td>
                <td>Data persistence</td>
                <td>1. Create meeting<br/>2. Navigate away<br/>3. Return to page</td>
                <td>Data persists after navigation</td>
                <td>☐</td>
              </tr>
            </tbody>
          </table>

          <h2>7. Sign-Off</h2>
          <table>
            <thead>
              <tr><th>Role</th><th>Name</th><th>Signature</th><th>Date</th></tr>
            </thead>
            <tbody>
              <tr><td>Business Owner</td><td>_________________</td><td>_________________</td><td>_________________</td></tr>
              <tr><td>Project Manager</td><td>_________________</td><td>_________________</td><td>_________________</td></tr>
              <tr><td>QA Lead</td><td>_________________</td><td>_________________</td><td>_________________</td></tr>
              <tr><td>User Representative</td><td>_________________</td><td>_________________</td><td>_________________</td></tr>
            </tbody>
          </table>
        </div>
      ),
    },
    {
      id: "system",
      title: "System Prompt Document",
      content: (
        <div className="prose prose-sm max-w-none">
          <h1>System Prompt Document</h1>
          <p><strong>Product:</strong> MedComply - Organizational Leadership Compliance Dashboard</p>
          <p><strong>Version:</strong> 2.0 Final</p>
          <p><strong>Last Updated:</strong> {new Date().toLocaleDateString()}</p>

          <h2>1. System Overview</h2>
          <p>MedComply is a comprehensive healthcare compliance management platform designed to streamline regulatory compliance tracking, risk management, and governance activities for healthcare organizations.</p>

          <h2>2. Core System Behaviors</h2>
          <h3>2.1 Authentication & Authorization</h3>
          <pre>{`
SYSTEM BEHAVIOR: AUTHENTICATION
- Users must authenticate before accessing any system functionality
- JWT tokens issued via Supabase Auth with 1-hour expiration
- Refresh tokens handled automatically for seamless session continuity
- Failed login attempts limited to 5 per 15-minute window

SYSTEM BEHAVIOR: AUTHORIZATION
- Role-based access control (RBAC) with three defined roles:
  * Compliance Head: Full system access
  * Department Head: Department-scoped access
  * View Only: Read-only access
- Row Level Security (RLS) policies enforce data access at database level
- Roles stored in separate user_roles table (never on user profile)
          `}</pre>

          <h3>2.2 Data Validation Rules</h3>
          <pre>{`
VALIDATION: MEETING MINUTES
- Title: Required, 1-200 characters
- Date: Required, valid date format
- Location: Required, 1-100 characters
- Meeting Type: Required, predefined list
- Chairperson: Required, 1-100 characters
- Secretary: Required, 1-100 characters
- Status: Enum [draft, pending, approved]
- Agenda: Required, 1-2000 characters
- Discussion Notes: Optional, max 5000 characters
- Decisions: Optional, max 2000 characters
- Next Meeting Agenda: Optional, max 1000 characters

VALIDATION: ATTENDEES
- Name: Required, non-empty
- Role: Required, non-empty
- Present: Boolean, default true

VALIDATION: ACTION ITEMS
- Description: Required, non-empty
- Assignee: Required, non-empty
- Due Date: Optional, valid date
- Status: Enum [pending, in-progress, completed]
          `}</pre>

          <h3>2.3 Version Control Behavior</h3>
          <pre>{`
SYSTEM BEHAVIOR: VERSIONING
- All meeting minutes are versioned
- Version increments on every save operation
- Version history tracks:
  * Version number
  * Editor name
  * Timestamp
  * Change description
- Previous versions are immutable
- Current version is always editable (if user has permission)
          `}</pre>

          <h2>3. UI/UX Interaction Patterns</h2>
          <h3>3.1 Navigation</h3>
          <pre>{`
NAVIGATION STRUCTURE:
Dashboard (/)
├── Action Center (Today Board)
├── Review Queue
├── Quick Stats
├── Quality KPIs
└── Quick Access (Micro Apps)

Management Hub
├── Governing Body Org Chart (/governing-body)
├── Audit Items (/audit-items)
├── Citations (/citations)
├── Enforcements (/enforcements)
├── Risk Management (/risk-management)
│   ├── Risks & Thresholds
│   └── Policies & Procedures
├── Compliance Tracking (/compliance)
│   ├── Compliance Items
│   └── Meeting Minutes
└── Documentation (/documentation)
          `}</pre>

          <h3>3.2 Form Interactions</h3>
          <pre>{`
FORM BEHAVIOR: MEETING MINUTES
- Form opens in sliding sheet from right
- Required fields marked with asterisk (*)
- Real-time validation on blur
- Submit validation before save
- Loading state during save operation
- Success toast on completion
- Form closes on successful save
- Cancel button returns to list without saving

FORM BEHAVIOR: ATTENDEES
- Inline add with name and role fields
- Click + button to add to list
- Click badge to toggle presence
- Click X on badge to remove
- Visual distinction for present/absent

FORM BEHAVIOR: ACTION ITEMS
- Inline add with description, assignee, due date
- Click + button to add to list
- Click X on row to remove
- Status default: pending
          `}</pre>

          <h3>3.3 Table Interactions</h3>
          <pre>{`
TABLE BEHAVIOR: DATA DISPLAY
- Paginated results (configurable)
- Sortable columns
- Searchable by title/ID
- Action buttons: View, Edit, Delete
- Empty state message when no data

TABLE BEHAVIOR: STATUS DISPLAY
- Approved: Green badge (bg-success/10 text-success)
- Pending: Yellow badge (bg-warning/10 text-warning)
- Draft: Gray badge (bg-muted text-muted-foreground)

TABLE BEHAVIOR: VERSION LINK
- Clickable version number opens history dialog
- History icon indicates interactivity
          `}</pre>

          <h2>4. Role-Specific Behaviors</h2>
          <pre>{`
ROLE: COMPLIANCE HEAD
- Full visibility across all departments
- Create, read, update, delete all meeting minutes
- Approve meeting minutes (change status to approved)
- Access all documentation
- Manage KPIs (add, edit, delete)
- View all compliance items and risks

ROLE: DEPARTMENT HEAD  
- Department-scoped data visibility
- Create meeting minutes (draft status)
- Edit own meeting minutes
- Cannot delete others' meeting minutes
- View KPIs (read-only)
- View department compliance items

ROLE: VIEW ONLY (STAFF)
- Read-only access to all visible data
- No create/edit/delete capabilities
- View action items assigned to self
- Download documentation
- View meeting minutes details
          `}</pre>

          <h2>5. Error Handling</h2>
          <pre>{`
ERROR BEHAVIOR: VALIDATION
- Field-level errors displayed below input
- Red border on invalid fields
- Error message describes issue
- Form cannot submit with validation errors

ERROR BEHAVIOR: API ERRORS
- Toast notification with error message
- Retry option when appropriate
- Graceful degradation on network failure
- User-friendly error messages (no technical jargon)

ERROR BEHAVIOR: PERMISSIONS
- Hidden UI elements for unauthorized actions
- 403 response for attempted unauthorized API calls
- Redirect to appropriate page on permission denial
          `}</pre>

          <h2>6. Performance Requirements</h2>
          <pre>{`
PERFORMANCE TARGETS:
- Initial page load: < 3 seconds
- Form submission: < 2 seconds
- Search results: < 500ms
- Navigation transitions: < 300ms

OPTIMIZATION STRATEGIES:
- React Query for data caching
- Optimistic updates for better UX
- Lazy loading for route-based code splitting
- Debounced search input
          `}</pre>

          <h2>7. Accessibility Requirements</h2>
          <pre>{`
ACCESSIBILITY (WCAG 2.1 AA):
- All form fields have associated labels
- Color contrast ratio ≥ 4.5:1 for text
- Keyboard navigation for all interactive elements
- Focus indicators visible
- Screen reader compatible
- Error messages announced by screen readers
- Skip links for main content
          `}</pre>

          <h2>8. Security Protocols</h2>
          <pre>{`
SECURITY MEASURES:
- HTTPS only for all communications
- JWT tokens with short expiration
- Role verification on every API call
- Input sanitization for all user input
- SQL injection prevention via parameterized queries
- XSS prevention via React's built-in escaping
- CSRF tokens for state-changing operations
- Audit logging for sensitive operations

DATA PROTECTION:
- Encryption at rest for database
- Encryption in transit (TLS 1.3)
- No PII in URL parameters
- Secure cookie flags (HttpOnly, Secure, SameSite)
          `}</pre>

          <h2>9. Integration Points</h2>
          <pre>{`
EXTERNAL INTEGRATIONS:
- Supabase Auth: User authentication
- Supabase Database: PostgreSQL data storage
- Supabase Edge Functions: Serverless API endpoints
- Email Service: Notification delivery (future)

INTERNAL INTEGRATIONS:
- ComplianceConnect: Compliance item management
- FeedbackHub: Stakeholder feedback
- RiskGuard: Risk assessment
- AuditPro: Audit management
- EnforcePoint: Enforcement tracking
          `}</pre>

          <h2>10. System Prompts for AI Features (Future)</h2>
          <pre>{`
AI ASSISTANT PROMPT (COMPLIANCE HELP):
"You are a healthcare compliance assistant for MedComply. 
Help users understand compliance requirements, interpret 
regulations, and navigate the system. Always cite relevant 
regulations when providing guidance. Never provide legal 
advice - recommend consulting legal counsel for specific 
legal questions."

AI ASSISTANT PROMPT (MEETING SUMMARY):
"You are a meeting minutes assistant. Help users create 
clear, concise meeting summaries from notes. Focus on:
1. Key decisions made
2. Action items with owners
3. Follow-up items
4. Next meeting agenda items
Maintain professional, formal tone appropriate for 
compliance documentation."
          `}</pre>
        </div>
      ),
    },
  ];

  return (
    <div className="flex min-h-screen w-full bg-background">
      <DashboardSidebar />

      <main className="flex-1 overflow-auto">
        <PageHeader
          title="Documentation"
          description="Product documentation, technical specs, and test cases"
          breadcrumbs={[
            { label: "Management Hub", href: "/" },
            { label: "Documentation" },
          ]}
        />

        <div className="p-8 max-w-7xl space-y-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="mb-6 flex-wrap h-auto gap-2">
              {documents.map((doc) => (
                <TabsTrigger key={doc.id} value={doc.id} className="gap-2">
                  <FileText className="h-4 w-4" />
                  {doc.id.toUpperCase()}
                </TabsTrigger>
              ))}
            </TabsList>

            {documents.map((doc) => (
              <TabsContent key={doc.id} value={doc.id}>
                <div className="bg-card rounded-xl card-shadow">
                  {/* Document Header */}
                  <div className="flex items-center justify-between p-4 border-b border-border">
                    <h2 className="text-lg font-semibold text-card-foreground">{doc.title}</h2>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePrint(doc.id)}
                        className="gap-2"
                      >
                        <Download className="h-4 w-4" />
                        Download PDF
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePrint(doc.id)}
                        className="gap-2"
                      >
                        <Printer className="h-4 w-4" />
                        Print
                      </Button>
                    </div>
                  </div>

                  {/* Document Content */}
                  <div id={`doc-${doc.id}`} className="p-6 overflow-auto max-h-[70vh]">
                    {doc.content}
                  </div>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </main>
    </div>
  );
};

export default Documentation;
