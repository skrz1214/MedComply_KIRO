import { useState } from "react";
import DashboardSidebar from "@/components/layout/DashboardSidebar";
import PageHeader from "@/components/compliance/PageHeader";
import { DataTable, Column } from "@/components/ui/data-table";
import FilterBar from "@/components/compliance/FilterBar";
import MetricsTile from "@/components/compliance/MetricsTile";
import UpcomingDeadlines from "@/components/compliance/UpcomingDeadlines";
import StatusBadge from "@/components/compliance/StatusBadge";
import PriorityBadge from "@/components/compliance/PriorityBadge";
import { toast } from "@/hooks/use-toast";
import { Scale, Clock, CheckCircle, AlertTriangle } from "lucide-react";

interface Enforcement {
  id: string;
  title: string;
  status: "pending" | "completed" | "overdue" | "active";
  dueDate: string;
  owner: string;
  priority: "high" | "medium" | "low";
}

const mockEnforcements: Enforcement[] = [
  { id: "ENF-001", title: "OSHA Violation Corrective Action", status: "pending", dueDate: "2024-12-20", owner: "Robert Martinez", priority: "high" },
  { id: "ENF-002", title: "Fire Safety Code Compliance", status: "completed", dueDate: "2024-09-15", owner: "David Thompson", priority: "medium" },
  { id: "ENF-003", title: "CMS Regulation Update Implementation", status: "active", dueDate: "2024-11-30", owner: "Dr. Sarah Johnson", priority: "high" },
  { id: "ENF-004", title: "State Health Department Citation Response", status: "overdue", dueDate: "2024-10-10", owner: "Patricia Williams", priority: "high" },
  { id: "ENF-005", title: "Joint Commission Standard Remediation", status: "pending", dueDate: "2024-12-01", owner: "Michael Chen", priority: "medium" },
];

const Enforcements = () => {
  const [enforcements] = useState<Enforcement[]>(mockEnforcements);
  const [searchValue, setSearchValue] = useState("");
  const [activeFilter, setActiveFilter] = useState<string | null>(null);

  const metrics = {
    total: enforcements.length,
    pending: enforcements.filter((e) => e.status === "pending" || e.status === "active").length,
    completed: enforcements.filter((e) => e.status === "completed").length,
    overdue: enforcements.filter((e) => e.status === "overdue").length,
  };

  const filteredEnforcements = enforcements.filter((e) => {
    const matchesSearch =
      e.title.toLowerCase().includes(searchValue.toLowerCase()) ||
      e.id.toLowerCase().includes(searchValue.toLowerCase());
    const matchesFilter =
      !activeFilter ||
      (activeFilter === "total") ||
      (activeFilter === "pending" && (e.status === "pending" || e.status === "active")) ||
      (activeFilter === "completed" && e.status === "completed") ||
      (activeFilter === "overdue" && e.status === "overdue");
    return matchesSearch && matchesFilter;
  });

  const upcomingDeadlines = enforcements
    .filter((e) => e.status !== "completed")
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    .slice(0, 5)
    .map((e) => ({
      id: e.id,
      title: e.title,
      dueDate: e.dueDate,
      priority: e.priority,
    }));

  const columns: Column<Enforcement>[] = [
    { key: "id", header: "Enforcement ID", className: "font-mono text-sm" },
    { key: "title", header: "Title", render: (item) => <span className="font-medium">{item.title}</span> },
    { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status === "active" ? "pending" : item.status} /> },
    { key: "dueDate", header: "Due Date" },
    { key: "owner", header: "Owner" },
    { key: "priority", header: "Priority", render: (item) => <PriorityBadge priority={item.priority} /> },
  ];

  const handleView = (enforcement: Enforcement) => {
    toast({ title: "Opening EnforcePoint", description: `Viewing ${enforcement.title}...` });
  };

  const handleEdit = (enforcement: Enforcement) => {
    toast({ title: "Opening EnforcePoint", description: `Editing ${enforcement.title}...` });
  };

  const handleDelete = (enforcement: Enforcement) => {
    toast({ title: "Enforcement Deleted", description: `${enforcement.title} has been removed.`, variant: "destructive" });
  };

  const handleAddNew = () => {
    toast({ title: "Opening EnforcePoint", description: "Creating new enforcement item..." });
  };

  return (
    <div className="flex min-h-screen w-full bg-background">
      <DashboardSidebar />

      <main className="flex-1 overflow-auto">
        <PageHeader
          title="Enforcements"
          description="Track regulatory enforcements and corrective actions"
          breadcrumbs={[
            { label: "Management Hub", href: "/" },
            { label: "Enforcements" },
          ]}
          onAddNew={handleAddNew}
          addNewLabel="Add Enforcement"
        />

        <div className="p-8 max-w-7xl space-y-6">
          {/* Metrics Tiles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricsTile
              title="Total Enforcements"
              value={metrics.total}
              icon={Scale}
              variant="default"
              onClick={() => setActiveFilter(activeFilter === "total" ? null : "total")}
              active={activeFilter === "total"}
            />
            <MetricsTile
              title="Pending"
              value={metrics.pending}
              icon={Clock}
              variant="warning"
              onClick={() => setActiveFilter(activeFilter === "pending" ? null : "pending")}
              active={activeFilter === "pending"}
            />
            <MetricsTile
              title="Completed"
              value={metrics.completed}
              icon={CheckCircle}
              variant="success"
              onClick={() => setActiveFilter(activeFilter === "completed" ? null : "completed")}
              active={activeFilter === "completed"}
            />
            <MetricsTile
              title="Overdue"
              value={metrics.overdue}
              icon={AlertTriangle}
              variant="destructive"
              onClick={() => setActiveFilter(activeFilter === "overdue" ? null : "overdue")}
              active={activeFilter === "overdue"}
            />
          </div>

          <FilterBar
            searchPlaceholder="Search by enforcement title or ID..."
            searchValue={searchValue}
            onSearchChange={setSearchValue}
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <DataTable
                columns={columns}
                data={filteredEnforcements}
                onView={handleView}
                onEdit={handleEdit}
                onDelete={handleDelete}
                emptyMessage="No enforcements found"
              />
            </div>
            <div>
              <UpcomingDeadlines deadlines={upcomingDeadlines} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Enforcements;
