import { useState } from "react";
import DashboardSidebar from "@/components/layout/DashboardSidebar";
import PageHeader from "@/components/compliance/PageHeader";
import { DataTable, Column } from "@/components/ui/data-table";
import FilterBar from "@/components/compliance/FilterBar";
import MetricsTile from "@/components/compliance/MetricsTile";
import UpcomingDeadlines from "@/components/compliance/UpcomingDeadlines";
import StatusBadge from "@/components/compliance/StatusBadge";
import { toast } from "@/hooks/use-toast";
import { ShieldCheck, Clock, CheckCircle, AlertTriangle } from "lucide-react";

interface ComplianceItem {
  id: string;
  description: string;
  status: "pending" | "completed" | "overdue" | "in-review";
  owner: string;
  deadline: string;
  category: string;
}

const mockComplianceItems: ComplianceItem[] = [
  { id: "CMP-001", description: "Annual HIPAA Training Completion", status: "pending", owner: "Jennifer Lee", deadline: "2024-12-31", category: "Training" },
  { id: "CMP-002", description: "Privacy Policy Review & Update", status: "completed", owner: "Dr. Sarah Johnson", deadline: "2024-09-30", category: "Policy" },
  { id: "CMP-003", description: "Data Retention Compliance Check", status: "in-review", owner: "Michael Chen", deadline: "2024-11-15", category: "Data" },
  { id: "CMP-004", description: "Business Associate Agreement Renewals", status: "overdue", owner: "Robert Martinez", deadline: "2024-10-01", category: "Legal" },
  { id: "CMP-005", description: "Access Control Audit", status: "pending", owner: "David Thompson", deadline: "2024-12-20", category: "Security" },
  { id: "CMP-006", description: "Incident Response Plan Update", status: "completed", owner: "Patricia Williams", deadline: "2024-08-31", category: "Security" },
];

const ComplianceItems = () => {
  const [items] = useState<ComplianceItem[]>(mockComplianceItems);
  const [searchValue, setSearchValue] = useState("");
  const [activeFilter, setActiveFilter] = useState<string | null>(null);

  const metrics = {
    total: items.length,
    pending: items.filter((i) => i.status === "pending" || i.status === "in-review").length,
    completed: items.filter((i) => i.status === "completed").length,
    overdue: items.filter((i) => i.status === "overdue").length,
  };

  const filteredItems = items.filter((i) => {
    const matchesSearch =
      i.description.toLowerCase().includes(searchValue.toLowerCase()) ||
      i.id.toLowerCase().includes(searchValue.toLowerCase());
    const matchesFilter =
      !activeFilter ||
      (activeFilter === "total") ||
      (activeFilter === "pending" && (i.status === "pending" || i.status === "in-review")) ||
      (activeFilter === "completed" && i.status === "completed") ||
      (activeFilter === "overdue" && i.status === "overdue");
    return matchesSearch && matchesFilter;
  });

  const upcomingDeadlines = items
    .filter((i) => i.status !== "completed")
    .sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime())
    .slice(0, 5)
    .map((i) => ({
      id: i.id,
      title: i.description,
      dueDate: i.deadline,
      priority: i.status === "overdue" ? "high" as const : "medium" as const,
    }));

  const columns: Column<ComplianceItem>[] = [
    { key: "id", header: "Compliance ID", className: "font-mono text-sm" },
    { key: "description", header: "Description", render: (item) => <span className="font-medium">{item.description}</span> },
    { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
    { key: "owner", header: "Owner" },
    { key: "category", header: "Category" },
  ];

  const handleView = (item: ComplianceItem) => {
    toast({ title: "Opening ComplianceConnect", description: `Viewing ${item.description}...` });
  };

  const handleEdit = (item: ComplianceItem) => {
    toast({ title: "Opening ComplianceConnect", description: `Editing ${item.description}...` });
  };

  const handleDelete = (item: ComplianceItem) => {
    toast({ title: "Compliance Item Deleted", description: `${item.description} has been removed.`, variant: "destructive" });
  };

  const handleAddNew = () => {
    toast({ title: "Opening ComplianceConnect", description: "Creating new compliance item..." });
  };

  return (
    <div className="flex min-h-screen w-full bg-background">
      <DashboardSidebar />

      <main className="flex-1 overflow-auto">
        <PageHeader
          title="Compliance Items"
          description="Track and manage compliance requirements"
          breadcrumbs={[
            { label: "Management Hub", href: "/" },
            { label: "Compliance Items" },
          ]}
          onAddNew={handleAddNew}
          addNewLabel="Add Compliance Item"
        />

        <div className="p-8 max-w-7xl space-y-6">
          {/* Metrics Tiles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricsTile
              title="Total Items"
              value={metrics.total}
              icon={ShieldCheck}
              variant="default"
              onClick={() => setActiveFilter(activeFilter === "total" ? null : "total")}
              active={activeFilter === "total"}
            />
            <MetricsTile
              title="Pending Review"
              value={metrics.pending}
              icon={Clock}
              variant="warning"
              onClick={() => setActiveFilter(activeFilter === "pending" ? null : "pending")}
              active={activeFilter === "pending"}
            />
            <MetricsTile
              title="Completed"
              value={metrics.completed}
              icon={CheckCircle}
              variant="success"
              onClick={() => setActiveFilter(activeFilter === "completed" ? null : "completed")}
              active={activeFilter === "completed"}
            />
            <MetricsTile
              title="Overdue"
              value={metrics.overdue}
              icon={AlertTriangle}
              variant="destructive"
              onClick={() => setActiveFilter(activeFilter === "overdue" ? null : "overdue")}
              active={activeFilter === "overdue"}
            />
          </div>

          <FilterBar
            searchPlaceholder="Search by description or ID..."
            searchValue={searchValue}
            onSearchChange={setSearchValue}
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <DataTable
                columns={columns}
                data={filteredItems}
                onView={handleView}
                onEdit={handleEdit}
                onDelete={handleDelete}
                emptyMessage="No compliance items found"
              />
            </div>
            <div>
              <UpcomingDeadlines deadlines={upcomingDeadlines} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ComplianceItems;
