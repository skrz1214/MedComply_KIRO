import { useState } from "react";
import DashboardSidebar from "@/components/layout/DashboardSidebar";
import PageHeader from "@/components/compliance/PageHeader";
import { DataTable, Column } from "@/components/ui/data-table";
import FilterBar from "@/components/compliance/FilterBar";
import MetricsTile from "@/components/compliance/MetricsTile";
import UpcomingDeadlines from "@/components/compliance/UpcomingDeadlines";
import StatusBadge from "@/components/compliance/StatusBadge";
import { toast } from "@/hooks/use-toast";
import { AlertTriangle, Clock, CheckCircle, Shield, ShieldAlert, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

interface Risk {
  id: string;
  description: string;
  level: "high" | "medium" | "low";
  status: "pending" | "completed" | "overdue" | "in-review";
  owner: string;
  deadline: string;
  mitigationType: "preventive" | "detective";
}

interface Policy {
  id: string;
  name: string;
  category: string;
  lastUpdate: string;
  status: "active" | "draft" | "pending" | "in-review";
  nextUpdateDate: string;
  ownerName: string;
}

const mockRisks: Risk[] = [
  { id: "RSK-001", description: "PHI Data Breach Vulnerability", level: "high", status: "pending", owner: "Michael Chen", deadline: "2024-12-15", mitigationType: "preventive" },
  { id: "RSK-002", description: "Third-Party Vendor Access Risk", level: "high", status: "in-review", owner: "David Thompson", deadline: "2024-11-30", mitigationType: "detective" },
  { id: "RSK-003", description: "Staff Compliance Training Gap", level: "medium", status: "completed", owner: "Jennifer Lee", deadline: "2024-10-01", mitigationType: "preventive" },
  { id: "RSK-004", description: "Outdated Security Protocols", level: "high", status: "overdue", owner: "Robert Martinez", deadline: "2024-09-15", mitigationType: "preventive" },
  { id: "RSK-005", description: "Audit Trail Monitoring", level: "medium", status: "pending", owner: "Patricia Williams", deadline: "2024-12-20", mitigationType: "detective" },
  { id: "RSK-006", description: "Physical Access Control", level: "low", status: "completed", owner: "Dr. Sarah Johnson", deadline: "2024-08-31", mitigationType: "preventive" },
];

const mockPolicies: Policy[] = [
  { id: "POL-001", name: "HIPAA Privacy Compliance", category: "Privacy", lastUpdate: "2024-01-15", status: "active", nextUpdateDate: "2025-01-15", ownerName: "Dr. Sarah Johnson" },
  { id: "POL-002", name: "Patient Data Security", category: "Security", lastUpdate: "2024-02-20", status: "active", nextUpdateDate: "2025-02-20", ownerName: "Michael Chen" },
  { id: "POL-003", name: "Medication Administration", category: "Clinical", lastUpdate: "2024-03-10", status: "in-review", nextUpdateDate: "2025-03-10", ownerName: "Patricia Williams" },
  { id: "POL-004", name: "Emergency Response Protocol", category: "Safety", lastUpdate: "2024-01-05", status: "active", nextUpdateDate: "2025-01-05", ownerName: "Robert Martinez" },
  { id: "POL-005", name: "Staff Training Requirements", category: "HR", lastUpdate: "2024-04-01", status: "draft", nextUpdateDate: "2025-04-01", ownerName: "Jennifer Lee" },
  { id: "POL-006", name: "Infection Control Procedures", category: "Clinical", lastUpdate: "2024-02-28", status: "pending", nextUpdateDate: "2025-02-28", ownerName: "David Thompson" },
];

const RiskManagement = () => {
  const [activeTab, setActiveTab] = useState("risks");
  const [risks] = useState<Risk[]>(mockRisks);
  const [policies] = useState<Policy[]>(mockPolicies);
  const [searchValue, setSearchValue] = useState("");
  const [levelFilter, setLevelFilter] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [policyStatusFilter, setPolicyStatusFilter] = useState("all");

  // Risk calculations
  const levelCounts = {
    high: risks.filter((r) => r.level === "high").length,
    medium: risks.filter((r) => r.level === "medium").length,
    low: risks.filter((r) => r.level === "low").length,
  };

  const statusCounts = {
    total: risks.length,
    pending: risks.filter((r) => r.status === "pending" || r.status === "in-review").length,
    completed: risks.filter((r) => r.status === "completed").length,
    overdue: risks.filter((r) => r.status === "overdue").length,
  };

  const filteredRisks = risks.filter((r) => {
    const matchesSearch =
      r.description.toLowerCase().includes(searchValue.toLowerCase()) ||
      r.id.toLowerCase().includes(searchValue.toLowerCase());
    const matchesLevel = !levelFilter || r.level === levelFilter;
    const matchesStatus =
      !statusFilter ||
      (statusFilter === "total") ||
      (statusFilter === "pending" && (r.status === "pending" || r.status === "in-review")) ||
      (statusFilter === "completed" && r.status === "completed") ||
      (statusFilter === "overdue" && r.status === "overdue");
    return matchesSearch && matchesLevel && matchesStatus;
  });

  const filteredPolicies = policies.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchValue.toLowerCase()) ||
      p.id.toLowerCase().includes(searchValue.toLowerCase());
    const matchesCategory = categoryFilter === "all" || p.category === categoryFilter;
    const matchesStatus = policyStatusFilter === "all" || p.status === policyStatusFilter;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const preventiveControls = risks.filter((r) => r.mitigationType === "preventive");
  const detectiveControls = risks.filter((r) => r.mitigationType === "detective");

  const upcomingDeadlines = risks
    .filter((r) => r.status !== "completed")
    .sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime())
    .slice(0, 5)
    .map((r) => ({
      id: r.id,
      title: r.description,
      dueDate: r.deadline,
      priority: r.level,
    }));

  const riskColumns: Column<Risk>[] = [
    { key: "id", header: "Risk ID", className: "font-mono text-sm" },
    { key: "description", header: "Description", render: (item) => <span className="font-medium">{item.description}</span> },
    {
      key: "level",
      header: "Level",
      render: (item) => (
        <span
          className={cn(
            "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
            item.level === "high" && "bg-destructive/10 text-destructive",
            item.level === "medium" && "bg-warning/10 text-warning",
            item.level === "low" && "bg-success/10 text-success"
          )}
        >
          {item.level.toUpperCase()}
        </span>
      ),
    },
    { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
    { key: "owner", header: "Owner" },
  ];

  const policyColumns: Column<Policy>[] = [
    { key: "id", header: "Policy ID", className: "font-mono text-sm" },
    { key: "name", header: "Policy Name", render: (item) => <span className="font-medium">{item.name}</span> },
    { key: "category", header: "Category" },
    { key: "lastUpdate", header: "Last Update" },
    { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
    { key: "ownerName", header: "Owner" },
  ];

  const handleViewRisk = (risk: Risk) => {
    toast({ title: "Opening RiskGuard", description: `Viewing ${risk.description}...` });
  };

  const handleEditRisk = (risk: Risk) => {
    toast({ title: "Opening RiskGuard", description: `Editing ${risk.description}...` });
  };

  const handleDeleteRisk = (risk: Risk) => {
    toast({ title: "Risk Deleted", description: `${risk.description} has been removed.`, variant: "destructive" });
  };

  const handleViewPolicy = (policy: Policy) => {
    toast({ title: "View Policy", description: `Opening ${policy.name}...` });
  };

  const handleEditPolicy = (policy: Policy) => {
    toast({ title: "Edit Policy", description: `Editing ${policy.name}...` });
  };

  const handleDeletePolicy = (policy: Policy) => {
    toast({ title: "Delete Policy", description: `${policy.name} has been deleted.`, variant: "destructive" });
  };

  const handleAddNew = () => {
    if (activeTab === "risks") {
      toast({ title: "Opening RiskGuard", description: "Creating new risk item..." });
    } else {
      toast({ title: "Add New Policy", description: "Opening policy creation form..." });
    }
  };

  const categories = ["all", "Privacy", "Security", "Clinical", "Safety", "HR"];
  const statuses = ["all", "active", "draft", "pending", "in-review"];

  return (
    <div className="flex min-h-screen w-full bg-background">
      <DashboardSidebar />

      <main className="flex-1 overflow-auto">
        <PageHeader
          title="Risk Management"
          description="Monitor risks and manage policies and procedures"
          breadcrumbs={[
            { label: "Management Hub", href: "/" },
            { label: "Risk Management" },
          ]}
          onAddNew={handleAddNew}
          addNewLabel={activeTab === "risks" ? "Add Risk" : "Add Policy"}
        />

        <div className="p-8 max-w-7xl space-y-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="risks">Risks & Thresholds</TabsTrigger>
              <TabsTrigger value="policies">Policies & Procedures</TabsTrigger>
            </TabsList>

            <TabsContent value="risks" className="space-y-6">
              {/* Risk Threshold Tiles */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <button
                  onClick={() => setLevelFilter(levelFilter === "high" ? null : "high")}
                  className={cn(
                    "bg-card rounded-lg p-4 card-shadow hover:card-shadow-hover transition-all border-l-4 border-l-destructive text-left",
                    levelFilter === "high" && "ring-2 ring-destructive ring-offset-2"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">High Risk</p>
                      <p className="text-2xl font-bold text-destructive mt-1">{levelCounts.high}</p>
                    </div>
                    <ShieldAlert className="h-8 w-8 text-destructive/30" />
                  </div>
                </button>
                <button
                  onClick={() => setLevelFilter(levelFilter === "medium" ? null : "medium")}
                  className={cn(
                    "bg-card rounded-lg p-4 card-shadow hover:card-shadow-hover transition-all border-l-4 border-l-warning text-left",
                    levelFilter === "medium" && "ring-2 ring-warning ring-offset-2"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Medium Risk</p>
                      <p className="text-2xl font-bold text-warning mt-1">{levelCounts.medium}</p>
                    </div>
                    <Shield className="h-8 w-8 text-warning/30" />
                  </div>
                </button>
                <button
                  onClick={() => setLevelFilter(levelFilter === "low" ? null : "low")}
                  className={cn(
                    "bg-card rounded-lg p-4 card-shadow hover:card-shadow-hover transition-all border-l-4 border-l-success text-left",
                    levelFilter === "low" && "ring-2 ring-success ring-offset-2"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Low Risk</p>
                      <p className="text-2xl font-bold text-success mt-1">{levelCounts.low}</p>
                    </div>
                    <ShieldCheck className="h-8 w-8 text-success/30" />
                  </div>
                </button>
              </div>

              {/* Status Metrics */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <MetricsTile
                  title="Total Risks"
                  value={statusCounts.total}
                  icon={AlertTriangle}
                  variant="default"
                  onClick={() => setStatusFilter(statusFilter === "total" ? null : "total")}
                  active={statusFilter === "total"}
                />
                <MetricsTile
                  title="Pending Review"
                  value={statusCounts.pending}
                  icon={Clock}
                  variant="warning"
                  onClick={() => setStatusFilter(statusFilter === "pending" ? null : "pending")}
                  active={statusFilter === "pending"}
                />
                <MetricsTile
                  title="Completed"
                  value={statusCounts.completed}
                  icon={CheckCircle}
                  variant="success"
                  onClick={() => setStatusFilter(statusFilter === "completed" ? null : "completed")}
                  active={statusFilter === "completed"}
                />
                <MetricsTile
                  title="Overdue"
                  value={statusCounts.overdue}
                  icon={AlertTriangle}
                  variant="destructive"
                  onClick={() => setStatusFilter(statusFilter === "overdue" ? null : "overdue")}
                  active={statusFilter === "overdue"}
                />
              </div>

              <FilterBar
                searchPlaceholder="Search by risk description or ID..."
                searchValue={searchValue}
                onSearchChange={setSearchValue}
              />

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                  <DataTable
                    columns={riskColumns}
                    data={filteredRisks}
                    onView={handleViewRisk}
                    onEdit={handleEditRisk}
                    onDelete={handleDeleteRisk}
                    emptyMessage="No risks found"
                  />

                  {/* Mitigation Strategies */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-card rounded-lg card-shadow p-5">
                      <h3 className="font-semibold text-card-foreground mb-3 flex items-center gap-2">
                        <Shield className="h-4 w-4 text-primary" />
                        Preventive Controls ({preventiveControls.length})
                      </h3>
                      <div className="space-y-2">
                        {preventiveControls.slice(0, 3).map((r) => (
                          <div key={r.id} className="text-sm p-2 bg-muted/30 rounded">
                            {r.description}
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="bg-card rounded-lg card-shadow p-5">
                      <h3 className="font-semibold text-card-foreground mb-3 flex items-center gap-2">
                        <Shield className="h-4 w-4 text-accent" />
                        Detective Controls ({detectiveControls.length})
                      </h3>
                      <div className="space-y-2">
                        {detectiveControls.slice(0, 3).map((r) => (
                          <div key={r.id} className="text-sm p-2 bg-muted/30 rounded">
                            {r.description}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                <div>
                  <UpcomingDeadlines deadlines={upcomingDeadlines} />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="policies" className="space-y-6">
              <FilterBar
                searchPlaceholder="Search by policy name or ID..."
                searchValue={searchValue}
                onSearchChange={setSearchValue}
                filters={[
                  {
                    label: "Category",
                    value: categoryFilter,
                    options: categories.map((c) => ({ value: c, label: c === "all" ? "All Categories" : c })),
                    onChange: setCategoryFilter,
                  },
                  {
                    label: "Status",
                    value: policyStatusFilter,
                    options: statuses.map((s) => ({ value: s, label: s === "all" ? "All Statuses" : s.charAt(0).toUpperCase() + s.slice(1) })),
                    onChange: setPolicyStatusFilter,
                  },
                ]}
              />

              <DataTable
                columns={policyColumns}
                data={filteredPolicies}
                onView={handleViewPolicy}
                onEdit={handleEditPolicy}
                onDelete={handleDeletePolicy}
                emptyMessage="No policies found"
              />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
};

export default RiskManagement;
