import { useState } from "react";
import DashboardSidebar from "@/components/layout/DashboardSidebar";
import PageHeader from "@/components/compliance/PageHeader";
import { DataTable, Column } from "@/components/ui/data-table";
import FilterBar from "@/components/compliance/FilterBar";
import StatusBadge from "@/components/compliance/StatusBadge";
import { toast } from "@/hooks/use-toast";

interface Policy {
  id: string;
  name: string;
  category: string;
  lastUpdate: string;
  status: "active" | "draft" | "pending" | "in-review";
  nextUpdateDate: string;
  ownerName: string;
}

const mockPolicies: Policy[] = [
  { id: "POL-001", name: "HIPAA Privacy Compliance", category: "Privacy", lastUpdate: "2024-01-15", status: "active", nextUpdateDate: "2025-01-15", ownerName: "Dr. Sarah Johnson" },
  { id: "POL-002", name: "Patient Data Security", category: "Security", lastUpdate: "2024-02-20", status: "active", nextUpdateDate: "2025-02-20", ownerName: "Michael Chen" },
  { id: "POL-003", name: "Medication Administration", category: "Clinical", lastUpdate: "2024-03-10", status: "in-review", nextUpdateDate: "2025-03-10", ownerName: "Patricia Williams" },
  { id: "POL-004", name: "Emergency Response Protocol", category: "Safety", lastUpdate: "2024-01-05", status: "active", nextUpdateDate: "2025-01-05", ownerName: "Robert Martinez" },
  { id: "POL-005", name: "Staff Training Requirements", category: "HR", lastUpdate: "2024-04-01", status: "draft", nextUpdateDate: "2025-04-01", ownerName: "Jennifer Lee" },
  { id: "POL-006", name: "Infection Control Procedures", category: "Clinical", lastUpdate: "2024-02-28", status: "pending", nextUpdateDate: "2025-02-28", ownerName: "David Thompson" },
];

const PoliciesProcedures = () => {
  const [policies] = useState<Policy[]>(mockPolicies);
  const [searchValue, setSearchValue] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");

  const filteredPolicies = policies.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchValue.toLowerCase()) ||
      p.id.toLowerCase().includes(searchValue.toLowerCase());
    const matchesCategory = categoryFilter === "all" || p.category === categoryFilter;
    const matchesStatus = statusFilter === "all" || p.status === statusFilter;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const columns: Column<Policy>[] = [
    { key: "id", header: "Policy ID", className: "font-mono text-sm" },
    { key: "name", header: "Policy Name", render: (item) => <span className="font-medium">{item.name}</span> },
    { key: "category", header: "Category" },
    { key: "lastUpdate", header: "Last Update" },
    { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
    { key: "nextUpdateDate", header: "Next Update" },
    { key: "ownerName", header: "Owner" },
  ];

  const handleView = (policy: Policy) => {
    toast({ title: "View Policy", description: `Opening ${policy.name}...` });
  };

  const handleEdit = (policy: Policy) => {
    toast({ title: "Edit Policy", description: `Editing ${policy.name}...` });
  };

  const handleDelete = (policy: Policy) => {
    toast({ title: "Delete Policy", description: `${policy.name} has been deleted.`, variant: "destructive" });
  };

  const handleAddNew = () => {
    toast({ title: "Add New Policy", description: "Opening policy creation form..." });
  };

  const categories = ["all", "Privacy", "Security", "Clinical", "Safety", "HR"];
  const statuses = ["all", "active", "draft", "pending", "in-review"];

  return (
    <div className="flex min-h-screen w-full bg-background">
      <DashboardSidebar />

      <main className="flex-1 overflow-auto">
        <PageHeader
          title="Policies and Procedures"
          description="Manage organizational policies and compliance procedures"
          breadcrumbs={[
            { label: "Management Hub", href: "/" },
            { label: "Policies and Procedures" },
          ]}
          onAddNew={handleAddNew}
          addNewLabel="Add Policy"
        />

        <div className="p-8 max-w-7xl space-y-6">
          <FilterBar
            searchPlaceholder="Search by policy name or ID..."
            searchValue={searchValue}
            onSearchChange={setSearchValue}
            filters={[
              {
                label: "Category",
                value: categoryFilter,
                options: categories.map((c) => ({ value: c, label: c === "all" ? "All Categories" : c })),
                onChange: setCategoryFilter,
              },
              {
                label: "Status",
                value: statusFilter,
                options: statuses.map((s) => ({ value: s, label: s === "all" ? "All Statuses" : s.charAt(0).toUpperCase() + s.slice(1) })),
                onChange: setStatusFilter,
              },
            ]}
          />

          <DataTable
            columns={columns}
            data={filteredPolicies}
            onView={handleView}
            onEdit={handleEdit}
            onDelete={handleDelete}
            emptyMessage="No policies found"
          />
        </div>
      </main>
    </div>
  );
};

export default PoliciesProcedures;
