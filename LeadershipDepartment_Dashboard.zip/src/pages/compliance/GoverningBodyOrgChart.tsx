import { useState } from "react";
import DashboardSidebar from "@/components/layout/DashboardSidebar";
import PageHeader from "@/components/compliance/PageHeader";
import { DataTable, Column } from "@/components/ui/data-table";
import FilterBar from "@/components/compliance/FilterBar";
import { toast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Users, Mail, Phone, Building } from "lucide-react";

interface Member {
  id: string;
  name: string;
  title: string;
  department: string;
  email: string;
  phone: string;
  role: string;
}

const mockMembers: Member[] = [
  { id: "1", name: "Dr. Sarah Johnson", title: "Chief Compliance Officer", department: "Compliance", email: "sarah.j@hospital.org", phone: "(555) 123-4567", role: "Executive" },
  { id: "2", name: "Michael Chen", title: "VP of Risk Management", department: "Risk", email: "m.chen@hospital.org", phone: "(555) 234-5678", role: "Executive" },
  { id: "3", name: "Patricia Williams", title: "Director of Audits", department: "Internal Audit", email: "p.williams@hospital.org", phone: "(555) 345-6789", role: "Director" },
  { id: "4", name: "Robert Martinez", title: "Legal Counsel", department: "Legal", email: "r.martinez@hospital.org", phone: "(555) 456-7890", role: "Executive" },
  { id: "5", name: "Jennifer Lee", title: "Quality Assurance Manager", department: "Quality", email: "j.lee@hospital.org", phone: "(555) 567-8901", role: "Manager" },
  { id: "6", name: "David Thompson", title: "Privacy Officer", department: "Compliance", email: "d.thompson@hospital.org", phone: "(555) 678-9012", role: "Officer" },
];

const GoverningBodyOrgChart = () => {
  const [members, setMembers] = useState<Member[]>(mockMembers);
  const [searchValue, setSearchValue] = useState("");
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isMessageOpen, setIsMessageOpen] = useState(false);
  const [message, setMessage] = useState("");

  const filteredMembers = members.filter(
    (m) =>
      m.name.toLowerCase().includes(searchValue.toLowerCase()) ||
      m.department.toLowerCase().includes(searchValue.toLowerCase()) ||
      m.title.toLowerCase().includes(searchValue.toLowerCase())
  );

  const columns: Column<Member>[] = [
    {
      key: "name",
      header: "Name",
      render: (item) => (
        <div className="flex items-center gap-3">
          <Avatar className="h-8 w-8">
            <AvatarFallback className="bg-primary/10 text-primary text-xs">
              {item.name.split(" ").map((n) => n[0]).join("")}
            </AvatarFallback>
          </Avatar>
          <span className="font-medium">{item.name}</span>
        </div>
      ),
    },
    { key: "title", header: "Title" },
    { key: "department", header: "Department" },
    { key: "role", header: "Role" },
    { key: "email", header: "Email" },
  ];

  const handleView = (member: Member) => {
    setSelectedMember(member);
    setIsViewOpen(true);
  };

  const handleEdit = (member: Member) => {
    setSelectedMember(member);
    setIsEditOpen(true);
  };

  const handleDelete = (member: Member) => {
    setMembers((prev) => prev.filter((m) => m.id !== member.id));
    toast({
      title: "Member Removed",
      description: `${member.name} has been removed from the organization.`,
    });
  };

  const handleMessage = (member: Member) => {
    setSelectedMember(member);
    setIsMessageOpen(true);
  };

  const handleSendMessage = () => {
    toast({
      title: "Message Sent",
      description: `Your message has been sent to ${selectedMember?.name}.`,
    });
    setIsMessageOpen(false);
    setMessage("");
  };

  const handleAddNew = () => {
    toast({
      title: "Add New Member",
      description: "This would open the member creation form.",
    });
  };

  return (
    <div className="flex min-h-screen w-full bg-background">
      <DashboardSidebar />

      <main className="flex-1 overflow-auto">
        <PageHeader
          title="Governing Body Org Chart"
          description="View and manage organizational leadership structure"
          breadcrumbs={[
            { label: "Management Hub", href: "/" },
            { label: "Governing Body Org Chart" },
          ]}
          onAddNew={handleAddNew}
          addNewLabel="Add Member"
        />

        <div className="p-8 max-w-7xl space-y-6">
          {/* Org Chart Visual */}
          <div className="bg-card rounded-lg card-shadow p-6">
            <div className="flex items-center gap-2 mb-4">
              <Users className="h-5 w-5 text-primary" />
              <h2 className="text-lg font-semibold text-card-foreground">
                Organization Structure
              </h2>
            </div>
            
            {/* Simple Tree View */}
            <div className="flex flex-col items-center">
              <div className="bg-primary/10 border-2 border-primary rounded-lg p-4 text-center">
                <p className="font-semibold text-primary">Dr. Sarah Johnson</p>
                <p className="text-sm text-muted-foreground">Chief Compliance Officer</p>
              </div>
              <div className="w-px h-8 bg-border"></div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {mockMembers.slice(1, 4).map((member) => (
                  <div key={member.id} className="bg-muted/50 border border-border rounded-lg p-3 text-center">
                    <p className="font-medium text-foreground">{member.name}</p>
                    <p className="text-xs text-muted-foreground">{member.title}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Filter */}
          <FilterBar
            searchPlaceholder="Search by name, title, or department..."
            searchValue={searchValue}
            onSearchChange={setSearchValue}
          />

          {/* Members Table */}
          <DataTable
            columns={columns}
            data={filteredMembers}
            onView={handleView}
            onEdit={handleEdit}
            onDelete={handleDelete}
            onMessage={handleMessage}
            emptyMessage="No members found"
          />
        </div>

        {/* View Member Dialog */}
        <Dialog open={isViewOpen} onOpenChange={setIsViewOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Member Details</DialogTitle>
            </DialogHeader>
            {selectedMember && (
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarFallback className="bg-primary/10 text-primary text-lg">
                      {selectedMember.name.split(" ").map((n) => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="text-lg font-semibold">{selectedMember.name}</h3>
                    <p className="text-muted-foreground">{selectedMember.title}</p>
                  </div>
                </div>
                <div className="grid gap-3">
                  <div className="flex items-center gap-2 text-sm">
                    <Building className="h-4 w-4 text-muted-foreground" />
                    <span>{selectedMember.department}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span>{selectedMember.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{selectedMember.phone}</span>
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Edit Member Dialog */}
        <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Member</DialogTitle>
            </DialogHeader>
            {selectedMember && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input defaultValue={selectedMember.name} />
                </div>
                <div className="space-y-2">
                  <Label>Title</Label>
                  <Input defaultValue={selectedMember.title} />
                </div>
                <div className="space-y-2">
                  <Label>Department</Label>
                  <Input defaultValue={selectedMember.department} />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input defaultValue={selectedMember.email} />
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => {
                toast({ title: "Member Updated", description: "Member details have been saved." });
                setIsEditOpen(false);
              }}>
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Message Dialog */}
        <Dialog open={isMessageOpen} onOpenChange={setIsMessageOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Send Message to {selectedMember?.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Message</Label>
                <textarea
                  className="w-full min-h-[120px] p-3 rounded-md border border-input bg-background text-sm"
                  placeholder="Type your message here..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsMessageOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSendMessage}>Send Message</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
};

export default GoverningBodyOrgChart;
