import { useState } from "react";
import DashboardSidebar from "@/components/layout/DashboardSidebar";
import PageHeader from "@/components/compliance/PageHeader";
import { DataTable, Column } from "@/components/ui/data-table";
import FilterBar from "@/components/compliance/FilterBar";
import MetricsTile from "@/components/compliance/MetricsTile";
import UpcomingDeadlines from "@/components/compliance/UpcomingDeadlines";
import StatusBadge from "@/components/compliance/StatusBadge";
import PriorityBadge from "@/components/compliance/PriorityBadge";
import { toast } from "@/hooks/use-toast";
import { FileWarning, Clock, CheckCircle, AlertTriangle } from "lucide-react";

interface Citation {
  id: string;
  title: string;
  issuingBody: string;
  status: "pending" | "completed" | "overdue" | "in-review";
  responseDeadline: string;
  owner: string;
  priority: "high" | "medium" | "low";
  fineAmount?: string;
}

const mockCitations: Citation[] = [
  { id: "CIT-001", title: "OSHA Workplace Safety Violation", issuingBody: "OSHA", status: "pending", responseDeadline: "2024-12-15", owner: "Robert Martinez", priority: "high", fineAmount: "$15,000" },
  { id: "CIT-002", title: "CMS Billing Discrepancy", issuingBody: "CMS", status: "in-review", responseDeadline: "2024-11-30", owner: "Michael Chen", priority: "high", fineAmount: "$25,000" },
  { id: "CIT-003", title: "State Health Department Finding", issuingBody: "State Health Dept", status: "completed", responseDeadline: "2024-09-30", owner: "Dr. Sarah Johnson", priority: "medium" },
  { id: "CIT-004", title: "Joint Commission Deficiency", issuingBody: "Joint Commission", status: "overdue", responseDeadline: "2024-10-01", owner: "Patricia Williams", priority: "high", fineAmount: "$10,000" },
  { id: "CIT-005", title: "Fire Marshal Safety Citation", issuingBody: "Fire Marshal", status: "pending", responseDeadline: "2024-12-20", owner: "David Thompson", priority: "medium" },
];

const Citations = () => {
  const [citations] = useState<Citation[]>(mockCitations);
  const [searchValue, setSearchValue] = useState("");
  const [activeFilter, setActiveFilter] = useState<string | null>(null);

  const metrics = {
    total: citations.length,
    pending: citations.filter((c) => c.status === "pending" || c.status === "in-review").length,
    completed: citations.filter((c) => c.status === "completed").length,
    overdue: citations.filter((c) => c.status === "overdue").length,
  };

  const filteredCitations = citations.filter((c) => {
    const matchesSearch =
      c.title.toLowerCase().includes(searchValue.toLowerCase()) ||
      c.id.toLowerCase().includes(searchValue.toLowerCase()) ||
      c.issuingBody.toLowerCase().includes(searchValue.toLowerCase());
    const matchesFilter =
      !activeFilter ||
      (activeFilter === "total") ||
      (activeFilter === "pending" && (c.status === "pending" || c.status === "in-review")) ||
      (activeFilter === "completed" && c.status === "completed") ||
      (activeFilter === "overdue" && c.status === "overdue");
    return matchesSearch && matchesFilter;
  });

  const upcomingDeadlines = citations
    .filter((c) => c.status !== "completed")
    .sort((a, b) => new Date(a.responseDeadline).getTime() - new Date(b.responseDeadline).getTime())
    .slice(0, 5)
    .map((c) => ({
      id: c.id,
      title: c.title,
      dueDate: c.responseDeadline,
      priority: c.priority,
    }));

  const columns: Column<Citation>[] = [
    { key: "id", header: "Citation ID", className: "font-mono text-sm" },
    { key: "title", header: "Title", render: (item) => <span className="font-medium">{item.title}</span> },
    { key: "issuingBody", header: "Issuing Body" },
    { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
    { key: "responseDeadline", header: "Response Deadline" },
    { key: "owner", header: "Owner" },
    { key: "priority", header: "Priority", render: (item) => <PriorityBadge priority={item.priority} /> },
    {
      key: "fineAmount",
      header: "Fine",
      render: (item) => (
        <span className={item.fineAmount ? "text-destructive font-medium" : "text-muted-foreground"}>
          {item.fineAmount || "N/A"}
        </span>
      ),
    },
  ];

  const handleView = (citation: Citation) => {
    toast({ title: "Opening CitaPro", description: `Viewing ${citation.title}...` });
  };

  const handleEdit = (citation: Citation) => {
    toast({ title: "Opening CitaPro", description: `Editing ${citation.title}...` });
  };

  const handleDelete = (citation: Citation) => {
    toast({ title: "Citation Deleted", description: `${citation.title} has been removed.`, variant: "destructive" });
  };

  const handleAddNew = () => {
    toast({ title: "Opening CitaPro", description: "Creating new citation..." });
  };

  return (
    <div className="flex min-h-screen w-full bg-background">
      <DashboardSidebar />

      <main className="flex-1 overflow-auto">
        <PageHeader
          title="Citations"
          description="Track regulatory citations and responses"
          breadcrumbs={[
            { label: "Management Hub", href: "/" },
            { label: "Citations" },
          ]}
          onAddNew={handleAddNew}
          addNewLabel="Add Citation"
        />

        <div className="p-8 max-w-7xl space-y-6">
          {/* Metrics Tiles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricsTile
              title="Total Citations"
              value={metrics.total}
              icon={FileWarning}
              variant="default"
              onClick={() => setActiveFilter(activeFilter === "total" ? null : "total")}
              active={activeFilter === "total"}
            />
            <MetricsTile
              title="Pending Response"
              value={metrics.pending}
              icon={Clock}
              variant="warning"
              onClick={() => setActiveFilter(activeFilter === "pending" ? null : "pending")}
              active={activeFilter === "pending"}
            />
            <MetricsTile
              title="Resolved"
              value={metrics.completed}
              icon={CheckCircle}
              variant="success"
              onClick={() => setActiveFilter(activeFilter === "completed" ? null : "completed")}
              active={activeFilter === "completed"}
            />
            <MetricsTile
              title="Overdue"
              value={metrics.overdue}
              icon={AlertTriangle}
              variant="destructive"
              onClick={() => setActiveFilter(activeFilter === "overdue" ? null : "overdue")}
              active={activeFilter === "overdue"}
            />
          </div>

          <FilterBar
            searchPlaceholder="Search by title, ID, or issuing body..."
            searchValue={searchValue}
            onSearchChange={setSearchValue}
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <DataTable
                columns={columns}
                data={filteredCitations}
                onView={handleView}
                onEdit={handleEdit}
                onDelete={handleDelete}
                emptyMessage="No citations found"
              />
            </div>
            <div>
              <UpcomingDeadlines deadlines={upcomingDeadlines} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Citations;
