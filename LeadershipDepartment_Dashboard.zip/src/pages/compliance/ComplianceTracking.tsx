import { useState } from "react";
import DashboardSidebar from "@/components/layout/DashboardSidebar";
import PageHeader from "@/components/compliance/PageHeader";
import { DataTable, Column } from "@/components/ui/data-table";
import FilterBar from "@/components/compliance/FilterBar";
import MetricsTile from "@/components/compliance/MetricsTile";
import UpcomingDeadlines from "@/components/compliance/UpcomingDeadlines";
import StatusBadge from "@/components/compliance/StatusBadge";
import MeetingMinuteForm, { MeetingMinuteFormData } from "@/components/compliance/MeetingMinuteForm";
import MeetingMinuteViewDialog from "@/components/compliance/MeetingMinuteViewDialog";
import { toast } from "@/hooks/use-toast";
import { ShieldCheck, Clock, CheckCircle, AlertTriangle, Calendar, History } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";

interface ComplianceItem {
  id: string;
  description: string;
  status: "pending" | "completed" | "overdue" | "in-review";
  owner: string;
  deadline: string;
  category: string;
}

interface Attendee {
  name: string;
  role: string;
  present: boolean;
}

interface ActionItem {
  description: string;
  assignee: string;
  dueDate: string;
  status: "pending" | "in-progress" | "completed";
}

interface MeetingMinute {
  id: string;
  title: string;
  date: string;
  location: string;
  meetingType: string;
  chairperson: string;
  secretary: string;
  attendees: Attendee[];
  status: "draft" | "approved" | "pending";
  agenda: string;
  discussionNotes?: string;
  decisions?: string;
  actionItems: ActionItem[];
  nextMeetingDate?: string;
  nextMeetingAgenda?: string;
  version: number;
  lastUpdated: string;
  createdBy: string;
}

const mockComplianceItems: ComplianceItem[] = [
  { id: "CMP-001", description: "Annual HIPAA Training Completion", status: "pending", owner: "Jennifer Lee", deadline: "2024-12-31", category: "Training" },
  { id: "CMP-002", description: "Privacy Policy Review & Update", status: "completed", owner: "Dr. Sarah Johnson", deadline: "2024-09-30", category: "Policy" },
  { id: "CMP-003", description: "Data Retention Compliance Check", status: "in-review", owner: "Michael Chen", deadline: "2024-11-15", category: "Data" },
  { id: "CMP-004", description: "Business Associate Agreement Renewals", status: "overdue", owner: "Robert Martinez", deadline: "2024-10-01", category: "Legal" },
  { id: "CMP-005", description: "Access Control Audit", status: "pending", owner: "David Thompson", deadline: "2024-12-20", category: "Security" },
  { id: "CMP-006", description: "Incident Response Plan Update", status: "completed", owner: "Patricia Williams", deadline: "2024-08-31", category: "Security" },
];

const initialMockMinutes: MeetingMinute[] = [
  {
    id: "MTG-001",
    title: "Q4 Compliance Board Meeting",
    date: "2024-10-15",
    location: "Conference Room A",
    meetingType: "Board Meeting",
    chairperson: "Dr. Sarah Johnson",
    secretary: "Emily Davis",
    attendees: [
      { name: "Dr. Sarah Johnson", role: "Compliance Head", present: true },
      { name: "Michael Chen", role: "Risk Manager", present: true },
      { name: "Patricia Williams", role: "Quality Director", present: true },
      { name: "Robert Martinez", role: "Department Head", present: false },
    ],
    status: "approved",
    agenda: "1. Review Q3 compliance metrics\n2. Discuss upcoming audit preparations\n3. Policy updates review",
    discussionNotes: "The team reviewed Q3 metrics showing 94% compliance rate. Audit preparations are on track.",
    decisions: "1. Approved additional training budget\n2. Scheduled mock audit for October 28",
    actionItems: [
      { description: "Complete policy updates", assignee: "Patricia Williams", dueDate: "2024-10-30", status: "in-progress" },
    ],
    nextMeetingDate: "2024-11-15",
    nextMeetingAgenda: "Audit readiness review",
    version: 3,
    lastUpdated: "2024-10-20",
    createdBy: "Dr. Sarah Johnson",
  },
  {
    id: "MTG-002",
    title: "Risk Assessment Committee",
    date: "2024-10-10",
    location: "Virtual Meeting",
    meetingType: "Risk Assessment Committee",
    chairperson: "Michael Chen",
    secretary: "Jennifer Lee",
    attendees: [
      { name: "Michael Chen", role: "Risk Manager", present: true },
      { name: "Jennifer Lee", role: "Analyst", present: true },
      { name: "David Brown", role: "IT Security", present: true },
    ],
    status: "approved",
    agenda: "1. Q3 risk register review\n2. New risk identification",
    discussionNotes: "Identified 3 new risks related to data security.",
    decisions: "Approved enhanced security protocols",
    actionItems: [
      { description: "Implement new access controls", assignee: "David Brown", dueDate: "2024-10-25", status: "completed" },
    ],
    version: 2,
    lastUpdated: "2024-10-12",
    createdBy: "Michael Chen",
  },
  {
    id: "MTG-003",
    title: "HIPAA Compliance Review",
    date: "2024-10-05",
    location: "Conference Room B",
    meetingType: "HIPAA Review",
    chairperson: "Patricia Williams",
    secretary: "Amanda Foster",
    attendees: [
      { name: "Patricia Williams", role: "Quality Director", present: true },
      { name: "Amanda Foster", role: "HIPAA Officer", present: true },
    ],
    status: "pending",
    agenda: "1. HIPAA audit findings review\n2. Corrective action plans",
    discussionNotes: "Reviewed findings from recent HIPAA assessment.",
    actionItems: [
      { description: "Submit corrective action plan", assignee: "Amanda Foster", dueDate: "2024-10-20", status: "pending" },
    ],
    version: 1,
    lastUpdated: "2024-10-05",
    createdBy: "Patricia Williams",
  },
  {
    id: "MTG-004",
    title: "Emergency Preparedness Planning",
    date: "2024-09-28",
    location: "Emergency Operations Center",
    meetingType: "Emergency Preparedness",
    chairperson: "Robert Martinez",
    secretary: "Carlos Rodriguez",
    attendees: [
      { name: "Robert Martinez", role: "Department Head", present: true },
      { name: "Carlos Rodriguez", role: "Safety Officer", present: true },
      { name: "Susan Thompson", role: "Nurse Manager", present: true },
    ],
    status: "approved",
    agenda: "1. Emergency response drill results\n2. Equipment inventory update",
    discussionNotes: "Drill results showed 95% staff participation.",
    decisions: "Approved quarterly drill schedule",
    actionItems: [],
    version: 4,
    lastUpdated: "2024-10-01",
    createdBy: "Robert Martinez",
  },
  {
    id: "MTG-005",
    title: "Quality Improvement Initiative",
    date: "2024-09-20",
    location: "Training Room 1",
    meetingType: "Quality Improvement",
    chairperson: "Jennifer Lee",
    secretary: "Mark Wilson",
    attendees: [
      { name: "Jennifer Lee", role: "Analyst", present: true },
      { name: "Mark Wilson", role: "QA Specialist", present: true },
    ],
    status: "draft",
    agenda: "1. Quality metrics review\n2. Process improvement proposals",
    actionItems: [],
    version: 1,
    lastUpdated: "2024-09-20",
    createdBy: "Jennifer Lee",
  },
];

const mockVersionHistory = [
  { version: 3, date: "2024-10-20", editor: "Dr. Sarah Johnson", changes: "Final approval and sign-off" },
  { version: 2, date: "2024-10-18", editor: "Michael Chen", changes: "Added action items from discussion" },
  { version: 1, date: "2024-10-15", editor: "Dr. Sarah Johnson", changes: "Initial draft created" },
];

const ComplianceTracking = () => {
  const [activeTab, setActiveTab] = useState("compliance");
  const [items] = useState<ComplianceItem[]>(mockComplianceItems);
  const [minutes, setMinutes] = useState<MeetingMinute[]>(initialMockMinutes);
  const [searchValue, setSearchValue] = useState("");
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [selectedMinute, setSelectedMinute] = useState<MeetingMinute | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [editingMinute, setEditingMinute] = useState<MeetingMinute | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const metrics = {
    total: items.length,
    pending: items.filter((i) => i.status === "pending" || i.status === "in-review").length,
    completed: items.filter((i) => i.status === "completed").length,
    overdue: items.filter((i) => i.status === "overdue").length,
  };

  const filteredItems = items.filter((i) => {
    const matchesSearch =
      i.description.toLowerCase().includes(searchValue.toLowerCase()) ||
      i.id.toLowerCase().includes(searchValue.toLowerCase());
    const matchesFilter =
      !activeFilter ||
      (activeFilter === "total") ||
      (activeFilter === "pending" && (i.status === "pending" || i.status === "in-review")) ||
      (activeFilter === "completed" && i.status === "completed") ||
      (activeFilter === "overdue" && i.status === "overdue");
    return matchesSearch && matchesFilter;
  });

  const filteredMinutes = minutes.filter(
    (m) =>
      m.title.toLowerCase().includes(searchValue.toLowerCase()) ||
      m.id.toLowerCase().includes(searchValue.toLowerCase())
  );

  const upcomingDeadlines = items
    .filter((i) => i.status !== "completed")
    .sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime())
    .slice(0, 5)
    .map((i) => ({
      id: i.id,
      title: i.description,
      dueDate: i.deadline,
      priority: i.status === "overdue" ? "high" as const : "medium" as const,
    }));

  const complianceColumns: Column<ComplianceItem>[] = [
    { key: "id", header: "Compliance ID", className: "font-mono text-sm" },
    { key: "description", header: "Description", render: (item) => <span className="font-medium">{item.description}</span> },
    { key: "status", header: "Status", render: (item) => <StatusBadge status={item.status} /> },
    { key: "owner", header: "Owner" },
    { key: "category", header: "Category" },
  ];

  const minuteColumns: Column<MeetingMinute>[] = [
    { key: "id", header: "Meeting ID", className: "font-mono text-sm" },
    { key: "title", header: "Title", render: (item) => <span className="font-medium">{item.title}</span> },
    { key: "date", header: "Date" },
    {
      key: "attendees",
      header: "Attendees",
      render: (item) => <span>{item.attendees.length} attendees</span>,
    },
    {
      key: "status",
      header: "Status",
      render: (item) => (
        <span
          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
            item.status === "approved"
              ? "bg-success/10 text-success"
              : item.status === "pending"
              ? "bg-warning/10 text-warning"
              : "bg-muted text-muted-foreground"
          }`}
        >
          {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
        </span>
      ),
    },
    {
      key: "version",
      header: "Version",
      render: (item) => (
        <button
          onClick={() => {
            setSelectedMinute(item);
            setIsHistoryOpen(true);
          }}
          className="flex items-center gap-1 text-primary hover:underline"
        >
          <span>v{item.version}</span>
          <History className="h-3 w-3" />
        </button>
      ),
    },
    { key: "lastUpdated", header: "Last Updated" },
  ];

  const handleViewItem = (item: ComplianceItem) => {
    toast({ title: "Opening ComplianceConnect", description: `Viewing ${item.description}...` });
  };

  const handleEditItem = (item: ComplianceItem) => {
    toast({ title: "Opening ComplianceConnect", description: `Editing ${item.description}...` });
  };

  const handleDeleteItem = (item: ComplianceItem) => {
    toast({ title: "Compliance Item Deleted", description: `${item.description} has been removed.`, variant: "destructive" });
  };

  const handleViewMinute = (minute: MeetingMinute) => {
    setSelectedMinute(minute);
    setIsViewOpen(true);
  };

  const handleEditMinute = (minute: MeetingMinute) => {
    setEditingMinute(minute);
    setIsFormOpen(true);
  };

  const handleDeleteMinute = (minute: MeetingMinute) => {
    setSelectedMinute(minute);
    setIsDeleteOpen(true);
  };

  const confirmDeleteMinute = () => {
    if (selectedMinute) {
      setMinutes(minutes.filter((m) => m.id !== selectedMinute.id));
      toast({
        title: "Meeting Minutes Deleted",
        description: `${selectedMinute.title} has been removed.`,
      });
      setIsDeleteOpen(false);
      setSelectedMinute(null);
    }
  };

  const handleAddNew = () => {
    if (activeTab === "compliance") {
      toast({ title: "Opening ComplianceConnect", description: "Creating new compliance item..." });
    } else {
      setEditingMinute(null);
      setIsFormOpen(true);
    }
  };

  const generateId = () => {
    const maxId = minutes.reduce((max, m) => {
      const num = parseInt(m.id.replace("MTG-", ""));
      return num > max ? num : max;
    }, 0);
    return `MTG-${String(maxId + 1).padStart(3, "0")}`;
  };

  const handleFormSubmit = (
    data: MeetingMinuteFormData & { attendees: Attendee[]; actionItems: ActionItem[] }
  ) => {
    setIsLoading(true);

    setTimeout(() => {
      if (editingMinute) {
        const updated: MeetingMinute = {
          ...editingMinute,
          title: data.title,
          date: data.date.toISOString().split("T")[0],
          location: data.location,
          meetingType: data.meetingType,
          chairperson: data.chairperson,
          secretary: data.secretary,
          status: data.status,
          agenda: data.agenda,
          discussionNotes: data.discussionNotes,
          decisions: data.decisions,
          attendees: data.attendees,
          actionItems: data.actionItems,
          nextMeetingDate: data.nextMeetingDate?.toISOString().split("T")[0],
          nextMeetingAgenda: data.nextMeetingAgenda,
          version: editingMinute.version + 1,
          lastUpdated: new Date().toISOString().split("T")[0],
        };
        setMinutes(minutes.map((m) => (m.id === editingMinute.id ? updated : m)));
        toast({
          title: "Meeting Minutes Updated",
          description: `${data.title} has been updated to version ${updated.version}.`,
        });
      } else {
        const newMinute: MeetingMinute = {
          id: generateId(),
          title: data.title,
          date: data.date.toISOString().split("T")[0],
          location: data.location,
          meetingType: data.meetingType,
          chairperson: data.chairperson,
          secretary: data.secretary,
          status: data.status,
          agenda: data.agenda,
          discussionNotes: data.discussionNotes,
          decisions: data.decisions,
          attendees: data.attendees,
          actionItems: data.actionItems,
          nextMeetingDate: data.nextMeetingDate?.toISOString().split("T")[0],
          nextMeetingAgenda: data.nextMeetingAgenda,
          version: 1,
          lastUpdated: new Date().toISOString().split("T")[0],
          createdBy: "Current User",
        };
        setMinutes([newMinute, ...minutes]);
        toast({
          title: "Meeting Minutes Created",
          description: `${data.title} has been created successfully.`,
        });
      }

      setIsLoading(false);
      setIsFormOpen(false);
      setEditingMinute(null);
    }, 500);
  };

  const getFormInitialData = () => {
    if (!editingMinute) return undefined;
    return {
      title: editingMinute.title,
      date: new Date(editingMinute.date),
      location: editingMinute.location,
      meetingType: editingMinute.meetingType,
      chairperson: editingMinute.chairperson,
      secretary: editingMinute.secretary,
      status: editingMinute.status,
      agenda: editingMinute.agenda,
      discussionNotes: editingMinute.discussionNotes,
      decisions: editingMinute.decisions,
      attendees: editingMinute.attendees,
      actionItems: editingMinute.actionItems,
      nextMeetingDate: editingMinute.nextMeetingDate ? new Date(editingMinute.nextMeetingDate) : undefined,
      nextMeetingAgenda: editingMinute.nextMeetingAgenda,
    };
  };

  return (
    <div className="flex min-h-screen w-full bg-background">
      <DashboardSidebar />

      <main className="flex-1 overflow-auto">
        <PageHeader
          title="Compliance Tracking"
          description="Track compliance items and manage meeting minutes"
          breadcrumbs={[
            { label: "Management Hub", href: "/" },
            { label: "Compliance Tracking" },
          ]}
          onAddNew={handleAddNew}
          addNewLabel={activeTab === "compliance" ? "Add Compliance Item" : "Add Minutes"}
        />

        <div className="p-8 max-w-7xl space-y-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="compliance">Compliance Items</TabsTrigger>
              <TabsTrigger value="meetings">Meeting Minutes</TabsTrigger>
            </TabsList>

            <TabsContent value="compliance" className="space-y-6">
              {/* Metrics Tiles */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <MetricsTile
                  title="Total Items"
                  value={metrics.total}
                  icon={ShieldCheck}
                  variant="default"
                  onClick={() => setActiveFilter(activeFilter === "total" ? null : "total")}
                  active={activeFilter === "total"}
                />
                <MetricsTile
                  title="Pending Review"
                  value={metrics.pending}
                  icon={Clock}
                  variant="warning"
                  onClick={() => setActiveFilter(activeFilter === "pending" ? null : "pending")}
                  active={activeFilter === "pending"}
                />
                <MetricsTile
                  title="Completed"
                  value={metrics.completed}
                  icon={CheckCircle}
                  variant="success"
                  onClick={() => setActiveFilter(activeFilter === "completed" ? null : "completed")}
                  active={activeFilter === "completed"}
                />
                <MetricsTile
                  title="Overdue"
                  value={metrics.overdue}
                  icon={AlertTriangle}
                  variant="destructive"
                  onClick={() => setActiveFilter(activeFilter === "overdue" ? null : "overdue")}
                  active={activeFilter === "overdue"}
                />
              </div>

              <FilterBar
                searchPlaceholder="Search by description or ID..."
                searchValue={searchValue}
                onSearchChange={setSearchValue}
              />

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <DataTable
                    columns={complianceColumns}
                    data={filteredItems}
                    onView={handleViewItem}
                    onEdit={handleEditItem}
                    onDelete={handleDeleteItem}
                    emptyMessage="No compliance items found"
                  />
                </div>
                <div>
                  <UpcomingDeadlines deadlines={upcomingDeadlines} />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="meetings" className="space-y-6">
              {/* Summary Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-card rounded-lg card-shadow p-4 flex items-center gap-4">
                  <div className="p-3 rounded-lg bg-primary/10">
                    <Calendar className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Total Meetings</p>
                    <p className="text-2xl font-bold">{minutes.length}</p>
                  </div>
                </div>
                <div className="bg-card rounded-lg card-shadow p-4 flex items-center gap-4">
                  <div className="p-3 rounded-lg bg-success/10">
                    <Calendar className="h-5 w-5 text-success" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Approved</p>
                    <p className="text-2xl font-bold">{minutes.filter((m) => m.status === "approved").length}</p>
                  </div>
                </div>
                <div className="bg-card rounded-lg card-shadow p-4 flex items-center gap-4">
                  <div className="p-3 rounded-lg bg-warning/10">
                    <Calendar className="h-5 w-5 text-warning" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Pending Review</p>
                    <p className="text-2xl font-bold">{minutes.filter((m) => m.status !== "approved").length}</p>
                  </div>
                </div>
              </div>

              <FilterBar
                searchPlaceholder="Search by title or ID..."
                searchValue={searchValue}
                onSearchChange={setSearchValue}
              />

              <DataTable
                columns={minuteColumns}
                data={filteredMinutes}
                onView={handleViewMinute}
                onEdit={handleEditMinute}
                onDelete={handleDeleteMinute}
                emptyMessage="No meeting minutes found"
              />
            </TabsContent>
          </Tabs>
        </div>

        {/* Create/Edit Form Sheet */}
        <Sheet open={isFormOpen} onOpenChange={setIsFormOpen}>
          <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto">
            <SheetHeader>
              <SheetTitle>
                {editingMinute ? "Edit Meeting Minutes" : "Create Meeting Minutes"}
              </SheetTitle>
            </SheetHeader>
            <div className="mt-6">
              <MeetingMinuteForm
                initialData={getFormInitialData()}
                onSubmit={handleFormSubmit}
                onCancel={() => {
                  setIsFormOpen(false);
                  setEditingMinute(null);
                }}
                isLoading={isLoading}
              />
            </div>
          </SheetContent>
        </Sheet>

        {/* View Dialog */}
        <MeetingMinuteViewDialog
          open={isViewOpen}
          onOpenChange={setIsViewOpen}
          minute={selectedMinute}
          onEdit={() => {
            setIsViewOpen(false);
            if (selectedMinute) {
              handleEditMinute(selectedMinute);
            }
          }}
        />

        {/* Delete Confirmation */}
        <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Meeting Minutes</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete "{selectedMinute?.title}"? This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={confirmDeleteMinute} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Version History Dialog */}
        <Dialog open={isHistoryOpen} onOpenChange={setIsHistoryOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <History className="h-5 w-5" />
                Version History
              </DialogTitle>
              <DialogDescription>
                View all versions of this meeting minute
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">{selectedMinute?.title}</p>
              <div className="border rounded-lg divide-y">
                {mockVersionHistory.map((v) => (
                  <div key={v.version} className="p-3 hover:bg-muted/30">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">Version {v.version}</span>
                      <span className="text-sm text-muted-foreground">{v.date}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{v.changes}</p>
                    <p className="text-xs text-muted-foreground mt-1">By {v.editor}</p>
                  </div>
                ))}
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsHistoryOpen(false)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
};

export default ComplianceTracking;
