import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import GoverningBodyOrgChart from "./pages/compliance/GoverningBodyOrgChart";
import AuditItems from "./pages/compliance/AuditItems";
import Enforcements from "./pages/compliance/Enforcements";
import RiskManagement from "./pages/compliance/RiskManagement";
import ComplianceTracking from "./pages/compliance/ComplianceTracking";
import Documentation from "./pages/compliance/Documentation";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/governing-body" element={<GoverningBodyOrgChart />} />
          <Route path="/audits" element={<AuditItems />} />
          <Route path="/enforcements" element={<Enforcements />} />
          <Route path="/risks" element={<RiskManagement />} />
          <Route path="/policies" element={<RiskManagement />} />
          <Route path="/compliance" element={<ComplianceTracking />} />
          <Route path="/meetings" element={<ComplianceTracking />} />
          <Route path="/documentation" element={<Documentation />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
