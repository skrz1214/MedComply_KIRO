import { useState, useCallback } from "react";
import { ChevronDown, ChevronRight, Menu, X, LayoutDashboard, FileText } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Users,
  ClipboardCheck,
  Scale,
  AlertTriangle,
  ShieldCheck,
  Shield,
} from "lucide-react";

interface NavItem {
  label: string;
  icon: React.ElementType;
  href: string;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

const managementHub: NavSection = {
  title: "Management Hub",
  items: [
    { label: "Dashboard", icon: LayoutDashboard, href: "/" },
    { label: "Governing Body Org Chart", icon: Users, href: "/governing-body" },
    { label: "Audit Items", icon: ClipboardCheck, href: "/audits" },
    { label: "Enforcements", icon: Scale, href: "/enforcements" },
    { label: "Risk Management", icon: AlertTriangle, href: "/risks" },
    { label: "Compliance Tracking", icon: ShieldCheck, href: "/compliance" },
    { label: "Documentation", icon: FileText, href: "/documentation" },
  ],
};

interface NavGroupProps {
  section: NavSection;
  defaultOpen?: boolean;
}

const NavGroup = ({ section, defaultOpen = true }: NavGroupProps) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      setIsOpen(!isOpen);
    }
  }, [isOpen]);

  return (
    <div className="mb-2">
      <button
        onClick={() => setIsOpen(!isOpen)}
        onKeyDown={handleKeyDown}
        aria-expanded={isOpen}
        aria-controls={`nav-section-${section.title.replace(/\s+/g, '-').toLowerCase()}`}
        className="w-full flex items-center justify-between px-4 py-3 text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring rounded-md touch-target"
      >
        <span className="text-xs font-semibold uppercase tracking-wider">{section.title}</span>
        {isOpen ? (
          <ChevronDown className="h-4 w-4" aria-hidden="true" />
        ) : (
          <ChevronRight className="h-4 w-4" aria-hidden="true" />
        )}
      </button>
      
      <nav
        id={`nav-section-${section.title.replace(/\s+/g, '-').toLowerCase()}`}
        aria-label={section.title}
        className={cn(
          "overflow-hidden transition-all duration-300",
          isOpen ? "max-h-[600px]" : "max-h-0"
        )}
      >
        <ul>
          {section.items.map((item) => (
            <li key={item.label}>
              <a
                href={item.href}
                className="flex items-center gap-3 px-4 py-2.5 mx-2 rounded-lg text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring touch-target"
              >
                <item.icon className="h-4 w-4 text-sidebar-muted group-hover:text-sidebar-primary transition-colors" aria-hidden="true" />
                <span className="text-sm font-medium">{item.label}</span>
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
};

const DashboardSidebar = () => {
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  return (
    <>
      {/* Mobile Menu Button */}
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsMobileOpen(true)}
        className="fixed top-4 left-4 z-50 lg:hidden touch-target bg-card shadow-md"
        aria-label="Open navigation menu"
        aria-expanded={isMobileOpen}
        aria-controls="mobile-nav"
      >
        <Menu className="h-5 w-5" aria-hidden="true" />
      </Button>

      {/* Mobile Backdrop */}
      <div
        className={cn(
          "fixed inset-0 bg-foreground/50 z-40 lg:hidden transition-opacity duration-200",
          isMobileOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
        onClick={() => setIsMobileOpen(false)}
        aria-hidden="true"
      />

      {/* Sidebar */}
      <aside
        id="mobile-nav"
        className={cn(
          "fixed lg:static inset-y-0 left-0 z-50 w-64 min-h-screen bg-sidebar border-r border-sidebar-border flex flex-col transition-transform duration-300 lg:translate-x-0",
          isMobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
        aria-label="Main navigation"
      >
        {/* Close button for mobile */}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsMobileOpen(false)}
          className="absolute top-4 right-4 lg:hidden touch-target text-sidebar-foreground"
          aria-label="Close navigation menu"
        >
          <X className="h-5 w-5" aria-hidden="true" />
        </Button>

        {/* Logo Section */}
        <div className="p-5 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg brand-gradient flex items-center justify-center" aria-hidden="true">
              <Shield className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <span className="text-base font-bold text-sidebar-foreground">MedComply</span>
              <p className="text-xs text-sidebar-muted">Leadership Dashboard</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex-1 py-4 overflow-y-auto">
          <NavGroup section={managementHub} />
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-sidebar-border">
          <div className="flex items-center gap-3 px-2">
            <div 
              className="h-10 w-10 rounded-full bg-sidebar-accent flex items-center justify-center"
              aria-hidden="true"
            >
              <span className="text-sm font-semibold text-sidebar-foreground">JD</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-sidebar-foreground truncate">John Doe</p>
              <p className="text-xs text-sidebar-muted truncate">Chief Compliance Officer</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default DashboardSidebar;
