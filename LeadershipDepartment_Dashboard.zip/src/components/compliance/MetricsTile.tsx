import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface MetricsTileProps {
  title: string;
  value: number;
  icon: LucideIcon;
  variant?: "default" | "success" | "warning" | "destructive" | "info";
  onClick?: () => void;
  active?: boolean;
}

const MetricsTile = ({
  title,
  value,
  icon: Icon,
  variant = "default",
  onClick,
  active,
}: MetricsTileProps) => {
  const variantStyles = {
    default: "border-l-primary",
    success: "border-l-success",
    warning: "border-l-warning",
    destructive: "border-l-destructive",
    info: "border-l-accent",
  };

  const iconStyles = {
    default: "text-primary bg-primary/10",
    success: "text-success bg-success/10",
    warning: "text-warning bg-warning/10",
    destructive: "text-destructive bg-destructive/10",
    info: "text-accent bg-accent/10",
  };

  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full bg-card rounded-lg p-4 card-shadow hover:card-shadow-hover transition-all duration-300 border-l-4 text-left",
        variantStyles[variant],
        onClick && "cursor-pointer hover:scale-[1.02]",
        active && "ring-2 ring-primary ring-offset-2"
      )}
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-2xl font-bold text-card-foreground mt-1">{value}</p>
        </div>
        <div className={cn("p-2.5 rounded-lg", iconStyles[variant])}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </button>
  );
};

export default MetricsTile;
