import { Clock, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface Deadline {
  id: string;
  title: string;
  dueDate: string;
  priority: "high" | "medium" | "low";
  type?: string;
}

interface UpcomingDeadlinesProps {
  deadlines: Deadline[];
  onItemClick?: (item: Deadline) => void;
}

const UpcomingDeadlines = ({ deadlines, onItemClick }: UpcomingDeadlinesProps) => {
  const priorityColors = {
    high: "text-destructive bg-destructive/10",
    medium: "text-warning bg-warning/10",
    low: "text-success bg-success/10",
  };

  return (
    <div className="bg-card rounded-lg card-shadow p-5">
      <div className="flex items-center gap-2 mb-4">
        <Clock className="h-5 w-5 text-primary" />
        <h3 className="font-semibold text-card-foreground">Upcoming Deadlines</h3>
      </div>
      
      <div className="space-y-3">
        {deadlines.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            No upcoming deadlines
          </p>
        ) : (
          deadlines.map((deadline) => (
            <button
              key={deadline.id}
              onClick={() => onItemClick?.(deadline)}
              className="w-full flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors group"
            >
              <div className="flex items-center gap-3">
                <span
                  className={cn(
                    "text-xs font-medium px-2 py-1 rounded-full",
                    priorityColors[deadline.priority]
                  )}
                >
                  {deadline.priority.toUpperCase()}
                </span>
                <div className="text-left">
                  <p className="text-sm font-medium text-card-foreground">
                    {deadline.title}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Due: {deadline.dueDate}
                  </p>
                </div>
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
            </button>
          ))
        )}
      </div>
    </div>
  );
};

export default UpcomingDeadlines;
