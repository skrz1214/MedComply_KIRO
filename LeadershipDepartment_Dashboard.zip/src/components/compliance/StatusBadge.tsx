import { cn } from "@/lib/utils";

type Status = "active" | "pending" | "completed" | "overdue" | "draft" | "in-review" | "approved";

interface StatusBadgeProps {
  status: Status;
}

const StatusBadge = ({ status }: StatusBadgeProps) => {
  const statusStyles: Record<Status, string> = {
    active: "bg-primary/10 text-primary",
    pending: "bg-warning/10 text-warning",
    completed: "bg-success/10 text-success",
    overdue: "bg-destructive/10 text-destructive",
    draft: "bg-muted text-muted-foreground",
    "in-review": "bg-accent/10 text-accent",
    approved: "bg-success/10 text-success",
  };

  const statusLabels: Record<Status, string> = {
    active: "Active",
    pending: "Pending",
    completed: "Completed",
    overdue: "Overdue",
    draft: "Draft",
    "in-review": "In Review",
    approved: "Approved",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
        statusStyles[status]
      )}
    >
      {statusLabels[status]}
    </span>
  );
};

export default StatusBadge;
