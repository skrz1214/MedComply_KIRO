import { cn } from "@/lib/utils";

type Priority = "high" | "medium" | "low";

interface PriorityBadgeProps {
  priority: Priority;
}

const PriorityBadge = ({ priority }: PriorityBadgeProps) => {
  const priorityStyles: Record<Priority, string> = {
    high: "bg-destructive/10 text-destructive",
    medium: "bg-warning/10 text-warning",
    low: "bg-success/10 text-success",
  };

  const priorityLabels: Record<Priority, string> = {
    high: "High",
    medium: "Medium",
    low: "Low",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
        priorityStyles[priority]
      )}
    >
      {priorityLabels[priority]}
    </span>
  );
};

export default PriorityBadge;
