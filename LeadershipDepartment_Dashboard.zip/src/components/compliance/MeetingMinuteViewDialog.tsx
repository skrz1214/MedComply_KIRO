import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Calendar, Users, MapPin, CheckCircle, Clock, User } from "lucide-react";

interface Attendee {
  name: string;
  role: string;
  present: boolean;
}

interface ActionItem {
  description: string;
  assignee: string;
  dueDate: string;
  status: "pending" | "in-progress" | "completed";
}

interface MeetingMinuteDetail {
  id: string;
  title: string;
  date: string;
  location: string;
  meetingType: string;
  chairperson: string;
  secretary: string;
  status: "draft" | "approved" | "pending";
  agenda: string;
  discussionNotes?: string;
  decisions?: string;
  attendees: Attendee[];
  actionItems: ActionItem[];
  nextMeetingDate?: string;
  nextMeetingAgenda?: string;
  createdBy: string;
  lastUpdated: string;
  version: number;
}

interface MeetingMinuteViewDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  minute: MeetingMinuteDetail | null;
  onEdit?: () => void;
}

const MeetingMinuteViewDialog = ({
  open,
  onOpenChange,
  minute,
  onEdit,
}: MeetingMinuteViewDialogProps) => {
  if (!minute) return null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-success/10 text-success";
      case "pending":
        return "bg-warning/10 text-warning";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh]">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="text-xl">{minute.title}</DialogTitle>
              <p className="text-sm text-muted-foreground mt-1">
                {minute.id} • Version {minute.version}
              </p>
            </div>
            <Badge className={getStatusColor(minute.status)}>
              {minute.status.charAt(0).toUpperCase() + minute.status.slice(1)}
            </Badge>
          </div>
        </DialogHeader>

        <ScrollArea className="max-h-[60vh] pr-4">
          <div className="space-y-6">
            {/* Meeting Details */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Date</p>
                  <p className="text-sm font-medium">{minute.date}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Location</p>
                  <p className="text-sm font-medium">{minute.location}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Chairperson</p>
                  <p className="text-sm font-medium">{minute.chairperson}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Secretary</p>
                  <p className="text-sm font-medium">{minute.secretary}</p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Attendees */}
            <div>
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Users className="h-4 w-4" />
                Attendees ({minute.attendees.length})
              </h4>
              <div className="flex flex-wrap gap-2">
                {minute.attendees.map((attendee, index) => (
                  <Badge
                    key={index}
                    variant={attendee.present ? "default" : "outline"}
                  >
                    {attendee.name} ({attendee.role})
                    {!attendee.present && " - Absent"}
                  </Badge>
                ))}
              </div>
            </div>

            <Separator />

            {/* Agenda */}
            <div>
              <h4 className="font-semibold mb-2">Agenda</h4>
              <div className="bg-muted/30 rounded-lg p-4">
                <p className="text-sm whitespace-pre-wrap">{minute.agenda}</p>
              </div>
            </div>

            {/* Discussion Notes */}
            {minute.discussionNotes && (
              <div>
                <h4 className="font-semibold mb-2">Discussion Notes</h4>
                <div className="bg-muted/30 rounded-lg p-4">
                  <p className="text-sm whitespace-pre-wrap">{minute.discussionNotes}</p>
                </div>
              </div>
            )}

            {/* Key Decisions */}
            {minute.decisions && (
              <div>
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-success" />
                  Key Decisions
                </h4>
                <div className="bg-success/5 border border-success/20 rounded-lg p-4">
                  <p className="text-sm whitespace-pre-wrap">{minute.decisions}</p>
                </div>
              </div>
            )}

            {/* Action Items */}
            {minute.actionItems.length > 0 && (
              <div>
                <h4 className="font-semibold mb-3">Action Items</h4>
                <div className="border rounded-lg divide-y">
                  {minute.actionItems.map((item, index) => (
                    <div key={index} className="p-3 flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium">{item.description}</p>
                        <p className="text-xs text-muted-foreground">
                          Assigned to: {item.assignee}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        {item.dueDate && (
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {item.dueDate}
                          </span>
                        )}
                        <Badge
                          variant={
                            item.status === "completed"
                              ? "default"
                              : item.status === "in-progress"
                              ? "secondary"
                              : "outline"
                          }
                        >
                          {item.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Next Meeting */}
            {minute.nextMeetingDate && (
              <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                <h4 className="font-semibold mb-2">Next Meeting</h4>
                <p className="text-sm">
                  <strong>Date:</strong> {minute.nextMeetingDate}
                </p>
                {minute.nextMeetingAgenda && (
                  <p className="text-sm mt-1">
                    <strong>Preliminary Agenda:</strong> {minute.nextMeetingAgenda}
                  </p>
                )}
              </div>
            )}

            {/* Metadata */}
            <div className="text-xs text-muted-foreground pt-4 border-t">
              <p>Created by: {minute.createdBy}</p>
              <p>Last updated: {minute.lastUpdated}</p>
            </div>
          </div>
        </ScrollArea>

        <DialogFooter>
          {onEdit && (
            <Button variant="outline" onClick={onEdit}>
              Edit Minutes
            </Button>
          )}
          <Button onClick={() => onOpenChange(false)}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default MeetingMinuteViewDialog;
