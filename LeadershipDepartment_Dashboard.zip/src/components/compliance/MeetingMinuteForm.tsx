import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { CalendarIcon, Plus, X, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";

const meetingMinuteSchema = z.object({
  title: z.string().min(1, "Title is required").max(200, "Title must be less than 200 characters"),
  date: z.date({ required_error: "Meeting date is required" }),
  location: z.string().min(1, "Location is required").max(100, "Location must be less than 100 characters"),
  meetingType: z.string().min(1, "Meeting type is required"),
  chairperson: z.string().min(1, "Chairperson is required").max(100),
  secretary: z.string().min(1, "Secretary/Recorder is required").max(100),
  status: z.enum(["draft", "pending", "approved"]),
  agenda: z.string().min(1, "Agenda is required").max(2000, "Agenda must be less than 2000 characters"),
  discussionNotes: z.string().max(5000, "Discussion notes must be less than 5000 characters").optional(),
  decisions: z.string().max(2000, "Decisions must be less than 2000 characters").optional(),
  nextMeetingDate: z.date().optional(),
  nextMeetingAgenda: z.string().max(1000).optional(),
});

export type MeetingMinuteFormData = z.infer<typeof meetingMinuteSchema>;

interface Attendee {
  name: string;
  role: string;
  present: boolean;
}

interface ActionItem {
  description: string;
  assignee: string;
  dueDate: string;
  status: "pending" | "in-progress" | "completed";
}

interface MeetingMinuteFormProps {
  initialData?: Partial<MeetingMinuteFormData> & {
    attendees?: Attendee[];
    actionItems?: ActionItem[];
  };
  onSubmit: (data: MeetingMinuteFormData & { attendees: Attendee[]; actionItems: ActionItem[] }) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

const meetingTypes = [
  "Board Meeting",
  "Compliance Committee",
  "Risk Assessment Committee",
  "Quality Improvement",
  "HIPAA Review",
  "Emergency Preparedness",
  "Policy Review",
  "Audit Committee",
  "Other",
];

const MeetingMinuteForm = ({ initialData, onSubmit, onCancel, isLoading }: MeetingMinuteFormProps) => {
  const [attendees, setAttendees] = useState<Attendee[]>(
    initialData?.attendees || []
  );
  const [actionItems, setActionItems] = useState<ActionItem[]>(
    initialData?.actionItems || []
  );
  const [newAttendee, setNewAttendee] = useState({ name: "", role: "" });
  const [newActionItem, setNewActionItem] = useState({
    description: "",
    assignee: "",
    dueDate: "",
  });

  const form = useForm<MeetingMinuteFormData>({
    resolver: zodResolver(meetingMinuteSchema),
    defaultValues: {
      title: initialData?.title || "",
      date: initialData?.date,
      location: initialData?.location || "",
      meetingType: initialData?.meetingType || "",
      chairperson: initialData?.chairperson || "",
      secretary: initialData?.secretary || "",
      status: initialData?.status || "draft",
      agenda: initialData?.agenda || "",
      discussionNotes: initialData?.discussionNotes || "",
      decisions: initialData?.decisions || "",
      nextMeetingDate: initialData?.nextMeetingDate,
      nextMeetingAgenda: initialData?.nextMeetingAgenda || "",
    },
  });

  const handleAddAttendee = () => {
    if (newAttendee.name.trim() && newAttendee.role.trim()) {
      setAttendees([...attendees, { ...newAttendee, present: true }]);
      setNewAttendee({ name: "", role: "" });
    }
  };

  const handleRemoveAttendee = (index: number) => {
    setAttendees(attendees.filter((_, i) => i !== index));
  };

  const handleToggleAttendance = (index: number) => {
    setAttendees(
      attendees.map((a, i) => (i === index ? { ...a, present: !a.present } : a))
    );
  };

  const handleAddActionItem = () => {
    if (newActionItem.description.trim() && newActionItem.assignee.trim()) {
      setActionItems([
        ...actionItems,
        { ...newActionItem, status: "pending" as const },
      ]);
      setNewActionItem({ description: "", assignee: "", dueDate: "" });
    }
  };

  const handleRemoveActionItem = (index: number) => {
    setActionItems(actionItems.filter((_, i) => i !== index));
  };

  const handleFormSubmit = (data: MeetingMinuteFormData) => {
    onSubmit({ ...data, attendees, actionItems });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-6">
        {/* Basic Information */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground border-b pb-2">
            Meeting Information
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem className="col-span-2">
                  <FormLabel>Meeting Title *</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter meeting title" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Meeting Date *</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full pl-3 text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          {field.value ? (
                            format(field.value, "PPP")
                          ) : (
                            <span>Select date</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        initialFocus
                        className="p-3 pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="meetingType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Meeting Type *</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select meeting type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {meetingTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Location *</FormLabel>
                  <FormControl>
                    <Input placeholder="Conference Room / Virtual" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status *</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="pending">Pending Approval</SelectItem>
                      <SelectItem value="approved">Approved</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="chairperson"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Chairperson *</FormLabel>
                  <FormControl>
                    <Input placeholder="Meeting chairperson name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="secretary"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Secretary/Recorder *</FormLabel>
                  <FormControl>
                    <Input placeholder="Meeting secretary name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>

        {/* Attendees Section */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground border-b pb-2 flex items-center gap-2">
            <Users className="h-5 w-5" />
            Attendees
          </h3>
          
          <div className="flex gap-2 items-end">
            <div className="flex-1">
              <label className="text-sm font-medium">Name</label>
              <Input
                placeholder="Attendee name"
                value={newAttendee.name}
                onChange={(e) =>
                  setNewAttendee({ ...newAttendee, name: e.target.value })
                }
              />
            </div>
            <div className="flex-1">
              <label className="text-sm font-medium">Role</label>
              <Input
                placeholder="Role/Title"
                value={newAttendee.role}
                onChange={(e) =>
                  setNewAttendee({ ...newAttendee, role: e.target.value })
                }
              />
            </div>
            <Button type="button" onClick={handleAddAttendee} size="icon">
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          {attendees.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {attendees.map((attendee, index) => (
                <Badge
                  key={index}
                  variant={attendee.present ? "default" : "secondary"}
                  className="flex items-center gap-2 py-1.5 px-3 cursor-pointer"
                  onClick={() => handleToggleAttendance(index)}
                >
                  <span>
                    {attendee.name} ({attendee.role})
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleRemoveAttendee(index);
                    }}
                    className="hover:text-destructive"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          )}
          <p className="text-xs text-muted-foreground">
            Click on an attendee badge to toggle attendance status
          </p>
        </div>

        {/* Agenda & Discussion */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground border-b pb-2">
            Meeting Content
          </h3>

          <FormField
            control={form.control}
            name="agenda"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Agenda *</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Enter meeting agenda items..."
                    className="min-h-[120px]"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="discussionNotes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Discussion Notes</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Enter discussion notes and key points..."
                    className="min-h-[150px]"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="decisions"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Key Decisions</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Enter key decisions made during the meeting..."
                    className="min-h-[100px]"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        {/* Action Items */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground border-b pb-2">
            Action Items
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-2 items-end">
            <div className="md:col-span-2">
              <label className="text-sm font-medium">Description</label>
              <Input
                placeholder="Action item description"
                value={newActionItem.description}
                onChange={(e) =>
                  setNewActionItem({ ...newActionItem, description: e.target.value })
                }
              />
            </div>
            <div>
              <label className="text-sm font-medium">Assignee</label>
              <Input
                placeholder="Assigned to"
                value={newActionItem.assignee}
                onChange={(e) =>
                  setNewActionItem({ ...newActionItem, assignee: e.target.value })
                }
              />
            </div>
            <div className="flex gap-2">
              <div className="flex-1">
                <label className="text-sm font-medium">Due Date</label>
                <Input
                  type="date"
                  value={newActionItem.dueDate}
                  onChange={(e) =>
                    setNewActionItem({ ...newActionItem, dueDate: e.target.value })
                  }
                />
              </div>
              <Button
                type="button"
                onClick={handleAddActionItem}
                size="icon"
                className="self-end"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {actionItems.length > 0 && (
            <div className="border rounded-lg divide-y">
              {actionItems.map((item, index) => (
                <div
                  key={index}
                  className="p-3 flex items-center justify-between hover:bg-muted/30"
                >
                  <div className="flex-1">
                    <p className="font-medium text-sm">{item.description}</p>
                    <p className="text-xs text-muted-foreground">
                      Assigned to: {item.assignee}
                      {item.dueDate && ` • Due: ${item.dueDate}`}
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemoveActionItem(index)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Next Meeting */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground border-b pb-2">
            Next Meeting (Optional)
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="nextMeetingDate"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Next Meeting Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full pl-3 text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          {field.value ? (
                            format(field.value, "PPP")
                          ) : (
                            <span>Select date</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        disabled={(date) => date < new Date()}
                        initialFocus
                        className="p-3 pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="nextMeetingAgenda"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Preliminary Agenda</FormLabel>
                  <FormControl>
                    <Input placeholder="Topics for next meeting" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>

        {/* Form Actions */}
        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? "Saving..." : initialData ? "Update Minutes" : "Create Minutes"}
          </Button>
        </div>
      </form>
    </Form>
  );
};

export default MeetingMinuteForm;
