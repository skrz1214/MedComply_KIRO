import { ChevronRight, Home, Plus } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

interface Breadcrumb {
  label: string;
  href?: string;
}

interface PageHeaderProps {
  title: string;
  description?: string;
  breadcrumbs: Breadcrumb[];
  onAddNew?: () => void;
  addNewLabel?: string;
}

const PageHeader = ({
  title,
  description,
  breadcrumbs,
  onAddNew,
  addNewLabel = "Add New",
}: PageHeaderProps) => {
  return (
    <header className="bg-card border-b border-border px-8 py-6">
      <div className="max-w-7xl">
        {/* Breadcrumbs */}
        <nav className="flex items-center gap-2 text-sm mb-3">
          <Link
            to="/"
            className="text-muted-foreground hover:text-primary transition-colors flex items-center gap-1"
          >
            <Home className="h-4 w-4" />
          </Link>
          {breadcrumbs.map((crumb, index) => (
            <div key={crumb.label} className="flex items-center gap-2">
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
              {crumb.href ? (
                <Link
                  to={crumb.href}
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  {crumb.label}
                </Link>
              ) : (
                <span className="text-foreground font-medium">{crumb.label}</span>
              )}
            </div>
          ))}
        </nav>

        {/* Title and Actions */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">{title}</h1>
            {description && (
              <p className="text-muted-foreground mt-1">{description}</p>
            )}
          </div>
          {onAddNew && (
            <Button onClick={onAddNew} className="gap-2">
              <Plus className="h-4 w-4" />
              {addNewLabel}
            </Button>
          )}
        </div>
      </div>
    </header>
  );
};

export default PageHeader;
