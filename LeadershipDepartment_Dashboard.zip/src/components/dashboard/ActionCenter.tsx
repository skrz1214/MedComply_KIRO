import { useState, useRef, useCallback } from "react";
import { 
  Plus, AlertCircle, Clock, Calendar, CheckCircle2, User, 
  Search, ChevronDown, ChevronRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import TaskDetailDrawer from "./TaskDetailDrawer";

export interface Task {
  id: string;
  title: string;
  dueLabel: string;
  priority: "high" | "medium" | "low";
  owner: string;
  status: "not-started" | "in-progress" | "blocked";
  tab: "today" | "week" | "overdue";
  description?: string;
}

interface ActionCenterProps {
  onAddTask: () => void;
}

const allTasks: Task[] = [
  { id: "1", title: "Review compliance documentation for Q2 2025", dueLabel: "Due Today", priority: "high", owner: "Me", status: "not-started", tab: "today", description: "Complete quarterly compliance documentation review including all updated policies and regulatory changes." },
  { id: "2", title: "Update risk assessment report", dueLabel: "Due Tomorrow", priority: "medium", owner: "Me", status: "in-progress", tab: "today", description: "Update the annual risk assessment report with Q2 findings and mitigation strategies." },
  { id: "3", title: "Schedule monthly compliance meeting", dueLabel: "In 3 days", priority: "low", owner: "J. Smith", status: "not-started", tab: "today", description: "Coordinate with department heads to schedule the monthly compliance review meeting." },
  { id: "4", title: "Submit audit findings to board", dueLabel: "In 5 days", priority: "medium", owner: "Me", status: "not-started", tab: "week" },
  { id: "5", title: "Review policy update requests", dueLabel: "In 6 days", priority: "low", owner: "A. Johnson", status: "not-started", tab: "week" },
  { id: "6", title: "Complete training certification", dueLabel: "Overdue by 2 days", priority: "high", owner: "Me", status: "blocked", tab: "overdue" },
  { id: "7", title: "Address citation response", dueLabel: "Overdue by 5 days", priority: "high", owner: "Me", status: "not-started", tab: "overdue" },
];

const priorityConfig = {
  high: { 
    label: "High", 
    className: "bg-destructive-soft text-destructive border-destructive/20",
    icon: AlertCircle
  },
  medium: { 
    label: "Med", 
    className: "bg-warning-soft text-warning border-warning/20",
    icon: Clock
  },
  low: { 
    label: "Low", 
    className: "bg-muted text-muted-foreground border-border",
    icon: Calendar
  },
};

const statusConfig = {
  "not-started": { label: "Not started", className: "bg-muted text-muted-dark" },
  "in-progress": { label: "In progress", className: "bg-info-soft text-info" },
  "blocked": { label: "Blocked", className: "bg-destructive-soft text-destructive" },
};

const dueConfig = {
  "Due Today": { icon: AlertCircle, className: "text-destructive" },
  "Due Tomorrow": { icon: Clock, className: "text-warning" },
  "In 3 days": { icon: Calendar, className: "text-muted-foreground" },
  "In 5 days": { icon: Calendar, className: "text-muted-foreground" },
  "In 6 days": { icon: Calendar, className: "text-muted-foreground" },
  "Overdue by 2 days": { icon: AlertCircle, className: "text-destructive" },
  "Overdue by 5 days": { icon: AlertCircle, className: "text-destructive" },
};

type TabId = "today" | "week" | "overdue";

const ActionCenter = ({ onAddTask }: ActionCenterProps) => {
  const [activeTab, setActiveTab] = useState<TabId>("today");
  const [ownerFilter, setOwnerFilter] = useState<"me" | "all">("me");
  const [deptFilter, setDeptFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  
  const tabsRef = useRef<HTMLDivElement>(null);
  const tabRefs = useRef<(HTMLButtonElement | null)[]>([]);

  const tabs: { id: TabId; label: string }[] = [
    { id: "today", label: "Today" },
    { id: "week", label: "This Week" },
    { id: "overdue", label: "Overdue" },
  ];

  const filteredTasks = allTasks.filter(task => {
    const tabMatch = task.tab === activeTab;
    const ownerMatch = ownerFilter === "all" || task.owner === "Me";
    const searchMatch = !searchQuery || task.title.toLowerCase().includes(searchQuery.toLowerCase());
    return tabMatch && ownerMatch && searchMatch;
  });

  const todayTasks = allTasks.filter(t => t.tab === "today");
  const completedToday = todayTasks.filter(t => t.status === "in-progress").length;
  const totalToday = todayTasks.length;
  const progressPercent = totalToday > 0 ? (completedToday / totalToday) * 100 : 0;

  const tabCounts = {
    today: allTasks.filter(t => t.tab === "today").length,
    week: allTasks.filter(t => t.tab === "week").length,
    overdue: allTasks.filter(t => t.tab === "overdue").length,
  };

  // Keyboard navigation for tabs
  const handleTabKeyDown = useCallback((e: React.KeyboardEvent, index: number) => {
    let newIndex = index;
    
    if (e.key === "ArrowRight") {
      e.preventDefault();
      newIndex = (index + 1) % tabs.length;
    } else if (e.key === "ArrowLeft") {
      e.preventDefault();
      newIndex = (index - 1 + tabs.length) % tabs.length;
    } else if (e.key === "Home") {
      e.preventDefault();
      newIndex = 0;
    } else if (e.key === "End") {
      e.preventDefault();
      newIndex = tabs.length - 1;
    } else {
      return;
    }

    setActiveTab(tabs[newIndex].id);
    tabRefs.current[newIndex]?.focus();
  }, [tabs]);

  const handleTaskClick = (task: Task) => {
    setSelectedTask(task);
    setIsDrawerOpen(true);
  };


  return (
    <section 
      aria-labelledby="action-center-title"
      className="bg-card rounded-card card-shadow animate-fade-in h-full flex flex-col"
    >
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-3">
          <div>
            <div className="flex items-center gap-2">
              <h2 id="action-center-title" className="text-xl font-bold text-foreground">
                Action Center
              </h2>
              <span className="bg-primary-soft text-primary text-sm font-semibold px-2.5 py-0.5 rounded-chip">
                {filteredTasks.length}
              </span>
            </div>
            <p className="text-sm text-muted-foreground mt-1">Executive compliance tasks</p>
          </div>
          <Button 
            onClick={onAddTask} 
            className="gap-2 touch-target"
            aria-label="Add new action item"
          >
            <Plus className="h-4 w-4" aria-hidden="true" />
            Add Action Item
          </Button>
        </div>

        {/* Progress Meter - Accessible */}
        <div className="flex items-center gap-3 p-3 rounded-card bg-secondary mb-3">
          <div className="flex-1">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-foreground">Today's Progress</span>
              <span className="text-sm text-muted-foreground">{completedToday} of {totalToday} completed</span>
            </div>
            <div 
              role="progressbar" 
              aria-valuenow={completedToday} 
              aria-valuemin={0} 
              aria-valuemax={totalToday}
              aria-label={`Today's progress: ${completedToday} of ${totalToday} tasks completed`}
              className="h-2.5 bg-muted rounded-chip overflow-hidden"
            >
              <div 
                className="h-full bg-primary transition-all duration-300 rounded-chip"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
          <div className="h-10 w-10 rounded-full bg-primary-soft flex items-center justify-center flex-shrink-0">
            <CheckCircle2 className="h-5 w-5 text-primary" aria-hidden="true" />
          </div>
        </div>

        {/* Accessible Tabs */}
        <div 
          ref={tabsRef}
          role="tablist" 
          aria-label="Task time periods"
          className="flex gap-1 p-1 bg-muted rounded-input mb-3"
        >
          {tabs.map((tab, index) => (
            <button
              key={tab.id}
              ref={el => tabRefs.current[index] = el}
              role="tab"
              id={`tab-${tab.id}`}
              aria-selected={activeTab === tab.id}
              aria-controls={`tabpanel-${tab.id}`}
              tabIndex={activeTab === tab.id ? 0 : -1}
              onClick={() => setActiveTab(tab.id)}
              onKeyDown={(e) => handleTabKeyDown(e, index)}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-sm text-sm font-medium transition-colors touch-target",
                activeTab === tab.id
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {tab.label}
              <span 
                className={cn(
                  "text-xs px-2 py-0.5 rounded-chip",
                  activeTab === tab.id ? "bg-primary-soft text-primary" : "bg-muted text-muted-foreground",
                  tab.id === "overdue" && tabCounts.overdue > 0 && "bg-destructive-soft text-destructive"
                )}
                aria-label={`${tabCounts[tab.id]} tasks`}
              >
                {tabCounts[tab.id]}
              </span>
            </button>
          ))}
        </div>

        {/* Filters Row */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Owner Segmented Control */}
          <fieldset className="flex gap-1 p-1 bg-muted rounded-input" role="radiogroup" aria-label="Filter by owner">
            <button
              role="radio"
              aria-checked={ownerFilter === "me"}
              onClick={() => setOwnerFilter("me")}
              className={cn(
                "px-4 py-2 rounded-sm text-sm font-medium transition-colors touch-target",
                ownerFilter === "me"
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              Me
            </button>
            <button
              role="radio"
              aria-checked={ownerFilter === "all"}
              onClick={() => setOwnerFilter("all")}
              className={cn(
                "px-4 py-2 rounded-sm text-sm font-medium transition-colors touch-target",
                ownerFilter === "all"
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              All
            </button>
          </fieldset>

          {/* Department Dropdown */}
          <div className="relative">
            <Label htmlFor="dept-filter" className="sr-only">Filter by department</Label>
            <select
              id="dept-filter"
              value={deptFilter}
              onChange={(e) => setDeptFilter(e.target.value)}
              className="appearance-none bg-card border border-border rounded-input px-4 py-2 pr-8 text-sm text-foreground touch-target focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label="Filter by department"
            >
              <option value="">All Departments</option>
              <option value="compliance">Compliance</option>
              <option value="audit">Audit</option>
              <option value="risk">Risk Management</option>
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" aria-hidden="true" />
          </div>

          {/* Type Dropdown */}
          <div className="relative">
            <Label htmlFor="type-filter" className="sr-only">Filter by type</Label>
            <select
              id="type-filter"
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="appearance-none bg-card border border-border rounded-input px-4 py-2 pr-8 text-sm text-foreground touch-target focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label="Filter by type"
            >
              <option value="">All Types</option>
              <option value="policy">Policy</option>
              <option value="audit">Audit</option>
              <option value="training">Training</option>
              <option value="enforcement">Enforcement</option>
              <option value="risk">Risk</option>
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" aria-hidden="true" />
          </div>

          {/* Search Input */}
          <div className="relative flex-1 min-w-[200px]">
            <Label htmlFor="task-search" className="sr-only">Search tasks</Label>
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="task-search"
              type="search"
              placeholder="Search tasks"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 rounded-input touch-target"
              aria-describedby="search-hint"
            />
            <span id="search-hint" className="sr-only">Type to filter tasks by title</span>
          </div>
        </div>
      </div>

      {/* Task List */}
      <div 
        role="tabpanel" 
        id={`tabpanel-${activeTab}`}
        aria-labelledby={`tab-${activeTab}`}
        className="p-3 space-y-2 flex-1 overflow-auto"
      >
        {filteredTasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-muted-foreground" role="status">
            <CheckCircle2 className="h-12 w-12 mb-3 opacity-40" aria-hidden="true" />
            <p className="text-base font-medium">
              {activeTab === "overdue" ? "No overdue tasks" : "No tasks in this view"}
            </p>
            <p className="text-sm mt-1">
              {activeTab === "overdue" ? "Great job staying on track!" : "Try adjusting your filters"}
            </p>
          </div>
        ) : (
          <ul className="space-y-3" aria-label={`${tabs.find(t => t.id === activeTab)?.label} tasks`}>
            {filteredTasks.map((task) => {
              const priority = priorityConfig[task.priority];
              const status = statusConfig[task.status];
              const due = dueConfig[task.dueLabel as keyof typeof dueConfig];
              const DueIcon = due?.icon || Calendar;
              const PriorityIcon = priority.icon;

              return (
                <li key={task.id}>
                  <article
                    onClick={() => handleTaskClick(task)}
                    onKeyDown={(e) => e.key === "Enter" && handleTaskClick(task)}
                    tabIndex={0}
                    role="button"
                    aria-label={`${task.title}. Priority: ${priority.label}. Status: ${status.label}. ${task.dueLabel}. Owner: ${task.owner}. Press Enter to view details.`}
                    className="group p-4 rounded-card border border-border bg-card hover:bg-secondary/50 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 mb-2">
                          {task.title}
                        </h3>
                        
                        <div className="flex flex-wrap items-center gap-2">
                          {/* Due Label with Icon */}
                          <span className={cn("inline-flex items-center gap-1.5 text-xs font-medium", due?.className)}>
                            <DueIcon className="h-3.5 w-3.5" aria-hidden="true" />
                            <span>{task.dueLabel}</span>
                          </span>

                          <span className="text-muted-foreground" aria-hidden="true">•</span>

                          {/* Owner */}
                          <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                            <User className="h-3.5 w-3.5" aria-hidden="true" />
                            <span>{task.owner}</span>
                          </span>

                          <span className="text-muted-foreground" aria-hidden="true">•</span>

                          {/* Priority Badge */}
                          <span className={cn(
                            "inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-chip border",
                            priority.className
                          )}>
                            <PriorityIcon className="h-3 w-3" aria-hidden="true" />
                            <span>{priority.label}</span>
                          </span>

                          {/* Status Badge */}
                          <span className={cn(
                            "text-xs font-medium px-2 py-0.5 rounded-chip",
                            status.className
                          )}>
                            {status.label}
                          </span>
                        </div>
                      </div>

                      {/* Arrow indicator */}
                      <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-foreground transition-colors flex-shrink-0" aria-hidden="true" />
                    </div>
                  </article>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      {/* Task Detail Drawer */}
      <TaskDetailDrawer
        task={selectedTask}
        open={isDrawerOpen}
        onOpenChange={setIsDrawerOpen}
      />
    </section>
  );
};

export default ActionCenter;
