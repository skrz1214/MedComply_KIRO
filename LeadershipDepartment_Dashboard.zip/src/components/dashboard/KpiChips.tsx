import { CheckCircle2, Clock, AlertTriangle, FileText, TrendingUp, TrendingDown } from "lucide-react";
import { cn } from "@/lib/utils";

interface KpiChipsProps {
  layout?: "horizontal" | "vertical";
}

const kpis = [
  { 
    label: "Total", 
    value: 24, 
    icon: FileText, 
    trend: "+3",
    trendUp: true,
    color: "text-primary",
    bgColor: "bg-primary/10",
    borderColor: "border-primary/20"
  },
  { 
    label: "Completed", 
    value: 12, 
    icon: CheckCircle2, 
    trend: "+5",
    trendUp: true,
    color: "text-success",
    bgColor: "bg-success/10",
    borderColor: "border-success/20"
  },
  { 
    label: "Pending", 
    value: 10, 
    icon: Clock, 
    trend: "-2",
    trendUp: true,
    color: "text-warning",
    bgColor: "bg-warning/10",
    borderColor: "border-warning/20"
  },
  { 
    label: "Overdue", 
    value: 2, 
    icon: AlertTriangle, 
    trend: "+1",
    trendUp: false,
    color: "text-destructive",
    bgColor: "bg-destructive/10",
    borderColor: "border-destructive/20"
  },
];

const KpiChips = ({ layout = "horizontal" }: KpiChipsProps) => {
  if (layout === "vertical") {
    return (
      <div className="bg-card rounded-lg card-shadow p-4 animate-fade-in">
        <h3 className="text-sm font-semibold text-card-foreground mb-4">Quick Stats</h3>
        <div className="space-y-3">
          {kpis.map((kpi) => (
            <div
              key={kpi.label}
              className={cn(
                "flex items-center justify-between p-3 rounded-lg border transition-colors hover:bg-muted/50",
                kpi.borderColor
              )}
            >
              <div className="flex items-center gap-3">
                <div className={cn("p-2 rounded-lg", kpi.bgColor)}>
                  <kpi.icon className={cn("h-4 w-4", kpi.color)} />
                </div>
                <span className="text-sm text-muted-foreground">{kpi.label}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className={cn("text-lg font-bold", kpi.color)}>{kpi.value}</span>
                <div className={cn(
                  "flex items-center text-xs",
                  kpi.trendUp ? "text-success" : "text-destructive"
                )}>
                  {kpi.trendUp ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  <span>{kpi.trend}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2 flex-wrap">
      {kpis.map((kpi, index) => (
        <div
          key={kpi.label}
          className={cn(
            "flex items-center gap-2 px-3 py-1.5 rounded-full border bg-card/50 transition-colors hover:bg-card",
            kpi.borderColor
          )}
          style={{ animationDelay: `${index * 50}ms` }}
        >
          <kpi.icon className={cn("h-3.5 w-3.5", kpi.color)} />
          <span className="text-xs text-muted-foreground">{kpi.label}</span>
          <span className={cn("text-sm font-semibold", kpi.color)}>{kpi.value}</span>
          <div className={cn(
            "flex items-center text-xs",
            kpi.trendUp ? "text-success" : "text-destructive"
          )}>
            {kpi.trendUp ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
          </div>
        </div>
      ))}
    </div>
  );
};

export default KpiChips;
