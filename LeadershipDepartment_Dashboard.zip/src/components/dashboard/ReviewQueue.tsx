import { FileText, User, Calendar, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface ReviewItem {
  id: string;
  title: string;
  type: string;
  submittedBy: string;
  date: string;
  status: "pending" | "in-review" | "needs-revision";
}

const reviewItems: ReviewItem[] = [
  { 
    id: "1", 
    title: "New policy draft – Patient Data Protection", 
    type: "Policy",
    submittedBy: "Sarah Johnson",
    date: "Dec 10, 2025",
    status: "pending"
  },
  { 
    id: "2", 
    title: "Quarterly Audit Results", 
    type: "Audit",
    submittedBy: "Michael Chen",
    date: "Dec 9, 2025",
    status: "in-review"
  },
  { 
    id: "3", 
    title: "Staff Training Compliance Report", 
    type: "Training",
    submittedBy: "Emily Davis",
    date: "Dec 8, 2025",
    status: "pending"
  },
];

const statusConfig = {
  "pending": { label: "Pending Review", className: "bg-warning-soft text-warning" },
  "in-review": { label: "In Review", className: "bg-info-soft text-info" },
  "needs-revision": { label: "Needs Revision", className: "bg-destructive-soft text-destructive" },
};

const ReviewQueue = () => {
  const handleReview = (item: ReviewItem, e?: React.MouseEvent) => {
    e?.stopPropagation();
    toast.info(`Opening review for: ${item.title}`);
  };

  const handleRowClick = (item: ReviewItem) => {
    handleReview(item);
  };

  return (
    <section 
      aria-labelledby="review-queue-title"
      className="bg-card rounded-card card-shadow animate-fade-in"
    >
      <div className="p-5 border-b border-border">
        <div className="flex items-center gap-2">
          <h2 id="review-queue-title" className="text-lg font-bold text-foreground">
            Review Queue
          </h2>
          <span className="bg-secondary text-muted-foreground text-sm font-semibold px-2.5 py-0.5 rounded-chip">
            {reviewItems.length}
          </span>
        </div>
        <p className="text-sm text-muted-foreground mt-1">Pending reviews & sign-offs</p>
      </div>

      <div className="p-4">
        {reviewItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-muted-foreground" role="status">
            <FileText className="h-12 w-12 mb-3 opacity-40" aria-hidden="true" />
            <p className="text-base font-medium">No pending reviews</p>
            <p className="text-sm mt-1">All caught up!</p>
          </div>
        ) : (
          <ul className="space-y-3" aria-label="Pending reviews">
            {reviewItems.map((item) => {
              const status = statusConfig[item.status];

              return (
                <li key={item.id}>
                  <article
                    onClick={() => handleRowClick(item)}
                    onKeyDown={(e) => e.key === "Enter" && handleRowClick(item)}
                    tabIndex={0}
                    role="button"
                    aria-label={`${item.title}. Type: ${item.type}. Submitted by ${item.submittedBy} on ${item.date}. Status: ${status.label}. Press Enter to review.`}
                    className="group flex items-center justify-between p-4 rounded-card bg-secondary/50 hover:bg-secondary transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <div className="flex items-center gap-4 flex-1 min-w-0">
                      <div className="h-10 w-10 rounded-lg bg-primary-soft flex items-center justify-center flex-shrink-0">
                        <FileText className="h-5 w-5 text-primary" aria-hidden="true" />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <h3 className="text-sm font-semibold text-foreground truncate mb-1">
                          {item.title}
                        </h3>
                        
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                          <span className="bg-muted px-2 py-0.5 rounded-chip font-medium">
                            {item.type}
                          </span>
                          
                          <span className="inline-flex items-center gap-1">
                            <User className="h-3 w-3" aria-hidden="true" />
                            {item.submittedBy}
                          </span>
                          
                          <span className="inline-flex items-center gap-1">
                            <Calendar className="h-3 w-3" aria-hidden="true" />
                            {item.date}
                          </span>

                          <span className={cn(
                            "px-2 py-0.5 rounded-chip font-medium",
                            status.className
                          )}>
                            {status.label}
                          </span>
                        </div>
                      </div>
                    </div>

                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={(e) => handleReview(item, e)}
                      className="touch-target text-primary hover:text-primary hover:bg-primary-soft gap-1.5 flex-shrink-0"
                      aria-label={`Review ${item.title}`}
                    >
                      Review
                      <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                    </Button>
                  </article>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </section>
  );
};

export default ReviewQueue;
