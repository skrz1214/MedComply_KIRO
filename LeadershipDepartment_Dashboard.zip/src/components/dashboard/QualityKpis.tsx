import { useState } from "react";
import { Plus, TrendingUp, TrendingDown, X, Edit2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";

interface KpiItem {
  id: string;
  name: string;
  value: number;
  target: number;
  formula: string;
  formulaDescription: string;
  trend: "up" | "down";
}

const defaultKpis: KpiItem[] = [
  {
    id: "1",
    name: "Content Compliance Rate",
    value: 94,
    target: 95,
    formula: "(Compliant Content / Total Content Reviewed) × 100",
    formulaDescription: "(Compliant Content: 188 ÷ Total Content Reviewed: 200) × 100",
    trend: "up",
  },
  {
    id: "2",
    name: "Campaign Approval Rate",
    value: 88,
    target: 90,
    formula: "(First-Time Approvals / Total Submissions) × 100",
    formulaDescription: "(First-Time Approvals: 44 ÷ Total Submissions: 50) × 100",
    trend: "up",
  },
  {
    id: "3",
    name: "Disclosure Compliance Rate",
    value: 97,
    target: 100,
    formula: "(Content with Proper Disclosures / Content Requiring Disclosure) × 100",
    formulaDescription: "(Content with Proper Disclosures: 97 ÷ Content Requiring Disclosure: 100) × 100",
    trend: "down",
  },
  {
    id: "4",
    name: "Regulatory Violation Rate",
    value: 2,
    target: 0,
    formula: "(Violations Found / Total Content Audited) × 100",
    formulaDescription: "(Violations Found: 2 ÷ Total Content Audited: 100) × 100",
    trend: "down",
  },
];

interface KpiFormData {
  name: string;
  value: string;
  target: string;
  formula: string;
  numeratorLabel: string;
  numeratorValue: string;
  denominatorLabel: string;
  denominatorValue: string;
}

const initialFormData: KpiFormData = {
  name: "",
  value: "",
  target: "",
  formula: "",
  numeratorLabel: "",
  numeratorValue: "",
  denominatorLabel: "",
  denominatorValue: "",
};

const QualityKpis = () => {
  const [kpis, setKpis] = useState<KpiItem[]>(defaultKpis);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingKpi, setEditingKpi] = useState<KpiItem | null>(null);
  const [formData, setFormData] = useState<KpiFormData>(initialFormData);

  const getProgressColor = (value: number, target: number, isLowerBetter = false) => {
    if (isLowerBetter) {
      if (value <= target) return "bg-success";
      if (value <= target * 1.5) return "bg-warning";
      return "bg-destructive";
    }
    if (value >= target) return "bg-success";
    if (value >= target * 0.9) return "bg-warning";
    return "bg-destructive";
  };

  const handleAddKpi = () => {
    setEditingKpi(null);
    setFormData(initialFormData);
    setIsModalOpen(true);
  };

  const handleEditKpi = (kpi: KpiItem) => {
    setEditingKpi(kpi);
    setFormData({
      name: kpi.name,
      value: kpi.value.toString(),
      target: kpi.target.toString(),
      formula: kpi.formula,
      numeratorLabel: "",
      numeratorValue: "",
      denominatorLabel: "",
      denominatorValue: "",
    });
    setIsModalOpen(true);
  };

  const handleDeleteKpi = (id: string) => {
    setKpis(kpis.filter((k) => k.id !== id));
    toast({
      title: "KPI deleted",
      description: "The KPI has been removed.",
    });
  };

  const handleSubmit = () => {
    if (!formData.name || !formData.value || !formData.target) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    const value = parseFloat(formData.value);
    const target = parseFloat(formData.target);
    
    const formulaDescription = formData.numeratorLabel && formData.denominatorLabel
      ? `(${formData.numeratorLabel}: ${formData.numeratorValue} ÷ ${formData.denominatorLabel}: ${formData.denominatorValue}) × 100`
      : formData.formula;

    if (editingKpi) {
      setKpis(kpis.map((k) => 
        k.id === editingKpi.id 
          ? { 
              ...k, 
              name: formData.name, 
              value, 
              target, 
              formula: formData.formula || k.formula,
              formulaDescription,
              trend: value >= target ? "up" : "down"
            } 
          : k
      ));
      toast({
        title: "KPI updated",
        description: "The KPI has been updated successfully.",
      });
    } else {
      const newKpi: KpiItem = {
        id: Date.now().toString(),
        name: formData.name,
        value,
        target,
        formula: formData.formula || "(Numerator / Denominator) × 100",
        formulaDescription,
        trend: value >= target ? "up" : "down",
      };
      setKpis([...kpis, newKpi]);
      toast({
        title: "KPI added",
        description: "New KPI has been created successfully.",
      });
    }
    
    setIsModalOpen(false);
    setFormData(initialFormData);
  };

  return (
    <div className="bg-card rounded-xl card-shadow p-4 animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-card-foreground">Quality KPIs</h3>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleAddKpi}
          className="h-8 w-8 p-0"
          aria-label="Add new KPI"
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      <div className="space-y-4">
        {kpis.map((kpi) => {
          const isLowerBetter = kpi.name.toLowerCase().includes("violation");
          const progressColor = getProgressColor(kpi.value, kpi.target, isLowerBetter);
          const meetsTarget = isLowerBetter ? kpi.value <= kpi.target : kpi.value >= kpi.target;
          
          return (
            <div key={kpi.id} className="group relative">
              <div className="flex items-center justify-between mb-1">
                <button
                  onClick={() => handleEditKpi(kpi)}
                  className="text-sm font-medium text-primary hover:underline text-left flex items-center gap-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  {kpi.name}
                  {kpi.trend === "up" ? (
                    <TrendingUp className="h-3 w-3 text-success" />
                  ) : (
                    <TrendingDown className="h-3 w-3 text-destructive" />
                  )}
                </button>
                <span className="text-xs text-muted-foreground">Target: {kpi.target}%</span>
              </div>
              
              <div className="flex items-baseline gap-1 mb-1">
                <span className="text-2xl font-bold text-card-foreground">{kpi.value}</span>
                <span className="text-sm text-muted-foreground">%</span>
              </div>
              
              <div className="h-1.5 bg-muted rounded-full overflow-hidden mb-1">
                <div
                  className={cn("h-full rounded-full transition-all", progressColor)}
                  style={{ width: `${Math.min(kpi.value, 100)}%` }}
                />
              </div>
              
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <span className="inline-block w-2 h-2 rounded-sm bg-muted" />
                {kpi.formulaDescription}
              </p>

              {/* Hover actions */}
              <div className="absolute top-0 right-0 hidden group-hover:flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleEditKpi(kpi)}
                  className="h-6 w-6 p-0"
                  aria-label={`Edit ${kpi.name}`}
                >
                  <Edit2 className="h-3 w-3" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDeleteKpi(kpi.id)}
                  className="h-6 w-6 p-0 text-destructive hover:text-destructive"
                  aria-label={`Delete ${kpi.name}`}
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add/Edit KPI Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingKpi ? "Edit KPI" : "Add New KPI"}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="kpi-name">KPI Name *</Label>
              <Input
                id="kpi-name"
                placeholder="e.g., Content Compliance Rate"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="kpi-value">Current Value (%) *</Label>
                <Input
                  id="kpi-value"
                  type="number"
                  placeholder="94"
                  value={formData.value}
                  onChange={(e) => setFormData({ ...formData, value: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="kpi-target">Target (%) *</Label>
                <Input
                  id="kpi-target"
                  type="number"
                  placeholder="95"
                  value={formData.target}
                  onChange={(e) => setFormData({ ...formData, target: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="kpi-formula">Formula</Label>
              <Input
                id="kpi-formula"
                placeholder="(Numerator / Denominator) × 100"
                value={formData.formula}
                onChange={(e) => setFormData({ ...formData, formula: e.target.value })}
              />
            </div>

            <div className="border rounded-lg p-3 space-y-3 bg-muted/30">
              <p className="text-xs font-medium text-muted-foreground">Formula Components</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label htmlFor="numerator-label" className="text-xs">Numerator Label</Label>
                  <Input
                    id="numerator-label"
                    placeholder="Compliant Content"
                    value={formData.numeratorLabel}
                    onChange={(e) => setFormData({ ...formData, numeratorLabel: e.target.value })}
                    className="h-8 text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="numerator-value" className="text-xs">Value</Label>
                  <Input
                    id="numerator-value"
                    type="number"
                    placeholder="188"
                    value={formData.numeratorValue}
                    onChange={(e) => setFormData({ ...formData, numeratorValue: e.target.value })}
                    className="h-8 text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="denominator-label" className="text-xs">Denominator Label</Label>
                  <Input
                    id="denominator-label"
                    placeholder="Total Content Reviewed"
                    value={formData.denominatorLabel}
                    onChange={(e) => setFormData({ ...formData, denominatorLabel: e.target.value })}
                    className="h-8 text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="denominator-value" className="text-xs">Value</Label>
                  <Input
                    id="denominator-value"
                    type="number"
                    placeholder="200"
                    value={formData.denominatorValue}
                    onChange={(e) => setFormData({ ...formData, denominatorValue: e.target.value })}
                    className="h-8 text-sm"
                  />
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit}>
              {editingKpi ? "Save Changes" : "Add KPI"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default QualityKpis;
