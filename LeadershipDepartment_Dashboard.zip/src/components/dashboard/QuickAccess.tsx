import { 
  CheckCircle, 
  MessageSquare, 
  AlertTriangle, 
  ClipboardCheck, 
  Gavel
} from "lucide-react";
import { cn } from "@/lib/utils";

interface MicroApp {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  href: string;
}

const microApps: MicroApp[] = [
  {
    id: "compliance-connect",
    name: "ComplianceConnect",
    description: "Compliance management hub",
    icon: CheckCircle,
    color: "text-primary",
    bgColor: "bg-primary/10",
    href: "#",
  },
  {
    id: "feedback-hub",
    name: "FeedbackHub",
    description: "Stakeholder feedback system",
    icon: MessageSquare,
    color: "text-warning",
    bgColor: "bg-warning/10",
    href: "#",
  },
  {
    id: "risk-guard",
    name: "RiskGuard",
    description: "Risk assessment platform",
    icon: AlertTriangle,
    color: "text-destructive",
    bgColor: "bg-destructive/10",
    href: "#",
  },
  {
    id: "audit-pro",
    name: "AuditPro",
    description: "Audit management system",
    icon: ClipboardCheck,
    color: "text-info",
    bgColor: "bg-info/10",
    href: "#",
  },
  {
    id: "enforce-point",
    name: "EnforcePoint",
    description: "Enforcement tracking",
    icon: Gavel,
    color: "text-destructive",
    bgColor: "bg-destructive/10",
    href: "#",
  },
];

const QuickAccess = () => {
  return (
    <section className="animate-fade-in" style={{ animationDelay: "300ms" }}>
      <h2 className="text-lg font-semibold text-foreground mb-4">Quick Access</h2>
      
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {microApps.map((app) => (
          <a
            key={app.id}
            href={app.href}
            className="group bg-card rounded-xl p-4 card-shadow hover:shadow-md transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring touch-target"
          >
            <div className={cn(
              "w-10 h-10 rounded-lg flex items-center justify-center mb-3 transition-transform group-hover:scale-110",
              app.bgColor
            )}>
              <app.icon className={cn("h-5 w-5", app.color)} aria-hidden="true" />
            </div>
            <h3 className="text-sm font-medium text-card-foreground group-hover:text-primary transition-colors">
              {app.name}
            </h3>
            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">
              {app.description}
            </p>
          </a>
        ))}
      </div>
    </section>
  );
};

export default QuickAccess;
