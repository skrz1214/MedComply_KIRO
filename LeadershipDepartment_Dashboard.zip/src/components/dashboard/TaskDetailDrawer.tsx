import { useEffect, useRef, useCallback } from "react";
import { X, CheckCircle2, Clock3, User, Calendar, AlertCircle, Paperclip, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { Task } from "./ActionCenter";

interface TaskDetailDrawerProps {
  task: Task | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const priorityConfig = {
  high: { label: "High Priority", className: "text-destructive" },
  medium: { label: "Medium Priority", className: "text-warning" },
  low: { label: "Low Priority", className: "text-muted-foreground" },
};

const statusConfig = {
  "not-started": { label: "Not Started", className: "bg-muted text-muted-dark" },
  "in-progress": { label: "In Progress", className: "bg-info-soft text-info" },
  "blocked": { label: "Blocked", className: "bg-destructive-soft text-destructive" },
};

const TaskDetailDrawer = ({ task, open, onOpenChange }: TaskDetailDrawerProps) => {
  const drawerRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const previousFocusRef = useRef<HTMLElement | null>(null);

  // Store the previously focused element
  useEffect(() => {
    if (open) {
      previousFocusRef.current = document.activeElement as HTMLElement;
    }
  }, [open]);

  // Focus trap and restore
  useEffect(() => {
    if (!open) {
      // Restore focus when closing
      previousFocusRef.current?.focus();
      return;
    }

    // Focus the close button when opening
    const timer = setTimeout(() => {
      closeButtonRef.current?.focus();
    }, 100);

    return () => clearTimeout(timer);
  }, [open]);

  // Handle Escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && open) {
        onOpenChange(false);
      }
    };

    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [open, onOpenChange]);

  // Focus trap
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key !== "Tab" || !drawerRef.current) return;

    const focusableElements = drawerRef.current.querySelectorAll(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    const firstElement = focusableElements[0] as HTMLElement;
    const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

    if (e.shiftKey && document.activeElement === firstElement) {
      e.preventDefault();
      lastElement?.focus();
    } else if (!e.shiftKey && document.activeElement === lastElement) {
      e.preventDefault();
      firstElement?.focus();
    }
  }, []);

  const handleComplete = () => {
    toast.success("Task marked complete", { description: task?.title });
    onOpenChange(false);
  };

  const handleSubmitForReview = () => {
    toast.success("Task submitted for review", { description: task?.title });
    onOpenChange(false);
  };

  if (!task) return null;

  const priority = priorityConfig[task.priority];
  const status = statusConfig[task.status];

  return (
    <>
      {/* Backdrop */}
      <div
        className={cn(
          "fixed inset-0 bg-foreground/30 z-40 transition-opacity duration-200",
          open ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
        onClick={() => onOpenChange(false)}
        aria-hidden="true"
      />

      {/* Drawer */}
      <div
        ref={drawerRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="drawer-title"
        aria-describedby="drawer-description"
        onKeyDown={handleKeyDown}
        className={cn(
          "fixed top-0 right-0 h-full w-full sm:w-[480px] bg-card z-50 shadow-xl transition-transform duration-300 ease-out flex flex-col",
          open ? "translate-x-0" : "translate-x-full"
        )}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <h2 id="drawer-title" className="text-lg font-bold text-foreground">
              Task Details
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              View and manage this task
            </p>
          </div>
          <Button
            ref={closeButtonRef}
            variant="ghost"
            size="sm"
            onClick={() => onOpenChange(false)}
            className="touch-target rounded-full"
            aria-label="Close task details"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6 space-y-6">
          {/* Title and Priority */}
          <div>
            <h3 className="text-base font-bold text-foreground mb-2">{task.title}</h3>
            <div className="flex flex-wrap items-center gap-2">
              <span className={cn("text-sm font-medium", priority.className)}>
                <AlertCircle className="h-4 w-4 inline mr-1" aria-hidden="true" />
                {priority.label}
              </span>
              <span className={cn("text-sm font-medium px-2.5 py-1 rounded-chip", status.className)}>
                {status.label}
              </span>
            </div>
          </div>

          {/* Summary */}
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-2">Summary</h4>
            <p id="drawer-description" className="text-sm text-muted-foreground leading-relaxed">
              {task.description || "No description provided for this task. Add details to help track progress and requirements."}
            </p>
          </div>

          {/* Meta Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-secondary rounded-card">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Calendar className="h-4 w-4" aria-hidden="true" />
                <span className="text-xs font-medium uppercase">Due Date</span>
              </div>
              <p className="text-sm font-semibold text-foreground">{task.dueLabel}</p>
            </div>
            <div className="p-4 bg-secondary rounded-card">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <User className="h-4 w-4" aria-hidden="true" />
                <span className="text-xs font-medium uppercase">Owner</span>
              </div>
              <p className="text-sm font-semibold text-foreground">{task.owner}</p>
            </div>
          </div>

          {/* Checklist Placeholder */}
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-primary" aria-hidden="true" />
              Checklist
            </h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-3 p-3 bg-secondary rounded-card">
                <input 
                  type="checkbox" 
                  id="checklist-1" 
                  className="h-5 w-5 rounded border-border accent-primary"
                  aria-label="Review documentation"
                />
                <label htmlFor="checklist-1" className="flex-1">Review documentation</label>
              </div>
              <div className="flex items-center gap-3 p-3 bg-secondary rounded-card">
                <input 
                  type="checkbox" 
                  id="checklist-2" 
                  className="h-5 w-5 rounded border-border accent-primary"
                  aria-label="Complete assessment"
                />
                <label htmlFor="checklist-2" className="flex-1">Complete assessment</label>
              </div>
              <div className="flex items-center gap-3 p-3 bg-secondary rounded-card">
                <input 
                  type="checkbox" 
                  id="checklist-3" 
                  className="h-5 w-5 rounded border-border accent-primary"
                  aria-label="Submit for approval"
                />
                <label htmlFor="checklist-3" className="flex-1">Submit for approval</label>
              </div>
            </div>
          </div>

          {/* Attachments Placeholder */}
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
              <Paperclip className="h-4 w-4 text-primary" aria-hidden="true" />
              Attachments
            </h4>
            <div className="p-6 border-2 border-dashed border-border rounded-card text-center">
              <p className="text-sm text-muted-foreground">No attachments yet</p>
              <Button variant="ghost" size="sm" className="mt-2 touch-target">
                Add Attachment
              </Button>
            </div>
          </div>

          {/* Comments Placeholder */}
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-primary" aria-hidden="true" />
              Comments
            </h4>
            <div className="p-6 bg-secondary rounded-card text-center">
              <p className="text-sm text-muted-foreground">No comments yet</p>
              <Button variant="ghost" size="sm" className="mt-2 touch-target">
                Add Comment
              </Button>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-6 border-t border-border bg-card">
          <div className="flex flex-col sm:flex-row gap-3">
            <Button 
              onClick={handleComplete}
              className="flex-1 touch-target gap-2"
              aria-label="Mark task as complete"
            >
              <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
              Complete
            </Button>
            <Button 
              variant="outline"
              onClick={handleSubmitForReview}
              className="flex-1 touch-target gap-2"
              aria-label="Submit task for review"
            >
              <Clock3 className="h-4 w-4" aria-hidden="true" />
              Submit for Review
            </Button>
          </div>
          <Button
            variant="ghost"
            onClick={() => onOpenChange(false)}
            className="w-full mt-3 touch-target text-muted-foreground"
          >
            Close
          </Button>
        </div>
      </div>
    </>
  );
};

export default TaskDetailDrawer;
