import { useState } from "react";
import { Users, ChevronDown, Eye, Building2, Shield } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";

export type UserRole = "compliance-head" | "department-head" | "view-only";

interface RoleConfig {
  id: UserRole;
  label: string;
  description: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
}

const roles: RoleConfig[] = [
  {
    id: "compliance-head",
    label: "Compliance Head",
    description: "Full access to all features",
    icon: Shield,
    color: "text-success",
    bgColor: "bg-success/10",
  },
  {
    id: "department-head",
    label: "Department Head",
    description: "Department-level management",
    icon: Building2,
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    id: "view-only",
    label: "View Only",
    description: "Read-only access",
    icon: Eye,
    color: "text-muted-foreground",
    bgColor: "bg-muted",
  },
];

interface RoleImpersonationProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
}

const RoleImpersonation = ({ currentRole, onRoleChange }: RoleImpersonationProps) => {
  const activeRole = roles.find((r) => r.id === currentRole) || roles[0];
  const ActiveIcon = activeRole.icon;

  return (
    <div className="bg-card rounded-xl card-shadow p-4 animate-fade-in">
      <div className="flex items-center gap-2 mb-3">
        <Users className="h-4 w-4 text-muted-foreground" />
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          Impersonate Role
        </span>
      </div>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            className="w-full justify-between h-auto py-3 px-3"
            aria-label="Select role to impersonate"
          >
            <div className="flex items-center gap-3">
              <div className={cn("p-2 rounded-lg", activeRole.bgColor)}>
                <ActiveIcon className={cn("h-4 w-4", activeRole.color)} />
              </div>
              <div className="text-left">
                <p className="text-sm font-medium">{activeRole.label}</p>
                <p className="text-xs text-muted-foreground">{activeRole.description}</p>
              </div>
            </div>
            <ChevronDown className="h-4 w-4 text-muted-foreground ml-2" />
          </Button>
        </DropdownMenuTrigger>

        <DropdownMenuContent align="end" className="w-64">
          <DropdownMenuLabel>Select Role</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {roles.map((role) => {
            const RoleIcon = role.icon;
            const isActive = role.id === currentRole;

            return (
              <DropdownMenuItem
                key={role.id}
                onClick={() => onRoleChange(role.id)}
                className={cn(
                  "flex items-center gap-3 py-3 cursor-pointer",
                  isActive && "bg-muted"
                )}
              >
                <div className={cn("p-2 rounded-lg", role.bgColor)}>
                  <RoleIcon className={cn("h-4 w-4", role.color)} />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{role.label}</p>
                  <p className="text-xs text-muted-foreground">{role.description}</p>
                </div>
                {isActive && (
                  <span className="text-xs font-medium text-success bg-success/10 px-2 py-0.5 rounded-full">
                    Active
                  </span>
                )}
              </DropdownMenuItem>
            );
          })}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

export default RoleImpersonation;
