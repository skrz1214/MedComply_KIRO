import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { 
  ShieldCheck, 
  AlertTriangle, 
  MessageSquare, 
  ClipboardCheck, 
  Scale, 
  FileWarning, 
  Target 
} from "lucide-react";

interface AddTaskModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const taskTypes = [
  { id: "compliance", label: "Compliance", icon: ShieldCheck, color: "text-primary" },
  { id: "risk", label: "Risk", icon: AlertTriangle, color: "text-warning" },
  { id: "feedback", label: "Feedback", icon: MessageSquare, color: "text-accent" },
  { id: "audit", label: "Audit", icon: ClipboardCheck, color: "text-success" },
  { id: "enforcement", label: "Enforcement", icon: Scale, color: "text-destructive" },
  { id: "citation", label: "Citation", icon: FileWarning, color: "text-warning" },
  { id: "kpi", label: "KPI", icon: Target, color: "text-primary" },
];

const AddTaskModal = ({ open, onOpenChange }: AddTaskModalProps) => {
  const [selected, setSelected] = useState<string | null>(null);

  const handleContinue = () => {
    if (selected) {
      console.log("Navigate to:", selected);
      onOpenChange(false);
      setSelected(null);
    }
  };

  const handleClose = () => {
    onOpenChange(false);
    setSelected(null);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">Add New Action Item</DialogTitle>
          <p className="text-sm text-muted-foreground mt-1">Select the type of task to create</p>
        </DialogHeader>
        
        <div className="grid grid-cols-4 gap-3 py-6">
          {taskTypes.map((type) => (
            <button
              key={type.id}
              onClick={() => setSelected(type.id)}
              className={cn(
                "flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all duration-200",
                selected === type.id
                  ? "border-primary bg-primary/5 scale-105"
                  : "border-border hover:border-primary/50 hover:bg-secondary"
              )}
            >
              <type.icon className={cn("h-6 w-6", type.color)} />
              <span className="text-xs font-medium text-card-foreground">{type.label}</span>
            </button>
          ))}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={handleClose}>
            Cancel
          </Button>
          <Button onClick={handleContinue} disabled={!selected}>
            Continue
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AddTaskModal;
