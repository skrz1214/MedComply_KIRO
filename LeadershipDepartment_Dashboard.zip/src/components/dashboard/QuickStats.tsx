import { FileText, CheckCircle2, Clock, AlertTriangle, TrendingUp, TrendingDown } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatItem {
  label: string;
  value: number;
  icon: React.ElementType;
  trend: string;
  trendUp: boolean;
  color: string;
  bgColor: string;
  borderColor: string;
}

const stats: StatItem[] = [
  { 
    label: "Total", 
    value: 42, 
    icon: FileText, 
    trend: "+3",
    trendUp: true,
    color: "text-primary",
    bgColor: "bg-primary/10",
    borderColor: "border-primary/20"
  },
  { 
    label: "Completed", 
    value: 25, 
    icon: CheckCircle2, 
    trend: "+5",
    trendUp: true,
    color: "text-success",
    bgColor: "bg-success/10",
    borderColor: "border-success/20"
  },
  { 
    label: "Pending", 
    value: 13, 
    icon: Clock, 
    trend: "+2",
    trendUp: true,
    color: "text-warning",
    bgColor: "bg-warning/10",
    borderColor: "border-warning/20"
  },
  { 
    label: "Overdue", 
    value: 4, 
    icon: AlertTriangle, 
    trend: "+1",
    trendUp: false,
    color: "text-destructive",
    bgColor: "bg-destructive/10",
    borderColor: "border-destructive/20"
  },
];

const QuickStats = () => {
  return (
    <div className="bg-card rounded-xl card-shadow p-4 animate-fade-in">
      <h3 className="text-sm font-semibold text-card-foreground mb-4">Quick Stats</h3>
      <div className="space-y-3">
        {stats.map((stat) => (
          <div
            key={stat.label}
            className={cn(
              "flex items-center justify-between p-3 rounded-lg border transition-colors hover:bg-muted/50",
              stat.borderColor
            )}
          >
            <div className="flex items-center gap-3">
              <div className={cn("p-2 rounded-lg", stat.bgColor)}>
                <stat.icon className={cn("h-4 w-4", stat.color)} aria-hidden="true" />
              </div>
              <span className="text-sm text-muted-foreground">{stat.label}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={cn("text-lg font-bold", stat.color)}>{stat.value}</span>
              <div className={cn(
                "flex items-center text-xs",
                stat.trendUp ? "text-success" : "text-destructive"
              )}>
                {stat.trendUp ? (
                  <TrendingUp className="h-3 w-3" aria-hidden="true" />
                ) : (
                  <TrendingDown className="h-3 w-3" aria-hidden="true" />
                )}
                <span>{stat.trend}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default QuickStats;
