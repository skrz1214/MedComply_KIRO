import { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BookOpen, FileText, History, Search } from 'lucide-react';
import { TemplatesList } from '@/components/library/TemplatesList';
import { RegulatoryList } from '@/components/library/RegulatoryList';
import { HistoricalList } from '@/components/library/HistoricalList';
import { categories, governingBodies } from '@/data/libraryData';

const EnforcementLibrary = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [bodyFilter, setBodyFilter] = useState('All');

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8 md:px-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold tracking-tight text-foreground mb-1">
            Enforcement Library
          </h1>
          <p className="text-muted-foreground">
            Reference templates, regulations, and historical records for enforcement actions.
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search library..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={bodyFilter} onValueChange={setBodyFilter}>
            <SelectTrigger className="w-full md:w-56">
              <SelectValue placeholder="Governing Body" />
            </SelectTrigger>
            <SelectContent>
              {governingBodies.map((body) => (
                <SelectItem key={body} value={body}>{body}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Tabs defaultValue="templates" className="space-y-6">
          <TabsList className="bg-muted/50 p-1">
            <TabsTrigger value="templates" className="gap-2 data-[state=active]:bg-card">
              <FileText className="h-4 w-4" />
              Templates
            </TabsTrigger>
            <TabsTrigger value="regulatory" className="gap-2 data-[state=active]:bg-card">
              <BookOpen className="h-4 w-4" />
              Regulatory Reference
            </TabsTrigger>
            <TabsTrigger value="historical" className="gap-2 data-[state=active]:bg-card">
              <History className="h-4 w-4" />
              Historical Records
            </TabsTrigger>
          </TabsList>

          <TabsContent value="templates">
            <TemplatesList 
              searchQuery={searchQuery} 
              categoryFilter={categoryFilter}
              bodyFilter={bodyFilter}
            />
          </TabsContent>

          <TabsContent value="regulatory">
            <RegulatoryList 
              searchQuery={searchQuery}
              bodyFilter={bodyFilter}
            />
          </TabsContent>

          <TabsContent value="historical">
            <HistoricalList 
              searchQuery={searchQuery}
              bodyFilter={bodyFilter}
            />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default EnforcementLibrary;
