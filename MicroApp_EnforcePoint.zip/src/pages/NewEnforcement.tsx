import { useNavigate, useSearchParams } from 'react-router-dom';
import { useEnforcement } from '@/context/EnforcementContext';
import { Header } from '@/components/layout/Header';
import { EnforcementForm } from '@/components/enforcement/EnforcementForm';
import { toast } from '@/hooks/use-toast';

const NewEnforcement = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const todoId = searchParams.get('todoId');
  const { addEnforcement, getTodoById, processTodoItem } = useEnforcement();

  const todoItem = todoId ? getTodoById(todoId) : undefined;

  const handleSubmit = (data: Parameters<typeof addEnforcement>[0]) => {
    addEnforcement(data);
    
    if (todoId && todoItem) {
      processTodoItem(todoId, `enf-${Date.now()}`);
    }

    toast({
      title: 'Enforcement Created',
      description: 'The enforcement has been successfully created.',
    });
    
    navigate('/enforcements');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8 md:px-6 max-w-3xl">
        <EnforcementForm
          ticketDescription={todoItem?.ticketDescription}
          ticketId={todoItem?.ticketId}
          onSubmit={handleSubmit}
          onCancel={() => navigate(-1)}
          mode="create"
        />
      </main>
    </div>
  );
};

export default NewEnforcement;
