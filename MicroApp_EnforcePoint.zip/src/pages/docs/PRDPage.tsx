import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Printer, Download } from "lucide-react";

export default function PRDPage() {
  const handlePrint = () => {
    window.print();
  };

  return (
    <AppLayout breadcrumbs={[{ label: "Documentation" }, { label: "Product Requirements Document" }]}>
      <div className="space-y-6 print:space-y-4">
        {/* Header with Print Button */}
        <div className="flex items-center justify-between print:hidden">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Product Requirements Document</h1>
            <p className="text-muted-foreground">EnforcePoint PRD v2.0 - Full Requirements for Development Team</p>
          </div>
          <Button onClick={handlePrint} className="gap-2">
            <Printer className="h-4 w-4" />
            Print / Save as PDF
          </Button>
        </div>

        {/* Document Content */}
        <Card className="print:shadow-none print:border-none">
          <CardContent className="prose prose-slate max-w-none p-8 print:p-0">
            {/* Title Page */}
            <div className="text-center mb-12 print:mb-8">
              <h1 className="text-4xl font-bold mb-4">EnforcePoint</h1>
              <h2 className="text-2xl text-muted-foreground mb-6">Product Requirements Document</h2>
              <div className="flex justify-center gap-4 mb-4">
                <Badge variant="outline">Version 2.0</Badge>
                <Badge variant="outline">December 2024</Badge>
                <Badge>Active Development</Badge>
              </div>
              <p className="text-sm text-muted-foreground">Healthcare Compliance Enforcement Management System</p>
            </div>

            {/* Executive Summary */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">1. Executive Summary</h2>
              <p>
                EnforcePoint is an enterprise-grade microapplication designed to manage enforcement actions as 
                compliance guardrails within healthcare organizations. It provides a centralized platform for 
                tracking penalties, constraints, and mandatory compliance requirements with full lifecycle 
                management from case intake through resolution.
              </p>
              <h3 className="text-lg font-semibold mt-4 mb-2">Key Objectives</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li>Centralize all enforcement case management in a single platform</li>
                <li>Provide complete audit trail and compliance documentation</li>
                <li>Enable proactive deadline management with escalation workflows</li>
                <li>Maintain a reusable library of remedies, templates, and evidence requirements</li>
                <li>Support regulatory body-specific configurations and workflows</li>
              </ul>
            </section>

            {/* Product Vision */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">2. Product Vision</h2>
              <p>
                Enable compliance teams to efficiently track, manage, and resolve enforcement actions while 
                maintaining a comprehensive library of templates, regulations, and historical records for 
                informed decision-making. EnforcePoint transforms reactive compliance management into a 
                proactive, data-driven operation.
              </p>
            </section>

            {/* Case Lifecycle */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">3. Case Lifecycle & Stages</h2>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">3.1 Intake Status</h3>
              <p className="mb-4">Initial processing phase when a case enters the system:</p>
              <table className="w-full border-collapse border mb-4">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Status</th>
                    <th className="border p-2 text-left">Definition</th>
                    <th className="border p-2 text-left">Actions Available</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border p-2 font-medium">Pending Review</td><td className="border p-2">Case created, awaiting initial review</td><td className="border p-2">Review, Assign, Reject</td></tr>
                  <tr><td className="border p-2 font-medium">Under Review</td><td className="border p-2">Case being reviewed for acceptance</td><td className="border p-2">Accept, Reject, Request Info</td></tr>
                  <tr><td className="border p-2 font-medium">Accepted</td><td className="border p-2">Case accepted into operational phase</td><td className="border p-2">Assign Owner, Set Priority</td></tr>
                  <tr><td className="border p-2 font-medium">Rejected</td><td className="border p-2">Case rejected (not applicable)</td><td className="border p-2">Archive, Reopen</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">3.2 Operational Status</h3>
              <p className="mb-4">Active case management phase:</p>
              <table className="w-full border-collapse border mb-4">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Status</th>
                    <th className="border p-2 text-left">Definition</th>
                    <th className="border p-2 text-left">Actions Available</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border p-2 font-medium">Open</td><td className="border p-2">Active case requiring work</td><td className="border p-2">Add Actions, Add Deadlines, Upload Evidence</td></tr>
                  <tr><td className="border p-2 font-medium">In Progress</td><td className="border p-2">Actively being worked on</td><td className="border p-2">Update Progress, Add Correspondence</td></tr>
                  <tr><td className="border p-2 font-medium">Pending Response</td><td className="border p-2">Awaiting regulatory body response</td><td className="border p-2">Log Response, Update Status</td></tr>
                  <tr><td className="border p-2 font-medium">Under Appeal</td><td className="border p-2">Appeal filed, awaiting decision</td><td className="border p-2">Track Appeal, Add Evidence</td></tr>
                  <tr><td className="border p-2 font-medium">Resolved</td><td className="border p-2">Case successfully closed</td><td className="border p-2">Archive, Generate Report</td></tr>
                  <tr><td className="border p-2 font-medium">Closed - Unresolved</td><td className="border p-2">Case closed without full resolution</td><td className="border p-2">Document Reason, Archive</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">3.3 Case Workflow Diagram</h3>
              <div className="bg-muted p-4 rounded-lg text-center text-sm">
                <pre className="whitespace-pre-wrap">
{`
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  PENDING REVIEW │ ──▶ │  UNDER REVIEW   │ ──▶ │    ACCEPTED     │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                               │                        │
                               ▼                        ▼
                        ┌─────────────────┐     ┌─────────────────┐
                        │    REJECTED     │     │      OPEN       │
                        └─────────────────┘     └─────────────────┘
                                                        │
                                                        ▼
                                                ┌─────────────────┐
                                                │   IN PROGRESS   │
                                                └─────────────────┘
                                                        │
                              ┌──────────────────────────┼──────────────────────────┐
                              ▼                          ▼                          ▼
                      ┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐
                      │PENDING RESPONSE │       │  UNDER APPEAL   │       │    RESOLVED     │
                      └─────────────────┘       └─────────────────┘       └─────────────────┘
`}
                </pre>
              </div>
            </section>

            {/* Case Creation Cycle */}
            <section className="mb-10 print:break-before-page">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">3A. Case Creation Cycle (Detailed)</h2>
              <p className="mb-4">
                The Case Creation Cycle encompasses all activities from initial enforcement notice receipt through 
                case acceptance into the operational queue. This cycle ensures proper validation, classification, 
                and assignment before active case management begins.
              </p>

              <h3 className="text-lg font-semibold mt-6 mb-3">3A.1 Cycle Overview</h3>
              <div className="bg-muted p-4 rounded-lg text-center text-sm mb-4">
                <pre className="whitespace-pre-wrap">
{`
┌──────────────┐    ┌──────────────┐    ┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│   TRIGGER    │───▶│   CAPTURE    │───▶│   VALIDATE   │───▶│   CLASSIFY   │───▶│   ASSIGN     │
│              │    │              │    │              │    │              │    │              │
│ • Notice     │    │ • Enter data │    │ • Review     │    │ • Severity   │    │ • Owner      │
│   received   │    │ • Attach     │    │ • Verify     │    │ • Case type  │    │ • Team       │
│ • Survey     │    │   documents  │    │ • Check for  │    │ • Priority   │    │ • Notify     │
│   completed  │    │ • Record     │    │   duplicates │    │ • Tags       │    │ • Accept     │
│ • Complaint  │    │   dates      │    │              │    │              │    │              │
└──────────────┘    └──────────────┘    └──────────────┘    └──────────────┘    └──────────────┘
`}
                </pre>
              </div>

              <h3 className="text-lg font-semibold mt-6 mb-3">3A.2 Stages & Definitions</h3>
              <table className="w-full border-collapse border mb-6">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left w-24">Stage</th>
                    <th className="border p-2 text-left">Description</th>
                    <th className="border p-2 text-left">Key Activities</th>
                    <th className="border p-2 text-left">Exit Criteria</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border p-2 font-medium bg-blue-50">1. Trigger</td>
                    <td className="border p-2">An event initiates the need for a new enforcement case</td>
                    <td className="border p-2">
                      <ul className="list-disc pl-4 text-sm space-y-1">
                        <li>Receive enforcement notice via mail/portal</li>
                        <li>Complete regulatory survey with findings</li>
                        <li>Receive complaint investigation results</li>
                        <li>Self-report compliance issue</li>
                      </ul>
                    </td>
                    <td className="border p-2 text-sm">Decision made to create case</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium bg-blue-50">2. Capture</td>
                    <td className="border p-2">Initial data entry via Create Case Wizard (Steps 1-2)</td>
                    <td className="border p-2">
                      <ul className="list-disc pl-4 text-sm space-y-1">
                        <li>Select regulatory body</li>
                        <li>Enter case type and provider information</li>
                        <li>Record notice received date and survey date</li>
                        <li>Enter regulatory reference numbers</li>
                        <li>Attach initial notice documents</li>
                      </ul>
                    </td>
                    <td className="border p-2 text-sm">All mandatory fields completed, documents attached</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium bg-blue-50">3. Validate</td>
                    <td className="border p-2">Review and verification by intake team</td>
                    <td className="border p-2">
                      <ul className="list-disc pl-4 text-sm space-y-1">
                        <li>Check for duplicate cases</li>
                        <li>Verify regulatory body and case type accuracy</li>
                        <li>Confirm provider information matches records</li>
                        <li>Validate dates and reference numbers</li>
                        <li>Review attached documents for completeness</li>
                      </ul>
                    </td>
                    <td className="border p-2 text-sm">Case validated or returned for corrections</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium bg-blue-50">4. Classify</td>
                    <td className="border p-2">Classification via Create Case Wizard (Step 3)</td>
                    <td className="border p-2">
                      <ul className="list-disc pl-4 text-sm space-y-1">
                        <li>Assess and assign severity level</li>
                        <li>Determine priority based on deadlines</li>
                        <li>Apply relevant tags for filtering</li>
                        <li>Link to related existing cases</li>
                        <li>Apply library recommendations</li>
                      </ul>
                    </td>
                    <td className="border p-2 text-sm">Severity, priority, and tags assigned</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium bg-blue-50">5. Assign</td>
                    <td className="border p-2">Ownership assignment via Create Case Wizard (Step 4)</td>
                    <td className="border p-2">
                      <ul className="list-disc pl-4 text-sm space-y-1">
                        <li>Assign primary case owner</li>
                        <li>Add team members as needed</li>
                        <li>Set notification preferences</li>
                        <li>Review and submit case</li>
                        <li>Accept case into operational queue</li>
                      </ul>
                    </td>
                    <td className="border p-2 text-sm">Owner assigned, case status = "Accepted"</td>
                  </tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">3A.3 Wizard Steps Mapping</h3>
              <table className="w-full border-collapse border mb-4">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Wizard Step</th>
                    <th className="border p-2 text-left">Cycle Stage</th>
                    <th className="border p-2 text-left">Fields Captured</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border p-2 font-medium">Step 1: Basic Info</td>
                    <td className="border p-2">Capture</td>
                    <td className="border p-2 text-sm">Regulatory Body, Case Type, Provider Name, Provider Type, Provider ID</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium">Step 2: Notice Details</td>
                    <td className="border p-2">Capture</td>
                    <td className="border p-2 text-sm">Notice Received Date, Survey Date, Regulatory Reference Number, Initial Notice Upload</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium">Step 3: Classification</td>
                    <td className="border p-2">Classify</td>
                    <td className="border p-2 text-sm">Severity, Priority, Tags, Related Cases, Description/Summary</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium">Step 4: Assignment</td>
                    <td className="border p-2">Assign</td>
                    <td className="border p-2 text-sm">Primary Owner, Team Members, Notification Settings, Initial Deadlines from Library</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium">Step 5: Review & Submit</td>
                    <td className="border p-2">Validate/Assign</td>
                    <td className="border p-2 text-sm">Final review of all entered data, Submit for acceptance</td>
                  </tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">3A.4 Validation Rules</h3>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Duplicate Detection:</strong> System checks for existing cases with same regulatory reference number or provider + survey date combination</li>
                <li><strong>Required Fields:</strong> Regulatory Body, Case Type, Provider Name, Notice Received Date are mandatory</li>
                <li><strong>Date Validation:</strong> Survey Date cannot be in the future; Notice Received Date cannot be before Survey Date</li>
                <li><strong>Document Requirements:</strong> Initial notice document recommended but not required at creation</li>
                <li><strong>Owner Requirement:</strong> Case cannot be accepted without assigned owner</li>
              </ul>
            </section>

            {/* Case Management Cycle */}
            <section className="mb-10 print:break-before-page">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">3B. Case Management Cycle (Detailed)</h2>
              <p className="mb-4">
                The Case Management Cycle covers all operational activities from case acceptance through final resolution. 
                This cycle includes deadline tracking, action management, correspondence handling, appeals processing, 
                and compliance documentation.
              </p>

              <h3 className="text-lg font-semibold mt-6 mb-3">3B.1 Cycle Overview</h3>
              <div className="bg-muted p-4 rounded-lg text-center text-sm mb-4">
                <pre className="whitespace-pre-wrap">
{`
                                    ┌─────────────────────────────────────────────────────────────┐
                                    │                    CASE MANAGEMENT CYCLE                      │
                                    └─────────────────────────────────────────────────────────────┘
                                                              │
        ┌─────────────────┬───────────────────┬───────────────┼───────────────┬─────────────────┐
        ▼                 ▼                   ▼               ▼               ▼                 ▼
┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│   ANALYZE    │  │    PLAN      │  │   EXECUTE    │  │   MONITOR    │  │   RESPOND    │  │   RESOLVE    │
│              │  │              │  │              │  │              │  │              │  │              │
│ • Review     │  │ • Set        │  │ • Complete   │  │ • Track      │  │ • Handle     │  │ • Verify     │
│   findings   │  │   deadlines  │  │   actions    │  │   progress   │  │   appeals    │  │   completion │
│ • Assess     │  │ • Identify   │  │ • Upload     │  │ • Escalate   │  │ • Process    │  │ • Document   │
│   impact     │  │   remedies   │  │   evidence   │  │   overdue    │  │   responses  │  │   outcome    │
│ • Determine  │  │ • Draft      │  │ • Send       │  │ • Update     │  │ • Adjust     │  │ • Close      │
│   strategy   │  │   responses  │  │   correspond │  │   status     │  │   amounts    │  │   case       │
└──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘
`}
                </pre>
              </div>

              <h3 className="text-lg font-semibold mt-6 mb-3">3B.2 Stages & Definitions</h3>
              <table className="w-full border-collapse border mb-6">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left w-24">Stage</th>
                    <th className="border p-2 text-left">Description</th>
                    <th className="border p-2 text-left">Key Activities</th>
                    <th className="border p-2 text-left">System Features Used</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border p-2 font-medium bg-green-50">1. Analyze</td>
                    <td className="border p-2">Deep review of enforcement details and impact assessment</td>
                    <td className="border p-2">
                      <ul className="list-disc pl-4 text-sm space-y-1">
                        <li>Review all findings/deficiencies in detail</li>
                        <li>Identify scope of harm or immediate jeopardy</li>
                        <li>Assess financial exposure</li>
                        <li>Determine operational impact</li>
                        <li>Review historical precedents from library</li>
                      </ul>
                    </td>
                    <td className="border p-2 text-sm">Findings Tab, Library Reference Sheet, Historical Records</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium bg-green-50">2. Plan</td>
                    <td className="border p-2">Develop response strategy and set timeline</td>
                    <td className="border p-2">
                      <ul className="list-disc pl-4 text-sm space-y-1">
                        <li>Set all required deadlines (Response, PoC, Appeal)</li>
                        <li>Apply deadline rules from library</li>
                        <li>Identify required remedies/actions</li>
                        <li>Apply remedy library recommendations</li>
                        <li>Draft response using templates</li>
                        <li>Assign tasks to team members</li>
                      </ul>
                    </td>
                    <td className="border p-2 text-sm">Deadlines Tab, Library Picker, Response Templates, Actions Tab</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium bg-green-50">3. Execute</td>
                    <td className="border p-2">Carry out planned actions and remediation</td>
                    <td className="border p-2">
                      <ul className="list-disc pl-4 text-sm space-y-1">
                        <li>Complete each action item</li>
                        <li>Implement operational remedies</li>
                        <li>Process payments for financial penalties</li>
                        <li>Upload evidence of compliance</li>
                        <li>Send correspondence to regulatory body</li>
                        <li>Update action status as completed</li>
                      </ul>
                    </td>
                    <td className="border p-2 text-sm">Actions Tab, Evidence Tab, Correspondence Tab</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium bg-green-50">4. Monitor</td>
                    <td className="border p-2">Ongoing tracking and escalation management</td>
                    <td className="border p-2">
                      <ul className="list-disc pl-4 text-sm space-y-1">
                        <li>Track deadline approach via dashboard</li>
                        <li>Monitor action completion percentage</li>
                        <li>Receive and acknowledge warnings</li>
                        <li>Escalate overdue items per rules</li>
                        <li>Update case status as milestones met</li>
                        <li>Log timeline events</li>
                      </ul>
                    </td>
                    <td className="border p-2 text-sm">Dashboard, Calendar, Timeline Tab, Escalation Rules</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium bg-green-50">5. Respond</td>
                    <td className="border p-2">Handle regulatory responses and appeals</td>
                    <td className="border p-2">
                      <ul className="list-disc pl-4 text-sm space-y-1">
                        <li>Log inbound correspondence from regulator</li>
                        <li>Review acceptance or rejection of submissions</li>
                        <li>File appeals (IDR, Formal, Hearing) if needed</li>
                        <li>Track appeal status and deadlines</li>
                        <li>Attend hearings and record outcomes</li>
                        <li>Adjust penalty amounts based on decisions</li>
                      </ul>
                    </td>
                    <td className="border p-2 text-sm">Correspondence Tab, Appeals Tab, Appeal Form Dialog</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium bg-green-50">6. Resolve</td>
                    <td className="border p-2">Final case closure and documentation</td>
                    <td className="border p-2">
                      <ul className="list-disc pl-4 text-sm space-y-1">
                        <li>Verify all actions completed</li>
                        <li>Confirm all payments made</li>
                        <li>Ensure all evidence uploaded</li>
                        <li>Document final outcome</li>
                        <li>Update status to Resolved or Closed-Unresolved</li>
                        <li>Generate case summary report</li>
                        <li>Archive case for historical reference</li>
                      </ul>
                    </td>
                    <td className="border p-2 text-sm">Overview Tab, Status Workflow, Reports</td>
                  </tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">3B.3 Status Transitions</h3>
              <table className="w-full border-collapse border mb-4">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">From Status</th>
                    <th className="border p-2 text-left">To Status</th>
                    <th className="border p-2 text-left">Trigger Condition</th>
                    <th className="border p-2 text-left">Cycle Stage</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border p-2">Accepted</td>
                    <td className="border p-2">Open</td>
                    <td className="border p-2 text-sm">Case owner begins analysis</td>
                    <td className="border p-2">Analyze</td>
                  </tr>
                  <tr>
                    <td className="border p-2">Open</td>
                    <td className="border p-2">In Progress</td>
                    <td className="border p-2 text-sm">First action item or deadline added</td>
                    <td className="border p-2">Plan</td>
                  </tr>
                  <tr>
                    <td className="border p-2">In Progress</td>
                    <td className="border p-2">Pending Response</td>
                    <td className="border p-2 text-sm">Response/PoC submitted, awaiting regulator</td>
                    <td className="border p-2">Execute → Monitor</td>
                  </tr>
                  <tr>
                    <td className="border p-2">Pending Response</td>
                    <td className="border p-2">In Progress</td>
                    <td className="border p-2 text-sm">Regulator response received, more work needed</td>
                    <td className="border p-2">Respond → Execute</td>
                  </tr>
                  <tr>
                    <td className="border p-2">In Progress</td>
                    <td className="border p-2">Under Appeal</td>
                    <td className="border p-2 text-sm">Appeal filed</td>
                    <td className="border p-2">Respond</td>
                  </tr>
                  <tr>
                    <td className="border p-2">Under Appeal</td>
                    <td className="border p-2">In Progress</td>
                    <td className="border p-2 text-sm">Appeal decided, additional work required</td>
                    <td className="border p-2">Respond → Execute</td>
                  </tr>
                  <tr>
                    <td className="border p-2">In Progress / Pending Response / Under Appeal</td>
                    <td className="border p-2">Resolved</td>
                    <td className="border p-2 text-sm">All actions complete, compliance verified</td>
                    <td className="border p-2">Resolve</td>
                  </tr>
                  <tr>
                    <td className="border p-2">Any Operational Status</td>
                    <td className="border p-2">Closed - Unresolved</td>
                    <td className="border p-2 text-sm">Case closed without full resolution (documented reason required)</td>
                    <td className="border p-2">Resolve</td>
                  </tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">3B.4 Deadline Management Within Cycle</h3>
              <table className="w-full border-collapse border mb-4">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Deadline Type</th>
                    <th className="border p-2 text-left">Typical Trigger</th>
                    <th className="border p-2 text-left">Default Duration</th>
                    <th className="border p-2 text-left">Warning Thresholds</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border p-2 font-medium">Response Deadline</td>
                    <td className="border p-2 text-sm">Notice received date</td>
                    <td className="border p-2 text-sm">10-30 calendar days (varies by regulator)</td>
                    <td className="border p-2 text-sm">7 days, 3 days, 1 day</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium">Plan of Correction (PoC)</td>
                    <td className="border p-2 text-sm">Survey exit date or notice date</td>
                    <td className="border p-2 text-sm">10-14 business days</td>
                    <td className="border p-2 text-sm">5 days, 2 days, 1 day</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium">Appeal Filing</td>
                    <td className="border p-2 text-sm">CMP notice date</td>
                    <td className="border p-2 text-sm">60 calendar days (CMS); varies by state</td>
                    <td className="border p-2 text-sm">14 days, 7 days, 3 days</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium">Payment Due</td>
                    <td className="border p-2 text-sm">Final CMP amount determined or appeal exhausted</td>
                    <td className="border p-2 text-sm">30 calendar days</td>
                    <td className="border p-2 text-sm">7 days, 3 days, due date</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium">Revisit/Follow-up</td>
                    <td className="border p-2 text-sm">PoC submission date</td>
                    <td className="border p-2 text-sm">45-90 calendar days</td>
                    <td className="border p-2 text-sm">14 days, 7 days</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium">Hearing Date</td>
                    <td className="border p-2 text-sm">Hearing scheduled</td>
                    <td className="border p-2 text-sm">Set by ALJ/hearing officer</td>
                    <td className="border p-2 text-sm">30 days, 14 days, 7 days, 1 day</td>
                  </tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">3B.5 Evidence Management Requirements</h3>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Evidence Checklist:</strong> Applied from Evidence Requirements library based on case type and findings</li>
                <li><strong>Sensitivity Tagging:</strong> PHI, PII, Confidential, Internal Only, Public</li>
                <li><strong>Version Control:</strong> Track document versions with upload timestamps</li>
                <li><strong>Audit Trail:</strong> Log all uploads, views, and downloads</li>
                <li><strong>Attachment Linking:</strong> Evidence linked to specific findings or actions</li>
              </ul>

              <h3 className="text-lg font-semibold mt-6 mb-3">3B.6 Resolution Criteria</h3>
              <p className="mb-2">A case may be marked as "Resolved" only when ALL of the following are true:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>All required actions marked as complete</li>
                <li>All financial penalties paid in full (or payment plan in good standing)</li>
                <li>All required evidence uploaded and accepted</li>
                <li>No pending appeals or regulatory responses expected</li>
                <li>Regulatory body has acknowledged resolution (if applicable)</li>
                <li>Final outcome documented in case summary</li>
              </ul>
            </section>

            {/* Core Features */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">4. Core Features</h2>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">4.1 Case Management</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li><strong>Case Creation Wizard:</strong> Step-by-step guided case creation with validation</li>
                <li><strong>Case Workspace:</strong> Tabbed interface with Overview, Timeline, Deadlines, Actions, Findings, Evidence, Correspondence</li>
                <li><strong>Case List:</strong> Filterable, sortable list with quick actions</li>
                <li><strong>Status Workflow:</strong> Visual status transitions with audit logging</li>
                <li><strong>Cross-Case Linking:</strong> Link related cases together</li>
              </ul>

              <h3 className="text-lg font-semibold mt-6 mb-3">4.2 Deadline Management</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li><strong>Deadline Types:</strong> Response, PoC, Appeal Filing, Payment, Revisit, Hearing</li>
                <li><strong>Warning Thresholds:</strong> Configurable alerts at 7, 3, 1 days (default)</li>
                <li><strong>Escalation Rules:</strong> Auto-escalate to defined recipients on approach/overdue</li>
                <li><strong>Calendar Integration:</strong> Visual calendar with all deadlines</li>
              </ul>

              <h3 className="text-lg font-semibold mt-6 mb-3">4.3 Actions & Remedies</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li><strong>Action Categories:</strong> Financial Penalty, Payment Remedy, Operational Remedy, Licensure/Restriction, Monitoring Requirement</li>
                <li><strong>Financial Tracking:</strong> Original amount, amount paid, amount due, interest calculations</li>
                <li><strong>Remedy Library:</strong> Pre-defined remedies with evidence expectations</li>
              </ul>

              <h3 className="text-lg font-semibold mt-6 mb-3">4.4 Correspondence Management</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li><strong>Directions:</strong> Inbound (from regulator) and Outbound (to regulator)</li>
                <li><strong>Document Types:</strong> Notice, Statement of Deficiencies, Response Letter, Appeal Filing, etc.</li>
                <li><strong>Response Templates:</strong> Pre-defined templates with required sections</li>
                <li><strong>Attachment Management:</strong> File uploads with sensitivity tagging</li>
              </ul>

              <h3 className="text-lg font-semibold mt-6 mb-3">4.5 Appeals Management</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li><strong>Appeal Types:</strong> Informal Dispute Resolution, Formal Appeal, Administrative Hearing</li>
                <li><strong>Appeal Tracking:</strong> Status, deadlines, hearing dates, outcomes</li>
                <li><strong>Outcome Recording:</strong> Upheld, Partially Upheld, Overturned with adjusted amounts</li>
              </ul>

              <h3 className="text-lg font-semibold mt-6 mb-3">4.6 Enforcement Library</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li><strong>Remedy Library:</strong> Pre-defined remedies with evidence expectations, warning thresholds</li>
                <li><strong>Deadline Rules:</strong> Regulatory body-specific deadline configurations</li>
                <li><strong>Response Templates:</strong> Templates with required sections and attachments</li>
                <li><strong>Evidence Requirements:</strong> Checklists with sensitivity guidance</li>
                <li><strong>Finding Categories:</strong> Standard finding classifications by case type</li>
              </ul>
            </section>

            {/* Data Model */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">5. Data Model</h2>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">5.1 Enforcement Case</h3>
              <table className="w-full border-collapse border text-sm mb-4">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Field</th>
                    <th className="border p-2 text-left">Type</th>
                    <th className="border p-2 text-left">Description</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border p-2">id</td><td className="border p-2">string</td><td className="border p-2">Unique identifier</td></tr>
                  <tr><td className="border p-2">caseNumber</td><td className="border p-2">string</td><td className="border p-2">Human-readable case number (ENF-YYYY-NNN)</td></tr>
                  <tr><td className="border p-2">regulatoryBodyId</td><td className="border p-2">string</td><td className="border p-2">Reference to regulatory body</td></tr>
                  <tr><td className="border p-2">caseType</td><td className="border p-2">enum</td><td className="border p-2">Survey, Complaint, CMP, Audit, Self-Reported</td></tr>
                  <tr><td className="border p-2">providerName</td><td className="border p-2">string</td><td className="border p-2">Affected provider/facility name</td></tr>
                  <tr><td className="border p-2">providerType</td><td className="border p-2">enum</td><td className="border p-2">Hospital, Clinic, SNF, ALF, Home Health</td></tr>
                  <tr><td className="border p-2">severity</td><td className="border p-2">enum</td><td className="border p-2">Low, Medium, High, Critical</td></tr>
                  <tr><td className="border p-2">intakeStatus</td><td className="border p-2">enum</td><td className="border p-2">Pending Review, Under Review, Accepted, Rejected</td></tr>
                  <tr><td className="border p-2">operationalStatus</td><td className="border p-2">enum</td><td className="border p-2">Open, In Progress, Pending Response, etc.</td></tr>
                  <tr><td className="border p-2">noticeReceivedDate</td><td className="border p-2">Date</td><td className="border p-2">Date enforcement notice received</td></tr>
                  <tr><td className="border p-2">surveyDate</td><td className="border p-2">Date</td><td className="border p-2">Date of survey (if applicable)</td></tr>
                  <tr><td className="border p-2">assignedOwnerId</td><td className="border p-2">string</td><td className="border p-2">Primary responsible user</td></tr>
                  <tr><td className="border p-2">teamMemberIds</td><td className="border p-2">string[]</td><td className="border p-2">Additional team members</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">5.2 Regulatory Body</h3>
              <table className="w-full border-collapse border text-sm mb-4">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Field</th>
                    <th className="border p-2 text-left">Type</th>
                    <th className="border p-2 text-left">Description</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border p-2">id</td><td className="border p-2">string</td><td className="border p-2">Unique identifier</td></tr>
                  <tr><td className="border p-2">name</td><td className="border p-2">string</td><td className="border p-2">Full name (e.g., Centers for Medicare & Medicaid Services)</td></tr>
                  <tr><td className="border p-2">abbreviation</td><td className="border p-2">string</td><td className="border p-2">Short name (e.g., CMS)</td></tr>
                  <tr><td className="border p-2">level</td><td className="border p-2">enum</td><td className="border p-2">Federal, State, Local</td></tr>
                  <tr><td className="border p-2">jurisdiction</td><td className="border p-2">string</td><td className="border p-2">Geographic jurisdiction</td></tr>
                  <tr><td className="border p-2">oversightTypes</td><td className="border p-2">enum[]</td><td className="border p-2">Licensing, Certification, Accreditation, etc.</td></tr>
                  <tr><td className="border p-2">standardResponseDays</td><td className="border p-2">number</td><td className="border p-2">Default response deadline</td></tr>
                  <tr><td className="border p-2">contactEmail</td><td className="border p-2">string</td><td className="border p-2">Primary contact email</td></tr>
                  <tr><td className="border p-2">portalUrl</td><td className="border p-2">string</td><td className="border p-2">Online portal URL</td></tr>
                </tbody>
              </table>
            </section>

            {/* User Workflows */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">6. User Workflows</h2>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">6.1 Create New Case</h3>
              <ol className="list-decimal pl-6 space-y-1">
                <li>Navigate to Cases → Create New Case</li>
                <li>Complete Step 1: Basic Info (Regulatory Body, Case Type, Provider)</li>
                <li>Complete Step 2: Notice Details (Dates, Reference Numbers)</li>
                <li>Complete Step 3: Classification (Severity, Tags)</li>
                <li>Complete Step 4: Assignment (Owner, Team)</li>
                <li>Review and Submit</li>
                <li>Case created in "Pending Review" status</li>
              </ol>

              <h3 className="text-lg font-semibold mt-6 mb-3">6.2 Manage Case Through Lifecycle</h3>
              <ol className="list-decimal pl-6 space-y-1">
                <li>Review case in intake queue</li>
                <li>Accept case → Status changes to "Open"</li>
                <li>Add deadlines from library or manually</li>
                <li>Add actions/remedies as imposed</li>
                <li>Log correspondence (inbound and outbound)</li>
                <li>Upload evidence against requirements</li>
                <li>Track progress through status changes</li>
                <li>File appeal if necessary</li>
                <li>Resolve case when all actions complete</li>
              </ol>

              <h3 className="text-lg font-semibold mt-6 mb-3">6.3 Apply Library Items to Case</h3>
              <ol className="list-decimal pl-6 space-y-1">
                <li>Open case workspace</li>
                <li>Click "Add from Library" button</li>
                <li>Browse recommended items based on case type</li>
                <li>Select item to preview</li>
                <li>Choose "Reference" (link only) or "Apply" (copy values)</li>
                <li>Item added to case with audit trail</li>
              </ol>
            </section>

            {/* Technical Architecture */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">7. Technical Architecture</h2>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">7.1 Frontend Stack</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li><strong>Framework:</strong> React 18 with TypeScript</li>
                <li><strong>Routing:</strong> React Router DOM v6</li>
                <li><strong>Styling:</strong> Tailwind CSS with custom design system</li>
                <li><strong>UI Components:</strong> shadcn/ui component library</li>
                <li><strong>State Management:</strong> React Context API</li>
                <li><strong>Forms:</strong> React Hook Form with Zod validation</li>
                <li><strong>Data Fetching:</strong> TanStack Query</li>
              </ul>

              <h3 className="text-lg font-semibold mt-6 mb-3">7.2 Backend (Lovable Cloud)</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li><strong>Database:</strong> PostgreSQL via Supabase</li>
                <li><strong>Authentication:</strong> Supabase Auth</li>
                <li><strong>Storage:</strong> Supabase Storage for file uploads</li>
                <li><strong>Edge Functions:</strong> Deno-based serverless functions</li>
                <li><strong>Row Level Security:</strong> Enforced on all tables</li>
              </ul>

              <h3 className="text-lg font-semibold mt-6 mb-3">7.3 Key Components</h3>
              <table className="w-full border-collapse border text-sm">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Component</th>
                    <th className="border p-2 text-left">Purpose</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border p-2">EnforcePointContext</td><td className="border p-2">Global state management for cases, library items</td></tr>
                  <tr><td className="border p-2">CaseWorkspace</td><td className="border p-2">Main case management interface with tabs</td></tr>
                  <tr><td className="border p-2">CreateCaseWizard</td><td className="border p-2">Multi-step case creation flow</td></tr>
                  <tr><td className="border p-2">LibraryPickerDialog</td><td className="border p-2">Browse and apply library items</td></tr>
                  <tr><td className="border p-2">CaseStatusWorkflow</td><td className="border p-2">Visual status transition component</td></tr>
                  <tr><td className="border p-2">AdminConfigPage</td><td className="border p-2">System configuration interface</td></tr>
                  <tr><td className="border p-2">UserContext</td><td className="border p-2">User role and view mode state management</td></tr>
                  <tr><td className="border p-2">UserSwitcher</td><td className="border p-2">User impersonation and view mode toggle component</td></tr>
                </tbody>
              </table>
            </section>

            {/* User Roles & Impersonation */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">8. User Roles & View Modes</h2>
              <p className="mb-4">
                EnforcePoint implements role-based access control with flexible view modes to allow users 
                to see data at different organizational levels.
              </p>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">8.1 User Roles</h3>
              <table className="w-full border-collapse border mb-4">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Role</th>
                    <th className="border p-2 text-left">Description</th>
                    <th className="border p-2 text-left">Data Access</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border p-2 font-medium">Admin</td>
                    <td className="border p-2">System administrator with full access</td>
                    <td className="border p-2 text-sm">All cases across all departments and users</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium">Compliance Head</td>
                    <td className="border p-2">Organization-wide compliance leadership</td>
                    <td className="border p-2 text-sm">All cases across all departments and users</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium">Department Head</td>
                    <td className="border p-2">Department-level leadership</td>
                    <td className="border p-2 text-sm">Cases within assigned department only</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium">Staff</td>
                    <td className="border p-2">Individual contributor</td>
                    <td className="border p-2 text-sm">Cases assigned to self only</td>
                  </tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">8.2 View Modes</h3>
              <p className="mb-4">Users can switch between view modes based on their role permissions:</p>
              <table className="w-full border-collapse border mb-4">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">View Mode</th>
                    <th className="border p-2 text-left">Available To</th>
                    <th className="border p-2 text-left">Shows</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border p-2 font-medium">Organization View</td>
                    <td className="border p-2">Admin, Compliance Head</td>
                    <td className="border p-2 text-sm">All cases across the entire organization</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium">Department View</td>
                    <td className="border p-2">Admin, Compliance Head, Department Head</td>
                    <td className="border p-2 text-sm">All cases within a selected department</td>
                  </tr>
                  <tr>
                    <td className="border p-2 font-medium">Individual View</td>
                    <td className="border p-2">All roles</td>
                    <td className="border p-2 text-sm">Cases assigned to a specific user (or self for Staff role)</td>
                  </tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">8.3 User Impersonation</h3>
              <p className="mb-4">
                For testing and support purposes, users with Admin role can impersonate other users 
                to see the system from their perspective. This feature:
              </p>
              <ul className="list-disc pl-6 space-y-1">
                <li>Allows switching between different user personas via the User Switcher component</li>
                <li>Displays the current user's role and available view mode options in the header</li>
                <li>Automatically adjusts available view modes based on the impersonated user's role</li>
                <li>Provides visual indicators showing which view mode is currently active</li>
              </ul>
            </section>

            {/* Admin Configuration */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">9. Admin Configuration</h2>
              <p className="mb-4">The Admin Configuration module allows system administrators to customize the application:</p>
              
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Regulatory Bodies:</strong> Add/edit/delete regulatory bodies with contact info and jurisdiction</li>
                <li><strong>Case Types:</strong> Configure case type options</li>
                <li><strong>Provider Types:</strong> Manage provider type classifications</li>
                <li><strong>Action Types:</strong> Define action/remedy categories</li>
                <li><strong>Finding Categories:</strong> Standard finding classifications</li>
                <li><strong>Deadline Rules:</strong> Configure deadline calculations and warning thresholds</li>
                <li><strong>Document Types:</strong> Manage correspondence document types</li>
                <li><strong>Escalation Rules:</strong> Define escalation triggers and recipients</li>
                <li><strong>Severity Levels:</strong> Configure severity classifications with colors</li>
                <li><strong>Library Settings:</strong> Manage library versioning and access controls</li>
              </ul>
            </section>

            {/* Success Metrics */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">10. Success Metrics</h2>
              <table className="w-full border-collapse border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Metric</th>
                    <th className="border p-2 text-left">Target</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border p-2">Case creation time</td><td className="border p-2">&lt; 5 minutes</td></tr>
                  <tr><td className="border p-2">Library item application</td><td className="border p-2">&lt; 30 seconds</td></tr>
                  <tr><td className="border p-2">Deadline visibility</td><td className="border p-2">100% of deadlines visible in calendar</td></tr>
                  <tr><td className="border p-2">Escalation accuracy</td><td className="border p-2">100% of overdue items escalated</td></tr>
                  <tr><td className="border p-2">Audit trail completeness</td><td className="border p-2">All status changes logged</td></tr>
                </tbody>
              </table>
            </section>

            {/* Glossary */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">11. Glossary</h2>
              <table className="w-full border-collapse border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Term</th>
                    <th className="border p-2 text-left">Definition</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border p-2 font-medium">Enforcement Case</td><td className="border p-2">A compliance action requiring tracking and resolution</td></tr>
                  <tr><td className="border p-2 font-medium">Regulatory Body</td><td className="border p-2">Government or accreditation agency issuing enforcement</td></tr>
                  <tr><td className="border p-2 font-medium">CMP</td><td className="border p-2">Civil Money Penalty - financial penalty imposed by regulator</td></tr>
                  <tr><td className="border p-2 font-medium">PoC</td><td className="border p-2">Plan of Correction - required remediation plan</td></tr>
                  <tr><td className="border p-2 font-medium">IDR</td><td className="border p-2">Informal Dispute Resolution - first-level appeal process</td></tr>
                  <tr><td className="border p-2 font-medium">Library Item</td><td className="border p-2">Reusable template for remedies, deadlines, or templates</td></tr>
                  <tr><td className="border p-2 font-medium">Finding</td><td className="border p-2">Specific deficiency or violation identified in case</td></tr>
                  <tr><td className="border p-2 font-medium">View Mode</td><td className="border p-2">Data scope filter (Organization, Department, or Individual level)</td></tr>
                  <tr><td className="border p-2 font-medium">User Impersonation</td><td className="border p-2">Admin feature to view system as another user</td></tr>
                </tbody>
              </table>
            </section>

            <div className="text-center text-sm text-muted-foreground mt-12 pt-8 border-t">
              <p>Document maintained by EnforcePoint Product Team</p>
              <p>Last Updated: December 2024</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
