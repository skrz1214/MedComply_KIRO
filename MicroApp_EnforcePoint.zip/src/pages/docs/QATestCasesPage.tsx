import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Printer } from "lucide-react";

export default function QATestCasesPage() {
  const handlePrint = () => {
    window.print();
  };

  return (
    <AppLayout breadcrumbs={[{ label: "Documentation" }, { label: "QA Test Cases" }]}>
      <div className="space-y-6 print:space-y-4">
        {/* Header with Print Button */}
        <div className="flex items-center justify-between print:hidden">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">QA Test Cases</h1>
            <p className="text-muted-foreground">EnforcePoint Quality Assurance Test Suite</p>
          </div>
          <Button onClick={handlePrint} className="gap-2">
            <Printer className="h-4 w-4" />
            Print / Save as PDF
          </Button>
        </div>

        {/* Document Content */}
        <Card className="print:shadow-none print:border-none">
          <CardContent className="prose prose-slate max-w-none p-8 print:p-0">
            {/* Title Page */}
            <div className="text-center mb-12 print:mb-8">
              <h1 className="text-4xl font-bold mb-4">EnforcePoint</h1>
              <h2 className="text-2xl text-muted-foreground mb-6">QA Test Cases Document</h2>
              <div className="flex justify-center gap-4 mb-4">
                <Badge variant="outline">Version 2.0</Badge>
                <Badge variant="outline">December 2024</Badge>
              </div>
            </div>

            {/* Test Case Categories */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">1. Case Management Tests</h2>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">TC-CM-001: Create New Case</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">User is logged in, at least one Regulatory Body exists</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Cases → Create New Case</li>
                      <li>Select Regulatory Body from dropdown</li>
                      <li>Select Case Type</li>
                      <li>Enter Provider Name and Type</li>
                      <li>Enter Notice Received Date</li>
                      <li>Set Severity Level</li>
                      <li>Assign Owner</li>
                      <li>Click "Create Case"</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Case is created with status "Pending Review", case number generated (ENF-YYYY-NNN format), audit log entry created</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">TC-CM-002: Create Case - Validation</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">User is on Create Case form</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Leave Regulatory Body blank</li>
                      <li>Attempt to proceed to next step</li>
                      <li>Leave Provider Name blank</li>
                      <li>Attempt to submit form</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Validation errors displayed for required fields, form submission prevented</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">TC-CM-003: View Case List</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Multiple cases exist in system</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Cases list</li>
                      <li>Verify all cases displayed</li>
                      <li>Click column headers to sort</li>
                      <li>Use search input to filter</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Cases displayed in table format, sorting and filtering work correctly</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">TC-CM-004: Case Status Transition</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">Critical</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Case exists in "Pending Review" status</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Open case workspace</li>
                      <li>Click status workflow indicator</li>
                      <li>Select "Accept" action</li>
                      <li>Confirm transition</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Intake status changes to "Accepted", Operational status set to "Open", audit log entry created</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">TC-CM-005: Delete Case</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">Medium</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Case exists</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Open case</li>
                      <li>Click Delete button</li>
                      <li>Confirm deletion in dialog</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Case removed from active list (soft delete), case remains in database for audit purposes</td></tr>
                </tbody>
              </table>
            </section>

            {/* Deadline Management Tests */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">2. Deadline Management Tests</h2>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">TC-DL-001: Add Deadline to Case</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Case exists in "Open" status</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Open case workspace</li>
                      <li>Navigate to Deadlines tab</li>
                      <li>Click "Add Deadline"</li>
                      <li>Select deadline type (e.g., Response Due)</li>
                      <li>Enter due date</li>
                      <li>Save deadline</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Deadline added to case, appears in calendar, warning thresholds calculated</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">TC-DL-002: Apply Deadline from Library</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Deadline rules exist in library</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Open case workspace</li>
                      <li>Click "Add from Library"</li>
                      <li>Navigate to Deadline Rules tab</li>
                      <li>Select applicable rule</li>
                      <li>Click "Apply to Case"</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Deadline created with pre-configured values from library item, library reference recorded</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">TC-DL-003: Deadline Warning Display</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Deadline exists due in 7 days</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>View dashboard</li>
                      <li>Check upcoming deadlines widget</li>
                      <li>Open case with deadline</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Deadline shows warning indicator, appears in dashboard widget</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">TC-DL-004: Mark Deadline Complete</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Active deadline exists on case</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to deadline in case workspace</li>
                      <li>Click "Mark Complete"</li>
                      <li>Enter completion date</li>
                      <li>Save</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Deadline status changes to "Complete", removed from active warnings</td></tr>
                </tbody>
              </table>
            </section>

            {/* Actions & Remedies Tests */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">3. Actions & Remedies Tests</h2>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">TC-AR-001: Add Action to Case</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Case in operational status</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Open case workspace</li>
                      <li>Navigate to Actions tab</li>
                      <li>Click "Add Action"</li>
                      <li>Select action type (e.g., Civil Money Penalty)</li>
                      <li>Enter amount if financial</li>
                      <li>Enter due date</li>
                      <li>Save action</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Action added to case, associated deadline created if applicable</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">TC-AR-002: Apply Remedy from Library</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Remedy library items exist</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Open case workspace</li>
                      <li>Click "Add from Library"</li>
                      <li>Select Remedies tab</li>
                      <li>Choose appropriate remedy</li>
                      <li>Click "Apply to Case"</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Action created with library values, evidence requirements added, library reference recorded</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">TC-AR-003: Financial Action Tracking</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Financial action exists on case</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Open action details</li>
                      <li>Record partial payment</li>
                      <li>Verify amount due updated</li>
                      <li>Record final payment</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Payment history tracked, amount due calculated correctly, status updates when fully paid</td></tr>
                </tbody>
              </table>
            </section>

            {/* Correspondence Tests */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">4. Correspondence Tests</h2>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">TC-CO-001: Log Inbound Correspondence</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Case exists</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Open case workspace</li>
                      <li>Navigate to Correspondence tab</li>
                      <li>Click "Add Correspondence"</li>
                      <li>Select Direction: Inbound</li>
                      <li>Select Document Type</li>
                      <li>Enter received date</li>
                      <li>Upload attachment</li>
                      <li>Save</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Correspondence logged with attachment, appears in timeline</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">TC-CO-002: Create Outbound Response</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Response template exists in library</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Open case workspace</li>
                      <li>Click "Create Response"</li>
                      <li>Select template from library</li>
                      <li>Complete required sections</li>
                      <li>Attach required documents</li>
                      <li>Submit for review or send</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Response package created, checklist validated, correspondence logged</td></tr>
                </tbody>
              </table>
            </section>

            {/* Library Tests */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">5. Library Management Tests</h2>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">TC-LB-001: Create Library Item</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">User has admin permissions</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Admin Config → Library tab</li>
                      <li>Click "Add Remedy" (or other item type)</li>
                      <li>Enter name and description</li>
                      <li>Configure applicable settings</li>
                      <li>Set status to Draft</li>
                      <li>Save</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Library item created in Draft status, not available in case pickers until published</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">TC-LB-002: Publish Library Item</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Draft library item exists</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Edit library item</li>
                      <li>Change status to Published</li>
                      <li>Save</li>
                      <li>Open case and click "Add from Library"</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Item now appears in library picker, available for application to cases</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">TC-LB-003: Library Recommendations</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">Medium</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Library items configured with regulatory body/case type applicability</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Open case with specific regulatory body and case type</li>
                      <li>Click "Add from Library"</li>
                      <li>View "Recommended" section</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Items matching case regulatory body and case type appear in recommendations</td></tr>
                </tbody>
              </table>
            </section>

            {/* Admin Configuration Tests */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">6. Admin Configuration Tests</h2>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">TC-AC-001: Add Regulatory Body</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">High</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">User has admin access</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Admin Config → Regulatory Bodies</li>
                      <li>Click "Add Body"</li>
                      <li>Enter name, abbreviation, level</li>
                      <li>Enter contact information</li>
                      <li>Save</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Regulatory body created, available in case creation dropdown</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">TC-AC-002: Configure Escalation Rule</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">Medium</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">User has admin access</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Admin Config → Escalation</li>
                      <li>Click "Add Rule"</li>
                      <li>Enter rule name and trigger days</li>
                      <li>Select recipients</li>
                      <li>Save</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Escalation rule created, applied to deadline notifications</td></tr>
                </tbody>
              </table>
            </section>

            {/* Calendar & Reporting Tests */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">7. Calendar & Reporting Tests</h2>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">TC-CR-001: View Calendar</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">Medium</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Deadlines exist on multiple cases</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Calendar</li>
                      <li>Verify deadlines displayed</li>
                      <li>Click deadline to view details</li>
                      <li>Navigate between months</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">All deadlines visible, clickable to navigate to case</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">TC-CR-002: Dashboard Statistics</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-32">Priority</td><td className="border p-2">Medium</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Preconditions</td><td className="border p-2">Cases exist in various statuses</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Test Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Dashboard</li>
                      <li>Verify stats cards show correct counts</li>
                      <li>Click stat card to filter cases</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected Result</td><td className="border p-2">Statistics accurate, clickable to navigate to filtered view</td></tr>
                </tbody>
              </table>
            </section>

            {/* Test Summary */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">8. Test Summary</h2>
              <table className="w-full border-collapse border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Category</th>
                    <th className="border p-2 text-left">Total Tests</th>
                    <th className="border p-2 text-left">Critical</th>
                    <th className="border p-2 text-left">High</th>
                    <th className="border p-2 text-left">Medium</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border p-2">Case Management</td><td className="border p-2">5</td><td className="border p-2">1</td><td className="border p-2">3</td><td className="border p-2">1</td></tr>
                  <tr><td className="border p-2">Deadline Management</td><td className="border p-2">4</td><td className="border p-2">0</td><td className="border p-2">4</td><td className="border p-2">0</td></tr>
                  <tr><td className="border p-2">Actions & Remedies</td><td className="border p-2">3</td><td className="border p-2">0</td><td className="border p-2">3</td><td className="border p-2">0</td></tr>
                  <tr><td className="border p-2">Correspondence</td><td className="border p-2">2</td><td className="border p-2">0</td><td className="border p-2">2</td><td className="border p-2">0</td></tr>
                  <tr><td className="border p-2">Library Management</td><td className="border p-2">3</td><td className="border p-2">0</td><td className="border p-2">2</td><td className="border p-2">1</td></tr>
                  <tr><td className="border p-2">Admin Configuration</td><td className="border p-2">2</td><td className="border p-2">0</td><td className="border p-2">1</td><td className="border p-2">1</td></tr>
                  <tr><td className="border p-2">Calendar & Reporting</td><td className="border p-2">2</td><td className="border p-2">0</td><td className="border p-2">0</td><td className="border p-2">2</td></tr>
                  <tr className="bg-muted font-bold"><td className="border p-2">TOTAL</td><td className="border p-2">21</td><td className="border p-2">1</td><td className="border p-2">15</td><td className="border p-2">5</td></tr>
                </tbody>
              </table>
            </section>

            <div className="text-center text-sm text-muted-foreground mt-12 pt-8 border-t">
              <p>QA Test Cases maintained by EnforcePoint QA Team</p>
              <p>Last Updated: December 2024</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
