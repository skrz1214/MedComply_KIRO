import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Printer } from "lucide-react";

export default function UATTestCasesPage() {
  const handlePrint = () => {
    window.print();
  };

  return (
    <AppLayout breadcrumbs={[{ label: "Documentation" }, { label: "UAT Test Cases" }]}>
      <div className="space-y-6 print:space-y-4">
        {/* Header with Print Button */}
        <div className="flex items-center justify-between print:hidden">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">UAT Test Cases</h1>
            <p className="text-muted-foreground">EnforcePoint User Acceptance Testing Scenarios</p>
          </div>
          <Button onClick={handlePrint} className="gap-2">
            <Printer className="h-4 w-4" />
            Print / Save as PDF
          </Button>
        </div>

        {/* Document Content */}
        <Card className="print:shadow-none print:border-none">
          <CardContent className="prose prose-slate max-w-none p-8 print:p-0">
            {/* Title Page */}
            <div className="text-center mb-12 print:mb-8">
              <h1 className="text-4xl font-bold mb-4">EnforcePoint</h1>
              <h2 className="text-2xl text-muted-foreground mb-6">User Acceptance Test Cases</h2>
              <div className="flex justify-center gap-4 mb-4">
                <Badge variant="outline">Version 2.0</Badge>
                <Badge variant="outline">December 2024</Badge>
              </div>
              <p className="text-sm text-muted-foreground">Business User Validation Scenarios</p>
            </div>

            {/* Introduction */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">1. Introduction</h2>
              <p>
                This document contains User Acceptance Test (UAT) scenarios for EnforcePoint. These tests 
                are designed for business users to validate that the system meets operational requirements 
                and supports real-world compliance workflows.
              </p>
              <h3 className="text-lg font-semibold mt-4 mb-2">UAT Participants</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li><strong>Compliance Officers:</strong> Primary users managing enforcement cases</li>
                <li><strong>Compliance Managers:</strong> Supervisors overseeing case resolution</li>
                <li><strong>Administrative Staff:</strong> Data entry and document management</li>
                <li><strong>System Administrators:</strong> Configuration and setup</li>
              </ul>
              <h3 className="text-lg font-semibold mt-4 mb-2">Test Environment</h3>
              <p>
                All UAT tests should be performed in the staging environment with realistic test data.
                Users should log in with their assigned test credentials.
              </p>
            </section>

            {/* Scenario 1: New CMS Survey Case */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">2. Scenario: Process New CMS Survey Case</h2>
              <div className="bg-muted p-4 rounded-lg mb-4">
                <p><strong>User Role:</strong> Compliance Officer</p>
                <p><strong>Business Context:</strong> Your facility received a Statement of Deficiencies from CMS following a standard survey. You need to log the case, track deadlines, and prepare a Plan of Correction.</p>
              </div>

              <h3 className="text-lg font-semibold mt-6 mb-3">UAT-001: Create Survey Case</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-40">Objective</td><td className="border p-2">Create a new enforcement case for a CMS survey</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Cases → Create New Case</li>
                      <li>Select "Centers for Medicare & Medicaid Services (CMS)" as Regulatory Body</li>
                      <li>Select "Survey" as Case Type</li>
                      <li>Enter your facility name as Provider</li>
                      <li>Enter the date you received the Statement of Deficiencies</li>
                      <li>Enter the survey date</li>
                      <li>Set severity based on findings (use High for this test)</li>
                      <li>Assign yourself as owner</li>
                      <li>Complete case creation</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected</td><td className="border p-2">Case created with unique case number, appears in your cases list</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Pass/Fail</td><td className="border p-2">☐ Pass &nbsp;&nbsp; ☐ Fail</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Notes</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">UAT-002: Add PoC Deadline</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-40">Objective</td><td className="border p-2">Add Plan of Correction deadline to case</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Open the case you just created</li>
                      <li>Navigate to Deadlines tab</li>
                      <li>Click "Add from Library"</li>
                      <li>Find and select the CMS PoC deadline rule</li>
                      <li>Verify the deadline calculates correctly (10 days from notice)</li>
                      <li>Apply to case</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected</td><td className="border p-2">Deadline appears with correct due date, warning indicators show when approaching</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Pass/Fail</td><td className="border p-2">☐ Pass &nbsp;&nbsp; ☐ Fail</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Notes</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">UAT-003: Log Statement of Deficiencies</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-40">Objective</td><td className="border p-2">Document the received Statement of Deficiencies</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Correspondence tab</li>
                      <li>Click "Add Correspondence"</li>
                      <li>Select Direction: Inbound</li>
                      <li>Select Type: Statement of Deficiencies</li>
                      <li>Enter the date received</li>
                      <li>Add notes about key findings</li>
                      <li>Upload the SOD document (use a test PDF)</li>
                      <li>Save</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected</td><td className="border p-2">Correspondence logged, document accessible, appears in case timeline</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Pass/Fail</td><td className="border p-2">☐ Pass &nbsp;&nbsp; ☐ Fail</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Notes</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">UAT-004: Create Plan of Correction Response</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-40">Objective</td><td className="border p-2">Create and submit PoC response using template</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Correspondence tab</li>
                      <li>Click "Add Correspondence"</li>
                      <li>Select Direction: Outbound</li>
                      <li>Click "Add from Library" and select PoC template</li>
                      <li>Verify required sections are listed</li>
                      <li>Add notes for each required section</li>
                      <li>Save as draft first</li>
                      <li>Then mark as sent</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected</td><td className="border p-2">Response created with template guidance, status trackable, appears in correspondence list</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Pass/Fail</td><td className="border p-2">☐ Pass &nbsp;&nbsp; ☐ Fail</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Notes</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>
            </section>

            {/* Scenario 2: CMP Case with Appeal */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">3. Scenario: Manage CMP with Appeal</h2>
              <div className="bg-muted p-4 rounded-lg mb-4">
                <p><strong>User Role:</strong> Compliance Manager</p>
                <p><strong>Business Context:</strong> Your facility received a Civil Money Penalty. You need to log the financial action, track the payment deadline, and file an appeal to contest the penalty amount.</p>
              </div>

              <h3 className="text-lg font-semibold mt-6 mb-3">UAT-005: Create CMP Case</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-40">Objective</td><td className="border p-2">Create enforcement case for Civil Money Penalty</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Create new case with Case Type: CMP</li>
                      <li>Set severity: Critical</li>
                      <li>Enter notice received date</li>
                      <li>Complete case creation</li>
                      <li>Accept case into operational status</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected</td><td className="border p-2">Case created and moved to operational status</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Pass/Fail</td><td className="border p-2">☐ Pass &nbsp;&nbsp; ☐ Fail</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Notes</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">UAT-006: Add Financial Penalty Action</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-40">Objective</td><td className="border p-2">Record the CMP financial action</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Actions tab</li>
                      <li>Click "Add Action"</li>
                      <li>Select Type: Civil Money Penalty</li>
                      <li>Enter amount: $50,000</li>
                      <li>Enter payment due date (60 days from notice)</li>
                      <li>Save action</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected</td><td className="border p-2">Action created with financial tracking, payment deadline added automatically</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Pass/Fail</td><td className="border p-2">☐ Pass &nbsp;&nbsp; ☐ Fail</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Notes</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">UAT-007: File Appeal</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-40">Objective</td><td className="border p-2">File IDR appeal for the CMP</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to case overview</li>
                      <li>Change case status to "Under Appeal"</li>
                      <li>Navigate to Appeals tab (or section)</li>
                      <li>Click "File Appeal"</li>
                      <li>Select Type: Informal Dispute Resolution</li>
                      <li>Enter filing date</li>
                      <li>Enter grounds for appeal</li>
                      <li>Save appeal</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected</td><td className="border p-2">Appeal created, case status reflects appeal, appeal deadline tracked</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Pass/Fail</td><td className="border p-2">☐ Pass &nbsp;&nbsp; ☐ Fail</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Notes</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">UAT-008: Record Appeal Outcome</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-40">Objective</td><td className="border p-2">Record partial appeal success</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Open the appeal</li>
                      <li>Update outcome: Partially Upheld</li>
                      <li>Enter adjusted amount: $35,000</li>
                      <li>Enter outcome date</li>
                      <li>Add notes about decision</li>
                      <li>Save</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected</td><td className="border p-2">Appeal outcome recorded, financial action amount updated, audit trail shows change</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Pass/Fail</td><td className="border p-2">☐ Pass &nbsp;&nbsp; ☐ Fail</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Notes</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>
            </section>

            {/* Scenario 3: Dashboard and Reporting */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">4. Scenario: Monitor Compliance Status</h2>
              <div className="bg-muted p-4 rounded-lg mb-4">
                <p><strong>User Role:</strong> Compliance Manager</p>
                <p><strong>Business Context:</strong> You need to monitor all active enforcement cases, track upcoming deadlines, and ensure nothing falls through the cracks.</p>
              </div>

              <h3 className="text-lg font-semibold mt-6 mb-3">UAT-009: Review Dashboard</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-40">Objective</td><td className="border p-2">Verify dashboard provides accurate overview</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Dashboard</li>
                      <li>Review active cases count</li>
                      <li>Review cases by severity breakdown</li>
                      <li>Review upcoming deadlines count</li>
                      <li>Review overdue items count</li>
                      <li>Click on a stat card to see details</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected</td><td className="border p-2">Statistics match actual case counts, navigation works correctly</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Pass/Fail</td><td className="border p-2">☐ Pass &nbsp;&nbsp; ☐ Fail</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Notes</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">UAT-010: Check Calendar View</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-40">Objective</td><td className="border p-2">Verify calendar shows all deadlines</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Calendar</li>
                      <li>Verify deadlines from your cases appear</li>
                      <li>Navigate to different months</li>
                      <li>Click on a deadline to view details</li>
                      <li>Verify you can navigate to the associated case</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected</td><td className="border p-2">All deadlines visible, color-coded by urgency, clickable to case</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Pass/Fail</td><td className="border p-2">☐ Pass &nbsp;&nbsp; ☐ Fail</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Notes</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">UAT-011: Filter Cases</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-40">Objective</td><td className="border p-2">Filter cases by various criteria</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Cases list</li>
                      <li>Filter by Regulatory Body</li>
                      <li>Filter by Status</li>
                      <li>Filter by Severity</li>
                      <li>Use search to find specific case</li>
                      <li>Clear filters</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected</td><td className="border p-2">Filters work correctly, combine properly, clear completely</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Pass/Fail</td><td className="border p-2">☐ Pass &nbsp;&nbsp; ☐ Fail</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Notes</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>
            </section>

            {/* Scenario 4: Admin Configuration */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">5. Scenario: System Configuration</h2>
              <div className="bg-muted p-4 rounded-lg mb-4">
                <p><strong>User Role:</strong> System Administrator</p>
                <p><strong>Business Context:</strong> You need to add a new state regulatory body and configure associated deadline rules.</p>
              </div>

              <h3 className="text-lg font-semibold mt-6 mb-3">UAT-012: Add Regulatory Body</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-40">Objective</td><td className="border p-2">Add new state health department</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Admin Configuration</li>
                      <li>Select Regulatory Bodies tab</li>
                      <li>Click "Add Body"</li>
                      <li>Enter name: "State Health Department - Test"</li>
                      <li>Enter abbreviation: "SHDTEST"</li>
                      <li>Select Level: State</li>
                      <li>Enter contact information</li>
                      <li>Save</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected</td><td className="border p-2">Regulatory body created, appears in case creation dropdown</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Pass/Fail</td><td className="border p-2">☐ Pass &nbsp;&nbsp; ☐ Fail</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Notes</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">UAT-013: Create Library Remedy Item</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-40">Objective</td><td className="border p-2">Add new remedy to library</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Admin Configuration → Library tab</li>
                      <li>Click "Add Remedy"</li>
                      <li>Enter name: "Test Monitoring Requirement"</li>
                      <li>Enter description</li>
                      <li>Set default due days: 90</li>
                      <li>Set status: Published</li>
                      <li>Save</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected</td><td className="border p-2">Remedy created, appears in library picker when applying to cases</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Pass/Fail</td><td className="border p-2">☐ Pass &nbsp;&nbsp; ☐ Fail</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Notes</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">UAT-014: Configure Response Template</h3>
              <table className="w-full border-collapse border text-sm mb-6">
                <tbody>
                  <tr><td className="border p-2 bg-muted font-medium w-40">Objective</td><td className="border p-2">Create response template with required sections</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Steps</td><td className="border p-2">
                    <ol className="list-decimal pl-4 space-y-1">
                      <li>Navigate to Admin Configuration → Library tab</li>
                      <li>Scroll to Response Templates</li>
                      <li>Click "Add Template"</li>
                      <li>Enter template name</li>
                      <li>Select applicable regulatory body</li>
                      <li>Add required sections (one per line)</li>
                      <li>Add required attachments (one per line)</li>
                      <li>Set status: Published</li>
                      <li>Save</li>
                    </ol>
                  </td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Expected</td><td className="border p-2">Template created with all sections, available for use in correspondence</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Pass/Fail</td><td className="border p-2">☐ Pass &nbsp;&nbsp; ☐ Fail</td></tr>
                  <tr><td className="border p-2 bg-muted font-medium">Notes</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>
            </section>

            {/* Sign-off Section */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">6. UAT Sign-Off</h2>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">Test Summary</h3>
              <table className="w-full border-collapse border mb-6">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Scenario</th>
                    <th className="border p-2 text-left">Tests</th>
                    <th className="border p-2 text-left">Passed</th>
                    <th className="border p-2 text-left">Failed</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border p-2">CMS Survey Case</td><td className="border p-2">4</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td></tr>
                  <tr><td className="border p-2">CMP with Appeal</td><td className="border p-2">4</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td></tr>
                  <tr><td className="border p-2">Compliance Monitoring</td><td className="border p-2">3</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td></tr>
                  <tr><td className="border p-2">System Configuration</td><td className="border p-2">3</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td></tr>
                  <tr className="bg-muted font-bold"><td className="border p-2">TOTAL</td><td className="border p-2">14</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>

              <h3 className="text-lg font-semibold mt-6 mb-3">Approval Signatures</h3>
              <table className="w-full border-collapse border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Role</th>
                    <th className="border p-2 text-left">Name</th>
                    <th className="border p-2 text-left">Signature</th>
                    <th className="border p-2 text-left">Date</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border p-2">Compliance Officer</td><td className="border p-2 h-8">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td></tr>
                  <tr><td className="border p-2">Compliance Manager</td><td className="border p-2 h-8">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td></tr>
                  <tr><td className="border p-2">System Administrator</td><td className="border p-2 h-8">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td></tr>
                  <tr><td className="border p-2">Project Sponsor</td><td className="border p-2 h-8">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>
            </section>

            {/* Issues Log */}
            <section className="mb-10">
              <h2 className="text-2xl font-bold border-b pb-2 mb-4">7. Issues Log</h2>
              <table className="w-full border-collapse border">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Issue #</th>
                    <th className="border p-2 text-left">Test ID</th>
                    <th className="border p-2 text-left">Description</th>
                    <th className="border p-2 text-left">Severity</th>
                    <th className="border p-2 text-left">Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="border p-2 h-8">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td></tr>
                  <tr><td className="border p-2 h-8">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td></tr>
                  <tr><td className="border p-2 h-8">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td></tr>
                  <tr><td className="border p-2 h-8">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td></tr>
                  <tr><td className="border p-2 h-8">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td><td className="border p-2">&nbsp;</td></tr>
                </tbody>
              </table>
            </section>

            <div className="text-center text-sm text-muted-foreground mt-12 pt-8 border-t">
              <p>UAT Test Cases maintained by EnforcePoint Project Team</p>
              <p>Last Updated: December 2024</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
