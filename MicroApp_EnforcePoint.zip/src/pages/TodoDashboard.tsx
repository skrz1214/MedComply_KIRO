import { useNavigate } from 'react-router-dom';
import { useEnforcement } from '@/context/EnforcementContext';
import { Header } from '@/components/layout/Header';
import { TodoCard } from '@/components/enforcement/TodoCard';
import { Button } from '@/components/ui/button';
import { CheckCircle, Inbox, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

const TodoDashboard = () => {
  const { todoItems } = useEnforcement();
  const navigate = useNavigate();

  const unprocessedTodos = todoItems.filter(t => !t.isProcessed);
  const processedTodos = todoItems.filter(t => t.isProcessed);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8 md:px-6">
        <div className="flex items-center gap-4 mb-6">
          <Link to="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground mb-1">
              To Do Dashboard
            </h1>
            <p className="text-muted-foreground">
              ComplianceConnect tickets requiring enforcement actions.
            </p>
          </div>
        </div>

        <div className="space-y-8">
          {/* Pending Items */}
          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <Inbox className="h-5 w-5 text-warning" />
              <h2 className="text-xl font-semibold text-foreground">
                Pending Actions ({unprocessedTodos.length})
              </h2>
            </div>
            {unprocessedTodos.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2">
                {unprocessedTodos.map((todo) => (
                  <TodoCard
                    key={todo.id}
                    todo={todo}
                    onProcess={(todoId) => navigate(`/enforcements/new?todoId=${todoId}`)}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-success/5 rounded-lg border border-success/20">
                <CheckCircle className="h-12 w-12 text-success mx-auto mb-4" />
                <h3 className="font-semibold text-foreground mb-2">All Caught Up!</h3>
                <p className="text-sm text-muted-foreground">
                  No pending items from ComplianceConnect.
                </p>
              </div>
            )}
          </section>

          {/* Processed Items */}
          {processedTodos.length > 0 && (
            <section className="space-y-4">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-success" />
                <h2 className="text-xl font-semibold text-foreground">
                  Processed ({processedTodos.length})
                </h2>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                {processedTodos.map((todo) => (
                  <div key={todo.id} className="p-4 bg-muted/30 rounded-lg border border-border opacity-60">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="h-4 w-4 text-success" />
                      <span className="text-xs font-medium text-success">Processed</span>
                      <span className="text-xs text-muted-foreground">{todo.ticketId}</span>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {todo.ticketDescription}
                    </p>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      </main>
    </div>
  );
};

export default TodoDashboard;
