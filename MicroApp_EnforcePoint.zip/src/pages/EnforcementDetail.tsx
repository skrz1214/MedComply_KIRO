import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useEnforcement } from '@/context/EnforcementContext';
import { Header } from '@/components/layout/Header';
import { EnforcementView } from '@/components/enforcement/EnforcementView';
import { useEffect, useState } from 'react';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const EnforcementDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { getEnforcementById, deleteEnforcement } = useEnforcement();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  
  const enforcement = id ? getEnforcementById(id) : undefined;

  useEffect(() => {
    if (searchParams.get('action') === 'delete') {
      setShowDeleteDialog(true);
    }
  }, [searchParams]);

  if (!enforcement) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container px-4 py-8 md:px-6">
          <div className="text-center py-16">
            <h2 className="text-2xl font-semibold text-foreground mb-2">Enforcement Not Found</h2>
            <p className="text-muted-foreground mb-4">The enforcement you're looking for doesn't exist.</p>
            <button 
              onClick={() => navigate('/enforcements')}
              className="text-primary hover:underline"
            >
              Back to Enforcements
            </button>
          </div>
        </main>
      </div>
    );
  }

  const handleDelete = () => {
    deleteEnforcement(enforcement.id);
    navigate('/enforcements');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8 md:px-6">
        <EnforcementView
          enforcement={enforcement}
          onBack={() => navigate('/enforcements')}
          onEdit={() => navigate(`/enforcements/${enforcement.id}/edit`)}
          onDelete={() => setShowDeleteDialog(true)}
        />
      </main>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Enforcement?</AlertDialogTitle>
            <AlertDialogDescription>
              This will mark the enforcement as deleted. It will be removed from the active view but can still be accessed in the Deleted tab.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default EnforcementDetail;
