import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { AppLayout } from "@/components/layout/AppLayout";
import { useEnforcePoint } from "@/context/EnforcePointContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { TriggerSource, CaseType, ProviderType, CaseSeverity, ScopePrevalence } from "@/types/enforcepoint";
import { CrossLinkSelector } from "@/components/enforcement/CrossLinkSelector";

const STEPS = [
  { id: 1, title: "Basics", description: "Case information" },
  { id: 2, title: "Deadlines", description: "Response dates" },
  { id: 3, title: "Scope & Risk", description: "Severity assessment" },
  { id: 4, title: "Linkage", description: "Related records" },
  { id: 5, title: "Upload", description: "Attach notice" },
];

const CASE_TYPES: CaseType[] = [
  "Survey/Inspection",
  "Complaint Investigation",
  "Program Integrity/Fraud",
  "Privacy/Security",
  "Licensure",
  "Life Safety",
  "Other",
];

const PROVIDER_TYPES: ProviderType[] = [
  "Hospital",
  "Clinic",
  "SNF",
  "ALF",
  "Home Health",
  "Other",
];

const TRIGGER_SOURCES: TriggerSource[] = [
  "Survey",
  "Complaint",
  "Incident",
  "Audit",
  "Self-Disclosure",
  "Referral",
  "Other",
];

export default function CreateCaseWizard() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { addCase, regulatoryBodies } = useEnforcePoint();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    title: "",
    summary: "",
    regulatoryBodyId: "",
    caseType: "" as CaseType | "",
    providerType: "" as ProviderType | "",
    facility: "",
    department: "",
    triggerSource: "" as TriggerSource | "",
    noticeReceivedDate: "",
    responseDueDate: "",
    appealFilingDueDate: "",
    severity: "Medium" as CaseSeverity,
    immediateJeopardy: false,
    scopePrevalence: "" as ScopePrevalence | "",
    linkedIssueIds: [] as string[],
    linkedCapaIds: [] as string[],
    linkedCitationIds: [] as string[],
    linkedCitationCaseIds: [] as string[],
    linkedRiskIds: [] as string[],
    linkedFeedbackIds: [] as string[],
    linkedAuditIds: [] as string[],
  });

  const progress = (currentStep / STEPS.length) * 100;

  const handleInputChange = (field: string, value: string | boolean | string[]) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return formData.title && formData.regulatoryBodyId && formData.caseType && formData.noticeReceivedDate;
      case 2:
        return formData.responseDueDate;
      case 3:
        return formData.severity;
      default:
        return true;
    }
  };

  const handleNext = () => {
    if (currentStep < STEPS.length) {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const handleSubmit = () => {
    if (!formData.caseType || !formData.providerType || !formData.triggerSource) {
      toast({
        title: "Missing Required Fields",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    addCase({
      title: formData.title,
      summary: formData.summary,
      regulatoryBodyId: formData.regulatoryBodyId,
      caseType: formData.caseType as CaseType,
      providerType: (formData.providerType || "Other") as ProviderType,
      facility: formData.facility,
      department: formData.department,
      triggerSource: (formData.triggerSource || "Other") as TriggerSource,
      noticeReceivedDate: new Date(formData.noticeReceivedDate),
      responseDueDate: new Date(formData.responseDueDate),
      intakeStatus: 'I1_Notice_Logged',
      caseStatus: 'O0_Not_Started',
      status: "Notice Received",
      severity: formData.severity,
      immediateJeopardy: formData.immediateJeopardy,
      scopePrevalence: formData.scopePrevalence as ScopePrevalence || undefined,
      linkedIssueIds: formData.linkedIssueIds,
      linkedCapaIds: formData.linkedCapaIds,
      linkedCitationIds: formData.linkedCitationIds,
      linkedCitationCaseIds: formData.linkedCitationCaseIds,
      libraryReferences: [],
      appliedLibrarySnapshots: [],
      evidenceFiles: [],
      watchers: [],
      createdBy: "current-user",
    });
    toast({
      title: "Case Created",
      description: "The enforcement case has been created successfully.",
    });
    navigate("/enforcement/cases");
  };

  return (
    <AppLayout
      breadcrumbs={[
        { label: "Enforcement", href: "/enforcement" },
        { label: "Cases", href: "/enforcement/cases" },
        { label: "New Case" },
      ]}
    >
      <div className="max-w-3xl mx-auto space-y-6">
        {/* Progress Header */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold">Create Enforcement Case</h1>
            <span className="text-sm text-muted-foreground">
              Step {currentStep} of {STEPS.length}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
          <div className="flex justify-between">
            {STEPS.map((step) => (
              <div
                key={step.id}
                className={`flex flex-col items-center ${
                  step.id === currentStep
                    ? "text-primary"
                    : step.id < currentStep
                    ? "text-success"
                    : "text-muted-foreground"
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    step.id === currentStep
                      ? "bg-primary text-primary-foreground"
                      : step.id < currentStep
                      ? "bg-success text-success-foreground"
                      : "bg-muted"
                  }`}
                >
                  {step.id < currentStep ? <Check className="h-4 w-4" /> : step.id}
                </div>
                <span className="text-xs mt-1 hidden sm:block">{step.title}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Step Content */}
        <Card>
          <CardHeader>
            <CardTitle>{STEPS[currentStep - 1].title}</CardTitle>
            <CardDescription>{STEPS[currentStep - 1].description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {currentStep === 1 && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="title">Case Title *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => handleInputChange("title", e.target.value)}
                    placeholder="Enter case title"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="regulatoryBody">Regulatory Body *</Label>
                  <Select
                    value={formData.regulatoryBodyId}
                    onValueChange={(value) => handleInputChange("regulatoryBodyId", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select regulatory body" />
                    </SelectTrigger>
                    <SelectContent>
                      {regulatoryBodies.map((body) => (
                        <SelectItem key={body.id} value={body.id}>
                          {body.name} ({body.level})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="caseType">Case Type *</Label>
                    <Select
                      value={formData.caseType}
                      onValueChange={(value) => handleInputChange("caseType", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        {CASE_TYPES.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="providerType">Provider Type</Label>
                    <Select
                      value={formData.providerType}
                      onValueChange={(value) => handleInputChange("providerType", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select provider" />
                      </SelectTrigger>
                      <SelectContent>
                        {PROVIDER_TYPES.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="facility">Facility/Location</Label>
                    <Input
                      id="facility"
                      value={formData.facility}
                      onChange={(e) => handleInputChange("facility", e.target.value)}
                      placeholder="Enter facility"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="department">Department</Label>
                    <Input
                      id="department"
                      value={formData.department}
                      onChange={(e) => handleInputChange("department", e.target.value)}
                      placeholder="Enter department"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="noticeDate">Notice Received Date *</Label>
                  <Input
                    id="noticeDate"
                    type="date"
                    value={formData.noticeReceivedDate}
                    onChange={(e) => handleInputChange("noticeReceivedDate", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="triggerSource">Trigger/Event Source</Label>
                  <Select
                    value={formData.triggerSource}
                    onValueChange={(value) => handleInputChange("triggerSource", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select source" />
                    </SelectTrigger>
                    <SelectContent>
                      {TRIGGER_SOURCES.map((source) => (
                        <SelectItem key={source} value={source}>
                          {source}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}

            {currentStep === 2 && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="responseDue">Response Due Date *</Label>
                  <Input
                    id="responseDue"
                    type="date"
                    value={formData.responseDueDate}
                    onChange={(e) => handleInputChange("responseDueDate", e.target.value)}
                  />
                  <p className="text-sm text-muted-foreground">
                    Auto-suggested based on regulatory body rules when available
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="appealDue">Appeal Filing Due Date (Optional)</Label>
                  <Input
                    id="appealDue"
                    type="date"
                    value={formData.appealFilingDueDate}
                    onChange={(e) => handleInputChange("appealFilingDueDate", e.target.value)}
                  />
                </div>
              </>
            )}

            {currentStep === 3 && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="severity">Severity *</Label>
                  <Select
                    value={formData.severity}
                    onValueChange={(value) => handleInputChange("severity", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select severity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Low">Low</SelectItem>
                      <SelectItem value="Medium">Medium</SelectItem>
                      <SelectItem value="High">High</SelectItem>
                      <SelectItem value="Critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="immediateJeopardy"
                    checked={formData.immediateJeopardy}
                    onCheckedChange={(checked) =>
                      handleInputChange("immediateJeopardy", checked as boolean)
                    }
                  />
                  <Label htmlFor="immediateJeopardy">
                    Immediate Jeopardy (LTC/SNF context)
                  </Label>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="scope">Scope/Prevalence</Label>
                  <Select
                    value={formData.scopePrevalence}
                    onValueChange={(value) => handleInputChange("scopePrevalence", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select scope" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Isolated">Isolated</SelectItem>
                      <SelectItem value="Pattern">Pattern</SelectItem>
                      <SelectItem value="Widespread">Widespread</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="summary">Summary</Label>
                  <Textarea
                    id="summary"
                    value={formData.summary}
                    onChange={(e) => handleInputChange("summary", e.target.value)}
                    placeholder="Brief description of the enforcement matter"
                    rows={4}
                  />
                </div>
              </>
            )}

            {currentStep === 4 && (
              <>
                <p className="text-sm text-muted-foreground mb-4">
                  Link existing compliance records to this case. You can also create or link records later from the Case Workspace.
                </p>
                <CrossLinkSelector
                  selectedIssues={formData.linkedIssueIds}
                  selectedCapas={formData.linkedCapaIds}
                  selectedCitations={formData.linkedCitationIds}
                  selectedCitationCases={formData.linkedCitationCaseIds}
                  selectedRisks={formData.linkedRiskIds}
                  selectedFeedback={formData.linkedFeedbackIds}
                  selectedAudits={formData.linkedAuditIds}
                  onIssuesChange={(ids) => handleInputChange("linkedIssueIds", ids)}
                  onCapasChange={(ids) => handleInputChange("linkedCapaIds", ids)}
                  onCitationsChange={(ids) => handleInputChange("linkedCitationIds", ids)}
                  onCitationCasesChange={(ids) => handleInputChange("linkedCitationCaseIds", ids)}
                  onRisksChange={(ids) => handleInputChange("linkedRiskIds", ids)}
                  onFeedbackChange={(ids) => handleInputChange("linkedFeedbackIds", ids)}
                  onAuditsChange={(ids) => handleInputChange("linkedAuditIds", ids)}
                />
              </>
            )}

            {currentStep === 5 && (
              <>
                <div className="space-y-4">
                  <div 
                    className="border-2 border-dashed rounded-lg p-8 text-center cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => document.getElementById('file-upload')?.click()}
                  >
                    <input
                      id="file-upload"
                      type="file"
                      className="hidden"
                      accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          toast({
                            title: "File Selected",
                            description: `${file.name} ready to upload`,
                          });
                        }
                      }}
                    />
                    <div className="space-y-2">
                      <p className="text-sm font-medium">
                        Drag and drop notice/deficiency letter here
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Or click to browse files
                      </p>
                      <Button 
                        variant="outline" 
                        size="sm"
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          document.getElementById('file-upload')?.click();
                        }}
                      >
                        Browse Files
                      </Button>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Upload the original notice or deficiency letter. You can add more documents later.
                  </p>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={currentStep === 1}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => navigate("/enforcement/cases")}>
              Cancel
            </Button>
            {currentStep === STEPS.length ? (
              <Button onClick={handleSubmit}>
                <Check className="mr-2 h-4 w-4" />
                Create Case
              </Button>
            ) : (
              <Button onClick={handleNext} disabled={!canProceed()}>
                Next
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
