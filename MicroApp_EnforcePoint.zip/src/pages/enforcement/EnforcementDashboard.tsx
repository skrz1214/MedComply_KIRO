import { AppLayout } from "@/components/layout/AppLayout";
import { useEnforcePoint } from "@/context/EnforcePointContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  FolderOpen, 
  AlertTriangle, 
  Clock, 
  CheckCircle, 
  Plus,
  ArrowRight,
  Calendar,
  TrendingUp
} from "lucide-react";
import { Link } from "react-router-dom";
import { format, differenceInDays, isPast } from "date-fns";

export default function EnforcementDashboard() {
  const { cases, deadlines } = useEnforcePoint();

  const openCases = cases.filter(c => !['Closed', 'Draft'].includes(c.status));
  const criticalCases = cases.filter(c => c.severity === 'Critical' || c.immediateJeopardy);
  const overdueDeadlines = deadlines.filter(d => !d.isCompleted && isPast(new Date(d.dueDate)));
  const upcomingDeadlines = deadlines
    .filter(d => !d.isCompleted && !isPast(new Date(d.dueDate)))
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    .slice(0, 5);

  const recentCases = [...cases]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'Critical': return 'bg-destructive text-destructive-foreground';
      case 'High': return 'bg-warning text-warning-foreground';
      case 'Medium': return 'bg-info text-info-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Notice Received':
      case 'Triage & Assignment':
        return 'bg-warning/10 text-warning border-warning/20';
      case 'Response Planning':
      case 'Remediation Linked':
      case 'Response In Progress':
        return 'bg-info/10 text-info border-info/20';
      case 'Submitted / Awaiting Determination':
        return 'bg-accent/10 text-accent border-accent/20';
      case 'Remedies Active':
        return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'Closed':
        return 'bg-success/10 text-success border-success/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <AppLayout breadcrumbs={[{ label: "Enforcement" }]}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">EnforcePoint Dashboard</h1>
            <p className="text-muted-foreground">
              Monitor and manage regulatory enforcement cases
            </p>
          </div>
          <Button asChild>
            <Link to="/enforcement/cases/new">
              <Plus className="mr-2 h-4 w-4" />
              New Case
            </Link>
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Open Cases</CardTitle>
              <FolderOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{openCases.length}</div>
              <p className="text-xs text-muted-foreground">
                Active enforcement matters
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Critical/High Severity</CardTitle>
              <AlertTriangle className="h-4 w-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">{criticalCases.length}</div>
              <p className="text-xs text-muted-foreground">
                Require immediate attention
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Overdue Deadlines</CardTitle>
              <Clock className="h-4 w-4 text-warning" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-warning">{overdueDeadlines.length}</div>
              <p className="text-xs text-muted-foreground">
                Past due dates
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Closed This Month</CardTitle>
              <CheckCircle className="h-4 w-4 text-success" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success">
                {cases.filter(c => c.status === 'Closed').length}
              </div>
              <p className="text-xs text-muted-foreground">
                Successfully resolved
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Recent Cases */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Recent Cases
              </CardTitle>
              <CardDescription>Latest enforcement matters</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentCases.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No cases yet. Create your first case to get started.
                  </p>
                ) : (
                  recentCases.map((caseItem) => (
                    <Link
                      key={caseItem.id}
                      to={`/enforcement/cases/${caseItem.id}`}
                      className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{caseItem.title}</span>
                          <Badge className={getSeverityColor(caseItem.severity)} variant="secondary">
                            {caseItem.severity}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {caseItem.caseNumber} • {caseItem.caseType}
                        </p>
                      </div>
                      <Badge variant="outline" className={getStatusColor(caseItem.status)}>
                        {caseItem.status}
                      </Badge>
                    </Link>
                  ))
                )}
              </div>
              {recentCases.length > 0 && (
                <Button variant="ghost" className="w-full mt-4" asChild>
                  <Link to="/enforcement/cases">
                    View All Cases
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Upcoming Deadlines */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Upcoming Deadlines
              </CardTitle>
              <CardDescription>Response and action due dates</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingDeadlines.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No upcoming deadlines
                  </p>
                ) : (
                  upcomingDeadlines.map((deadline) => {
                    const daysUntil = differenceInDays(new Date(deadline.dueDate), new Date());
                    const isUrgent = daysUntil <= 7;
                    
                    return (
                      <div
                        key={deadline.id}
                        className="flex items-center justify-between p-3 rounded-lg border"
                      >
                        <div className="space-y-1">
                          <p className="font-medium">{deadline.title}</p>
                          <p className="text-sm text-muted-foreground">
                            {deadline.type}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className={`text-sm font-medium ${isUrgent ? 'text-destructive' : ''}`}>
                            {format(new Date(deadline.dueDate), 'MMM d, yyyy')}
                          </p>
                          <p className={`text-xs ${isUrgent ? 'text-destructive' : 'text-muted-foreground'}`}>
                            {daysUntil === 0 ? 'Due today' : `${daysUntil} days`}
                          </p>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
              <Button variant="ghost" className="w-full mt-4" asChild>
                <Link to="/enforcement/calendar">
                  View Calendar
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
