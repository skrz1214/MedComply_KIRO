import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useEnforcePoint } from "@/context/EnforcePointContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Search, 
  Download, 
  Mail, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Info,
  FileText,
  Paperclip,
  ExternalLink,
  Calendar
} from "lucide-react";
import { Link } from "react-router-dom";
import { format } from "date-fns";

export default function CorrespondencePage() {
  const { correspondence, cases } = useEnforcePoint();
  const [searchTerm, setSearchTerm] = useState("");
  const [docTypeFilter, setDocTypeFilter] = useState<string>("all");
  const [activeTab, setActiveTab] = useState<string>("all");

  const filteredCorrespondence = correspondence.filter((item) => {
    const matchesSearch = item.subject.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDocType = docTypeFilter === "all" || item.documentType === docTypeFilter;
    
    // Tab filtering
    let matchesTab = true;
    if (activeTab === "inbound") matchesTab = item.direction === "Inbound";
    if (activeTab === "outbound") matchesTab = item.direction === "Outbound";
    
    return matchesSearch && matchesDocType && matchesTab;
  });

  const getCaseInfo = (caseId: string) => {
    const caseItem = cases.find((c) => c.id === caseId);
    return {
      title: caseItem?.title || "Unknown Case",
      caseNumber: caseItem?.caseNumber || "N/A"
    };
  };

  const getDocTypeIcon = (docType: string) => {
    switch (docType) {
      case "Statement of Deficiencies":
      case "Demand Letter":
      case "Notice":
        return FileText;
      case "Plan of Correction":
      case "CAP Request":
        return FileText;
      default:
        return Mail;
    }
  };

  const docTypes = [
    "Notice",
    "Statement of Deficiencies",
    "Demand Letter",
    "CAP Request",
    "Plan of Correction",
    "Appeal Filing",
    "Settlement",
    "Payment Confirmation",
    "Revisit Results",
    "Other",
  ];

  const handleExportCSV = () => {
    const headers = ["Date", "Case Number", "Case", "Direction", "Type", "Subject", "Sender/Recipient"];
    const rows = filteredCorrespondence.map((item) => {
      const caseInfo = getCaseInfo(item.caseId);
      return [
        format(new Date(item.date), "yyyy-MM-dd"),
        caseInfo.caseNumber,
        caseInfo.title,
        item.direction,
        item.documentType,
        item.subject,
        item.senderRecipient || "",
      ];
    });
    
    const csv = [headers.join(","), ...rows.map((r) => r.map(v => `"${v}"`).join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `correspondence-${format(new Date(), "yyyy-MM-dd")}.csv`;
    anchor.click();
  };

  const inboundCount = correspondence.filter((c) => c.direction === "Inbound").length;
  const outboundCount = correspondence.filter((c) => c.direction === "Outbound").length;
  const withAttachments = correspondence.filter((c) => c.attachments && c.attachments.length > 0).length;

  return (
    <AppLayout breadcrumbs={[{ label: "Enforcement", href: "/enforcement" }, { label: "Correspondence" }]}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Correspondence</h1>
            <p className="text-muted-foreground">
              Portfolio-wide view of all regulatory communications
            </p>
          </div>
          <Button variant="outline" onClick={handleExportCSV}>
            <Download className="mr-2 h-4 w-4" />
            Export CSV
          </Button>
        </div>

        {/* Contextual Explainer */}
        <Alert className="border-primary/30 bg-primary/5">
          <Info className="h-4 w-4 text-primary" />
          <AlertDescription className="text-sm">
            <span className="font-medium">What is this page?</span> This tracks all formal communications 
            (notices, letters, submissions) with regulatory bodies across your caseload. 
            <span className="text-muted-foreground"> Inbound = received from regulators. Outbound = sent by your organization.</span>
          </AlertDescription>
        </Alert>

        {/* Stats with Click-to-Filter */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card className="cursor-pointer hover:border-primary/50 transition-colors" onClick={() => setActiveTab("all")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Items</CardTitle>
              <Mail className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{correspondence.length}</div>
              <p className="text-xs text-muted-foreground">All correspondence</p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:border-info/50 transition-colors" onClick={() => setActiveTab("inbound")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Inbound</CardTitle>
              <ArrowDownLeft className="h-4 w-4 text-info" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-info">{inboundCount}</div>
              <p className="text-xs text-muted-foreground">Received from regulators</p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:border-success/50 transition-colors" onClick={() => setActiveTab("outbound")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Outbound</CardTitle>
              <ArrowUpRight className="h-4 w-4 text-success" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success">{outboundCount}</div>
              <p className="text-xs text-muted-foreground">Sent to regulators</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">With Attachments</CardTitle>
              <Paperclip className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{withAttachments}</div>
              <p className="text-xs text-muted-foreground">Have linked documents</p>
            </CardContent>
          </Card>
        </div>

        {/* Tabs for Quick Filtering */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <div className="flex items-center justify-between">
            <TabsList>
              <TabsTrigger value="all" className="gap-2">
                All
                <Badge variant="secondary" className="ml-1">{correspondence.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="inbound" className="gap-2">
                <ArrowDownLeft className="h-3 w-3" />
                Inbound
                <Badge variant="outline" className="ml-1 bg-info/10 text-info border-info/20">{inboundCount}</Badge>
              </TabsTrigger>
              <TabsTrigger value="outbound" className="gap-2">
                <ArrowUpRight className="h-3 w-3" />
                Outbound
                <Badge variant="outline" className="ml-1 bg-success/10 text-success border-success/20">{outboundCount}</Badge>
              </TabsTrigger>
            </TabsList>

            {/* Search & Filters */}
            <div className="flex gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search correspondence..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 w-[200px]"
                />
              </div>
              <Select value={docTypeFilter} onValueChange={setDocTypeFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Document Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {docTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Correspondence List */}
          <TabsContent value={activeTab} className="mt-0">
            <Card>
              <CardHeader className="pb-3">
                <CardDescription>
                  {activeTab === "all" && "Showing all correspondence across all cases"}
                  {activeTab === "inbound" && "Notices, letters, and documents received from regulatory bodies"}
                  {activeTab === "outbound" && "Responses, submissions, and documents sent to regulatory bodies"}
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                {filteredCorrespondence.length === 0 ? (
                  <div className="py-12 text-center">
                    <div className="flex flex-col items-center gap-2 text-muted-foreground">
                      <Mail className="h-8 w-8 opacity-50" />
                      <p>No correspondence found matching your filters.</p>
                      <Button variant="link" onClick={() => { setSearchTerm(""); setDocTypeFilter("all"); setActiveTab("all"); }}>
                        Clear filters
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="divide-y">
                    {filteredCorrespondence.map((item) => {
                      const caseInfo = getCaseInfo(item.caseId);
                      const DocIcon = getDocTypeIcon(item.documentType);
                      
                      return (
                        <div key={item.id} className="p-4 hover:bg-muted/50 transition-colors group">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-4">
                              <div className={`p-2 rounded-lg ${item.direction === 'Inbound' ? 'bg-info/10' : 'bg-success/10'}`}>
                                {item.direction === "Inbound" ? (
                                  <ArrowDownLeft className="h-5 w-5 text-info" />
                                ) : (
                                  <ArrowUpRight className="h-5 w-5 text-success" />
                                )}
                              </div>
                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <span className="font-medium">{item.subject}</span>
                                  <Badge variant="outline">{item.documentType}</Badge>
                                  {item.attachments && item.attachments.length > 0 && (
                                    <Paperclip className="h-3 w-3 text-muted-foreground" />
                                  )}
                                </div>
                                <div className="flex items-center gap-3 text-sm">
                                  <span className="text-xs text-muted-foreground font-mono">{caseInfo.caseNumber}</span>
                                  <Link
                                    to={`/enforcement/cases/${item.caseId}`}
                                    className="text-primary hover:underline"
                                  >
                                    {caseInfo.title}
                                  </Link>
                                </div>
                                <p className="text-sm text-muted-foreground">
                                  {item.direction === "Inbound" ? "From" : "To"}: {item.senderRecipient}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              <div className="text-right">
                                <div className="flex items-center gap-1 text-sm font-medium">
                                  <Calendar className="h-3 w-3 text-muted-foreground" />
                                  {format(new Date(item.date), "MMM d, yyyy")}
                                </div>
                                <Badge
                                  variant="secondary"
                                  className={`mt-1 ${item.direction === "Inbound" ? "bg-info/10 text-info" : "bg-success/10 text-success"}`}
                                >
                                  {item.direction}
                                </Badge>
                              </div>
                              <Link to={`/enforcement/cases/${item.caseId}`}>
                                <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity">
                                  <ExternalLink className="h-4 w-4" />
                                </Button>
                              </Link>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
