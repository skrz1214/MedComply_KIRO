import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useEnforcePoint } from "@/context/EnforcePointContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Search, 
  Download, 
  DollarSign, 
  Scale, 
  Info, 
  CheckCircle2, 
  Clock, 
  AlertTriangle,
  Gavel,
  FileText,
  Shield,
  ExternalLink
} from "lucide-react";
import { Link } from "react-router-dom";
import { format } from "date-fns";

export default function ActionsPage() {
  const { actions, cases } = useEnforcePoint();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [activeTab, setActiveTab] = useState<string>("all");

  const filteredActions = actions.filter((action) => {
    const matchesSearch = action.actionTypeName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || action.status === statusFilter;
    const matchesCategory = categoryFilter === "all" || action.actionCategory === categoryFilter;
    
    // Tab filtering
    let matchesTab = true;
    if (activeTab === "active") matchesTab = action.status === "Active" || action.status === "Imposed";
    if (activeTab === "pending") matchesTab = action.status === "Proposed" || action.status === "Stayed";
    if (activeTab === "resolved") matchesTab = action.status === "Resolved";
    
    return matchesSearch && matchesStatus && matchesCategory && matchesTab;
  });

  const getCaseInfo = (caseId: string) => {
    const caseItem = cases.find((c) => c.id === caseId);
    return {
      title: caseItem?.title || "Unknown Case",
      caseNumber: caseItem?.caseNumber || "N/A"
    };
  };

  const getStatusInfo = (status: string) => {
    switch (status) {
      case "Proposed":
        return { color: "bg-muted text-muted-foreground", icon: Clock, description: "Awaiting approval" };
      case "Imposed":
        return { color: "bg-warning/10 text-warning border-warning/20", icon: Gavel, description: "Formally ordered" };
      case "Active":
        return { color: "bg-destructive/10 text-destructive border-destructive/20", icon: AlertTriangle, description: "Currently in effect" };
      case "Stayed":
        return { color: "bg-info/10 text-info border-info/20", icon: Clock, description: "Temporarily suspended" };
      case "Resolved":
        return { color: "bg-success/10 text-success border-success/20", icon: CheckCircle2, description: "Completed" };
      default:
        return { color: "bg-muted text-muted-foreground", icon: FileText, description: "" };
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Financial Penalty": return DollarSign;
      case "Operational Remedy": return FileText;
      case "Licensure/Restriction": return Shield;
      case "Monitoring/Reporting Requirement": return FileText;
      default: return Scale;
    }
  };

  // Stats
  const totalPenalties = actions
    .filter((a) => a.actionCategory === "Financial Penalty" && a.amount)
    .reduce((sum, a) => sum + (a.amount || 0), 0);

  const activeActions = actions.filter((a) => a.status === "Active" || a.status === "Imposed").length;
  const pendingActions = actions.filter((a) => a.status === "Proposed" || a.status === "Stayed").length;
  const resolvedActions = actions.filter((a) => a.status === "Resolved").length;

  const handleExportCSV = () => {
    const headers = ["Action ID", "Case Number", "Case", "Category", "Type", "Amount", "Status", "Start Date", "End Date"];
    const rows = filteredActions.map((a) => {
      const caseInfo = getCaseInfo(a.caseId);
      return [
        a.id,
        caseInfo.caseNumber,
        caseInfo.title,
        a.actionCategory,
        a.actionTypeName,
        a.amount ? `$${a.amount}` : "",
        a.status,
        a.startDate ? format(new Date(a.startDate), "yyyy-MM-dd") : "",
        a.endDate ? format(new Date(a.endDate), "yyyy-MM-dd") : "",
      ];
    });
    
    const csv = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `enforcement-actions-${format(new Date(), "yyyy-MM-dd")}.csv`;
    anchor.click();
  };

  return (
    <AppLayout breadcrumbs={[{ label: "Enforcement", href: "/enforcement" }, { label: "Actions & Remedies" }]}>
      <div className="space-y-6">
        {/* Header with Context */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Actions & Remedies</h1>
            <p className="text-muted-foreground">
              Portfolio-wide view of all enforcement actions across cases
            </p>
          </div>
          <Button variant="outline" onClick={handleExportCSV}>
            <Download className="mr-2 h-4 w-4" />
            Export CSV
          </Button>
        </div>

        {/* Contextual Explainer */}
        <Alert className="border-primary/30 bg-primary/5">
          <Info className="h-4 w-4 text-primary" />
          <AlertDescription className="text-sm">
            <span className="font-medium">What is this page?</span> This aggregates all enforcement actions 
            (penalties, remedies, restrictions) across your entire caseload. To manage actions for a specific case, 
            navigate to that case's workspace.
          </AlertDescription>
        </Alert>

        {/* Stats with Better Context */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card className="cursor-pointer hover:border-primary/50 transition-colors" onClick={() => setActiveTab("all")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Actions</CardTitle>
              <Scale className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{actions.length}</div>
              <p className="text-xs text-muted-foreground">All remedies tracked</p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:border-destructive/50 transition-colors" onClick={() => setActiveTab("active")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active / Imposed</CardTitle>
              <AlertTriangle className="h-4 w-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">{activeActions}</div>
              <p className="text-xs text-muted-foreground">Currently in effect</p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:border-warning/50 transition-colors" onClick={() => setActiveTab("pending")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending / Stayed</CardTitle>
              <Clock className="h-4 w-4 text-warning" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-warning">{pendingActions}</div>
              <p className="text-xs text-muted-foreground">Awaiting resolution</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Penalties</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalPenalties.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">Financial penalties assessed</p>
            </CardContent>
          </Card>
        </div>

        {/* Tabs for Quick Filtering */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <div className="flex items-center justify-between">
            <TabsList>
              <TabsTrigger value="all" className="gap-2">
                All
                <Badge variant="secondary" className="ml-1">{actions.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="active" className="gap-2">
                Active
                <Badge variant="destructive" className="ml-1">{activeActions}</Badge>
              </TabsTrigger>
              <TabsTrigger value="pending" className="gap-2">
                Pending
                <Badge variant="outline" className="ml-1">{pendingActions}</Badge>
              </TabsTrigger>
              <TabsTrigger value="resolved" className="gap-2">
                Resolved
                <Badge variant="secondary" className="ml-1">{resolvedActions}</Badge>
              </TabsTrigger>
            </TabsList>

            {/* Search & Filters */}
            <div className="flex gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search actions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 w-[200px]"
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Financial Penalty">Financial Penalty</SelectItem>
                  <SelectItem value="Operational Remedy">Operational Remedy</SelectItem>
                  <SelectItem value="Licensure/Restriction">Licensure/Restriction</SelectItem>
                  <SelectItem value="Monitoring/Reporting Requirement">Monitoring/Reporting</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Table Content */}
          <TabsContent value={activeTab} className="mt-0">
            <Card>
              <CardHeader className="pb-3">
                <CardDescription>
                  {activeTab === "all" && "Showing all enforcement actions across all cases"}
                  {activeTab === "active" && "Actions currently in effect that require ongoing monitoring"}
                  {activeTab === "pending" && "Actions awaiting approval, imposition, or currently stayed"}
                  {activeTab === "resolved" && "Completed actions that have been fully satisfied"}
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[60px]">Type</TableHead>
                      <TableHead>Action</TableHead>
                      <TableHead>Case</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Dates</TableHead>
                      <TableHead className="w-[50px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredActions.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center py-12">
                          <div className="flex flex-col items-center gap-2 text-muted-foreground">
                            <Scale className="h-8 w-8 opacity-50" />
                            <p>No actions found matching your filters.</p>
                            <Button variant="link" onClick={() => { setSearchTerm(""); setCategoryFilter("all"); setActiveTab("all"); }}>
                              Clear filters
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredActions.map((action) => {
                        const caseInfo = getCaseInfo(action.caseId);
                        const statusInfo = getStatusInfo(action.status);
                        const CategoryIcon = getCategoryIcon(action.actionCategory);
                        
                        return (
                          <TableRow key={action.id} className="group">
                            <TableCell>
                              <div className="flex items-center justify-center">
                                <CategoryIcon className="h-4 w-4 text-muted-foreground" />
                              </div>
                            </TableCell>
                            <TableCell className="font-medium">{action.actionTypeName}</TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                <span className="text-xs text-muted-foreground font-mono">{caseInfo.caseNumber}</span>
                                <Link
                                  to={`/enforcement/cases/${action.caseId}`}
                                  className="text-primary hover:underline text-sm"
                                >
                                  {caseInfo.title}
                                </Link>
                              </div>
                            </TableCell>
                            <TableCell className="text-sm">{action.actionCategory}</TableCell>
                            <TableCell className="text-right font-medium">
                              {action.amount ? `$${action.amount.toLocaleString()}` : "-"}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className={statusInfo.color}>
                                {action.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground">
                              {action.startDate && format(new Date(action.startDate), "MMM d, yyyy")}
                              {action.endDate && (
                                <span className="block text-xs">
                                  to {format(new Date(action.endDate), "MMM d, yyyy")}
                                </span>
                              )}
                            </TableCell>
                            <TableCell>
                              <Link to={`/enforcement/cases/${action.caseId}`}>
                                <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity">
                                  <ExternalLink className="h-4 w-4" />
                                </Button>
                              </Link>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
