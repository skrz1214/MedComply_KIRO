import { useState } from "react";
import { useEnforcePoint } from "@/context/EnforcePointContext";
import { AppLayout } from "@/components/layout/AppLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { 
  Search, 
  Plus, 
  Building2, 
  Scale, 
  Clock, 
  FileText, 
  FolderCheck, 
  Tags,
  Pencil,
  Trash2,
  CheckCircle,
  AlertCircle,
  ExternalLink,
} from "lucide-react";
import { toast } from "sonner";
import { 
  LibraryItemStatus, 
  RemedyLibraryItem, 
  DeadlineRuleLibraryItem, 
  ResponseTemplateLibraryItem,
  EvidenceRequirementLibraryItem,
  FindingCategoryLibraryItem,
} from "@/types/enforcepoint";
import { RemedyLibraryFormDialog } from "@/components/enforcement/RemedyLibraryFormDialog";
import { DeadlineRuleFormDialog } from "@/components/enforcement/DeadlineRuleFormDialog";
import { ResponseTemplateFormDialog } from "@/components/enforcement/ResponseTemplateFormDialog";
import { EvidenceRequirementFormDialog } from "@/components/enforcement/EvidenceRequirementFormDialog";
import { FindingCategoryFormDialog } from "@/components/enforcement/FindingCategoryFormDialog";

const getStatusBadge = (status: LibraryItemStatus) => {
  switch (status) {
    case 'Published':
      return <Badge className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" />Published</Badge>;
    case 'Draft':
      return <Badge variant="secondary"><Pencil className="h-3 w-3 mr-1" />Draft</Badge>;
    case 'Deprecated':
      return <Badge variant="outline" className="text-muted-foreground"><AlertCircle className="h-3 w-3 mr-1" />Deprecated</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

export default function EnforcementLibrary() {
  const { 
    regulatoryBodies,
    remedyLibraryItems,
    addRemedyLibraryItem,
    updateRemedyLibraryItem,
    deleteRemedyLibraryItem,
    deadlineRuleLibraryItems,
    addDeadlineRuleLibraryItem,
    updateDeadlineRuleLibraryItem,
    deleteDeadlineRuleLibraryItem,
    responseTemplateLibraryItems,
    addResponseTemplateLibraryItem,
    updateResponseTemplateLibraryItem,
    deleteResponseTemplateLibraryItem,
    evidenceRequirementLibraryItems,
    addEvidenceRequirementLibraryItem,
    updateEvidenceRequirementLibraryItem,
    deleteEvidenceRequirementLibraryItem,
    findingCategoryLibraryItems,
    addFindingCategoryLibraryItem,
    updateFindingCategoryLibraryItem,
    deleteFindingCategoryLibraryItem,
    currentUser,
  } = useEnforcePoint();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("remedies");
  
  // Dialog states
  const [remedyDialogOpen, setRemedyDialogOpen] = useState(false);
  const [editingRemedy, setEditingRemedy] = useState<RemedyLibraryItem | null>(null);
  
  const [deadlineDialogOpen, setDeadlineDialogOpen] = useState(false);
  const [editingDeadline, setEditingDeadline] = useState<DeadlineRuleLibraryItem | null>(null);
  
  const [templateDialogOpen, setTemplateDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<ResponseTemplateLibraryItem | null>(null);
  
  const [evidenceDialogOpen, setEvidenceDialogOpen] = useState(false);
  const [editingEvidence, setEditingEvidence] = useState<EvidenceRequirementLibraryItem | null>(null);
  
  const [categoryDialogOpen, setCategoryDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<FindingCategoryLibraryItem | null>(null);
  
  // Delete confirmation
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{ type: string; id: string; name: string } | null>(null);

  const canManageLibrary = currentUser.role === 'Admin' || currentUser.role === 'Compliance Head';

  const filteredRemedies = remedyLibraryItems.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredDeadlineRules = deadlineRuleLibraryItems.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredTemplates = responseTemplateLibraryItems.filter(item =>
    item.templateName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredEvidenceReqs = evidenceRequirementLibraryItems.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredCategories = findingCategoryLibraryItems.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getBodyName = (bodyId?: string) => {
    if (!bodyId) return 'All Bodies';
    const body = regulatoryBodies.find(b => b.id === bodyId);
    return body?.abbreviation || body?.name || bodyId;
  };

  // CRUD Handlers
  const handleSaveRemedy = (data: Omit<RemedyLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingRemedy) {
      updateRemedyLibraryItem(editingRemedy.id, data);
      toast.success("Remedy updated");
    } else {
      addRemedyLibraryItem(data);
      toast.success("Remedy added");
    }
    setEditingRemedy(null);
  };

  const handleSaveDeadline = (data: Omit<DeadlineRuleLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingDeadline) {
      updateDeadlineRuleLibraryItem(editingDeadline.id, data);
      toast.success("Deadline rule updated");
    } else {
      addDeadlineRuleLibraryItem(data);
      toast.success("Deadline rule added");
    }
    setEditingDeadline(null);
  };

  const handleSaveTemplate = (data: Omit<ResponseTemplateLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingTemplate) {
      updateResponseTemplateLibraryItem(editingTemplate.id, data);
      toast.success("Template updated");
    } else {
      addResponseTemplateLibraryItem(data);
      toast.success("Template added");
    }
    setEditingTemplate(null);
  };

  const handleSaveEvidence = (data: Omit<EvidenceRequirementLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingEvidence) {
      updateEvidenceRequirementLibraryItem(editingEvidence.id, data);
      toast.success("Evidence requirement updated");
    } else {
      addEvidenceRequirementLibraryItem(data);
      toast.success("Evidence requirement added");
    }
    setEditingEvidence(null);
  };

  const handleSaveCategory = (data: Omit<FindingCategoryLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingCategory) {
      updateFindingCategoryLibraryItem(editingCategory.id, data);
      toast.success("Finding category updated");
    } else {
      addFindingCategoryLibraryItem(data);
      toast.success("Finding category added");
    }
    setEditingCategory(null);
  };

  const confirmDelete = () => {
    if (!itemToDelete) return;
    
    switch (itemToDelete.type) {
      case 'remedy':
        deleteRemedyLibraryItem(itemToDelete.id);
        break;
      case 'deadline':
        deleteDeadlineRuleLibraryItem(itemToDelete.id);
        break;
      case 'template':
        deleteResponseTemplateLibraryItem(itemToDelete.id);
        break;
      case 'evidence':
        deleteEvidenceRequirementLibraryItem(itemToDelete.id);
        break;
      case 'category':
        deleteFindingCategoryLibraryItem(itemToDelete.id);
        break;
    }
    
    toast.success("Item deleted");
    setItemToDelete(null);
    setDeleteDialogOpen(false);
  };

  const openAddDialog = () => {
    switch (activeTab) {
      case 'remedies':
        setEditingRemedy(null);
        setRemedyDialogOpen(true);
        break;
      case 'deadlines':
        setEditingDeadline(null);
        setDeadlineDialogOpen(true);
        break;
      case 'templates':
        setEditingTemplate(null);
        setTemplateDialogOpen(true);
        break;
      case 'evidence':
        setEditingEvidence(null);
        setEvidenceDialogOpen(true);
        break;
      case 'categories':
        setEditingCategory(null);
        setCategoryDialogOpen(true);
        break;
    }
  };

  const getAddButtonLabel = () => {
    switch (activeTab) {
      case 'remedies': return 'Add Remedy';
      case 'deadlines': return 'Add Deadline Rule';
      case 'templates': return 'Add Template';
      case 'evidence': return 'Add Evidence Req';
      case 'categories': return 'Add Category';
      default: return 'Add Item';
    }
  };

  return (
    <AppLayout breadcrumbs={[{ label: "Enforcement", href: "/enforcement" }, { label: "Library" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Enforcement Library</h1>
            <p className="text-muted-foreground">
              Manage reusable enforcement items, templates, and requirements
            </p>
          </div>
          {canManageLibrary && activeTab !== 'bodies' && (
            <Button onClick={openAddDialog}>
              <Plus className="h-4 w-4 mr-2" />
              {getAddButtonLabel()}
            </Button>
          )}
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search library items..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Summary Cards */}
        <div className="grid gap-4 md:grid-cols-6">
          <Card className="cursor-pointer hover:bg-muted/50" onClick={() => setActiveTab("bodies")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Regulatory Bodies</CardTitle>
              <Building2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{regulatoryBodies.length}</div>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:bg-muted/50" onClick={() => setActiveTab("remedies")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Remedies</CardTitle>
              <Scale className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{remedyLibraryItems.filter(r => r.status === 'Published').length}</div>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:bg-muted/50" onClick={() => setActiveTab("deadlines")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Deadline Rules</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{deadlineRuleLibraryItems.filter(d => d.status === 'Published').length}</div>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:bg-muted/50" onClick={() => setActiveTab("templates")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Templates</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{responseTemplateLibraryItems.filter(t => t.status === 'Published').length}</div>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:bg-muted/50" onClick={() => setActiveTab("evidence")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Evidence Reqs</CardTitle>
              <FolderCheck className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{evidenceRequirementLibraryItems.filter(e => e.status === 'Published').length}</div>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:bg-muted/50" onClick={() => setActiveTab("categories")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Finding Categories</CardTitle>
              <Tags className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{findingCategoryLibraryItems.filter(f => f.status === 'Published').length}</div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="bodies">Regulatory Bodies</TabsTrigger>
            <TabsTrigger value="remedies">Remedies & Actions</TabsTrigger>
            <TabsTrigger value="deadlines">Deadline Rules</TabsTrigger>
            <TabsTrigger value="templates">Response Templates</TabsTrigger>
            <TabsTrigger value="evidence">Evidence Requirements</TabsTrigger>
            <TabsTrigger value="categories">Finding Categories</TabsTrigger>
          </TabsList>

          {/* Regulatory Bodies Tab */}
          <TabsContent value="bodies">
            <Card>
              <CardHeader>
                <CardTitle>Regulatory Bodies Directory</CardTitle>
                <CardDescription>
                  Manage regulatory bodies from the <a href="/enforcement/regulatory" className="text-primary underline">Regulatory Bodies page</a>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Level</TableHead>
                      <TableHead>Jurisdiction</TableHead>
                      <TableHead>Oversight Types</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {regulatoryBodies.map((body) => (
                      <TableRow key={body.id}>
                        <TableCell className="font-medium">
                          <div>
                            <div>{body.name}</div>
                            {body.abbreviation && <div className="text-xs text-muted-foreground">{body.abbreviation}</div>}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={body.level === 'Federal' ? 'default' : 'secondary'}>{body.level}</Badge>
                        </TableCell>
                        <TableCell>{body.jurisdiction || 'National'}</TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {body.oversightTypes.slice(0, 2).map((type, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">{type}</Badge>
                            ))}
                            {body.oversightTypes.length > 2 && (
                              <Badge variant="outline" className="text-xs">+{body.oversightTypes.length - 2}</Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          {body.isActive ? (
                            <Badge className="bg-green-500">Active</Badge>
                          ) : (
                            <Badge variant="outline">Inactive</Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Remedies & Actions Tab */}
          <TabsContent value="remedies">
            <Card>
              <CardHeader>
                <CardTitle>Enforcement Remedies & Actions</CardTitle>
                <CardDescription>Reusable remedy types with evidence expectations and requirements</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Level</TableHead>
                      <TableHead>Penalty Range</TableHead>
                      <TableHead>Reference</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRemedies.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          No remedies found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredRemedies.map((remedy) => (
                        <TableRow key={remedy.id}>
                          <TableCell className="font-medium">
                            <div>
                              <div className="flex items-center gap-2">
                                {remedy.name}
                                {remedy.isFinancial && <Badge variant="secondary" className="text-xs">Financial</Badge>}
                              </div>
                              <div className="text-xs text-muted-foreground line-clamp-1">{remedy.description}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {remedy.levelApplicability.map((level, idx) => (
                                <Badge key={idx} variant="outline" className="text-xs">{level}</Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            {(remedy.penaltyMin || remedy.penaltyMax) ? (
                              <div className="text-sm font-medium">
                                {remedy.penaltyMin && remedy.penaltyMax ? (
                                  <span>${remedy.penaltyMin.toLocaleString()} - ${remedy.penaltyMax.toLocaleString()}</span>
                                ) : remedy.penaltyMin ? (
                                  <span>From ${remedy.penaltyMin.toLocaleString()}</span>
                                ) : remedy.penaltyMax ? (
                                  <span>Up to ${remedy.penaltyMax.toLocaleString()}</span>
                                ) : null}
                              </div>
                            ) : (
                              <span className="text-muted-foreground">—</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {remedy.referenceUrl ? (
                              <a
                                href={remedy.referenceUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1 text-primary hover:underline text-sm"
                              >
                                <ExternalLink className="h-3 w-3" />
                                View
                              </a>
                            ) : (
                              <span className="text-muted-foreground">—</span>
                            )}
                          </TableCell>
                          <TableCell>{getStatusBadge(remedy.status)}</TableCell>
                          <TableCell className="text-right">
                            {canManageLibrary && (
                              <div className="flex justify-end gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => { setEditingRemedy(remedy); setRemedyDialogOpen(true); }}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => { setItemToDelete({ type: 'remedy', id: remedy.id, name: remedy.name }); setDeleteDialogOpen(true); }}
                                >
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Deadline Rules Tab */}
          <TabsContent value="deadlines">
            <Card>
              <CardHeader>
                <CardTitle>Deadline Rules</CardTitle>
                <CardDescription>Standard deadline calculations by regulatory body and case type</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Regulatory Body</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Due In Days</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredDeadlineRules.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          No deadline rules found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredDeadlineRules.map((rule) => (
                        <TableRow key={rule.id}>
                          <TableCell className="font-medium">{rule.name}</TableCell>
                          <TableCell>{getBodyName(rule.regulatoryBodyId)}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{rule.deadlineType}</Badge>
                          </TableCell>
                          <TableCell>{rule.defaultDueInDays} days</TableCell>
                          <TableCell>{getStatusBadge(rule.status)}</TableCell>
                          <TableCell className="text-right">
                            {canManageLibrary && (
                              <div className="flex justify-end gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => { setEditingDeadline(rule); setDeadlineDialogOpen(true); }}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => { setItemToDelete({ type: 'deadline', id: rule.id, name: rule.name }); setDeleteDialogOpen(true); }}
                                >
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Response Templates Tab */}
          <TabsContent value="templates">
            <Card>
              <CardHeader>
                <CardTitle>Response Templates</CardTitle>
                <CardDescription>Standard response package formats by regulatory body</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Template Name</TableHead>
                      <TableHead>Regulatory Body</TableHead>
                      <TableHead>Case Type</TableHead>
                      <TableHead>Sections</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTemplates.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          No templates found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredTemplates.map((template) => (
                        <TableRow key={template.id}>
                          <TableCell className="font-medium">{template.templateName}</TableCell>
                          <TableCell>{getBodyName(template.regulatoryBodyId)}</TableCell>
                          <TableCell>
                            {template.caseType ? (
                              <Badge variant="outline">{template.caseType}</Badge>
                            ) : (
                              <span className="text-muted-foreground">All Types</span>
                            )}
                          </TableCell>
                          <TableCell>{template.requiredSections.length}</TableCell>
                          <TableCell>{getStatusBadge(template.status)}</TableCell>
                          <TableCell className="text-right">
                            {canManageLibrary && (
                              <div className="flex justify-end gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => { setEditingTemplate(template); setTemplateDialogOpen(true); }}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => { setItemToDelete({ type: 'template', id: template.id, name: template.templateName }); setDeleteDialogOpen(true); }}
                                >
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Evidence Requirements Tab */}
          <TabsContent value="evidence">
            <Card>
              <CardHeader>
                <CardTitle>Evidence Requirements</CardTitle>
                <CardDescription>Standard evidence checklists by case type and remedy</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Case Type</TableHead>
                      <TableHead>Evidence Items</TableHead>
                      <TableHead>Required Items</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredEvidenceReqs.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          No evidence requirements found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredEvidenceReqs.map((evreq) => (
                        <TableRow key={evreq.id}>
                          <TableCell className="font-medium">{evreq.name}</TableCell>
                          <TableCell>
                            {evreq.caseType ? (
                              <Badge variant="outline">{evreq.caseType}</Badge>
                            ) : (
                              <span className="text-muted-foreground">All Types</span>
                            )}
                          </TableCell>
                          <TableCell>{evreq.evidenceChecklist.length}</TableCell>
                          <TableCell>{evreq.evidenceChecklist.filter(e => e.isRequired).length}</TableCell>
                          <TableCell>{getStatusBadge(evreq.status)}</TableCell>
                          <TableCell className="text-right">
                            {canManageLibrary && (
                              <div className="flex justify-end gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => { setEditingEvidence(evreq); setEvidenceDialogOpen(true); }}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => { setItemToDelete({ type: 'evidence', id: evreq.id, name: evreq.name }); setDeleteDialogOpen(true); }}
                                >
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Finding Categories Tab */}
          <TabsContent value="categories">
            <Card>
              <CardHeader>
                <CardTitle>Finding Categories</CardTitle>
                <CardDescription>Standard categories for deficiency findings</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Typical Citations</TableHead>
                      <TableHead>Case Types</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCategories.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          No finding categories found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredCategories.map((cat) => (
                        <TableRow key={cat.id}>
                          <TableCell className="font-medium">{cat.name}</TableCell>
                          <TableCell className="text-sm text-muted-foreground max-w-[200px] truncate">{cat.description}</TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {cat.typicalCitations?.slice(0, 3).map((cit, idx) => (
                                <Badge key={idx} variant="outline" className="text-xs">{cit}</Badge>
                              ))}
                              {(cat.typicalCitations?.length || 0) > 3 && (
                                <Badge variant="outline" className="text-xs">+{cat.typicalCitations!.length - 3}</Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {cat.applicableCaseTypes.slice(0, 2).map((type, idx) => (
                                <Badge key={idx} variant="secondary" className="text-xs">{type}</Badge>
                              ))}
                              {cat.applicableCaseTypes.length > 2 && (
                                <Badge variant="secondary" className="text-xs">+{cat.applicableCaseTypes.length - 2}</Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>{getStatusBadge(cat.status)}</TableCell>
                          <TableCell className="text-right">
                            {canManageLibrary && (
                              <div className="flex justify-end gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => { setEditingCategory(cat); setCategoryDialogOpen(true); }}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => { setItemToDelete({ type: 'category', id: cat.id, name: cat.name }); setDeleteDialogOpen(true); }}
                                >
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Form Dialogs */}
      <RemedyLibraryFormDialog
        open={remedyDialogOpen}
        onOpenChange={setRemedyDialogOpen}
        item={editingRemedy}
        onSave={handleSaveRemedy}
        currentUserName={currentUser.name}
      />

      <DeadlineRuleFormDialog
        open={deadlineDialogOpen}
        onOpenChange={setDeadlineDialogOpen}
        item={editingDeadline}
        onSave={handleSaveDeadline}
        regulatoryBodies={regulatoryBodies}
        currentUserName={currentUser.name}
      />

      <ResponseTemplateFormDialog
        open={templateDialogOpen}
        onOpenChange={setTemplateDialogOpen}
        item={editingTemplate}
        onSave={handleSaveTemplate}
        regulatoryBodies={regulatoryBodies}
        currentUserName={currentUser.name}
      />

      <EvidenceRequirementFormDialog
        open={evidenceDialogOpen}
        onOpenChange={setEvidenceDialogOpen}
        item={editingEvidence}
        onSave={handleSaveEvidence}
        currentUserName={currentUser.name}
      />

      <FindingCategoryFormDialog
        open={categoryDialogOpen}
        onOpenChange={setCategoryDialogOpen}
        item={editingCategory}
        onSave={handleSaveCategory}
        currentUserName={currentUser.name}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Library Item</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{itemToDelete?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}