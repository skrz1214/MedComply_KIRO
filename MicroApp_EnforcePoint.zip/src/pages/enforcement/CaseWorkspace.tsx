import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { AppLayout } from "@/components/layout/AppLayout";
import { useEnforcePoint } from "@/context/EnforcePointContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  AlertTriangle,
  Calendar,
  CheckCircle,
  Clock,
  FileText,
  Link as LinkIcon,
  Mail,
  Scale,
  Shield,
  Users,
  ArrowLeft,
  ArrowRight,
  Edit,
  History,
  BookOpen,
  UserPlus,
  Info,
  Gavel,
} from "lucide-react";
import { format, differenceInDays, isPast } from "date-fns";
import { CaseStatusWorkflow } from "@/components/enforcement/CaseStatusWorkflow";
import { CaseAssignmentDialog } from "@/components/enforcement/CaseAssignmentDialog";
import { LibraryPickerDialog } from "@/components/enforcement/LibraryPickerDialog";
import { LibraryReferencesTab } from "@/components/enforcement/LibraryReferencesTab";
import { CrossLinkDialog } from "@/components/enforcement/CrossLinkDialog";
import { AppealFormDialog } from "@/components/enforcement/AppealFormDialog";
import { CaseStatus, IntakeStatus, OperationalStatus, LibraryItemType, Appeal } from "@/types/enforcepoint";
import { toast } from "@/hooks/use-toast";

export default function CaseWorkspace() {
  const { caseId } = useParams<{ caseId: string }>();
  const { 
    cases, 
    regulatoryBodies, 
    findings, 
    correspondence, 
    deadlines, 
    actions,
    appeals,
    getFindingsByCase, 
    getCorrespondenceByCase, 
    getDeadlinesByCase, 
    getActionsByCase,
    getAppealsByCase,
    updateCaseStatus,
    getAuditLogByCase,
    updateCase,
    addLibraryReference,
    applyLibrarySnapshot,
    addAppeal,
    updateAppeal,
    currentUser,
  } = useEnforcePoint();

  const [assignmentAction, setAssignmentAction] = useState<'assign' | 'advance' | 'revert' | null>(null);
  const [showLibraryPicker, setShowLibraryPicker] = useState(false);
  const [libraryMode, setLibraryMode] = useState<'browse' | 'recommended'>('recommended');
  const [libraryFilterType, setLibraryFilterType] = useState<LibraryItemType | null>(null);
  const [showCrossLinkDialog, setShowCrossLinkDialog] = useState(false);
  const [showAppealDialog, setShowAppealDialog] = useState(false);
  const [editingAppeal, setEditingAppeal] = useState<Appeal | null>(null);
  const caseData = cases.find((c) => c.id === caseId);
  const regulatoryBody = regulatoryBodies.find((b) => b.id === caseData?.regulatoryBodyId);
  const caseFindings = caseId ? getFindingsByCase(caseId) : [];
  const caseCorrespondence = caseId ? getCorrespondenceByCase(caseId) : [];
  const caseDeadlines = caseId ? getDeadlinesByCase(caseId) : [];
  const caseActions = caseId ? getActionsByCase(caseId) : [];
  const caseAppeals = caseId ? getAppealsByCase(caseId) : [];
  const caseAuditLog = caseId ? getAuditLogByCase(caseId) : [];
  const isClosed = caseData?.caseStatus === 'O7_Closed';
  const hasActiveAppeal = caseAppeals.some((a) => a.outcome === 'Pending');

  const openLibraryForType = (type: LibraryItemType) => {
    setLibraryFilterType(type);
    setLibraryMode('browse');
    setShowLibraryPicker(true);
  };

  const handleStatusChange = (newStatus: CaseStatus, justification?: string) => {
    if (caseId) {
      updateCaseStatus(caseId, newStatus, justification);
    }
  };

  const handleAssignmentSave = (updates: any) => {
    if (caseId && updateCase) {
      updateCase(caseId, updates);
      toast({ title: "Case Updated", description: "Case assignment has been updated." });
    }
  };

  const handleCrossLinkSave = (updates: {
    linkedIssueIds: string[];
    linkedCapaIds: string[];
    linkedCitationIds: string[];
    linkedCitationCaseIds: string[];
  }) => {
    if (caseId && updateCase) {
      updateCase(caseId, updates);
      toast({ title: "Links Updated", description: "Cross-linked records have been updated." });
    }
  };

  const handleLibraryReference = (itemType: LibraryItemType, itemId: string, itemName: string, version: number, note?: string) => {
    if (caseId && addLibraryReference) {
      addLibraryReference(caseId, {
        id: `ref-${Date.now()}`,
        libraryItemType: itemType,
        libraryItemId: itemId,
        libraryItemVersion: version,
        libraryItemName: itemName,
        referencedBy: currentUser.name,
        note,
      });
      toast({ title: "Reference Added", description: `${itemName} has been referenced.` });
    }
  };

  const handleLibraryApply = (itemType: LibraryItemType, itemId: string, itemName: string, version: number, targetType: string) => {
    if (caseId && applyLibrarySnapshot) {
      applyLibrarySnapshot(caseId, {
        id: `snap-${Date.now()}`,
        libraryItemType: itemType,
        libraryItemId: itemId,
        libraryItemVersion: version,
        libraryItemName: itemName,
        snapshotPayload: { name: itemName },
        appliedBy: currentUser.name,
        appliedToTarget: targetType as any,
      });
      toast({ title: "Library Item Applied", description: `${itemName} has been applied to the case.` });
    }
  };

  const handleAppealSave = (appealData: Omit<Appeal, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingAppeal) {
      updateAppeal(editingAppeal.id, appealData);
      toast({ title: "Appeal Updated", description: "The appeal has been updated." });
    } else {
      addAppeal(appealData);
      toast({ title: "Appeal Filed", description: "A new appeal has been filed." });
    }
    setEditingAppeal(null);
  };

  if (!caseData) {
    return (
      <AppLayout breadcrumbs={[{ label: "Enforcement", href: "/enforcement" }, { label: "Cases", href: "/enforcement/cases" }, { label: "Not Found" }]}>
        <div className="flex flex-col items-center justify-center py-12">
          <h2 className="text-2xl font-bold">Case Not Found</h2>
          <p className="text-muted-foreground mt-2">The requested case could not be found.</p>
          <Button asChild className="mt-4">
            <Link to="/enforcement/cases">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Cases
            </Link>
          </Button>
        </div>
      </AppLayout>
    );
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "Critical": return "bg-destructive text-destructive-foreground";
      case "High": return "bg-warning text-warning-foreground";
      case "Medium": return "bg-info text-info-foreground";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Notice Received":
      case "Triage & Assignment":
        return "bg-warning/10 text-warning border-warning/20";
      case "Response Planning":
      case "Remediation Linked":
      case "Response In Progress":
        return "bg-info/10 text-info border-info/20";
      case "Submitted / Awaiting Determination":
        return "bg-accent/10 text-accent border-accent/20";
      case "Remedies Active":
        return "bg-destructive/10 text-destructive border-destructive/20";
      case "Closed":
        return "bg-success/10 text-success border-success/20";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const daysUntilDue = caseData.responseDueDate
    ? differenceInDays(new Date(caseData.responseDueDate), new Date())
    : null;
  const isOverdue = caseData.responseDueDate && isPast(new Date(caseData.responseDueDate));

  return (
    <AppLayout
      breadcrumbs={[
        { label: "Enforcement", href: "/enforcement" },
        { label: "Cases", href: "/enforcement/cases" },
        { label: caseData.caseNumber },
      ]}
    >
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1 min-w-0">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" asChild>
                <Link to="/enforcement/cases">
                  <ArrowLeft className="h-4 w-4" />
                </Link>
              </Button>
              <h1 className="text-2xl font-bold truncate">{caseData.title}</h1>
              <Badge className={getSeverityColor(caseData.severity)}>{caseData.severity}</Badge>
              {caseData.immediateJeopardy && (
                <Badge variant="destructive">Immediate Jeopardy</Badge>
              )}
              {hasActiveAppeal && (
                <Badge variant="outline" className="bg-warning/10 text-warning border-warning/30 gap-1">
                  <Gavel className="h-3 w-3" />
                  Appeal Active
                </Badge>
              )}
              <Badge variant="outline" className="whitespace-nowrap">
                Intake: {String(caseData.intakeStatus).replace(/_/g, ' ')}
              </Badge>
              <Badge variant="outline" className="whitespace-nowrap">
                Case: {String(caseData.caseStatus).replace(/_/g, ' ')}
              </Badge>
            </div>
            <p className="text-muted-foreground ml-12 truncate">
              {caseData.caseNumber} • {caseData.caseType} • {regulatoryBody?.name}
            </p>
          </div>
          <div className="flex flex-wrap justify-end gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setLibraryMode('recommended');
                setShowLibraryPicker(true);
              }}
            >
              <BookOpen className="mr-2 h-4 w-4" />
              Recommended
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setLibraryMode('browse');
                setShowLibraryPicker(true);
              }}
            >
              <BookOpen className="mr-2 h-4 w-4" />
              Browse Library
            </Button>
            <Button variant="outline" onClick={() => setAssignmentAction('assign')}
            >
              <UserPlus className="mr-2 h-4 w-4" />
              Assign
            </Button>
            <Button variant="outline" size="icon" onClick={() => setAssignmentAction('revert')} aria-label="Move to previous stage">
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={() => setAssignmentAction('advance')} aria-label="Move to next stage">
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* At Risk Banner */}
        {(isOverdue || (daysUntilDue !== null && daysUntilDue <= 7)) && (
          <div className={`p-4 rounded-lg flex items-center gap-3 ${isOverdue ? 'bg-destructive/10 border border-destructive/20' : 'bg-warning/10 border border-warning/20'}`}>
            <AlertTriangle className={`h-5 w-5 ${isOverdue ? 'text-destructive' : 'text-warning'}`} />
            <div>
              <p className={`font-medium ${isOverdue ? 'text-destructive' : 'text-warning'}`}>
                {isOverdue ? 'Response Overdue' : 'Response Due Soon'}
              </p>
              <p className="text-sm text-muted-foreground">
                {isOverdue
                  ? `Response was due ${format(new Date(caseData.responseDueDate!), 'MMM d, yyyy')}`
                  : `Response due in ${daysUntilDue} day${daysUntilDue !== 1 ? 's' : ''} (${format(new Date(caseData.responseDueDate!), 'MMM d, yyyy')})`
                }
              </p>
            </div>
          </div>
        )}

        {/* Case Lifecycle / Status Workflow */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Case Lifecycle</CardTitle>
          </CardHeader>
          <CardContent>
            <CaseStatusWorkflow 
              caseData={caseData} 
              onStatusChange={handleStatusChange}
            />
            <Separator className="my-4" />
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>Notice: {caseData.noticeReceivedDate ? format(new Date(caseData.noticeReceivedDate), 'MMM d, yyyy') : 'Not set'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>Due: {caseData.responseDueDate ? format(new Date(caseData.responseDueDate), 'MMM d, yyyy') : 'Not set'}</span>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-auto p-1 text-sm hover:bg-accent"
                  onClick={() => setAssignmentAction('assign')}
                >
                  <Users className="h-4 w-4 mr-1 text-muted-foreground" />
                  <span className="text-muted-foreground">Owner:</span>
                  <span className="ml-1 font-medium">{caseData.assignedOwnerName || 'Unassigned'}</span>
                  <Edit className="h-3 w-3 ml-1 text-muted-foreground" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-auto p-1 text-sm hover:bg-accent"
                  onClick={() => setAssignmentAction('assign')}
                >
                  <span className="text-muted-foreground">Dept:</span>
                  <span className="ml-1 font-medium">{caseData.department || caseData.assignedDepartment || 'Not set'}</span>
                  <Edit className="h-3 w-3 ml-1 text-muted-foreground" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Dual Lifecycle Position Callout */}
        <Alert className="border-primary/30 bg-primary/5">
          <Info className="h-4 w-4 text-primary" />
          <AlertDescription className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div>
                <span className="text-muted-foreground text-sm">Intake:</span>
                <Badge variant="outline" className="ml-2">
                  {caseData.intakeStatus === 'I0_Draft' && 'I0 - Draft'}
                  {caseData.intakeStatus === 'I1_Notice_Logged' && 'I1 - Notice Logged'}
                  {caseData.intakeStatus === 'I2_Triage_Assignment' && 'I2 - Triage & Assignment'}
                  {caseData.intakeStatus === 'I3_Ready_For_Management' && 'I3 - Ready for Management'}
                </Badge>
              </div>
              <ArrowRight className="h-4 w-4 text-muted-foreground" />
              <div>
                <span className="text-muted-foreground text-sm">Operations:</span>
                <Badge variant="outline" className="ml-2">
                  {caseData.caseStatus.replace(/_/g, ' ').replace(/^O\d\s/, '')}
                </Badge>
              </div>
            </div>
            {caseData.intakeStatus !== 'I3_Ready_For_Management' ? (
              <span className="text-xs text-muted-foreground italic">
                Complete intake to unlock operational stages
              </span>
            ) : caseData.caseStatus === 'O0_Not_Started' ? (
              <span className="text-xs text-primary font-medium">
                ✓ Intake complete — Ready to begin operational management
              </span>
            ) : null}
          </AlertDescription>
        </Alert>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content - Tabs */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="overview" className="space-y-4">
              <TabsList className="grid w-full grid-cols-8">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="findings">Findings ({caseFindings.length})</TabsTrigger>
                <TabsTrigger value="correspondence">Correspondence ({caseCorrespondence.length})</TabsTrigger>
                <TabsTrigger value="deadlines">Deadlines ({caseDeadlines.length})</TabsTrigger>
                <TabsTrigger value="remedies">Remedies ({caseActions.length})</TabsTrigger>
                <TabsTrigger value="appeals" className={hasActiveAppeal ? "text-warning" : ""}>
                  Appeals ({caseAppeals.length})
                  {hasActiveAppeal && <Gavel className="ml-1 h-3 w-3" />}
                </TabsTrigger>
                <TabsTrigger value="library">Library</TabsTrigger>
                <TabsTrigger value="history">History</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Case Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p>{caseData.summary || 'No summary provided.'}</p>
                    <Separator />
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Provider Type:</span>
                        <p className="font-medium">{caseData.providerType}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Facility:</span>
                        <p className="font-medium">{caseData.facility || 'Not specified'}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Department:</span>
                        <p className="font-medium">{caseData.department || 'Not specified'}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Trigger Source:</span>
                        <p className="font-medium">{caseData.triggerSource || 'Not specified'}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Recent Activity */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <History className="h-5 w-5" />
                      Recent Activity
                    </CardTitle>
                    <CardDescription>Latest updates on this case</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {caseAuditLog.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-4">
                        No activity recorded yet
                      </p>
                    ) : (
                      <div className="space-y-3">
                        {caseAuditLog.slice(0, 5).map((entry) => (
                          <div key={entry.id} className="flex items-start gap-3 text-sm">
                            <div className="w-2 h-2 rounded-full bg-primary mt-1.5 shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="font-medium">{entry.description}</p>
                              <p className="text-xs text-muted-foreground">
                                {entry.performedBy} • {format(new Date(entry.performedAt), 'MMM d, yyyy h:mm a')}
                              </p>
                              {entry.justification && (
                                <p className="text-xs text-muted-foreground italic mt-1">
                                  "{entry.justification}"
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                        {caseAuditLog.length > 5 && (
                          <p className="text-xs text-muted-foreground text-center pt-2">
                            + {caseAuditLog.length - 5} more entries in History tab
                          </p>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="findings" className="space-y-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Findings & Deficiencies</CardTitle>
                      <CardDescription>Documented findings for this case</CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" onClick={() => openLibraryForType('finding_category')}>
                        <BookOpen className="mr-2 h-4 w-4" />
                        Add from Library
                      </Button>
                      <Button>Add Finding</Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {caseFindings.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-8">
                        No findings documented yet.
                      </p>
                    ) : (
                      <div className="space-y-4">
                        {caseFindings.map((finding) => (
                          <div key={finding.id} className="p-4 border rounded-lg">
                            <div className="flex items-start justify-between">
                              <div>
                                <h4 className="font-medium">{finding.title}</h4>
                                <p className="text-sm text-muted-foreground mt-1">{finding.description}</p>
                              </div>
                              <Badge variant="outline">{finding.category}</Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="correspondence" className="space-y-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Correspondence</CardTitle>
                      <CardDescription>Notices, letters, and submissions</CardDescription>
                    </div>
                    <Button>Add Correspondence</Button>
                  </CardHeader>
                  <CardContent>
                    {caseCorrespondence.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-8">
                        No correspondence recorded yet.
                      </p>
                    ) : (
                      <div className="space-y-4">
                        {caseCorrespondence.map((item) => (
                          <div key={item.id} className="p-4 border rounded-lg">
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-3">
                                <Mail className={`h-5 w-5 ${item.direction === 'Inbound' ? 'text-info' : 'text-success'}`} />
                                <div>
                                  <h4 className="font-medium">{item.subject}</h4>
                                  <p className="text-sm text-muted-foreground">
                                    {item.documentType} • {item.direction} • {format(new Date(item.date), 'MMM d, yyyy')}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="deadlines" className="space-y-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Deadlines</CardTitle>
                      <CardDescription>Track all case deadlines</CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" onClick={() => openLibraryForType('deadline_rule')}>
                        <BookOpen className="mr-2 h-4 w-4" />
                        Add from Library
                      </Button>
                      <Button>Add Deadline</Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {caseDeadlines.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-8">
                        No deadlines set yet.
                      </p>
                    ) : (
                      <div className="space-y-4">
                        {caseDeadlines.map((deadline) => {
                          const isComplete = deadline.isCompleted;
                          const deadlineOverdue = !isComplete && isPast(new Date(deadline.dueDate));
                          
                          return (
                            <div key={deadline.id} className={`p-4 border rounded-lg ${deadlineOverdue ? 'border-destructive/50 bg-destructive/5' : ''}`}>
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  {isComplete ? (
                                    <CheckCircle className="h-5 w-5 text-success" />
                                  ) : (
                                    <Clock className={`h-5 w-5 ${deadlineOverdue ? 'text-destructive' : 'text-muted-foreground'}`} />
                                  )}
                                  <div>
                                    <h4 className="font-medium">{deadline.title}</h4>
                                    <p className="text-sm text-muted-foreground">{deadline.type}</p>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <p className={`font-medium ${deadlineOverdue ? 'text-destructive' : ''}`}>
                                    {format(new Date(deadline.dueDate), 'MMM d, yyyy')}
                                  </p>
                                  {isComplete && (
                                    <p className="text-sm text-success">Completed</p>
                                  )}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="remedies" className="space-y-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Remedies & Penalties</CardTitle>
                      <CardDescription>Track enforcement actions and penalties</CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" onClick={() => openLibraryForType('remedy')}>
                        <BookOpen className="mr-2 h-4 w-4" />
                        Add from Library
                      </Button>
                      <Button>Add Action</Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {caseActions.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-8">
                        No remedies or penalties recorded yet.
                      </p>
                    ) : (
                      <div className="space-y-4">
                        {caseActions.map((action) => (
                          <div key={action.id} className="p-4 border rounded-lg">
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-3">
                                <Scale className="h-5 w-5 text-muted-foreground" />
                                <div>
                                  <h4 className="font-medium">{action.actionTypeName}</h4>
                                  <p className="text-sm text-muted-foreground">{action.actionCategory}</p>
                                </div>
                              </div>
                              <div className="text-right">
                                {action.amount && (
                                  <p className="font-medium">${action.amount.toLocaleString()}</p>
                                )}
                                <Badge variant="outline">{action.status}</Badge>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="appeals" className="space-y-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Gavel className="h-5 w-5" />
                        Appeals & Disputes
                      </CardTitle>
                      <CardDescription>Formal disputes filed against findings or enforcement actions</CardDescription>
                    </div>
                    <Button onClick={() => {
                      setEditingAppeal(null);
                      setShowAppealDialog(true);
                    }}>
                      <Gavel className="mr-2 h-4 w-4" />
                      File Appeal
                    </Button>
                  </CardHeader>
                  <CardContent>
                    {caseAppeals.length === 0 ? (
                      <div className="text-center py-8">
                        <Gavel className="h-12 w-12 mx-auto text-muted-foreground/30 mb-4" />
                        <p className="text-muted-foreground">No appeals filed for this case.</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Appeals can be filed to contest findings, penalties, or enforcement actions.
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {caseAppeals.map((appeal) => (
                          <div key={appeal.id} className="p-4 border rounded-lg">
                            <div className="flex items-start justify-between">
                              <div className="space-y-2">
                                <div className="flex items-center gap-2">
                                  <Badge 
                                    variant="outline" 
                                    className={
                                      appeal.outcome === 'Pending' 
                                        ? 'bg-warning/10 text-warning border-warning/30' 
                                        : appeal.outcome === 'Won' || appeal.outcome === 'Settled'
                                        ? 'bg-success/10 text-success border-success/30'
                                        : appeal.outcome === 'Lost'
                                        ? 'bg-destructive/10 text-destructive border-destructive/30'
                                        : 'bg-muted'
                                    }
                                  >
                                    {appeal.outcome}
                                  </Badge>
                                  <Badge variant="outline">{appeal.appealLevel}</Badge>
                                </div>
                                <div className="text-sm space-y-1">
                                  {appeal.filedDate && (
                                    <p>
                                      <span className="text-muted-foreground">Filed:</span>{' '}
                                      {format(new Date(appeal.filedDate), 'MMM d, yyyy')}
                                    </p>
                                  )}
                                  {appeal.hearingDate && (
                                    <p>
                                      <span className="text-muted-foreground">Hearing:</span>{' '}
                                      {format(new Date(appeal.hearingDate), 'MMM d, yyyy')}
                                    </p>
                                  )}
                                  {appeal.counselRepresentative && (
                                    <p>
                                      <span className="text-muted-foreground">Counsel:</span>{' '}
                                      {appeal.counselRepresentative}
                                    </p>
                                  )}
                                </div>
                                {appeal.notes && (
                                  <p className="text-sm text-muted-foreground mt-2 p-2 bg-muted/50 rounded">
                                    {appeal.notes}
                                  </p>
                                )}
                              </div>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => {
                                  setEditingAppeal(appeal);
                                  setShowAppealDialog(true);
                                }}
                              >
                                <Edit className="h-3 w-3 mr-1" />
                                Edit
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="library" className="space-y-4">
                <LibraryReferencesTab
                  caseData={caseData}
                  onOpenLibrary={() => {
                    setLibraryMode('browse');
                    setShowLibraryPicker(true);
                  }}
                />
              </TabsContent>

              <TabsContent value="history" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <History className="h-5 w-5" />
                      Case History & Audit Log
                    </CardTitle>
                    <CardDescription>Complete history of all case actions and status changes</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {caseAuditLog.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-8">
                        No history recorded yet.
                      </p>
                    ) : (
                      <div className="space-y-4">
                        {caseAuditLog.map((entry, index) => (
                          <div key={entry.id} className="flex gap-4">
                            <div className="flex flex-col items-center">
                              <div className={`w-3 h-3 rounded-full ${
                                entry.action === 'Status Changed' ? 'bg-primary' :
                                entry.action === 'Created' ? 'bg-success' :
                                entry.action === 'Override' ? 'bg-warning' :
                                'bg-muted-foreground'
                              }`} />
                              {index < caseAuditLog.length - 1 && (
                                <div className="w-0.5 h-full bg-border mt-1" />
                              )}
                            </div>
                            <div className="flex-1 pb-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <Badge variant="outline" className="text-xs mb-1">{entry.action}</Badge>
                                  <p className="font-medium">{entry.description}</p>
                                </div>
                                <p className="text-xs text-muted-foreground">
                                  {format(new Date(entry.performedAt), 'MMM d, yyyy h:mm a')}
                                </p>
                              </div>
                              <p className="text-sm text-muted-foreground mt-1">
                                By {entry.performedBy} ({entry.performedByRole})
                              </p>
                              {entry.previousValue && entry.newValue && (
                                <div className="mt-2 text-xs">
                                  <span className="text-muted-foreground">Changed from </span>
                                  <Badge variant="outline" className="text-xs">{entry.previousValue}</Badge>
                                  <span className="text-muted-foreground"> to </span>
                                  <Badge variant="outline" className="text-xs">{entry.newValue}</Badge>
                                </div>
                              )}
                              {entry.justification && (
                                <div className="mt-2 p-2 bg-muted rounded text-sm">
                                  <span className="text-muted-foreground">Justification: </span>
                                  {entry.justification}
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Action Center Rail */}
          <div className="space-y-4">
            {/* Library Suggestions */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <BookOpen className="h-4 w-4" />
                  Library Suggestions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div 
                  className="p-2 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                  onClick={() => openLibraryForType('deadline_rule')}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">Standard Deadlines</span>
                    </div>
                    <Badge variant="outline" className="text-xs">Apply</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Set deadlines from library rules</p>
                </div>
                <div 
                  className="p-2 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                  onClick={() => openLibraryForType('remedy')}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">Remedies</span>
                    </div>
                    <Badge variant="outline" className="text-xs">{isClosed ? 'Ref' : 'Apply'}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Add enforcement actions</p>
                </div>
                <div 
                  className="p-2 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                  onClick={() => openLibraryForType('response_template')}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">Response Templates</span>
                    </div>
                    <Badge variant="outline" className="text-xs">{isClosed ? 'Ref' : 'Apply'}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Use template for response</p>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="w-full text-xs" 
                  onClick={() => {
                    setLibraryMode('recommended');
                    setLibraryFilterType(null);
                    setShowLibraryPicker(true);
                  }}
                >
                  View All Recommendations
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Action Center</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full justify-start" variant="outline">
                  <FileText className="mr-2 h-4 w-4" />
                  Draft Response
                </Button>
                <Button className="w-full justify-start" variant="outline">
                  <Users className="mr-2 h-4 w-4" />
                  Request Dept Input
                </Button>
                <Button className="w-full justify-start" variant="outline">
                  <Mail className="mr-2 h-4 w-4" />
                  Submit Package
                </Button>
                <Button className="w-full justify-start" variant="outline">
                  <Scale className="mr-2 h-4 w-4" />
                  Open Appeal
                </Button>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:border-primary/50 transition-colors" onClick={() => setShowCrossLinkDialog(true)}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-base">Linked Records</CardTitle>
                <Button variant="ghost" size="sm" className="h-7 text-xs">
                  <LinkIcon className="h-3 w-3 mr-1" />
                  Manage
                </Button>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <LinkIcon className="h-4 w-4 text-orange-500" />
                  <span className="text-muted-foreground">
                    {caseData.linkedIssueIds?.length || 0} Issues
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Shield className="h-4 w-4 text-blue-500" />
                  <span className="text-muted-foreground">
                    {caseData.linkedCapaIds?.length || 0} CAPAs
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <FileText className="h-4 w-4 text-purple-500" />
                  <span className="text-muted-foreground">
                    {caseData.linkedCitationIds?.length || 0} Citations
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <FileText className="h-4 w-4 text-emerald-500" />
                  <span className="text-muted-foreground">
                    {caseData.linkedCitationCaseIds?.length || 0} Citation Cases
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Checklist</CardTitle>
                <CardDescription>Requirements to advance</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-success" />
                    <span>Regulatory body assigned</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-success" />
                    <span>Notice date set</span>
                  </li>
                  <li className="flex items-center gap-2">
                    {caseData.responseDueDate ? (
                      <CheckCircle className="h-4 w-4 text-success" />
                    ) : (
                      <Clock className="h-4 w-4 text-muted-foreground" />
                    )}
                    <span>Response due date</span>
                  </li>
                  <li className="flex items-center gap-2">
                    {caseData.assignedOwnerName ? (
                      <CheckCircle className="h-4 w-4 text-success" />
                    ) : (
                      <Clock className="h-4 w-4 text-muted-foreground" />
                    )}
                    <span>Owner assigned</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Dialogs */}
        <LibraryPickerDialog
          open={showLibraryPicker}
          onOpenChange={setShowLibraryPicker}
          caseData={caseData}
          onReference={handleLibraryReference}
          onApply={handleLibraryApply}
          showRecommended={libraryMode === 'recommended'}
        />

        {assignmentAction && (
          <CaseAssignmentDialog
            open={true}
            onOpenChange={(open) => {
              if (!open) setAssignmentAction(null);
            }}
            caseData={caseData}
            action={assignmentAction}
            onSave={handleAssignmentSave}
          />
        )}

        <CrossLinkDialog
          open={showCrossLinkDialog}
          onOpenChange={setShowCrossLinkDialog}
          caseData={caseData}
          onSave={handleCrossLinkSave}
        />

        <AppealFormDialog
          open={showAppealDialog}
          onOpenChange={(open) => {
            setShowAppealDialog(open);
            if (!open) setEditingAppeal(null);
          }}
          appeal={editingAppeal}
          caseId={caseId!}
          onSave={handleAppealSave}
        />
      </div>
    </AppLayout>
  );
}
