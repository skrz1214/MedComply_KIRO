import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useEnforcePoint } from "@/context/EnforcePointContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Search, Filter, Download, Gavel, Clock, CheckCircle, XCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { format } from "date-fns";

export default function AppealsPage() {
  const { appeals, cases } = useEnforcePoint();
  const [searchTerm, setSearchTerm] = useState("");
  const [outcomeFilter, setOutcomeFilter] = useState<string>("all");
  const [levelFilter, setLevelFilter] = useState<string>("all");

  const filteredAppeals = appeals.filter((appeal) => {
    const caseItem = cases.find((c) => c.id === appeal.caseId);
    const matchesSearch = caseItem?.title.toLowerCase().includes(searchTerm.toLowerCase()) || false;
    const matchesOutcome = outcomeFilter === "all" || appeal.outcome === outcomeFilter;
    const matchesLevel = levelFilter === "all" || appeal.appealLevel === levelFilter;
    return matchesSearch && matchesOutcome && matchesLevel;
  });

  const getCaseTitle = (caseId: string) => {
    const caseItem = cases.find((c) => c.id === caseId);
    return caseItem?.title || "Unknown Case";
  };

  const getOutcomeColor = (outcome: string) => {
    switch (outcome) {
      case "Pending":
        return "bg-warning/10 text-warning border-warning/20";
      case "Won":
        return "bg-success/10 text-success border-success/20";
      case "Lost":
        return "bg-destructive/10 text-destructive border-destructive/20";
      case "Settled":
        return "bg-info/10 text-info border-info/20";
      case "Withdrawn":
        return "bg-muted text-muted-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getOutcomeIcon = (outcome: string) => {
    switch (outcome) {
      case "Pending":
        return <Clock className="h-4 w-4" />;
      case "Won":
        return <CheckCircle className="h-4 w-4" />;
      case "Lost":
        return <XCircle className="h-4 w-4" />;
      default:
        return <Gavel className="h-4 w-4" />;
    }
  };

  const pendingAppeals = appeals.filter((a) => a.outcome === "Pending").length;
  const wonAppeals = appeals.filter((a) => a.outcome === "Won").length;

  const handleExportCSV = () => {
    const headers = ["Appeal ID", "Case", "Level", "Filing Due", "Filed Date", "Outcome"];
    const rows = filteredAppeals.map((a) => [
      a.id,
      getCaseTitle(a.caseId),
      a.appealLevel,
      a.filingDueDate ? format(new Date(a.filingDueDate), "yyyy-MM-dd") : "",
      a.filedDate ? format(new Date(a.filedDate), "yyyy-MM-dd") : "",
      a.outcome,
    ]);
    
    const csv = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `appeals-${format(new Date(), "yyyy-MM-dd")}.csv`;
    anchor.click();
  };

  const appealLevels = [
    "Informal Dispute",
    "Administrative Hearing",
    "State-Level Hearing",
    "Federal-Level",
    "Other",
  ];

  return (
    <AppLayout breadcrumbs={[{ label: "Enforcement", href: "/enforcement" }, { label: "Appeals" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Appeals</h1>
            <p className="text-muted-foreground">
              Track appeals and hearings
            </p>
          </div>
          <Button variant="outline" onClick={handleExportCSV}>
            <Download className="mr-2 h-4 w-4" />
            Export CSV
          </Button>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Appeals</CardTitle>
              <Gavel className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{appeals.length}</div>
              <p className="text-xs text-muted-foreground">All appeals filed</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
              <Clock className="h-4 w-4 text-warning" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-warning">{pendingAppeals}</div>
              <p className="text-xs text-muted-foreground">Awaiting outcome</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Won</CardTitle>
              <CheckCircle className="h-4 w-4 text-success" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success">{wonAppeals}</div>
              <p className="text-xs text-muted-foreground">Successful appeals</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Filter className="h-4 w-4" />
              Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <div className="flex-1 min-w-[200px]">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search by case..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>
              <Select value={levelFilter} onValueChange={setLevelFilter}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Appeal Level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  {appealLevels.map((level) => (
                    <SelectItem key={level} value={level}>
                      {level}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={outcomeFilter} onValueChange={setOutcomeFilter}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Outcome" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Outcomes</SelectItem>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Won">Won</SelectItem>
                  <SelectItem value="Lost">Lost</SelectItem>
                  <SelectItem value="Settled">Settled</SelectItem>
                  <SelectItem value="Withdrawn">Withdrawn</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Appeals Table */}
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Case</TableHead>
                  <TableHead>Appeal Level</TableHead>
                  <TableHead>Filing Due</TableHead>
                  <TableHead>Filed Date</TableHead>
                  <TableHead>Outcome</TableHead>
                  <TableHead>Counsel</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAppeals.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      No appeals found.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredAppeals.map((appeal) => (
                    <TableRow key={appeal.id}>
                      <TableCell>
                        <Link
                          to={`/enforcement/cases/${appeal.caseId}`}
                          className="font-medium text-primary hover:underline"
                        >
                          {getCaseTitle(appeal.caseId)}
                        </Link>
                      </TableCell>
                      <TableCell>{appeal.appealLevel}</TableCell>
                      <TableCell>
                        {appeal.filingDueDate
                          ? format(new Date(appeal.filingDueDate), "MMM d, yyyy")
                          : "-"}
                      </TableCell>
                      <TableCell>
                        {appeal.filedDate
                          ? format(new Date(appeal.filedDate), "MMM d, yyyy")
                          : "-"}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={getOutcomeColor(appeal.outcome)}>
                          <span className="mr-1">{getOutcomeIcon(appeal.outcome)}</span>
                          {appeal.outcome}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {appeal.counselRepresentative || "-"}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
