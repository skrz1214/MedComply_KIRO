import { useState } from "react";
import { useEnforcePoint } from "@/context/EnforcePointContext";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Building2, Search, Filter, Eye, FolderOpen, AlertTriangle, CheckCircle, Plus, Pencil, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { RegulatoryBody } from "@/types/enforcepoint";
import { RegulatoryBodyFormDialog } from "@/components/enforcement/RegulatoryBodyFormDialog";
import { toast } from "sonner";

export default function RegulatoryBodiesPage() {
  const { regulatoryBodies, cases, addRegulatoryBody, updateRegulatoryBody, deleteRegulatoryBody } = useEnforcePoint();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [levelFilter, setLevelFilter] = useState<string>("all");
  const [selectedBody, setSelectedBody] = useState<RegulatoryBody | null>(null);
  const [formDialogOpen, setFormDialogOpen] = useState(false);
  const [editingBody, setEditingBody] = useState<RegulatoryBody | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [bodyToDelete, setBodyToDelete] = useState<RegulatoryBody | null>(null);

  const getBodyStats = (bodyId: string) => {
    const bodyCases = cases.filter(c => c.regulatoryBodyId === bodyId);
    const activeCases = bodyCases.filter(c => !["Closed", "Draft"].includes(c.status));
    const criticalCases = bodyCases.filter(c => c.severity === "Critical" || c.immediateJeopardy);
    const overdueCases = bodyCases.filter(c => {
      if (!c.responseDueDate) return false;
      return new Date(c.responseDueDate) < new Date() && c.status !== "Closed";
    });
    return {
      total: bodyCases.length,
      active: activeCases.length,
      critical: criticalCases.length,
      overdue: overdueCases.length
    };
  };

  const filteredBodies = regulatoryBodies.filter(body => {
    const matchesSearch = body.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      body.oversightTypes.some(t => t.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesLevel = levelFilter === "all" || body.level === levelFilter;
    return matchesSearch && matchesLevel;
  });

  const federalBodies = filteredBodies.filter(b => b.level === "Federal");
  const stateBodies = filteredBodies.filter(b => b.level === "State");
  const localBodies = filteredBodies.filter(b => b.level === "Local");

  const getLevelBadgeVariant = (level: string) => {
    switch (level) {
      case "Federal": return "default";
      case "State": return "secondary";
      case "Local": return "outline";
      default: return "outline";
    }
  };

  const bodyCasesForSelected = selectedBody 
    ? cases.filter(c => c.regulatoryBodyId === selectedBody.id)
    : [];

  const handleSaveBody = (bodyData: Omit<RegulatoryBody, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingBody) {
      updateRegulatoryBody(editingBody.id, bodyData);
      toast.success("Regulatory body updated");
    } else {
      addRegulatoryBody(bodyData);
      toast.success("Regulatory body added");
    }
    setEditingBody(null);
  };

  const handleDelete = () => {
    if (bodyToDelete) {
      const stats = getBodyStats(bodyToDelete.id);
      if (stats.total > 0) {
        toast.error("Cannot delete: This body has associated cases");
        return;
      }
      deleteRegulatoryBody(bodyToDelete.id);
      toast.success("Regulatory body deleted");
      setBodyToDelete(null);
      setDeleteDialogOpen(false);
    }
  };

  const openEditDialog = (body: RegulatoryBody) => {
    setEditingBody(body);
    setFormDialogOpen(true);
  };

  const openDeleteDialog = (body: RegulatoryBody) => {
    setBodyToDelete(body);
    setDeleteDialogOpen(true);
  };

  return (
    <AppLayout breadcrumbs={[{ label: "Enforcement", href: "/enforcement" }, { label: "Regulatory Bodies" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Regulatory Bodies</h1>
            <p className="text-muted-foreground">
              View and manage enforcement cases by regulatory body
            </p>
          </div>
          <Button onClick={() => { setEditingBody(null); setFormDialogOpen(true); }}>
            <Plus className="mr-2 h-4 w-4" />
            Add Body
          </Button>
        </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Federal Bodies</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{federalBodies.length}</div>
            <p className="text-xs text-muted-foreground">
              {federalBodies.reduce((acc, b) => acc + getBodyStats(b.id).active, 0)} active cases
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">State Bodies</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stateBodies.length}</div>
            <p className="text-xs text-muted-foreground">
              {stateBodies.reduce((acc, b) => acc + getBodyStats(b.id).active, 0)} active cases
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Local Bodies</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{localBodies.length}</div>
            <p className="text-xs text-muted-foreground">
              {localBodies.reduce((acc, b) => acc + getBodyStats(b.id).active, 0)} active cases
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critical Cases</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">
              {filteredBodies.reduce((acc, b) => acc + getBodyStats(b.id).critical, 0)}
            </div>
            <p className="text-xs text-muted-foreground">Across all bodies</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filter Regulatory Bodies</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search by name or oversight type..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={levelFilter} onValueChange={setLevelFilter}>
              <SelectTrigger className="w-[180px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="Federal">Federal</SelectItem>
                <SelectItem value="State">State</SelectItem>
                <SelectItem value="Local">Local</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Regulatory Bodies Table */}
      <Card>
        <CardHeader>
          <CardTitle>Regulatory Bodies Directory</CardTitle>
          <CardDescription>
            Click on a regulatory body to view associated enforcement cases
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Level</TableHead>
                <TableHead>Oversight Types</TableHead>
                <TableHead className="text-center">Total Cases</TableHead>
                <TableHead className="text-center">Active</TableHead>
                <TableHead className="text-center">Critical</TableHead>
                <TableHead className="text-center">Overdue</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredBodies.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                    No regulatory bodies found matching your criteria
                  </TableCell>
                </TableRow>
              ) : (
                filteredBodies.map((body) => {
                  const stats = getBodyStats(body.id);
                  return (
                    <TableRow key={body.id} className="cursor-pointer hover:bg-muted/50">
                      <TableCell className="font-medium">
                        <div>
                          <div>{body.name}</div>
                          {body.jurisdiction && (
                            <div className="text-xs text-muted-foreground">{body.jurisdiction}</div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getLevelBadgeVariant(body.level)}>{body.level}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {body.oversightTypes.slice(0, 2).map((type, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {type}
                            </Badge>
                          ))}
                          {body.oversightTypes.length > 2 && (
                            <Badge variant="outline" className="text-xs">
                              +{body.oversightTypes.length - 2}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <span className="font-medium">{stats.total}</span>
                      </TableCell>
                      <TableCell className="text-center">
                        {stats.active > 0 ? (
                          <Badge variant="secondary">{stats.active}</Badge>
                        ) : (
                          <span className="text-muted-foreground">0</span>
                        )}
                      </TableCell>
                      <TableCell className="text-center">
                        {stats.critical > 0 ? (
                          <Badge variant="destructive">{stats.critical}</Badge>
                        ) : (
                          <span className="text-muted-foreground">0</span>
                        )}
                      </TableCell>
                      <TableCell className="text-center">
                        {stats.overdue > 0 ? (
                          <Badge variant="destructive" className="bg-orange-500">
                            {stats.overdue}
                          </Badge>
                        ) : (
                          <CheckCircle className="h-4 w-4 text-green-500 mx-auto" />
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setSelectedBody(body)}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                              <DialogHeader>
                                <DialogTitle>{selectedBody?.name}</DialogTitle>
                                <DialogDescription>
                                  {selectedBody?.level} • {selectedBody?.jurisdiction || "National"}
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <h4 className="font-medium mb-2">Oversight Types</h4>
                                  <div className="flex flex-wrap gap-2">
                                    {selectedBody?.oversightTypes.map((type, idx) => (
                                      <Badge key={idx} variant="outline">{type}</Badge>
                                    ))}
                                  </div>
                                </div>
                                {selectedBody?.standardResponseDays && (
                                  <div>
                                    <h4 className="font-medium mb-2">Standard Response Timeline</h4>
                                    <p className="text-sm text-muted-foreground">
                                      {selectedBody.standardResponseDays} days
                                    </p>
                                  </div>
                                )}
                                {(selectedBody?.contactEmail || selectedBody?.contactPhone || selectedBody?.portalUrl) && (
                                  <div>
                                    <h4 className="font-medium mb-2">Contact Information</h4>
                                    <div className="text-sm text-muted-foreground space-y-1">
                                      {selectedBody.contactEmail && <p>Email: {selectedBody.contactEmail}</p>}
                                      {selectedBody.contactPhone && <p>Phone: {selectedBody.contactPhone}</p>}
                                      {selectedBody.portalUrl && <p>Portal: {selectedBody.portalUrl}</p>}
                                    </div>
                                  </div>
                                )}
                                <div>
                                  <h4 className="font-medium mb-2">Associated Cases ({bodyCasesForSelected.length})</h4>
                                  {bodyCasesForSelected.length === 0 ? (
                                    <p className="text-sm text-muted-foreground">No cases for this regulatory body</p>
                                  ) : (
                                    <Table>
                                      <TableHeader>
                                        <TableRow>
                                          <TableHead>Case #</TableHead>
                                          <TableHead>Title</TableHead>
                                          <TableHead>Status</TableHead>
                                          <TableHead>Severity</TableHead>
                                          <TableHead></TableHead>
                                        </TableRow>
                                      </TableHeader>
                                      <TableBody>
                                        {bodyCasesForSelected.map((c) => (
                                          <TableRow key={c.id}>
                                            <TableCell className="font-mono text-sm">{c.caseNumber}</TableCell>
                                            <TableCell>{c.title}</TableCell>
                                            <TableCell>
                                              <Badge variant="outline">{c.status}</Badge>
                                            </TableCell>
                                            <TableCell>
                                              <Badge variant={c.severity === "Critical" ? "destructive" : "secondary"}>
                                                {c.severity}
                                              </Badge>
                                            </TableCell>
                                            <TableCell>
                                              <Button
                                                variant="ghost"
                                                size="sm"
                                                onClick={() => navigate(`/enforcement/cases/${c.id}`)}
                                              >
                                                <FolderOpen className="h-4 w-4" />
                                              </Button>
                                            </TableCell>
                                          </TableRow>
                                        ))}
                                      </TableBody>
                                    </Table>
                                  )}
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openEditDialog(body)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openDeleteDialog(body)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => navigate(`/enforcement/cases?body=${body.id}`)}
                          >
                            <FolderOpen className="h-4 w-4 mr-1" />
                            Cases
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
        </Card>
      </div>

      <RegulatoryBodyFormDialog
        open={formDialogOpen}
        onOpenChange={setFormDialogOpen}
        body={editingBody}
        onSave={handleSaveBody}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Regulatory Body</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{bodyToDelete?.name}"? This action cannot be undone.
              {bodyToDelete && getBodyStats(bodyToDelete.id).total > 0 && (
                <span className="block mt-2 text-destructive font-medium">
                  Warning: This body has associated cases and cannot be deleted.
                </span>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
