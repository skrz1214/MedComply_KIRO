import { useState, useRef } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useEnforcePoint } from "@/context/EnforcePointContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Clock,
  AlertTriangle,
  CheckCircle,
  Plus,
  CalendarDays,
  Pencil,
  Trash2,
} from "lucide-react";
import { Link } from "react-router-dom";
import { format, isSameDay, isPast } from "date-fns";
import { DeadlineFormDialog } from "@/components/enforcement/DeadlineFormDialog";
import {
  EventFormDialog,
  CalendarEvent,
} from "@/components/enforcement/EventFormDialog";
import { Deadline } from "@/types/enforcepoint";
import { toast } from "@/hooks/use-toast";

// Dummy events data
const initialEvents: CalendarEvent[] = [
  {
    id: "evt-001",
    title: "Compliance Committee Meeting",
    eventDate: new Date(new Date().setDate(new Date().getDate() + 2)),
    eventType: "Meeting",
    location: "Board Room A",
    attendees: "All Compliance Staff",
    description: "Monthly compliance review and case updates",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: "evt-002",
    caseId: "case-004",
    title: "DEA Audit Follow-up Hearing",
    eventDate: new Date(new Date().setDate(new Date().getDate() + 5)),
    eventType: "Hearing",
    location: "DEA Regional Office",
    attendees: "Dr. James Wilson, Legal Counsel",
    description: "Formal hearing regarding controlled substance audit findings",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: "evt-003",
    caseId: "case-005",
    title: "Fire Marshal Site Inspection",
    eventDate: new Date(new Date().setDate(new Date().getDate() + 7)),
    eventType: "Site Visit",
    location: "Valley View Nursing Home",
    attendees: "Facilities Team",
    description: "Follow-up inspection for life safety remediation",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: "evt-004",
    title: "HIPAA Training Session",
    eventDate: new Date(new Date().setDate(new Date().getDate() + 10)),
    eventType: "Training",
    location: "Training Center",
    attendees: "New Staff Members",
    description: "Mandatory HIPAA compliance training for new hires",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: "evt-005",
    caseId: "case-006",
    title: "Response Package Review",
    eventDate: new Date(new Date().setDate(new Date().getDate() + 1)),
    eventType: "Review",
    location: "Virtual",
    attendees: "Compliance Head, Department Heads",
    description: "Final review before submission to CMS",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
];

export default function CalendarPage() {
  const { deadlines, cases, addDeadline, updateDeadline, deleteDeadline } =
    useEnforcePoint();
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [viewFilter, setViewFilter] = useState<string>("all");
  const [itemFilter, setItemFilter] = useState<string>("both");
  const lastClickRef = useRef<{ date: Date; time: number } | null>(null);

  // Events state
  const [events, setEvents] = useState<CalendarEvent[]>(initialEvents);

  // Dialog states
  const [showDeadlineDialog, setShowDeadlineDialog] = useState(false);
  const [editingDeadline, setEditingDeadline] = useState<Deadline | null>(null);
  const [preselectedDate, setPreselectedDate] = useState<Date | null>(null);
  const [showEventDialog, setShowEventDialog] = useState(false);
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | null>(null);

  const getCaseTitle = (caseId: string) => {
    const caseItem = cases.find((c) => c.id === caseId);
    return caseItem?.title || "Unknown Case";
  };

  const filteredDeadlines = deadlines.filter((d) => {
    if (viewFilter === "all") return true;
    if (viewFilter === "pending") return !d.isCompleted;
    if (viewFilter === "overdue")
      return !d.isCompleted && isPast(new Date(d.dueDate));
    if (viewFilter === "completed") return d.isCompleted;
    return true;
  });

  const deadlinesOnSelectedDate = filteredDeadlines.filter((d) =>
    isSameDay(new Date(d.dueDate), selectedDate)
  );

  const eventsOnSelectedDate = events.filter((e) =>
    isSameDay(new Date(e.eventDate), selectedDate)
  );

  const getDeadlineTypeColor = (type: string) => {
    switch (type) {
      case "Response":
        return "bg-destructive text-destructive-foreground";
      case "Appeal Filing":
        return "bg-warning text-warning-foreground";
      case "Revisit":
        return "bg-info text-info-foreground";
      case "Payment":
        return "bg-success text-success-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getEventTypeColor = (type: string) => {
    switch (type) {
      case "Meeting":
        return "bg-primary text-primary-foreground";
      case "Hearing":
        return "bg-destructive text-destructive-foreground";
      case "Site Visit":
        return "bg-warning text-warning-foreground";
      case "Training":
        return "bg-info text-info-foreground";
      case "Review":
        return "bg-success text-success-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  // Get dates with deadlines/events for calendar highlighting
  const datesWithDeadlines =
    itemFilter !== "events"
      ? filteredDeadlines.map((d) => new Date(d.dueDate))
      : [];
  const datesWithEvents =
    itemFilter !== "deadlines" ? events.map((e) => new Date(e.eventDate)) : [];

  const upcomingDeadlines = filteredDeadlines
    .filter((d) => !d.isCompleted && new Date(d.dueDate) >= new Date())
    .sort(
      (a, b) =>
        new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
    )
    .slice(0, 5);

  const upcomingEvents = events
    .filter((e) => new Date(e.eventDate) >= new Date())
    .sort(
      (a, b) =>
        new Date(a.eventDate).getTime() - new Date(b.eventDate).getTime()
    )
    .slice(0, 5);

  const overdueDeadlines = filteredDeadlines.filter(
    (d) => !d.isCompleted && isPast(new Date(d.dueDate))
  );

  // Handlers
  const handleAddDeadline = (date?: Date) => {
    setEditingDeadline(null);
    setPreselectedDate(date || null);
    setShowDeadlineDialog(true);
  };

  const handleDateDoubleClick = (date: Date) => {
    handleAddDeadline(date);
  };

  const handleEditDeadline = (deadline: Deadline) => {
    setEditingDeadline(deadline);
    setShowDeadlineDialog(true);
  };

  const handleSaveDeadline = (
    deadlineData: Omit<Deadline, "id" | "createdAt" | "updatedAt">
  ) => {
    if (editingDeadline) {
      updateDeadline(editingDeadline.id, deadlineData);
      toast({
        title: "Deadline Updated",
        description: "The deadline has been updated successfully.",
      });
    } else {
      addDeadline(deadlineData);
      toast({
        title: "Deadline Added",
        description: "The deadline has been added to the calendar.",
      });
    }
  };

  const handleDeleteDeadline = (deadlineId: string) => {
    deleteDeadline(deadlineId);
    toast({
      title: "Deadline Deleted",
      description: "The deadline has been removed.",
    });
  };

  const handleAddEvent = () => {
    setEditingEvent(null);
    setShowEventDialog(true);
  };

  const handleEditEvent = (event: CalendarEvent) => {
    setEditingEvent(event);
    setShowEventDialog(true);
  };

  const handleSaveEvent = (
    eventData: Omit<CalendarEvent, "id" | "createdAt" | "updatedAt">
  ) => {
    if (editingEvent) {
      setEvents((prev) =>
        prev.map((e) =>
          e.id === editingEvent.id
            ? { ...e, ...eventData, updatedAt: new Date() }
            : e
        )
      );
      toast({
        title: "Event Updated",
        description: "The event has been updated successfully.",
      });
    } else {
      const newEvent: CalendarEvent = {
        ...eventData,
        id: `evt-${Date.now()}`,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      setEvents((prev) => [...prev, newEvent]);
      toast({
        title: "Event Added",
        description: "The event has been added to the calendar.",
      });
    }
  };

  const handleDeleteEvent = (eventId: string) => {
    setEvents((prev) => prev.filter((e) => e.id !== eventId));
    toast({
      title: "Event Deleted",
      description: "The event has been removed.",
    });
  };

  return (
    <AppLayout
      breadcrumbs={[
        { label: "Enforcement", href: "/enforcement" },
        { label: "Calendar" },
      ]}
    >
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              Deadlines & Events Calendar
            </h1>
            <p className="text-muted-foreground">
              Track response dates, hearings, meetings, and more
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Select value={itemFilter} onValueChange={setItemFilter}>
              <SelectTrigger className="w-[130px]">
                <SelectValue placeholder="Show" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="both">All Items</SelectItem>
                <SelectItem value="deadlines">Deadlines</SelectItem>
                <SelectItem value="events">Events</SelectItem>
              </SelectContent>
            </Select>
            <Select value={viewFilter} onValueChange={setViewFilter}>
              <SelectTrigger className="w-[130px]">
                <SelectValue placeholder="Filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="overdue">Overdue</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={() => handleAddDeadline()} size="sm">
              <Plus className="h-4 w-4 mr-1" />
              Deadline
            </Button>
            <Button onClick={handleAddEvent} size="sm" variant="outline">
              <CalendarDays className="h-4 w-4 mr-1" />
              Event
            </Button>
          </div>
        </div>

        {/* Overdue Alert */}
        {overdueDeadlines.length > 0 && (
          <button
            onClick={() => {
              setViewFilter("overdue");
              if (overdueDeadlines.length > 0) {
                setSelectedDate(new Date(overdueDeadlines[0].dueDate));
              }
            }}
            className="w-full p-4 rounded-lg bg-destructive/10 border border-destructive/20 flex items-center gap-3 hover:bg-destructive/20 transition-colors cursor-pointer text-left"
          >
            <AlertTriangle className="h-5 w-5 text-destructive" />
            <div className="flex-1">
              <p className="font-medium text-destructive">
                {overdueDeadlines.length} Overdue Deadline
                {overdueDeadlines.length !== 1 ? "s" : ""}
              </p>
              <p className="text-sm text-muted-foreground">
                Click to view overdue deadlines
              </p>
            </div>
          </button>
        )}

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Calendar */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Calendar View</CardTitle>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={(date) => date && setSelectedDate(date)}
                onDayClick={(date) => {
                  const now = Date.now();
                  const lastClick = lastClickRef.current;
                  
                  // Check if this is a double-click (same date clicked within 400ms)
                  if (
                    lastClick &&
                    isSameDay(lastClick.date, date) &&
                    now - lastClick.time < 400
                  ) {
                    // Double-click detected - open deadline form
                    handleDateDoubleClick(date);
                    lastClickRef.current = null;
                  } else {
                    // First click - record it
                    lastClickRef.current = { date, time: now };
                  }
                }}
                className="rounded-md border w-full pointer-events-auto"
                modifiers={{
                  hasDeadline: datesWithDeadlines,
                  hasEvent: datesWithEvents,
                }}
                modifiersStyles={{
                  hasDeadline: {
                    fontWeight: "bold",
                    textDecoration: "underline",
                    color: "hsl(var(--destructive))",
                  },
                  hasEvent: {
                    fontWeight: "bold",
                    backgroundColor: "hsl(var(--primary) / 0.1)",
                    borderRadius: "50%",
                  },
                }}
              />

              {/* Selected Date Items */}
              <div className="mt-6">
                <h4 className="font-medium mb-3">
                  {format(selectedDate, "MMMM d, yyyy")}
                </h4>

                {/* Deadlines on selected date */}
                {itemFilter !== "events" && (
                  <>
                    {deadlinesOnSelectedDate.length > 0 && (
                      <div className="space-y-2 mb-4">
                        <p className="text-sm font-medium text-muted-foreground">
                          Deadlines
                        </p>
                        {deadlinesOnSelectedDate.map((deadline) => (
                          <div
                            key={deadline.id}
                            className="flex items-center justify-between p-3 rounded-lg border"
                          >
                            <div className="flex items-center gap-3">
                              {deadline.isCompleted ? (
                                <CheckCircle className="h-4 w-4 text-success" />
                              ) : (
                                <Clock className="h-4 w-4 text-muted-foreground" />
                              )}
                              <div>
                                <p className="font-medium">{deadline.title}</p>
                                <Link
                                  to={`/enforcement/cases/${deadline.caseId}`}
                                  className="text-sm text-primary hover:underline"
                                >
                                  {getCaseTitle(deadline.caseId)}
                                </Link>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge
                                className={getDeadlineTypeColor(deadline.type)}
                              >
                                {deadline.type}
                              </Badge>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => handleEditDeadline(deadline)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-destructive"
                                onClick={() => handleDeleteDeadline(deadline.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}

                {/* Events on selected date */}
                {itemFilter !== "deadlines" && (
                  <>
                    {eventsOnSelectedDate.length > 0 && (
                      <div className="space-y-2">
                        <p className="text-sm font-medium text-muted-foreground">
                          Events
                        </p>
                        {eventsOnSelectedDate.map((event) => (
                          <div
                            key={event.id}
                            className="flex items-center justify-between p-3 rounded-lg border"
                          >
                            <div className="flex items-center gap-3">
                              <CalendarDays className="h-4 w-4 text-primary" />
                              <div>
                                <p className="font-medium">{event.title}</p>
                                {event.location && (
                                  <p className="text-sm text-muted-foreground">
                                    {event.location}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge
                                className={getEventTypeColor(event.eventType)}
                              >
                                {event.eventType}
                              </Badge>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => handleEditEvent(event)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-destructive"
                                onClick={() => handleDeleteEvent(event.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}

                {deadlinesOnSelectedDate.length === 0 &&
                  eventsOnSelectedDate.length === 0 && (
                    <p className="text-sm text-muted-foreground">
                      No items on this date
                    </p>
                  )}
              </div>
            </CardContent>
          </Card>

          {/* Upcoming Lists */}
          <div className="space-y-6">
            {/* Upcoming Deadlines */}
            {itemFilter !== "events" && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Clock className="h-5 w-5" />
                    Upcoming Deadlines
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {upcomingDeadlines.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      No upcoming deadlines
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {upcomingDeadlines.map((deadline) => {
                        const isUrgent =
                          Math.ceil(
                            (new Date(deadline.dueDate).getTime() -
                              new Date().getTime()) /
                              (1000 * 60 * 60 * 24)
                          ) <= 7;

                        return (
                          <div
                            key={deadline.id}
                            className={`p-3 rounded-lg border cursor-pointer hover:bg-muted/50 ${
                              isUrgent ? "border-warning/50 bg-warning/5" : ""
                            }`}
                            onClick={() => handleEditDeadline(deadline)}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <Badge
                                variant="outline"
                                className={getDeadlineTypeColor(deadline.type)}
                              >
                                {deadline.type}
                              </Badge>
                              <span
                                className={`text-sm font-medium ${
                                  isUrgent ? "text-warning" : ""
                                }`}
                              >
                                {format(new Date(deadline.dueDate), "MMM d")}
                              </span>
                            </div>
                            <p className="font-medium text-sm">
                              {deadline.title}
                            </p>
                            <Link
                              to={`/enforcement/cases/${deadline.caseId}`}
                              className="text-xs text-primary hover:underline"
                              onClick={(e) => e.stopPropagation()}
                            >
                              {getCaseTitle(deadline.caseId)}
                            </Link>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Upcoming Events */}
            {itemFilter !== "deadlines" && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base">
                    <CalendarDays className="h-5 w-5" />
                    Upcoming Events
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {upcomingEvents.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      No upcoming events
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {upcomingEvents.map((event) => (
                        <div
                          key={event.id}
                          className="p-3 rounded-lg border cursor-pointer hover:bg-muted/50"
                          onClick={() => handleEditEvent(event)}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <Badge
                              variant="outline"
                              className={getEventTypeColor(event.eventType)}
                            >
                              {event.eventType}
                            </Badge>
                            <span className="text-sm font-medium">
                              {format(new Date(event.eventDate), "MMM d")}
                            </span>
                          </div>
                          <p className="font-medium text-sm">{event.title}</p>
                          {event.location && (
                            <p className="text-xs text-muted-foreground">
                              {event.location}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      {/* Dialogs */}
      <DeadlineFormDialog
        open={showDeadlineDialog}
        onOpenChange={setShowDeadlineDialog}
        deadline={editingDeadline}
        cases={cases}
        preselectedCaseId={undefined}
        preselectedDate={preselectedDate}
        onSave={handleSaveDeadline}
      />

      <EventFormDialog
        open={showEventDialog}
        onOpenChange={setShowEventDialog}
        event={editingEvent}
        cases={cases}
        preselectedDate={selectedDate}
        onSave={handleSaveEvent}
      />
    </AppLayout>
  );
}
