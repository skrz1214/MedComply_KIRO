import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useEnforcePoint } from "@/context/EnforcePointContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Edit2,
  Trash2,
  Building,
  FileText,
  Scale,
  AlertTriangle,
  Settings,
  Clock,
  Bell,
  Users,
  Library,
  Hospital,
  Shield,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { OversightType, CaseType, ProviderType, UserRole } from "@/types/enforcepoint";

// Provider Types Configuration
const defaultProviderTypes: { id: string; name: ProviderType; description: string; isActive: boolean }[] = [
  { id: "pt-1", name: "Hospital", description: "Acute care facilities", isActive: true },
  { id: "pt-2", name: "Clinic", description: "Outpatient care centers", isActive: true },
  { id: "pt-3", name: "SNF", description: "Skilled Nursing Facilities", isActive: true },
  { id: "pt-4", name: "ALF", description: "Assisted Living Facilities", isActive: true },
  { id: "pt-5", name: "Home Health", description: "Home health agencies", isActive: true },
  { id: "pt-6", name: "Other", description: "Other provider types", isActive: true },
];

// Severity Levels Configuration
const defaultSeverityLevels = [
  { id: "sev-1", name: "Low", color: "#22c55e", description: "Minor non-compliance", weight: 1 },
  { id: "sev-2", name: "Medium", color: "#eab308", description: "Moderate compliance issues", weight: 2 },
  { id: "sev-3", name: "High", color: "#f97316", description: "Significant compliance failures", weight: 3 },
  { id: "sev-4", name: "Critical", color: "#ef4444", description: "Immediate jeopardy situations", weight: 4 },
];

// Document Types Configuration
const defaultDocumentTypes = [
  { id: "doc-1", name: "Notice", category: "Inbound", isActive: true },
  { id: "doc-2", name: "Statement of Deficiencies", category: "Inbound", isActive: true },
  { id: "doc-3", name: "Demand Letter", category: "Inbound", isActive: true },
  { id: "doc-4", name: "CAP Request", category: "Inbound", isActive: true },
  { id: "doc-5", name: "Plan of Correction", category: "Outbound", isActive: true },
  { id: "doc-6", name: "Response Letter", category: "Outbound", isActive: true },
  { id: "doc-7", name: "Appeal Filing", category: "Outbound", isActive: true },
  { id: "doc-8", name: "Settlement", category: "Both", isActive: true },
  { id: "doc-9", name: "Payment Confirmation", category: "Outbound", isActive: true },
  { id: "doc-10", name: "Revisit Results", category: "Inbound", isActive: true },
  { id: "doc-11", name: "Meeting Notes", category: "Internal", isActive: true },
];

// Escalation Rules Configuration
const defaultEscalationRules = [
  { id: "esc-1", name: "7-Day Deadline Warning", triggerDays: 7, recipients: ["Assigned Owner"], isActive: true },
  { id: "esc-2", name: "3-Day Deadline Warning", triggerDays: 3, recipients: ["Assigned Owner", "Department Head"], isActive: true },
  { id: "esc-3", name: "1-Day Deadline Warning", triggerDays: 1, recipients: ["Assigned Owner", "Department Head", "Compliance Head"], isActive: true },
  { id: "esc-4", name: "Overdue Escalation", triggerDays: 0, recipients: ["Compliance Head", "Admin"], isActive: true },
];

export default function AdminConfigPage() {
  const {
    regulatoryBodies,
    caseTypes,
    findingCategories,
    actionTypes,
    deadlineRules,
    libraryConfig,
    addRegulatoryBody,
    updateRegulatoryBody,
    deleteRegulatoryBody,
    addCaseType,
    updateCaseType,
    deleteCaseType,
    addFindingCategory,
    updateFindingCategory,
    deleteFindingCategory,
    addActionType,
    updateActionType,
    deleteActionType,
    addDeadlineRule,
    updateDeadlineRule,
    deleteDeadlineRule,
    // Library Items
    remedyLibraryItems,
    addRemedyLibraryItem,
    updateRemedyLibraryItem,
    deleteRemedyLibraryItem,
    responseTemplateLibraryItems,
    addResponseTemplateLibraryItem,
    updateResponseTemplateLibraryItem,
    deleteResponseTemplateLibraryItem,
    evidenceRequirementLibraryItems,
    addEvidenceRequirementLibraryItem,
    updateEvidenceRequirementLibraryItem,
    deleteEvidenceRequirementLibraryItem,
    findingCategoryLibraryItems,
    addFindingCategoryLibraryItem,
    updateFindingCategoryLibraryItem,
    deleteFindingCategoryLibraryItem,
  } = useEnforcePoint();
  const { toast } = useToast();

  // Regulatory Body Dialog State
  const [isAddingBody, setIsAddingBody] = useState(false);
  const [editingBody, setEditingBody] = useState<string | null>(null);
  const [deletingBody, setDeletingBody] = useState<{ id: string; name: string } | null>(null);
  const [newBody, setNewBody] = useState({
    name: "",
    abbreviation: "",
    level: "Federal" as "Federal" | "State" | "Local",
    jurisdiction: "",
    oversightTypes: [] as OversightType[],
    enforcementScopeTags: [] as string[],
    standardResponseDays: 10,
    contactEmail: "",
    contactPhone: "",
    portalUrl: "",
    isActive: true,
  });

  // Case Type Dialog State
  const [isAddingCaseType, setIsAddingCaseType] = useState(false);
  const [editingCaseType, setEditingCaseType] = useState<string | null>(null);
  const [deletingCaseType, setDeletingCaseType] = useState<{ id: string; name: string } | null>(null);
  const [newCaseType, setNewCaseType] = useState({ name: "", description: "" });

  // Action Type Dialog State
  const [isAddingActionType, setIsAddingActionType] = useState(false);
  const [editingActionType, setEditingActionType] = useState<string | null>(null);
  const [deletingActionType, setDeletingActionType] = useState<{ id: string; name: string } | null>(null);
  const [newActionType, setNewActionType] = useState({
    name: "",
    category: "Financial Penalty" as "Financial Penalty" | "Payment Remedy" | "Operational Remedy" | "Licensure/Restriction" | "Monitoring/Reporting Requirement" | "Other",
    description: "",
    isDefault: false,
    isActive: true,
  });

  // Finding Category Dialog State
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [editingCategory, setEditingCategory] = useState<string | null>(null);
  const [deletingCategory, setDeletingCategory] = useState<{ id: string; name: string } | null>(null);
  const [newCategory, setNewCategory] = useState({ name: "", description: "" });

  // Deadline Rule Dialog State
  const [isAddingDeadlineRule, setIsAddingDeadlineRule] = useState(false);
  const [editingDeadlineRule, setEditingDeadlineRule] = useState<string | null>(null);
  const [deletingDeadlineRule, setDeletingDeadlineRule] = useState<{ id: string; name: string } | null>(null);
  const [newDeadlineRule, setNewDeadlineRule] = useState({
    regulatoryBodyId: "",
    caseType: "" as string,
    deadlineType: "PoC" as "Response" | "PoC" | "Appeal Filing" | "Payment" | "Revisit" | "Hearing" | "Other",
    defaultDays: 10,
    warningDays: [7, 3, 1] as number[],
    escalationRecipients: [] as string[],
    isActive: true,
  });

  // Provider Types State
  const [providerTypes, setProviderTypes] = useState(defaultProviderTypes);
  const [isAddingProviderType, setIsAddingProviderType] = useState(false);
  const [newProviderType, setNewProviderType] = useState({ name: "", description: "" });

  // Severity Levels State
  const [severityLevels, setSeverityLevels] = useState(defaultSeverityLevels);
  const [isAddingSeverity, setIsAddingSeverity] = useState(false);
  const [editingSeverity, setEditingSeverity] = useState<string | null>(null);
  const [deletingSeverity, setDeletingSeverity] = useState<{ id: string; name: string } | null>(null);
  const [newSeverity, setNewSeverity] = useState({ name: "", color: "#22c55e", description: "", weight: 1 });

  // Document Types State
  const [documentTypes, setDocumentTypes] = useState(defaultDocumentTypes);
  const [isAddingDocType, setIsAddingDocType] = useState(false);
  const [newDocType, setNewDocType] = useState({ name: "", category: "Inbound" });

  // Escalation Rules State
  const [escalationRules, setEscalationRules] = useState(defaultEscalationRules);
  const [isAddingEscRule, setIsAddingEscRule] = useState(false);
  const [editingEscRule, setEditingEscRule] = useState<string | null>(null);
  const [deletingEscRule, setDeletingEscRule] = useState<{ id: string; name: string } | null>(null);
  const [newEscRule, setNewEscRule] = useState({ name: "", triggerDays: 7, recipients: [] as string[] });

  // Library Config State
  const [localLibraryConfig, setLocalLibraryConfig] = useState({
    whoCanManage: libraryConfig?.whoCanManage || ["Admin"],
    editPublishedAllowed: libraryConfig?.editPublishedAllowed ?? false,
    requireNewVersionOnChange: libraryConfig?.requireNewVersionOnChange ?? true,
    hideDeprecatedFromPickers: libraryConfig?.hideDeprecatedFromPickers ?? true,
    defaultWarningThresholds: libraryConfig?.defaultWarningThresholds || [7, 3, 1],
    defaultEscalationRoles: libraryConfig?.defaultEscalationRoles || ["Compliance Head"],
  });

  // Remedy Library State
  const [isAddingRemedy, setIsAddingRemedy] = useState(false);
  const [editingRemedy, setEditingRemedy] = useState<string | null>(null);
  const [deletingRemedy, setDeletingRemedy] = useState<{ id: string; name: string } | null>(null);
  const [newRemedy, setNewRemedy] = useState({ name: "", description: "", defaultDueInDays: 30, isFinancial: false, status: "Draft" as "Draft" | "Published" | "Deprecated" });

  // Response Template Library State
  const [isAddingTemplate, setIsAddingTemplate] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<string | null>(null);
  const [deletingTemplate, setDeletingTemplate] = useState<{ id: string; name: string } | null>(null);
  const [newTemplate, setNewTemplate] = useState({
    templateName: "",
    description: "",
    regulatoryBodyId: "",
    caseType: "",
    requiredSections: "" as string, // comma-separated
    requiredAttachments: "" as string, // comma-separated
    status: "Draft" as "Draft" | "Published" | "Deprecated",
  });

  // Evidence Requirement Library State
  const [isAddingEvidence, setIsAddingEvidence] = useState(false);
  const [editingEvidence, setEditingEvidence] = useState<string | null>(null);
  const [deletingEvidence, setDeletingEvidence] = useState<{ id: string; name: string } | null>(null);
  const [newEvidence, setNewEvidence] = useState({ name: "", description: "", status: "Draft" as "Draft" | "Published" | "Deprecated" });

  // Finding Category Library State
  const [isAddingFindingCatLib, setIsAddingFindingCatLib] = useState(false);
  const [editingFindingCatLib, setEditingFindingCatLib] = useState<string | null>(null);
  const [deletingFindingCatLib, setDeletingFindingCatLib] = useState<{ id: string; name: string } | null>(null);
  const [newFindingCatLib, setNewFindingCatLib] = useState({ name: "", description: "", status: "Draft" as "Draft" | "Published" | "Deprecated" });

  // General Settings State
  const [generalSettings, setGeneralSettings] = useState({
    defaultResponseDays: 10,
    deadlineWarningDays: 7,
    allowCsvExport: true,
    requireApprovalForSubmission: true,
    autoCloseAfterDays: 90,
    enableAuditLog: true,
    enableNotifications: true,
  });

  const handleAddBody = () => {
    if (!newBody.name || !newBody.level) {
      toast({
        title: "Validation Error",
        description: "Name and level are required.",
        variant: "destructive",
      });
      return;
    }

    addRegulatoryBody({
      name: newBody.name,
      abbreviation: newBody.abbreviation,
      level: newBody.level,
      jurisdiction: newBody.jurisdiction,
      oversightTypes: newBody.oversightTypes,
      enforcementScopeTags: newBody.enforcementScopeTags,
      standardResponseDays: newBody.standardResponseDays,
      contactEmail: newBody.contactEmail,
      contactPhone: newBody.contactPhone,
      portalUrl: newBody.portalUrl,
      isActive: true,
    });

    toast({
      title: "Regulatory Body Added",
      description: `${newBody.name} has been added to the directory.`,
    });

    resetBodyForm();
    setIsAddingBody(false);
  };

  const resetBodyForm = () => {
    setNewBody({
      name: "",
      abbreviation: "",
      level: "Federal",
      jurisdiction: "",
      oversightTypes: [],
      enforcementScopeTags: [],
      standardResponseDays: 10,
      contactEmail: "",
      contactPhone: "",
      portalUrl: "",
      isActive: true,
    });
  };

  const handleAddActionType = () => {
    if (!newActionType.name) {
      toast({ title: "Name is required", variant: "destructive" });
      return;
    }
    addActionType(newActionType);
    toast({ title: "Action Type Added", description: `${newActionType.name} has been added.` });
    setNewActionType({ name: "", category: "Financial Penalty", description: "", isDefault: false, isActive: true });
    setIsAddingActionType(false);
  };

  const handleAddProviderType = () => {
    if (!newProviderType.name) {
      toast({ title: "Name is required", variant: "destructive" });
      return;
    }
    setProviderTypes((prev) => [
      ...prev,
      { id: `pt-${Date.now()}`, name: newProviderType.name as ProviderType, description: newProviderType.description, isActive: true },
    ]);
    toast({ title: "Provider Type Added" });
    setNewProviderType({ name: "", description: "" });
    setIsAddingProviderType(false);
  };

  const handleAddDocType = () => {
    if (!newDocType.name) {
      toast({ title: "Name is required", variant: "destructive" });
      return;
    }
    setDocumentTypes((prev) => [...prev, { id: `doc-${Date.now()}`, name: newDocType.name, category: newDocType.category, isActive: true }]);
    toast({ title: "Document Type Added" });
    setNewDocType({ name: "", category: "Inbound" });
    setIsAddingDocType(false);
  };

  const handleAddEscRule = () => {
    if (!newEscRule.name) {
      toast({ title: "Name is required", variant: "destructive" });
      return;
    }
    setEscalationRules((prev) => [
      ...prev,
      { id: `esc-${Date.now()}`, name: newEscRule.name, triggerDays: newEscRule.triggerDays, recipients: newEscRule.recipients, isActive: true },
    ]);
    toast({ title: "Escalation Rule Added" });
    setNewEscRule({ name: "", triggerDays: 7, recipients: [] });
    setIsAddingEscRule(false);
  };

  const handleSaveLibraryConfig = () => {
    toast({ title: "Library Configuration Saved", description: "Settings have been updated." });
  };

  const handleSaveGeneralSettings = () => {
    toast({ title: "General Settings Saved", description: "Settings have been updated." });
  };

  const federalBodies = regulatoryBodies.filter((b) => b.level === "Federal");
  const stateBodies = regulatoryBodies.filter((b) => b.level === "State");
  const localBodies = regulatoryBodies.filter((b) => b.level === "Local");

  const actionTypesByCategory = actionTypes.reduce(
    (acc, type) => {
      if (!acc[type.category]) {
        acc[type.category] = [];
      }
      acc[type.category].push(type);
      return acc;
    },
    {} as Record<string, typeof actionTypes>
  );

  return (
    <AppLayout breadcrumbs={[{ label: "Enforcement", href: "/enforcement" }, { label: "Admin Configuration" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Admin Configuration</h1>
            <p className="text-muted-foreground">Configure EnforcePoint settings, taxonomies, and system behavior</p>
          </div>
        </div>

        <Tabs defaultValue="regulatory-bodies" className="space-y-4">
          <TabsList className="flex-wrap h-auto gap-1 p-1">
            <TabsTrigger value="regulatory-bodies" className="flex items-center gap-2">
              <Building className="h-4 w-4" />
              <span className="hidden sm:inline">Regulatory Bodies</span>
            </TabsTrigger>
            <TabsTrigger value="case-types" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Case Types</span>
            </TabsTrigger>
            <TabsTrigger value="provider-types" className="flex items-center gap-2">
              <Hospital className="h-4 w-4" />
              <span className="hidden sm:inline">Provider Types</span>
            </TabsTrigger>
            <TabsTrigger value="action-types" className="flex items-center gap-2">
              <Scale className="h-4 w-4" />
              <span className="hidden sm:inline">Action Types</span>
            </TabsTrigger>
            <TabsTrigger value="finding-categories" className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              <span className="hidden sm:inline">Finding Categories</span>
            </TabsTrigger>
            <TabsTrigger value="deadline-rules" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span className="hidden sm:inline">Deadline Rules</span>
            </TabsTrigger>
            <TabsTrigger value="document-types" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Document Types</span>
            </TabsTrigger>
            <TabsTrigger value="escalation" className="flex items-center gap-2">
              <Bell className="h-4 w-4" />
              <span className="hidden sm:inline">Escalation</span>
            </TabsTrigger>
            <TabsTrigger value="severity-levels" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              <span className="hidden sm:inline">Severity</span>
            </TabsTrigger>
            <TabsTrigger value="library-config" className="flex items-center gap-2">
              <Library className="h-4 w-4" />
              <span className="hidden sm:inline">Library</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">General</span>
            </TabsTrigger>
          </TabsList>

          {/* ========== REGULATORY BODIES TAB ========== */}
          <TabsContent value="regulatory-bodies" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Regulatory Bodies Directory</CardTitle>
                  <CardDescription>Configure federal, state, and local regulatory bodies with contact info and oversight scope</CardDescription>
                </div>
                <Dialog open={isAddingBody} onOpenChange={setIsAddingBody}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Body
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Add Regulatory Body</DialogTitle>
                      <DialogDescription>Add a new regulatory body with full details</DialogDescription>
                    </DialogHeader>
                    <div className="grid grid-cols-2 gap-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Name *</Label>
                        <Input id="name" value={newBody.name} onChange={(e) => setNewBody({ ...newBody, name: e.target.value })} placeholder="e.g., CMS" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="abbreviation">Abbreviation</Label>
                        <Input
                          id="abbreviation"
                          value={newBody.abbreviation}
                          onChange={(e) => setNewBody({ ...newBody, abbreviation: e.target.value })}
                          placeholder="e.g., CMS"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="level">Level *</Label>
                        <Select value={newBody.level} onValueChange={(value) => setNewBody({ ...newBody, level: value as "Federal" | "State" | "Local" })}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select level" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Federal">Federal</SelectItem>
                            <SelectItem value="State">State</SelectItem>
                            <SelectItem value="Local">Local</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="jurisdiction">Jurisdiction/State</Label>
                        <Input
                          id="jurisdiction"
                          value={newBody.jurisdiction}
                          onChange={(e) => setNewBody({ ...newBody, jurisdiction: e.target.value })}
                          placeholder="e.g., California"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="responseDays">Default Response Days</Label>
                        <Input
                          id="responseDays"
                          type="number"
                          value={newBody.standardResponseDays}
                          onChange={(e) => setNewBody({ ...newBody, standardResponseDays: parseInt(e.target.value) || 10 })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="contactEmail">Contact Email</Label>
                        <Input
                          id="contactEmail"
                          type="email"
                          value={newBody.contactEmail}
                          onChange={(e) => setNewBody({ ...newBody, contactEmail: e.target.value })}
                          placeholder="contact@agency.gov"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="contactPhone">Contact Phone</Label>
                        <Input
                          id="contactPhone"
                          value={newBody.contactPhone}
                          onChange={(e) => setNewBody({ ...newBody, contactPhone: e.target.value })}
                          placeholder="(555) 123-4567"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="portalUrl">Portal URL</Label>
                        <Input
                          id="portalUrl"
                          value={newBody.portalUrl}
                          onChange={(e) => setNewBody({ ...newBody, portalUrl: e.target.value })}
                          placeholder="https://portal.agency.gov"
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddingBody(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleAddBody}>Add Body</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Edit Regulatory Body Dialog */}
                <Dialog open={!!editingBody} onOpenChange={(open) => !open && setEditingBody(null)}>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Edit Regulatory Body</DialogTitle>
                      <DialogDescription>Update regulatory body details</DialogDescription>
                    </DialogHeader>
                    <div className="grid grid-cols-2 gap-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="edit-name">Name *</Label>
                        <Input id="edit-name" value={newBody.name} onChange={(e) => setNewBody({ ...newBody, name: e.target.value })} placeholder="e.g., CMS" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="edit-abbreviation">Abbreviation</Label>
                        <Input
                          id="edit-abbreviation"
                          value={newBody.abbreviation}
                          onChange={(e) => setNewBody({ ...newBody, abbreviation: e.target.value })}
                          placeholder="e.g., CMS"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="edit-level">Level *</Label>
                        <Select value={newBody.level} onValueChange={(value) => setNewBody({ ...newBody, level: value as "Federal" | "State" | "Local" })}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select level" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Federal">Federal</SelectItem>
                            <SelectItem value="State">State</SelectItem>
                            <SelectItem value="Local">Local</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="edit-jurisdiction">Jurisdiction/State</Label>
                        <Input
                          id="edit-jurisdiction"
                          value={newBody.jurisdiction}
                          onChange={(e) => setNewBody({ ...newBody, jurisdiction: e.target.value })}
                          placeholder="e.g., California"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="edit-responseDays">Default Response Days</Label>
                        <Input
                          id="edit-responseDays"
                          type="number"
                          value={newBody.standardResponseDays}
                          onChange={(e) => setNewBody({ ...newBody, standardResponseDays: parseInt(e.target.value) || 10 })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="edit-contactEmail">Contact Email</Label>
                        <Input
                          id="edit-contactEmail"
                          type="email"
                          value={newBody.contactEmail}
                          onChange={(e) => setNewBody({ ...newBody, contactEmail: e.target.value })}
                          placeholder="contact@agency.gov"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="edit-contactPhone">Contact Phone</Label>
                        <Input
                          id="edit-contactPhone"
                          value={newBody.contactPhone}
                          onChange={(e) => setNewBody({ ...newBody, contactPhone: e.target.value })}
                          placeholder="(555) 123-4567"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="edit-portalUrl">Portal URL</Label>
                        <Input
                          id="edit-portalUrl"
                          value={newBody.portalUrl}
                          onChange={(e) => setNewBody({ ...newBody, portalUrl: e.target.value })}
                          placeholder="https://portal.agency.gov"
                        />
                      </div>
                      <div className="col-span-2 flex items-center space-x-2">
                        <Switch
                          id="edit-isActive"
                          checked={newBody.isActive}
                          onCheckedChange={(checked) => setNewBody({ ...newBody, isActive: checked })}
                        />
                        <Label htmlFor="edit-isActive">Active</Label>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setEditingBody(null)}>
                        Cancel
                      </Button>
                      <Button onClick={() => {
                        if (editingBody) {
                          updateRegulatoryBody(editingBody, {
                            name: newBody.name,
                            abbreviation: newBody.abbreviation,
                            level: newBody.level,
                            jurisdiction: newBody.jurisdiction,
                            standardResponseDays: newBody.standardResponseDays,
                            contactEmail: newBody.contactEmail,
                            contactPhone: newBody.contactPhone,
                            portalUrl: newBody.portalUrl,
                            isActive: newBody.isActive,
                          });
                          toast({
                            title: "Regulatory Body Updated",
                            description: `${newBody.name} has been updated.`,
                          });
                          setEditingBody(null);
                          resetBodyForm();
                        }
                      }}>Save Changes</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Delete Confirmation Dialog */}
                <AlertDialog open={!!deletingBody} onOpenChange={(open) => !open && setDeletingBody(null)}>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Regulatory Body</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete "{deletingBody?.name}"? This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => {
                          if (deletingBody) {
                            deleteRegulatoryBody(deletingBody.id);
                            toast({
                              title: "Regulatory Body Deleted",
                              description: `${deletingBody.name} has been removed.`,
                            });
                            setDeletingBody(null);
                          }
                        }}
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Federal Bodies */}
                <div>
                  <h4 className="font-medium mb-3 flex items-center gap-2">
                    <Badge>Federal</Badge>
                    {federalBodies.length} bodies
                  </h4>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Response Days</TableHead>
                        <TableHead>Contact</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="w-[100px]">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {federalBodies.map((body) => (
                        <TableRow key={body.id}>
                          <TableCell className="font-medium">
                            {body.name}
                            {body.abbreviation && <span className="text-muted-foreground ml-1">({body.abbreviation})</span>}
                          </TableCell>
                          <TableCell>{body.standardResponseDays || 10} days</TableCell>
                          <TableCell className="text-sm text-muted-foreground">{body.contactEmail || "-"}</TableCell>
                          <TableCell>
                            <Badge variant={body.isActive ? "default" : "secondary"}>{body.isActive ? "Active" : "Inactive"}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => {
                                setNewBody({
                                  name: body.name,
                                  abbreviation: body.abbreviation || "",
                                  level: body.level,
                                  jurisdiction: body.jurisdiction || "",
                                  oversightTypes: body.oversightTypes || [],
                                  enforcementScopeTags: body.enforcementScopeTags || [],
                                  standardResponseDays: body.standardResponseDays || 10,
                                  contactEmail: body.contactEmail || "",
                                  contactPhone: body.contactPhone || "",
                                  portalUrl: body.portalUrl || "",
                                  isActive: body.isActive,
                                });
                                setEditingBody(body.id);
                              }}>
                                <Edit2 className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeletingBody({ id: body.id, name: body.name })}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {/* State Bodies */}
                {stateBodies.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-3 flex items-center gap-2">
                      <Badge variant="secondary">State</Badge>
                      {stateBodies.length} bodies
                    </h4>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Jurisdiction</TableHead>
                          <TableHead>Response Days</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="w-[100px]">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {stateBodies.map((body) => (
                          <TableRow key={body.id}>
                            <TableCell className="font-medium">{body.name}</TableCell>
                            <TableCell>{body.jurisdiction || "-"}</TableCell>
                            <TableCell>{body.standardResponseDays || 10} days</TableCell>
                            <TableCell>
                              <Badge variant={body.isActive ? "default" : "secondary"}>{body.isActive ? "Active" : "Inactive"}</Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => {
                                  setNewBody({
                                    name: body.name,
                                    abbreviation: body.abbreviation || "",
                                    level: body.level,
                                    jurisdiction: body.jurisdiction || "",
                                    oversightTypes: body.oversightTypes || [],
                                    enforcementScopeTags: body.enforcementScopeTags || [],
                                    standardResponseDays: body.standardResponseDays || 10,
                                    contactEmail: body.contactEmail || "",
                                    contactPhone: body.contactPhone || "",
                                    portalUrl: body.portalUrl || "",
                                    isActive: body.isActive,
                                  });
                                  setEditingBody(body.id);
                                }}>
                                  <Edit2 className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeletingBody({ id: body.id, name: body.name })}>
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}

                {/* Local Bodies */}
                {localBodies.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-3 flex items-center gap-2">
                      <Badge variant="outline">Local</Badge>
                      {localBodies.length} bodies
                    </h4>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Jurisdiction</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="w-[100px]">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {localBodies.map((body) => (
                          <TableRow key={body.id}>
                            <TableCell className="font-medium">{body.name}</TableCell>
                            <TableCell>{body.jurisdiction || "-"}</TableCell>
                            <TableCell>
                              <Badge variant={body.isActive ? "default" : "secondary"}>{body.isActive ? "Active" : "Inactive"}</Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => {
                                  setNewBody({
                                    name: body.name,
                                    abbreviation: body.abbreviation || "",
                                    level: body.level,
                                    jurisdiction: body.jurisdiction || "",
                                    oversightTypes: body.oversightTypes || [],
                                    enforcementScopeTags: body.enforcementScopeTags || [],
                                    standardResponseDays: body.standardResponseDays || 10,
                                    contactEmail: body.contactEmail || "",
                                    contactPhone: body.contactPhone || "",
                                    portalUrl: body.portalUrl || "",
                                    isActive: body.isActive,
                                  });
                                  setEditingBody(body.id);
                                }}>
                                  <Edit2 className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeletingBody({ id: body.id, name: body.name })}>
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ========== CASE TYPES TAB ========== */}
          <TabsContent value="case-types" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Case Types</CardTitle>
                  <CardDescription>Configure enforcement case type classifications and required evidence types</CardDescription>
                </div>
                <Dialog open={isAddingCaseType} onOpenChange={setIsAddingCaseType}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Case Type
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Case Type</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="caseTypeName">Name *</Label>
                        <Input
                          id="caseTypeName"
                          value={newCaseType.name}
                          onChange={(e) => setNewCaseType({ ...newCaseType, name: e.target.value })}
                          placeholder="e.g., HIPAA Violation"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="caseTypeDesc">Description</Label>
                        <Textarea
                          id="caseTypeDesc"
                          value={newCaseType.description}
                          onChange={(e) => setNewCaseType({ ...newCaseType, description: e.target.value })}
                          placeholder="Describe this case type..."
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddingCaseType(false)}>
                        Cancel
                      </Button>
                      <Button
                        onClick={() => {
                          if (!newCaseType.name) {
                            toast({ title: "Name is required", variant: "destructive" });
                            return;
                          }
                          addCaseType({ name: newCaseType.name, description: newCaseType.description, requiredEvidenceTypes: [], isActive: true });
                          toast({ title: "Case Type Added", description: `${newCaseType.name} has been added.` });
                          setNewCaseType({ name: "", description: "" });
                          setIsAddingCaseType(false);
                        }}
                      >
                        Add Type
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Edit Case Type Dialog */}
                <Dialog open={!!editingCaseType} onOpenChange={(open) => !open && setEditingCaseType(null)}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Edit Case Type</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="editCaseTypeName">Name *</Label>
                        <Input
                          id="editCaseTypeName"
                          value={newCaseType.name}
                          onChange={(e) => setNewCaseType({ ...newCaseType, name: e.target.value })}
                          placeholder="e.g., HIPAA Violation"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="editCaseTypeDesc">Description</Label>
                        <Textarea
                          id="editCaseTypeDesc"
                          value={newCaseType.description}
                          onChange={(e) => setNewCaseType({ ...newCaseType, description: e.target.value })}
                          placeholder="Describe this case type..."
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setEditingCaseType(null)}>
                        Cancel
                      </Button>
                      <Button
                        onClick={() => {
                          if (editingCaseType) {
                            updateCaseType(editingCaseType, { name: newCaseType.name, description: newCaseType.description });
                            toast({ title: "Case Type Updated", description: `${newCaseType.name} has been updated.` });
                            setEditingCaseType(null);
                            setNewCaseType({ name: "", description: "" });
                          }
                        }}
                      >
                        Save Changes
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Delete Case Type Confirmation */}
                <AlertDialog open={!!deletingCaseType} onOpenChange={(open) => !open && setDeletingCaseType(null)}>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Case Type</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete "{deletingCaseType?.name}"? This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => {
                          if (deletingCaseType) {
                            deleteCaseType(deletingCaseType.id);
                            toast({ title: "Case Type Deleted", description: `${deletingCaseType.name} has been removed.` });
                            setDeletingCaseType(null);
                          }
                        }}
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {caseTypes.map((type) => (
                    <div key={type.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <span className="font-medium">{type.name}</span>
                        {type.description && <p className="text-sm text-muted-foreground">{type.description}</p>}
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => {
                          setNewCaseType({ name: type.name, description: type.description || "" });
                          setEditingCaseType(type.id);
                        }}>
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeletingCaseType({ id: type.id, name: type.name })}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ========== PROVIDER TYPES TAB ========== */}
          <TabsContent value="provider-types" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Provider Types</CardTitle>
                  <CardDescription>Configure healthcare facility and provider type classifications</CardDescription>
                </div>
                <Dialog open={isAddingProviderType} onOpenChange={setIsAddingProviderType}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Provider Type
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Provider Type</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="providerName">Name *</Label>
                        <Input
                          id="providerName"
                          value={newProviderType.name}
                          onChange={(e) => setNewProviderType({ ...newProviderType, name: e.target.value })}
                          placeholder="e.g., Behavioral Health"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="providerDesc">Description</Label>
                        <Textarea
                          id="providerDesc"
                          value={newProviderType.description}
                          onChange={(e) => setNewProviderType({ ...newProviderType, description: e.target.value })}
                          placeholder="Describe this provider type..."
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddingProviderType(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleAddProviderType}>Add Type</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {providerTypes.map((type) => (
                    <div key={type.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <span className="font-medium">{type.name}</span>
                        {type.description && <p className="text-sm text-muted-foreground">{type.description}</p>}
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch checked={type.isActive} onCheckedChange={(checked) => setProviderTypes((prev) => prev.map((t) => (t.id === type.id ? { ...t, isActive: checked } : t)))} />
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ========== ACTION TYPES TAB ========== */}
          <TabsContent value="action-types" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Action Types Taxonomy</CardTitle>
                  <CardDescription>Configure enforcement action, remedy, and penalty type classifications</CardDescription>
                </div>
                <Dialog open={isAddingActionType} onOpenChange={setIsAddingActionType}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Action Type
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Action Type</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="actionName">Name *</Label>
                        <Input
                          id="actionName"
                          value={newActionType.name}
                          onChange={(e) => setNewActionType({ ...newActionType, name: e.target.value })}
                          placeholder="e.g., Civil Money Penalty"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="actionCategory">Category *</Label>
                        <Select
                          value={newActionType.category}
                          onValueChange={(value) => setNewActionType({ ...newActionType, category: value as typeof newActionType.category })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Financial Penalty">Financial Penalty</SelectItem>
                            <SelectItem value="Payment Remedy">Payment Remedy</SelectItem>
                            <SelectItem value="Operational Remedy">Operational Remedy</SelectItem>
                            <SelectItem value="Licensure/Restriction">Licensure/Restriction</SelectItem>
                            <SelectItem value="Monitoring/Reporting Requirement">Monitoring/Reporting</SelectItem>
                            <SelectItem value="Other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="actionDesc">Description</Label>
                        <Textarea
                          id="actionDesc"
                          value={newActionType.description}
                          onChange={(e) => setNewActionType({ ...newActionType, description: e.target.value })}
                          placeholder="Describe this action type..."
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch checked={newActionType.isDefault} onCheckedChange={(checked) => setNewActionType({ ...newActionType, isDefault: checked })} />
                        <Label>Set as default for category</Label>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddingActionType(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleAddActionType}>Add Type</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Edit Action Type Dialog */}
                <Dialog open={!!editingActionType} onOpenChange={(open) => !open && setEditingActionType(null)}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Edit Action Type</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="editActionName">Name *</Label>
                        <Input
                          id="editActionName"
                          value={newActionType.name}
                          onChange={(e) => setNewActionType({ ...newActionType, name: e.target.value })}
                          placeholder="e.g., Civil Money Penalty"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="editActionCategory">Category *</Label>
                        <Select
                          value={newActionType.category}
                          onValueChange={(value) => setNewActionType({ ...newActionType, category: value as typeof newActionType.category })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Financial Penalty">Financial Penalty</SelectItem>
                            <SelectItem value="Payment Remedy">Payment Remedy</SelectItem>
                            <SelectItem value="Operational Remedy">Operational Remedy</SelectItem>
                            <SelectItem value="Licensure/Restriction">Licensure/Restriction</SelectItem>
                            <SelectItem value="Monitoring/Reporting Requirement">Monitoring/Reporting</SelectItem>
                            <SelectItem value="Other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="editActionDesc">Description</Label>
                        <Textarea
                          id="editActionDesc"
                          value={newActionType.description}
                          onChange={(e) => setNewActionType({ ...newActionType, description: e.target.value })}
                          placeholder="Describe this action type..."
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch checked={newActionType.isDefault} onCheckedChange={(checked) => setNewActionType({ ...newActionType, isDefault: checked })} />
                        <Label>Set as default for category</Label>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setEditingActionType(null)}>
                        Cancel
                      </Button>
                      <Button onClick={() => {
                        if (editingActionType) {
                          updateActionType(editingActionType, {
                            name: newActionType.name,
                            category: newActionType.category,
                            description: newActionType.description,
                            isDefault: newActionType.isDefault,
                          });
                          toast({ title: "Action Type Updated", description: `${newActionType.name} has been updated.` });
                          setEditingActionType(null);
                          setNewActionType({ name: "", category: "Financial Penalty", description: "", isDefault: false, isActive: true });
                        }
                      }}>Save Changes</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Delete Action Type Confirmation */}
                <AlertDialog open={!!deletingActionType} onOpenChange={(open) => !open && setDeletingActionType(null)}>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Action Type</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete "{deletingActionType?.name}"? This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => {
                          if (deletingActionType) {
                            deleteActionType(deletingActionType.id);
                            toast({ title: "Action Type Deleted", description: `${deletingActionType.name} has been removed.` });
                            setDeletingActionType(null);
                          }
                        }}
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardHeader>
              <CardContent>
                {Object.entries(actionTypesByCategory).map(([category, types]) => (
                  <div key={category} className="mb-6">
                    <h4 className="font-medium mb-3 flex items-center gap-2">
                      <Badge variant="outline">{category}</Badge>
                      {types.length} types
                    </h4>
                    <div className="space-y-2">
                      {types.map((type) => (
                        <div key={type.id} className="flex items-center justify-between p-2 border rounded-lg">
                          <div className="flex items-center gap-2">
                            <span className="text-sm">{type.name}</span>
                            {type.isDefault && <Badge className="text-xs">Default</Badge>}
                          </div>
                          <div className="flex items-center gap-1">
                            <Switch checked={type.isActive} onCheckedChange={(checked) => updateActionType(type.id, { isActive: checked })} />
                            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => {
                              setNewActionType({
                                name: type.name,
                                category: type.category,
                                description: type.description || "",
                                isDefault: type.isDefault,
                                isActive: type.isActive,
                              });
                              setEditingActionType(type.id);
                            }}>
                              <Edit2 className="h-3 w-3" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => setDeletingActionType({ id: type.id, name: type.name })}>
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ========== FINDING CATEGORIES TAB ========== */}
          <TabsContent value="finding-categories" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Finding Categories</CardTitle>
                  <CardDescription>Configure deficiency and finding category classifications</CardDescription>
                </div>
                <Dialog open={isAddingCategory} onOpenChange={setIsAddingCategory}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Category
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Finding Category</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="catName">Name *</Label>
                        <Input
                          id="catName"
                          value={newCategory.name}
                          onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                          placeholder="e.g., Medication Management"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="catDesc">Description</Label>
                        <Textarea
                          id="catDesc"
                          value={newCategory.description}
                          onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
                          placeholder="Describe this category..."
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddingCategory(false)}>
                        Cancel
                      </Button>
                      <Button
                        onClick={() => {
                          if (!newCategory.name) {
                            toast({ title: "Name is required", variant: "destructive" });
                            return;
                          }
                          addFindingCategory({ name: newCategory.name, description: newCategory.description, isActive: true });
                          toast({ title: "Category Added", description: `${newCategory.name} has been added.` });
                          setNewCategory({ name: "", description: "" });
                          setIsAddingCategory(false);
                        }}
                      >
                        Add Category
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Edit Finding Category Dialog */}
                <Dialog open={!!editingCategory} onOpenChange={(open) => !open && setEditingCategory(null)}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Edit Finding Category</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="editCatName">Name *</Label>
                        <Input
                          id="editCatName"
                          value={newCategory.name}
                          onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                          placeholder="e.g., Medication Management"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="editCatDesc">Description</Label>
                        <Textarea
                          id="editCatDesc"
                          value={newCategory.description}
                          onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
                          placeholder="Describe this category..."
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setEditingCategory(null)}>
                        Cancel
                      </Button>
                      <Button onClick={() => {
                        if (editingCategory) {
                          updateFindingCategory(editingCategory, { name: newCategory.name, description: newCategory.description });
                          toast({ title: "Category Updated", description: `${newCategory.name} has been updated.` });
                          setEditingCategory(null);
                          setNewCategory({ name: "", description: "" });
                        }
                      }}>Save Changes</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Delete Finding Category Confirmation */}
                <AlertDialog open={!!deletingCategory} onOpenChange={(open) => !open && setDeletingCategory(null)}>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Finding Category</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete "{deletingCategory?.name}"? This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => {
                          if (deletingCategory) {
                            deleteFindingCategory(deletingCategory.id);
                            toast({ title: "Category Deleted", description: `${deletingCategory.name} has been removed.` });
                            setDeletingCategory(null);
                          }
                        }}
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {findingCategories.map((category) => (
                    <div key={category.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <span className="font-medium">{category.name}</span>
                        {category.description && <p className="text-sm text-muted-foreground">{category.description}</p>}
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => {
                          setNewCategory({ name: category.name, description: category.description || "" });
                          setEditingCategory(category.id);
                        }}>
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeletingCategory({ id: category.id, name: category.name })}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ========== DEADLINE RULES TAB ========== */}
          <TabsContent value="deadline-rules" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Deadline Rules</CardTitle>
                  <CardDescription>Configure automatic deadline calculations based on case type and regulatory body</CardDescription>
                </div>
                <Dialog open={isAddingDeadlineRule} onOpenChange={setIsAddingDeadlineRule}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Rule
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-lg">
                    <DialogHeader>
                      <DialogTitle>Add Deadline Rule</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Deadline Type *</Label>
                        <Select value={newDeadlineRule.deadlineType} onValueChange={(value) => setNewDeadlineRule({ ...newDeadlineRule, deadlineType: value as typeof newDeadlineRule.deadlineType })}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Response">Response</SelectItem>
                            <SelectItem value="PoC">Plan of Correction</SelectItem>
                            <SelectItem value="Appeal Filing">Appeal Filing</SelectItem>
                            <SelectItem value="Payment">Payment</SelectItem>
                            <SelectItem value="Revisit">Revisit</SelectItem>
                            <SelectItem value="Hearing">Hearing</SelectItem>
                            <SelectItem value="Other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Regulatory Body (optional)</Label>
                        <Select value={newDeadlineRule.regulatoryBodyId || "all"} onValueChange={(value) => setNewDeadlineRule({ ...newDeadlineRule, regulatoryBodyId: value === "all" ? "" : value })}>
                          <SelectTrigger>
                            <SelectValue placeholder="All bodies" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Bodies</SelectItem>
                            {regulatoryBodies.map(body => (
                              <SelectItem key={body.id} value={body.id}>{body.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Case Type (optional)</Label>
                        <Select value={newDeadlineRule.caseType || "all"} onValueChange={(value) => setNewDeadlineRule({ ...newDeadlineRule, caseType: value === "all" ? "" : value })}>
                          <SelectTrigger>
                            <SelectValue placeholder="All case types" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Case Types</SelectItem>
                            {caseTypes.map(ct => (
                              <SelectItem key={ct.id} value={ct.name}>{ct.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Default Days *</Label>
                          <Input type="number" value={newDeadlineRule.defaultDays} onChange={(e) => setNewDeadlineRule({ ...newDeadlineRule, defaultDays: parseInt(e.target.value) || 10 })} />
                        </div>
                        <div className="space-y-2">
                          <Label>Warning Days (comma-separated)</Label>
                          <Input 
                            value={newDeadlineRule.warningDays.join(", ")} 
                            onChange={(e) => setNewDeadlineRule({ ...newDeadlineRule, warningDays: e.target.value.split(",").map(s => parseInt(s.trim())).filter(n => !isNaN(n)) })} 
                            placeholder="7, 3, 1"
                          />
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch checked={newDeadlineRule.isActive} onCheckedChange={(checked) => setNewDeadlineRule({ ...newDeadlineRule, isActive: checked })} />
                        <Label>Active</Label>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddingDeadlineRule(false)}>Cancel</Button>
                      <Button onClick={() => {
                        addDeadlineRule({
                          regulatoryBodyId: newDeadlineRule.regulatoryBodyId || undefined,
                          caseType: (newDeadlineRule.caseType || undefined) as any,
                          deadlineType: newDeadlineRule.deadlineType,
                          defaultDays: newDeadlineRule.defaultDays,
                          warningDays: newDeadlineRule.warningDays,
                          escalationRecipients: [],
                          isActive: newDeadlineRule.isActive,
                        });
                        toast({ title: "Deadline Rule Added" });
                        setNewDeadlineRule({ regulatoryBodyId: "", caseType: "", deadlineType: "PoC", defaultDays: 10, warningDays: [7, 3, 1], escalationRecipients: [], isActive: true });
                        setIsAddingDeadlineRule(false);
                      }}>Add Rule</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Edit Deadline Rule Dialog */}
                <Dialog open={!!editingDeadlineRule} onOpenChange={(open) => !open && setEditingDeadlineRule(null)}>
                  <DialogContent className="max-w-lg">
                    <DialogHeader>
                      <DialogTitle>Edit Deadline Rule</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Deadline Type *</Label>
                        <Select value={newDeadlineRule.deadlineType} onValueChange={(value) => setNewDeadlineRule({ ...newDeadlineRule, deadlineType: value as typeof newDeadlineRule.deadlineType })}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Response">Response</SelectItem>
                            <SelectItem value="PoC">Plan of Correction</SelectItem>
                            <SelectItem value="Appeal Filing">Appeal Filing</SelectItem>
                            <SelectItem value="Payment">Payment</SelectItem>
                            <SelectItem value="Revisit">Revisit</SelectItem>
                            <SelectItem value="Hearing">Hearing</SelectItem>
                            <SelectItem value="Other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Regulatory Body (optional)</Label>
                        <Select value={newDeadlineRule.regulatoryBodyId || "all"} onValueChange={(value) => setNewDeadlineRule({ ...newDeadlineRule, regulatoryBodyId: value === "all" ? "" : value })}>
                          <SelectTrigger>
                            <SelectValue placeholder="All bodies" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Bodies</SelectItem>
                            {regulatoryBodies.map(body => (
                              <SelectItem key={body.id} value={body.id}>{body.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Case Type (optional)</Label>
                        <Select value={newDeadlineRule.caseType || "all"} onValueChange={(value) => setNewDeadlineRule({ ...newDeadlineRule, caseType: value === "all" ? "" : value })}>
                          <SelectTrigger>
                            <SelectValue placeholder="All case types" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Case Types</SelectItem>
                            {caseTypes.map(ct => (
                              <SelectItem key={ct.id} value={ct.name}>{ct.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Default Days *</Label>
                          <Input type="number" value={newDeadlineRule.defaultDays} onChange={(e) => setNewDeadlineRule({ ...newDeadlineRule, defaultDays: parseInt(e.target.value) || 10 })} />
                        </div>
                        <div className="space-y-2">
                          <Label>Warning Days (comma-separated)</Label>
                          <Input 
                            value={newDeadlineRule.warningDays.join(", ")} 
                            onChange={(e) => setNewDeadlineRule({ ...newDeadlineRule, warningDays: e.target.value.split(",").map(s => parseInt(s.trim())).filter(n => !isNaN(n)) })} 
                            placeholder="7, 3, 1"
                          />
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch checked={newDeadlineRule.isActive} onCheckedChange={(checked) => setNewDeadlineRule({ ...newDeadlineRule, isActive: checked })} />
                        <Label>Active</Label>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setEditingDeadlineRule(null)}>Cancel</Button>
                      <Button onClick={() => {
                        if (editingDeadlineRule) {
                          updateDeadlineRule(editingDeadlineRule, {
                            regulatoryBodyId: newDeadlineRule.regulatoryBodyId || undefined,
                            caseType: (newDeadlineRule.caseType || undefined) as any,
                            deadlineType: newDeadlineRule.deadlineType,
                            defaultDays: newDeadlineRule.defaultDays,
                            warningDays: newDeadlineRule.warningDays,
                            isActive: newDeadlineRule.isActive,
                          });
                          toast({ title: "Deadline Rule Updated" });
                          setEditingDeadlineRule(null);
                          setNewDeadlineRule({ regulatoryBodyId: "", caseType: "", deadlineType: "PoC", defaultDays: 10, warningDays: [7, 3, 1], escalationRecipients: [], isActive: true });
                        }
                      }}>Save Changes</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Delete Deadline Rule Confirmation */}
                <AlertDialog open={!!deletingDeadlineRule} onOpenChange={(open) => !open && setDeletingDeadlineRule(null)}>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Deadline Rule</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete the "{deletingDeadlineRule?.name}" rule? This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => {
                          if (deletingDeadlineRule) {
                            deleteDeadlineRule(deletingDeadlineRule.id);
                            toast({ title: "Deadline Rule Deleted" });
                            setDeletingDeadlineRule(null);
                          }
                        }}
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Deadline Type</TableHead>
                      <TableHead>Regulatory Body</TableHead>
                      <TableHead>Case Type</TableHead>
                      <TableHead>Default Days</TableHead>
                      <TableHead>Warning Days</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="w-[100px]">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {deadlineRules.map((rule) => {
                      const regBody = rule.regulatoryBodyId ? regulatoryBodies.find((b) => b.id === rule.regulatoryBodyId) : null;
                      return (
                        <TableRow key={rule.id}>
                          <TableCell className="font-medium">{rule.deadlineType}</TableCell>
                          <TableCell>{regBody?.name || "All"}</TableCell>
                          <TableCell>{rule.caseType || "All"}</TableCell>
                          <TableCell>{rule.defaultDays} days</TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              {rule.warningDays.map((d) => (
                                <Badge key={d} variant="outline" className="text-xs">
                                  {d}d
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant={rule.isActive ? "default" : "secondary"}>{rule.isActive ? "Active" : "Inactive"}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => {
                                setNewDeadlineRule({
                                  regulatoryBodyId: rule.regulatoryBodyId || "",
                                  caseType: rule.caseType || "",
                                  deadlineType: rule.deadlineType,
                                  defaultDays: rule.defaultDays,
                                  warningDays: rule.warningDays,
                                  escalationRecipients: rule.escalationRecipients as string[],
                                  isActive: rule.isActive,
                                });
                                setEditingDeadlineRule(rule.id);
                              }}>
                                <Edit2 className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeletingDeadlineRule({ id: rule.id, name: rule.deadlineType })}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ========== DOCUMENT TYPES TAB ========== */}
          <TabsContent value="document-types" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Document Types</CardTitle>
                  <CardDescription>Configure correspondence and document type classifications</CardDescription>
                </div>
                <Dialog open={isAddingDocType} onOpenChange={setIsAddingDocType}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Document Type
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Document Type</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="docTypeName">Name *</Label>
                        <Input
                          id="docTypeName"
                          value={newDocType.name}
                          onChange={(e) => setNewDocType({ ...newDocType, name: e.target.value })}
                          placeholder="e.g., Legal Filing"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="docTypeCategory">Category</Label>
                        <Select value={newDocType.category} onValueChange={(value) => setNewDocType({ ...newDocType, category: value })}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Inbound">Inbound</SelectItem>
                            <SelectItem value="Outbound">Outbound</SelectItem>
                            <SelectItem value="Both">Both</SelectItem>
                            <SelectItem value="Internal">Internal</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddingDocType(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleAddDocType}>Add Type</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {documentTypes.map((type) => (
                    <div key={type.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{type.name}</span>
                        <Badge variant="outline" className="text-xs">
                          {type.category}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch checked={type.isActive} onCheckedChange={(checked) => setDocumentTypes((prev) => prev.map((t) => (t.id === type.id ? { ...t, isActive: checked } : t)))} />
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ========== ESCALATION TAB ========== */}
          <TabsContent value="escalation" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Escalation Rules</CardTitle>
                  <CardDescription>Configure deadline warning and escalation notification rules</CardDescription>
                </div>
                <Dialog open={isAddingEscRule} onOpenChange={setIsAddingEscRule}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Rule
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Escalation Rule</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="escRuleName">Rule Name *</Label>
                        <Input
                          id="escRuleName"
                          value={newEscRule.name}
                          onChange={(e) => setNewEscRule({ ...newEscRule, name: e.target.value })}
                          placeholder="e.g., Critical Deadline Escalation"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="triggerDays">Trigger Days Before Deadline</Label>
                        <Input
                          id="triggerDays"
                          type="number"
                          value={newEscRule.triggerDays}
                          onChange={(e) => setNewEscRule({ ...newEscRule, triggerDays: parseInt(e.target.value) || 0 })}
                          placeholder="0 = on deadline day"
                        />
                        <p className="text-xs text-muted-foreground">0 = on the deadline day, negative = after deadline</p>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddingEscRule(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleAddEscRule}>Add Rule</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Edit Escalation Rule Dialog */}
                <Dialog open={!!editingEscRule} onOpenChange={(open) => !open && setEditingEscRule(null)}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Edit Escalation Rule</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="editEscRuleName">Rule Name *</Label>
                        <Input
                          id="editEscRuleName"
                          value={newEscRule.name}
                          onChange={(e) => setNewEscRule({ ...newEscRule, name: e.target.value })}
                          placeholder="e.g., Critical Deadline Escalation"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="editTriggerDays">Trigger Days Before Deadline</Label>
                        <Input
                          id="editTriggerDays"
                          type="number"
                          value={newEscRule.triggerDays}
                          onChange={(e) => setNewEscRule({ ...newEscRule, triggerDays: parseInt(e.target.value) || 0 })}
                          placeholder="0 = on deadline day"
                        />
                        <p className="text-xs text-muted-foreground">0 = on the deadline day, negative = after deadline</p>
                      </div>
                      <div className="space-y-2">
                        <Label>Recipients (comma-separated)</Label>
                        <Input
                          value={newEscRule.recipients.join(", ")}
                          onChange={(e) => setNewEscRule({ ...newEscRule, recipients: e.target.value.split(",").map(s => s.trim()).filter(Boolean) })}
                          placeholder="e.g., Assigned Owner, Department Head"
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setEditingEscRule(null)}>Cancel</Button>
                      <Button onClick={() => {
                        if (editingEscRule) {
                          setEscalationRules(prev => prev.map(r => r.id === editingEscRule ? { ...r, name: newEscRule.name, triggerDays: newEscRule.triggerDays, recipients: newEscRule.recipients } : r));
                          toast({ title: "Escalation Rule Updated" });
                          setEditingEscRule(null);
                          setNewEscRule({ name: "", triggerDays: 7, recipients: [] });
                        }
                      }}>Save Changes</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Delete Escalation Rule Confirmation */}
                <AlertDialog open={!!deletingEscRule} onOpenChange={(open) => !open && setDeletingEscRule(null)}>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Escalation Rule</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete "{deletingEscRule?.name}"? This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => {
                          if (deletingEscRule) {
                            setEscalationRules(prev => prev.filter(r => r.id !== deletingEscRule.id));
                            toast({ title: "Escalation Rule Deleted" });
                            setDeletingEscRule(null);
                          }
                        }}
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Rule Name</TableHead>
                      <TableHead>Trigger</TableHead>
                      <TableHead>Recipients</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="w-[100px]">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {escalationRules.map((rule) => (
                      <TableRow key={rule.id}>
                        <TableCell className="font-medium">{rule.name}</TableCell>
                        <TableCell>
                          {rule.triggerDays === 0 ? "On deadline" : rule.triggerDays > 0 ? `${rule.triggerDays} days before` : `${Math.abs(rule.triggerDays)} days after`}
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {rule.recipients.map((r) => (
                              <Badge key={r} variant="secondary" className="text-xs">
                                {r}
                              </Badge>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Switch checked={rule.isActive} onCheckedChange={(checked) => setEscalationRules((prev) => prev.map((r) => (r.id === rule.id ? { ...r, isActive: checked } : r)))} />
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => {
                              setNewEscRule({ name: rule.name, triggerDays: rule.triggerDays, recipients: rule.recipients });
                              setEditingEscRule(rule.id);
                            }}>
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeletingEscRule({ id: rule.id, name: rule.name })}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ========== SEVERITY LEVELS TAB ========== */}
          <TabsContent value="severity-levels" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Severity Levels</CardTitle>
                  <CardDescription>Configure case severity and impact level classifications</CardDescription>
                </div>
                <Dialog open={isAddingSeverity} onOpenChange={setIsAddingSeverity}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Level
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Severity Level</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Name *</Label>
                        <Input value={newSeverity.name} onChange={(e) => setNewSeverity({ ...newSeverity, name: e.target.value })} placeholder="e.g., Critical" />
                      </div>
                      <div className="space-y-2">
                        <Label>Color</Label>
                        <div className="flex gap-2">
                          <Input type="color" value={newSeverity.color} onChange={(e) => setNewSeverity({ ...newSeverity, color: e.target.value })} className="w-16 h-10 p-1" />
                          <Input value={newSeverity.color} onChange={(e) => setNewSeverity({ ...newSeverity, color: e.target.value })} placeholder="#ef4444" className="flex-1" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea value={newSeverity.description} onChange={(e) => setNewSeverity({ ...newSeverity, description: e.target.value })} placeholder="Describe this severity level..." />
                      </div>
                      <div className="space-y-2">
                        <Label>Weight (for sorting/priority)</Label>
                        <Input type="number" value={newSeverity.weight} onChange={(e) => setNewSeverity({ ...newSeverity, weight: parseInt(e.target.value) || 1 })} />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddingSeverity(false)}>Cancel</Button>
                      <Button onClick={() => {
                        if (!newSeverity.name) {
                          toast({ title: "Name is required", variant: "destructive" });
                          return;
                        }
                        setSeverityLevels(prev => [...prev, { id: `sev-${Date.now()}`, ...newSeverity }]);
                        toast({ title: "Severity Level Added" });
                        setNewSeverity({ name: "", color: "#22c55e", description: "", weight: 1 });
                        setIsAddingSeverity(false);
                      }}>Add Level</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Edit Severity Level Dialog */}
                <Dialog open={!!editingSeverity} onOpenChange={(open) => !open && setEditingSeverity(null)}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Edit Severity Level</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Name *</Label>
                        <Input value={newSeverity.name} onChange={(e) => setNewSeverity({ ...newSeverity, name: e.target.value })} placeholder="e.g., Critical" />
                      </div>
                      <div className="space-y-2">
                        <Label>Color</Label>
                        <div className="flex gap-2">
                          <Input type="color" value={newSeverity.color} onChange={(e) => setNewSeverity({ ...newSeverity, color: e.target.value })} className="w-16 h-10 p-1" />
                          <Input value={newSeverity.color} onChange={(e) => setNewSeverity({ ...newSeverity, color: e.target.value })} placeholder="#ef4444" className="flex-1" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea value={newSeverity.description} onChange={(e) => setNewSeverity({ ...newSeverity, description: e.target.value })} placeholder="Describe this severity level..." />
                      </div>
                      <div className="space-y-2">
                        <Label>Weight (for sorting/priority)</Label>
                        <Input type="number" value={newSeverity.weight} onChange={(e) => setNewSeverity({ ...newSeverity, weight: parseInt(e.target.value) || 1 })} />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setEditingSeverity(null)}>Cancel</Button>
                      <Button onClick={() => {
                        if (editingSeverity) {
                          setSeverityLevels(prev => prev.map(s => s.id === editingSeverity ? { ...s, ...newSeverity } : s));
                          toast({ title: "Severity Level Updated" });
                          setEditingSeverity(null);
                          setNewSeverity({ name: "", color: "#22c55e", description: "", weight: 1 });
                        }
                      }}>Save Changes</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Delete Severity Level Confirmation */}
                <AlertDialog open={!!deletingSeverity} onOpenChange={(open) => !open && setDeletingSeverity(null)}>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Severity Level</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete "{deletingSeverity?.name}"? This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => {
                          if (deletingSeverity) {
                            setSeverityLevels(prev => prev.filter(s => s.id !== deletingSeverity.id));
                            toast({ title: "Severity Level Deleted" });
                            setDeletingSeverity(null);
                          }
                        }}
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Level</TableHead>
                      <TableHead>Color</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Weight</TableHead>
                      <TableHead className="w-[100px]">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {severityLevels.map((level) => (
                      <TableRow key={level.id}>
                        <TableCell className="font-medium">{level.name}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded" style={{ backgroundColor: level.color }} />
                            <span className="text-sm text-muted-foreground">{level.color}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">{level.description}</TableCell>
                        <TableCell>{level.weight}</TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => {
                              setNewSeverity({ name: level.name, color: level.color, description: level.description, weight: level.weight });
                              setEditingSeverity(level.id);
                            }}>
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeletingSeverity({ id: level.id, name: level.name })}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ========== LIBRARY CONFIG TAB ========== */}
          <TabsContent value="library-config" className="space-y-4">
            {/* Library Settings Card */}
            <Card>
              <CardHeader>
                <CardTitle>Library Configuration</CardTitle>
                <CardDescription>Configure how the enforcement library items are managed and versioned</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Who Can Manage Library</Label>
                    <Select
                      value={localLibraryConfig.whoCanManage.includes("Admin+Compliance Head") ? "Admin+Compliance Head" : "Admin"}
                      onValueChange={(value) => setLocalLibraryConfig({ ...localLibraryConfig, whoCanManage: [value as "Admin" | "Admin+Compliance Head"] })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Admin">Admin Only</SelectItem>
                        <SelectItem value="Admin+Compliance Head">Admin + Compliance Head</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-muted-foreground">Controls who can create, edit, or delete library items</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Default Warning Thresholds (days)</Label>
                    <Input value={localLibraryConfig.defaultWarningThresholds.join(", ")} onChange={(e) => setLocalLibraryConfig({ ...localLibraryConfig, defaultWarningThresholds: e.target.value.split(",").map((s) => parseInt(s.trim())).filter((n) => !isNaN(n)) })} placeholder="7, 3, 1" />
                    <p className="text-sm text-muted-foreground">Comma-separated days before deadline to send warnings</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <Label>Allow Editing Published Items</Label>
                      <p className="text-sm text-muted-foreground">If disabled, published items must be versioned to make changes</p>
                    </div>
                    <Switch checked={localLibraryConfig.editPublishedAllowed} onCheckedChange={(checked) => setLocalLibraryConfig({ ...localLibraryConfig, editPublishedAllowed: checked })} />
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <Label>Require New Version on Change</Label>
                      <p className="text-sm text-muted-foreground">Create a new version automatically when published items are modified</p>
                    </div>
                    <Switch checked={localLibraryConfig.requireNewVersionOnChange} onCheckedChange={(checked) => setLocalLibraryConfig({ ...localLibraryConfig, requireNewVersionOnChange: checked })} />
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <Label>Hide Deprecated Items from Pickers</Label>
                      <p className="text-sm text-muted-foreground">Deprecated library items won't appear in dropdown selections</p>
                    </div>
                    <Switch checked={localLibraryConfig.hideDeprecatedFromPickers} onCheckedChange={(checked) => setLocalLibraryConfig({ ...localLibraryConfig, hideDeprecatedFromPickers: checked })} />
                  </div>
                </div>

                <Button onClick={handleSaveLibraryConfig}>Save Library Configuration</Button>
              </CardContent>
            </Card>

            {/* Remedy Library Items */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Remedy Library</CardTitle>
                  <CardDescription>Pre-defined remedy types that can be applied to enforcement cases</CardDescription>
                </div>
                <Dialog open={isAddingRemedy} onOpenChange={setIsAddingRemedy}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Remedy
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-lg">
                    <DialogHeader>
                      <DialogTitle>Add Remedy</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto">
                      <div className="space-y-2">
                        <Label>Name *</Label>
                        <Input value={newRemedy.name} onChange={(e) => setNewRemedy({ ...newRemedy, name: e.target.value })} placeholder="e.g., Civil Money Penalty" />
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea value={newRemedy.description} onChange={(e) => setNewRemedy({ ...newRemedy, description: e.target.value })} placeholder="Describe this remedy..." />
                      </div>
                      <div className="space-y-2">
                        <Label>Default Due In Days</Label>
                        <Input type="number" value={newRemedy.defaultDueInDays} onChange={(e) => setNewRemedy({ ...newRemedy, defaultDueInDays: parseInt(e.target.value) || 30 })} />
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch checked={newRemedy.isFinancial} onCheckedChange={(checked) => setNewRemedy({ ...newRemedy, isFinancial: checked })} />
                        <Label>Is Financial Remedy</Label>
                      </div>
                      <div className="space-y-2">
                        <Label>Status</Label>
                        <Select value={newRemedy.status} onValueChange={(v) => setNewRemedy({ ...newRemedy, status: v as "Draft" | "Published" | "Deprecated" })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Draft">Draft</SelectItem>
                            <SelectItem value="Published">Published</SelectItem>
                            <SelectItem value="Deprecated">Deprecated</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddingRemedy(false)}>Cancel</Button>
                      <Button onClick={() => {
                        if (!newRemedy.name) {
                          toast({ title: "Name is required", variant: "destructive" });
                          return;
                        }
                        addRemedyLibraryItem({
                          name: newRemedy.name,
                          description: newRemedy.description,
                          levelApplicability: ["Federal", "State"],
                          regulatoryBodyTags: [],
                          providerTypeApplicability: [],
                          evidenceExpectations: [],
                          defaultDueInDays: newRemedy.defaultDueInDays,
                          warningThresholds: [7, 3, 1],
                          isFinancial: newRemedy.isFinancial,
                          amountRequired: newRemedy.isFinancial,
                          operationalRequirements: [],
                          status: newRemedy.status,
                          version: 1,
                          createdBy: "Admin",
                        });
                        toast({ title: "Remedy Added" });
                        setNewRemedy({ name: "", description: "", defaultDueInDays: 30, isFinancial: false, status: "Draft" });
                        setIsAddingRemedy(false);
                      }}>Add Remedy</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Edit Remedy Dialog */}
                <Dialog open={!!editingRemedy} onOpenChange={(open) => !open && setEditingRemedy(null)}>
                  <DialogContent className="max-w-lg">
                    <DialogHeader>
                      <DialogTitle>Edit Remedy</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto">
                      <div className="space-y-2">
                        <Label>Name *</Label>
                        <Input value={newRemedy.name} onChange={(e) => setNewRemedy({ ...newRemedy, name: e.target.value })} />
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea value={newRemedy.description} onChange={(e) => setNewRemedy({ ...newRemedy, description: e.target.value })} />
                      </div>
                      <div className="space-y-2">
                        <Label>Default Due In Days</Label>
                        <Input type="number" value={newRemedy.defaultDueInDays} onChange={(e) => setNewRemedy({ ...newRemedy, defaultDueInDays: parseInt(e.target.value) || 30 })} />
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch checked={newRemedy.isFinancial} onCheckedChange={(checked) => setNewRemedy({ ...newRemedy, isFinancial: checked })} />
                        <Label>Is Financial Remedy</Label>
                      </div>
                      <div className="space-y-2">
                        <Label>Status</Label>
                        <Select value={newRemedy.status} onValueChange={(v) => setNewRemedy({ ...newRemedy, status: v as "Draft" | "Published" | "Deprecated" })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Draft">Draft</SelectItem>
                            <SelectItem value="Published">Published</SelectItem>
                            <SelectItem value="Deprecated">Deprecated</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setEditingRemedy(null)}>Cancel</Button>
                      <Button onClick={() => {
                        if (editingRemedy) {
                          updateRemedyLibraryItem(editingRemedy, {
                            name: newRemedy.name,
                            description: newRemedy.description,
                            defaultDueInDays: newRemedy.defaultDueInDays,
                            isFinancial: newRemedy.isFinancial,
                            amountRequired: newRemedy.isFinancial,
                            status: newRemedy.status,
                          });
                          toast({ title: "Remedy Updated" });
                          setEditingRemedy(null);
                          setNewRemedy({ name: "", description: "", defaultDueInDays: 30, isFinancial: false, status: "Draft" });
                        }
                      }}>Save Changes</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Delete Remedy Confirmation */}
                <AlertDialog open={!!deletingRemedy} onOpenChange={(open) => !open && setDeletingRemedy(null)}>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Remedy</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete "{deletingRemedy?.name}"? This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => {
                          if (deletingRemedy) {
                            deleteRemedyLibraryItem(deletingRemedy.id);
                            toast({ title: "Remedy Deleted" });
                            setDeletingRemedy(null);
                          }
                        }}
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Due Days</TableHead>
                      <TableHead>Financial</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="w-[100px]">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {remedyLibraryItems.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell className="text-sm max-w-[200px] truncate">{item.description}</TableCell>
                        <TableCell>{item.defaultDueInDays || "-"}</TableCell>
                        <TableCell>{item.isFinancial ? "Yes" : "No"}</TableCell>
                        <TableCell>
                          <Badge variant={item.status === "Published" ? "default" : item.status === "Draft" ? "secondary" : "outline"}>
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => {
                              setNewRemedy({ name: item.name, description: item.description, defaultDueInDays: item.defaultDueInDays || 30, isFinancial: item.isFinancial, status: item.status });
                              setEditingRemedy(item.id);
                            }}>
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeletingRemedy({ id: item.id, name: item.name })}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {/* Response Template Library Items */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Response Templates</CardTitle>
                  <CardDescription>Pre-defined response templates for correspondence</CardDescription>
                </div>
                <Dialog open={isAddingTemplate} onOpenChange={setIsAddingTemplate}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Template
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-lg">
                    <DialogHeader>
                      <DialogTitle>Add Response Template</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto">
                      <div className="space-y-2">
                        <Label>Template Name *</Label>
                        <Input value={newTemplate.templateName} onChange={(e) => setNewTemplate({ ...newTemplate, templateName: e.target.value })} placeholder="e.g., Plan of Correction Template" />
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea value={newTemplate.description} onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })} placeholder="Describe this template..." />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Regulatory Body</Label>
                          <Select value={newTemplate.regulatoryBodyId || "__any__"} onValueChange={(v) => setNewTemplate({ ...newTemplate, regulatoryBodyId: v === "__any__" ? "" : v })}>
                            <SelectTrigger><SelectValue placeholder="Select body..." /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="__any__">Any</SelectItem>
                              {regulatoryBodies.map((body) => (
                                <SelectItem key={body.id} value={body.id}>{body.abbreviation || body.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Case Type</Label>
                          <Select value={newTemplate.caseType || "__any__"} onValueChange={(v) => setNewTemplate({ ...newTemplate, caseType: v === "__any__" ? "" : v })}>
                            <SelectTrigger><SelectValue placeholder="Select type..." /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="__any__">Any</SelectItem>
                              {caseTypes.map((ct) => (
                                <SelectItem key={ct.id} value={ct.name}>{ct.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Required Sections</Label>
                        <Textarea 
                          value={newTemplate.requiredSections} 
                          onChange={(e) => setNewTemplate({ ...newTemplate, requiredSections: e.target.value })} 
                          placeholder="Enter section names, one per line (e.g., Executive Summary, Corrective Actions, Timeline)"
                          rows={3}
                        />
                        <p className="text-xs text-muted-foreground">One section name per line</p>
                      </div>
                      <div className="space-y-2">
                        <Label>Required Attachments</Label>
                        <Textarea 
                          value={newTemplate.requiredAttachments} 
                          onChange={(e) => setNewTemplate({ ...newTemplate, requiredAttachments: e.target.value })} 
                          placeholder="Enter attachment names, one per line (e.g., Policy Documents, Training Records)"
                          rows={3}
                        />
                        <p className="text-xs text-muted-foreground">One attachment name per line</p>
                      </div>
                      <div className="space-y-2">
                        <Label>Status</Label>
                        <Select value={newTemplate.status} onValueChange={(v) => setNewTemplate({ ...newTemplate, status: v as "Draft" | "Published" | "Deprecated" })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Draft">Draft</SelectItem>
                            <SelectItem value="Published">Published</SelectItem>
                            <SelectItem value="Deprecated">Deprecated</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddingTemplate(false)}>Cancel</Button>
                      <Button onClick={() => {
                        if (!newTemplate.templateName) {
                          toast({ title: "Template name is required", variant: "destructive" });
                          return;
                        }
                        const sections = newTemplate.requiredSections.split("\n").filter(s => s.trim()).map((s, i) => ({
                          id: `sec-${Date.now()}-${i}`,
                          name: s.trim(),
                          isRequired: true,
                        }));
                        const attachments = newTemplate.requiredAttachments.split("\n").filter(s => s.trim()).map((s, i) => ({
                          id: `att-${Date.now()}-${i}`,
                          name: s.trim(),
                          isRequired: true,
                        }));
                        addResponseTemplateLibraryItem({
                          templateName: newTemplate.templateName,
                          description: newTemplate.description,
                          regulatoryBodyId: newTemplate.regulatoryBodyId || undefined,
                          caseType: newTemplate.caseType as any || undefined,
                          requiredSections: sections,
                          requiredAttachments: attachments,
                          status: newTemplate.status,
                          version: 1,
                          createdBy: "Admin",
                        });
                        toast({ title: "Template Added" });
                        setNewTemplate({ templateName: "", description: "", regulatoryBodyId: "", caseType: "", requiredSections: "", requiredAttachments: "", status: "Draft" });
                        setIsAddingTemplate(false);
                      }}>Add Template</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Edit Template Dialog */}
                <Dialog open={!!editingTemplate} onOpenChange={(open) => !open && setEditingTemplate(null)}>
                  <DialogContent className="max-w-lg">
                    <DialogHeader>
                      <DialogTitle>Edit Response Template</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto">
                      <div className="space-y-2">
                        <Label>Template Name *</Label>
                        <Input value={newTemplate.templateName} onChange={(e) => setNewTemplate({ ...newTemplate, templateName: e.target.value })} />
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea value={newTemplate.description} onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })} />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Regulatory Body</Label>
                          <Select value={newTemplate.regulatoryBodyId || "__any__"} onValueChange={(v) => setNewTemplate({ ...newTemplate, regulatoryBodyId: v === "__any__" ? "" : v })}>
                            <SelectTrigger><SelectValue placeholder="Select body..." /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="__any__">Any</SelectItem>
                              {regulatoryBodies.map((body) => (
                                <SelectItem key={body.id} value={body.id}>{body.abbreviation || body.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Case Type</Label>
                          <Select value={newTemplate.caseType || "__any__"} onValueChange={(v) => setNewTemplate({ ...newTemplate, caseType: v === "__any__" ? "" : v })}>
                            <SelectTrigger><SelectValue placeholder="Select type..." /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="__any__">Any</SelectItem>
                              {caseTypes.map((ct) => (
                                <SelectItem key={ct.id} value={ct.name}>{ct.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Required Sections</Label>
                        <Textarea 
                          value={newTemplate.requiredSections} 
                          onChange={(e) => setNewTemplate({ ...newTemplate, requiredSections: e.target.value })} 
                          placeholder="Enter section names, one per line"
                          rows={3}
                        />
                        <p className="text-xs text-muted-foreground">One section name per line</p>
                      </div>
                      <div className="space-y-2">
                        <Label>Required Attachments</Label>
                        <Textarea 
                          value={newTemplate.requiredAttachments} 
                          onChange={(e) => setNewTemplate({ ...newTemplate, requiredAttachments: e.target.value })} 
                          placeholder="Enter attachment names, one per line"
                          rows={3}
                        />
                        <p className="text-xs text-muted-foreground">One attachment name per line</p>
                      </div>
                      <div className="space-y-2">
                        <Label>Status</Label>
                        <Select value={newTemplate.status} onValueChange={(v) => setNewTemplate({ ...newTemplate, status: v as "Draft" | "Published" | "Deprecated" })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Draft">Draft</SelectItem>
                            <SelectItem value="Published">Published</SelectItem>
                            <SelectItem value="Deprecated">Deprecated</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setEditingTemplate(null)}>Cancel</Button>
                      <Button onClick={() => {
                        if (editingTemplate) {
                          const sections = newTemplate.requiredSections.split("\n").filter(s => s.trim()).map((s, i) => ({
                            id: `sec-${Date.now()}-${i}`,
                            name: s.trim(),
                            isRequired: true,
                          }));
                          const attachments = newTemplate.requiredAttachments.split("\n").filter(s => s.trim()).map((s, i) => ({
                            id: `att-${Date.now()}-${i}`,
                            name: s.trim(),
                            isRequired: true,
                          }));
                          updateResponseTemplateLibraryItem(editingTemplate, {
                            templateName: newTemplate.templateName,
                            description: newTemplate.description,
                            regulatoryBodyId: newTemplate.regulatoryBodyId || undefined,
                            caseType: newTemplate.caseType as any || undefined,
                            requiredSections: sections,
                            requiredAttachments: attachments,
                            status: newTemplate.status,
                          });
                          toast({ title: "Template Updated" });
                          setEditingTemplate(null);
                          setNewTemplate({ templateName: "", description: "", regulatoryBodyId: "", caseType: "", requiredSections: "", requiredAttachments: "", status: "Draft" });
                        }
                      }}>Save Changes</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Delete Template Confirmation */}
                <AlertDialog open={!!deletingTemplate} onOpenChange={(open) => !open && setDeletingTemplate(null)}>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Template</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete "{deletingTemplate?.name}"? This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => {
                          if (deletingTemplate) {
                            deleteResponseTemplateLibraryItem(deletingTemplate.id);
                            toast({ title: "Template Deleted" });
                            setDeletingTemplate(null);
                          }
                        }}
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Template Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Version</TableHead>
                      <TableHead className="w-[100px]">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {responseTemplateLibraryItems.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.templateName}</TableCell>
                        <TableCell className="text-sm max-w-[200px] truncate">{item.description}</TableCell>
                        <TableCell>
                          <Badge variant={item.status === "Published" ? "default" : item.status === "Draft" ? "secondary" : "outline"}>
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell>v{item.version}</TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => {
                              setNewTemplate({
                                templateName: item.templateName,
                                description: item.description || "",
                                regulatoryBodyId: item.regulatoryBodyId || "",
                                caseType: item.caseType || "",
                                requiredSections: item.requiredSections?.map(s => s.name).join("\n") || "",
                                requiredAttachments: item.requiredAttachments?.map(a => a.name).join("\n") || "",
                                status: item.status,
                              });
                              setEditingTemplate(item.id);
                            }}>
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeletingTemplate({ id: item.id, name: item.templateName })}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {/* Evidence Requirements Library Items */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Evidence Requirements</CardTitle>
                  <CardDescription>Pre-defined evidence requirement checklists</CardDescription>
                </div>
                <Dialog open={isAddingEvidence} onOpenChange={setIsAddingEvidence}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Requirement
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Evidence Requirement</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Name *</Label>
                        <Input value={newEvidence.name} onChange={(e) => setNewEvidence({ ...newEvidence, name: e.target.value })} placeholder="e.g., CMP Evidence Package" />
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea value={newEvidence.description} onChange={(e) => setNewEvidence({ ...newEvidence, description: e.target.value })} placeholder="Describe this requirement..." />
                      </div>
                      <div className="space-y-2">
                        <Label>Status</Label>
                        <Select value={newEvidence.status} onValueChange={(v) => setNewEvidence({ ...newEvidence, status: v as "Draft" | "Published" | "Deprecated" })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Draft">Draft</SelectItem>
                            <SelectItem value="Published">Published</SelectItem>
                            <SelectItem value="Deprecated">Deprecated</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddingEvidence(false)}>Cancel</Button>
                      <Button onClick={() => {
                        if (!newEvidence.name) {
                          toast({ title: "Name is required", variant: "destructive" });
                          return;
                        }
                        addEvidenceRequirementLibraryItem({
                          name: newEvidence.name,
                          description: newEvidence.description,
                          evidenceChecklist: [],
                          status: newEvidence.status,
                          version: 1,
                          createdBy: "Admin",
                        });
                        toast({ title: "Evidence Requirement Added" });
                        setNewEvidence({ name: "", description: "", status: "Draft" });
                        setIsAddingEvidence(false);
                      }}>Add Requirement</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Edit Evidence Dialog */}
                <Dialog open={!!editingEvidence} onOpenChange={(open) => !open && setEditingEvidence(null)}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Edit Evidence Requirement</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Name *</Label>
                        <Input value={newEvidence.name} onChange={(e) => setNewEvidence({ ...newEvidence, name: e.target.value })} />
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea value={newEvidence.description} onChange={(e) => setNewEvidence({ ...newEvidence, description: e.target.value })} />
                      </div>
                      <div className="space-y-2">
                        <Label>Status</Label>
                        <Select value={newEvidence.status} onValueChange={(v) => setNewEvidence({ ...newEvidence, status: v as "Draft" | "Published" | "Deprecated" })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Draft">Draft</SelectItem>
                            <SelectItem value="Published">Published</SelectItem>
                            <SelectItem value="Deprecated">Deprecated</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setEditingEvidence(null)}>Cancel</Button>
                      <Button onClick={() => {
                        if (editingEvidence) {
                          updateEvidenceRequirementLibraryItem(editingEvidence, {
                            name: newEvidence.name,
                            description: newEvidence.description,
                            status: newEvidence.status,
                          });
                          toast({ title: "Evidence Requirement Updated" });
                          setEditingEvidence(null);
                          setNewEvidence({ name: "", description: "", status: "Draft" });
                        }
                      }}>Save Changes</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Delete Evidence Confirmation */}
                <AlertDialog open={!!deletingEvidence} onOpenChange={(open) => !open && setDeletingEvidence(null)}>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Evidence Requirement</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete "{deletingEvidence?.name}"? This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => {
                          if (deletingEvidence) {
                            deleteEvidenceRequirementLibraryItem(deletingEvidence.id);
                            toast({ title: "Evidence Requirement Deleted" });
                            setDeletingEvidence(null);
                          }
                        }}
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Version</TableHead>
                      <TableHead className="w-[100px]">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {evidenceRequirementLibraryItems.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell className="text-sm max-w-[200px] truncate">{item.description}</TableCell>
                        <TableCell>
                          <Badge variant={item.status === "Published" ? "default" : item.status === "Draft" ? "secondary" : "outline"}>
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell>v{item.version}</TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => {
                              setNewEvidence({ name: item.name, description: item.description || "", status: item.status });
                              setEditingEvidence(item.id);
                            }}>
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeletingEvidence({ id: item.id, name: item.name })}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {/* Finding Categories Library Items */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Finding Category Library</CardTitle>
                  <CardDescription>Pre-defined finding categories for case findings</CardDescription>
                </div>
                <Dialog open={isAddingFindingCatLib} onOpenChange={setIsAddingFindingCatLib}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Category
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Finding Category</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Name *</Label>
                        <Input value={newFindingCatLib.name} onChange={(e) => setNewFindingCatLib({ ...newFindingCatLib, name: e.target.value })} placeholder="e.g., Infection Control" />
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea value={newFindingCatLib.description} onChange={(e) => setNewFindingCatLib({ ...newFindingCatLib, description: e.target.value })} placeholder="Describe this category..." />
                      </div>
                      <div className="space-y-2">
                        <Label>Status</Label>
                        <Select value={newFindingCatLib.status} onValueChange={(v) => setNewFindingCatLib({ ...newFindingCatLib, status: v as "Draft" | "Published" | "Deprecated" })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Draft">Draft</SelectItem>
                            <SelectItem value="Published">Published</SelectItem>
                            <SelectItem value="Deprecated">Deprecated</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddingFindingCatLib(false)}>Cancel</Button>
                      <Button onClick={() => {
                        if (!newFindingCatLib.name) {
                          toast({ title: "Name is required", variant: "destructive" });
                          return;
                        }
                        addFindingCategoryLibraryItem({
                          name: newFindingCatLib.name,
                          description: newFindingCatLib.description,
                          typicalCitations: [],
                          applicableCaseTypes: [],
                          status: newFindingCatLib.status,
                          createdBy: "Admin",
                        });
                        toast({ title: "Finding Category Added" });
                        setNewFindingCatLib({ name: "", description: "", status: "Draft" });
                        setIsAddingFindingCatLib(false);
                      }}>Add Category</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Edit Finding Category Dialog */}
                <Dialog open={!!editingFindingCatLib} onOpenChange={(open) => !open && setEditingFindingCatLib(null)}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Edit Finding Category</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Name *</Label>
                        <Input value={newFindingCatLib.name} onChange={(e) => setNewFindingCatLib({ ...newFindingCatLib, name: e.target.value })} />
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea value={newFindingCatLib.description} onChange={(e) => setNewFindingCatLib({ ...newFindingCatLib, description: e.target.value })} />
                      </div>
                      <div className="space-y-2">
                        <Label>Status</Label>
                        <Select value={newFindingCatLib.status} onValueChange={(v) => setNewFindingCatLib({ ...newFindingCatLib, status: v as "Draft" | "Published" | "Deprecated" })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Draft">Draft</SelectItem>
                            <SelectItem value="Published">Published</SelectItem>
                            <SelectItem value="Deprecated">Deprecated</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setEditingFindingCatLib(null)}>Cancel</Button>
                      <Button onClick={() => {
                        if (editingFindingCatLib) {
                          updateFindingCategoryLibraryItem(editingFindingCatLib, {
                            name: newFindingCatLib.name,
                            description: newFindingCatLib.description,
                            status: newFindingCatLib.status,
                          });
                          toast({ title: "Finding Category Updated" });
                          setEditingFindingCatLib(null);
                          setNewFindingCatLib({ name: "", description: "", status: "Draft" });
                        }
                      }}>Save Changes</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Delete Finding Category Confirmation */}
                <AlertDialog open={!!deletingFindingCatLib} onOpenChange={(open) => !open && setDeletingFindingCatLib(null)}>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Finding Category</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete "{deletingFindingCatLib?.name}"? This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => {
                          if (deletingFindingCatLib) {
                            deleteFindingCategoryLibraryItem(deletingFindingCatLib.id);
                            toast({ title: "Finding Category Deleted" });
                            setDeletingFindingCatLib(null);
                          }
                        }}
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="w-[100px]">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {findingCategoryLibraryItems.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell className="text-sm max-w-[200px] truncate">{item.description}</TableCell>
                        <TableCell>
                          <Badge variant={item.status === "Published" ? "default" : item.status === "Draft" ? "secondary" : "outline"}>
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => {
                              setNewFindingCatLib({ name: item.name, description: item.description || "", status: item.status });
                              setEditingFindingCatLib(item.id);
                            }}>
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeletingFindingCatLib({ id: item.id, name: item.name })}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ========== GENERAL SETTINGS TAB ========== */}
          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>General Settings</CardTitle>
                <CardDescription>Configure EnforcePoint system behavior and defaults</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Default Response Timeline (days)</Label>
                    <Input type="number" value={generalSettings.defaultResponseDays} onChange={(e) => setGeneralSettings({ ...generalSettings, defaultResponseDays: parseInt(e.target.value) || 10 })} className="w-32" />
                    <p className="text-sm text-muted-foreground">Default days for response due date from notice receipt</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Deadline Warning Threshold (days)</Label>
                    <Input type="number" value={generalSettings.deadlineWarningDays} onChange={(e) => setGeneralSettings({ ...generalSettings, deadlineWarningDays: parseInt(e.target.value) || 7 })} className="w-32" />
                    <p className="text-sm text-muted-foreground">Show warning when deadline is within this many days</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Auto-Close Cases After (days)</Label>
                    <Input type="number" value={generalSettings.autoCloseAfterDays} onChange={(e) => setGeneralSettings({ ...generalSettings, autoCloseAfterDays: parseInt(e.target.value) || 90 })} className="w-32" />
                    <p className="text-sm text-muted-foreground">Auto-close resolved cases after this many days of inactivity</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <Label>Allow Staff CSV Export</Label>
                      <p className="text-sm text-muted-foreground">Allow staff to export case data to CSV</p>
                    </div>
                    <Switch checked={generalSettings.allowCsvExport} onCheckedChange={(checked) => setGeneralSettings({ ...generalSettings, allowCsvExport: checked })} />
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <Label>Require Approval for Submission</Label>
                      <p className="text-sm text-muted-foreground">Response packages require department and compliance head approval</p>
                    </div>
                    <Switch checked={generalSettings.requireApprovalForSubmission} onCheckedChange={(checked) => setGeneralSettings({ ...generalSettings, requireApprovalForSubmission: checked })} />
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <Label>Enable Audit Log</Label>
                      <p className="text-sm text-muted-foreground">Track all case changes with user and timestamp</p>
                    </div>
                    <Switch checked={generalSettings.enableAuditLog} onCheckedChange={(checked) => setGeneralSettings({ ...generalSettings, enableAuditLog: checked })} />
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <Label>Enable Email Notifications</Label>
                      <p className="text-sm text-muted-foreground">Send email notifications for deadlines and escalations</p>
                    </div>
                    <Switch checked={generalSettings.enableNotifications} onCheckedChange={(checked) => setGeneralSettings({ ...generalSettings, enableNotifications: checked })} />
                  </div>
                </div>

                <Button onClick={handleSaveGeneralSettings}>Save Settings</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
