import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useEnforcePoint } from "@/context/EnforcePointContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Download, BarChart3, PieChart, TrendingUp, Clock } from "lucide-react";
import { format, isPast, differenceInDays } from "date-fns";

export default function ReportsPage() {
  const { cases, actions, deadlines, regulatoryBodies, findings } = useEnforcePoint();
  const [reportType, setReportType] = useState("cases-by-body");

  // Cases by regulatory body
  const casesByBody = regulatoryBodies.map((body) => ({
    body: body.name,
    level: body.level,
    count: cases.filter((c) => c.regulatoryBodyId === body.id).length,
    open: cases.filter((c) => c.regulatoryBodyId === body.id && !['Closed', 'Draft'].includes(c.status)).length,
  })).filter((item) => item.count > 0);

  // Cases by severity
  const casesBySeverity = ['Critical', 'High', 'Medium', 'Low'].map((severity) => ({
    severity,
    count: cases.filter((c) => c.severity === severity).length,
    open: cases.filter((c) => c.severity === severity && !['Closed', 'Draft'].includes(c.status)).length,
  }));

  // Upcoming/overdue deadlines
  const deadlineStatus = {
    overdue: deadlines.filter((d) => !d.isCompleted && isPast(new Date(d.dueDate))).length,
    dueThisWeek: deadlines.filter((d) => {
      if (d.isCompleted) return false;
      const days = differenceInDays(new Date(d.dueDate), new Date());
      return days >= 0 && days <= 7;
    }).length,
    upcoming: deadlines.filter((d) => {
      if (d.isCompleted) return false;
      const days = differenceInDays(new Date(d.dueDate), new Date());
      return days > 7;
    }).length,
    completed: deadlines.filter((d) => d.isCompleted).length,
  };

  // Total penalties
  const totalPenalties = actions
    .filter((a) => a.actionCategory === 'Financial Penalty' && a.amount)
    .reduce((sum, a) => sum + (a.amount || 0), 0);

  // Top finding categories
  const findingCategories = findings.reduce((acc, f) => {
    acc[f.category] = (acc[f.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const topCategories = Object.entries(findingCategories)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  const handleExport = (type: string) => {
    let csv = '';
    let filename = '';

    switch (type) {
      case 'cases-by-body':
        csv = 'Regulatory Body,Level,Total Cases,Open Cases\n' +
          casesByBody.map((r) => `${r.body},${r.level},${r.count},${r.open}`).join('\n');
        filename = 'cases-by-regulatory-body';
        break;
      case 'cases-by-severity':
        csv = 'Severity,Total Cases,Open Cases\n' +
          casesBySeverity.map((r) => `${r.severity},${r.count},${r.open}`).join('\n');
        filename = 'cases-by-severity';
        break;
      case 'deadlines':
        csv = 'Status,Count\n' +
          `Overdue,${deadlineStatus.overdue}\nDue This Week,${deadlineStatus.dueThisWeek}\nUpcoming,${deadlineStatus.upcoming}\nCompleted,${deadlineStatus.completed}`;
        filename = 'deadline-status';
        break;
      case 'penalties':
        csv = 'Case ID,Action Type,Amount,Status\n' +
          actions.filter((a) => a.amount).map((a) => {
            const c = cases.find((c) => c.id === a.caseId);
            return `${c?.caseNumber || 'Unknown'},${a.actionTypeName},${a.amount},${a.status}`;
          }).join('\n');
        filename = 'penalties';
        break;
      default:
        return;
    }

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${filename}-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    anchor.click();
  };

  return (
    <AppLayout breadcrumbs={[{ label: "Enforcement", href: "/enforcement" }, { label: "Reports" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Enforcement Reports</h1>
            <p className="text-muted-foreground">
              Analytics and insights for enforcement cases
            </p>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Cases</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{cases.length}</div>
              <p className="text-xs text-muted-foreground">
                {cases.filter((c) => !['Closed', 'Draft'].includes(c.status)).length} open
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Penalties</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalPenalties.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">All financial penalties</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Overdue Deadlines</CardTitle>
              <Clock className="h-4 w-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">{deadlineStatus.overdue}</div>
              <p className="text-xs text-muted-foreground">Require attention</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Findings</CardTitle>
              <PieChart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{findings.length}</div>
              <p className="text-xs text-muted-foreground">Documented deficiencies</p>
            </CardContent>
          </Card>
        </div>

        {/* Report Selection */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Report Data</CardTitle>
                <CardDescription>Select a report to view and export</CardDescription>
              </div>
              <div className="flex gap-2">
                <Select value={reportType} onValueChange={setReportType}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Select report" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cases-by-body">Cases by Regulatory Body</SelectItem>
                    <SelectItem value="cases-by-severity">Cases by Severity</SelectItem>
                    <SelectItem value="deadlines">Deadline Status</SelectItem>
                    <SelectItem value="penalties">Penalties & Actions</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" onClick={() => handleExport(reportType)}>
                  <Download className="mr-2 h-4 w-4" />
                  Export CSV
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {reportType === 'cases-by-body' && (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Regulatory Body</TableHead>
                    <TableHead>Level</TableHead>
                    <TableHead className="text-right">Total Cases</TableHead>
                    <TableHead className="text-right">Open Cases</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {casesByBody.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                        No data available
                      </TableCell>
                    </TableRow>
                  ) : (
                    casesByBody.map((row) => (
                      <TableRow key={row.body}>
                        <TableCell className="font-medium">{row.body}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{row.level}</Badge>
                        </TableCell>
                        <TableCell className="text-right">{row.count}</TableCell>
                        <TableCell className="text-right">{row.open}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}

            {reportType === 'cases-by-severity' && (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Severity</TableHead>
                    <TableHead className="text-right">Total Cases</TableHead>
                    <TableHead className="text-right">Open Cases</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {casesBySeverity.map((row) => (
                    <TableRow key={row.severity}>
                      <TableCell>
                        <Badge
                          variant="secondary"
                          className={
                            row.severity === 'Critical'
                              ? 'bg-destructive text-destructive-foreground'
                              : row.severity === 'High'
                              ? 'bg-warning text-warning-foreground'
                              : row.severity === 'Medium'
                              ? 'bg-info text-info-foreground'
                              : 'bg-muted text-muted-foreground'
                          }
                        >
                          {row.severity}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">{row.count}</TableCell>
                      <TableCell className="text-right">{row.open}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}

            {reportType === 'deadlines' && (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Count</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>
                      <Badge variant="destructive">Overdue</Badge>
                    </TableCell>
                    <TableCell className="text-right font-medium">{deadlineStatus.overdue}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      <Badge className="bg-warning text-warning-foreground">Due This Week</Badge>
                    </TableCell>
                    <TableCell className="text-right font-medium">{deadlineStatus.dueThisWeek}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      <Badge variant="outline">Upcoming</Badge>
                    </TableCell>
                    <TableCell className="text-right font-medium">{deadlineStatus.upcoming}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>
                      <Badge className="bg-success text-success-foreground">Completed</Badge>
                    </TableCell>
                    <TableCell className="text-right font-medium">{deadlineStatus.completed}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            )}

            {reportType === 'penalties' && (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Case</TableHead>
                    <TableHead>Action Type</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {actions.filter((a) => a.amount).length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                        No financial penalties recorded
                      </TableCell>
                    </TableRow>
                  ) : (
                    actions.filter((a) => a.amount).map((action) => {
                      const caseItem = cases.find((c) => c.id === action.caseId);
                      return (
                        <TableRow key={action.id}>
                          <TableCell className="font-medium">{caseItem?.title || 'Unknown'}</TableCell>
                          <TableCell>{action.actionTypeName}</TableCell>
                          <TableCell className="text-right">${action.amount?.toLocaleString()}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{action.status}</Badge>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Top Finding Categories */}
        <Card>
          <CardHeader>
            <CardTitle>Top Finding Categories</CardTitle>
            <CardDescription>Most common deficiency categories</CardDescription>
          </CardHeader>
          <CardContent>
            {topCategories.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                No findings recorded yet
              </p>
            ) : (
              <div className="space-y-3">
                {topCategories.map(([category, count]) => (
                  <div key={category} className="flex items-center justify-between">
                    <span className="font-medium">{category}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-32 bg-muted rounded-full h-2">
                        <div
                          className="bg-primary rounded-full h-2"
                          style={{ width: `${(count / Math.max(...topCategories.map(([, c]) => c))) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm text-muted-foreground w-8">{count}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
