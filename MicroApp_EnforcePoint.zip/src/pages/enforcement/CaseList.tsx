import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { AppLayout } from "@/components/layout/AppLayout";
import { useEnforcePoint } from "@/context/EnforcePointContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Plus, Search, Download, ChevronDown, ChevronRight, FileText, ClipboardList, ArrowRight, Info, Gavel } from "lucide-react";
import { Link } from "react-router-dom";
import { format } from "date-fns";
import { IntakeStatus, OperationalStatus, EnforcementCase } from "@/types/enforcepoint";

const formatStageLabel = (value?: string) => {
  if (!value) return "-";
  return String(value).replace(/_/g, " ").replace(/^[A-Z]\d+\s/, "");
};

const intakeStages: { key: IntakeStatus; label: string; description: string }[] = [
  { key: "I0_Draft", label: "I0 - Draft", description: "Initial case draft, not yet logged" },
  { key: "I1_Notice_Logged", label: "I1 - Notice Logged", description: "Notice received and logged into system" },
  { key: "I2_Triage_Assignment", label: "I2 - Triage & Assignment", description: "Case being triaged and assigned to owners" },
  { key: "I3_Ready_For_Management", label: "I3 - Ready for Management", description: "Intake complete, ready for operational management" },
];

const operationalStages: { key: OperationalStatus; label: string; description: string }[] = [
  { key: "O0_Not_Started", label: "O0 - Not Started", description: "Operational phase not yet begun" },
  { key: "O1_Response_Planning", label: "O1 - Response Planning", description: "Planning response strategy and actions" },
  { key: "O2_Remediation_Linked", label: "O2 - Remediation Linked", description: "Remediation actions linked to findings" },
  { key: "O3_Response_In_Progress", label: "O3 - Response In Progress", description: "Active work on response package" },
  { key: "O4_Submitted_Awaiting", label: "O4 - Submitted / Awaiting", description: "Response submitted, awaiting determination" },
  { key: "O5_Remedies_Active", label: "O5 - Remedies Active", description: "Remedies imposed and being executed" },
  { key: "O6_Verification_Revisit", label: "O6 - Verification / Revisit", description: "Verification activities or revisit surveys" },
  { key: "O7_Closed", label: "O7 - Closed", description: "Case closed and archived" },
  { key: "O8_Reopened", label: "O8 - Reopened", description: "Previously closed case reopened" },
];

export default function CaseList() {
  const navigate = useNavigate();
  const { cases, regulatoryBodies, appeals } = useEnforcePoint();
  const [searchTerm, setSearchTerm] = useState("");
  const [expandedIntake, setExpandedIntake] = useState<string[]>(["I0_Draft", "I1_Notice_Logged", "I2_Triage_Assignment"]);
  const [expandedOps, setExpandedOps] = useState<string[]>(["O1_Response_Planning", "O3_Response_In_Progress", "O5_Remedies_Active"]);

  const filteredCases = cases.filter((c) => {
    const matchesSearch =
      c.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.caseNumber.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const getCasesByIntakeStatus = (status: IntakeStatus) => {
    return filteredCases.filter((c) => c.intakeStatus === status);
  };

  const getCasesByOperationalStatus = (status: OperationalStatus) => {
    return filteredCases.filter((c) => c.caseStatus === status && c.intakeStatus === "I3_Ready_For_Management");
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "Critical":
        return "bg-destructive text-destructive-foreground";
      case "High":
        return "bg-warning text-warning-foreground";
      case "Medium":
        return "bg-info text-info-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getRegulatoryBodyName = (id: string) => {
    const body = regulatoryBodies.find((b) => b.id === id);
    return body?.abbreviation || body?.name || "Unknown";
  };

  const hasActiveAppeal = (caseId: string) => {
    return appeals.some((a) => a.caseId === caseId && a.outcome === 'Pending');
  };

  const handleExportCSV = () => {
    const headers = ["Case Number", "Title", "Type", "Regulatory Body", "Severity", "Intake Status", "Operational Status", "Response Due"];
    const rows = filteredCases.map((c) => [
      c.caseNumber,
      c.title,
      c.caseType,
      getRegulatoryBodyName(c.regulatoryBodyId),
      c.severity,
      c.intakeStatus || "",
      c.caseStatus || "",
      c.responseDueDate ? format(new Date(c.responseDueDate), "yyyy-MM-dd") : "",
    ]);
    
    const csv = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `enforcement-cases-${format(new Date(), "yyyy-MM-dd")}.csv`;
    anchor.click();
  };

  const toggleIntakeExpand = (key: string) => {
    setExpandedIntake((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  const toggleOpsExpand = (key: string) => {
    setExpandedOps((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  const CaseCard = ({ caseItem }: { caseItem: EnforcementCase }) => (
    <div
      className="p-3 border rounded-lg bg-card hover:bg-accent/50 cursor-pointer transition-colors"
      onClick={() => navigate(`/enforcement/cases/${caseItem.id}`)}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium text-primary text-sm">{caseItem.caseNumber}</span>
            {caseItem.immediateJeopardy && (
              <Badge variant="destructive" className="text-xs">IJ</Badge>
            )}
            {hasActiveAppeal(caseItem.id) && (
              <Badge variant="outline" className="text-xs bg-warning/10 text-warning border-warning/30 gap-1">
                <Gavel className="h-3 w-3" />
                Appeal
              </Badge>
            )}
          </div>
          <p className="text-sm text-foreground truncate mt-0.5">{caseItem.title}</p>
          <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
            <span>{getRegulatoryBodyName(caseItem.regulatoryBodyId)}</span>
            <span>•</span>
            <span>{caseItem.assignedOwnerName || "Unassigned"}</span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
          <Badge className={getSeverityColor(caseItem.severity)} variant="secondary">
            {caseItem.severity}
          </Badge>
          {caseItem.responseDueDate && (
            <span className="text-xs text-muted-foreground">
              Due {format(new Date(caseItem.responseDueDate), "MMM d")}
            </span>
          )}
        </div>
      </div>
    </div>
  );

  const StageSection = ({
    stage,
    cases,
    isExpanded,
    onToggle,
    stageType,
  }: {
    stage: { key: string; label: string; description: string };
    cases: EnforcementCase[];
    isExpanded: boolean;
    onToggle: () => void;
    stageType: "intake" | "operational";
  }) => (
    <Collapsible open={isExpanded} onOpenChange={onToggle}>
      <CollapsibleTrigger asChild>
        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted cursor-pointer transition-colors">
          <div className="flex items-center gap-3">
            {isExpanded ? (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            )}
            <div>
              <span className="font-medium">{stage.label}</span>
              <p className="text-xs text-muted-foreground">{stage.description}</p>
            </div>
          </div>
          <Badge variant="secondary" className="ml-2">
            {cases.length}
          </Badge>
        </div>
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="pl-7 pt-2 space-y-2">
          {cases.length === 0 ? (
            <p className="text-sm text-muted-foreground py-2">No cases in this stage</p>
          ) : (
            cases.map((c) => <CaseCard key={c.id} caseItem={c} />)
          )}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );

  // Count cases in each lifecycle
  const intakeCasesCount = intakeStages
    .filter((s) => s.key !== "I3_Ready_For_Management")
    .reduce((sum, s) => sum + getCasesByIntakeStatus(s.key).length, 0);
  const opsCasesCount = operationalStages.reduce(
    (sum, s) => sum + getCasesByOperationalStatus(s.key).length,
    0
  );

  return (
    <AppLayout breadcrumbs={[{ label: "Enforcement", href: "/enforcement" }, { label: "Cases" }]}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Enforcement Cases</h1>
            <p className="text-muted-foreground">
              Dual lifecycle management: Case Creation → Case Management
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleExportCSV}>
              <Download className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
            <Button asChild>
              <Link to="/enforcement/cases/new">
                <Plus className="mr-2 h-4 w-4" />
                New Case
              </Link>
            </Button>
          </div>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search cases by number or title..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Case Creation (Intake Lifecycle) */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                <CardTitle>Case Creation</CardTitle>
              </div>
              <CardDescription>
                Intake lifecycle: Draft → Notice Logged → Triage → Ready for Management
              </CardDescription>
              <Badge variant="outline" className="w-fit mt-2">
                {intakeCasesCount} active cases
              </Badge>
            </CardHeader>
            <CardContent className="space-y-2">
              {intakeStages
                .filter((s) => s.key !== "I3_Ready_For_Management")
                .map((stage) => (
                  <StageSection
                    key={stage.key}
                    stage={stage}
                    cases={getCasesByIntakeStatus(stage.key)}
                    isExpanded={expandedIntake.includes(stage.key)}
                    onToggle={() => toggleIntakeExpand(stage.key)}
                    stageType="intake"
                  />
                ))}
              
              {/* Transition Gate Callout */}
              <div className="mt-4 p-3 rounded-lg border-2 border-dashed border-primary/30 bg-primary/5">
                <div className="flex items-center gap-2 text-sm">
                  <ArrowRight className="h-4 w-4 text-primary" />
                  <span className="font-medium text-primary">I3 - Ready for Management</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1 ml-6">
                  After completing Triage & Assignment, cases transition here and move to Case Management →
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Case Management (Operational Lifecycle) */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <ClipboardList className="h-5 w-5 text-primary" />
                <CardTitle>Case Management</CardTitle>
              </div>
              <CardDescription>
                Operational lifecycle: Response Planning → Remediation → Verification → Closed
              </CardDescription>
              <Badge variant="outline" className="w-fit mt-2">
                {opsCasesCount} active cases
              </Badge>
            </CardHeader>
            <CardContent className="space-y-2">
              {operationalStages.map((stage) => (
                <StageSection
                  key={stage.key}
                  stage={stage}
                  cases={getCasesByOperationalStatus(stage.key)}
                  isExpanded={expandedOps.includes(stage.key)}
                  onToggle={() => toggleOpsExpand(stage.key)}
                  stageType="operational"
                />
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
