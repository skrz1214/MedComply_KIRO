import { useParams, useNavigate } from 'react-router-dom';
import { useEnforcement } from '@/context/EnforcementContext';
import { Header } from '@/components/layout/Header';
import { EnforcementForm } from '@/components/enforcement/EnforcementForm';
import { toast } from '@/hooks/use-toast';

const EditEnforcement = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getEnforcementById, updateEnforcement } = useEnforcement();

  const enforcement = id ? getEnforcementById(id) : undefined;

  if (!enforcement) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container px-4 py-8 md:px-6">
          <div className="text-center py-16">
            <h2 className="text-2xl font-semibold text-foreground mb-2">Enforcement Not Found</h2>
            <p className="text-muted-foreground mb-4">The enforcement you're trying to edit doesn't exist.</p>
            <button 
              onClick={() => navigate('/enforcements')}
              className="text-primary hover:underline"
            >
              Back to Enforcements
            </button>
          </div>
        </main>
      </div>
    );
  }

  const handleSubmit = (data: Parameters<typeof updateEnforcement>[1]) => {
    updateEnforcement(enforcement.id, data);
    toast({
      title: 'Enforcement Updated',
      description: 'The enforcement has been successfully updated.',
    });
    navigate(`/enforcements/${enforcement.id}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8 md:px-6 max-w-3xl">
        <EnforcementForm
          enforcement={enforcement}
          onSubmit={handleSubmit}
          onCancel={() => navigate(-1)}
          mode="edit"
        />
      </main>
    </div>
  );
};

export default EditEnforcement;
