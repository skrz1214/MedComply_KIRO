import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useEnforcement } from '@/context/EnforcementContext';
import { Header } from '@/components/layout/Header';
import { EnforcementCard } from '@/components/enforcement/EnforcementCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Search, Shield, XCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const Enforcements = () => {
  const { enforcements, deleteEnforcement } = useEnforcement();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const activeEnforcements = enforcements.filter(e => e.status === 'Active');
  const deletedEnforcements = enforcements.filter(e => e.status === 'Deleted');

  const filterEnforcements = (list: typeof enforcements) => {
    if (!searchQuery) return list;
    const query = searchQuery.toLowerCase();
    return list.filter(e => 
      e.referenceNumber.toLowerCase().includes(query) ||
      e.description.toLowerCase().includes(query) ||
      e.governingBody.toLowerCase().includes(query)
    );
  };

  const handleDelete = () => {
    if (deleteId) {
      deleteEnforcement(deleteId);
      setDeleteId(null);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8 md:px-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground mb-1">
              Enforcements
            </h1>
            <p className="text-muted-foreground">
              View and manage all enforcement actions.
            </p>
          </div>
          <Link to="/enforcements/new">
            <Button size="lg" className="gap-2 shadow-md">
              <Plus className="h-5 w-5" />
              Add New Enforcement
            </Button>
          </Link>
        </div>

        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search enforcements..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <Tabs defaultValue="active" className="space-y-6">
          <TabsList className="bg-muted/50 p-1">
            <TabsTrigger value="active" className="gap-2 data-[state=active]:bg-card">
              <Shield className="h-4 w-4" />
              Active ({activeEnforcements.length})
            </TabsTrigger>
            <TabsTrigger value="deleted" className="gap-2 data-[state=active]:bg-card">
              <XCircle className="h-4 w-4" />
              Deleted ({deletedEnforcements.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="space-y-4">
            {filterEnforcements(activeEnforcements).length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2">
                {filterEnforcements(activeEnforcements).map((enforcement) => (
                  <EnforcementCard
                    key={enforcement.id}
                    enforcement={enforcement}
                    onView={(id) => navigate(`/enforcements/${id}`)}
                    onEdit={(id) => navigate(`/enforcements/${id}/edit`)}
                    onDelete={(id) => setDeleteId(id)}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-muted/30 rounded-lg border border-dashed border-border">
                <Shield className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                <h3 className="font-medium text-foreground mb-2">No Active Enforcements</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {searchQuery ? 'No results match your search.' : 'Get started by creating a new enforcement action.'}
                </p>
                {!searchQuery && (
                  <Link to="/enforcements/new">
                    <Button variant="outline">
                      Create New Enforcement
                    </Button>
                  </Link>
                )}
              </div>
            )}
          </TabsContent>

          <TabsContent value="deleted" className="space-y-4">
            {filterEnforcements(deletedEnforcements).length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2">
                {filterEnforcements(deletedEnforcements).map((enforcement) => (
                  <EnforcementCard
                    key={enforcement.id}
                    enforcement={enforcement}
                    onView={(id) => navigate(`/enforcements/${id}`)}
                    onEdit={() => {}}
                    onDelete={() => {}}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-muted/30 rounded-lg border border-dashed border-border">
                <XCircle className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                <h3 className="font-medium text-foreground mb-2">No Deleted Enforcements</h3>
                <p className="text-sm text-muted-foreground">
                  {searchQuery ? 'No results match your search.' : 'Deleted enforcements will appear here.'}
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Enforcement?</AlertDialogTitle>
            <AlertDialogDescription>
              This will mark the enforcement as deleted. It will be removed from the active view but can still be accessed in the Deleted tab.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Enforcements;
