import { useEnforcement } from '@/context/EnforcementContext';
import { Header } from '@/components/layout/Header';
import { StatsCard } from '@/components/dashboard/StatsCard';
import { EnforcementCard } from '@/components/enforcement/EnforcementCard';
import { TodoCard } from '@/components/enforcement/TodoCard';
import { Button } from '@/components/ui/button';
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Plus,
  ArrowRight,
  DollarSign
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

const Index = () => {
  const { enforcements, todoItems } = useEnforcement();
  const navigate = useNavigate();

  const activeEnforcements = enforcements.filter(e => e.status !== 'Deleted');
  const criticalCount = activeEnforcements.filter(e => e.impactLevel === 'Critical').length;
  const overdueCount = activeEnforcements.filter(e => e.paymentStatus === 'Overdue').length;
  const unprocessedTodos = todoItems.filter(t => !t.isProcessed);

  const totalPenalties = activeEnforcements.reduce((sum, e) => sum + e.penaltyAmount, 0);

  const recentEnforcements = activeEnforcements.slice(0, 3);
  const recentTodos = unprocessedTodos.slice(0, 2);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8 md:px-6">
        <section className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-foreground mb-1">
                EnforcePoint Dashboard
              </h1>
              <p className="text-muted-foreground">
                Manage enforcement actions and penalties across your organization.
              </p>
            </div>
            <Link to="/enforcements/new">
              <Button size="lg" className="gap-2 shadow-md">
                <Plus className="h-5 w-5" />
                Add New Enforcement
              </Button>
            </Link>
          </div>
        </section>

        <section className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <StatsCard
            title="Active Enforcements"
            value={activeEnforcements.length}
            description="Total active items"
            icon={Shield}
            variant="primary"
          />
          <StatsCard
            title="Total Penalties"
            value={formatCurrency(totalPenalties)}
            description="Combined fine amount"
            icon={DollarSign}
            variant="warning"
          />
          <StatsCard
            title="Critical Impact"
            value={criticalCount}
            description="Requires immediate action"
            icon={AlertTriangle}
            variant="destructive"
          />
          <StatsCard
            title="Pending To Do"
            value={unprocessedTodos.length}
            description="From ComplianceConnect"
            icon={Clock}
            variant="accent"
          />
        </section>

        <div className="grid gap-8 lg:grid-cols-3">
          <section className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-foreground">Recent Enforcements</h2>
              <Link to="/enforcements">
                <Button variant="ghost" size="sm" className="gap-1 text-muted-foreground hover:text-foreground">
                  View All
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </div>
            <div className="space-y-4">
              {recentEnforcements.length > 0 ? (
                recentEnforcements.map((enforcement) => (
                  <EnforcementCard
                    key={enforcement.id}
                    enforcement={enforcement}
                    onView={(id) => navigate(`/enforcements/${id}`)}
                    onEdit={(id) => navigate(`/enforcements/${id}/edit`)}
                    onDelete={(id) => navigate(`/enforcements/${id}?action=delete`)}
                  />
                ))
              ) : (
                <div className="text-center py-12 bg-muted/30 rounded-lg border border-dashed border-border">
                  <CheckCircle className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                  <h3 className="font-medium text-foreground mb-2">No Active Enforcements</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    All enforcement actions have been completed.
                  </p>
                  <Link to="/enforcements/new">
                    <Button variant="outline" size="sm">
                      Create New Enforcement
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </section>

          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-foreground">To Do</h2>
              <Link to="/todo">
                <Button variant="ghost" size="sm" className="gap-1 text-muted-foreground hover:text-foreground">
                  View All
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </div>
            <div className="space-y-4">
              {recentTodos.length > 0 ? (
                recentTodos.map((todo) => (
                  <TodoCard
                    key={todo.id}
                    todo={todo}
                    onProcess={(todoId) => navigate(`/enforcements/new?todoId=${todoId}`)}
                  />
                ))
              ) : (
                <div className="text-center py-12 bg-muted/30 rounded-lg border border-dashed border-border">
                  <CheckCircle className="h-10 w-10 text-success/50 mx-auto mb-3" />
                  <h3 className="font-medium text-foreground mb-1">All Caught Up!</h3>
                  <p className="text-sm text-muted-foreground">
                    No pending items from ComplianceConnect.
                  </p>
                </div>
              )}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
};

export default Index;
