import { useState } from 'react';
import { useLibrary } from '@/context/LibraryContext';
import { regulatoryReferences, historicalRecords } from '@/data/libraryData';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { BookOpen, FileText, History, Search, Building2, DollarSign, Copy, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';

interface LibraryReferenceSheetProps {
  onApplyTemplate?: (data: {
    description: string;
    governingBody: string;
    penaltyType: string;
    notes: string;
  }) => void;
}

export function LibraryReferenceSheet({ onApplyTemplate }: LibraryReferenceSheetProps) {
  const { templates } = useLibrary();
  const [searchQuery, setSearchQuery] = useState('');
  const [open, setOpen] = useState(false);

  const filteredTemplates = templates.filter((t) =>
    !searchQuery ||
    t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredRegulations = regulatoryReferences.filter((r) =>
    !searchQuery ||
    r.regulation.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredRecords = historicalRecords.filter((r) =>
    !searchQuery ||
    r.referenceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.violationType.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleApplyTemplate = (template: typeof templates[0]) => {
    if (onApplyTemplate) {
      onApplyTemplate({
        description: template.description,
        governingBody: template.governingBody,
        penaltyType: template.penaltyType,
        notes: `Template: ${template.name}\n\nKey Requirements:\n${template.keyRequirements.map(r => `• ${r}`).join('\n')}`,
      });
      setOpen(false);
      toast.success('Template applied to form');
    }
  };

  const getPenaltyTypeVariant = (type: string) => {
    switch (type) {
      case 'Financial': return 'priorityHigh';
      case 'Legal': return 'priorityCritical';
      case 'Operational': return 'priorityMedium';
      case 'Administrative': return 'priorityLow';
      default: return 'secondary';
    }
  };

  const getImpactVariant = (level: string) => {
    switch (level) {
      case 'Critical': return 'priorityCritical';
      case 'High': return 'priorityHigh';
      case 'Medium': return 'priorityMedium';
      case 'Low': return 'priorityLow';
      default: return 'secondary';
    }
  };

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" type="button" className="gap-2">
          <BookOpen className="h-4 w-4" />
          Reference Library
        </Button>
      </SheetTrigger>
      <SheetContent className="w-full sm:max-w-xl">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-primary" />
            Enforcement Library
          </SheetTitle>
        </SheetHeader>

        <div className="mt-4 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search library..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          <Tabs defaultValue="templates" className="h-[calc(100vh-200px)]">
            <TabsList className="w-full grid grid-cols-3">
              <TabsTrigger value="templates" className="gap-1 text-xs">
                <FileText className="h-3 w-3" />
                Templates
              </TabsTrigger>
              <TabsTrigger value="regulatory" className="gap-1 text-xs">
                <BookOpen className="h-3 w-3" />
                Regulations
              </TabsTrigger>
              <TabsTrigger value="historical" className="gap-1 text-xs">
                <History className="h-3 w-3" />
                History
              </TabsTrigger>
            </TabsList>

            <ScrollArea className="h-[calc(100%-48px)] mt-4">
              <TabsContent value="templates" className="space-y-3 mt-0">
                {filteredTemplates.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">No templates found</p>
                ) : (
                  filteredTemplates.map((template) => (
                    <Card key={template.id} className="hover:shadow-sm transition-shadow">
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant="outline" className="text-xs">{template.category}</Badge>
                              <Badge variant={getPenaltyTypeVariant(template.penaltyType)} className="text-xs">
                                {template.penaltyType}
                              </Badge>
                            </div>
                            <h4 className="font-medium text-sm">{template.name}</h4>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2">{template.description}</p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Building2 className="h-3 w-3" />
                          <span className="truncate">{template.governingBody}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <DollarSign className="h-3 w-3" />
                          <span>{template.typicalPenaltyRange}</span>
                        </div>
                        {onApplyTemplate && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="w-full gap-2 mt-2"
                            onClick={() => handleApplyTemplate(template)}
                          >
                            <Copy className="h-3 w-3" />
                            Apply to Form
                          </Button>
                        )}
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>

              <TabsContent value="regulatory" className="space-y-3 mt-0">
                {filteredRegulations.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">No regulations found</p>
                ) : (
                  filteredRegulations.map((ref) => (
                    <Card key={ref.id} className="hover:shadow-sm transition-shadow">
                      <CardContent className="p-4 space-y-3">
                        <div>
                          <Badge variant="outline" className="text-xs font-mono mb-2">{ref.code}</Badge>
                          <h4 className="font-medium text-sm">{ref.regulation}</h4>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2">{ref.description}</p>
                        <div className="text-xs">
                          <span className="font-medium">Penalties:</span>
                          <p className="text-muted-foreground mt-0.5">{ref.penalties}</p>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Building2 className="h-3 w-3" />
                          <span>{ref.governingBody}</span>
                        </div>
                        <Button variant="outline" size="sm" className="w-full gap-2" asChild>
                          <a href={ref.sourceUrl} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-3 w-3" />
                            View Source
                          </a>
                        </Button>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>

              <TabsContent value="historical" className="space-y-3 mt-0">
                {filteredRecords.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">No records found</p>
                ) : (
                  filteredRecords.map((record) => (
                    <Card key={record.id} className="hover:shadow-sm transition-shadow">
                      <CardContent className="p-4 space-y-3">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline" className="text-xs font-mono">{record.referenceNumber}</Badge>
                            <Badge variant={getImpactVariant(record.impactLevel)} className="text-xs">
                              {record.impactLevel}
                            </Badge>
                          </div>
                          <h4 className="font-medium text-sm">{record.violationType}</h4>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">{record.governingBody}</span>
                          <span className="font-medium">${record.penaltyAmount.toLocaleString()}</span>
                        </div>
                        <div className="text-xs">
                          <span className="font-medium">Resolution:</span>
                          <p className="text-muted-foreground mt-0.5">{record.resolution}</p>
                        </div>
                        <div className="text-xs bg-primary/5 p-2 rounded">
                          <span className="font-medium">Lessons Learned:</span>
                          <p className="text-muted-foreground mt-0.5 line-clamp-2">{record.lessonsLearned}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>
            </ScrollArea>
          </Tabs>
        </div>
      </SheetContent>
    </Sheet>
  );
}
