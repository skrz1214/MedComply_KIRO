import { useState, useEffect } from 'react';
import { EnforcementTemplate } from '@/data/libraryData';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { X, Plus, Link2, Paperclip } from 'lucide-react';
import { toast } from 'sonner';

interface TemplateFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  template?: EnforcementTemplate | null;
  onSave: (template: Omit<EnforcementTemplate, 'id'>) => void;
}

const categories = ['Privacy', 'Security', 'Billing', 'Fraud', 'Referral', 'Patient Care', 'Licensing', 'Safety'];
const penaltyTypes = ['Financial', 'Operational', 'Legal', 'Administrative'] as const;

export function TemplateFormDialog({ open, onOpenChange, template, onSave }: TemplateFormDialogProps) {
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    description: '',
    governingBody: '',
    typicalPenaltyRange: '',
    penaltyType: 'Financial' as EnforcementTemplate['penaltyType'],
    complianceArea: '',
    keyRequirements: [''],
    sourceUrl: '',
    attachments: [''],
  });

  useEffect(() => {
    if (template) {
      setFormData({
        name: template.name,
        category: template.category,
        description: template.description,
        governingBody: template.governingBody,
        typicalPenaltyRange: template.typicalPenaltyRange,
        penaltyType: template.penaltyType,
        complianceArea: template.complianceArea,
        keyRequirements: template.keyRequirements.length > 0 ? template.keyRequirements : [''],
        sourceUrl: template.sourceUrl || '',
        attachments: template.attachments && template.attachments.length > 0 ? template.attachments : [''],
      });
    } else {
      setFormData({
        name: '',
        category: '',
        description: '',
        governingBody: '',
        typicalPenaltyRange: '',
        penaltyType: 'Financial',
        complianceArea: '',
        keyRequirements: [''],
        sourceUrl: '',
        attachments: [''],
      });
    }
  }, [template, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.category || !formData.description.trim()) {
      toast.error('Please fill in all required fields');
      return;
    }

    const filteredAttachments = formData.attachments.filter((a) => a.trim() !== '');

    onSave({
      ...formData,
      name: formData.name.trim(),
      description: formData.description.trim(),
      governingBody: formData.governingBody.trim(),
      typicalPenaltyRange: formData.typicalPenaltyRange.trim(),
      complianceArea: formData.complianceArea.trim(),
      keyRequirements: formData.keyRequirements.filter((r) => r.trim() !== ''),
      sourceUrl: formData.sourceUrl.trim() || undefined,
      attachments: filteredAttachments.length > 0 ? filteredAttachments : undefined,
    });
    
    onOpenChange(false);
    toast.success(template ? 'Template updated' : 'Template added');
  };

  const addRequirement = () => {
    setFormData((prev) => ({
      ...prev,
      keyRequirements: [...prev.keyRequirements, ''],
    }));
  };

  const removeRequirement = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      keyRequirements: prev.keyRequirements.filter((_, i) => i !== index),
    }));
  };

  const updateRequirement = (index: number, value: string) => {
    setFormData((prev) => ({
      ...prev,
      keyRequirements: prev.keyRequirements.map((r, i) => (i === index ? value : r)),
    }));
  };

  const addAttachment = () => {
    setFormData((prev) => ({
      ...prev,
      attachments: [...prev.attachments, ''],
    }));
  };

  const removeAttachment = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      attachments: prev.attachments.filter((_, i) => i !== index),
    }));
  };

  const updateAttachment = (index: number, value: string) => {
    setFormData((prev) => ({
      ...prev,
      attachments: prev.attachments.map((a, i) => (i === index ? value : a)),
    }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{template ? 'Edit Template' : 'Add New Template'}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="name">Template Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                placeholder="e.g., HIPAA Privacy Violation"
                maxLength={100}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData((prev) => ({ ...prev, category: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
              placeholder="Describe the enforcement type..."
              rows={3}
              maxLength={500}
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="governingBody">Governing Body</Label>
              <Input
                id="governingBody"
                value={formData.governingBody}
                onChange={(e) => setFormData((prev) => ({ ...prev, governingBody: e.target.value }))}
                placeholder="e.g., HHS Office for Civil Rights"
                maxLength={100}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="penaltyType">Penalty Type</Label>
              <Select
                value={formData.penaltyType}
                onValueChange={(value: EnforcementTemplate['penaltyType']) => 
                  setFormData((prev) => ({ ...prev, penaltyType: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {penaltyTypes.map((type) => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="penaltyRange">Typical Penalty Range</Label>
              <Input
                id="penaltyRange"
                value={formData.typicalPenaltyRange}
                onChange={(e) => setFormData((prev) => ({ ...prev, typicalPenaltyRange: e.target.value }))}
                placeholder="e.g., $100 - $50,000 per violation"
                maxLength={100}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="complianceArea">Compliance Area</Label>
              <Input
                id="complianceArea"
                value={formData.complianceArea}
                onChange={(e) => setFormData((prev) => ({ ...prev, complianceArea: e.target.value }))}
                placeholder="e.g., HIPAA Privacy Rule"
                maxLength={100}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Link2 className="h-4 w-4" />
              Source URL
            </Label>
            <Input
              value={formData.sourceUrl}
              onChange={(e) => setFormData((prev) => ({ ...prev, sourceUrl: e.target.value }))}
              placeholder="https://example.gov/regulation-details"
              type="url"
            />
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Paperclip className="h-4 w-4" />
              Attachments (URLs)
            </Label>
            <div className="space-y-2">
              {formData.attachments.map((attachment, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={attachment}
                    onChange={(e) => updateAttachment(index, e.target.value)}
                    placeholder="https://example.com/document.pdf"
                    type="url"
                  />
                  {formData.attachments.length > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => removeAttachment(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
              <Button type="button" variant="outline" size="sm" onClick={addAttachment} className="gap-1">
                <Plus className="h-4 w-4" />
                Add Attachment
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Key Requirements</Label>
            <div className="space-y-2">
              {formData.keyRequirements.map((req, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={req}
                    onChange={(e) => updateRequirement(index, e.target.value)}
                    placeholder="Enter requirement..."
                    maxLength={200}
                  />
                  {formData.keyRequirements.length > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => removeRequirement(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
              <Button type="button" variant="outline" size="sm" onClick={addRequirement} className="gap-1">
                <Plus className="h-4 w-4" />
                Add Requirement
              </Button>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">
              {template ? 'Save Changes' : 'Add Template'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
