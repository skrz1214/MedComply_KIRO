import { regulatoryReferences } from '@/data/libraryData';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { BookOpen, ExternalLink, Calendar, Building2, AlertTriangle } from 'lucide-react';

interface RegulatoryListProps {
  searchQuery: string;
  bodyFilter: string;
}

export function RegulatoryList({ searchQuery, bodyFilter }: RegulatoryListProps) {
  const filteredReferences = regulatoryReferences.filter((ref) => {
    const matchesSearch = !searchQuery || 
      ref.regulation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ref.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ref.code.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesBody = bodyFilter === 'All' || ref.governingBody.includes(bodyFilter);
    
    return matchesSearch && matchesBody;
  });

  if (filteredReferences.length === 0) {
    return (
      <div className="text-center py-16 bg-muted/30 rounded-lg border border-dashed border-border">
        <BookOpen className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
        <h3 className="font-medium text-foreground mb-2">No Regulations Found</h3>
        <p className="text-sm text-muted-foreground">
          Try adjusting your search or filters.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {filteredReferences.map((ref) => (
        <Card key={ref.id} className="hover:shadow-md transition-shadow">
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between gap-4">
              <div>
                <Badge variant="outline" className="mb-2 text-xs font-mono">
                  {ref.code}
                </Badge>
                <CardTitle className="text-xl">{ref.regulation}</CardTitle>
              </div>
              <Button variant="outline" size="sm" className="shrink-0 gap-2" asChild>
                <a href={ref.sourceUrl} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4" />
                  Source
                </a>
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              {ref.description}
            </p>

            <div className="grid gap-3 md:grid-cols-2">
              <div className="flex items-start gap-2 text-sm">
                <Building2 className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
                <div>
                  <p className="font-medium text-foreground">Governing Body</p>
                  <p className="text-muted-foreground">{ref.governingBody}</p>
                </div>
              </div>
              <div className="flex items-start gap-2 text-sm">
                <Calendar className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
                <div>
                  <p className="font-medium text-foreground">Effective Date</p>
                  <p className="text-muted-foreground">{ref.effectiveDate}</p>
                </div>
              </div>
            </div>

            <div className="bg-destructive/5 border border-destructive/20 rounded-lg p-3">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0 text-destructive" />
                <div>
                  <p className="text-sm font-medium text-foreground">Penalties</p>
                  <p className="text-sm text-muted-foreground">{ref.penalties}</p>
                </div>
              </div>
            </div>

            <div className="text-sm">
              <p className="font-medium text-foreground mb-1">Applicability</p>
              <p className="text-muted-foreground">{ref.applicability}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
