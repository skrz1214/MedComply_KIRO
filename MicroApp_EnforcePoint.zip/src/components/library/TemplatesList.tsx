import { useState } from 'react';
import { EnforcementTemplate } from '@/data/libraryData';
import { useLibrary } from '@/context/LibraryContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { FileText, DollarSign, Building2, CheckCircle, Copy, Pencil, Trash2, Plus } from 'lucide-react';
import { toast } from 'sonner';
import { TemplateFormDialog } from './TemplateFormDialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

interface TemplatesListProps {
  searchQuery: string;
  categoryFilter: string;
  bodyFilter: string;
}

export function TemplatesList({ searchQuery, categoryFilter, bodyFilter }: TemplatesListProps) {
  const navigate = useNavigate();
  const { templates, addTemplate, updateTemplate, deleteTemplate } = useLibrary();
  const [formOpen, setFormOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<EnforcementTemplate | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const filteredTemplates = templates.filter((template) => {
    const matchesSearch = !searchQuery || 
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = categoryFilter === 'All' || template.category === categoryFilter;
    const matchesBody = bodyFilter === 'All' || template.governingBody.includes(bodyFilter);
    
    return matchesSearch && matchesCategory && matchesBody;
  });

  const handleUseTemplate = (template: EnforcementTemplate) => {
    navigate('/enforcements/new', { 
      state: { 
        template: {
          description: template.description,
          governingBody: template.governingBody,
          penaltyType: template.penaltyType,
          notes: `Template: ${template.name}\n\nKey Requirements:\n${template.keyRequirements.map(r => `• ${r}`).join('\n')}`
        }
      }
    });
    toast.success('Template loaded', { description: 'Form pre-filled with template data' });
  };

  const handleEdit = (template: EnforcementTemplate) => {
    setEditingTemplate(template);
    setFormOpen(true);
  };

  const handleSave = (data: Omit<EnforcementTemplate, 'id'>) => {
    if (editingTemplate) {
      updateTemplate(editingTemplate.id, data);
    } else {
      addTemplate(data);
    }
    setEditingTemplate(null);
  };

  const handleDelete = () => {
    if (deleteId) {
      deleteTemplate(deleteId);
      setDeleteId(null);
      toast.success('Template deleted');
    }
  };

  const handleAddNew = () => {
    setEditingTemplate(null);
    setFormOpen(true);
  };

  const getPenaltyTypeVariant = (type: string) => {
    switch (type) {
      case 'Financial': return 'priorityHigh';
      case 'Legal': return 'priorityCritical';
      case 'Operational': return 'priorityMedium';
      case 'Administrative': return 'priorityLow';
      default: return 'secondary';
    }
  };

  return (
    <>
      <div className="flex justify-end mb-4">
        <Button onClick={handleAddNew} className="gap-2">
          <Plus className="h-4 w-4" />
          Add Template
        </Button>
      </div>

      {filteredTemplates.length === 0 ? (
        <div className="text-center py-16 bg-muted/30 rounded-lg border border-dashed border-border">
          <FileText className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
          <h3 className="font-medium text-foreground mb-2">No Templates Found</h3>
          <p className="text-sm text-muted-foreground mb-4">
            {searchQuery || categoryFilter !== 'All' || bodyFilter !== 'All' 
              ? 'Try adjusting your search or filters.' 
              : 'Get started by adding your first template.'}
          </p>
          {!searchQuery && categoryFilter === 'All' && bodyFilter === 'All' && (
            <Button variant="outline" onClick={handleAddNew}>
              Add First Template
            </Button>
          )}
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {filteredTemplates.map((template) => (
            <Card key={template.id} className="group hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline" className="text-xs">
                        {template.category}
                      </Badge>
                      <Badge variant={getPenaltyTypeVariant(template.penaltyType)} className="text-xs">
                        {template.penaltyType}
                      </Badge>
                    </div>
                    <CardTitle className="text-lg">{template.name}</CardTitle>
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleEdit(template)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeleteId(template.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {template.description}
                </p>
                
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Building2 className="h-4 w-4 shrink-0" />
                    <span className="truncate">{template.governingBody}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <DollarSign className="h-4 w-4 shrink-0" />
                    <span>{template.typicalPenaltyRange}</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <p className="text-xs font-medium text-foreground">Key Requirements:</p>
                  <div className="space-y-1">
                    {template.keyRequirements.slice(0, 2).map((req, idx) => (
                      <div key={idx} className="flex items-start gap-1.5 text-xs text-muted-foreground">
                        <CheckCircle className="h-3 w-3 mt-0.5 shrink-0 text-primary" />
                        <span className="line-clamp-1">{req}</span>
                      </div>
                    ))}
                    {template.keyRequirements.length > 2 && (
                      <p className="text-xs text-muted-foreground pl-4">
                        +{template.keyRequirements.length - 2} more...
                      </p>
                    )}
                  </div>
                </div>

                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full gap-2"
                  onClick={() => handleUseTemplate(template)}
                >
                  <Copy className="h-4 w-4" />
                  Use Template
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <TemplateFormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        template={editingTemplate}
        onSave={handleSave}
      />

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Template?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove this template from the library. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
