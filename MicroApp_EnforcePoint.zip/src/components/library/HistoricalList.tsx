import { historicalRecords } from '@/data/libraryData';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { History, Building2, Calendar, DollarSign, Lightbulb, CheckCircle } from 'lucide-react';
import { format } from 'date-fns';

interface HistoricalListProps {
  searchQuery: string;
  bodyFilter: string;
}

export function HistoricalList({ searchQuery, bodyFilter }: HistoricalListProps) {
  const filteredRecords = historicalRecords.filter((record) => {
    const matchesSearch = !searchQuery || 
      record.referenceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.violationType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.lessonsLearned.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesBody = bodyFilter === 'All' || record.governingBody.includes(bodyFilter);
    
    return matchesSearch && matchesBody;
  });

  const getImpactVariant = (level: string) => {
    switch (level) {
      case 'Critical': return 'priorityCritical';
      case 'High': return 'priorityHigh';
      case 'Medium': return 'priorityMedium';
      case 'Low': return 'priorityLow';
      default: return 'secondary';
    }
  };

  if (filteredRecords.length === 0) {
    return (
      <div className="text-center py-16 bg-muted/30 rounded-lg border border-dashed border-border">
        <History className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
        <h3 className="font-medium text-foreground mb-2">No Historical Records Found</h3>
        <p className="text-sm text-muted-foreground">
          Try adjusting your search or filters.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {filteredRecords.map((record) => (
        <Card key={record.id} className="hover:shadow-md transition-shadow">
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline" className="font-mono text-xs">
                    {record.referenceNumber}
                  </Badge>
                  <Badge variant={getImpactVariant(record.impactLevel)}>
                    {record.impactLevel}
                  </Badge>
                  <Badge variant="statusResolved" className="gap-1">
                    <CheckCircle className="h-3 w-3" />
                    Resolved
                  </Badge>
                </div>
                <CardTitle className="text-lg">{record.violationType}</CardTitle>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-3 md:grid-cols-3">
              <div className="flex items-center gap-2 text-sm">
                <Building2 className="h-4 w-4 shrink-0 text-primary" />
                <div>
                  <p className="text-muted-foreground">{record.governingBody}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <DollarSign className="h-4 w-4 shrink-0 text-primary" />
                <div>
                  <p className="font-medium text-foreground">
                    ${record.penaltyAmount.toLocaleString()}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Calendar className="h-4 w-4 shrink-0 text-primary" />
                <div>
                  <p className="text-muted-foreground">
                    {format(new Date(record.resolvedDate), 'MMM d, yyyy')}
                  </p>
                </div>
              </div>
            </div>

            <div className="text-sm">
              <p className="font-medium text-foreground mb-1">Resolution</p>
              <p className="text-muted-foreground">{record.resolution}</p>
            </div>

            <div className="bg-primary/5 border border-primary/20 rounded-lg p-3">
              <div className="flex items-start gap-2">
                <Lightbulb className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
                <div>
                  <p className="text-sm font-medium text-foreground">Lessons Learned</p>
                  <p className="text-sm text-muted-foreground">{record.lessonsLearned}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
