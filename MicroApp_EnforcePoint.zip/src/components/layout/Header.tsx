import { Shield, Bell, User, Menu, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useEnforcement } from '@/context/EnforcementContext';
import { Link, useLocation } from 'react-router-dom';

export function Header() {
  const { todoItems } = useEnforcement();
  const location = useLocation();
  const unprocessedTodos = todoItems.filter(t => !t.isProcessed).length;

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-card shadow-sm">
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        <div className="flex items-center gap-4">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg gradient-primary shadow-md transition-transform group-hover:scale-105">
              <Shield className="h-5 w-5 text-primary-foreground" />
            </div>
            <div className="hidden sm:block">
              <h1 className="text-lg font-bold text-foreground tracking-tight">EnforcePoint</h1>
              <p className="text-xs text-muted-foreground">MedComply Suite</p>
            </div>
          </Link>
        </div>

        <nav className="hidden md:flex items-center gap-1">
          <Link to="/">
            <Button
              variant={location.pathname === '/' ? 'secondary' : 'ghost'}
              size="sm"
              className="font-medium"
            >
              Dashboard
            </Button>
          </Link>
          <Link to="/enforcements">
            <Button
              variant={location.pathname === '/enforcements' ? 'secondary' : 'ghost'}
              size="sm"
              className="font-medium"
            >
              Enforcements
            </Button>
          </Link>
          <Link to="/library">
            <Button
              variant={location.pathname === '/library' ? 'secondary' : 'ghost'}
              size="sm"
              className="font-medium gap-1.5"
            >
              <BookOpen className="h-4 w-4" />
              Library
            </Button>
          </Link>
          <Link to="/todo">
            <Button
              variant={location.pathname === '/todo' ? 'secondary' : 'ghost'}
              size="sm"
              className="font-medium relative"
            >
              To Do
              {unprocessedTodos > 0 && (
                <Badge variant="destructive" className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-[10px]">
                  {unprocessedTodos}
                </Badge>
              )}
            </Button>
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            {unprocessedTodos > 0 && (
              <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-destructive" />
            )}
          </Button>
          <Button variant="ghost" size="icon">
            <User className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </header>
  );
}
