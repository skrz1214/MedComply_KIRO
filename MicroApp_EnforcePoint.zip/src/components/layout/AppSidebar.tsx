import { 
  Shield, 
  AlertTriangle, 
  FileText, 
  Gavel, 
  BarChart3, 
  Settings,
  LayoutDashboard,
  FolderOpen,
  Scale,
  Mail,
  Calendar,
  ChevronDown,
  Building2,
  BookOpen,
  FileText as FileTextIcon,
  ClipboardCheck,
  TestTube2,
  Terminal,
} from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton,
  useSidebar,
} from "@/components/ui/sidebar";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { cn } from "@/lib/utils";

const suiteNavItems = [
  { title: "Enforcement", url: "/enforcement", icon: Gavel },
  { title: "Reports", url: "/reports", icon: BarChart3 },
  { title: "Admin Configuration", url: "/admin", icon: Settings },
  { title: "PRD Document", url: "/docs/prd", icon: FileTextIcon },
  { title: "QA Test Cases", url: "/docs/qa-test-cases", icon: TestTube2 },
  { title: "UAT Test Cases", url: "/docs/uat-test-cases", icon: ClipboardCheck },
  { title: "System Prompt", url: "/docs/system-prompt", icon: Terminal },
];

const enforcementSubItems = [
  { title: "Dashboard", url: "/enforcement", icon: LayoutDashboard },
  { title: "Cases", url: "/enforcement/cases", icon: FolderOpen },
  { title: "Regulatory Bodies", url: "/enforcement/regulatory", icon: Building2 },
  { title: "Library", url: "/enforcement/library", icon: BookOpen },
  { title: "Actions & Remedies", url: "/enforcement/actions", icon: Scale },
  { title: "Correspondence", url: "/enforcement/correspondence", icon: Mail },
  { title: "Appeals", url: "/enforcement/appeals", icon: Gavel },
  { title: "Calendar", url: "/enforcement/calendar", icon: Calendar },
  { title: "Reports", url: "/enforcement/reports", icon: BarChart3 },
];

export function AppSidebar() {
  const location = useLocation();
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  
  const isEnforcementActive = location.pathname.startsWith("/enforcement");

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sidebar-primary">
            <Shield className="h-4 w-4 text-sidebar-primary-foreground" />
          </div>
          {!collapsed && (
            <div className="flex flex-col">
              <span className="text-sm font-semibold text-sidebar-foreground">EnforcePoint</span>
              <span className="text-xs text-sidebar-foreground/60">Healthcare Provider</span>
            </div>
          )}
        </div>
      </SidebarHeader>
      
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {suiteNavItems.map((item) => {
                const isEnforcement = item.url === "/enforcement";
                const isActive = isEnforcement 
                  ? isEnforcementActive 
                  : location.pathname === item.url;

                if (isEnforcement) {
                  return (
                    <Collapsible key={item.title} defaultOpen={isEnforcementActive} className="group/collapsible">
                      <SidebarMenuItem>
                        <CollapsibleTrigger asChild>
                          <SidebarMenuButton
                            isActive={isActive}
                            tooltip={item.title}
                            className={cn(
                              isActive && "bg-sidebar-accent text-sidebar-accent-foreground"
                            )}
                          >
                            <item.icon className="h-4 w-4" />
                            {!collapsed && (
                              <>
                                <span className="flex-1">{item.title}</span>
                                <ChevronDown className="h-4 w-4 transition-transform group-data-[state=open]/collapsible:rotate-180" />
                              </>
                            )}
                          </SidebarMenuButton>
                        </CollapsibleTrigger>
                        {!collapsed && (
                          <CollapsibleContent>
                            <SidebarMenuSub>
                              {enforcementSubItems.map((subItem) => (
                                <SidebarMenuSubItem key={subItem.url}>
                                  <SidebarMenuSubButton
                                    asChild
                                    isActive={
                                      subItem.url === "/enforcement"
                                        ? location.pathname === "/enforcement"
                                        : location.pathname.startsWith(subItem.url)
                                    }
                                  >
                                    <NavLink to={subItem.url}>
                                      <subItem.icon className="h-3 w-3" />
                                      <span>{subItem.title}</span>
                                    </NavLink>
                                  </SidebarMenuSubButton>
                                </SidebarMenuSubItem>
                              ))}
                            </SidebarMenuSub>
                          </CollapsibleContent>
                        )}
                      </SidebarMenuItem>
                    </Collapsible>
                  );
                }

                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActive}
                      tooltip={item.title}
                    >
                      <NavLink to={item.url}>
                        <item.icon className="h-4 w-4" />
                        {!collapsed && <span>{item.title}</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
