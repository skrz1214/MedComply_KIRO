import { useState } from "react";
import { useUser, mockUsers, departments, UserRole, ViewMode } from "@/context/UserContext";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { 
  User, 
  Building2, 
  Users, 
  ChevronDown, 
  Eye,
  Shield,
  UserCog,
  Briefcase,
  UserCircle
} from "lucide-react";

const roleIcons: Record<UserRole, React.ReactNode> = {
  admin: <Shield className="h-3 w-3" />,
  compliance_head: <UserCog className="h-3 w-3" />,
  department_head: <Briefcase className="h-3 w-3" />,
  staff: <UserCircle className="h-3 w-3" />,
};

const roleBadgeVariants: Record<UserRole, "default" | "secondary" | "outline" | "destructive"> = {
  admin: "destructive",
  compliance_head: "default",
  department_head: "secondary",
  staff: "outline",
};

export function UserSwitcher() {
  const {
    currentUser,
    setCurrentUser,
    viewMode,
    setViewMode,
    selectedDepartment,
    setSelectedDepartment,
    selectedUserId,
    setSelectedUserId,
    getAvailableViewModes,
    getRoleLabel,
  } = useUser();

  const [open, setOpen] = useState(false);

  const availableViewModes = getAvailableViewModes();

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  const getViewModeLabel = (mode: ViewMode) => {
    switch (mode) {
      case "organization": return "Organization View";
      case "department": return "Department View";
      case "individual": return "Individual View";
    }
  };

  const getViewModeIcon = (mode: ViewMode) => {
    switch (mode) {
      case "organization": return <Building2 className="h-4 w-4" />;
      case "department": return <Users className="h-4 w-4" />;
      case "individual": return <User className="h-4 w-4" />;
    }
  };

  const handleViewModeChange = (mode: ViewMode) => {
    setViewMode(mode);
    if (mode === "department") {
      setSelectedDepartment(currentUser.department);
      setSelectedUserId(null);
    } else if (mode === "individual") {
      setSelectedUserId(currentUser.id);
      setSelectedDepartment(null);
    } else {
      setSelectedDepartment(null);
      setSelectedUserId(null);
    }
  };

  const filteredUsersForImpersonation = mockUsers.filter(u => {
    if (currentUser.role === "department_head") {
      return u.department === currentUser.department;
    }
    return true;
  });

  return (
    <div className="flex items-center gap-2">
      {/* View Mode Toggle */}
      {availableViewModes.length > 1 && (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="gap-2 bg-background">
              {getViewModeIcon(viewMode)}
              <span className="hidden sm:inline">{getViewModeLabel(viewMode)}</span>
              <ChevronDown className="h-3 w-3" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56 bg-popover">
            <DropdownMenuLabel className="flex items-center gap-2">
              <Eye className="h-4 w-4" />
              Switch View
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuRadioGroup value={viewMode} onValueChange={(v) => handleViewModeChange(v as ViewMode)}>
              {availableViewModes.map((mode) => (
                <DropdownMenuRadioItem key={mode} value={mode} className="gap-2">
                  {getViewModeIcon(mode)}
                  {getViewModeLabel(mode)}
                </DropdownMenuRadioItem>
              ))}
            </DropdownMenuRadioGroup>

            {/* Department Selector for Org View */}
            {viewMode === "organization" && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuSub>
                  <DropdownMenuSubTrigger className="gap-2">
                    <Building2 className="h-4 w-4" />
                    Filter by Department
                  </DropdownMenuSubTrigger>
                  <DropdownMenuSubContent className="bg-popover">
                    <DropdownMenuItem onClick={() => setSelectedDepartment(null)}>
                      All Departments
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    {departments.map((dept) => (
                      <DropdownMenuItem 
                        key={dept} 
                        onClick={() => setSelectedDepartment(dept)}
                        className={selectedDepartment === dept ? "bg-accent" : ""}
                      >
                        {dept}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuSubContent>
                </DropdownMenuSub>
              </>
            )}

            {/* User Selector for Individual View */}
            {viewMode === "individual" && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuSub>
                  <DropdownMenuSubTrigger className="gap-2">
                    <User className="h-4 w-4" />
                    View as User
                  </DropdownMenuSubTrigger>
                  <DropdownMenuSubContent className="bg-popover max-h-64 overflow-y-auto">
                    {filteredUsersForImpersonation.map((user) => (
                      <DropdownMenuItem 
                        key={user.id} 
                        onClick={() => setSelectedUserId(user.id)}
                        className={selectedUserId === user.id ? "bg-accent" : ""}
                      >
                        <div className="flex items-center gap-2">
                          <Avatar className="h-6 w-6">
                            <AvatarFallback className="text-xs">{getInitials(user.name)}</AvatarFallback>
                          </Avatar>
                          <div className="flex flex-col">
                            <span className="text-sm">{user.name}</span>
                            <span className="text-xs text-muted-foreground">{user.department}</span>
                          </div>
                        </div>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuSubContent>
                </DropdownMenuSub>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      )}

      {/* User Impersonation Dropdown */}
      <DropdownMenu open={open} onOpenChange={setOpen}>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="sm" className="gap-2 px-2">
            <Avatar className="h-7 w-7">
              <AvatarFallback className="text-xs bg-primary text-primary-foreground">
                {getInitials(currentUser.name)}
              </AvatarFallback>
            </Avatar>
            <div className="hidden sm:flex flex-col items-start">
              <span className="text-sm font-medium leading-none">{currentUser.name}</span>
              <Badge variant={roleBadgeVariants[currentUser.role]} className="text-[10px] px-1 py-0 h-4 mt-0.5">
                {roleIcons[currentUser.role]}
                <span className="ml-1">{getRoleLabel(currentUser.role)}</span>
              </Badge>
            </div>
            <ChevronDown className="h-3 w-3 hidden sm:block" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-72 bg-popover">
          <DropdownMenuLabel>Switch User (Impersonation)</DropdownMenuLabel>
          <DropdownMenuSeparator />
          
          {/* Group by Role */}
          {(["admin", "compliance_head", "department_head", "staff"] as UserRole[]).map((role) => {
            const usersInRole = mockUsers.filter((u) => u.role === role);
            if (usersInRole.length === 0) return null;
            
            return (
              <div key={role}>
                <DropdownMenuLabel className="text-xs text-muted-foreground flex items-center gap-1 py-1">
                  {roleIcons[role]}
                  {getRoleLabel(role)}
                </DropdownMenuLabel>
                {usersInRole.map((user) => (
                  <DropdownMenuItem
                    key={user.id}
                    onClick={() => {
                      setCurrentUser(user);
                      setOpen(false);
                    }}
                    className={currentUser.id === user.id ? "bg-accent" : ""}
                  >
                    <div className="flex items-center gap-3 w-full">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="text-xs">{getInitials(user.name)}</AvatarFallback>
                      </Avatar>
                      <div className="flex flex-col flex-1">
                        <span className="text-sm font-medium">{user.name}</span>
                        <span className="text-xs text-muted-foreground">{user.department}</span>
                      </div>
                      {currentUser.id === user.id && (
                        <Badge variant="outline" className="text-[10px]">Current</Badge>
                      )}
                    </div>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
              </div>
            );
          })}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
