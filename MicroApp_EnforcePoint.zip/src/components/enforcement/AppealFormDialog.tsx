import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Appeal, AppealLevel, AppealOutcome } from "@/types/enforcepoint";

interface AppealFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  appeal?: Appeal | null;
  caseId: string;
  onSave: (appeal: Omit<Appeal, 'id' | 'createdAt' | 'updatedAt'>) => void;
}

const appealLevels: AppealLevel[] = [
  'Informal Dispute',
  'Administrative Hearing',
  'State-Level Hearing',
  'Federal-Level',
  'Other',
];

const appealOutcomes: AppealOutcome[] = ['Pending', 'Won', 'Lost', 'Settled', 'Withdrawn'];

export function AppealFormDialog({ open, onOpenChange, appeal, caseId, onSave }: AppealFormDialogProps) {
  const [appealLevel, setAppealLevel] = useState<AppealLevel>('Informal Dispute');
  const [filingDueDate, setFilingDueDate] = useState<Date | undefined>();
  const [filedDate, setFiledDate] = useState<Date | undefined>();
  const [hearingDate, setHearingDate] = useState<Date | undefined>();
  const [outcome, setOutcome] = useState<AppealOutcome>('Pending');
  const [counselRepresentative, setCounselRepresentative] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (appeal) {
      setAppealLevel(appeal.appealLevel);
      setFilingDueDate(appeal.filingDueDate ? new Date(appeal.filingDueDate) : undefined);
      setFiledDate(appeal.filedDate ? new Date(appeal.filedDate) : undefined);
      setHearingDate(appeal.hearingDate ? new Date(appeal.hearingDate) : undefined);
      setOutcome(appeal.outcome);
      setCounselRepresentative(appeal.counselRepresentative || '');
      setNotes(appeal.notes || '');
    } else {
      setAppealLevel('Informal Dispute');
      setFilingDueDate(undefined);
      setFiledDate(undefined);
      setHearingDate(undefined);
      setOutcome('Pending');
      setCounselRepresentative('');
      setNotes('');
    }
  }, [appeal, open]);

  const handleSave = () => {
    onSave({
      caseId,
      appealLevel,
      filingDueDate,
      filedDate,
      hearingDate,
      outcome,
      counselRepresentative: counselRepresentative || undefined,
      notes: notes || undefined,
      documents: appeal?.documents || [],
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{appeal ? 'Edit Appeal' : 'File New Appeal'}</DialogTitle>
          <DialogDescription>
            {appeal ? 'Update the appeal details below.' : 'Enter the appeal details to file a new appeal for this case.'}
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="appealLevel">Appeal Level</Label>
            <Select value={appealLevel} onValueChange={(v) => setAppealLevel(v as AppealLevel)}>
              <SelectTrigger>
                <SelectValue placeholder="Select appeal level" />
              </SelectTrigger>
              <SelectContent>
                {appealLevels.map((level) => (
                  <SelectItem key={level} value={level}>{level}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="outcome">Outcome Status</Label>
            <Select value={outcome} onValueChange={(v) => setOutcome(v as AppealOutcome)}>
              <SelectTrigger>
                <SelectValue placeholder="Select outcome" />
              </SelectTrigger>
              <SelectContent>
                {appealOutcomes.map((o) => (
                  <SelectItem key={o} value={o}>{o}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>Filing Due Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn("justify-start text-left font-normal", !filingDueDate && "text-muted-foreground")}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {filingDueDate ? format(filingDueDate, 'MMM d, yyyy') : 'Select date'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar mode="single" selected={filingDueDate} onSelect={setFilingDueDate} />
                </PopoverContent>
              </Popover>
            </div>

            <div className="grid gap-2">
              <Label>Filed Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn("justify-start text-left font-normal", !filedDate && "text-muted-foreground")}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {filedDate ? format(filedDate, 'MMM d, yyyy') : 'Select date'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar mode="single" selected={filedDate} onSelect={setFiledDate} />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <div className="grid gap-2">
            <Label>Hearing Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn("w-full justify-start text-left font-normal", !hearingDate && "text-muted-foreground")}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {hearingDate ? format(hearingDate, 'MMM d, yyyy') : 'Select hearing date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={hearingDate} onSelect={setHearingDate} />
              </PopoverContent>
            </Popover>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="counsel">Counsel / Representative</Label>
            <Input
              id="counsel"
              value={counselRepresentative}
              onChange={(e) => setCounselRepresentative(e.target.value)}
              placeholder="Enter counsel name or firm"
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Enter any additional notes about this appeal..."
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave}>{appeal ? 'Save Changes' : 'File Appeal'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
