import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, X } from "lucide-react";
import {
  ResponseTemplateLibraryItem,
  CaseType,
  LibraryItemStatus,
  RegulatoryBody,
  TemplateSection,
  RequiredAttachment,
} from "@/types/enforcepoint";

interface ResponseTemplateFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item?: ResponseTemplateLibraryItem | null;
  onSave: (item: Omit<ResponseTemplateLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  regulatoryBodies: RegulatoryBody[];
  currentUserName: string;
}

const CASE_TYPES: CaseType[] = ['Survey/Inspection', 'Complaint Investigation', 'Program Integrity/Fraud', 'Privacy/Security', 'Licensure', 'Life Safety', 'Other'];

export function ResponseTemplateFormDialog({
  open,
  onOpenChange,
  item,
  onSave,
  regulatoryBodies,
  currentUserName,
}: ResponseTemplateFormDialogProps) {
  const [formData, setFormData] = useState({
    templateName: "",
    description: "",
    regulatoryBodyId: "",
    caseType: "" as CaseType | "",
    status: "Draft" as LibraryItemStatus,
  });

  const [requiredSections, setRequiredSections] = useState<TemplateSection[]>([]);
  const [requiredAttachments, setRequiredAttachments] = useState<RequiredAttachment[]>([]);
  const [newSection, setNewSection] = useState({ name: "", required: true });
  const [newAttachment, setNewAttachment] = useState({ name: "", required: true });

  useEffect(() => {
    if (item) {
      setFormData({
        templateName: item.templateName,
        description: item.description || "",
        regulatoryBodyId: item.regulatoryBodyId || "",
        caseType: item.caseType || "",
        status: item.status,
      });
      setRequiredSections(item.requiredSections);
      setRequiredAttachments(item.requiredAttachments);
    } else {
      setFormData({
        templateName: "",
        description: "",
        regulatoryBodyId: "",
        caseType: "",
        status: "Draft",
      });
      setRequiredSections([
        { id: 'sec-1', name: 'Response Summary', isRequired: true },
        { id: 'sec-2', name: 'Corrective Actions', isRequired: true },
        { id: 'sec-3', name: 'Preventive Actions', isRequired: true },
        { id: 'sec-4', name: 'Monitoring Plan', isRequired: true },
      ]);
      setRequiredAttachments([]);
    }
  }, [item, open]);

  const addSection = () => {
    if (!newSection.name.trim()) return;
    setRequiredSections(prev => [
      ...prev,
      { id: `sec-${Date.now()}`, name: newSection.name, isRequired: newSection.required }
    ]);
    setNewSection({ name: "", required: true });
  };

  const removeSection = (id: string) => {
    setRequiredSections(prev => prev.filter(s => s.id !== id));
  };

  const addAttachment = () => {
    if (!newAttachment.name.trim()) return;
    setRequiredAttachments(prev => [
      ...prev,
      { id: `att-${Date.now()}`, name: newAttachment.name, isRequired: newAttachment.required }
    ]);
    setNewAttachment({ name: "", required: true });
  };

  const removeAttachment = (id: string) => {
    setRequiredAttachments(prev => prev.filter(a => a.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      templateName: formData.templateName.trim(),
      description: formData.description || undefined,
      regulatoryBodyId: formData.regulatoryBodyId || undefined,
      caseType: formData.caseType as CaseType || undefined,
      requiredSections,
      requiredAttachments,
      status: formData.status,
      version: item ? item.version + 1 : 1,
      createdBy: item?.createdBy || currentUserName,
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{item ? "Edit Response Template" : "Add Response Template"}</DialogTitle>
          <DialogDescription>
            {item ? "Update this template." : "Create a new response package template."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="templateName">Template Name *</Label>
              <Input
                id="templateName"
                value={formData.templateName}
                onChange={(e) => setFormData({ ...formData, templateName: e.target.value })}
                placeholder="e.g., CMS Survey Response"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: LibraryItemStatus) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Draft">Draft</SelectItem>
                  <SelectItem value="Published">Published</SelectItem>
                  <SelectItem value="Deprecated">Deprecated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe when to use this template..."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Regulatory Body</Label>
              <Select
                value={formData.regulatoryBodyId || "all"}
                onValueChange={(value) => setFormData({ ...formData, regulatoryBodyId: value === "all" ? "" : value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All Bodies" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Bodies</SelectItem>
                  {regulatoryBodies.map(body => (
                    <SelectItem key={body.id} value={body.id}>{body.abbreviation || body.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Case Type</Label>
              <Select
                value={formData.caseType || "all"}
                onValueChange={(value) => setFormData({ ...formData, caseType: value === "all" ? "" : value as CaseType | "" })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {CASE_TYPES.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="border-t pt-4 space-y-3">
            <h4 className="font-medium">Required Sections</h4>
            <div className="flex flex-wrap gap-2 min-h-[32px]">
              {requiredSections.map(section => (
                <Badge key={section.id} variant={section.isRequired ? "default" : "secondary"} className="flex items-center gap-1">
                  {section.name}
                  <button type="button" onClick={() => removeSection(section.id)}>
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
            <div className="flex gap-2 items-end">
              <div className="flex-1">
                <Input
                  placeholder="Section name..."
                  value={newSection.name}
                  onChange={(e) => setNewSection({ ...newSection, name: e.target.value })}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="secRequired"
                  checked={newSection.required}
                  onCheckedChange={(checked) => setNewSection({ ...newSection, required: checked as boolean })}
                />
                <Label htmlFor="secRequired" className="text-sm">Required</Label>
              </div>
              <Button type="button" variant="outline" size="sm" onClick={addSection}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="border-t pt-4 space-y-3">
            <h4 className="font-medium">Required Attachments</h4>
            <div className="flex flex-wrap gap-2 min-h-[32px]">
              {requiredAttachments.map(att => (
                <Badge key={att.id} variant={att.isRequired ? "default" : "secondary"} className="flex items-center gap-1">
                  {att.name}
                  <button type="button" onClick={() => removeAttachment(att.id)}>
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
            <div className="flex gap-2 items-end">
              <div className="flex-1">
                <Input
                  placeholder="Attachment name (e.g., Training Roster)..."
                  value={newAttachment.name}
                  onChange={(e) => setNewAttachment({ ...newAttachment, name: e.target.value })}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="attRequired"
                  checked={newAttachment.required}
                  onCheckedChange={(checked) => setNewAttachment({ ...newAttachment, required: checked as boolean })}
                />
                <Label htmlFor="attRequired" className="text-sm">Required</Label>
              </div>
              <Button type="button" variant="outline" size="sm" onClick={addAttachment}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={!formData.templateName.trim()}>
              {item ? "Save Changes" : "Add Template"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}