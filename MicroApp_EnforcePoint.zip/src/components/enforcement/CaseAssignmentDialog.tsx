import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { EnforcementCase, IntakeStatus, OperationalStatus, CaseStatus } from "@/types/enforcepoint";
import { ArrowLeft, ArrowRight, UserPlus } from "lucide-react";

interface CaseAssignmentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  caseData: EnforcementCase;
  action: 'assign' | 'advance' | 'revert';
  onSave: (updates: {
    assignedOwnerName?: string;
    assignedDepartment?: string;
    intakeStatus?: IntakeStatus;
    caseStatus?: OperationalStatus;
    status?: CaseStatus;
    justification?: string;
  }) => void;
}

const INTAKE_STATUSES: { value: IntakeStatus; label: string }[] = [
  { value: 'I0_Draft', label: 'Draft' },
  { value: 'I1_Notice_Logged', label: 'Notice Logged' },
  { value: 'I2_Triage_Assignment', label: 'Triage & Assignment' },
  { value: 'I3_Ready_For_Management', label: 'Ready for Management' },
];

const OPERATIONAL_STATUSES: { value: OperationalStatus; label: string }[] = [
  { value: 'O0_Not_Started', label: 'Not Started' },
  { value: 'O1_Response_Planning', label: 'Response Planning' },
  { value: 'O2_Remediation_Linked', label: 'Remediation Linked' },
  { value: 'O3_Response_In_Progress', label: 'Response In Progress' },
  { value: 'O4_Submitted_Awaiting', label: 'Submitted / Awaiting' },
  { value: 'O5_Remedies_Active', label: 'Remedies Active' },
  { value: 'O6_Verification_Revisit', label: 'Verification / Revisit' },
  { value: 'O7_Closed', label: 'Closed' },
  { value: 'O8_Reopened', label: 'Reopened' },
];

const DEPARTMENTS = [
  'Compliance',
  'Nursing',
  'Administration',
  'Pharmacy',
  'Facilities',
  'Health Information Management',
  'Billing',
  'Social Services',
  'Environmental Services',
  'Quality Assurance',
];

const USERS = [
  'Sarah Johnson',
  'Maria Garcia',
  'Robert Chen',
  'Dr. James Wilson',
  'Tom Martinez',
  'Angela Torres',
  'John Smith',
  'Nancy Drew',
  'Lisa Anderson',
  'Mark Thompson',
  'Jennifer White',
  'Patricia Williams',
];

// Map operational status to combined status for backwards compatibility
function mapOperationalToCombined(opStatus: OperationalStatus, intakeStatus: IntakeStatus): CaseStatus {
  if (intakeStatus === 'I0_Draft') return 'Draft';
  if (intakeStatus === 'I1_Notice_Logged') return 'Notice Received';
  if (intakeStatus === 'I2_Triage_Assignment') return 'Triage & Assignment';
  
  switch (opStatus) {
    case 'O0_Not_Started': return 'Triage & Assignment';
    case 'O1_Response_Planning': return 'Response Planning';
    case 'O2_Remediation_Linked': return 'Remediation Linked';
    case 'O3_Response_In_Progress': return 'Response In Progress';
    case 'O4_Submitted_Awaiting': return 'Submitted / Awaiting Determination';
    case 'O5_Remedies_Active': return 'Remedies Active';
    case 'O6_Verification_Revisit': return 'Verification / Revisit';
    case 'O7_Closed': return 'Closed';
    case 'O8_Reopened': return 'Reopened';
    default: return 'Draft';
  }
}

export function CaseAssignmentDialog({
  open,
  onOpenChange,
  caseData,
  action,
  onSave,
}: CaseAssignmentDialogProps) {
  const [assignee, setAssignee] = useState(caseData.assignedOwnerName || '');
  const [department, setDepartment] = useState(caseData.assignedDepartment || caseData.department || '');
  const [intakeStatus, setIntakeStatus] = useState<IntakeStatus>(caseData.intakeStatus);
  const [operationalStatus, setOperationalStatus] = useState<OperationalStatus>(caseData.caseStatus);
  const [justification, setJustification] = useState('');

  const currentIntakeIndex = INTAKE_STATUSES.findIndex(s => s.value === caseData.intakeStatus);
  const currentOpIndex = OPERATIONAL_STATUSES.findIndex(s => s.value === caseData.caseStatus);

  const getNextStatus = () => {
    // First advance intake if not at Ready for Management
    if (currentIntakeIndex < INTAKE_STATUSES.length - 1) {
      return {
        intakeStatus: INTAKE_STATUSES[currentIntakeIndex + 1].value,
        operationalStatus: caseData.caseStatus,
      };
    }
    // Then advance operational
    if (currentOpIndex < OPERATIONAL_STATUSES.length - 2) { // -2 to exclude Closed unless going there explicitly
      return {
        intakeStatus: caseData.intakeStatus,
        operationalStatus: OPERATIONAL_STATUSES[currentOpIndex + 1].value,
      };
    }
    return null;
  };

  const getPrevStatus = () => {
    // First revert operational if beyond Not Started
    if (currentOpIndex > 0) {
      return {
        intakeStatus: caseData.intakeStatus,
        operationalStatus: OPERATIONAL_STATUSES[currentOpIndex - 1].value,
      };
    }
    // Then revert intake
    if (currentIntakeIndex > 0) {
      return {
        intakeStatus: INTAKE_STATUSES[currentIntakeIndex - 1].value,
        operationalStatus: caseData.caseStatus,
      };
    }
    return null;
  };

  const handleSave = () => {
    const updates: Parameters<typeof onSave>[0] = {};
    
    if (assignee !== caseData.assignedOwnerName) {
      updates.assignedOwnerName = assignee;
    }
    if (department !== (caseData.assignedDepartment || caseData.department)) {
      updates.assignedDepartment = department;
    }
    
    if (action === 'advance') {
      const next = getNextStatus();
      if (next) {
        updates.intakeStatus = next.intakeStatus;
        updates.caseStatus = next.operationalStatus;
        updates.status = mapOperationalToCombined(next.operationalStatus, next.intakeStatus);
      }
    } else if (action === 'revert') {
      const prev = getPrevStatus();
      if (prev) {
        updates.intakeStatus = prev.intakeStatus;
        updates.caseStatus = prev.operationalStatus;
        updates.status = mapOperationalToCombined(prev.operationalStatus, prev.intakeStatus);
      }
    } else {
      // Manual status change for assign action
      if (intakeStatus !== caseData.intakeStatus || operationalStatus !== caseData.caseStatus) {
        updates.intakeStatus = intakeStatus;
        updates.caseStatus = operationalStatus;
        updates.status = mapOperationalToCombined(operationalStatus, intakeStatus);
      }
    }
    
    if (justification) {
      updates.justification = justification;
    }
    
    onSave(updates);
    onOpenChange(false);
  };

  const getTitle = () => {
    switch (action) {
      case 'assign': return 'Assign Case';
      case 'advance': return 'Advance to Next Stage';
      case 'revert': return 'Return to Previous Stage';
    }
  };

  const getDescription = () => {
    switch (action) {
      case 'assign': return 'Assign this case to a different user and/or department, and optionally change the status.';
      case 'advance': return 'Move this case to the next stage in the workflow. You can also reassign the case.';
      case 'revert': return 'Return this case to the previous stage. A justification is required.';
    }
  };

  const nextStatus = getNextStatus();
  const prevStatus = getPrevStatus();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {action === 'assign' && <UserPlus className="h-5 w-5" />}
            {action === 'advance' && <ArrowRight className="h-5 w-5" />}
            {action === 'revert' && <ArrowLeft className="h-5 w-5" />}
            {getTitle()}
          </DialogTitle>
          <DialogDescription>{getDescription()}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Current Status Display */}
          <div className="p-3 bg-muted rounded-lg">
            <p className="text-sm text-muted-foreground mb-2">Current Status</p>
            <div className="flex gap-2">
              <Badge variant="outline">
                Intake: {INTAKE_STATUSES.find(s => s.value === caseData.intakeStatus)?.label}
              </Badge>
              <Badge variant="outline">
                Operations: {OPERATIONAL_STATUSES.find(s => s.value === caseData.caseStatus)?.label}
              </Badge>
            </div>
          </div>

          {/* Status Change Preview */}
          {action === 'advance' && nextStatus && (
            <div className="p-3 bg-success/10 border border-success/20 rounded-lg">
              <p className="text-sm text-success font-medium mb-2">Moving to</p>
              <div className="flex gap-2">
                <Badge className="bg-success text-success-foreground">
                  Intake: {INTAKE_STATUSES.find(s => s.value === nextStatus.intakeStatus)?.label}
                </Badge>
                <Badge className="bg-success text-success-foreground">
                  Operations: {OPERATIONAL_STATUSES.find(s => s.value === nextStatus.operationalStatus)?.label}
                </Badge>
              </div>
            </div>
          )}

          {action === 'revert' && prevStatus && (
            <div className="p-3 bg-warning/10 border border-warning/20 rounded-lg">
              <p className="text-sm text-warning font-medium mb-2">Reverting to</p>
              <div className="flex gap-2">
                <Badge className="bg-warning text-warning-foreground">
                  Intake: {INTAKE_STATUSES.find(s => s.value === prevStatus.intakeStatus)?.label}
                </Badge>
                <Badge className="bg-warning text-warning-foreground">
                  Operations: {OPERATIONAL_STATUSES.find(s => s.value === prevStatus.operationalStatus)?.label}
                </Badge>
              </div>
            </div>
          )}

          {/* Manual Status Selection (only for assign action) */}
          {action === 'assign' && (
            <>
              <div className="space-y-2">
                <Label>Intake Status</Label>
                <Select value={intakeStatus} onValueChange={(v) => {
                  setIntakeStatus(v as IntakeStatus);
                  // Reset operational status when moving away from I3
                  if (v !== 'I3_Ready_For_Management') {
                    setOperationalStatus('O0_Not_Started');
                  }
                }}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {INTAKE_STATUSES.map(s => (
                      <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Operational Status</Label>
                {intakeStatus !== 'I3_Ready_For_Management' ? (
                  <div className="p-3 bg-muted rounded-md text-sm text-muted-foreground">
                    <p>Operational stages are only available after reaching <strong>I3 - Ready for Management</strong>.</p>
                    <p className="mt-1">Current: <Badge variant="outline">O0 - Not Started</Badge></p>
                  </div>
                ) : (
                  <Select value={operationalStatus} onValueChange={(v) => setOperationalStatus(v as OperationalStatus)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {OPERATIONAL_STATUSES.map(s => (
                        <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </>
          )}

          {/* Assignee Selection */}
          <div className="space-y-2">
            <Label>Assign To</Label>
            <Select value={assignee} onValueChange={setAssignee}>
              <SelectTrigger>
                <SelectValue placeholder="Select assignee" />
              </SelectTrigger>
              <SelectContent>
                {USERS.map(user => (
                  <SelectItem key={user} value={user}>{user}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Department Selection */}
          <div className="space-y-2">
            <Label>Department</Label>
            <Select value={department} onValueChange={setDepartment}>
              <SelectTrigger>
                <SelectValue placeholder="Select department" />
              </SelectTrigger>
              <SelectContent>
                {DEPARTMENTS.map(dept => (
                  <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Justification (required for revert) */}
          <div className="space-y-2">
            <Label>{action === 'revert' ? 'Justification (Required)' : 'Notes (Optional)'}</Label>
            <Textarea
              value={justification}
              onChange={(e) => setJustification(e.target.value)}
              placeholder={action === 'revert' ? 'Explain why this case is being reverted...' : 'Add any notes about this change...'}
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleSave}
            disabled={action === 'revert' && !justification.trim()}
          >
            {action === 'assign' && 'Save Assignment'}
            {action === 'advance' && 'Advance Case'}
            {action === 'revert' && 'Revert Case'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
