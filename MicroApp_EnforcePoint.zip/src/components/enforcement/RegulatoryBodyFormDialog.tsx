import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { RegulatoryBody, RegulatoryLevel, OversightType } from "@/types/enforcepoint";

interface RegulatoryBodyFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  body?: RegulatoryBody | null;
  onSave: (body: Omit<RegulatoryBody, 'id' | 'createdAt' | 'updatedAt'>) => void;
}

const oversightTypeOptions: { value: OversightType; label: string }[] = [
  { value: 'survey', label: 'Survey' },
  { value: 'privacy', label: 'Privacy' },
  { value: 'fraud', label: 'Fraud' },
  { value: 'licensure', label: 'Licensure' },
  { value: 'life_safety', label: 'Life Safety' },
  { value: 'program_integrity', label: 'Program Integrity' },
  { value: 'other', label: 'Other' },
];

const US_STATES = [
  "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA",
  "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD",
  "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ",
  "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC",
  "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"
];

export function RegulatoryBodyFormDialog({
  open,
  onOpenChange,
  body,
  onSave,
}: RegulatoryBodyFormDialogProps) {
  const [formData, setFormData] = useState({
    name: "",
    abbreviation: "",
    level: "Federal" as RegulatoryLevel,
    jurisdiction: "",
    oversightTypes: [] as OversightType[],
    enforcementScopeTags: [] as string[],
    standardResponseDays: "",
    contactEmail: "",
    contactPhone: "",
    portalUrl: "",
    isActive: true,
  });

  useEffect(() => {
    if (body) {
      setFormData({
        name: body.name,
        abbreviation: body.abbreviation || "",
        level: body.level,
        jurisdiction: body.jurisdiction || "",
        oversightTypes: body.oversightTypes,
        enforcementScopeTags: body.enforcementScopeTags,
        standardResponseDays: body.standardResponseDays?.toString() || "",
        contactEmail: body.contactEmail || "",
        contactPhone: body.contactPhone || "",
        portalUrl: body.portalUrl || "",
        isActive: body.isActive,
      });
    } else {
      setFormData({
        name: "",
        abbreviation: "",
        level: "Federal",
        jurisdiction: "",
        oversightTypes: [],
        enforcementScopeTags: [],
        standardResponseDays: "",
        contactEmail: "",
        contactPhone: "",
        portalUrl: "",
        isActive: true,
      });
    }
  }, [body, open]);

  const handleOversightTypeToggle = (type: OversightType) => {
    setFormData(prev => ({
      ...prev,
      oversightTypes: prev.oversightTypes.includes(type)
        ? prev.oversightTypes.filter(t => t !== type)
        : [...prev.oversightTypes, type]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name: formData.name.trim(),
      abbreviation: formData.abbreviation.trim() || undefined,
      level: formData.level,
      jurisdiction: formData.jurisdiction || undefined,
      oversightTypes: formData.oversightTypes,
      enforcementScopeTags: formData.enforcementScopeTags,
      standardResponseDays: formData.standardResponseDays ? parseInt(formData.standardResponseDays) : undefined,
      contactEmail: formData.contactEmail.trim() || undefined,
      contactPhone: formData.contactPhone.trim() || undefined,
      portalUrl: formData.portalUrl.trim() || undefined,
      isActive: formData.isActive,
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{body ? "Edit Regulatory Body" : "Add Regulatory Body"}</DialogTitle>
          <DialogDescription>
            {body ? "Update the details of this regulatory body." : "Add a new regulatory body to the directory."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Centers for Medicare & Medicaid Services"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="abbreviation">Abbreviation</Label>
              <Input
                id="abbreviation"
                value={formData.abbreviation}
                onChange={(e) => setFormData({ ...formData, abbreviation: e.target.value })}
                placeholder="e.g., CMS"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="level">Level *</Label>
              <Select
                value={formData.level}
                onValueChange={(value: RegulatoryLevel) => setFormData({ ...formData, level: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Federal">Federal</SelectItem>
                  <SelectItem value="State">State</SelectItem>
                  <SelectItem value="Local">Local</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {(formData.level === "State" || formData.level === "Local") && (
              <div className="space-y-2">
                <Label htmlFor="jurisdiction">Jurisdiction (State)</Label>
                <Select
                  value={formData.jurisdiction}
                  onValueChange={(value) => setFormData({ ...formData, jurisdiction: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select state" />
                  </SelectTrigger>
                  <SelectContent>
                    {US_STATES.map(state => (
                      <SelectItem key={state} value={state}>{state}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>Oversight Types</Label>
            <div className="grid grid-cols-3 gap-2">
              {oversightTypeOptions.map(option => (
                <div key={option.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={option.value}
                    checked={formData.oversightTypes.includes(option.value)}
                    onCheckedChange={() => handleOversightTypeToggle(option.value)}
                  />
                  <Label htmlFor={option.value} className="text-sm font-normal cursor-pointer">
                    {option.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="standardResponseDays">Standard Response Days</Label>
            <Input
              id="standardResponseDays"
              type="number"
              value={formData.standardResponseDays}
              onChange={(e) => setFormData({ ...formData, standardResponseDays: e.target.value })}
              placeholder="e.g., 10"
              min={1}
            />
          </div>

          <div className="border-t pt-4">
            <h4 className="font-medium mb-3">Contact Information</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="contactEmail">Email</Label>
                <Input
                  id="contactEmail"
                  type="email"
                  value={formData.contactEmail}
                  onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })}
                  placeholder="contact@agency.gov"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contactPhone">Phone</Label>
                <Input
                  id="contactPhone"
                  value={formData.contactPhone}
                  onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                  placeholder="(555) 123-4567"
                />
              </div>
            </div>
            <div className="space-y-2 mt-4">
              <Label htmlFor="portalUrl">Portal URL</Label>
              <Input
                id="portalUrl"
                type="url"
                value={formData.portalUrl}
                onChange={(e) => setFormData({ ...formData, portalUrl: e.target.value })}
                placeholder="https://portal.agency.gov"
              />
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="isActive"
              checked={formData.isActive}
              onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked as boolean })}
            />
            <Label htmlFor="isActive" className="cursor-pointer">Active</Label>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={!formData.name.trim()}>
              {body ? "Save Changes" : "Add Body"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}