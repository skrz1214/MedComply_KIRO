import { Enforcement } from '@/types/enforcement';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { StatusBadge, ImpactBadge, PaymentBadge } from './StatusBadge';
import { format } from 'date-fns';
import { 
  ArrowLeft, 
  Pencil, 
  Trash2, 
  Calendar, 
  Building2, 
  DollarSign,
  Clock,
  Link as LinkIcon,
  FileText,
  MessageSquare,
  User,
  Mail,
  Phone,
  Paperclip,
  ExternalLink
} from 'lucide-react';

interface EnforcementViewProps {
  enforcement: Enforcement;
  onBack: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

export function EnforcementView({ enforcement, onBack, onEdit, onDelete }: EnforcementViewProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack} className="gap-2">
          <ArrowLeft className="h-4 w-4" />
          Back to List
        </Button>
        {enforcement.status !== 'Deleted' && (
          <div className="flex gap-2">
            <Button variant="outline" onClick={onEdit}>
              <Pencil className="h-4 w-4 mr-2" />
              Edit
            </Button>
            <Button variant="destructive" onClick={onDelete}>
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </Button>
          </div>
        )}
      </div>

      <Card className="shadow-lg">
        <CardHeader className="border-b border-border bg-muted/30">
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2 flex-wrap">
                <StatusBadge status={enforcement.status} />
                <ImpactBadge impact={enforcement.impactLevel} />
                {enforcement.paymentStatus && (
                  <PaymentBadge status={enforcement.paymentStatus} />
                )}
              </div>
              <CardTitle className="text-2xl">
                {enforcement.description.split(' - ')[0]} #{enforcement.referenceNumber}
              </CardTitle>
            </div>
            {enforcement.ticketId && (
              <div className="flex items-center gap-2 px-3 py-2 bg-info/10 border border-info/20 rounded-lg text-sm">
                <LinkIcon className="h-4 w-4 text-info" />
                <span className="font-medium text-info">{enforcement.ticketId}</span>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="pt-6 space-y-6">
          {/* Enforcement Information */}
          <div>
            <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-4">
              Enforcement Information
            </h3>
            <div className="grid gap-6 md:grid-cols-3">
              <div className="space-y-1">
                <p className="text-xs font-medium text-muted-foreground">Reference Number</p>
                <p className="font-semibold">{enforcement.referenceNumber}</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-medium text-muted-foreground">Status</p>
                <StatusBadge status={enforcement.status} />
              </div>
              <div className="space-y-1">
                <p className="text-xs font-medium text-muted-foreground">Fine Amount</p>
                <p className="font-semibold text-lg">{formatCurrency(enforcement.penaltyAmount)}</p>
              </div>
            </div>
          </div>

          {/* Penalty Information */}
          <div className="border-t border-border pt-6">
            <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-4">
              Penalty Information
            </h3>
            <div className="grid gap-6 md:grid-cols-3">
              <div className="space-y-1">
                <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                  <Calendar className="h-3.5 w-3.5" /> Issue Date
                </p>
                <p className="font-medium">{format(enforcement.issueDate, 'MMMM d, yyyy')}</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                  <Calendar className="h-3.5 w-3.5" /> Due Date
                </p>
                <p className="font-medium">
                  {enforcement.dueDate ? format(enforcement.dueDate, 'MMMM d, yyyy') : 'Not set'}
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                  <DollarSign className="h-3.5 w-3.5" /> Payment Status
                </p>
                {enforcement.paymentStatus ? (
                  <PaymentBadge status={enforcement.paymentStatus} />
                ) : (
                  <p className="text-muted-foreground">Not applicable</p>
                )}
              </div>
            </div>
          </div>

          {/* Violation Details */}
          <div className="border-t border-border pt-6">
            <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-4">
              Violation Details
            </h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                  <FileText className="h-4 w-4" /> Description
                </p>
                <p className="text-foreground leading-relaxed">{enforcement.description}</p>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-1">
                  <p className="text-xs font-medium text-muted-foreground">Impact Level</p>
                  <ImpactBadge impact={enforcement.impactLevel} />
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-medium text-muted-foreground">Penalty Type</p>
                  <p className="font-medium">{enforcement.penaltyType}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Governing Authority */}
          <div className="border-t border-border pt-6">
            <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-4">
              Governing Authority
            </h3>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-1">
                <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                  <Building2 className="h-3.5 w-3.5" /> Authority Name
                </p>
                <p className="font-medium">{enforcement.governingAuthority?.name || enforcement.governingBody}</p>
              </div>
              {enforcement.governingAuthority?.contactPerson && (
                <div className="space-y-1">
                  <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                    <User className="h-3.5 w-3.5" /> Contact Person
                  </p>
                  <p className="font-medium">{enforcement.governingAuthority.contactPerson}</p>
                </div>
              )}
              {enforcement.governingAuthority?.email && (
                <div className="space-y-1">
                  <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                    <Mail className="h-3.5 w-3.5" /> Email
                  </p>
                  <a href={`mailto:${enforcement.governingAuthority.email}`} className="font-medium text-primary hover:underline">
                    {enforcement.governingAuthority.email}
                  </a>
                </div>
              )}
              {enforcement.governingAuthority?.phone && (
                <div className="space-y-1">
                  <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                    <Phone className="h-3.5 w-3.5" /> Phone
                  </p>
                  <a href={`tel:${enforcement.governingAuthority.phone}`} className="font-medium text-primary hover:underline">
                    {enforcement.governingAuthority.phone}
                  </a>
                </div>
              )}
            </div>
          </div>

          {/* Evidence & Documentation */}
          {(enforcement.attachments && enforcement.attachments.length > 0) && (
            <div className="border-t border-border pt-6">
              <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-4 flex items-center gap-1.5">
                <Paperclip className="h-4 w-4" /> Evidence & Documentation
              </h3>
              <div className="flex flex-wrap gap-2">
                {enforcement.attachments.map((file, index) => (
                  <div key={index} className="flex items-center gap-2 bg-muted px-3 py-2 rounded-lg text-sm">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <span>{file}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Source URL */}
          {enforcement.sourceUrl && (
            <div className="border-t border-border pt-6">
              <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-4">
                Source Reference
              </h3>
              <a 
                href={enforcement.sourceUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-primary hover:underline"
              >
                <ExternalLink className="h-4 w-4" />
                {enforcement.sourceUrl}
              </a>
            </div>
          )}

          {/* ComplianceConnect Ticket */}
          {enforcement.ticketDescription && (
            <div className="border-t border-border pt-6">
              <div className="space-y-2 p-4 bg-muted/50 rounded-lg border border-border">
                <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
                  <LinkIcon className="h-4 w-4" /> ComplianceConnect Ticket Description
                </p>
                <p className="text-foreground text-sm leading-relaxed">{enforcement.ticketDescription}</p>
              </div>
            </div>
          )}

          {/* Notes */}
          {enforcement.notes && (
            <div className="border-t border-border pt-6">
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
                  <MessageSquare className="h-4 w-4" /> Notes
                </p>
                <p className="text-foreground leading-relaxed">{enforcement.notes}</p>
              </div>
            </div>
          )}

          <div className="border-t border-border pt-6">
            <p className="text-xs text-muted-foreground">
              Created on {format(enforcement.createdAt, 'MMMM d, yyyy')} • Last modified {format(enforcement.updatedAt, 'MMMM d, yyyy')}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
