import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { X, Search, Link2, FileText, AlertTriangle, Shield, BookOpen, Activity, MessageSquare, ClipboardCheck } from "lucide-react";

export type MicroappType = "issue" | "capa" | "citation" | "citationCase" | "risk" | "feedback" | "audit";

export interface LinkableItem {
  id: string;
  type: MicroappType;
  title: string;
  reference: string;
  status: string;
  description?: string;
  createdAt: Date;
}

// Mock data for linkable items from other microapps
export const mockLinkableItems: LinkableItem[] = [
  // ComplianceConnect Issues
  { id: "issue-001", type: "issue", title: "HIPAA Privacy Training Gap", reference: "ISS-2024-001", status: "Open", description: "Staff training records incomplete", createdAt: new Date("2024-01-15") },
  { id: "issue-002", type: "issue", title: "Documentation Deficiency", reference: "ISS-2024-002", status: "In Progress", description: "Patient consent forms missing signatures", createdAt: new Date("2024-02-10") },
  { id: "issue-003", type: "issue", title: "Medication Storage Issue", reference: "ISS-2024-003", status: "Open", description: "Temperature logs not maintained", createdAt: new Date("2024-03-05") },
  { id: "issue-004", type: "issue", title: "Infection Control Gap", reference: "ISS-2024-004", status: "Resolved", description: "Hand hygiene compliance below threshold", createdAt: new Date("2024-03-20") },
  { id: "issue-005", type: "issue", title: "Emergency Preparedness", reference: "ISS-2024-005", status: "Open", description: "Evacuation drill overdue", createdAt: new Date("2024-04-01") },
  
  // ActionGuard CAPA Records
  { id: "capa-001", type: "capa", title: "HIPAA Training Program Enhancement", reference: "CAPA-2024-001", status: "Open", description: "Implement quarterly training schedule", createdAt: new Date("2024-01-20") },
  { id: "capa-002", type: "capa", title: "Consent Form Process Improvement", reference: "CAPA-2024-002", status: "In Progress", description: "Electronic consent system implementation", createdAt: new Date("2024-02-15") },
  { id: "capa-003", type: "capa", title: "Temperature Monitoring System", reference: "CAPA-2024-003", status: "Pending Verification", description: "Automated temperature logging", createdAt: new Date("2024-03-10") },
  { id: "capa-004", type: "capa", title: "Hand Hygiene Compliance Program", reference: "CAPA-2024-004", status: "Closed", description: "Installation of additional sanitizer stations", createdAt: new Date("2024-03-25") },
  
  // Citations Library
  { id: "cite-001", type: "citation", title: "F-Tag F880 - Infection Control", reference: "F880", status: "Active", description: "Infection Prevention and Control", createdAt: new Date("2023-01-01") },
  { id: "cite-002", type: "citation", title: "F-Tag F684 - Quality of Care", reference: "F684", status: "Active", description: "Quality of Care requirements", createdAt: new Date("2023-01-01") },
  { id: "cite-003", type: "citation", title: "F-Tag F758 - Medication Management", reference: "F758", status: "Active", description: "Free from Unnecessary Psychotropic Drugs", createdAt: new Date("2023-01-01") },
  { id: "cite-004", type: "citation", title: "45 CFR 164.530 - Privacy Safeguards", reference: "164.530", status: "Active", description: "HIPAA Administrative Requirements", createdAt: new Date("2023-01-01") },
  
  // Citation Cases
  { id: "cc-001", type: "citationCase", title: "2024 Annual Survey - F880 Citation", reference: "CC-2024-001", status: "Active", description: "Citation from annual survey", createdAt: new Date("2024-02-01") },
  { id: "cc-002", type: "citationCase", title: "Complaint Investigation - F684", reference: "CC-2024-002", status: "Resolved", description: "Citation from complaint investigation", createdAt: new Date("2024-03-15") },

  // RiskGuard - Risk Management Items
  { id: "risk-001", type: "risk", title: "Fall Risk - North Wing", reference: "RISK-2024-001", status: "High", description: "Elevated fall incidents in north wing corridor", createdAt: new Date("2024-01-10") },
  { id: "risk-002", type: "risk", title: "Medication Error Risk", reference: "RISK-2024-002", status: "Medium", description: "Similar medication names causing confusion", createdAt: new Date("2024-02-05") },
  { id: "risk-003", type: "risk", title: "Data Breach Risk", reference: "RISK-2024-003", status: "High", description: "Outdated security protocols on legacy systems", createdAt: new Date("2024-02-20") },
  { id: "risk-004", type: "risk", title: "Staffing Shortage Risk", reference: "RISK-2024-004", status: "Critical", description: "Nursing staff below minimum requirements", createdAt: new Date("2024-03-01") },
  { id: "risk-005", type: "risk", title: "Equipment Failure Risk", reference: "RISK-2024-005", status: "Low", description: "Aging ventilator equipment", createdAt: new Date("2024-03-15") },

  // FeedbackHub - Complaints and Grievances
  { id: "fb-001", type: "feedback", title: "Patient Complaint - Wait Times", reference: "FB-2024-001", status: "Under Review", description: "Extended wait times in ER department", createdAt: new Date("2024-01-25") },
  { id: "fb-002", type: "feedback", title: "Family Grievance - Communication", reference: "FB-2024-002", status: "Resolved", description: "Lack of updates during surgery", createdAt: new Date("2024-02-08") },
  { id: "fb-003", type: "feedback", title: "Staff Complaint - Safety Concern", reference: "FB-2024-003", status: "Open", description: "Inadequate PPE supplies reported", createdAt: new Date("2024-02-28") },
  { id: "fb-004", type: "feedback", title: "Patient Grievance - Billing", reference: "FB-2024-004", status: "Escalated", description: "Disputed charges for services", createdAt: new Date("2024-03-10") },
  { id: "fb-005", type: "feedback", title: "Visitor Feedback - Parking", reference: "FB-2024-005", status: "Acknowledged", description: "Insufficient parking availability", createdAt: new Date("2024-03-22") },

  // AuditPro - Audit Records
  { id: "audit-001", type: "audit", title: "Q1 2024 Infection Control Audit", reference: "AUD-2024-001", status: "Completed", description: "Quarterly infection control compliance audit", createdAt: new Date("2024-01-15") },
  { id: "audit-002", type: "audit", title: "HIPAA Security Audit", reference: "AUD-2024-002", status: "In Progress", description: "Annual HIPAA security assessment", createdAt: new Date("2024-02-01") },
  { id: "audit-003", type: "audit", title: "Medication Administration Audit", reference: "AUD-2024-003", status: "Scheduled", description: "Monthly medication administration review", createdAt: new Date("2024-03-01") },
  { id: "audit-004", type: "audit", title: "Documentation Compliance Audit", reference: "AUD-2024-004", status: "Completed", description: "Medical records documentation audit", createdAt: new Date("2024-03-15") },
  { id: "audit-005", type: "audit", title: "Fire Safety Audit", reference: "AUD-2024-005", status: "Finding Review", description: "Annual fire safety and evacuation audit", createdAt: new Date("2024-04-01") },
];

interface CrossLinkSelectorProps {
  selectedIssues: string[];
  selectedCapas: string[];
  selectedCitations: string[];
  selectedCitationCases?: string[];
  selectedRisks?: string[];
  selectedFeedback?: string[];
  selectedAudits?: string[];
  onIssuesChange: (ids: string[]) => void;
  onCapasChange: (ids: string[]) => void;
  onCitationsChange: (ids: string[]) => void;
  onCitationCasesChange?: (ids: string[]) => void;
  onRisksChange?: (ids: string[]) => void;
  onFeedbackChange?: (ids: string[]) => void;
  onAuditsChange?: (ids: string[]) => void;
  compact?: boolean;
}

const getMicroappIcon = (type: MicroappType) => {
  switch (type) {
    case "issue":
      return <AlertTriangle className="h-4 w-4" />;
    case "capa":
      return <Shield className="h-4 w-4" />;
    case "citation":
      return <BookOpen className="h-4 w-4" />;
    case "citationCase":
      return <FileText className="h-4 w-4" />;
    case "risk":
      return <Activity className="h-4 w-4" />;
    case "feedback":
      return <MessageSquare className="h-4 w-4" />;
    case "audit":
      return <ClipboardCheck className="h-4 w-4" />;
  }
};

const getMicroappLabel = (type: MicroappType) => {
  switch (type) {
    case "issue":
      return "ComplianceConnect Issue";
    case "capa":
      return "ActionGuard CAPA";
    case "citation":
      return "Citation";
    case "citationCase":
      return "Citation Case";
    case "risk":
      return "RiskGuard Risk";
    case "feedback":
      return "FeedbackHub Item";
    case "audit":
      return "AuditPro Audit";
  }
};

const getMicroappColor = (type: MicroappType) => {
  switch (type) {
    case "issue":
      return "bg-orange-500/10 text-orange-600 border-orange-200";
    case "capa":
      return "bg-blue-500/10 text-blue-600 border-blue-200";
    case "citation":
      return "bg-purple-500/10 text-purple-600 border-purple-200";
    case "citationCase":
      return "bg-emerald-500/10 text-emerald-600 border-emerald-200";
    case "risk":
      return "bg-red-500/10 text-red-600 border-red-200";
    case "feedback":
      return "bg-amber-500/10 text-amber-600 border-amber-200";
    case "audit":
      return "bg-indigo-500/10 text-indigo-600 border-indigo-200";
  }
};

export function CrossLinkSelector({
  selectedIssues,
  selectedCapas,
  selectedCitations,
  selectedCitationCases = [],
  selectedRisks = [],
  selectedFeedback = [],
  selectedAudits = [],
  onIssuesChange,
  onCapasChange,
  onCitationsChange,
  onCitationCasesChange,
  onRisksChange,
  onFeedbackChange,
  onAuditsChange,
  compact = false,
}: CrossLinkSelectorProps) {
  const [activeTab, setActiveTab] = useState<MicroappType>("issue");
  const [searchTerm, setSearchTerm] = useState("");

  const getSelectedIds = (type: MicroappType): string[] => {
    switch (type) {
      case "issue":
        return selectedIssues;
      case "capa":
        return selectedCapas;
      case "citation":
        return selectedCitations;
      case "citationCase":
        return selectedCitationCases;
      case "risk":
        return selectedRisks;
      case "feedback":
        return selectedFeedback;
      case "audit":
        return selectedAudits;
    }
  };

  const handleToggleItem = (item: LinkableItem) => {
    const currentIds = getSelectedIds(item.type);
    const isSelected = currentIds.includes(item.id);
    const newIds = isSelected
      ? currentIds.filter((id) => id !== item.id)
      : [...currentIds, item.id];

    switch (item.type) {
      case "issue":
        onIssuesChange(newIds);
        break;
      case "capa":
        onCapasChange(newIds);
        break;
      case "citation":
        onCitationsChange(newIds);
        break;
      case "citationCase":
        onCitationCasesChange?.(newIds);
        break;
      case "risk":
        onRisksChange?.(newIds);
        break;
      case "feedback":
        onFeedbackChange?.(newIds);
        break;
      case "audit":
        onAuditsChange?.(newIds);
        break;
    }
  };

  const handleRemoveItem = (id: string, type: MicroappType) => {
    switch (type) {
      case "issue":
        onIssuesChange(selectedIssues.filter((i) => i !== id));
        break;
      case "capa":
        onCapasChange(selectedCapas.filter((i) => i !== id));
        break;
      case "citation":
        onCitationsChange(selectedCitations.filter((i) => i !== id));
        break;
      case "citationCase":
        onCitationCasesChange?.(selectedCitationCases.filter((i) => i !== id));
        break;
      case "risk":
        onRisksChange?.(selectedRisks.filter((i) => i !== id));
        break;
      case "feedback":
        onFeedbackChange?.(selectedFeedback.filter((i) => i !== id));
        break;
      case "audit":
        onAuditsChange?.(selectedAudits.filter((i) => i !== id));
        break;
    }
  };

  const filteredItems = mockLinkableItems.filter(
    (item) =>
      item.type === activeTab &&
      (item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.reference.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const allSelectedItems = mockLinkableItems.filter(
    (item) =>
      selectedIssues.includes(item.id) ||
      selectedCapas.includes(item.id) ||
      selectedCitations.includes(item.id) ||
      selectedCitationCases.includes(item.id) ||
      selectedRisks.includes(item.id) ||
      selectedFeedback.includes(item.id) ||
      selectedAudits.includes(item.id)
  );

  const totalLinked = selectedIssues.length + selectedCapas.length + selectedCitations.length + 
    selectedCitationCases.length + selectedRisks.length + selectedFeedback.length + selectedAudits.length;

  return (
    <div className="space-y-4">
      {/* Selected Items Summary */}
      {allSelectedItems.length > 0 && (
        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <Link2 className="h-4 w-4" />
            Linked Items ({totalLinked})
          </Label>
          <div className="flex flex-wrap gap-2">
            {allSelectedItems.map((item) => (
              <Badge
                key={item.id}
                variant="outline"
                className={`${getMicroappColor(item.type)} flex items-center gap-1`}
              >
                {getMicroappIcon(item.type)}
                <span className="max-w-[150px] truncate">{item.reference}</span>
                <button
                  onClick={() => handleRemoveItem(item.id, item.type)}
                  className="ml-1 hover:bg-muted rounded-full p-0.5"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Microapp Type Selector */}
      <div className="space-y-2">
        <Label>Link from Microapp</Label>
        <Select value={activeTab} onValueChange={(v) => setActiveTab(v as MicroappType)}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="issue">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-orange-500" />
                ComplianceConnect ({mockLinkableItems.filter(i => i.type === "issue").length})
              </div>
            </SelectItem>
            <SelectItem value="capa">
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-blue-500" />
                ActionGuard CAPA ({mockLinkableItems.filter(i => i.type === "capa").length})
              </div>
            </SelectItem>
            <SelectItem value="citation">
              <div className="flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-purple-500" />
                Citations Library ({mockLinkableItems.filter(i => i.type === "citation").length})
              </div>
            </SelectItem>
            <SelectItem value="citationCase">
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-emerald-500" />
                Citation Cases ({mockLinkableItems.filter(i => i.type === "citationCase").length})
              </div>
            </SelectItem>
            <SelectItem value="risk">
              <div className="flex items-center gap-2">
                <Activity className="h-4 w-4 text-red-500" />
                RiskGuard ({mockLinkableItems.filter(i => i.type === "risk").length})
              </div>
            </SelectItem>
            <SelectItem value="feedback">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-amber-500" />
                FeedbackHub ({mockLinkableItems.filter(i => i.type === "feedback").length})
              </div>
            </SelectItem>
            <SelectItem value="audit">
              <div className="flex items-center gap-2">
                <ClipboardCheck className="h-4 w-4 text-indigo-500" />
                AuditPro ({mockLinkableItems.filter(i => i.type === "audit").length})
              </div>
            </SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder={`Search ${getMicroappLabel(activeTab).toLowerCase()}s...`}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Items List */}
      <ScrollArea className={compact ? "h-[200px]" : "h-[300px]"}>
        <div className="space-y-2 pr-4">
          {filteredItems.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">
              No {getMicroappLabel(activeTab).toLowerCase()}s found
            </p>
          ) : (
            filteredItems.map((item) => {
              const isSelected = getSelectedIds(item.type).includes(item.id);
              return (
                <div
                  key={item.id}
                  className={`flex items-start gap-3 p-3 border rounded-lg cursor-pointer transition-colors ${
                    isSelected ? "bg-primary/5 border-primary" : "hover:bg-muted/50"
                  }`}
                  onClick={() => handleToggleItem(item)}
                >
                  <Checkbox checked={isSelected} className="mt-1" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={getMicroappColor(item.type)}>
                        {item.reference}
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        {item.status}
                      </Badge>
                    </div>
                    <p className="font-medium text-sm mt-1 truncate">{item.title}</p>
                    {item.description && (
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">
                        {item.description}
                      </p>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </ScrollArea>
    </div>
  );
}

// Display component for showing linked items in read-only mode
interface LinkedItemsDisplayProps {
  issueIds: string[];
  capaIds: string[];
  citationIds: string[];
  citationCaseIds?: string[];
  riskIds?: string[];
  feedbackIds?: string[];
  auditIds?: string[];
}

export function LinkedItemsDisplay({
  issueIds,
  capaIds,
  citationIds,
  citationCaseIds = [],
  riskIds = [],
  feedbackIds = [],
  auditIds = [],
}: LinkedItemsDisplayProps) {
  const allIds = [...issueIds, ...capaIds, ...citationIds, ...citationCaseIds, ...riskIds, ...feedbackIds, ...auditIds];
  const linkedItems = mockLinkableItems.filter((item) => allIds.includes(item.id));

  if (linkedItems.length === 0) {
    return (
      <p className="text-sm text-muted-foreground">No linked items</p>
    );
  }

  return (
    <div className="space-y-2">
      {linkedItems.map((item) => (
        <div
          key={item.id}
          className="flex items-center gap-2 p-2 border rounded-lg bg-muted/30"
        >
          {getMicroappIcon(item.type)}
          <Badge variant="outline" className={getMicroappColor(item.type)}>
            {item.reference}
          </Badge>
          <span className="text-sm truncate flex-1">{item.title}</span>
          <Badge variant="secondary" className="text-xs">
            {item.status}
          </Badge>
        </div>
      ))}
    </div>
  );
}
