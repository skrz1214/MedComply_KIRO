import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { EnforcementCase, LibraryReference, AppliedLibrarySnapshot, LibraryItemType } from "@/types/enforcepoint";
import { BookOpen, Link as LinkIcon, Package, Eye, Clock, User, RefreshCw } from "lucide-react";
import { format } from "date-fns";

interface LibraryReferencesTabProps {
  caseData: EnforcementCase;
  onOpenLibrary: () => void;
  onUpdateFromLatest?: (snapshotId: string) => void;
}

const ITEM_TYPE_LABELS: Record<LibraryItemType, string> = {
  'regulatory_body': 'Regulatory Body',
  'remedy': 'Remedy/Action',
  'deadline_rule': 'Deadline Rule',
  'response_template': 'Response Template',
  'evidence_requirement': 'Evidence Requirement',
  'finding_category': 'Finding Category',
};

const TARGET_LABELS: Record<string, string> = {
  'case_overview': 'Case Overview',
  'deadline': 'Deadline',
  'remedy_action': 'Remedy/Action',
  'response_package': 'Response Package',
  'evidence_checklist': 'Evidence Checklist',
  'finding': 'Finding',
};

export function LibraryReferencesTab({ caseData, onOpenLibrary, onUpdateFromLatest }: LibraryReferencesTabProps) {
  const [selectedSnapshot, setSelectedSnapshot] = useState<AppliedLibrarySnapshot | null>(null);
  const [showSnapshotModal, setShowSnapshotModal] = useState(false);

  const references = caseData.libraryReferences || [];
  const appliedSnapshots = caseData.appliedLibrarySnapshots || [];

  const viewSnapshot = (snapshot: AppliedLibrarySnapshot) => {
    setSelectedSnapshot(snapshot);
    setShowSnapshotModal(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Library References</h3>
          <p className="text-sm text-muted-foreground">
            Library items referenced or applied to this case
          </p>
        </div>
        <Button onClick={onOpenLibrary}>
          <BookOpen className="h-4 w-4 mr-2" />
          Browse Library
        </Button>
      </div>

      {/* Applied Items (Snapshots) */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Package className="h-5 w-5" />
            Applied Items ({appliedSnapshots.length})
          </CardTitle>
          <CardDescription>
            Library items that have been applied to create case records. Data is snapshotted at time of application.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {appliedSnapshots.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Package className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No library items have been applied yet.</p>
              <p className="text-sm">Apply items from the library to create case records.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {appliedSnapshots.map((snapshot) => (
                <div 
                  key={snapshot.id} 
                  className="p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{snapshot.libraryItemName}</span>
                        <Badge variant="outline" className="text-xs">
                          v{snapshot.libraryItemVersion}
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          {ITEM_TYPE_LABELS[snapshot.libraryItemType]}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {format(new Date(snapshot.appliedAt), 'MMM d, yyyy h:mm a')}
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          {snapshot.appliedBy}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Applied to: {TARGET_LABELS[snapshot.appliedToTarget]}
                        {snapshot.targetEntityId && ` (${snapshot.targetEntityId})`}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => viewSnapshot(snapshot)}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        View Snapshot
                      </Button>
                      {onUpdateFromLatest && (
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => onUpdateFromLatest(snapshot.id)}
                        >
                          <RefreshCw className="h-4 w-4 mr-1" />
                          Update
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Reference Links */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <LinkIcon className="h-5 w-5" />
            References ({references.length})
          </CardTitle>
          <CardDescription>
            Library items linked for reference. These do not modify case data.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {references.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <LinkIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No library items have been referenced yet.</p>
              <p className="text-sm">Reference items for context without modifying case data.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {references.map((ref) => (
                <div 
                  key={ref.id} 
                  className="p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{ref.libraryItemName}</span>
                        <Badge variant="outline" className="text-xs">
                          v{ref.libraryItemVersion}
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          {ITEM_TYPE_LABELS[ref.libraryItemType]}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {format(new Date(ref.referencedAt), 'MMM d, yyyy h:mm a')}
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          {ref.referencedBy}
                        </span>
                      </div>
                      {ref.note && (
                        <p className="text-sm text-muted-foreground italic">"{ref.note}"</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Snapshot View Modal */}
      <Dialog open={showSnapshotModal} onOpenChange={setShowSnapshotModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Snapshot Details</DialogTitle>
            <DialogDescription>
              This is the data that was captured when the library item was applied.
            </DialogDescription>
          </DialogHeader>
          {selectedSnapshot && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Item Name</p>
                  <p className="font-medium">{selectedSnapshot.libraryItemName}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Version</p>
                  <p className="font-medium">v{selectedSnapshot.libraryItemVersion}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Applied By</p>
                  <p className="font-medium">{selectedSnapshot.appliedBy}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Applied At</p>
                  <p className="font-medium">{format(new Date(selectedSnapshot.appliedAt), 'MMM d, yyyy h:mm a')}</p>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <p className="text-sm text-muted-foreground mb-2">Snapshot Payload</p>
                <ScrollArea className="h-[300px] border rounded-lg p-4">
                  <pre className="text-xs whitespace-pre-wrap">
                    {JSON.stringify(selectedSnapshot.snapshotPayload, null, 2)}
                  </pre>
                </ScrollArea>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
