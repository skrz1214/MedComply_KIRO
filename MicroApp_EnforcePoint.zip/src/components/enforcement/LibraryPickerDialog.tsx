import { useState, useMemo } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useEnforcePoint } from "@/context/EnforcePointContext";
import { 
  LibraryItemType, 
  IntakeStatus, 
  OperationalStatus,
  EnforcementCase,
  RemedyLibraryItem,
  DeadlineRuleLibraryItem,
  ResponseTemplateLibraryItem,
  EvidenceRequirementLibraryItem,
  FindingCategoryLibraryItem,
} from "@/types/enforcepoint";
import { Search, BookOpen, Clock, FileText, Shield, Tag, Building2, Lightbulb, Link as LinkIcon } from "lucide-react";

interface LibraryPickerDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  caseData: EnforcementCase;
  onReference: (itemType: LibraryItemType, itemId: string, itemName: string, version: number, note?: string) => void;
  onApply: (itemType: LibraryItemType, itemId: string, itemName: string, version: number, targetType: string) => void;
  showRecommended?: boolean;
}

// Define which library items are applicable at each stage
const INTAKE_APPLICABLE: Record<IntakeStatus, LibraryItemType[]> = {
  'I0_Draft': ['regulatory_body', 'evidence_requirement'],
  'I1_Notice_Logged': ['regulatory_body', 'deadline_rule', 'evidence_requirement', 'finding_category'],
  'I2_Triage_Assignment': ['regulatory_body', 'deadline_rule', 'response_template', 'evidence_requirement', 'finding_category'],
  'I3_Ready_For_Management': ['regulatory_body', 'deadline_rule', 'response_template', 'evidence_requirement', 'finding_category', 'remedy'],
};

const OPERATIONAL_APPLICABLE: Record<OperationalStatus, LibraryItemType[]> = {
  'O0_Not_Started': ['regulatory_body', 'deadline_rule', 'response_template', 'evidence_requirement', 'finding_category'],
  'O1_Response_Planning': ['regulatory_body', 'deadline_rule', 'response_template', 'evidence_requirement', 'finding_category', 'remedy'],
  'O2_Remediation_Linked': ['regulatory_body', 'deadline_rule', 'response_template', 'evidence_requirement', 'finding_category', 'remedy'],
  'O3_Response_In_Progress': ['regulatory_body', 'deadline_rule', 'response_template', 'evidence_requirement', 'finding_category', 'remedy'],
  'O4_Submitted_Awaiting': ['regulatory_body', 'deadline_rule', 'response_template', 'evidence_requirement', 'remedy'],
  'O5_Remedies_Active': ['regulatory_body', 'deadline_rule', 'evidence_requirement', 'remedy'],
  'O6_Verification_Revisit': ['regulatory_body', 'deadline_rule', 'evidence_requirement', 'remedy'],
  'O7_Closed': ['regulatory_body'], // Reference only for closed cases
  'O8_Reopened': ['regulatory_body', 'deadline_rule', 'response_template', 'evidence_requirement', 'finding_category', 'remedy'],
};

const LIBRARY_ITEM_LABELS: Record<LibraryItemType, { label: string; icon: React.ElementType }> = {
  'regulatory_body': { label: 'Regulatory Bodies', icon: Building2 },
  'remedy': { label: 'Remedies & Actions', icon: Shield },
  'deadline_rule': { label: 'Deadline Rules', icon: Clock },
  'response_template': { label: 'Response Templates', icon: FileText },
  'evidence_requirement': { label: 'Evidence Requirements', icon: BookOpen },
  'finding_category': { label: 'Finding Categories', icon: Tag },
};

export function LibraryPickerDialog({
  open,
  onOpenChange,
  caseData,
  onReference,
  onApply,
  showRecommended = true,
}: LibraryPickerDialogProps) {
  const { 
    regulatoryBodies, 
    remedyLibraryItems, 
    deadlineRuleLibraryItems, 
    responseTemplateLibraryItems,
    evidenceRequirementLibraryItems,
    findingCategoryLibraryItems,
  } = useEnforcePoint();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTab, setSelectedTab] = useState<LibraryItemType>("remedy");
  const [selectedItem, setSelectedItem] = useState<{ type: LibraryItemType; id: string; name: string; version: number } | null>(null);

  const isClosed = caseData.caseStatus === 'O7_Closed';
  
  // Get applicable library item types for current stage
  const applicableTypes = useMemo(() => {
    const intakeApplicable = INTAKE_APPLICABLE[caseData.intakeStatus] || [];
    const operationalApplicable = OPERATIONAL_APPLICABLE[caseData.caseStatus] || [];
    return [...new Set([...intakeApplicable, ...operationalApplicable])];
  }, [caseData.intakeStatus, caseData.caseStatus]);

  // Filter library items based on search and published status
  const filteredRemedies = useMemo(() => {
    return remedyLibraryItems.filter(item => 
      item.status === 'Published' &&
      (item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
       item.description.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [remedyLibraryItems, searchTerm]);

  const filteredDeadlineRules = useMemo(() => {
    return deadlineRuleLibraryItems.filter(item =>
      item.status === 'Published' &&
      item.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [deadlineRuleLibraryItems, searchTerm]);

  const filteredResponseTemplates = useMemo(() => {
    return responseTemplateLibraryItems.filter(item =>
      item.status === 'Published' &&
      item.templateName.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [responseTemplateLibraryItems, searchTerm]);

  const filteredEvidenceRequirements = useMemo(() => {
    return evidenceRequirementLibraryItems.filter(item =>
      item.status === 'Published' &&
      item.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [evidenceRequirementLibraryItems, searchTerm]);

  const filteredFindingCategories = useMemo(() => {
    return findingCategoryLibraryItems.filter(item =>
      item.status === 'Published' &&
      item.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [findingCategoryLibraryItems, searchTerm]);

  const filteredRegulatoryBodies = useMemo(() => {
    return regulatoryBodies.filter(item =>
      item.isActive &&
      (item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
       (item.abbreviation?.toLowerCase().includes(searchTerm.toLowerCase())))
    );
  }, [regulatoryBodies, searchTerm]);

  // Get recommended items based on case context
  const recommendedItems = useMemo(() => {
    const recommendations: Array<{ type: LibraryItemType; item: any; reason: string }> = [];
    
    // Recommend remedies based on regulatory body
    filteredRemedies
      .filter(r => r.regulatoryBodyTags.includes(caseData.regulatoryBodyId))
      .slice(0, 2)
      .forEach(item => {
        recommendations.push({ 
          type: 'remedy', 
          item, 
          reason: 'Matches regulatory body' 
        });
      });
    
    // Recommend deadline rules based on case type
    filteredDeadlineRules
      .filter(d => d.caseType === caseData.caseType || d.regulatoryBodyId === caseData.regulatoryBodyId)
      .slice(0, 2)
      .forEach(item => {
        recommendations.push({ 
          type: 'deadline_rule', 
          item, 
          reason: 'Matches case type' 
        });
      });

    // Recommend response templates
    filteredResponseTemplates
      .filter(t => t.caseType === caseData.caseType || t.regulatoryBodyId === caseData.regulatoryBodyId)
      .slice(0, 2)
      .forEach(item => {
        recommendations.push({ 
          type: 'response_template', 
          item: { ...item, name: item.templateName }, 
          reason: 'Matches case type' 
        });
      });

    return recommendations;
  }, [caseData, filteredRemedies, filteredDeadlineRules, filteredResponseTemplates]);

  const handleReference = () => {
    if (selectedItem) {
      onReference(selectedItem.type, selectedItem.id, selectedItem.name, selectedItem.version);
      setSelectedItem(null);
      onOpenChange(false);
    }
  };

  const handleApply = () => {
    if (selectedItem && !isClosed) {
      const targetMap: Record<LibraryItemType, string> = {
        'regulatory_body': 'case_overview',
        'remedy': 'remedy_action',
        'deadline_rule': 'deadline',
        'response_template': 'response_package',
        'evidence_requirement': 'evidence_checklist',
        'finding_category': 'finding',
      };
      onApply(selectedItem.type, selectedItem.id, selectedItem.name, selectedItem.version, targetMap[selectedItem.type]);
      setSelectedItem(null);
      onOpenChange(false);
    }
  };

  const renderLibraryItems = (type: LibraryItemType) => {
    let items: Array<{ id: string; name: string; description?: string; version: number }> = [];
    
    switch (type) {
      case 'remedy':
        items = filteredRemedies.map(r => ({ id: r.id, name: r.name, description: r.description, version: r.version }));
        break;
      case 'deadline_rule':
        items = filteredDeadlineRules.map(d => ({ id: d.id, name: d.name, description: `${d.defaultDueInDays} days`, version: d.version }));
        break;
      case 'response_template':
        items = filteredResponseTemplates.map(t => ({ id: t.id, name: t.templateName, description: t.description, version: t.version }));
        break;
      case 'evidence_requirement':
        items = filteredEvidenceRequirements.map(e => ({ id: e.id, name: e.name, description: e.description, version: e.version }));
        break;
      case 'finding_category':
        items = filteredFindingCategories.map(f => ({ id: f.id, name: f.name, description: f.description, version: 1 }));
        break;
      case 'regulatory_body':
        items = filteredRegulatoryBodies.map(r => ({ id: r.id, name: r.name, description: r.abbreviation, version: 1 }));
        break;
    }

    if (items.length === 0) {
      return (
        <div className="text-center py-8 text-muted-foreground">
          No items found
        </div>
      );
    }

    return (
      <div className="space-y-2">
        {items.map(item => (
          <Card 
            key={item.id}
            className={`cursor-pointer transition-colors ${
              selectedItem?.id === item.id ? 'border-primary bg-primary/5' : 'hover:bg-muted/50'
            }`}
            onClick={() => setSelectedItem({ type, id: item.id, name: item.name, version: item.version })}
          >
            <CardHeader className="p-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">{item.name}</CardTitle>
                <Badge variant="outline" className="text-xs">v{item.version}</Badge>
              </div>
              {item.description && (
                <CardDescription className="text-xs">{item.description}</CardDescription>
              )}
            </CardHeader>
          </Card>
        ))}
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            Enforcement Library
          </DialogTitle>
          <DialogDescription>
            Browse and apply library items to this case. Reference items for context or apply them to create case records.
          </DialogDescription>
        </DialogHeader>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search library items..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>

        {showRecommended && recommendedItems.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Lightbulb className="h-4 w-4 text-warning" />
              Recommended for This Stage
            </div>
            <div className="grid grid-cols-2 gap-2">
              {recommendedItems.slice(0, 4).map((rec, idx) => {
                const Icon = LIBRARY_ITEM_LABELS[rec.type].icon;
                return (
                  <Card 
                    key={idx}
                    className={`cursor-pointer transition-colors ${
                      selectedItem?.id === rec.item.id ? 'border-primary bg-primary/5' : 'hover:bg-muted/50'
                    }`}
                    onClick={() => setSelectedItem({ 
                      type: rec.type, 
                      id: rec.item.id, 
                      name: rec.item.name, 
                      version: rec.item.version 
                    })}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-center gap-2">
                        <Icon className="h-4 w-4 text-muted-foreground" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{rec.item.name}</p>
                          <p className="text-xs text-muted-foreground">{rec.reason}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        <Tabs value={selectedTab} onValueChange={(v) => setSelectedTab(v as LibraryItemType)} className="flex-1">
          <TabsList className="grid grid-cols-6 w-full">
            {Object.entries(LIBRARY_ITEM_LABELS).map(([type, { label, icon: Icon }]) => {
              const isApplicable = applicableTypes.includes(type as LibraryItemType);
              return (
                <TabsTrigger 
                  key={type} 
                  value={type}
                  className={!isApplicable ? 'opacity-50' : ''}
                  disabled={!isApplicable}
                >
                  <Icon className="h-4 w-4 mr-1" />
                  <span className="hidden lg:inline">{label.split(' ')[0]}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>
          
          <ScrollArea className="h-[300px] mt-4">
            {Object.keys(LIBRARY_ITEM_LABELS).map(type => (
              <TabsContent key={type} value={type} className="mt-0">
                {renderLibraryItems(type as LibraryItemType)}
              </TabsContent>
            ))}
          </ScrollArea>
        </Tabs>

        <DialogFooter className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            {selectedItem ? `Selected: ${selectedItem.name}` : 'Select an item to continue'}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button 
              variant="outline" 
              onClick={handleReference}
              disabled={!selectedItem}
            >
              <LinkIcon className="h-4 w-4 mr-2" />
              Reference
            </Button>
            <Button 
              onClick={handleApply}
              disabled={!selectedItem || isClosed}
            >
              Apply to Case
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
