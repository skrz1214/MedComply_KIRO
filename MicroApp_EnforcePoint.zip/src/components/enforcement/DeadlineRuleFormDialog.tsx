import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DeadlineRuleLibraryItem,
  DeadlineRuleType,
  DeadlineCalculationBase,
  CaseType,
  UserRole,
  LibraryItemStatus,
  RegulatoryBody,
} from "@/types/enforcepoint";

interface DeadlineRuleFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item?: DeadlineRuleLibraryItem | null;
  onSave: (item: Omit<DeadlineRuleLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  regulatoryBodies: RegulatoryBody[];
  currentUserName: string;
}

const DEADLINE_TYPES: DeadlineRuleType[] = ['Response Due', 'Appeal Due', 'Payment Due', 'Revisit', 'PoC Due', 'Other'];
const CALCULATION_BASES: { value: DeadlineCalculationBase; label: string }[] = [
  { value: 'notice_received_date', label: 'Notice Received Date' },
  { value: 'survey_date', label: 'Survey Date' },
  { value: 'posted_date', label: 'Posted Date' },
];
const CASE_TYPES: CaseType[] = ['Survey/Inspection', 'Complaint Investigation', 'Program Integrity/Fraud', 'Privacy/Security', 'Licensure', 'Life Safety', 'Other'];
const USER_ROLES: UserRole[] = ['Admin', 'Compliance Head', 'Department Head', 'Staff'];

export function DeadlineRuleFormDialog({
  open,
  onOpenChange,
  item,
  onSave,
  regulatoryBodies,
  currentUserName,
}: DeadlineRuleFormDialogProps) {
  const [formData, setFormData] = useState({
    name: "",
    regulatoryBodyId: "",
    caseType: "" as CaseType | "",
    deadlineType: "Response Due" as DeadlineRuleType,
    calculationBase: "notice_received_date" as DeadlineCalculationBase,
    defaultDueInDays: "10",
    warningThresholds: "7,3,1",
    escalationRoles: [] as UserRole[],
    status: "Draft" as LibraryItemStatus,
  });

  useEffect(() => {
    if (item) {
      setFormData({
        name: item.name,
        regulatoryBodyId: item.regulatoryBodyId || "",
        caseType: item.caseType || "",
        deadlineType: item.deadlineType,
        calculationBase: item.calculationBase,
        defaultDueInDays: item.defaultDueInDays.toString(),
        warningThresholds: item.warningThresholds.join(","),
        escalationRoles: item.escalationRoles,
        status: item.status,
      });
    } else {
      setFormData({
        name: "",
        regulatoryBodyId: "",
        caseType: "",
        deadlineType: "Response Due",
        calculationBase: "notice_received_date",
        defaultDueInDays: "10",
        warningThresholds: "7,3,1",
        escalationRoles: ['Compliance Head'],
        status: "Draft",
      });
    }
  }, [item, open]);

  const toggleEscalationRole = (role: UserRole) => {
    setFormData(prev => ({
      ...prev,
      escalationRoles: prev.escalationRoles.includes(role)
        ? prev.escalationRoles.filter(r => r !== role)
        : [...prev.escalationRoles, role]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name: formData.name.trim(),
      regulatoryBodyId: formData.regulatoryBodyId || undefined,
      caseType: formData.caseType as CaseType || undefined,
      deadlineType: formData.deadlineType,
      calculationBase: formData.calculationBase,
      defaultDueInDays: parseInt(formData.defaultDueInDays) || 10,
      warningThresholds: formData.warningThresholds.split(",").map(n => parseInt(n.trim())).filter(n => !isNaN(n)),
      escalationRoles: formData.escalationRoles,
      status: formData.status,
      version: item ? item.version + 1 : 1,
      createdBy: item?.createdBy || currentUserName,
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{item ? "Edit Deadline Rule" : "Add Deadline Rule"}</DialogTitle>
          <DialogDescription>
            {item ? "Update this deadline rule." : "Create a new deadline calculation rule."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., CMS Response Due"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: LibraryItemStatus) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Draft">Draft</SelectItem>
                  <SelectItem value="Published">Published</SelectItem>
                  <SelectItem value="Deprecated">Deprecated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Regulatory Body</Label>
              <Select
                value={formData.regulatoryBodyId || "all"}
                onValueChange={(value) => setFormData({ ...formData, regulatoryBodyId: value === "all" ? "" : value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All Bodies" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Bodies</SelectItem>
                  {regulatoryBodies.map(body => (
                    <SelectItem key={body.id} value={body.id}>{body.abbreviation || body.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Case Type</Label>
              <Select
                value={formData.caseType || "all"}
                onValueChange={(value) => setFormData({ ...formData, caseType: value === "all" ? "" : value as CaseType | "" })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {CASE_TYPES.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Deadline Type *</Label>
              <Select
                value={formData.deadlineType}
                onValueChange={(value: DeadlineRuleType) => setFormData({ ...formData, deadlineType: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DEADLINE_TYPES.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Calculate From</Label>
              <Select
                value={formData.calculationBase}
                onValueChange={(value: DeadlineCalculationBase) => setFormData({ ...formData, calculationBase: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CALCULATION_BASES.map(base => (
                    <SelectItem key={base.value} value={base.value}>{base.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="defaultDueInDays">Default Due (Days) *</Label>
              <Input
                id="defaultDueInDays"
                type="number"
                value={formData.defaultDueInDays}
                onChange={(e) => setFormData({ ...formData, defaultDueInDays: e.target.value })}
                min={1}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="warningThresholds">Warning Thresholds (days)</Label>
              <Input
                id="warningThresholds"
                value={formData.warningThresholds}
                onChange={(e) => setFormData({ ...formData, warningThresholds: e.target.value })}
                placeholder="7,3,1"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Escalation Recipients</Label>
            <div className="flex flex-wrap gap-4">
              {USER_ROLES.map(role => (
                <div key={role} className="flex items-center space-x-2">
                  <Checkbox
                    id={`role-${role}`}
                    checked={formData.escalationRoles.includes(role)}
                    onCheckedChange={() => toggleEscalationRole(role)}
                  />
                  <Label htmlFor={`role-${role}`} className="text-sm cursor-pointer">{role}</Label>
                </div>
              ))}
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={!formData.name.trim()}>
              {item ? "Save Changes" : "Add Rule"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}