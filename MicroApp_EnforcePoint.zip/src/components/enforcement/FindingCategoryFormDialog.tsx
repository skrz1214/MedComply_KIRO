import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, X } from "lucide-react";
import {
  FindingCategoryLibraryItem,
  CaseType,
  LibraryItemStatus,
} from "@/types/enforcepoint";

interface FindingCategoryFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item?: FindingCategoryLibraryItem | null;
  onSave: (item: Omit<FindingCategoryLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  currentUserName: string;
}

const CASE_TYPES: CaseType[] = ['Survey/Inspection', 'Complaint Investigation', 'Program Integrity/Fraud', 'Privacy/Security', 'Licensure', 'Life Safety', 'Other'];

export function FindingCategoryFormDialog({
  open,
  onOpenChange,
  item,
  onSave,
  currentUserName,
}: FindingCategoryFormDialogProps) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    status: "Draft" as LibraryItemStatus,
  });

  const [applicableCaseTypes, setApplicableCaseTypes] = useState<CaseType[]>([]);
  const [typicalCitations, setTypicalCitations] = useState<string[]>([]);
  const [newCitation, setNewCitation] = useState("");

  useEffect(() => {
    if (item) {
      setFormData({
        name: item.name,
        description: item.description || "",
        status: item.status,
      });
      setApplicableCaseTypes(item.applicableCaseTypes);
      setTypicalCitations(item.typicalCitations || []);
    } else {
      setFormData({
        name: "",
        description: "",
        status: "Draft",
      });
      setApplicableCaseTypes(['Survey/Inspection']);
      setTypicalCitations([]);
    }
  }, [item, open]);

  const toggleCaseType = (type: CaseType) => {
    setApplicableCaseTypes(prev =>
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  const addCitation = () => {
    if (!newCitation.trim()) return;
    setTypicalCitations(prev => [...prev, newCitation.trim()]);
    setNewCitation("");
  };

  const removeCitation = (citation: string) => {
    setTypicalCitations(prev => prev.filter(c => c !== citation));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name: formData.name.trim(),
      description: formData.description || undefined,
      typicalCitations: typicalCitations.length > 0 ? typicalCitations : undefined,
      applicableCaseTypes,
      status: formData.status,
      createdBy: item?.createdBy || currentUserName,
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{item ? "Edit Finding Category" : "Add Finding Category"}</DialogTitle>
          <DialogDescription>
            {item ? "Update this finding category." : "Create a new finding category for deficiencies."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Infection Control"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: LibraryItemStatus) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Draft">Draft</SelectItem>
                  <SelectItem value="Published">Published</SelectItem>
                  <SelectItem value="Deprecated">Deprecated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe this finding category..."
            />
          </div>

          <div className="space-y-2">
            <Label>Applicable Case Types</Label>
            <div className="flex flex-wrap gap-3">
              {CASE_TYPES.map(type => (
                <div key={type} className="flex items-center space-x-2">
                  <Checkbox
                    id={`case-${type}`}
                    checked={applicableCaseTypes.includes(type)}
                    onCheckedChange={() => toggleCaseType(type)}
                  />
                  <Label htmlFor={`case-${type}`} className="text-sm cursor-pointer">{type}</Label>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t pt-4 space-y-3">
            <h4 className="font-medium">Typical Citations</h4>
            <div className="flex flex-wrap gap-2 min-h-[32px]">
              {typicalCitations.map(citation => (
                <Badge key={citation} variant="outline" className="flex items-center gap-1">
                  {citation}
                  <button type="button" onClick={() => removeCitation(citation)}>
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                placeholder="Citation (e.g., F880)..."
                value={newCitation}
                onChange={(e) => setNewCitation(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addCitation())}
              />
              <Button type="button" variant="outline" size="sm" onClick={addCitation}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={!formData.name.trim() || applicableCaseTypes.length === 0}>
              {item ? "Save Changes" : "Add Category"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}