import { Badge } from '@/components/ui/badge';
import { EnforcementStatus, Enforcement } from '@/types/enforcement';
import { CheckCircle, XCircle, AlertTriangle, AlertCircle, Info, CircleDot, Clock, DollarSign } from 'lucide-react';

interface StatusBadgeProps {
  status: EnforcementStatus;
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const variants: Record<EnforcementStatus, 'statusPending' | 'statusActive' | 'statusResolved' | 'statusDeleted'> = {
    Pending: 'statusPending',
    Active: 'statusActive',
    Resolved: 'statusResolved',
    Deleted: 'statusDeleted',
  };

  const icons: Record<EnforcementStatus, React.ReactNode> = {
    Pending: <Clock className="h-3 w-3" />,
    Active: <AlertCircle className="h-3 w-3" />,
    Resolved: <CheckCircle className="h-3 w-3" />,
    Deleted: <XCircle className="h-3 w-3" />,
  };

  return (
    <Badge variant={variants[status]} className="gap-1">
      {icons[status]}
      {status}
    </Badge>
  );
}

interface ImpactBadgeProps {
  impact: Enforcement['impactLevel'];
}

export function ImpactBadge({ impact }: ImpactBadgeProps) {
  const variants: Record<Enforcement['impactLevel'], 'priorityCritical' | 'priorityHigh' | 'priorityMedium' | 'priorityLow'> = {
    Critical: 'priorityCritical',
    High: 'priorityHigh',
    Medium: 'priorityMedium',
    Low: 'priorityLow',
  };

  const icons: Record<Enforcement['impactLevel'], React.ReactNode> = {
    Critical: <AlertCircle className="h-3 w-3" />,
    High: <AlertTriangle className="h-3 w-3" />,
    Medium: <Info className="h-3 w-3" />,
    Low: <CircleDot className="h-3 w-3" />,
  };

  return (
    <Badge variant={variants[impact]} className="gap-1">
      {icons[impact]}
      {impact} Impact
    </Badge>
  );
}

interface PaymentBadgeProps {
  status: Enforcement['paymentStatus'];
}

export function PaymentBadge({ status }: PaymentBadgeProps) {
  if (!status) return null;

  const variants: Record<NonNullable<Enforcement['paymentStatus']>, 'statusPending' | 'statusResolved' | 'priorityCritical' | 'priorityLow'> = {
    'Pending Payment': 'statusPending',
    'Paid': 'statusResolved',
    'Overdue': 'priorityCritical',
    'Waived': 'priorityLow',
  };

  return (
    <Badge variant={variants[status]} className="gap-1">
      <DollarSign className="h-3 w-3" />
      {status}
    </Badge>
  );
}
