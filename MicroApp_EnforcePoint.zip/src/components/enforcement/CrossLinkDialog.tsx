import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CrossLinkSelector } from "./CrossLinkSelector";
import { EnforcementCase } from "@/types/enforcepoint";
import { Link2 } from "lucide-react";

interface CrossLinkDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  caseData: EnforcementCase;
  onSave: (updates: {
    linkedIssueIds: string[];
    linkedCapaIds: string[];
    linkedCitationIds: string[];
    linkedCitationCaseIds: string[];
  }) => void;
}

export function CrossLinkDialog({
  open,
  onOpenChange,
  caseData,
  onSave,
}: CrossLinkDialogProps) {
  const [linkedIssues, setLinkedIssues] = useState<string[]>(caseData.linkedIssueIds || []);
  const [linkedCapas, setLinkedCapas] = useState<string[]>(caseData.linkedCapaIds || []);
  const [linkedCitations, setLinkedCitations] = useState<string[]>(caseData.linkedCitationIds || []);
  const [linkedCitationCases, setLinkedCitationCases] = useState<string[]>(caseData.linkedCitationCaseIds || []);

  const handleSave = () => {
    onSave({
      linkedIssueIds: linkedIssues,
      linkedCapaIds: linkedCapas,
      linkedCitationIds: linkedCitations,
      linkedCitationCaseIds: linkedCitationCases,
    });
    onOpenChange(false);
  };

  const totalLinked = linkedIssues.length + linkedCapas.length + linkedCitations.length + linkedCitationCases.length;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Link2 className="h-5 w-5" />
            Cross-Link Records
          </DialogTitle>
          <DialogDescription>
            Link this enforcement case to related items from other microapps (Issues, CAPAs, Citations, Risks, Feedback, Audits).
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto py-4">
          <CrossLinkSelector
            selectedIssues={linkedIssues}
            selectedCapas={linkedCapas}
            selectedCitations={linkedCitations}
            selectedCitationCases={linkedCitationCases}
            onIssuesChange={setLinkedIssues}
            onCapasChange={setLinkedCapas}
            onCitationsChange={setLinkedCitations}
            onCitationCasesChange={setLinkedCitationCases}
          />
        </div>

        <DialogFooter className="border-t pt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Save Links ({totalLinked})
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
