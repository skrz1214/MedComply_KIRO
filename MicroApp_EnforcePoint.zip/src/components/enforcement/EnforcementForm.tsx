import { useState, useEffect } from 'react';
import { Enforcement, EnforcementStatus } from '@/types/enforcement';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Save, X, FileText, Upload, Trash2 } from 'lucide-react';
import { LibraryReferenceSheet } from '@/components/library/LibraryReferenceSheet';

interface EnforcementFormProps {
  enforcement?: Enforcement;
  ticketDescription?: string;
  ticketId?: string;
  onSubmit: (data: Omit<Enforcement, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onCancel: () => void;
  mode: 'create' | 'edit';
}

const governingBodies = [
  'Healthcare Commission',
  'Safety Board',
  'Medical Board',
  'HHS Office for Civil Rights',
  'Patient Rights Committee',
  'State Health Department',
  'CMS',
  'Joint Commission',
  'Other',
];

const penaltyTypes = [
  'Monetary Fine',
  'Warning',
  'Corrective Action Plan',
  'License Suspension',
  'Probation',
  'Other',
];

const impactLevels: Enforcement['impactLevel'][] = ['Low', 'Medium', 'High', 'Critical'];
const statuses: EnforcementStatus[] = ['Pending', 'Active', 'Resolved'];
const paymentStatuses: NonNullable<Enforcement['paymentStatus']>[] = ['Pending Payment', 'Paid', 'Overdue', 'Waived'];

export function EnforcementForm({ enforcement, ticketDescription, ticketId, onSubmit, onCancel, mode }: EnforcementFormProps) {
  const [formData, setFormData] = useState({
    referenceNumber: '',
    description: '',
    status: 'Pending' as EnforcementStatus,
    governingBody: '',
    authorityName: '',
    contactPerson: '',
    contactEmail: '',
    contactPhone: '',
    penaltyAmount: '',
    penaltyType: 'Monetary Fine',
    issueDate: '',
    dueDate: '',
    paymentStatus: 'Pending Payment' as Enforcement['paymentStatus'],
    impactLevel: 'Medium' as Enforcement['impactLevel'],
    sourceUrl: '',
    attachments: [] as string[],
    notes: '',
    ticketId: ticketId || '',
    ticketDescription: ticketDescription || '',
  });

  const [newAttachment, setNewAttachment] = useState('');

  const handleApplyTemplate = (templateData: {
    description: string;
    governingBody: string;
    penaltyType: string;
    notes: string;
  }) => {
    setFormData(prev => ({
      ...prev,
      description: templateData.description,
      governingBody: templateData.governingBody,
      authorityName: templateData.governingBody,
      penaltyType: templateData.penaltyType === 'Financial' ? 'Monetary Fine' : 
                   templateData.penaltyType === 'Legal' ? 'License Suspension' :
                   templateData.penaltyType === 'Operational' ? 'Corrective Action Plan' : 'Other',
      notes: templateData.notes,
    }));
  };

  useEffect(() => {
    if (enforcement) {
      setFormData({
        referenceNumber: enforcement.referenceNumber,
        description: enforcement.description,
        status: enforcement.status === 'Deleted' ? 'Pending' : enforcement.status,
        governingBody: enforcement.governingBody,
        authorityName: enforcement.governingAuthority?.name || '',
        contactPerson: enforcement.governingAuthority?.contactPerson || '',
        contactEmail: enforcement.governingAuthority?.email || '',
        contactPhone: enforcement.governingAuthority?.phone || '',
        penaltyAmount: enforcement.penaltyAmount.toString(),
        penaltyType: enforcement.penaltyType,
        issueDate: enforcement.issueDate.toISOString().split('T')[0],
        dueDate: enforcement.dueDate ? enforcement.dueDate.toISOString().split('T')[0] : '',
        paymentStatus: enforcement.paymentStatus || 'Pending Payment',
        impactLevel: enforcement.impactLevel,
        sourceUrl: enforcement.sourceUrl || '',
        attachments: enforcement.attachments || [],
        notes: enforcement.notes || '',
        ticketId: enforcement.ticketId || '',
        ticketDescription: enforcement.ticketDescription || '',
      });
    } else if (ticketDescription) {
      setFormData(prev => ({
        ...prev,
        description: ticketDescription,
        ticketId: ticketId || '',
        ticketDescription: ticketDescription,
      }));
    }
  }, [enforcement, ticketDescription, ticketId]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const governingAuthority = formData.authorityName ? {
      name: formData.authorityName,
      contactPerson: formData.contactPerson || undefined,
      email: formData.contactEmail || undefined,
      phone: formData.contactPhone || undefined,
    } : undefined;

    onSubmit({
      referenceNumber: formData.referenceNumber,
      description: formData.description,
      status: formData.status,
      governingBody: formData.governingBody,
      governingAuthority,
      penaltyAmount: parseFloat(formData.penaltyAmount) || 0,
      penaltyType: formData.penaltyType,
      issueDate: new Date(formData.issueDate),
      dueDate: formData.dueDate ? new Date(formData.dueDate) : undefined,
      paymentStatus: formData.paymentStatus,
      impactLevel: formData.impactLevel,
      sourceUrl: formData.sourceUrl || undefined,
      attachments: formData.attachments.length > 0 ? formData.attachments : undefined,
      notes: formData.notes || undefined,
      ticketId: formData.ticketId || undefined,
      ticketDescription: formData.ticketDescription || undefined,
    });
  };

  const addAttachment = () => {
    if (newAttachment.trim()) {
      setFormData(prev => ({
        ...prev,
        attachments: [...prev.attachments, newAttachment.trim()],
      }));
      setNewAttachment('');
    }
  };

  const removeAttachment = (index: number) => {
    setFormData(prev => ({
      ...prev,
      attachments: prev.attachments.filter((_, i) => i !== index),
    }));
  };

  return (
    <Card className="animate-scale-in shadow-lg">
      <CardHeader className="border-b border-border bg-muted/30">
        <div className="flex items-start justify-between gap-4">
          <div>
            <CardTitle className="flex items-center gap-2 text-xl">
              <FileText className="h-5 w-5 text-primary" />
              {mode === 'create' ? 'Add New Enforcement' : 'Edit Enforcement'}
            </CardTitle>
            <CardDescription>
              {mode === 'create' 
                ? 'Create a new enforcement action and specify penalties.'
                : 'Update enforcement details and penalties.'}
            </CardDescription>
          </div>
          <LibraryReferenceSheet onApplyTemplate={handleApplyTemplate} />
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {formData.ticketId && (
            <div className="p-4 bg-info/10 border border-info/20 rounded-lg">
              <p className="text-sm font-medium text-info mb-1">Linked to ComplianceConnect Ticket</p>
              <p className="text-xs text-muted-foreground">{formData.ticketId}</p>
            </div>
          )}

          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="referenceNumber">Enforcement ID *</Label>
              <Input
                id="referenceNumber"
                value={formData.referenceNumber}
                onChange={(e) => setFormData(prev => ({ ...prev, referenceNumber: e.target.value }))}
                placeholder="#2025-001"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="penaltyAmount">Penalty Amount *</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                <Input
                  id="penaltyAmount"
                  type="number"
                  value={formData.penaltyAmount}
                  onChange={(e) => setFormData(prev => ({ ...prev, penaltyAmount: e.target.value }))}
                  placeholder="5000"
                  className="pl-7"
                  required
                />
              </div>
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Enter detailed description of the enforcement..."
                rows={4}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="governingBody">Governing Body *</Label>
              <Select
                value={formData.governingBody}
                onValueChange={(value) => setFormData(prev => ({ ...prev, governingBody: value, authorityName: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select Governing Body" />
                </SelectTrigger>
                <SelectContent>
                  {governingBodies.map((body) => (
                    <SelectItem key={body} value={body}>
                      {body}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="penaltyType">Penalty Type *</Label>
              <Select
                value={formData.penaltyType}
                onValueChange={(value) => setFormData(prev => ({ ...prev, penaltyType: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select penalty type" />
                </SelectTrigger>
                <SelectContent>
                  {penaltyTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData(prev => ({ ...prev, status: value as EnforcementStatus }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  {statuses.map((status) => (
                    <SelectItem key={status} value={status}>
                      {status}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="impactLevel">Impact Level *</Label>
              <Select
                value={formData.impactLevel}
                onValueChange={(value) => setFormData(prev => ({ ...prev, impactLevel: value as Enforcement['impactLevel'] }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select impact level" />
                </SelectTrigger>
                <SelectContent>
                  {impactLevels.map((level) => (
                    <SelectItem key={level} value={level}>
                      {level}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="issueDate">Issue Date *</Label>
              <Input
                id="issueDate"
                type="date"
                value={formData.issueDate}
                onChange={(e) => setFormData(prev => ({ ...prev, issueDate: e.target.value }))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="dueDate">Due Date</Label>
              <Input
                id="dueDate"
                type="date"
                value={formData.dueDate}
                onChange={(e) => setFormData(prev => ({ ...prev, dueDate: e.target.value }))}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="paymentStatus">Payment Status</Label>
              <Select
                value={formData.paymentStatus}
                onValueChange={(value) => setFormData(prev => ({ ...prev, paymentStatus: value as Enforcement['paymentStatus'] }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select payment status" />
                </SelectTrigger>
                <SelectContent>
                  {paymentStatuses.map((status) => (
                    <SelectItem key={status} value={status}>
                      {status}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="sourceUrl">Source URL</Label>
              <Input
                id="sourceUrl"
                type="url"
                value={formData.sourceUrl}
                onChange={(e) => setFormData(prev => ({ ...prev, sourceUrl: e.target.value }))}
                placeholder="https://"
              />
            </div>

            {/* Governing Authority Contact Section */}
            <div className="md:col-span-2 border-t border-border pt-6 mt-2">
              <h3 className="font-medium mb-4">Governing Authority Contact (Optional)</h3>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="contactPerson">Contact Person</Label>
                  <Input
                    id="contactPerson"
                    value={formData.contactPerson}
                    onChange={(e) => setFormData(prev => ({ ...prev, contactPerson: e.target.value }))}
                    placeholder="John Anderson"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contactEmail">Email</Label>
                  <Input
                    id="contactEmail"
                    type="email"
                    value={formData.contactEmail}
                    onChange={(e) => setFormData(prev => ({ ...prev, contactEmail: e.target.value }))}
                    placeholder="contact@authority.gov"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contactPhone">Phone</Label>
                  <Input
                    id="contactPhone"
                    type="tel"
                    value={formData.contactPhone}
                    onChange={(e) => setFormData(prev => ({ ...prev, contactPhone: e.target.value }))}
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
              </div>
            </div>

            {/* Attachments Section */}
            <div className="md:col-span-2 border-t border-border pt-6 mt-2">
              <h3 className="font-medium mb-4">Attachments</h3>
              <div className="space-y-3">
                <div className="flex gap-2">
                  <Input
                    value={newAttachment}
                    onChange={(e) => setNewAttachment(e.target.value)}
                    placeholder="Enter file name (e.g., report.pdf)"
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addAttachment())}
                  />
                  <Button type="button" variant="outline" onClick={addAttachment}>
                    <Upload className="h-4 w-4 mr-2" />
                    Add File
                  </Button>
                </div>
                {formData.attachments.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {formData.attachments.map((file, index) => (
                      <div key={index} className="flex items-center gap-2 bg-muted px-3 py-1.5 rounded-lg text-sm">
                        <span>{file}</span>
                        <button
                          type="button"
                          onClick={() => removeAttachment(index)}
                          className="text-muted-foreground hover:text-destructive"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                <p className="text-xs text-muted-foreground">Maximum file size: 10MB</p>
              </div>
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="notes">Additional Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="Any additional notes or context..."
                rows={3}
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-border">
            <Button type="button" variant="outline" onClick={onCancel}>
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button type="submit" variant="default">
              <Save className="h-4 w-4 mr-2" />
              {mode === 'create' ? 'Create Enforcement' : 'Save Changes'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
