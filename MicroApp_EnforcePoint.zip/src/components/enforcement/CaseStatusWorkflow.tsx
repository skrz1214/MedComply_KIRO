import { useState } from "react";
import { CaseStatus, EnforcementCase } from "@/types/enforcepoint";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  ChevronRight,
  Check,
  AlertTriangle,
  FileText,
  Users,
  ClipboardList,
  Send,
  Scale,
  Search,
  CheckCircle,
  RotateCcw,
  Lock,
} from "lucide-react";
import { toast } from "sonner";

const STATUS_ORDER: CaseStatus[] = [
  "Draft",
  "Notice Received",
  "Triage & Assignment",
  "Response Planning",
  "Remediation Linked",
  "Response In Progress",
  "Submitted / Awaiting Determination",
  "Remedies Active",
  "Verification / Revisit",
  "Closed",
];

const STATUS_CONFIG: Record<CaseStatus, { icon: React.ReactNode; color: string; description: string }> = {
  "Draft": { 
    icon: <FileText className="h-4 w-4" />, 
    color: "bg-muted text-muted-foreground",
    description: "Initial case creation"
  },
  "Notice Received": { 
    icon: <FileText className="h-4 w-4" />, 
    color: "bg-amber-500/10 text-amber-600 border-amber-200",
    description: "Notice received and logged"
  },
  "Triage & Assignment": { 
    icon: <Users className="h-4 w-4" />, 
    color: "bg-orange-500/10 text-orange-600 border-orange-200",
    description: "Case under review and assignment"
  },
  "Response Planning": { 
    icon: <ClipboardList className="h-4 w-4" />, 
    color: "bg-blue-500/10 text-blue-600 border-blue-200",
    description: "Planning response strategy"
  },
  "Remediation Linked": { 
    icon: <Check className="h-4 w-4" />, 
    color: "bg-indigo-500/10 text-indigo-600 border-indigo-200",
    description: "Corrective actions linked"
  },
  "Response In Progress": { 
    icon: <Send className="h-4 w-4" />, 
    color: "bg-cyan-500/10 text-cyan-600 border-cyan-200",
    description: "Preparing response package"
  },
  "Submitted / Awaiting Determination": { 
    icon: <Send className="h-4 w-4" />, 
    color: "bg-purple-500/10 text-purple-600 border-purple-200",
    description: "Response submitted, awaiting decision"
  },
  "Remedies Active": { 
    icon: <Scale className="h-4 w-4" />, 
    color: "bg-red-500/10 text-red-600 border-red-200",
    description: "Enforcement remedies in effect"
  },
  "Verification / Revisit": { 
    icon: <Search className="h-4 w-4" />, 
    color: "bg-teal-500/10 text-teal-600 border-teal-200",
    description: "Compliance verification pending"
  },
  "Closed": { 
    icon: <CheckCircle className="h-4 w-4" />, 
    color: "bg-green-500/10 text-green-600 border-green-200",
    description: "Case closed successfully"
  },
  "Reopened": { 
    icon: <RotateCcw className="h-4 w-4" />, 
    color: "bg-rose-500/10 text-rose-600 border-rose-200",
    description: "Case reopened for additional action"
  },
};

interface StatusGate {
  status: CaseStatus;
  requirements: string[];
  check: (caseData: EnforcementCase) => { passed: boolean; missing: string[] };
}

const STATUS_GATES: StatusGate[] = [
  {
    status: "Triage & Assignment",
    requirements: ["Regulatory body", "Notice date", "Response due date"],
    check: (c) => {
      const missing: string[] = [];
      if (!c.regulatoryBodyId) missing.push("Regulatory body");
      if (!c.noticeReceivedDate) missing.push("Notice date");
      if (!c.responseDueDate) missing.push("Response due date");
      return { passed: missing.length === 0, missing };
    },
  },
  {
    status: "Response Planning",
    requirements: ["Assigned owner", "Severity classification"],
    check: (c) => {
      const missing: string[] = [];
      if (!c.assignedOwnerId && !c.assignedOwnerName) missing.push("Assigned owner");
      if (!c.severity) missing.push("Severity classification");
      return { passed: missing.length === 0, missing };
    },
  },
  {
    status: "Submitted / Awaiting Determination",
    requirements: ["Response package submitted"],
    check: () => ({ passed: true, missing: [] }), // Simplified for demo
  },
  {
    status: "Closed",
    requirements: ["Verification evidence or closure decision", "Compliance Head sign-off"],
    check: () => ({ passed: true, missing: [] }), // Simplified for demo
  },
];

interface CaseStatusWorkflowProps {
  caseData: EnforcementCase;
  onStatusChange: (newStatus: CaseStatus, justification?: string) => void;
  compact?: boolean;
}

export function CaseStatusWorkflow({ caseData, onStatusChange, compact = false }: CaseStatusWorkflowProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState<CaseStatus | "">("");
  const [justification, setJustification] = useState("");
  const [gateWarnings, setGateWarnings] = useState<string[]>([]);

  const currentIndex = STATUS_ORDER.indexOf(caseData.status as CaseStatus);
  const isClosed = caseData.status === "Closed";
  const isReopened = caseData.status === "Reopened";

  const getAvailableTransitions = (): CaseStatus[] => {
    if (isClosed) return ["Reopened"];
    if (isReopened) return ["Triage & Assignment", "Response Planning", "Closed"];
    
    const transitions: CaseStatus[] = [];
    
    // Next status in sequence
    if (currentIndex < STATUS_ORDER.length - 1) {
      transitions.push(STATUS_ORDER[currentIndex + 1]);
    }
    
    // Previous status (rollback)
    if (currentIndex > 0) {
      transitions.push(STATUS_ORDER[currentIndex - 1]);
    }
    
    // Skip to specific statuses in certain conditions
    if (caseData.status === "Notice Received") {
      transitions.push("Response Planning"); // Skip triage if straightforward
    }
    
    return [...new Set(transitions)];
  };

  const checkGates = (targetStatus: CaseStatus): { passed: boolean; warnings: string[] } => {
    const gate = STATUS_GATES.find(g => g.status === targetStatus);
    if (!gate) return { passed: true, warnings: [] };
    
    const result = gate.check(caseData);
    return { passed: result.passed, warnings: result.missing };
  };

  const handleStatusSelect = (status: CaseStatus) => {
    setSelectedStatus(status);
    const gateResult = checkGates(status);
    setGateWarnings(gateResult.warnings);
  };

  const handleConfirmTransition = () => {
    if (!selectedStatus) return;
    
    const isBackward = STATUS_ORDER.indexOf(selectedStatus) < currentIndex;
    const isReopeningClosed = caseData.status === "Closed" && selectedStatus === "Reopened";
    
    if ((isBackward || isReopeningClosed) && !justification.trim()) {
      toast.error("Justification required for this status change");
      return;
    }
    
    onStatusChange(selectedStatus, justification.trim() || undefined);
    setDialogOpen(false);
    setSelectedStatus("");
    setJustification("");
    setGateWarnings([]);
    toast.success(`Status updated to "${selectedStatus}"`);
  };

  const availableTransitions = getAvailableTransitions();

  if (compact) {
    return (
      <div className="flex items-center gap-2">
        <Badge variant="outline" className={`${STATUS_CONFIG[caseData.status]?.color || ""} flex items-center gap-1`}>
          {STATUS_CONFIG[caseData.status]?.icon}
          {caseData.status}
        </Badge>
        <Button variant="outline" size="sm" onClick={() => setDialogOpen(true)}>
          Change Status
        </Button>
        
        <StatusTransitionDialog
          open={dialogOpen}
          onOpenChange={setDialogOpen}
          caseData={caseData}
          availableTransitions={availableTransitions}
          selectedStatus={selectedStatus}
          onStatusSelect={handleStatusSelect}
          justification={justification}
          onJustificationChange={setJustification}
          gateWarnings={gateWarnings}
          onConfirm={handleConfirmTransition}
          currentIndex={currentIndex}
        />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Visual Status Progress */}
      <div className="flex items-center gap-1 overflow-x-auto pb-2">
        {STATUS_ORDER.map((status, index) => {
          const isActive = status === caseData.status;
          const isPast = index < currentIndex;
          const config = STATUS_CONFIG[status];
          
          return (
            <div key={status} className="flex items-center">
              <div
                className={`flex items-center gap-1.5 px-2 py-1 rounded-full text-xs whitespace-nowrap transition-all ${
                  isActive
                    ? `${config.color} font-medium ring-2 ring-offset-1 ring-primary/30`
                    : isPast
                    ? "bg-success/10 text-success"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {isPast ? <Check className="h-3 w-3" /> : config.icon}
                <span className="hidden sm:inline">{status}</span>
              </div>
              {index < STATUS_ORDER.length - 1 && (
                <ChevronRight className={`h-4 w-4 mx-0.5 ${isPast ? "text-success" : "text-muted-foreground/30"}`} />
              )}
            </div>
          );
        })}
      </div>

      {/* Current Status Card */}
      <div className="flex items-center justify-between p-4 border rounded-lg bg-card">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-full ${STATUS_CONFIG[caseData.status]?.color || "bg-muted"}`}>
            {STATUS_CONFIG[caseData.status]?.icon}
          </div>
          <div>
            <p className="font-medium">{caseData.status}</p>
            <p className="text-sm text-muted-foreground">
              {STATUS_CONFIG[caseData.status]?.description}
            </p>
          </div>
        </div>
        
        <Button onClick={() => setDialogOpen(true)}>
          Advance Status
        </Button>
      </div>

      {/* Quick Actions */}
      {availableTransitions.length > 0 && (
        <div className="flex flex-wrap gap-2">
          <span className="text-sm text-muted-foreground self-center">Quick transition:</span>
          {availableTransitions.slice(0, 3).map((status) => {
            const config = STATUS_CONFIG[status];
            const isBackward = STATUS_ORDER.indexOf(status) < currentIndex;
            return (
              <Button
                key={status}
                variant="outline"
                size="sm"
                className={`${config.color} border`}
                onClick={() => {
                  handleStatusSelect(status);
                  setDialogOpen(true);
                }}
              >
                {isBackward && <RotateCcw className="h-3 w-3 mr-1" />}
                {config.icon}
                <span className="ml-1">{status}</span>
              </Button>
            );
          })}
        </div>
      )}

      <StatusTransitionDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        caseData={caseData}
        availableTransitions={availableTransitions}
        selectedStatus={selectedStatus}
        onStatusSelect={handleStatusSelect}
        justification={justification}
        onJustificationChange={setJustification}
        gateWarnings={gateWarnings}
        onConfirm={handleConfirmTransition}
        currentIndex={currentIndex}
      />
    </div>
  );
}

interface StatusTransitionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  caseData: EnforcementCase;
  availableTransitions: CaseStatus[];
  selectedStatus: CaseStatus | "";
  onStatusSelect: (status: CaseStatus) => void;
  justification: string;
  onJustificationChange: (value: string) => void;
  gateWarnings: string[];
  onConfirm: () => void;
  currentIndex: number;
}

function StatusTransitionDialog({
  open,
  onOpenChange,
  caseData,
  availableTransitions,
  selectedStatus,
  onStatusSelect,
  justification,
  onJustificationChange,
  gateWarnings,
  onConfirm,
  currentIndex,
}: StatusTransitionDialogProps) {
  const isBackward = selectedStatus && STATUS_ORDER.indexOf(selectedStatus) < currentIndex;
  const isReopening = caseData.status === "Closed" && selectedStatus === "Reopened";
  const requiresJustification = isBackward || isReopening;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Change Case Status</DialogTitle>
          <DialogDescription>
            Current status: <strong>{caseData.status}</strong>
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Select New Status</Label>
            <Select value={selectedStatus} onValueChange={(v) => onStatusSelect(v as CaseStatus)}>
              <SelectTrigger>
                <SelectValue placeholder="Choose status..." />
              </SelectTrigger>
              <SelectContent>
                {availableTransitions.map((status) => {
                  const config = STATUS_CONFIG[status];
                  const isBack = STATUS_ORDER.indexOf(status) < currentIndex;
                  return (
                    <SelectItem key={status} value={status}>
                      <div className="flex items-center gap-2">
                        {config.icon}
                        <span>{status}</span>
                        {isBack && <Badge variant="outline" className="ml-2 text-xs">Rollback</Badge>}
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          {gateWarnings.length > 0 && (
            <Alert variant="destructive">
              <Lock className="h-4 w-4" />
              <AlertDescription>
                <p className="font-medium">Missing requirements:</p>
                <ul className="list-disc list-inside text-sm mt-1">
                  {gateWarnings.map((warning, idx) => (
                    <li key={idx}>{warning}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          {requiresJustification && (
            <div className="space-y-2">
              <Label>
                Justification <span className="text-destructive">*</span>
              </Label>
              <Textarea
                placeholder="Provide reason for this status change..."
                value={justification}
                onChange={(e) => onJustificationChange(e.target.value)}
                rows={3}
              />
              <p className="text-xs text-muted-foreground">
                {isReopening 
                  ? "Justification required for reopening a closed case"
                  : "Justification required for rolling back to a previous status"
                }
              </p>
            </div>
          )}

          {selectedStatus && (
            <div className="p-3 bg-muted rounded-lg">
              <div className="flex items-center gap-2">
                {STATUS_CONFIG[selectedStatus]?.icon}
                <div>
                  <p className="font-medium text-sm">{selectedStatus}</p>
                  <p className="text-xs text-muted-foreground">
                    {STATUS_CONFIG[selectedStatus]?.description}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            onClick={onConfirm}
            disabled={!selectedStatus || (requiresJustification && !justification.trim())}
          >
            Confirm Transition
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
