import { Enforcement } from '@/types/enforcement';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { StatusBadge, ImpactBadge, PaymentBadge } from './StatusBadge';
import { Eye, Pencil, Trash2, Calendar, Building2, DollarSign, ExternalLink } from 'lucide-react';
import { format } from 'date-fns';

interface EnforcementCardProps {
  enforcement: Enforcement;
  onView: (id: string) => void;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
}

export function EnforcementCard({ enforcement, onView, onEdit, onDelete }: EnforcementCardProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <Card className="group animate-fade-in hover:shadow-lg transition-all duration-300 border-border/50 hover:border-primary/20">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1 flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <StatusBadge status={enforcement.status} />
              <ImpactBadge impact={enforcement.impactLevel} />
              {enforcement.paymentStatus && (
                <PaymentBadge status={enforcement.paymentStatus} />
              )}
            </div>
            <h3 className="font-semibold text-foreground text-lg leading-tight pt-2 group-hover:text-primary transition-colors">
              #{enforcement.referenceNumber}
            </h3>
          </div>
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button variant="ghost" size="icon" onClick={() => onView(enforcement.id)} title="View">
              <Eye className="h-4 w-4" />
            </Button>
            {enforcement.status !== 'Deleted' && (
              <>
                <Button variant="ghost" size="icon" onClick={() => onEdit(enforcement.id)} title="Edit">
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => onDelete(enforcement.id)} title="Delete" className="hover:text-destructive">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
          {enforcement.description}
        </p>
        <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <Building2 className="h-3.5 w-3.5" />
            <span>{enforcement.governingBody}</span>
          </div>
          <div className="flex items-center gap-1.5 font-semibold text-foreground">
            <DollarSign className="h-3.5 w-3.5" />
            <span>{formatCurrency(enforcement.penaltyAmount)}</span>
          </div>
          {enforcement.dueDate && (
            <div className="flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5" />
              <span>Due: {format(enforcement.dueDate, 'MMM d, yyyy')}</span>
            </div>
          )}
          {enforcement.sourceUrl && (
            <a 
              href={enforcement.sourceUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-primary hover:underline"
              onClick={(e) => e.stopPropagation()}
            >
              <ExternalLink className="h-3.5 w-3.5" />
              <span>View Source</span>
            </a>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
