import { TodoItem } from '@/types/enforcement';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, Clock, Link as LinkIcon, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';

interface TodoCardProps {
  todo: TodoItem;
  onProcess: (todoId: string) => void;
}

export function TodoCard({ todo, onProcess }: TodoCardProps) {
  return (
    <Card className="group animate-fade-in hover:shadow-lg transition-all duration-300 border-warning/30 bg-warning/5">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-2 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="warning" className="gap-1">
                <AlertTriangle className="h-3 w-3" />
                Action Required
              </Badge>
              <span className="inline-flex items-center gap-1 text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
                <LinkIcon className="h-3 w-3" />
                {todo.ticketId}
              </span>
            </div>
            <p className="text-sm font-medium text-foreground">
              New ComplianceConnect ticket requires enforcement action
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="p-3 bg-card border border-border rounded-lg mb-4">
          <p className="text-sm text-muted-foreground line-clamp-3">
            {todo.ticketDescription}
          </p>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Clock className="h-3.5 w-3.5" />
            <span>Received: {format(todo.createdAt, 'MMM d, yyyy')}</span>
          </div>
          <Button 
            variant="accent" 
            size="sm" 
            onClick={() => onProcess(todo.id)}
            className="gap-2"
          >
            Create Enforcement
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
