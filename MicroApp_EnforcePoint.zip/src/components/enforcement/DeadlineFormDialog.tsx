import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Deadline, EnforcementCase } from "@/types/enforcepoint";
import { format } from "date-fns";

const DEADLINE_TYPES = [
  "Response",
  "PoC",
  "Appeal Filing",
  "Payment",
  "Revisit",
  "Hearing",
  "Other",
] as const;

interface DeadlineFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  deadline?: Deadline | null;
  cases: EnforcementCase[];
  preselectedCaseId?: string;
  preselectedDate?: Date | null;
  onSave: (deadline: Omit<Deadline, "id" | "createdAt" | "updatedAt">) => void;
}

export function DeadlineFormDialog({
  open,
  onOpenChange,
  deadline,
  cases,
  preselectedCaseId,
  preselectedDate,
  onSave,
}: DeadlineFormDialogProps) {
  const [formData, setFormData] = useState({
    caseId: "",
    title: "",
    description: "",
    dueDate: "",
    type: "Response" as Deadline["type"],
    isCompleted: false,
    assigneeId: "",
  });

  useEffect(() => {
    if (deadline) {
      setFormData({
        caseId: deadline.caseId,
        title: deadline.title,
        description: deadline.description || "",
        dueDate: format(new Date(deadline.dueDate), "yyyy-MM-dd"),
        type: deadline.type,
        isCompleted: deadline.isCompleted,
        assigneeId: deadline.assigneeId || "",
      });
    } else {
      setFormData({
        caseId: preselectedCaseId || "",
        title: "",
        description: "",
        dueDate: format(preselectedDate || new Date(), "yyyy-MM-dd"),
        type: "Response",
        isCompleted: false,
        assigneeId: "",
      });
    }
  }, [deadline, preselectedCaseId, preselectedDate, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      caseId: formData.caseId,
      title: formData.title,
      description: formData.description || undefined,
      dueDate: new Date(formData.dueDate),
      type: formData.type,
      isCompleted: formData.isCompleted,
      completedDate: formData.isCompleted ? new Date() : undefined,
      assigneeId: formData.assigneeId || undefined,
      reminderDays: [7, 3, 1],
      escalationRecipients: [],
    });
    onOpenChange(false);
  };

  const isEditing = !!deadline;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Edit Deadline" : "Add New Deadline"}
          </DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Update the deadline details below."
              : "Create a new deadline for a case."}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="caseId">Case *</Label>
            <Select
              value={formData.caseId}
              onValueChange={(value) =>
                setFormData({ ...formData, caseId: value })
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a case" />
              </SelectTrigger>
              <SelectContent>
                {cases.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.caseNumber} - {c.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) =>
                setFormData({ ...formData, title: e.target.value })
              }
              placeholder="e.g., Submit Response to CMS"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="dueDate">Due Date *</Label>
              <Input
                id="dueDate"
                type="date"
                value={formData.dueDate}
                onChange={(e) =>
                  setFormData({ ...formData, dueDate: e.target.value })
                }
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Type *</Label>
              <Select
                value={formData.type}
                onValueChange={(value) =>
                  setFormData({ ...formData, type: value as Deadline["type"] })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DEADLINE_TYPES.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) =>
                setFormData({ ...formData, description: e.target.value })
              }
              placeholder="Additional details about this deadline..."
              rows={3}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="isCompleted"
              checked={formData.isCompleted}
              onCheckedChange={(checked) =>
                setFormData({ ...formData, isCompleted: checked === true })
              }
            />
            <Label htmlFor="isCompleted" className="font-normal">
              Mark as completed
            </Label>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={!formData.caseId || !formData.title}>
              {isEditing ? "Save Changes" : "Add Deadline"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
