import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { EnforcementCase } from "@/types/enforcepoint";
import { format } from "date-fns";

export type CalendarEventType =
  | "Meeting"
  | "Hearing"
  | "Site Visit"
  | "Training"
  | "Review"
  | "Other";

export interface CalendarEvent {
  id: string;
  caseId?: string;
  title: string;
  description?: string;
  eventDate: Date;
  eventType: CalendarEventType;
  location?: string;
  attendees?: string;
  createdAt: Date;
  updatedAt: Date;
}

const EVENT_TYPES: CalendarEventType[] = [
  "Meeting",
  "Hearing",
  "Site Visit",
  "Training",
  "Review",
  "Other",
];

interface EventFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  event?: CalendarEvent | null;
  cases: EnforcementCase[];
  preselectedDate?: Date;
  onSave: (event: Omit<CalendarEvent, "id" | "createdAt" | "updatedAt">) => void;
}

export function EventFormDialog({
  open,
  onOpenChange,
  event,
  cases,
  preselectedDate,
  onSave,
}: EventFormDialogProps) {
  const [formData, setFormData] = useState({
    caseId: "",
    title: "",
    description: "",
    eventDate: "",
    eventType: "Meeting" as CalendarEventType,
    location: "",
    attendees: "",
  });

  useEffect(() => {
    if (event) {
      setFormData({
        caseId: event.caseId || "",
        title: event.title,
        description: event.description || "",
        eventDate: format(new Date(event.eventDate), "yyyy-MM-dd"),
        eventType: event.eventType,
        location: event.location || "",
        attendees: event.attendees || "",
      });
    } else {
      setFormData({
        caseId: "",
        title: "",
        description: "",
        eventDate: preselectedDate
          ? format(preselectedDate, "yyyy-MM-dd")
          : format(new Date(), "yyyy-MM-dd"),
        eventType: "Meeting",
        location: "",
        attendees: "",
      });
    }
  }, [event, preselectedDate, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      caseId: formData.caseId === "none" ? undefined : formData.caseId || undefined,
      title: formData.title,
      description: formData.description || undefined,
      eventDate: new Date(formData.eventDate),
      eventType: formData.eventType,
      location: formData.location || undefined,
      attendees: formData.attendees || undefined,
    });
    onOpenChange(false);
  };

  const isEditing = !!event;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Edit Event" : "Add New Event"}
          </DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Update the event details below."
              : "Create a new calendar event."}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) =>
                setFormData({ ...formData, title: e.target.value })
              }
              placeholder="e.g., Compliance Team Meeting"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="eventDate">Date *</Label>
              <Input
                id="eventDate"
                type="date"
                value={formData.eventDate}
                onChange={(e) =>
                  setFormData({ ...formData, eventDate: e.target.value })
                }
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="eventType">Event Type *</Label>
              <Select
                value={formData.eventType}
                onValueChange={(value) =>
                  setFormData({ ...formData, eventType: value as CalendarEventType })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {EVENT_TYPES.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="caseId">Related Case (Optional)</Label>
            <Select
              value={formData.caseId}
              onValueChange={(value) =>
                setFormData({ ...formData, caseId: value })
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="No case linked" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No case linked</SelectItem>
                {cases.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.caseNumber} - {c.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              value={formData.location}
              onChange={(e) =>
                setFormData({ ...formData, location: e.target.value })
              }
              placeholder="e.g., Conference Room A"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="attendees">Attendees</Label>
            <Input
              id="attendees"
              value={formData.attendees}
              onChange={(e) =>
                setFormData({ ...formData, attendees: e.target.value })
              }
              placeholder="e.g., John, Sarah, Compliance Team"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) =>
                setFormData({ ...formData, description: e.target.value })
              }
              placeholder="Additional details about this event..."
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={!formData.title}>
              {isEditing ? "Save Changes" : "Add Event"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
