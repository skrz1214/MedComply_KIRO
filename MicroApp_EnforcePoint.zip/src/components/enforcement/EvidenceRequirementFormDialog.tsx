import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, X } from "lucide-react";
import {
  EvidenceRequirementLibraryItem,
  EvidenceChecklistItem,
  CaseType,
  LibraryItemStatus,
} from "@/types/enforcepoint";

interface EvidenceRequirementFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item?: EvidenceRequirementLibraryItem | null;
  onSave: (item: Omit<EvidenceRequirementLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  currentUserName: string;
}

const CASE_TYPES: CaseType[] = ['Survey/Inspection', 'Complaint Investigation', 'Program Integrity/Fraud', 'Privacy/Security', 'Licensure', 'Life Safety', 'Other'];

export function EvidenceRequirementFormDialog({
  open,
  onOpenChange,
  item,
  onSave,
  currentUserName,
}: EvidenceRequirementFormDialogProps) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    caseType: "" as CaseType | "",
    status: "Draft" as LibraryItemStatus,
  });

  const [evidenceChecklist, setEvidenceChecklist] = useState<EvidenceChecklistItem[]>([]);
  const [newEvidence, setNewEvidence] = useState({ type: "", required: true, hasPHI: false, hasPII: false });

  useEffect(() => {
    if (item) {
      setFormData({
        name: item.name,
        description: item.description || "",
        caseType: item.caseType || "",
        status: item.status,
      });
      setEvidenceChecklist(item.evidenceChecklist);
    } else {
      setFormData({
        name: "",
        description: "",
        caseType: "",
        status: "Draft",
      });
      setEvidenceChecklist([]);
    }
  }, [item, open]);

  const addEvidence = () => {
    if (!newEvidence.type.trim()) return;
    const sensitivityGuidance: ('PHI' | 'PII' | 'Confidential')[] = [];
    if (newEvidence.hasPHI) sensitivityGuidance.push('PHI');
    if (newEvidence.hasPII) sensitivityGuidance.push('PII');
    
    setEvidenceChecklist(prev => [
      ...prev,
      {
        id: `ev-${Date.now()}`,
        evidenceType: newEvidence.type,
        isRequired: newEvidence.required,
        sensitivityGuidance: sensitivityGuidance.length > 0 ? sensitivityGuidance : undefined,
      }
    ]);
    setNewEvidence({ type: "", required: true, hasPHI: false, hasPII: false });
  };

  const removeEvidence = (id: string) => {
    setEvidenceChecklist(prev => prev.filter(e => e.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name: formData.name.trim(),
      description: formData.description || undefined,
      caseType: formData.caseType as CaseType || undefined,
      evidenceChecklist,
      status: formData.status,
      version: item ? item.version + 1 : 1,
      createdBy: item?.createdBy || currentUserName,
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{item ? "Edit Evidence Requirement" : "Add Evidence Requirement"}</DialogTitle>
          <DialogDescription>
            {item ? "Update this evidence requirement." : "Create a new evidence checklist."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Survey Evidence Checklist"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: LibraryItemStatus) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Draft">Draft</SelectItem>
                  <SelectItem value="Published">Published</SelectItem>
                  <SelectItem value="Deprecated">Deprecated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe when to use this evidence checklist..."
            />
          </div>

          <div className="space-y-2">
            <Label>Case Type</Label>
            <Select
              value={formData.caseType || "all"}
              onValueChange={(value) => setFormData({ ...formData, caseType: value === "all" ? "" : value as CaseType | "" })}
            >
              <SelectTrigger>
                <SelectValue placeholder="All Types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {CASE_TYPES.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="border-t pt-4 space-y-3">
            <h4 className="font-medium">Evidence Checklist</h4>
            <div className="flex flex-wrap gap-2 min-h-[32px]">
              {evidenceChecklist.map(ev => (
                <Badge key={ev.id} variant={ev.isRequired ? "default" : "secondary"} className="flex items-center gap-1">
                  {ev.evidenceType}
                  {ev.sensitivityGuidance?.includes('PHI') && <span className="text-xs text-destructive">PHI</span>}
                  {ev.sensitivityGuidance?.includes('PII') && <span className="text-xs text-orange-500">PII</span>}
                  <button type="button" onClick={() => removeEvidence(ev.id)}>
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
            <div className="space-y-2">
              <Input
                placeholder="Evidence type (e.g., Training Records)..."
                value={newEvidence.type}
                onChange={(e) => setNewEvidence({ ...newEvidence, type: e.target.value })}
              />
              <div className="flex gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="evRequired"
                    checked={newEvidence.required}
                    onCheckedChange={(checked) => setNewEvidence({ ...newEvidence, required: checked as boolean })}
                  />
                  <Label htmlFor="evRequired" className="text-sm">Required</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="evPHI"
                    checked={newEvidence.hasPHI}
                    onCheckedChange={(checked) => setNewEvidence({ ...newEvidence, hasPHI: checked as boolean })}
                  />
                  <Label htmlFor="evPHI" className="text-sm">Contains PHI</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="evPII"
                    checked={newEvidence.hasPII}
                    onCheckedChange={(checked) => setNewEvidence({ ...newEvidence, hasPII: checked as boolean })}
                  />
                  <Label htmlFor="evPII" className="text-sm">Contains PII</Label>
                </div>
                <Button type="button" variant="outline" size="sm" onClick={addEvidence}>
                  <Plus className="h-4 w-4 mr-1" /> Add
                </Button>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={!formData.name.trim()}>
              {item ? "Save Changes" : "Add Requirement"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}