import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, X } from "lucide-react";
import {
  RemedyLibraryItem,
  RegulatoryLevel,
  ProviderType,
  LibraryItemStatus,
  EvidenceExpectation,
  OperationalRequirement,
} from "@/types/enforcepoint";

interface RemedyLibraryFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item?: RemedyLibraryItem | null;
  onSave: (item: Omit<RemedyLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  currentUserName: string;
}

const LEVELS: RegulatoryLevel[] = ['Federal', 'State', 'Local'];
const PROVIDER_TYPES: ProviderType[] = ['Hospital', 'SNF', 'ALF', 'Clinic', 'Home Health', 'Other'];

export function RemedyLibraryFormDialog({
  open,
  onOpenChange,
  item,
  onSave,
  currentUserName,
}: RemedyLibraryFormDialogProps) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    levelApplicability: [] as RegulatoryLevel[],
    providerTypeApplicability: [] as ProviderType[],
    typicalTriggers: "",
    typicalRequiredSubmissions: "",
    defaultDueInDays: "",
    warningThresholds: "7,3,1",
    isFinancial: false,
    amountRequired: false,
    financialNotes: "",
    penaltyMin: "",
    penaltyMax: "",
    referenceUrl: "",
    status: "Draft" as LibraryItemStatus,
  });

  const [evidenceExpectations, setEvidenceExpectations] = useState<EvidenceExpectation[]>([]);
  const [operationalRequirements, setOperationalRequirements] = useState<OperationalRequirement[]>([]);
  const [newEvidence, setNewEvidence] = useState({ type: "", description: "", required: true });
  const [newRequirement, setNewRequirement] = useState("");

  useEffect(() => {
    if (item) {
      setFormData({
        name: item.name,
        description: item.description,
        levelApplicability: item.levelApplicability,
        providerTypeApplicability: item.providerTypeApplicability,
        typicalTriggers: item.typicalTriggers || "",
        typicalRequiredSubmissions: item.typicalRequiredSubmissions || "",
        defaultDueInDays: item.defaultDueInDays?.toString() || "",
        warningThresholds: item.warningThresholds.join(","),
        isFinancial: item.isFinancial,
        amountRequired: item.amountRequired,
        financialNotes: item.financialNotes || "",
        penaltyMin: item.penaltyMin?.toString() || "",
        penaltyMax: item.penaltyMax?.toString() || "",
        referenceUrl: item.referenceUrl || "",
        status: item.status,
      });
      setEvidenceExpectations(item.evidenceExpectations);
      setOperationalRequirements(item.operationalRequirements);
    } else {
      setFormData({
        name: "",
        description: "",
        levelApplicability: ['Federal', 'State'],
        providerTypeApplicability: ['Hospital', 'SNF', 'ALF', 'Clinic', 'Home Health'],
        typicalTriggers: "",
        typicalRequiredSubmissions: "",
        defaultDueInDays: "",
        warningThresholds: "7,3,1",
        isFinancial: false,
        amountRequired: false,
        financialNotes: "",
        penaltyMin: "",
        penaltyMax: "",
        referenceUrl: "",
        status: "Draft",
      });
      setEvidenceExpectations([]);
      setOperationalRequirements([]);
    }
  }, [item, open]);

  const toggleLevel = (level: RegulatoryLevel) => {
    setFormData(prev => ({
      ...prev,
      levelApplicability: prev.levelApplicability.includes(level)
        ? prev.levelApplicability.filter(l => l !== level)
        : [...prev.levelApplicability, level]
    }));
  };

  const toggleProviderType = (type: ProviderType) => {
    setFormData(prev => ({
      ...prev,
      providerTypeApplicability: prev.providerTypeApplicability.includes(type)
        ? prev.providerTypeApplicability.filter(t => t !== type)
        : [...prev.providerTypeApplicability, type]
    }));
  };

  const addEvidenceExpectation = () => {
    if (!newEvidence.type.trim()) return;
    setEvidenceExpectations(prev => [
      ...prev,
      {
        id: `ee-${Date.now()}`,
        evidenceType: newEvidence.type,
        description: newEvidence.description,
        isRequired: newEvidence.required,
      }
    ]);
    setNewEvidence({ type: "", description: "", required: true });
  };

  const removeEvidenceExpectation = (id: string) => {
    setEvidenceExpectations(prev => prev.filter(e => e.id !== id));
  };

  const addOperationalRequirement = () => {
    if (!newRequirement.trim()) return;
    setOperationalRequirements(prev => [
      ...prev,
      { id: `or-${Date.now()}`, label: newRequirement }
    ]);
    setNewRequirement("");
  };

  const removeOperationalRequirement = (id: string) => {
    setOperationalRequirements(prev => prev.filter(r => r.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name: formData.name.trim(),
      description: formData.description.trim(),
      levelApplicability: formData.levelApplicability,
      regulatoryBodyTags: [],
      providerTypeApplicability: formData.providerTypeApplicability,
      typicalTriggers: formData.typicalTriggers || undefined,
      typicalRequiredSubmissions: formData.typicalRequiredSubmissions || undefined,
      evidenceExpectations,
      defaultDueInDays: formData.defaultDueInDays ? parseInt(formData.defaultDueInDays) : undefined,
      warningThresholds: formData.warningThresholds.split(",").map(n => parseInt(n.trim())).filter(n => !isNaN(n)),
      isFinancial: formData.isFinancial,
      amountRequired: formData.amountRequired,
      financialNotes: formData.financialNotes || undefined,
      penaltyMin: formData.penaltyMin ? parseFloat(formData.penaltyMin) : undefined,
      penaltyMax: formData.penaltyMax ? parseFloat(formData.penaltyMax) : undefined,
      referenceUrl: formData.referenceUrl.trim() || undefined,
      operationalRequirements,
      status: formData.status,
      version: item ? item.version + 1 : 1,
      createdBy: item?.createdBy || currentUserName,
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{item ? "Edit Remedy/Action" : "Add Remedy/Action"}</DialogTitle>
          <DialogDescription>
            {item ? "Update this library item." : "Create a new reusable remedy or action type."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Civil Money Penalty (CMP)"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: LibraryItemStatus) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Draft">Draft</SelectItem>
                  <SelectItem value="Published">Published</SelectItem>
                  <SelectItem value="Deprecated">Deprecated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe when this remedy applies..."
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Level Applicability</Label>
              <div className="flex flex-wrap gap-2">
                {LEVELS.map(level => (
                  <div key={level} className="flex items-center space-x-2">
                    <Checkbox
                      id={`level-${level}`}
                      checked={formData.levelApplicability.includes(level)}
                      onCheckedChange={() => toggleLevel(level)}
                    />
                    <Label htmlFor={`level-${level}`} className="text-sm cursor-pointer">{level}</Label>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <Label>Provider Types</Label>
              <div className="flex flex-wrap gap-2">
                {PROVIDER_TYPES.map(type => (
                  <div key={type} className="flex items-center space-x-2">
                    <Checkbox
                      id={`provider-${type}`}
                      checked={formData.providerTypeApplicability.includes(type)}
                      onCheckedChange={() => toggleProviderType(type)}
                    />
                    <Label htmlFor={`provider-${type}`} className="text-sm cursor-pointer">{type}</Label>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="typicalTriggers">Typical Triggers/Criteria</Label>
            <Textarea
              id="typicalTriggers"
              value={formData.typicalTriggers}
              onChange={(e) => setFormData({ ...formData, typicalTriggers: e.target.value })}
              placeholder="Describe typical triggers for this remedy..."
            />
          </div>

          <div className="border-t pt-4 space-y-4">
            <h4 className="font-medium">Financial Details & Penalties</h4>
            <div className="flex items-center gap-6">
              <div className="flex items-center space-x-2">
                <Switch
                  id="isFinancial"
                  checked={formData.isFinancial}
                  onCheckedChange={(checked) => setFormData({ ...formData, isFinancial: checked })}
                />
                <Label htmlFor="isFinancial">Financial Remedy</Label>
              </div>
              {formData.isFinancial && (
                <div className="flex items-center space-x-2">
                  <Switch
                    id="amountRequired"
                    checked={formData.amountRequired}
                    onCheckedChange={(checked) => setFormData({ ...formData, amountRequired: checked })}
                  />
                  <Label htmlFor="amountRequired">Amount Required</Label>
                </div>
              )}
            </div>
            {formData.isFinancial && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="penaltyMin">Penalty Minimum ($)</Label>
                    <Input
                      id="penaltyMin"
                      type="number"
                      value={formData.penaltyMin}
                      onChange={(e) => setFormData({ ...formData, penaltyMin: e.target.value })}
                      placeholder="e.g., 1000"
                      min={0}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="penaltyMax">Penalty Maximum ($)</Label>
                    <Input
                      id="penaltyMax"
                      type="number"
                      value={formData.penaltyMax}
                      onChange={(e) => setFormData({ ...formData, penaltyMax: e.target.value })}
                      placeholder="e.g., 50000"
                      min={0}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="financialNotes">Financial Notes</Label>
                  <Textarea
                    id="financialNotes"
                    value={formData.financialNotes}
                    onChange={(e) => setFormData({ ...formData, financialNotes: e.target.value })}
                    placeholder="Notes about penalty amounts, payment schedules..."
                  />
                </div>
              </>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="referenceUrl">Reference URL (Governing Body)</Label>
            <Input
              id="referenceUrl"
              type="url"
              value={formData.referenceUrl}
              onChange={(e) => setFormData({ ...formData, referenceUrl: e.target.value })}
              placeholder="https://www.cms.gov/regulations/..."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="defaultDueInDays">Default Due (Days)</Label>
              <Input
                id="defaultDueInDays"
                type="number"
                value={formData.defaultDueInDays}
                onChange={(e) => setFormData({ ...formData, defaultDueInDays: e.target.value })}
                placeholder="e.g., 10"
                min={1}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="warningThresholds">Warning Thresholds (days, comma-separated)</Label>
              <Input
                id="warningThresholds"
                value={formData.warningThresholds}
                onChange={(e) => setFormData({ ...formData, warningThresholds: e.target.value })}
                placeholder="7,3,1"
              />
            </div>
          </div>

          <div className="border-t pt-4 space-y-3">
            <h4 className="font-medium">Evidence Expectations</h4>
            <div className="flex flex-wrap gap-2 min-h-[32px]">
              {evidenceExpectations.map(ee => (
                <Badge key={ee.id} variant={ee.isRequired ? "default" : "secondary"} className="flex items-center gap-1">
                  {ee.evidenceType}
                  <button type="button" onClick={() => removeEvidenceExpectation(ee.id)}>
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
            <div className="flex gap-2 items-end">
              <div className="flex-1">
                <Input
                  placeholder="Evidence type..."
                  value={newEvidence.type}
                  onChange={(e) => setNewEvidence({ ...newEvidence, type: e.target.value })}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="evRequired"
                  checked={newEvidence.required}
                  onCheckedChange={(checked) => setNewEvidence({ ...newEvidence, required: checked as boolean })}
                />
                <Label htmlFor="evRequired" className="text-sm">Required</Label>
              </div>
              <Button type="button" variant="outline" size="sm" onClick={addEvidenceExpectation}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="border-t pt-4 space-y-3">
            <h4 className="font-medium">Operational Requirements</h4>
            <div className="flex flex-wrap gap-2 min-h-[32px]">
              {operationalRequirements.map(or => (
                <Badge key={or.id} variant="outline" className="flex items-center gap-1">
                  {or.label}
                  <button type="button" onClick={() => removeOperationalRequirement(or.id)}>
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                placeholder="Add requirement (e.g., Training completed)..."
                value={newRequirement}
                onChange={(e) => setNewRequirement(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addOperationalRequirement())}
              />
              <Button type="button" variant="outline" size="sm" onClick={addOperationalRequirement}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={!formData.name.trim() || !formData.description.trim()}>
              {item ? "Save Changes" : "Add Remedy"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}