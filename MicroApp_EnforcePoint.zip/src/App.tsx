import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { EnforcementProvider } from "@/context/EnforcementContext";
import { LibraryProvider } from "@/context/LibraryContext";
import { EnforcePointProvider } from "@/context/EnforcePointContext";
import { UserProvider } from "@/context/UserContext";

// EnforcePoint Pages
import EnforcementDashboard from "./pages/enforcement/EnforcementDashboard";
import CaseList from "./pages/enforcement/CaseList";
import CaseWorkspace from "./pages/enforcement/CaseWorkspace";
import CreateCaseWizard from "./pages/enforcement/CreateCaseWizard";
import ActionsPage from "./pages/enforcement/ActionsPage";
import CorrespondencePage from "./pages/enforcement/CorrespondencePage";
import AppealsPage from "./pages/enforcement/AppealsPage";
import CalendarPage from "./pages/enforcement/CalendarPage";
import ReportsPage from "./pages/enforcement/ReportsPage";
import AdminConfigPage from "./pages/enforcement/AdminConfigPage";
import RegulatoryBodiesPage from "./pages/enforcement/RegulatoryBodiesPage";
import EnforcementLibrary from "./pages/enforcement/EnforcementLibrary";
import PRDPage from "./pages/docs/PRDPage";
import QATestCasesPage from "./pages/docs/QATestCasesPage";
import UATTestCasesPage from "./pages/docs/UATTestCasesPage";
import SystemPromptPage from "./pages/docs/SystemPromptPage";

import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <UserProvider>
        <EnforcementProvider>
          <LibraryProvider>
            <EnforcePointProvider>
              <Toaster />
              <Sonner />
              <BrowserRouter>
                <Routes>
                  {/* Redirect root to enforcement dashboard */}
                  <Route path="/" element={<Navigate to="/enforcement" replace />} />
                  
                  {/* EnforcePoint Routes */}
                  <Route path="/enforcement" element={<EnforcementDashboard />} />
                  <Route path="/enforcement/cases" element={<CaseList />} />
                  <Route path="/enforcement/cases/new" element={<CreateCaseWizard />} />
                  <Route path="/enforcement/cases/:caseId" element={<CaseWorkspace />} />
                  <Route path="/enforcement/actions" element={<ActionsPage />} />
                  <Route path="/enforcement/regulatory" element={<RegulatoryBodiesPage />} />
                  <Route path="/enforcement/library" element={<EnforcementLibrary />} />
                  <Route path="/enforcement/correspondence" element={<CorrespondencePage />} />
                  <Route path="/enforcement/appeals" element={<AppealsPage />} />
                  <Route path="/enforcement/calendar" element={<CalendarPage />} />
                  <Route path="/enforcement/reports" element={<ReportsPage />} />
                  <Route path="/admin" element={<AdminConfigPage />} />
                  <Route path="/docs/prd" element={<PRDPage />} />
                  <Route path="/docs/qa-test-cases" element={<QATestCasesPage />} />
                  <Route path="/docs/uat-test-cases" element={<UATTestCasesPage />} />
                  <Route path="/docs/system-prompt" element={<SystemPromptPage />} />
                  
                  {/* Placeholder routes for other suite modules */}
                  <Route path="/compliance" element={<div className="p-8">Compliance Items - Coming Soon</div>} />
                  <Route path="/capa" element={<div className="p-8">ActionGuard CAPA - Coming Soon</div>} />
                  <Route path="/citations" element={<div className="p-8">Citations - Coming Soon</div>} />
                  <Route path="/reports" element={<div className="p-8">Reports - Coming Soon</div>} />
                  
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </BrowserRouter>
            </EnforcePointProvider>
          </LibraryProvider>
        </EnforcementProvider>
      </UserProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
