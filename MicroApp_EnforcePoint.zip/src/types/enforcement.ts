export type EnforcementStatus = 'Pending' | 'Active' | 'Resolved' | 'Deleted';

export interface GoverningAuthority {
  name: string;
  contactPerson?: string;
  email?: string;
  phone?: string;
}

export interface Enforcement {
  id: string;
  referenceNumber: string;
  description: string;
  status: EnforcementStatus;
  governingBody: string;
  governingAuthority?: GoverningAuthority;
  penaltyAmount: number;
  penaltyType: string;
  issueDate: Date;
  dueDate?: Date;
  paymentStatus?: 'Pending Payment' | 'Paid' | 'Overdue' | 'Waived';
  impactLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  sourceUrl?: string;
  attachments?: string[];
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
  ticketId?: string;
  ticketDescription?: string;
}

export interface TodoItem {
  id: string;
  enforcementId?: string;
  ticketId: string;
  ticketDescription: string;
  assignee: string;
  createdAt: Date;
  isProcessed: boolean;
}
