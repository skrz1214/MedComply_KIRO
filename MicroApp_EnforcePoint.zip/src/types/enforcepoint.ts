// ============= EnforcePoint Core Types =============

// User Roles
export type UserRole = 'Admin' | 'Compliance Head' | 'Department Head' | 'Staff';

// Regulatory Body Types
export type RegulatoryLevel = 'Federal' | 'State' | 'Local';
export type OversightType = 'survey' | 'privacy' | 'fraud' | 'licensure' | 'life_safety' | 'program_integrity' | 'other';

export interface RegulatoryBody {
  id: string;
  name: string;
  abbreviation?: string;
  level: RegulatoryLevel;
  jurisdiction?: string; // State code for state-level bodies
  oversightTypes: OversightType[];
  enforcementScopeTags: string[];
  standardResponseDays?: number;
  contactEmail?: string;
  contactPhone?: string;
  portalUrl?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Enforcement Case Types
export type CaseType = 
  | 'Survey/Inspection' 
  | 'Complaint Investigation' 
  | 'Program Integrity/Fraud' 
  | 'Privacy/Security' 
  | 'Licensure' 
  | 'Life Safety' 
  | 'Other';

export type ProviderType = 
  | 'Hospital' 
  | 'Clinic' 
  | 'SNF' 
  | 'ALF' 
  | 'Home Health' 
  | 'Other';

export type CaseSeverity = 'Low' | 'Medium' | 'High' | 'Critical';
export type ScopePrevalence = 'Isolated' | 'Pattern' | 'Widespread';

// DUAL LIFECYCLE STATUSES
// Intake Lifecycle (Case Creation)
export type IntakeStatus = 
  | 'I0_Draft'
  | 'I1_Notice_Logged'
  | 'I2_Triage_Assignment'
  | 'I3_Ready_For_Management';

// Operational Lifecycle (Case Management)
export type OperationalStatus = 
  | 'O0_Not_Started'
  | 'O1_Response_Planning'
  | 'O2_Remediation_Linked'
  | 'O3_Response_In_Progress'
  | 'O4_Submitted_Awaiting'
  | 'O5_Remedies_Active'
  | 'O6_Verification_Revisit'
  | 'O7_Closed'
  | 'O8_Reopened';

// Combined status for backwards compatibility
export type CaseStatus = 
  | 'Draft'
  | 'Notice Received'
  | 'Triage & Assignment'
  | 'Response Planning'
  | 'Remediation Linked'
  | 'Response In Progress'
  | 'Submitted / Awaiting Determination'
  | 'Remedies Active'
  | 'Verification / Revisit'
  | 'Closed'
  | 'Reopened';

// Library reference types
export type LibraryItemType = 
  | 'regulatory_body'
  | 'remedy'
  | 'deadline_rule'
  | 'response_template'
  | 'evidence_requirement'
  | 'finding_category';

export type LibraryApplyTarget = 
  | 'case_overview'
  | 'deadline'
  | 'remedy_action'
  | 'response_package'
  | 'evidence_checklist'
  | 'finding';

// Library Reference (link only, no case changes)
export interface LibraryReference {
  id: string;
  libraryItemType: LibraryItemType;
  libraryItemId: string;
  libraryItemVersion: number;
  libraryItemName: string;
  referencedBy: string;
  referencedAt: Date;
  note?: string;
}

// Applied Library Snapshot (copies data into case)
export interface AppliedLibrarySnapshot {
  id: string;
  libraryItemType: LibraryItemType;
  libraryItemId: string;
  libraryItemVersion: number;
  libraryItemName: string;
  snapshotPayload: Record<string, unknown>;
  appliedBy: string;
  appliedAt: Date;
  appliedToTarget: LibraryApplyTarget;
  targetEntityId?: string; // ID of the deadline, action, etc. created
}

export type TriggerSource = 
  | 'Survey' 
  | 'Complaint' 
  | 'Incident' 
  | 'Audit' 
  | 'Self-Disclosure' 
  | 'Referral' 
  | 'Other';

export interface Deadline {
  id: string;
  caseId: string;
  title: string;
  description?: string;
  dueDate: Date;
  type: 'Response' | 'PoC' | 'Appeal Filing' | 'Payment' | 'Revisit' | 'Hearing' | 'Other';
  isCompleted: boolean;
  completedDate?: Date;
  assigneeId?: string;
  reminderDays?: number[];
  escalationRecipients?: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface EnforcementCase {
  id: string;
  caseNumber: string;
  title: string;
  summary: string;
  regulatoryBodyId: string;
  caseType: CaseType;
  providerType: ProviderType;
  facility?: string;
  location?: string;
  unitWing?: string;
  department?: string;
  serviceLine?: string;
  triggerSource: TriggerSource;
  
  // Key Dates
  noticeReceivedDate: Date;
  surveyDates?: Date[];
  investigationStartDate?: Date;
  responseDueDate: Date;
  remedyEffectiveDates?: Date[];
  closureDate?: Date;
  
  // DUAL LIFECYCLE STATUS
  intakeStatus: IntakeStatus;
  caseStatus: OperationalStatus;
  status: CaseStatus; // Backwards compatibility - derived from dual statuses
  
  // Assignment
  assignedOwnerId?: string;
  assignedOwnerName?: string;
  assignedDepartment?: string;
  departmentHeadId?: string;
  departmentHeadName?: string;
  complianceHeadId?: string;
  complianceHeadName?: string;
  
  // Risk Classification
  severity: CaseSeverity;
  immediateJeopardy: boolean;
  scopePrevalence?: ScopePrevalence;
  
  // Related Records
  linkedIssueIds: string[];
  linkedCapaIds: string[];
  linkedCitationIds: string[];
  linkedCitationCaseIds: string[];
  
  // LIBRARY INTEGRATION
  libraryReferences: LibraryReference[];
  appliedLibrarySnapshots: AppliedLibrarySnapshot[];
  
  // Evidence & Notes
  evidenceFiles: EvidenceFile[];
  notes?: string;
  watchers: string[];
  
  // Audit
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

// Enforcement Action (Remedies/Penalties)
export type ActionCategory = 
  | 'Financial Penalty'
  | 'Payment Remedy'
  | 'Operational Remedy'
  | 'Licensure/Restriction'
  | 'Monitoring/Reporting Requirement'
  | 'Other';

export type ActionStatus = 'Proposed' | 'Imposed' | 'Active' | 'Stayed' | 'Resolved';

export interface ActionType {
  id: string;
  name: string;
  category: ActionCategory;
  description?: string;
  isDefault: boolean;
  isActive: boolean;
}

export interface EnforcementAction {
  id: string;
  caseId: string;
  actionCategory: ActionCategory;
  actionTypeId: string;
  actionTypeName: string;
  amount?: number;
  startDate?: Date;
  endDate?: Date;
  status: ActionStatus;
  conditionsRequirements?: string;
  requirementChecklist?: ChecklistItem[];
  proofOfComplianceRequired?: string;
  linkedCapaIds: string[];
  linkedIssueIds: string[];
  evidenceFiles: EvidenceFile[];
  createdAt: Date;
  updatedAt: Date;
}

export interface ChecklistItem {
  id: string;
  label: string;
  isCompleted: boolean;
  completedDate?: Date;
  completedBy?: string;
}

// Correspondence
export type CorrespondenceDirection = 'Inbound' | 'Outbound';
export type DocumentType = 
  | 'Notice'
  | 'Statement of Deficiencies'
  | 'Demand Letter'
  | 'CAP Request'
  | 'Plan of Correction'
  | 'Response Letter'
  | 'Appeal Filing'
  | 'Settlement'
  | 'Payment Confirmation'
  | 'Revisit Results'
  | 'Meeting Notes'
  | 'Other';

export interface CorrespondenceItem {
  id: string;
  caseId: string;
  direction: CorrespondenceDirection;
  documentType: DocumentType;
  date: Date;
  senderRecipient: string;
  subject: string;
  description?: string;
  attachments: EvidenceFile[];
  linkedDeadlineIds: string[];
  linkedActionIds: string[];
  version?: number;
  createdAt: Date;
  updatedAt: Date;
}

// Appeal
export type AppealLevel = 
  | 'Informal Dispute'
  | 'Administrative Hearing'
  | 'State-Level Hearing'
  | 'Federal-Level'
  | 'Other';

export type AppealOutcome = 'Pending' | 'Won' | 'Lost' | 'Settled' | 'Withdrawn';

export interface Appeal {
  id: string;
  caseId: string;
  appealLevel: AppealLevel;
  filingDueDate?: Date;
  filedDate?: Date;
  hearingDate?: Date;
  outcome: AppealOutcome;
  counselRepresentative?: string;
  notes?: string;
  documents: EvidenceFile[];
  createdAt: Date;
  updatedAt: Date;
}

// Finding/Deficiency
export type FindingCategory = 
  | 'Privacy'
  | 'Safety'
  | 'Staffing'
  | 'Infection Control'
  | 'Documentation'
  | 'Life Safety'
  | 'Medication Management'
  | 'Resident Rights'
  | 'Quality of Care'
  | 'Administration'
  | 'Other';

export interface Finding {
  id: string;
  caseId: string;
  title: string;
  description: string;
  category: FindingCategory;
  linkedCitationIds: string[];
  severity?: CaseSeverity;
  scopePrevalence?: ScopePrevalence;
  correctiveElementsChecklist: ChecklistItem[];
  linkedIssueId?: string;
  linkedCapaId?: string;
  createdAt: Date;
  updatedAt: Date;
}

// Response Package
export type ApprovalStatus = 'Draft' | 'Pending Dept Review' | 'Pending Compliance Review' | 'Approved' | 'Changes Requested' | 'Submitted';

export interface ResponsePackage {
  id: string;
  caseId: string;
  responseSummary: string;
  correctiveActionsTaken: string;
  preventiveSystemActions: string;
  monitoringPlan: string;
  completionDates?: string;
  responsibleParties?: string;
  attachmentIds: string[];
  submissionMethod?: 'Portal' | 'Mail' | 'Email' | 'Fax';
  submissionDate?: Date;
  submissionConfirmation?: string;
  
  // Approvals
  approvalStatus: ApprovalStatus;
  deptHeadApprovalDate?: Date;
  deptHeadApprovalBy?: string;
  complianceHeadApprovalDate?: Date;
  complianceHeadApprovalBy?: string;
  
  createdAt: Date;
  updatedAt: Date;
}

// Evidence File
export interface EvidenceFile {
  id: string;
  fileName: string;
  fileUrl?: string;
  fileSize?: number;
  mimeType?: string;
  sensitivityTags: ('PHI' | 'PII' | 'Confidential')[];
  uploadedBy: string;
  uploadedAt: Date;
  description?: string;
}

// Audit Log Entry
export type AuditAction = 
  | 'Created'
  | 'Updated'
  | 'Status Changed'
  | 'Deadline Added'
  | 'Deadline Updated'
  | 'Correspondence Added'
  | 'Action Added'
  | 'Action Updated'
  | 'Finding Added'
  | 'Approval Requested'
  | 'Approved'
  | 'Changes Requested'
  | 'Submitted'
  | 'Appeal Filed'
  | 'Closed'
  | 'Reopened'
  | 'Override'
  | 'Library Reference Added'
  | 'Library Item Applied';

export interface AuditLogEntry {
  id: string;
  caseId: string;
  action: AuditAction;
  description: string;
  previousValue?: string;
  newValue?: string;
  performedBy: string;
  performedByRole: UserRole;
  performedAt: Date;
  justification?: string;
}

// Configuration Types
export interface DeadlineRule {
  id: string;
  regulatoryBodyId?: string;
  caseType?: CaseType;
  deadlineType: Deadline['type'];
  defaultDays: number;
  warningDays: number[];
  escalationRecipients: UserRole[];
  isActive: boolean;
}

export interface EscalationRule {
  id: string;
  triggerCondition: string;
  triggerValue: number;
  recipients: UserRole[];
  isActive: boolean;
}

export interface FindingCategoryConfig {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
}

export interface CaseTypeConfig {
  id: string;
  name: string;
  description?: string;
  requiredEvidenceTypes: string[];
  isActive: boolean;
}

// Notification (Mock)
export interface Notification {
  id: string;
  userId: string;
  type: 'Notice Received' | 'Deadline Due' | 'Deadline Overdue' | 'Approval Requested' | 'Approval Decision' | 'Remedy Imposed' | 'Revisit Scheduled' | 'Revisit Outcome';
  title: string;
  message: string;
  caseId?: string;
  isRead: boolean;
  createdAt: Date;
}

// Dashboard Stats
export interface EnforcementStats {
  totalOpenCases: number;
  casesBySeverity: Record<CaseSeverity, number>;
  casesByStatus: Record<CaseStatus, number>;
  upcomingDeadlines: number;
  overdueDeadlines: number;
  activeRemedies: number;
  totalPenaltyAmount: number;
}

// ============= ENFORCEMENT LIBRARY TYPES =============

export type LibraryItemStatus = 'Draft' | 'Published' | 'Deprecated';

// A) RemedyLibraryItem - Core library item for remedies/actions
export interface EvidenceExpectation {
  id: string;
  evidenceType: string;
  description: string;
  isRequired: boolean;
  notes?: string;
}

export interface OperationalRequirement {
  id: string;
  label: string;
  description?: string;
}

export interface RemedyLibraryItem {
  id: string;
  name: string;
  levelApplicability: RegulatoryLevel[];
  regulatoryBodyTags: string[]; // IDs of regulatory bodies
  providerTypeApplicability: ProviderType[];
  description: string;
  typicalTriggers?: string;
  typicalRequiredSubmissions?: string;
  evidenceExpectations: EvidenceExpectation[];
  defaultDueInDays?: number;
  warningThresholds: number[]; // e.g., [7, 3, 1]
  isFinancial: boolean;
  amountRequired: boolean;
  financialNotes?: string;
  penaltyMin?: number;
  penaltyMax?: number;
  referenceUrl?: string;
  operationalRequirements: OperationalRequirement[];
  status: LibraryItemStatus;
  version: number;
  previousVersionId?: string;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

// B) DeadlineRuleLibraryItem
export type DeadlineRuleType = 'Response Due' | 'Appeal Due' | 'Payment Due' | 'Revisit' | 'PoC Due' | 'Other';
export type DeadlineCalculationBase = 'notice_received_date' | 'survey_date' | 'posted_date';

export interface DeadlineRuleLibraryItem {
  id: string;
  name: string;
  regulatoryBodyId?: string;
  caseType?: CaseType;
  remedyTypeId?: string;
  deadlineType: DeadlineRuleType;
  calculationBase: DeadlineCalculationBase;
  defaultDueInDays: number;
  warningThresholds: number[];
  escalationRoles: UserRole[];
  status: LibraryItemStatus;
  version: number;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

// C) ResponseTemplateLibraryItem
export interface TemplateSection {
  id: string;
  name: string;
  description?: string;
  isRequired: boolean;
  sampleLanguage?: string;
}

export interface RequiredAttachment {
  id: string;
  name: string;
  description?: string;
  isRequired: boolean;
}

export interface ResponseTemplateLibraryItem {
  id: string;
  templateName: string;
  regulatoryBodyId?: string;
  caseType?: CaseType;
  description?: string;
  requiredSections: TemplateSection[];
  requiredAttachments: RequiredAttachment[];
  status: LibraryItemStatus;
  version: number;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

// D) EvidenceRequirementLibraryItem
export interface EvidenceChecklistItem {
  id: string;
  evidenceType: string;
  description?: string;
  isRequired: boolean;
  sensitivityGuidance?: ('PHI' | 'PII' | 'Confidential')[];
  notes?: string;
}

export interface EvidenceRequirementLibraryItem {
  id: string;
  name: string;
  caseType?: CaseType;
  remedyTypeId?: string;
  description?: string;
  evidenceChecklist: EvidenceChecklistItem[];
  status: LibraryItemStatus;
  version: number;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

// E) FindingCategoryLibraryItem
export interface FindingCategoryLibraryItem {
  id: string;
  name: string;
  description?: string;
  typicalCitations?: string[];
  applicableCaseTypes: CaseType[];
  status: LibraryItemStatus;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

// Library Configuration
export interface LibraryConfig {
  whoCanManage: ('Admin' | 'Admin+Compliance Head')[];
  editPublishedAllowed: boolean;
  requireNewVersionOnChange: boolean;
  hideDeprecatedFromPickers: boolean;
  defaultWarningThresholds: number[];
  defaultEscalationRoles: UserRole[];
}

// Case-Library Reference (snapshot when library item is applied to case)
export interface CaseLibraryReference {
  id: string;
  caseId: string;
  libraryItemId: string;
  libraryItemType: 'remedy' | 'deadline_rule' | 'response_template' | 'evidence_requirement';
  libraryItemVersion: number;
  snapshotData: Record<string, unknown>; // Snapshot of library item at time of use
  appliedAt: Date;
  appliedBy: string;
}

// Extended EnforcementAction with library reference
export interface EnforcementActionWithLibrary extends EnforcementAction {
  remedyLibraryItemId?: string;
  remedyLibraryItemVersion?: number;
  snapshotEvidenceExpectations?: EvidenceExpectation[];
  snapshotOperationalRequirements?: OperationalRequirement[];
}

// Extended Deadline with library reference
export interface DeadlineWithLibrary extends Deadline {
  deadlineRuleLibraryItemId?: string;
  deadlineRuleLibraryItemVersion?: number;
}

// Extended ResponsePackage with library reference
export interface ResponsePackageWithLibrary extends ResponsePackage {
  templateLibraryItemId?: string;
  templateLibraryItemVersion?: number;
  snapshotRequiredSections?: TemplateSection[];
  snapshotRequiredAttachments?: RequiredAttachment[];
}

// Case Evidence Requirement Status
export interface CaseEvidenceRequirement {
  id: string;
  caseId: string;
  evidenceType: string;
  description?: string;
  isRequired: boolean;
  status: 'Missing' | 'Provided' | 'Reviewed';
  linkedFileId?: string;
  sourceLibraryItemId?: string;
  sourceType: 'remedy' | 'template' | 'manual';
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}
