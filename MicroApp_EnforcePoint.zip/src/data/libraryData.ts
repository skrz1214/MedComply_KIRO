export interface EnforcementTemplate {
  id: string;
  name: string;
  category: string;
  description: string;
  governingBody: string;
  typicalPenaltyRange: string;
  penaltyType: 'Financial' | 'Operational' | 'Legal' | 'Administrative';
  complianceArea: string;
  keyRequirements: string[];
  sourceUrl?: string;
  attachments?: string[];
}

export interface RegulatoryReference {
  id: string;
  regulation: string;
  code: string;
  governingBody: string;
  description: string;
  effectiveDate: string;
  penalties: string;
  applicability: string;
  sourceUrl: string;
}

export interface HistoricalRecord {
  id: string;
  referenceNumber: string;
  violationType: string;
  governingBody: string;
  penaltyAmount: number;
  resolution: string;
  resolvedDate: string;
  lessonsLearned: string;
  impactLevel: 'Critical' | 'High' | 'Medium' | 'Low';
}

export const enforcementTemplates: EnforcementTemplate[] = [
  {
    id: 'template-1',
    name: 'HIPAA Privacy Violation',
    category: 'Privacy',
    description: 'Unauthorized disclosure of protected health information (PHI) to unauthorized parties.',
    governingBody: 'HHS Office for Civil Rights',
    typicalPenaltyRange: '$100 - $50,000 per violation',
    penaltyType: 'Financial',
    complianceArea: 'HIPAA Privacy Rule',
    keyRequirements: [
      'Patient authorization for PHI disclosure',
      'Minimum necessary standard compliance',
      'Notice of Privacy Practices distribution',
      'Employee training on privacy policies'
    ]
  },
  {
    id: 'template-2',
    name: 'HIPAA Security Breach',
    category: 'Security',
    description: 'Failure to implement required security safeguards resulting in data breach.',
    governingBody: 'HHS Office for Civil Rights',
    typicalPenaltyRange: '$10,000 - $1,500,000 per year',
    penaltyType: 'Financial',
    complianceArea: 'HIPAA Security Rule',
    keyRequirements: [
      'Risk analysis and management',
      'Access controls implementation',
      'Encryption of ePHI',
      'Audit controls and monitoring'
    ]
  },
  {
    id: 'template-3',
    name: 'Medicare Billing Fraud',
    category: 'Billing',
    description: 'Submitting false claims or upcoding for Medicare reimbursement.',
    governingBody: 'CMS / OIG',
    typicalPenaltyRange: '$10,000 - $50,000 per false claim',
    penaltyType: 'Financial',
    complianceArea: 'False Claims Act',
    keyRequirements: [
      'Accurate coding practices',
      'Documentation supporting claims',
      'Regular billing audits',
      'Compliance training for billing staff'
    ]
  },
  {
    id: 'template-4',
    name: 'Anti-Kickback Violation',
    category: 'Fraud',
    description: 'Offering or receiving payment for patient referrals in federal healthcare programs.',
    governingBody: 'OIG / DOJ',
    typicalPenaltyRange: '$50,000 - $100,000 per violation + exclusion',
    penaltyType: 'Legal',
    complianceArea: 'Anti-Kickback Statute',
    keyRequirements: [
      'Fair market value arrangements',
      'Written agreements for referrals',
      'Safe harbor compliance',
      'Due diligence on business arrangements'
    ]
  },
  {
    id: 'template-5',
    name: 'Stark Law Violation',
    category: 'Referral',
    description: 'Physician self-referral for designated health services to entities with financial relationships.',
    governingBody: 'CMS',
    typicalPenaltyRange: '$15,000 - $100,000 per claim + refund',
    penaltyType: 'Financial',
    complianceArea: 'Physician Self-Referral Law',
    keyRequirements: [
      'Exception compliance verification',
      'Written documentation of arrangements',
      'Fair market value compensation',
      'Annual compliance reviews'
    ]
  },
  {
    id: 'template-6',
    name: 'EMTALA Violation',
    category: 'Patient Care',
    description: 'Failure to provide emergency medical screening and stabilization treatment.',
    governingBody: 'CMS',
    typicalPenaltyRange: '$25,000 - $50,000 per violation',
    penaltyType: 'Operational',
    complianceArea: 'Emergency Medical Treatment and Labor Act',
    keyRequirements: [
      'Medical screening examination for all',
      'Stabilization before transfer',
      'Proper transfer protocols',
      'On-call physician availability'
    ]
  },
  {
    id: 'template-7',
    name: 'State Licensure Non-Compliance',
    category: 'Licensing',
    description: 'Operating without proper state licensure or failing to meet licensing requirements.',
    governingBody: 'State Health Department',
    typicalPenaltyRange: '$1,000 - $25,000 per day',
    penaltyType: 'Administrative',
    complianceArea: 'State Healthcare Regulations',
    keyRequirements: [
      'Current license maintenance',
      'Timely renewal submissions',
      'Compliance with inspection findings',
      'Staff credentialing requirements'
    ]
  },
  {
    id: 'template-8',
    name: 'OSHA Workplace Safety Violation',
    category: 'Safety',
    description: 'Failure to maintain safe workplace conditions for healthcare workers.',
    governingBody: 'OSHA',
    typicalPenaltyRange: '$15,625 - $156,259 per violation',
    penaltyType: 'Financial',
    complianceArea: 'Occupational Safety and Health Act',
    keyRequirements: [
      'Bloodborne pathogen compliance',
      'Hazard communication program',
      'Personal protective equipment',
      'Injury and illness recordkeeping'
    ]
  }
];

export const regulatoryReferences: RegulatoryReference[] = [
  {
    id: 'reg-1',
    regulation: 'HIPAA Privacy Rule',
    code: '45 CFR Part 160 and Subparts A and E of Part 164',
    governingBody: 'HHS Office for Civil Rights',
    description: 'Establishes national standards for the protection of individually identifiable health information.',
    effectiveDate: 'April 14, 2003',
    penalties: 'Tier 1: $100-$50,000 | Tier 2: $1,000-$50,000 | Tier 3: $10,000-$50,000 | Tier 4: $50,000+',
    applicability: 'Covered entities and business associates',
    sourceUrl: 'https://www.hhs.gov/hipaa/for-professionals/privacy/index.html'
  },
  {
    id: 'reg-2',
    regulation: 'HIPAA Security Rule',
    code: '45 CFR Part 160 and Subparts A and C of Part 164',
    governingBody: 'HHS Office for Civil Rights',
    description: 'Establishes national standards for protecting electronic protected health information.',
    effectiveDate: 'April 20, 2005',
    penalties: 'Up to $1.5 million per violation category per year',
    applicability: 'Covered entities and business associates handling ePHI',
    sourceUrl: 'https://www.hhs.gov/hipaa/for-professionals/security/index.html'
  },
  {
    id: 'reg-3',
    regulation: 'False Claims Act',
    code: '31 U.S.C. §§ 3729-3733',
    governingBody: 'Department of Justice',
    description: 'Imposes liability on persons and companies who defraud governmental programs.',
    effectiveDate: 'March 2, 1863 (amended)',
    penalties: '$11,665 to $23,331 per false claim plus treble damages',
    applicability: 'Any entity submitting claims to federal healthcare programs',
    sourceUrl: 'https://www.justice.gov/civil/false-claims-act'
  },
  {
    id: 'reg-4',
    regulation: 'Anti-Kickback Statute',
    code: '42 U.S.C. § 1320a-7b(b)',
    governingBody: 'OIG / Department of Justice',
    description: 'Prohibits offering, paying, soliciting, or receiving anything of value to induce referrals.',
    effectiveDate: 'August 21, 1996',
    penalties: 'Up to $100,000 per violation, imprisonment up to 10 years, program exclusion',
    applicability: 'All participants in federal healthcare programs',
    sourceUrl: 'https://oig.hhs.gov/compliance/physician-education/fraud-abuse-laws/'
  },
  {
    id: 'reg-5',
    regulation: 'Stark Law (Physician Self-Referral)',
    code: '42 U.S.C. § 1395nn',
    governingBody: 'CMS',
    description: 'Prohibits physicians from referring Medicare patients for designated health services to entities with which they have financial relationships.',
    effectiveDate: 'January 1, 1992',
    penalties: 'Denial of payment, refunds, civil monetary penalties up to $100,000, program exclusion',
    applicability: 'Physicians and entities providing designated health services',
    sourceUrl: 'https://www.cms.gov/Medicare/Fraud-and-Abuse/PhysicianSelfReferral'
  },
  {
    id: 'reg-6',
    regulation: 'EMTALA',
    code: '42 U.S.C. § 1395dd',
    governingBody: 'CMS',
    description: 'Requires hospitals to provide emergency care regardless of ability to pay.',
    effectiveDate: 'August 1, 1986',
    penalties: 'Up to $50,000 per violation, Medicare termination for gross violations',
    applicability: 'Hospitals with emergency departments participating in Medicare',
    sourceUrl: 'https://www.cms.gov/Regulations-and-Guidance/Legislation/EMTALA'
  }
];

export const historicalRecords: HistoricalRecord[] = [
  {
    id: 'hist-1',
    referenceNumber: 'ENF-2024-0089',
    violationType: 'HIPAA Privacy Breach',
    governingBody: 'HHS OCR',
    penaltyAmount: 125000,
    resolution: 'Settlement with corrective action plan implemented',
    resolvedDate: '2024-08-15',
    lessonsLearned: 'Enhanced access controls and mandatory encryption for all mobile devices containing PHI. Implemented quarterly security awareness training.',
    impactLevel: 'High'
  },
  {
    id: 'hist-2',
    referenceNumber: 'ENF-2024-0056',
    violationType: 'Billing Code Error',
    governingBody: 'CMS',
    penaltyAmount: 45000,
    resolution: 'Voluntary refund and billing process overhaul',
    resolvedDate: '2024-06-22',
    lessonsLearned: 'Implemented automated coding validation system. Added secondary review for high-value claims before submission.',
    impactLevel: 'Medium'
  },
  {
    id: 'hist-3',
    referenceNumber: 'ENF-2023-0234',
    violationType: 'OSHA Safety Violation',
    governingBody: 'OSHA',
    penaltyAmount: 78500,
    resolution: 'Remediation completed, reinspection passed',
    resolvedDate: '2024-02-10',
    lessonsLearned: 'Updated PPE protocols and established monthly safety committee meetings. Created incident reporting mobile app for staff.',
    impactLevel: 'High'
  },
  {
    id: 'hist-4',
    referenceNumber: 'ENF-2023-0178',
    violationType: 'State Licensure Lapse',
    governingBody: 'State Health Department',
    penaltyAmount: 15000,
    resolution: 'License renewed, administrative penalty paid',
    resolvedDate: '2023-11-30',
    lessonsLearned: 'Implemented 90-day advance renewal tracking system. Assigned dedicated compliance coordinator for licensure management.',
    impactLevel: 'Low'
  },
  {
    id: 'hist-5',
    referenceNumber: 'ENF-2023-0145',
    violationType: 'Anti-Kickback Investigation',
    governingBody: 'OIG',
    penaltyAmount: 350000,
    resolution: 'Corporate Integrity Agreement signed, 5-year monitoring period',
    resolvedDate: '2023-09-18',
    lessonsLearned: 'Restructured all vendor relationships with legal review. Implemented annual fair market value assessments for all compensation arrangements.',
    impactLevel: 'Critical'
  }
];

export const categories = ['All', 'Privacy', 'Security', 'Billing', 'Fraud', 'Referral', 'Patient Care', 'Licensing', 'Safety'];

export const governingBodies = [
  'All',
  'HHS Office for Civil Rights',
  'CMS',
  'OIG',
  'DOJ',
  'OSHA',
  'State Health Department',
  'CMS / OIG'
];
