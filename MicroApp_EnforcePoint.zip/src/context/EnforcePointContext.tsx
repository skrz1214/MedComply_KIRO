import React, { createContext, useContext, useState, ReactNode } from 'react';
import {
  RegulatoryBody,
  EnforcementCase,
  EnforcementAction,
  CorrespondenceItem,
  Appeal,
  Finding,
  ResponsePackage,
  Deadline,
  AuditLogEntry,
  ActionType,
  Notification,
  DeadlineRule,
  CaseTypeConfig,
  FindingCategoryConfig,
  UserRole,
  CaseStatus,
  EnforcementStats,
  RemedyLibraryItem,
  DeadlineRuleLibraryItem,
  ResponseTemplateLibraryItem,
  EvidenceRequirementLibraryItem,
  FindingCategoryLibraryItem,
  LibraryConfig,
  CaseEvidenceRequirement,
  LibraryReference,
  AppliedLibrarySnapshot,
  LibraryItemType,
  LibraryApplyTarget,
} from '@/types/enforcepoint';
import {
  defaultRegulatoryBodies,
  defaultActionTypes,
  defaultCaseTypes,
  defaultFindingCategories,
  defaultDeadlineRules,
  mockEnforcementCases,
  mockDeadlines,
  mockEnforcementActions,
  mockCorrespondence,
  mockFindings,
  mockResponsePackages,
  mockAppeals,
  mockAuditLog,
  mockNotifications,
  defaultRemedyLibraryItems,
  defaultDeadlineRuleLibraryItems,
  defaultResponseTemplateLibraryItems,
  defaultEvidenceRequirementLibraryItems,
  defaultFindingCategoryLibraryItems,
  defaultLibraryConfig,
} from '@/data/enforcepointData';

interface EnforcePointContextType {
  // Current User (Mock)
  currentUser: { id: string; name: string; role: UserRole };
  
  // Regulatory Bodies
  regulatoryBodies: RegulatoryBody[];
  addRegulatoryBody: (body: Omit<RegulatoryBody, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateRegulatoryBody: (id: string, body: Partial<RegulatoryBody>) => void;
  deleteRegulatoryBody: (id: string) => void;
  
  // Enforcement Cases
  cases: EnforcementCase[];
  addCase: (caseData: Omit<EnforcementCase, 'id' | 'caseNumber' | 'createdAt' | 'updatedAt'>) => EnforcementCase;
  updateCase: (id: string, caseData: Partial<EnforcementCase>) => void;
  deleteCase: (id: string) => void;
  getCaseById: (id: string) => EnforcementCase | undefined;
  updateCaseStatus: (id: string, status: CaseStatus, justification?: string) => void;
  
  // Deadlines
  deadlines: Deadline[];
  addDeadline: (deadline: Omit<Deadline, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateDeadline: (id: string, deadline: Partial<Deadline>) => void;
  deleteDeadline: (id: string) => void;
  getDeadlinesByCase: (caseId: string) => Deadline[];
  
  // Enforcement Actions
  actions: EnforcementAction[];
  addAction: (action: Omit<EnforcementAction, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateAction: (id: string, action: Partial<EnforcementAction>) => void;
  deleteAction: (id: string) => void;
  getActionsByCase: (caseId: string) => EnforcementAction[];
  
  // Correspondence
  correspondence: CorrespondenceItem[];
  addCorrespondence: (item: Omit<CorrespondenceItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateCorrespondence: (id: string, item: Partial<CorrespondenceItem>) => void;
  deleteCorrespondence: (id: string) => void;
  getCorrespondenceByCase: (caseId: string) => CorrespondenceItem[];
  
  // Findings
  findings: Finding[];
  addFinding: (finding: Omit<Finding, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateFinding: (id: string, finding: Partial<Finding>) => void;
  deleteFinding: (id: string) => void;
  getFindingsByCase: (caseId: string) => Finding[];
  
  // Response Packages
  responsePackages: ResponsePackage[];
  addResponsePackage: (pkg: Omit<ResponsePackage, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateResponsePackage: (id: string, pkg: Partial<ResponsePackage>) => void;
  getResponsePackageByCase: (caseId: string) => ResponsePackage | undefined;
  
  // Appeals
  appeals: Appeal[];
  addAppeal: (appeal: Omit<Appeal, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateAppeal: (id: string, appeal: Partial<Appeal>) => void;
  deleteAppeal: (id: string) => void;
  getAppealsByCase: (caseId: string) => Appeal[];
  
  // Audit Log
  auditLog: AuditLogEntry[];
  addAuditEntry: (entry: Omit<AuditLogEntry, 'id' | 'performedAt'>) => void;
  getAuditLogByCase: (caseId: string) => AuditLogEntry[];
  
  // Notifications
  notifications: Notification[];
  markNotificationRead: (id: string) => void;
  
  // Configuration
  actionTypes: ActionType[];
  addActionType: (type: Omit<ActionType, 'id'>) => void;
  updateActionType: (id: string, type: Partial<ActionType>) => void;
  deleteActionType: (id: string) => void;
  caseTypes: CaseTypeConfig[];
  addCaseType: (type: Omit<CaseTypeConfig, 'id'>) => void;
  updateCaseType: (id: string, type: Partial<CaseTypeConfig>) => void;
  deleteCaseType: (id: string) => void;
  findingCategories: FindingCategoryConfig[];
  addFindingCategory: (category: Omit<FindingCategoryConfig, 'id'>) => void;
  updateFindingCategory: (id: string, category: Partial<FindingCategoryConfig>) => void;
  deleteFindingCategory: (id: string) => void;
  deadlineRules: DeadlineRule[];
  addDeadlineRule: (rule: Omit<DeadlineRule, 'id'>) => void;
  updateDeadlineRule: (id: string, rule: Partial<DeadlineRule>) => void;
  deleteDeadlineRule: (id: string) => void;
  
  // Library
  libraryConfig: LibraryConfig;
  remedyLibraryItems: RemedyLibraryItem[];
  addRemedyLibraryItem: (item: Omit<RemedyLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateRemedyLibraryItem: (id: string, item: Partial<RemedyLibraryItem>) => void;
  deleteRemedyLibraryItem: (id: string) => void;
  
  deadlineRuleLibraryItems: DeadlineRuleLibraryItem[];
  addDeadlineRuleLibraryItem: (item: Omit<DeadlineRuleLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateDeadlineRuleLibraryItem: (id: string, item: Partial<DeadlineRuleLibraryItem>) => void;
  deleteDeadlineRuleLibraryItem: (id: string) => void;
  
  responseTemplateLibraryItems: ResponseTemplateLibraryItem[];
  addResponseTemplateLibraryItem: (item: Omit<ResponseTemplateLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateResponseTemplateLibraryItem: (id: string, item: Partial<ResponseTemplateLibraryItem>) => void;
  deleteResponseTemplateLibraryItem: (id: string) => void;
  
  evidenceRequirementLibraryItems: EvidenceRequirementLibraryItem[];
  addEvidenceRequirementLibraryItem: (item: Omit<EvidenceRequirementLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateEvidenceRequirementLibraryItem: (id: string, item: Partial<EvidenceRequirementLibraryItem>) => void;
  deleteEvidenceRequirementLibraryItem: (id: string) => void;
  
  findingCategoryLibraryItems: FindingCategoryLibraryItem[];
  addFindingCategoryLibraryItem: (item: Omit<FindingCategoryLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateFindingCategoryLibraryItem: (id: string, item: Partial<FindingCategoryLibraryItem>) => void;
  deleteFindingCategoryLibraryItem: (id: string) => void;
  
  // Case Evidence Requirements
  caseEvidenceRequirements: CaseEvidenceRequirement[];
  addCaseEvidenceRequirement: (req: Omit<CaseEvidenceRequirement, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateCaseEvidenceRequirement: (id: string, req: Partial<CaseEvidenceRequirement>) => void;
  getCaseEvidenceRequirements: (caseId: string) => CaseEvidenceRequirement[];
  
  // Library Helper Functions
  applyRemedyFromLibrary: (caseId: string, remedyLibraryItemId: string, overrides?: Partial<EnforcementAction>) => void;
  generateDeadlinesFromLibrary: (caseId: string, baseDate: Date) => void;
  
  // Library Reference & Snapshot Functions
  addLibraryReference: (caseId: string, reference: Omit<LibraryReference, 'referencedAt'>) => void;
  applyLibrarySnapshot: (caseId: string, snapshot: Omit<AppliedLibrarySnapshot, 'appliedAt'>) => void;
  
  // Stats
  getStats: () => EnforcementStats;
}

const EnforcePointContext = createContext<EnforcePointContextType | undefined>(undefined);

export const EnforcePointProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Mock current user
  const [currentUser] = useState({ id: 'user-001', name: 'Patricia Williams', role: 'Compliance Head' as UserRole });
  
  // State
  const [regulatoryBodies, setRegulatoryBodies] = useState<RegulatoryBody[]>(defaultRegulatoryBodies);
  const [cases, setCases] = useState<EnforcementCase[]>(mockEnforcementCases);
  const [deadlines, setDeadlines] = useState<Deadline[]>(mockDeadlines);
  const [actions, setActions] = useState<EnforcementAction[]>(mockEnforcementActions);
  const [correspondence, setCorrespondence] = useState<CorrespondenceItem[]>(mockCorrespondence);
  const [findings, setFindings] = useState<Finding[]>(mockFindings);
  const [responsePackages, setResponsePackages] = useState<ResponsePackage[]>(mockResponsePackages);
  const [appeals, setAppeals] = useState<Appeal[]>(mockAppeals);
  const [auditLog, setAuditLog] = useState<AuditLogEntry[]>(mockAuditLog);
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);
  const [actionTypes, setActionTypes] = useState<ActionType[]>(defaultActionTypes);
  const [caseTypes, setCaseTypes] = useState<CaseTypeConfig[]>(defaultCaseTypes);
  const [findingCategories, setFindingCategories] = useState<FindingCategoryConfig[]>(defaultFindingCategories);
  const [deadlineRules, setDeadlineRules] = useState<DeadlineRule[]>(defaultDeadlineRules);
  
  // Library State
  const [libraryConfig] = useState<LibraryConfig>(defaultLibraryConfig);
  const [remedyLibraryItems, setRemedyLibraryItems] = useState<RemedyLibraryItem[]>(defaultRemedyLibraryItems);
  const [deadlineRuleLibraryItems, setDeadlineRuleLibraryItems] = useState<DeadlineRuleLibraryItem[]>(defaultDeadlineRuleLibraryItems);
  const [responseTemplateLibraryItems, setResponseTemplateLibraryItems] = useState<ResponseTemplateLibraryItem[]>(defaultResponseTemplateLibraryItems);
  const [evidenceRequirementLibraryItems, setEvidenceRequirementLibraryItems] = useState<EvidenceRequirementLibraryItem[]>(defaultEvidenceRequirementLibraryItems);
  const [findingCategoryLibraryItems, setFindingCategoryLibraryItems] = useState<FindingCategoryLibraryItem[]>(defaultFindingCategoryLibraryItems);
  const [caseEvidenceRequirements, setCaseEvidenceRequirements] = useState<CaseEvidenceRequirement[]>([]);

  // Generate unique IDs
  const generateId = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  const generateCaseNumber = () => `ENF-${new Date().getFullYear()}-${String(cases.length + 1).padStart(3, '0')}`;

  // Regulatory Bodies CRUD
  const addRegulatoryBody = (body: Omit<RegulatoryBody, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newBody: RegulatoryBody = {
      ...body,
      id: generateId('rb'),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setRegulatoryBodies(prev => [...prev, newBody]);
  };

  const updateRegulatoryBody = (id: string, body: Partial<RegulatoryBody>) => {
    setRegulatoryBodies(prev => prev.map(b => b.id === id ? { ...b, ...body, updatedAt: new Date() } : b));
  };

  const deleteRegulatoryBody = (id: string) => {
    setRegulatoryBodies(prev => prev.filter(b => b.id !== id));
  };

  // Cases CRUD
  const addCase = (caseData: Omit<EnforcementCase, 'id' | 'caseNumber' | 'createdAt' | 'updatedAt'>): EnforcementCase => {
    const newCase: EnforcementCase = {
      ...caseData,
      id: generateId('case'),
      caseNumber: generateCaseNumber(),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setCases(prev => [...prev, newCase]);
    addAuditEntry({
      caseId: newCase.id,
      action: 'Created',
      description: `Case ${newCase.caseNumber} created`,
      performedBy: currentUser.name,
      performedByRole: currentUser.role,
    });
    return newCase;
  };

  const updateCase = (id: string, caseData: Partial<EnforcementCase>) => {
    setCases(prev => prev.map(c => c.id === id ? { ...c, ...caseData, updatedAt: new Date() } : c));
  };

  const deleteCase = (id: string) => {
    setCases(prev => prev.filter(c => c.id !== id));
  };

  const getCaseById = (id: string) => cases.find(c => c.id === id);

  const updateCaseStatus = (id: string, status: CaseStatus, justification?: string) => {
    const currentCase = getCaseById(id);
    if (currentCase) {
      updateCase(id, { status });
      addAuditEntry({
        caseId: id,
        action: 'Status Changed',
        description: `Status changed from ${currentCase.status} to ${status}`,
        previousValue: currentCase.status,
        newValue: status,
        performedBy: currentUser.name,
        performedByRole: currentUser.role,
        justification,
      });
    }
  };

  // Deadlines CRUD
  const addDeadline = (deadline: Omit<Deadline, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newDeadline: Deadline = {
      ...deadline,
      id: generateId('dl'),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setDeadlines(prev => [...prev, newDeadline]);
  };

  const updateDeadline = (id: string, deadline: Partial<Deadline>) => {
    setDeadlines(prev => prev.map(d => d.id === id ? { ...d, ...deadline, updatedAt: new Date() } : d));
  };

  const deleteDeadline = (id: string) => {
    setDeadlines(prev => prev.filter(d => d.id !== id));
  };

  const getDeadlinesByCase = (caseId: string) => deadlines.filter(d => d.caseId === caseId);

  // Actions CRUD
  const addAction = (action: Omit<EnforcementAction, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newAction: EnforcementAction = {
      ...action,
      id: generateId('action'),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setActions(prev => [...prev, newAction]);
  };

  const updateAction = (id: string, action: Partial<EnforcementAction>) => {
    setActions(prev => prev.map(a => a.id === id ? { ...a, ...action, updatedAt: new Date() } : a));
  };

  const deleteAction = (id: string) => {
    setActions(prev => prev.filter(a => a.id !== id));
  };

  const getActionsByCase = (caseId: string) => actions.filter(a => a.caseId === caseId);

  // Correspondence CRUD
  const addCorrespondence = (item: Omit<CorrespondenceItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newItem: CorrespondenceItem = {
      ...item,
      id: generateId('corr'),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setCorrespondence(prev => [...prev, newItem]);
  };

  const updateCorrespondence = (id: string, item: Partial<CorrespondenceItem>) => {
    setCorrespondence(prev => prev.map(c => c.id === id ? { ...c, ...item, updatedAt: new Date() } : c));
  };

  const deleteCorrespondence = (id: string) => {
    setCorrespondence(prev => prev.filter(c => c.id !== id));
  };

  const getCorrespondenceByCase = (caseId: string) => correspondence.filter(c => c.caseId === caseId);

  // Findings CRUD
  const addFinding = (finding: Omit<Finding, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newFinding: Finding = {
      ...finding,
      id: generateId('finding'),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setFindings(prev => [...prev, newFinding]);
  };

  const updateFinding = (id: string, finding: Partial<Finding>) => {
    setFindings(prev => prev.map(f => f.id === id ? { ...f, ...finding, updatedAt: new Date() } : f));
  };

  const deleteFinding = (id: string) => {
    setFindings(prev => prev.filter(f => f.id !== id));
  };

  const getFindingsByCase = (caseId: string) => findings.filter(f => f.caseId === caseId);

  // Response Packages
  const addResponsePackage = (pkg: Omit<ResponsePackage, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newPkg: ResponsePackage = {
      ...pkg,
      id: generateId('resp'),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setResponsePackages(prev => [...prev, newPkg]);
  };

  const updateResponsePackage = (id: string, pkg: Partial<ResponsePackage>) => {
    setResponsePackages(prev => prev.map(p => p.id === id ? { ...p, ...pkg, updatedAt: new Date() } : p));
  };

  const getResponsePackageByCase = (caseId: string) => responsePackages.find(p => p.caseId === caseId);

  // Appeals CRUD
  const addAppeal = (appeal: Omit<Appeal, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newAppeal: Appeal = {
      ...appeal,
      id: generateId('appeal'),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setAppeals(prev => [...prev, newAppeal]);
  };

  const updateAppeal = (id: string, appeal: Partial<Appeal>) => {
    setAppeals(prev => prev.map(a => a.id === id ? { ...a, ...appeal, updatedAt: new Date() } : a));
  };

  const deleteAppeal = (id: string) => {
    setAppeals(prev => prev.filter(a => a.id !== id));
  };

  const getAppealsByCase = (caseId: string) => appeals.filter(a => a.caseId === caseId);

  // Audit Log
  const addAuditEntry = (entry: Omit<AuditLogEntry, 'id' | 'performedAt'>) => {
    const newEntry: AuditLogEntry = {
      ...entry,
      id: generateId('audit'),
      performedAt: new Date(),
    };
    setAuditLog(prev => [newEntry, ...prev]);
  };

  const getAuditLogByCase = (caseId: string) => auditLog.filter(e => e.caseId === caseId);

  // Notifications
  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  // Action Types
  const addActionType = (type: Omit<ActionType, 'id'>) => {
    const newType: ActionType = { ...type, id: generateId('at') };
    setActionTypes(prev => [...prev, newType]);
  };

  const updateActionType = (id: string, type: Partial<ActionType>) => {
    setActionTypes(prev => prev.map(t => t.id === id ? { ...t, ...type } : t));
  };

  const deleteActionType = (id: string) => {
    setActionTypes(prev => prev.filter(t => t.id !== id));
  };

  // Case Types
  const addCaseType = (type: Omit<CaseTypeConfig, 'id'>) => {
    const newType: CaseTypeConfig = { ...type, id: generateId('ct') };
    setCaseTypes(prev => [...prev, newType]);
  };

  const updateCaseType = (id: string, type: Partial<CaseTypeConfig>) => {
    setCaseTypes(prev => prev.map(t => t.id === id ? { ...t, ...type } : t));
  };

  const deleteCaseType = (id: string) => {
    setCaseTypes(prev => prev.filter(t => t.id !== id));
  };

  // Finding Categories
  const addFindingCategory = (category: Omit<FindingCategoryConfig, 'id'>) => {
    const newCategory: FindingCategoryConfig = { ...category, id: generateId('fc') };
    setFindingCategories(prev => [...prev, newCategory]);
  };

  const updateFindingCategory = (id: string, category: Partial<FindingCategoryConfig>) => {
    setFindingCategories(prev => prev.map(c => c.id === id ? { ...c, ...category } : c));
  };

  const deleteFindingCategory = (id: string) => {
    setFindingCategories(prev => prev.filter(c => c.id !== id));
  };

  // Deadline Rules
  const addDeadlineRule = (rule: Omit<DeadlineRule, 'id'>) => {
    const newRule: DeadlineRule = { ...rule, id: generateId('dr') };
    setDeadlineRules(prev => [...prev, newRule]);
  };

  const updateDeadlineRule = (id: string, rule: Partial<DeadlineRule>) => {
    setDeadlineRules(prev => prev.map(r => r.id === id ? { ...r, ...rule } : r));
  };

  const deleteDeadlineRule = (id: string) => {
    setDeadlineRules(prev => prev.filter(r => r.id !== id));
  };

  // Stats
  const getStats = (): EnforcementStats => {
    const openStatuses: CaseStatus[] = ['Draft', 'Notice Received', 'Triage & Assignment', 'Response Planning', 'Remediation Linked', 'Response In Progress', 'Submitted / Awaiting Determination', 'Remedies Active', 'Verification / Revisit', 'Reopened'];
    const openCases = cases.filter(c => openStatuses.includes(c.status));
    
    const today = new Date();
    const upcomingDeadlines = deadlines.filter(d => !d.isCompleted && new Date(d.dueDate) >= today);
    const overdueDeadlines = deadlines.filter(d => !d.isCompleted && new Date(d.dueDate) < today);
    const activeRemedies = actions.filter(a => a.status === 'Active' || a.status === 'Imposed');
    const totalPenalty = actions.filter(a => a.amount).reduce((sum, a) => sum + (a.amount || 0), 0);

    return {
      totalOpenCases: openCases.length,
      casesBySeverity: {
        Low: openCases.filter(c => c.severity === 'Low').length,
        Medium: openCases.filter(c => c.severity === 'Medium').length,
        High: openCases.filter(c => c.severity === 'High').length,
        Critical: openCases.filter(c => c.severity === 'Critical').length,
      },
      casesByStatus: cases.reduce((acc, c) => {
        acc[c.status] = (acc[c.status] || 0) + 1;
        return acc;
      }, {} as Record<CaseStatus, number>),
      upcomingDeadlines: upcomingDeadlines.length,
      overdueDeadlines: overdueDeadlines.length,
      activeRemedies: activeRemedies.length,
      totalPenaltyAmount: totalPenalty,
    };
  };

  // ============= Library CRUD Operations =============
  
  // Remedy Library
  const addRemedyLibraryItem = (item: Omit<RemedyLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newItem: RemedyLibraryItem = {
      ...item,
      id: generateId('remedy-lib'),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setRemedyLibraryItems(prev => [...prev, newItem]);
  };

  const updateRemedyLibraryItem = (id: string, item: Partial<RemedyLibraryItem>) => {
    setRemedyLibraryItems(prev => prev.map(i => i.id === id ? { ...i, ...item, updatedAt: new Date() } : i));
  };

  const deleteRemedyLibraryItem = (id: string) => {
    setRemedyLibraryItems(prev => prev.filter(i => i.id !== id));
  };

  // Deadline Rule Library
  const addDeadlineRuleLibraryItem = (item: Omit<DeadlineRuleLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newItem: DeadlineRuleLibraryItem = {
      ...item,
      id: generateId('dlr-lib'),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setDeadlineRuleLibraryItems(prev => [...prev, newItem]);
  };

  const updateDeadlineRuleLibraryItem = (id: string, item: Partial<DeadlineRuleLibraryItem>) => {
    setDeadlineRuleLibraryItems(prev => prev.map(i => i.id === id ? { ...i, ...item, updatedAt: new Date() } : i));
  };

  const deleteDeadlineRuleLibraryItem = (id: string) => {
    setDeadlineRuleLibraryItems(prev => prev.filter(i => i.id !== id));
  };

  // Response Template Library
  const addResponseTemplateLibraryItem = (item: Omit<ResponseTemplateLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newItem: ResponseTemplateLibraryItem = {
      ...item,
      id: generateId('tpl-lib'),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setResponseTemplateLibraryItems(prev => [...prev, newItem]);
  };

  const updateResponseTemplateLibraryItem = (id: string, item: Partial<ResponseTemplateLibraryItem>) => {
    setResponseTemplateLibraryItems(prev => prev.map(i => i.id === id ? { ...i, ...item, updatedAt: new Date() } : i));
  };

  const deleteResponseTemplateLibraryItem = (id: string) => {
    setResponseTemplateLibraryItems(prev => prev.filter(i => i.id !== id));
  };

  // Evidence Requirement Library
  const addEvidenceRequirementLibraryItem = (item: Omit<EvidenceRequirementLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newItem: EvidenceRequirementLibraryItem = {
      ...item,
      id: generateId('evreq-lib'),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setEvidenceRequirementLibraryItems(prev => [...prev, newItem]);
  };

  const updateEvidenceRequirementLibraryItem = (id: string, item: Partial<EvidenceRequirementLibraryItem>) => {
    setEvidenceRequirementLibraryItems(prev => prev.map(i => i.id === id ? { ...i, ...item, updatedAt: new Date() } : i));
  };

  const deleteEvidenceRequirementLibraryItem = (id: string) => {
    setEvidenceRequirementLibraryItems(prev => prev.filter(i => i.id !== id));
  };

  // Finding Category Library
  const addFindingCategoryLibraryItem = (item: Omit<FindingCategoryLibraryItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newItem: FindingCategoryLibraryItem = {
      ...item,
      id: generateId('fcat-lib'),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setFindingCategoryLibraryItems(prev => [...prev, newItem]);
  };

  const updateFindingCategoryLibraryItem = (id: string, item: Partial<FindingCategoryLibraryItem>) => {
    setFindingCategoryLibraryItems(prev => prev.map(i => i.id === id ? { ...i, ...item, updatedAt: new Date() } : i));
  };

  const deleteFindingCategoryLibraryItem = (id: string) => {
    setFindingCategoryLibraryItems(prev => prev.filter(i => i.id !== id));
  };

  // Case Evidence Requirements
  const addCaseEvidenceRequirement = (req: Omit<CaseEvidenceRequirement, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newReq: CaseEvidenceRequirement = {
      ...req,
      id: generateId('cevreq'),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setCaseEvidenceRequirements(prev => [...prev, newReq]);
  };

  const updateCaseEvidenceRequirement = (id: string, req: Partial<CaseEvidenceRequirement>) => {
    setCaseEvidenceRequirements(prev => prev.map(r => r.id === id ? { ...r, ...req, updatedAt: new Date() } : r));
  };

  const getCaseEvidenceRequirements = (caseId: string) => caseEvidenceRequirements.filter(r => r.caseId === caseId);

  // Apply Remedy from Library
  const applyRemedyFromLibrary = (caseId: string, remedyLibraryItemId: string, overrides?: Partial<EnforcementAction>) => {
    const libraryItem = remedyLibraryItems.find(r => r.id === remedyLibraryItemId);
    if (!libraryItem) return;

    // Find matching action type
    const matchingActionType = actionTypes.find(at => 
      at.name.toLowerCase().includes(libraryItem.name.toLowerCase().split('(')[0].trim())
    ) || actionTypes[0];

    const newAction: EnforcementAction = {
      id: generateId('action'),
      caseId,
      actionCategory: libraryItem.isFinancial ? 'Financial Penalty' : 'Operational Remedy',
      actionTypeId: matchingActionType?.id || '',
      actionTypeName: libraryItem.name,
      status: 'Proposed',
      conditionsRequirements: libraryItem.typicalRequiredSubmissions || '',
      requirementChecklist: libraryItem.operationalRequirements.map(or => ({
        id: or.id,
        label: or.label,
        isCompleted: false,
      })),
      linkedCapaIds: [],
      linkedIssueIds: [],
      evidenceFiles: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      ...overrides,
    };

    setActions(prev => [...prev, newAction]);

    // Add evidence requirements from library item
    libraryItem.evidenceExpectations.forEach(ee => {
      addCaseEvidenceRequirement({
        caseId,
        evidenceType: ee.evidenceType,
        description: ee.description,
        isRequired: ee.isRequired,
        status: 'Missing',
        sourceLibraryItemId: remedyLibraryItemId,
        sourceType: 'remedy',
        notes: ee.notes,
      });
    });

    addAuditEntry({
      caseId,
      action: 'Action Added',
      description: `Added ${libraryItem.name} from library`,
      performedBy: currentUser.name,
      performedByRole: currentUser.role,
    });
  };

  // Generate Deadlines from Library
  const generateDeadlinesFromLibrary = (caseId: string, baseDate: Date) => {
    const enforcementCase = getCaseById(caseId);
    if (!enforcementCase) return;

    const applicableRules = deadlineRuleLibraryItems.filter(rule => {
      if (rule.status !== 'Published') return false;
      if (rule.regulatoryBodyId && rule.regulatoryBodyId !== enforcementCase.regulatoryBodyId) return false;
      if (rule.caseType && rule.caseType !== enforcementCase.caseType) return false;
      return true;
    });

    applicableRules.forEach(rule => {
      const dueDate = new Date(baseDate);
      dueDate.setDate(dueDate.getDate() + rule.defaultDueInDays);

      addDeadline({
        caseId,
        title: rule.name,
        description: `Generated from library rule: ${rule.name}`,
        dueDate,
        type: rule.deadlineType === 'Response Due' ? 'Response' : 
              rule.deadlineType === 'PoC Due' ? 'PoC' : 
              rule.deadlineType === 'Appeal Due' ? 'Appeal Filing' : 
              rule.deadlineType === 'Payment Due' ? 'Payment' : 
              rule.deadlineType === 'Revisit' ? 'Revisit' : 'Other',
        isCompleted: false,
        reminderDays: rule.warningThresholds,
        escalationRecipients: rule.escalationRoles,
      });
    });

    addAuditEntry({
      caseId,
      action: 'Deadline Added',
      description: `Generated ${applicableRules.length} deadline(s) from library rules`,
      performedBy: currentUser.name,
      performedByRole: currentUser.role,
    });
  };

  // Add Library Reference (link only)
  const addLibraryReference = (caseId: string, reference: Omit<LibraryReference, 'referencedAt'>) => {
    const enforcementCase = getCaseById(caseId);
    if (!enforcementCase) return;

    const newReference: LibraryReference = {
      ...reference,
      referencedAt: new Date(),
    };

    const updatedReferences = [...(enforcementCase.libraryReferences || []), newReference];
    updateCase(caseId, { libraryReferences: updatedReferences });

    addAuditEntry({
      caseId,
      action: 'Library Reference Added',
      description: `Added library reference: ${reference.libraryItemType} (${reference.libraryItemId})`,
      performedBy: currentUser.name,
      performedByRole: currentUser.role,
    });
  };

  // Apply Library Snapshot (copy data into case)
  const applyLibrarySnapshot = (caseId: string, snapshot: Omit<AppliedLibrarySnapshot, 'appliedAt'>) => {
    const enforcementCase = getCaseById(caseId);
    if (!enforcementCase) return;

    // Check if case is closed - don't allow apply in closed state
    if (enforcementCase.caseStatus === 'O7_Closed') {
      console.warn('Cannot apply library items to closed cases. Reopen case first.');
      return;
    }

    const newSnapshot: AppliedLibrarySnapshot = {
      ...snapshot,
      appliedAt: new Date(),
    };

    const updatedSnapshots = [...(enforcementCase.appliedLibrarySnapshots || []), newSnapshot];
    updateCase(caseId, { appliedLibrarySnapshots: updatedSnapshots });

    addAuditEntry({
      caseId,
      action: 'Library Item Applied',
      description: `Applied library item: ${snapshot.libraryItemType} to ${snapshot.appliedToTarget}`,
      performedBy: currentUser.name,
      performedByRole: currentUser.role,
    });
  };

  return (
    <EnforcePointContext.Provider
      value={{
        currentUser,
        regulatoryBodies,
        addRegulatoryBody,
        updateRegulatoryBody,
        deleteRegulatoryBody,
        cases,
        addCase,
        updateCase,
        deleteCase,
        getCaseById,
        updateCaseStatus,
        deadlines,
        addDeadline,
        updateDeadline,
        deleteDeadline,
        getDeadlinesByCase,
        actions,
        addAction,
        updateAction,
        deleteAction,
        getActionsByCase,
        correspondence,
        addCorrespondence,
        updateCorrespondence,
        deleteCorrespondence,
        getCorrespondenceByCase,
        findings,
        addFinding,
        updateFinding,
        deleteFinding,
        getFindingsByCase,
        responsePackages,
        addResponsePackage,
        updateResponsePackage,
        getResponsePackageByCase,
        appeals,
        addAppeal,
        updateAppeal,
        deleteAppeal,
        getAppealsByCase,
        auditLog,
        addAuditEntry,
        getAuditLogByCase,
        notifications,
        markNotificationRead,
        actionTypes,
        addActionType,
        updateActionType,
        deleteActionType,
        caseTypes,
        addCaseType,
        updateCaseType,
        deleteCaseType,
        findingCategories,
        addFindingCategory,
        updateFindingCategory,
        deleteFindingCategory,
        deadlineRules,
        addDeadlineRule,
        updateDeadlineRule,
        deleteDeadlineRule,
        // Library
        libraryConfig,
        remedyLibraryItems,
        addRemedyLibraryItem,
        updateRemedyLibraryItem,
        deleteRemedyLibraryItem,
        deadlineRuleLibraryItems,
        addDeadlineRuleLibraryItem,
        updateDeadlineRuleLibraryItem,
        deleteDeadlineRuleLibraryItem,
        responseTemplateLibraryItems,
        addResponseTemplateLibraryItem,
        updateResponseTemplateLibraryItem,
        deleteResponseTemplateLibraryItem,
        evidenceRequirementLibraryItems,
        addEvidenceRequirementLibraryItem,
        updateEvidenceRequirementLibraryItem,
        deleteEvidenceRequirementLibraryItem,
        findingCategoryLibraryItems,
        addFindingCategoryLibraryItem,
        updateFindingCategoryLibraryItem,
        deleteFindingCategoryLibraryItem,
        caseEvidenceRequirements,
        addCaseEvidenceRequirement,
        updateCaseEvidenceRequirement,
        getCaseEvidenceRequirements,
        applyRemedyFromLibrary,
        generateDeadlinesFromLibrary,
        addLibraryReference,
        applyLibrarySnapshot,
        getStats,
      }}
    >
      {children}
    </EnforcePointContext.Provider>
  );
};

export const useEnforcePoint = () => {
  const context = useContext(EnforcePointContext);
  if (!context) {
    throw new Error('useEnforcePoint must be used within an EnforcePointProvider');
  }
  return context;
};
