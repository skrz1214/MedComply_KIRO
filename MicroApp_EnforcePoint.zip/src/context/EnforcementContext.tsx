import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Enforcement, TodoItem } from '@/types/enforcement';
import { mockEnforcements, mockTodoItems } from '@/data/mockData';

interface EnforcementContextType {
  enforcements: Enforcement[];
  todoItems: TodoItem[];
  addEnforcement: (enforcement: Omit<Enforcement, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateEnforcement: (id: string, enforcement: Partial<Enforcement>) => void;
  deleteEnforcement: (id: string) => void;
  getEnforcementById: (id: string) => Enforcement | undefined;
  processTodoItem: (todoId: string, enforcementId: string) => void;
  getTodoById: (id: string) => TodoItem | undefined;
}

const EnforcementContext = createContext<EnforcementContextType | undefined>(undefined);

export function EnforcementProvider({ children }: { children: ReactNode }) {
  const [enforcements, setEnforcements] = useState<Enforcement[]>(mockEnforcements);
  const [todoItems, setTodoItems] = useState<TodoItem[]>(mockTodoItems);

  const addEnforcement = (enforcement: Omit<Enforcement, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newEnforcement: Enforcement = {
      ...enforcement,
      id: `enf-${Date.now()}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setEnforcements(prev => [newEnforcement, ...prev]);
  };

  const updateEnforcement = (id: string, updates: Partial<Enforcement>) => {
    setEnforcements(prev =>
      prev.map(enf =>
        enf.id === id
          ? { ...enf, ...updates, updatedAt: new Date() }
          : enf
      )
    );
  };

  const deleteEnforcement = (id: string) => {
    setEnforcements(prev =>
      prev.map(enf =>
        enf.id === id
          ? { ...enf, status: 'Deleted' as const, updatedAt: new Date() }
          : enf
      )
    );
  };

  const getEnforcementById = (id: string) => {
    return enforcements.find(enf => enf.id === id);
  };

  const processTodoItem = (todoId: string, enforcementId: string) => {
    setTodoItems(prev =>
      prev.map(todo =>
        todo.id === todoId
          ? { ...todo, isProcessed: true, enforcementId }
          : todo
      )
    );
  };

  const getTodoById = (id: string) => {
    return todoItems.find(todo => todo.id === id);
  };

  return (
    <EnforcementContext.Provider
      value={{
        enforcements,
        todoItems,
        addEnforcement,
        updateEnforcement,
        deleteEnforcement,
        getEnforcementById,
        processTodoItem,
        getTodoById,
      }}
    >
      {children}
    </EnforcementContext.Provider>
  );
}

export function useEnforcement() {
  const context = useContext(EnforcementContext);
  if (context === undefined) {
    throw new Error('useEnforcement must be used within an EnforcementProvider');
  }
  return context;
}
