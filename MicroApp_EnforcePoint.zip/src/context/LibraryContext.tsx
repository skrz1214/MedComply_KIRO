import { createContext, useContext, useState, ReactNode } from 'react';
import { EnforcementTemplate, enforcementTemplates as initialTemplates } from '@/data/libraryData';

interface LibraryContextType {
  templates: EnforcementTemplate[];
  addTemplate: (template: Omit<EnforcementTemplate, 'id'>) => void;
  updateTemplate: (id: string, template: Partial<EnforcementTemplate>) => void;
  deleteTemplate: (id: string) => void;
}

const LibraryContext = createContext<LibraryContextType | undefined>(undefined);

export function LibraryProvider({ children }: { children: ReactNode }) {
  const [templates, setTemplates] = useState<EnforcementTemplate[]>(initialTemplates);

  const addTemplate = (template: Omit<EnforcementTemplate, 'id'>) => {
    const newTemplate: EnforcementTemplate = {
      ...template,
      id: `template-${Date.now()}`,
    };
    setTemplates((prev) => [...prev, newTemplate]);
  };

  const updateTemplate = (id: string, updates: Partial<EnforcementTemplate>) => {
    setTemplates((prev) =>
      prev.map((t) => (t.id === id ? { ...t, ...updates } : t))
    );
  };

  const deleteTemplate = (id: string) => {
    setTemplates((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <LibraryContext.Provider value={{ templates, addTemplate, updateTemplate, deleteTemplate }}>
      {children}
    </LibraryContext.Provider>
  );
}

export function useLibrary() {
  const context = useContext(LibraryContext);
  if (!context) {
    throw new Error('useLibrary must be used within a LibraryProvider');
  }
  return context;
}
