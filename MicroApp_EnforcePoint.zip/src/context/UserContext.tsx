import React, { createContext, useContext, useState, ReactNode } from "react";

export type UserRole = "admin" | "compliance_head" | "department_head" | "staff";

export type ViewMode = "organization" | "department" | "individual";

export interface MockUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
  avatar?: string;
}

export const mockUsers: MockUser[] = [
  { id: "1", name: "Sarah Mitchell", email: "sarah.mitchell@medcomply.com", role: "admin", department: "Administration" },
  { id: "2", name: "Dr. James Chen", email: "james.chen@medcomply.com", role: "compliance_head", department: "Compliance" },
  { id: "3", name: "Maria Rodriguez", email: "maria.rodriguez@medcomply.com", role: "department_head", department: "Nursing" },
  { id: "4", name: "Robert Williams", email: "robert.williams@medcomply.com", role: "department_head", department: "Radiology" },
  { id: "5", name: "Emily Davis", email: "emily.davis@medcomply.com", role: "staff", department: "Nursing" },
  { id: "6", name: "Michael Johnson", email: "michael.johnson@medcomply.com", role: "staff", department: "Radiology" },
  { id: "7", name: "Jennifer Lee", email: "jennifer.lee@medcomply.com", role: "staff", department: "Compliance" },
];

export const departments = ["Administration", "Compliance", "Nursing", "Radiology", "Laboratory", "Pharmacy"];

interface UserContextType {
  currentUser: MockUser;
  setCurrentUser: (user: MockUser) => void;
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  selectedDepartment: string | null;
  setSelectedDepartment: (dept: string | null) => void;
  selectedUserId: string | null;
  setSelectedUserId: (userId: string | null) => void;
  canToggleOrgView: boolean;
  canToggleDeptView: boolean;
  getAvailableViewModes: () => ViewMode[];
  getRoleLabel: (role: UserRole) => string;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<MockUser>(mockUsers[0]); // Default to Admin
  const [viewMode, setViewMode] = useState<ViewMode>("organization");
  const [selectedDepartment, setSelectedDepartment] = useState<string | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);

  const canToggleOrgView = currentUser.role === "admin" || currentUser.role === "compliance_head";
  const canToggleDeptView = currentUser.role === "department_head";

  const getAvailableViewModes = (): ViewMode[] => {
    if (currentUser.role === "admin" || currentUser.role === "compliance_head") {
      return ["organization", "individual"];
    }
    if (currentUser.role === "department_head") {
      return ["department", "individual"];
    }
    return ["individual"];
  };

  const getRoleLabel = (role: UserRole): string => {
    switch (role) {
      case "admin": return "Admin";
      case "compliance_head": return "Compliance Head";
      case "department_head": return "Department Head";
      case "staff": return "Staff";
      default: return role;
    }
  };

  // Reset view mode when user changes
  const handleSetCurrentUser = (user: MockUser) => {
    setCurrentUser(user);
    if (user.role === "admin" || user.role === "compliance_head") {
      setViewMode("organization");
      setSelectedDepartment(null);
    } else if (user.role === "department_head") {
      setViewMode("department");
      setSelectedDepartment(user.department);
    } else {
      setViewMode("individual");
      setSelectedUserId(user.id);
    }
  };

  return (
    <UserContext.Provider
      value={{
        currentUser,
        setCurrentUser: handleSetCurrentUser,
        viewMode,
        setViewMode,
        selectedDepartment,
        setSelectedDepartment,
        selectedUserId,
        setSelectedUserId,
        canToggleOrgView,
        canToggleDeptView,
        getAvailableViewModes,
        getRoleLabel,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = (): UserContextType => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
};
