export type Status = 'completed' | 'pending' | 'overdue' | 'active' | 'draft' | 'in-progress' | 'pending-review' | 'under-review' | 'approved' | 'flagged' | 'archived' | 'not-started';
export type Priority = 'high' | 'medium' | 'low';
export type RiskLevel = 'high' | 'medium' | 'low';

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  department: string;
  email: string;
  avatar?: string;
  reportsTo?: string;
}

export interface Policy {
  id: string;
  name: string;
  category: string;
  lastUpdated: string;
  status: Status;
  nextUpdate: string;
  owner: string;
}

export interface AuditItem {
  id: string;
  title: string;
  status: Status;
  deadline: string;
  owner: string;
  priority: Priority;
}

export interface Enforcement {
  id: string;
  title: string;
  status: Status;
  dueDate: string;
  owner: string;
  priority: Priority;
}

export interface RiskItem {
  id: string;
  description: string;
  level: RiskLevel;
  status: Status;
  owner: string;
  mitigationStrategy?: string;
}

export interface ComplianceItem {
  id: string;
  description: string;
  status: Status;
  owner: string;
  category: string;
}

export interface DigitalContent {
  id: string;
  name: string;
  type: 'ad' | 'video' | 'campaign' | 'social';
  status: Status;
  platform: string;
  lastReviewed: string;
  owner: string;
}

export interface PrintMarketing {
  id: string;
  name: string;
  type: string;
  status: Status;
  distributionDate: string;
  approvedBy?: string;
  archived: boolean;
}

export interface MetricCard {
  label: string;
  value: number;
  status?: Status;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
}

export interface MicroApp {
  id: string;
  name: string;
  description: string;
  icon: string;
  route: string;
  color: string;
}
