import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { DataTable } from '@/components/dashboard/DataTable';
import { StatusBadge, PriorityBadge } from '@/components/dashboard/StatusBadge';
import { MetricCard } from '@/components/dashboard/MetricCard';
import { Gavel } from 'lucide-react';
import { enforcements, dashboardMetrics } from '@/data/mockData';
import { Enforcement } from '@/types/compliance';
import { useToast } from '@/hooks/use-toast';

export default function Enforcements() {
  const { toast } = useToast();
  const [statusFilter, setStatusFilter] = useState<string | null>(null);

  const filteredEnforcements = statusFilter
    ? enforcements.filter((e) => e.status === statusFilter)
    : enforcements;

  const columns = [
    { key: 'id' as keyof Enforcement, label: 'Enforcement ID' },
    { key: 'title' as keyof Enforcement, label: 'Title' },
    {
      key: 'status' as keyof Enforcement,
      label: 'Status',
      render: (item: Enforcement) => <StatusBadge status={item.status} />,
    },
    { key: 'dueDate' as keyof Enforcement, label: 'Due Date' },
    { key: 'owner' as keyof Enforcement, label: 'Owner' },
    {
      key: 'priority' as keyof Enforcement,
      label: 'Priority',
      render: (item: Enforcement) => <PriorityBadge priority={item.priority} />,
    },
    { key: 'actions' as const, label: 'Actions' },
  ];

  const handleAction = (action: string, item: Enforcement) => {
    toast({
      title: `${action} - EnforcePoint`,
      description: `Routing to EnforcePoint for ${item.id}`,
    });
  };

  const handleRowClick = (item: Enforcement) => {
    toast({
      title: 'Opening in EnforcePoint',
      description: `Routing to EnforcePoint microapp for ${item.id}: ${item.title}`,
    });
  };

  return (
    <MainLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground">Enforcement Management</h1>
        <p className="text-muted-foreground mt-1">
          Enforcement actions and corrective measures
        </p>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <MetricCard
          label="Total Enforcements"
          value={dashboardMetrics.enforcements.total}
          icon={<Gavel className="h-5 w-5" />}
          onClick={() => setStatusFilter(null)}
          isActive={statusFilter === null}
        />
        <MetricCard
          label="Pending"
          value={dashboardMetrics.enforcements.pending}
          variant="warning"
          onClick={() => setStatusFilter('pending')}
          isActive={statusFilter === 'pending'}
        />
        <MetricCard
          label="Completed"
          value={dashboardMetrics.enforcements.completed}
          variant="success"
          onClick={() => setStatusFilter('completed')}
          isActive={statusFilter === 'completed'}
        />
        <MetricCard
          label="Overdue"
          value={dashboardMetrics.enforcements.overdue}
          variant="destructive"
          onClick={() => setStatusFilter('overdue')}
          isActive={statusFilter === 'overdue'}
        />
      </div>

      {/* Table */}
      <DataTable
        data={filteredEnforcements}
        columns={columns}
        title="Enforcement Registry"
        onAdd={() => handleAction('Add', { id: 'new' } as Enforcement)}
        onView={(item) => handleAction('View', item)}
        onEdit={(item) => handleAction('Edit', item)}
        onDelete={(item) => handleAction('Delete', item)}
        onRowClick={handleRowClick}
      />
    </MainLayout>
  );
}
