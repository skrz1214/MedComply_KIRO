import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { DataTable } from '@/components/dashboard/DataTable';
import { StatusBadge, PriorityBadge } from '@/components/dashboard/StatusBadge';
import { MetricCard } from '@/components/dashboard/MetricCard';
import { ClipboardCheck } from 'lucide-react';
import { auditItems, dashboardMetrics } from '@/data/mockData';
import { AuditItem } from '@/types/compliance';
import { useToast } from '@/hooks/use-toast';

export default function Audits() {
  const { toast } = useToast();
  const [statusFilter, setStatusFilter] = useState<string | null>(null);

  const filteredAudits = statusFilter
    ? auditItems.filter((a) => a.status === statusFilter)
    : auditItems;

  const columns = [
    { key: 'id' as keyof AuditItem, label: 'Audit ID' },
    { key: 'title' as keyof AuditItem, label: 'Title' },
    {
      key: 'status' as keyof AuditItem,
      label: 'Status',
      render: (item: AuditItem) => <StatusBadge status={item.status} />,
    },
    { key: 'deadline' as keyof AuditItem, label: 'Deadline' },
    { key: 'owner' as keyof AuditItem, label: 'Owner' },
    {
      key: 'priority' as keyof AuditItem,
      label: 'Priority',
      render: (item: AuditItem) => <PriorityBadge priority={item.priority} />,
    },
    { key: 'actions' as const, label: 'Actions' },
  ];

  const handleAction = (action: string, item: AuditItem) => {
    toast({
      title: `${action} - AuditPro`,
      description: `Routing to AuditPro for ${item.id}`,
    });
  };

  const handleRowClick = (item: AuditItem) => {
    toast({
      title: 'Opening in AuditPro',
      description: `Routing to AuditPro microapp for ${item.id}: ${item.title}`,
    });
  };

  return (
    <MainLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground">Audit Management</h1>
        <p className="text-muted-foreground mt-1">
          Manage and track compliance audits
        </p>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <MetricCard
          label="Total Audits"
          value={dashboardMetrics.audits.total}
          icon={<ClipboardCheck className="h-5 w-5" />}
          onClick={() => setStatusFilter(null)}
          isActive={statusFilter === null}
        />
        <MetricCard
          label="Pending Review"
          value={dashboardMetrics.audits.pending}
          variant="warning"
          onClick={() => setStatusFilter('pending')}
          isActive={statusFilter === 'pending'}
        />
        <MetricCard
          label="Completed"
          value={dashboardMetrics.audits.completed}
          variant="success"
          onClick={() => setStatusFilter('completed')}
          isActive={statusFilter === 'completed'}
        />
        <MetricCard
          label="Overdue"
          value={dashboardMetrics.audits.overdue}
          variant="destructive"
          onClick={() => setStatusFilter('overdue')}
          isActive={statusFilter === 'overdue'}
        />
      </div>

      {/* Table */}
      <DataTable
        data={filteredAudits}
        columns={columns}
        title="Audit Registry"
        onAdd={() => handleAction('Add', { id: 'new' } as AuditItem)}
        onView={(item) => handleAction('View', item)}
        onEdit={(item) => handleAction('Edit', item)}
        onDelete={(item) => handleAction('Delete', item)}
        onRowClick={handleRowClick}
      />
    </MainLayout>
  );
}
