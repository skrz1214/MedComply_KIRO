import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { DataTable } from '@/components/dashboard/DataTable';
import { StatusBadge, RiskLevelBadge } from '@/components/dashboard/StatusBadge';
import { MetricCard } from '@/components/dashboard/MetricCard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertTriangle,
  BookOpen,
  FileText,
  History,
  CheckCircle,
  Heart,
  Shield,
  FileCheck,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { riskItems as initialRiskItems, dashboardMetrics, policies } from '@/data/mockData';
import { RiskItem } from '@/types/compliance';
import { useToast } from '@/hooks/use-toast';
import { RiskDialog } from '@/components/risks/RiskDialog';
import { ViewRiskDialog } from '@/components/risks/ViewRiskDialog';
import { DeleteRiskDialog } from '@/components/risks/DeleteRiskDialog';

interface HIPAAItem {
  id: string;
  description: string;
  type: 'HIPAA' | 'ADAA';
  status: 'completed' | 'pending' | 'overdue' | 'active';
  channel: string;
  lastReviewed: string;
  owner: string;
}

const hipaaItems: HIPAAItem[] = [
  { id: 'HIP-001', description: 'Patient testimonial video consent forms', type: 'HIPAA', status: 'completed', channel: 'Video', lastReviewed: '2024-12-15', owner: 'Emily Watson' },
  { id: 'HIP-002', description: 'Email marketing PHI exposure review', type: 'HIPAA', status: 'pending', channel: 'Email', lastReviewed: '2024-12-10', owner: 'David Kim' },
  { id: 'HIP-003', description: 'Social media comment monitoring', type: 'HIPAA', status: 'active', channel: 'Social', lastReviewed: '2024-12-18', owner: 'David Kim' },
  { id: 'ADA-001', description: 'Website accessibility audit - homepage', type: 'ADAA', status: 'completed', channel: 'Web', lastReviewed: '2024-12-12', owner: 'Michael Torres' },
  { id: 'ADA-002', description: 'Digital ad alt-text compliance', type: 'ADAA', status: 'pending', channel: 'Advertising', lastReviewed: '2024-12-05', owner: 'David Kim' },
  { id: 'HIP-004', description: 'Chatbot data handling review', type: 'HIPAA', status: 'overdue', channel: 'Chat', lastReviewed: '2024-11-20', owner: 'Emily Watson' },
];

export default function Risks() {
  const { toast } = useToast();
  const [levelFilter, setLevelFilter] = useState<string | null>(null);
  const [hipaaTypeFilter, setHipaaTypeFilter] = useState<string | null>(null);
  
  // Risk state
  const [riskData, setRiskData] = useState<RiskItem[]>(initialRiskItems);
  const [riskDialogOpen, setRiskDialogOpen] = useState(false);
  const [viewRiskDialogOpen, setViewRiskDialogOpen] = useState(false);
  const [deleteRiskDialogOpen, setDeleteRiskDialogOpen] = useState(false);
  const [selectedRisk, setSelectedRisk] = useState<RiskItem | null>(null);

  // Risks data
  const filteredRisks = levelFilter
    ? riskData.filter((r) => r.level === levelFilter)
    : riskData;

  const riskColumns = [
    { key: 'id' as keyof RiskItem, label: 'Risk ID' },
    { key: 'description' as keyof RiskItem, label: 'Description' },
    {
      key: 'level' as keyof RiskItem,
      label: 'Level',
      render: (item: RiskItem) => <RiskLevelBadge level={item.level} />,
    },
    {
      key: 'status' as keyof RiskItem,
      label: 'Status',
      render: (item: RiskItem) => <StatusBadge status={item.status} />,
    },
    { key: 'owner' as keyof RiskItem, label: 'Owner' },
    { key: 'actions' as const, label: 'Actions' },
  ];

  // Marketing Policy data
  const marketingPolicies = policies.filter(
    (p) => p.category === 'Digital' || p.category === 'Print' || p.category === 'Privacy'
  );

  const policyColumns = [
    { key: 'id' as const, label: 'Policy ID' },
    { key: 'name' as const, label: 'Name' },
    { key: 'category' as const, label: 'Category' },
    { key: 'lastUpdated' as const, label: 'Last Updated' },
    {
      key: 'status' as const,
      label: 'Status',
      render: (item: typeof policies[0]) => <StatusBadge status={item.status} />,
    },
    { key: 'owner' as const, label: 'Owner' },
    { key: 'actions' as const, label: 'Actions' },
  ];

  // HIPAA/ADAA data
  const filteredHipaaItems = hipaaTypeFilter
    ? hipaaItems.filter((item) => item.type === hipaaTypeFilter)
    : hipaaItems;

  const hipaaCount = hipaaItems.filter((i) => i.type === 'HIPAA').length;
  const adaaCount = hipaaItems.filter((i) => i.type === 'ADAA').length;
  const hipaaPendingCount = hipaaItems.filter((i) => i.status === 'pending' || i.status === 'overdue').length;
  const hipaaCompliantCount = hipaaItems.filter((i) => i.status === 'completed').length;

  const hipaaColumns = [
    { key: 'id' as keyof HIPAAItem, label: 'ID' },
    { key: 'description' as keyof HIPAAItem, label: 'Description' },
    {
      key: 'type' as keyof HIPAAItem,
      label: 'Type',
      render: (item: HIPAAItem) => (
        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${item.type === 'HIPAA' ? 'bg-primary/10 text-primary' : 'bg-accent/10 text-accent-foreground'}`}>
          {item.type}
        </span>
      ),
    },
    { key: 'channel' as keyof HIPAAItem, label: 'Channel' },
    {
      key: 'status' as keyof HIPAAItem,
      label: 'Status',
      render: (item: HIPAAItem) => <StatusBadge status={item.status} />,
    },
    { key: 'lastReviewed' as keyof HIPAAItem, label: 'Last Reviewed' },
    { key: 'owner' as keyof HIPAAItem, label: 'Owner' },
    { key: 'actions' as const, label: 'Actions' },
  ];

  // Risk CRUD handlers
  const handleAddRisk = () => {
    setSelectedRisk(null);
    setRiskDialogOpen(true);
  };

  const handleViewRisk = (risk: RiskItem) => {
    setSelectedRisk(risk);
    setViewRiskDialogOpen(true);
  };

  const handleEditRisk = (risk: RiskItem) => {
    setSelectedRisk(risk);
    setRiskDialogOpen(true);
  };

  const handleDeleteRisk = (risk: RiskItem) => {
    setSelectedRisk(risk);
    setDeleteRiskDialogOpen(true);
  };

  const handleSaveRisk = (data: { id?: string; description: string; level: 'high' | 'medium' | 'low'; status: 'active' | 'pending' | 'completed'; owner: string; mitigationStrategy?: string }) => {
    if (data.id) {
      // Update existing
      setRiskData((prev) =>
        prev.map((r) =>
          r.id === data.id
            ? { ...r, ...data }
            : r
        )
      );
      toast({ title: 'Risk Updated', description: `${data.id} has been updated successfully.` });
    } else {
      // Create new
      const newId = `RSK-${String(riskData.length + 1).padStart(3, '0')}`;
      const newRisk: RiskItem = {
        id: newId,
        description: data.description,
        level: data.level,
        status: data.status,
        owner: data.owner,
        mitigationStrategy: data.mitigationStrategy,
      };
      setRiskData((prev) => [...prev, newRisk]);
      toast({ title: 'Risk Created', description: `${newId} has been created successfully.` });
    }
  };

  const handleConfirmDeleteRisk = () => {
    if (selectedRisk) {
      setRiskData((prev) => prev.filter((r) => r.id !== selectedRisk.id));
      toast({ title: 'Risk Deleted', description: `${selectedRisk.id} has been removed.` });
      setDeleteRiskDialogOpen(false);
      setSelectedRisk(null);
    }
  };

  const handleRiskRowClick = (item: RiskItem) => {
    handleViewRisk(item);
  };

  // RiskGuard routing helpers for Policies and HIPAA
  const routeToRiskGuard = (action: string, itemId: string, itemName?: string) => {
    toast({
      title: `${action} - RiskGuard`,
      description: (
        <div className="flex items-center gap-2">
          <ExternalLink className="h-4 w-4" />
          <span>Routing to RiskGuard Risk Management for {itemName || itemId}</span>
        </div>
      ),
    });
  };

  return (
    <MainLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground">Risk Management</h1>
        <p className="text-muted-foreground mt-1">
          Risk assessment, policies, and regulatory compliance management
        </p>
      </div>

      <Tabs defaultValue="risks" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 lg:w-auto lg:inline-grid">
          <TabsTrigger value="risks">Risks</TabsTrigger>
          <TabsTrigger value="policies">Policies</TabsTrigger>
          <TabsTrigger value="hipaa">HIPAA & ADAA</TabsTrigger>
        </TabsList>

        {/* Risks Tab */}
        <TabsContent value="risks" className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <MetricCard
              label="Total Risks"
              value={riskData.length}
              icon={<AlertTriangle className="h-5 w-5" />}
              onClick={() => setLevelFilter(null)}
              isActive={levelFilter === null}
            />
            <MetricCard
              label="High Risk"
              value={riskData.filter((r) => r.level === 'high').length}
              variant="destructive"
              onClick={() => setLevelFilter('high')}
              isActive={levelFilter === 'high'}
            />
            <MetricCard
              label="Medium Risk"
              value={riskData.filter((r) => r.level === 'medium').length}
              variant="warning"
              onClick={() => setLevelFilter('medium')}
              isActive={levelFilter === 'medium'}
            />
            <MetricCard
              label="Low Risk"
              value={riskData.filter((r) => r.level === 'low').length}
              variant="success"
              onClick={() => setLevelFilter('low')}
              isActive={levelFilter === 'low'}
            />
          </div>

          <DataTable
            data={filteredRisks}
            columns={riskColumns}
            title="Risk Registry"
            onAdd={handleAddRisk}
            onView={handleViewRisk}
            onEdit={handleEditRisk}
            onDelete={handleDeleteRisk}
            onRowClick={handleRiskRowClick}
          />
        </TabsContent>

        {/* Policies Tab */}
        <TabsContent value="policies" className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <MetricCard
              label="Total Policies"
              value={marketingPolicies.length}
              icon={<BookOpen className="h-5 w-5" />}
            />
            <MetricCard
              label="Active"
              value={marketingPolicies.filter((p) => p.status === 'active').length}
              icon={<CheckCircle className="h-5 w-5" />}
              variant="success"
            />
            <MetricCard
              label="Under Review"
              value={marketingPolicies.filter((p) => p.status === 'pending').length}
              icon={<FileText className="h-5 w-5" />}
              variant="warning"
            />
            <MetricCard
              label="Versions"
              value={42}
              icon={<History className="h-5 w-5" />}
            />
          </div>

          <DataTable
            data={marketingPolicies}
            columns={policyColumns}
            title="Policy Registry"
            onAdd={() => routeToRiskGuard('Add Policy', 'new')}
            onView={(item) => routeToRiskGuard('View Policy', item.id, item.name)}
            onEdit={(item) => routeToRiskGuard('Edit Policy', item.id, item.name)}
            onDelete={(item) => routeToRiskGuard('Delete Policy', item.id, item.name)}
            onRowClick={(item) => routeToRiskGuard('Open Policy', item.id, item.name)}
          />
        </TabsContent>

        {/* HIPAA & ADAA Tab */}
        <TabsContent value="hipaa" className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <MetricCard
              label="HIPAA Items"
              value={hipaaCount}
              icon={<Heart className="h-5 w-5" />}
              variant="info"
              onClick={() => setHipaaTypeFilter(hipaaTypeFilter === 'HIPAA' ? null : 'HIPAA')}
              isActive={hipaaTypeFilter === 'HIPAA'}
            />
            <MetricCard
              label="ADAA Items"
              value={adaaCount}
              icon={<Shield className="h-5 w-5" />}
              onClick={() => setHipaaTypeFilter(hipaaTypeFilter === 'ADAA' ? null : 'ADAA')}
              isActive={hipaaTypeFilter === 'ADAA'}
            />
            <MetricCard
              label="Compliant"
              value={hipaaCompliantCount}
              icon={<FileCheck className="h-5 w-5" />}
              variant="success"
            />
            <MetricCard
              label="Needs Attention"
              value={hipaaPendingCount}
              icon={<AlertCircle className="h-5 w-5" />}
              variant="warning"
            />
          </div>

          {/* Info Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-card rounded-lg border border-border p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Heart className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground">HIPAA Requirements</h3>
              </div>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• Protected Health Information (PHI) must not be disclosed without consent</li>
                <li>• Patient testimonials require signed authorization forms</li>
                <li>• Marketing materials cannot include identifying patient data</li>
                <li>• Social media interactions must be monitored for PHI exposure</li>
              </ul>
            </div>

            <div className="bg-card rounded-lg border border-border p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Shield className="h-5 w-5 text-accent-foreground" />
                </div>
                <h3 className="font-semibold text-foreground">ADAA Requirements</h3>
              </div>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• All digital content must be accessible to users with disabilities</li>
                <li>• Images require descriptive alt-text</li>
                <li>• Videos must include closed captions</li>
                <li>• Website meets WCAG 2.1 AA standards</li>
              </ul>
            </div>
          </div>

          <DataTable
            data={filteredHipaaItems}
            columns={hipaaColumns}
            title="HIPAA & ADAA Compliance Items"
            onAdd={() => routeToRiskGuard('Add Item', 'new')}
            onView={(item) => routeToRiskGuard('View Item', item.id, item.description)}
            onEdit={(item) => routeToRiskGuard('Edit Item', item.id, item.description)}
            onDelete={(item) => routeToRiskGuard('Delete Item', item.id, item.description)}
            onRowClick={(item) => routeToRiskGuard('Open Item', item.id, item.description)}
          />
        </TabsContent>
      </Tabs>

      {/* Risk Dialogs */}
      <RiskDialog
        open={riskDialogOpen}
        onOpenChange={setRiskDialogOpen}
        risk={selectedRisk}
        onSave={handleSaveRisk}
      />
      <ViewRiskDialog
        open={viewRiskDialogOpen}
        onOpenChange={setViewRiskDialogOpen}
        risk={selectedRisk}
        onEdit={() => {
          setViewRiskDialogOpen(false);
          setRiskDialogOpen(true);
        }}
      />
      <DeleteRiskDialog
        open={deleteRiskDialogOpen}
        onOpenChange={setDeleteRiskDialogOpen}
        risk={selectedRisk}
        onConfirm={handleConfirmDeleteRisk}
      />
    </MainLayout>
  );
}
