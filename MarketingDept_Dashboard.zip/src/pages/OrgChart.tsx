import { useState } from 'react';
import { Phone, MoreVertical, ChevronDown, ChevronRight, Pencil, Trash2, Plus, MessageSquare, User } from 'lucide-react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { teamMembers as initialMembers } from '@/data/mockData';
import { TeamMember } from '@/types/compliance';
import { useToast } from '@/hooks/use-toast';
import { SendMessageDialog } from '@/components/org-chart/SendMessageDialog';
import { MemberDialog } from '@/components/org-chart/MemberDialog';
import { DeleteMemberDialog } from '@/components/org-chart/DeleteMemberDialog';
import { ViewProfileDialog } from '@/components/org-chart/ViewProfileDialog';

interface OrgNode extends TeamMember {
  children: OrgNode[];
  expanded: boolean;
}

function buildOrgTree(members: TeamMember[]): OrgNode[] {
  const memberMap = new Map<string, OrgNode>();
  
  members.forEach((m) => {
    memberMap.set(m.id, { ...m, children: [], expanded: true });
  });

  const roots: OrgNode[] = [];
  
  memberMap.forEach((node) => {
    if (node.reportsTo) {
      const parent = memberMap.get(node.reportsTo);
      if (parent) {
        parent.children.push(node);
      } else {
        roots.push(node);
      }
    } else {
      roots.push(node);
    }
  });

  return roots;
}

interface OrgNodeCardProps {
  node: OrgNode;
  onMessage: (member: TeamMember) => void;
  onViewProfile: (member: TeamMember) => void;
  onEdit: (member: TeamMember) => void;
  onDelete: (member: TeamMember) => void;
  onToggle: (id: string) => void;
}

function OrgNodeCard({ node, onMessage, onViewProfile, onEdit, onDelete, onToggle }: OrgNodeCardProps) {
  const hasChildren = node.children.length > 0;

  return (
    <div className="flex flex-col items-center">
      <div className="relative bg-card border border-border rounded-lg p-4 w-64 hover:shadow-md transition-shadow">
        {hasChildren && (
          <button
            onClick={() => onToggle(node.id)}
            className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-6 h-6 bg-card border border-border rounded-full flex items-center justify-center hover:bg-muted transition-colors"
          >
            {node.expanded ? (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            )}
          </button>
        )}
        <div className="flex items-start gap-3">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
            <span className="text-sm font-semibold text-primary">
              {node.name.split(' ').map((n) => n[0]).join('')}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-medium text-foreground truncate">{node.name}</h3>
            <p className="text-sm text-muted-foreground truncate">{node.role}</p>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onMessage(node)}>
                <MessageSquare className="h-4 w-4 mr-2" />
                Send Message
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onViewProfile(node)}>
                <User className="h-4 w-4 mr-2" />
                View Profile
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => onEdit(node)}>
                <Pencil className="h-4 w-4 mr-2" />
                Edit Member
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onDelete(node)} className="text-destructive focus:text-destructive">
                <Trash2 className="h-4 w-4 mr-2" />
                Delete Member
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <div className="mt-3 pt-3 border-t border-border">
          <p className="text-xs text-muted-foreground truncate">{node.email}</p>
        </div>
      </div>

      {hasChildren && node.expanded && (
        <div className="mt-8 relative">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-8 bg-border -mt-8" />
          <div className="flex gap-8">
            {node.children.map((child, index) => (
              <div key={child.id} className="relative">
                {node.children.length > 1 && (
                  <>
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-4 bg-border -mt-4" />
                    {index === 0 && (
                      <div className="absolute -top-4 left-1/2 w-1/2 h-px bg-border" style={{ left: '50%' }} />
                    )}
                    {index === node.children.length - 1 && (
                      <div className="absolute -top-4 right-1/2 w-1/2 h-px bg-border" style={{ right: '50%' }} />
                    )}
                    {index > 0 && index < node.children.length - 1 && (
                      <div className="absolute -top-4 left-0 right-0 h-px bg-border" />
                    )}
                  </>
                )}
                <OrgNodeCard
                  node={child}
                  onMessage={onMessage}
                  onViewProfile={onViewProfile}
                  onEdit={onEdit}
                  onDelete={onDelete}
                  onToggle={onToggle}
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default function OrgChart() {
  const { toast } = useToast();
  const [members, setMembers] = useState<TeamMember[]>(initialMembers);
  const [orgTree, setOrgTree] = useState<OrgNode[]>(() => buildOrgTree(initialMembers));
  
  // Dialog states
  const [memberDialogOpen, setMemberDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [messageDialogOpen, setMessageDialogOpen] = useState(false);
  const [profileDialogOpen, setProfileDialogOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);

  const refreshOrgTree = (updatedMembers: TeamMember[]) => {
    setMembers(updatedMembers);
    setOrgTree(buildOrgTree(updatedMembers));
  };

  const handleMessage = (member: TeamMember) => {
    setSelectedMember(member);
    setMessageDialogOpen(true);
  };

  const handleViewProfile = (member: TeamMember) => {
    setSelectedMember(member);
    setProfileDialogOpen(true);
  };

  const handleSendMessage = (data: { subject: string; message: string; priority: 'normal' | 'high' | 'urgent'; recipientId: string }) => {
    toast({
      title: 'Message sent',
      description: `Your message "${data.subject}" has been sent to ${selectedMember?.name}.`,
    });
  };

  const handleAddMember = () => {
    setSelectedMember(null);
    setMemberDialogOpen(true);
  };

  const handleEditMember = (member: TeamMember) => {
    setSelectedMember(member);
    setMemberDialogOpen(true);
  };

  const handleDeleteClick = (member: TeamMember) => {
    setSelectedMember(member);
    setDeleteDialogOpen(true);
  };

  const handleSaveMember = (data: { id?: string; name: string; role: string; department: string; email: string; reportsTo?: string }) => {
    if (data.id) {
      // Update existing member
      const updatedMembers = members.map((m) =>
        m.id === data.id
          ? { ...m, name: data.name, role: data.role, department: data.department, email: data.email, reportsTo: data.reportsTo }
          : m
      );
      refreshOrgTree(updatedMembers);
      toast({
        title: 'Member updated',
        description: `${data.name}'s profile has been updated.`,
      });
    } else {
      // Add new member
      const newId = String(Math.max(...members.map((m) => parseInt(m.id))) + 1);
      const newMember: TeamMember = {
        id: newId,
        name: data.name,
        role: data.role,
        department: data.department,
        email: data.email,
        reportsTo: data.reportsTo,
      };
      refreshOrgTree([...members, newMember]);
      toast({
        title: 'Member added',
        description: `${data.name} has been added to the team.`,
      });
    }
  };

  const handleDeleteConfirm = () => {
    if (!selectedMember) return;
    
    // Reassign direct reports to top level (remove their reportsTo)
    const updatedMembers = members
      .filter((m) => m.id !== selectedMember.id)
      .map((m) => (m.reportsTo === selectedMember.id ? { ...m, reportsTo: undefined } : m));
    
    refreshOrgTree(updatedMembers);
    setDeleteDialogOpen(false);
    toast({
      title: 'Member removed',
      description: `${selectedMember.name} has been removed from the organization.`,
    });
  };

  const toggleNode = (id: string) => {
    const updateTree = (nodes: OrgNode[]): OrgNode[] => {
      return nodes.map((node) => {
        if (node.id === id) {
          return { ...node, expanded: !node.expanded };
        }
        return { ...node, children: updateTree(node.children) };
      });
    };
    setOrgTree(updateTree(orgTree));
  };

  const hasDirectReports = selectedMember
    ? members.some((m) => m.reportsTo === selectedMember.id)
    : false;

  return (
    <MainLayout>
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Organization Chart</h1>
            <p className="text-muted-foreground mt-1">Marketing Compliance Team Structure</p>
          </div>
          <Button onClick={handleAddMember}>
            <Plus className="h-4 w-4 mr-2" />
            Add Member
          </Button>
        </div>
      </div>

      <div className="bg-card rounded-lg border border-border p-8 overflow-x-auto">
        <div className="flex justify-center min-w-max">
          {orgTree.map((root) => (
            <OrgNodeCard
              key={root.id}
              node={root}
              onMessage={handleMessage}
              onViewProfile={handleViewProfile}
              onEdit={handleEditMember}
              onDelete={handleDeleteClick}
              onToggle={toggleNode}
            />
          ))}
        </div>
      </div>

      {/* Team List View */}
      <div className="mt-8 bg-card rounded-lg border border-border">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h2 className="font-semibold text-foreground">Team Directory</h2>
          <span className="text-sm text-muted-foreground">{members.length} members</span>
        </div>
        <div className="divide-y divide-border">
          {members.map((member) => (
            <div key={member.id} className="flex items-center justify-between p-4 hover:bg-muted/30 transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-sm font-medium text-primary">
                    {member.name.split(' ').map((n) => n[0]).join('')}
                  </span>
                </div>
                <div>
                  <p className="font-medium text-foreground">{member.name}</p>
                  <p className="text-sm text-muted-foreground">{member.role}</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="sm" onClick={() => handleMessage(member)}>
                  <MessageSquare className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" onClick={() => handleEditMember(member)}>
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" onClick={() => handleDeleteClick(member)} className="text-destructive hover:text-destructive">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Dialogs */}
      <MemberDialog
        open={memberDialogOpen}
        onOpenChange={setMemberDialogOpen}
        member={selectedMember}
        members={members}
        onSave={handleSaveMember}
      />
      
      <DeleteMemberDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        member={selectedMember}
        onConfirm={handleDeleteConfirm}
        hasReports={hasDirectReports}
      />

      <SendMessageDialog
        open={messageDialogOpen}
        onOpenChange={setMessageDialogOpen}
        recipient={selectedMember}
        onSend={handleSendMessage}
      />

      <ViewProfileDialog
        open={profileDialogOpen}
        onOpenChange={setProfileDialogOpen}
        member={selectedMember}
        members={members}
        onSendMessage={handleMessage}
      />
    </MainLayout>
  );
}
