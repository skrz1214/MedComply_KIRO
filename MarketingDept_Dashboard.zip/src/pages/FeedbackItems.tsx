import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { DataTable } from '@/components/dashboard/DataTable';
import { StatusBadge, PriorityBadge } from '@/components/dashboard/StatusBadge';
import { MetricCard } from '@/components/dashboard/MetricCard';
import { MessageSquare } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Status, Priority } from '@/types/compliance';

interface FeedbackItem {
  id: string;
  title: string;
  source: string;
  status: Status;
  priority: Priority;
  submittedDate: string;
  owner: string;
}

const feedbackItems: FeedbackItem[] = [
  { id: 'FB-001', title: 'Clarification needed on HIPAA disclosure policy', source: 'Internal', status: 'pending', priority: 'high', submittedDate: '2024-12-18', owner: 'Emily Watson' },
  { id: 'FB-002', title: 'Request for updated marketing guidelines', source: 'Marketing Team', status: 'completed', priority: 'medium', submittedDate: '2024-12-15', owner: 'David Kim' },
  { id: 'FB-003', title: 'Digital ad compliance concern', source: 'External Partner', status: 'active', priority: 'high', submittedDate: '2024-12-20', owner: 'Michael Torres' },
  { id: 'FB-004', title: 'Print material approval delay feedback', source: 'Internal', status: 'pending', priority: 'low', submittedDate: '2024-12-10', owner: 'James Wilson' },
  { id: 'FB-005', title: 'Social media policy suggestion', source: 'Marketing Team', status: 'completed', priority: 'medium', submittedDate: '2024-12-08', owner: 'David Kim' },
];

export default function FeedbackItems() {
  const { toast } = useToast();
  const [statusFilter, setStatusFilter] = useState<string | null>(null);

  const filteredItems = statusFilter
    ? feedbackItems.filter((f) => f.status === statusFilter)
    : feedbackItems;

  const metrics = {
    total: feedbackItems.length,
    pending: feedbackItems.filter((f) => f.status === 'pending').length,
    active: feedbackItems.filter((f) => f.status === 'active').length,
    completed: feedbackItems.filter((f) => f.status === 'completed').length,
  };

  const columns = [
    { key: 'id' as keyof FeedbackItem, label: 'Feedback ID' },
    { key: 'title' as keyof FeedbackItem, label: 'Title' },
    { key: 'source' as keyof FeedbackItem, label: 'Source' },
    {
      key: 'status' as keyof FeedbackItem,
      label: 'Status',
      render: (item: FeedbackItem) => <StatusBadge status={item.status} />,
    },
    {
      key: 'priority' as keyof FeedbackItem,
      label: 'Priority',
      render: (item: FeedbackItem) => <PriorityBadge priority={item.priority} />,
    },
    { key: 'submittedDate' as keyof FeedbackItem, label: 'Submitted' },
    { key: 'owner' as keyof FeedbackItem, label: 'Owner' },
    { key: 'actions' as const, label: 'Actions' },
  ];

  const handleAction = (action: string, item: FeedbackItem) => {
    toast({
      title: `${action} - FeedbackHub`,
      description: `Routing to FeedbackHub for ${item.id}`,
    });
  };

  const handleRowClick = (item: FeedbackItem) => {
    toast({
      title: 'Opening in FeedbackHub',
      description: `Routing to FeedbackHub microapp for ${item.id}: ${item.title}`,
    });
  };

  return (
    <MainLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground">Feedback Management</h1>
        <p className="text-muted-foreground mt-1">
          Stakeholder feedback and suggestions
        </p>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <MetricCard
          label="Total Feedback"
          value={metrics.total}
          icon={<MessageSquare className="h-5 w-5" />}
          onClick={() => setStatusFilter(null)}
          isActive={statusFilter === null}
        />
        <MetricCard
          label="Pending Review"
          value={metrics.pending}
          variant="warning"
          onClick={() => setStatusFilter('pending')}
          isActive={statusFilter === 'pending'}
        />
        <MetricCard
          label="In Progress"
          value={metrics.active}
          variant="info"
          onClick={() => setStatusFilter('active')}
          isActive={statusFilter === 'active'}
        />
        <MetricCard
          label="Completed"
          value={metrics.completed}
          variant="success"
          onClick={() => setStatusFilter('completed')}
          isActive={statusFilter === 'completed'}
        />
      </div>

      {/* Table */}
      <DataTable
        data={filteredItems}
        columns={columns}
        title="Feedback Registry"
        onAdd={() => handleAction('Add', { id: 'new' } as FeedbackItem)}
        onView={(item) => handleAction('View', item)}
        onEdit={(item) => handleAction('Edit', item)}
        onDelete={(item) => handleAction('Delete', item)}
        onRowClick={handleRowClick}
      />
    </MainLayout>
  );
}
