import { useParams } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Shield, MessageSquare, AlertTriangle, ClipboardCheck, Gavel, FileCheck, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { microApps } from '@/data/mockData';

const iconMap: Record<string, React.ElementType> = {
  'shield-check': Shield,
  'message-square': MessageSquare,
  'alert-triangle': AlertTriangle,
  'clipboard-check': ClipboardCheck,
  'gavel': Gavel,
  'file-text': FileCheck,
};

export default function MicroAppPage() {
  const { appId } = useParams();

  const app = microApps.find((a) => a.route === `/apps/${appId}`);

  if (!app) {
    return (
      <MainLayout>
        <div className="flex flex-col items-center justify-center py-20">
          <h1 className="text-2xl font-bold text-foreground mb-4">App Not Found</h1>
          <Link to="/">
            <Button>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
        </div>
      </MainLayout>
    );
  }

  const IconComponent = iconMap[app.icon] || Shield;

  return (
    <MainLayout>
      <div className="mb-8">
        <Link
          to="/"
          className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Dashboard
        </Link>
        <div className="flex items-center gap-4">
          <div className={`w-14 h-14 rounded-xl ${app.color} flex items-center justify-center`}>
            <IconComponent className="h-7 w-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">{app.name}</h1>
            <p className="text-muted-foreground">{app.description}</p>
          </div>
        </div>
      </div>

      <div className="bg-card rounded-lg border border-border p-12 text-center">
        <div className={`w-20 h-20 rounded-2xl ${app.color} flex items-center justify-center mx-auto mb-6`}>
          <IconComponent className="h-10 w-10 text-white" />
        </div>
        <h2 className="text-xl font-semibold text-foreground mb-2">
          Welcome to {app.name}
        </h2>
        <p className="text-muted-foreground max-w-md mx-auto mb-6">
          This micro app provides specialized functionality for {app.description.toLowerCase()}.
          Full integration coming soon.
        </p>
        <div className="flex items-center justify-center gap-4">
          <Button variant="outline">View Documentation</Button>
          <Button>Open Full App</Button>
        </div>
      </div>
    </MainLayout>
  );
}
