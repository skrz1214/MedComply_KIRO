import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  FileText,
  CheckCircle,
  Clock,
  AlertTriangle,
  Plus,
  Users,
  ChevronRight,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Minus,
  Pencil,
  Trash2,
  Eye,
  Calculator,
  Shield,
  MessageSquare,
  ClipboardCheck,
  Gavel,
  FileCheck,
} from 'lucide-react';
import { QuickStatItem } from '@/components/dashboard/MetricCard';
import { StatusBadge, PriorityBadge } from '@/components/dashboard/StatusBadge';
import { MainLayout } from '@/components/layout/MainLayout';
import { dashboardMetrics, microApps } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { Status } from '@/types/compliance';
import { cn } from '@/lib/utils';
import { KPIDialog, KPI } from '@/components/kpis/KPIDialog';
import { ViewKPIDialog } from '@/components/kpis/ViewKPIDialog';
import { DeleteKPIDialog } from '@/components/kpis/DeleteKPIDialog';
import { ActionItemDialog } from '@/components/dashboard/ActionItemDialog';

const getIconComponent = (iconName: string) => {
  const icons: Record<string, React.ElementType> = {
    'shield-check': Shield,
    'message-square': MessageSquare,
    'alert-triangle': AlertTriangle,
    'clipboard-check': ClipboardCheck,
    'gavel': Gavel,
    'file-text': FileCheck,
  };
  return icons[iconName] || Shield;
};

const initialKPIs: KPI[] = [
  { 
    id: 'KPI-001', 
    name: 'Content Compliance Rate', 
    current: 94, 
    target: 95, 
    unit: '%', 
    trend: 'up', 
    periodicity: 'Monthly', 
    category: 'Marketing Compliance',
    calculation: {
      numerator: 188,
      denominator: 200,
      numeratorLabel: 'Number of content pieces that passed compliance review',
      denominatorLabel: 'Total number of content pieces reviewed this period',
      formula: '(Compliant Content ÷ Total Content Reviewed) × 100',
      guidance: 'Count all marketing materials (ads, emails, social posts, brochures) that passed compliance review without issues. Divide by total pieces reviewed.'
    }
  },
  { 
    id: 'KPI-002', 
    name: 'Campaign Approval Rate', 
    current: 88, 
    target: 90, 
    unit: '%', 
    trend: 'up', 
    periodicity: 'Monthly', 
    category: 'Marketing Compliance',
    calculation: {
      numerator: 44,
      denominator: 50,
      numeratorLabel: 'Number of campaigns approved on first submission',
      denominatorLabel: 'Total number of campaigns submitted for approval',
      formula: '(First-Time Approvals ÷ Total Submissions) × 100',
      guidance: 'Track campaigns that received approval without requiring revisions. This measures how well teams follow compliance guidelines upfront.'
    }
  },
  { 
    id: 'KPI-003', 
    name: 'Disclosure Compliance Rate', 
    current: 97, 
    target: 100, 
    unit: '%', 
    trend: 'neutral', 
    periodicity: 'Weekly', 
    category: 'Marketing Compliance',
    calculation: {
      numerator: 97,
      denominator: 100,
      numeratorLabel: 'Content with complete and accurate disclosures',
      denominatorLabel: 'Total content requiring legal disclosures',
      formula: '(Content with Proper Disclosures ÷ Content Requiring Disclosures) × 100',
      guidance: 'Review all marketing materials requiring disclaimers, terms, or regulatory disclosures. Count those with complete, properly formatted disclosures.'
    }
  },
  { 
    id: 'KPI-004', 
    name: 'Regulatory Violation Rate', 
    current: 2, 
    target: 0, 
    unit: '%', 
    trend: 'down', 
    periodicity: 'Monthly', 
    category: 'Marketing Compliance',
    calculation: {
      numerator: 4,
      denominator: 200,
      numeratorLabel: 'Number of compliance violations identified',
      denominatorLabel: 'Total content pieces audited',
      formula: '(Violations Found ÷ Total Content Audited) × 100',
      guidance: 'Count any content that violated HIPAA, FTC, FDA, or other regulations. Lower is better - target should always be 0%.'
    }
  },
];

export default function Dashboard() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<'today' | 'week' | 'overdue'>('today');
  const [viewFilter, setViewFilter] = useState<'me' | 'all'>('me');
  
  // KPI state
  const [kpis, setKpis] = useState<KPI[]>(initialKPIs);
  const [kpiDialogOpen, setKpiDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedKPI, setSelectedKPI] = useState<KPI | null>(null);

  // Action Item state
  const [actionItemDialogOpen, setActionItemDialogOpen] = useState(false);
  const [actionItems, setActionItems] = useState<{
    id: string;
    title: string;
    dueDate: string;
    owner: string;
    priority: 'high' | 'medium' | 'low';
    status: string;
    microAppId: string;
  }[]>([
    {
      id: '1',
      title: 'Review compliance documentation for Q2 2025',
      dueDate: 'Due Today',
      owner: 'Me',
      priority: 'high',
      status: 'not-started',
      microAppId: 'cc',
    },
    {
      id: '2',
      title: 'Update risk assessment report',
      dueDate: 'Due Tomorrow',
      owner: 'Me',
      priority: 'medium',
      status: 'in-progress',
      microAppId: 'rg',
    },
  ]);

  const handleSelectMicroApp = (microAppId: string) => {
    const app = microApps.find((a) => a.id === microAppId);
    if (app) {
      toast({ title: 'Micro App Selected', description: `Navigating to ${app.name}` });
      // Navigate to the micro app route
      window.location.href = app.route;
    }
  };

  // Sample review queue
  const reviewQueue: { id: string; title: string; type: string; owner: string; date: string; status: Status }[] = [
    {
      id: '1',
      title: 'New policy draft – Patient Data Protection',
      type: 'Policy',
      owner: 'Sarah Johnson',
      date: 'Dec 10, 2024',
      status: 'pending-review',
    },
    {
      id: '2',
      title: 'Quarterly Audit Results',
      type: 'Audit',
      owner: 'Michael Chen',
      date: 'Dec 9, 2024',
      status: 'in-progress',
    },
    {
      id: '3',
      title: 'Staff Training Compliance Report',
      type: 'Training',
      owner: 'Emily Davis',
      date: 'Dec 8, 2024',
      status: 'pending-review',
    },
  ];

  // KPI helpers
  const getKPIStatus = (kpi: KPI): 'on-track' | 'at-risk' | 'off-track' => {
    const isLowerBetter = kpi.name.toLowerCase().includes('violation');
    if (isLowerBetter) {
      if (kpi.current <= kpi.target) return 'on-track';
      if (kpi.current <= kpi.target + 2) return 'at-risk';
      return 'off-track';
    }
    const ratio = kpi.current / kpi.target;
    if (ratio >= 1) return 'on-track';
    if (ratio >= 0.95) return kpi.trend === 'up' ? 'on-track' : 'at-risk';
    if (ratio >= 0.85) return kpi.trend === 'up' ? 'at-risk' : 'off-track';
    return 'off-track';
  };

  const TrendIcon = ({ trend }: { trend: 'up' | 'down' | 'neutral' }) => {
    if (trend === 'up') return <TrendingUp className="h-4 w-4 text-success" />;
    if (trend === 'down') return <TrendingDown className="h-4 w-4 text-destructive" />;
    return <Minus className="h-4 w-4 text-muted-foreground" />;
  };

  const getStatusColor = (status: 'on-track' | 'at-risk' | 'off-track') => {
    switch (status) {
      case 'on-track': return 'bg-success';
      case 'at-risk': return 'bg-warning';
      case 'off-track': return 'bg-destructive';
    }
  };

  const getTypeStyle = (type: string) => {
    const styles: Record<string, string> = {
      Policy: 'bg-info/10 text-info',
      Audit: 'bg-warning/10 text-warning',
      Training: 'bg-success/10 text-success',
    };
    return styles[type] || 'bg-muted text-muted-foreground';
  };

  // KPI CRUD handlers
  const handleAddKPI = () => {
    setSelectedKPI(null);
    setKpiDialogOpen(true);
  };

  const handleViewKPI = (kpi: KPI) => {
    setSelectedKPI(kpi);
    setViewDialogOpen(true);
  };

  const handleEditKPI = (kpi: KPI) => {
    setSelectedKPI(kpi);
    setKpiDialogOpen(true);
  };

  const handleDeleteKPI = (kpi: KPI) => {
    setSelectedKPI(kpi);
    setDeleteDialogOpen(true);
  };

  const handleSaveKPI = (data: Omit<KPI, 'id'> & { id?: string }) => {
    if (data.id) {
      setKpis((prev) => prev.map((k) => k.id === data.id ? { ...data, id: data.id } as KPI : k));
      toast({ title: 'KPI Updated', description: `${data.name} has been updated.` });
    } else {
      const newId = `KPI-${String(kpis.length + 1).padStart(3, '0')}`;
      setKpis((prev) => [...prev, { ...data, id: newId } as KPI]);
      toast({ title: 'KPI Created', description: `${data.name} has been created.` });
    }
  };

  const handleConfirmDelete = () => {
    if (selectedKPI) {
      setKpis((prev) => prev.filter((k) => k.id !== selectedKPI.id));
      toast({ title: 'KPI Deleted', description: `${selectedKPI.name} has been removed.` });
      setDeleteDialogOpen(false);
      setSelectedKPI(null);
    }
  };

  return (
    <MainLayout>
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Marketing Compliance Master Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Marketing Compliance Dashboard
        </p>
      </div>

      <div className="flex gap-6">
        {/* Main Content */}
        <div className="flex-1 space-y-6">
          {/* Action Center */}
          <div className="card-section">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-semibold text-foreground">Action Center</h2>
                <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-medium flex items-center justify-center">
                  5
                </span>
              </div>
              <Button size="sm" className="gap-2" onClick={() => setActionItemDialogOpen(true)}>
                <Plus className="h-4 w-4" />
                Add Action Item
              </Button>
            </div>

            <p className="text-sm text-muted-foreground mb-4">Executive compliance tasks</p>

            {/* Progress Bar */}
            <div className="bg-muted/50 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">Today's Progress</span>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>0 of 2 completed</span>
                  <RefreshCw className="h-4 w-4" />
                </div>
              </div>
              <Progress value={0} className="h-1.5 bg-warning/30" />
            </div>

            {/* Tab Filters */}
            <div className="flex items-center gap-4 mb-4">
              <div className="flex items-center gap-2 text-sm">
                <button 
                  onClick={() => setActiveTab('today')}
                  className={`${activeTab === 'today' ? 'font-medium text-foreground' : 'text-muted-foreground'}`}
                >
                  Today <span className="ml-1">2</span>
                </button>
                <button 
                  onClick={() => setActiveTab('week')}
                  className={`${activeTab === 'week' ? 'font-medium text-foreground' : 'text-muted-foreground'}`}
                >
                  This Week <span className="ml-1">1</span>
                </button>
                <button 
                  onClick={() => setActiveTab('overdue')}
                  className={`${activeTab === 'overdue' ? 'font-medium text-destructive' : 'text-destructive/70'}`}
                >
                  Overdue <span className="ml-1">2</span>
                </button>
              </div>
            </div>

            {/* Filter Buttons */}
            <div className="flex items-center gap-4 mb-4">
              <div className="flex items-center bg-muted rounded-lg p-1">
                <button
                  onClick={() => setViewFilter('me')}
                  className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${
                    viewFilter === 'me' 
                      ? 'bg-primary text-primary-foreground' 
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  Me
                </button>
                <button
                  onClick={() => setViewFilter('all')}
                  className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${
                    viewFilter === 'all' 
                      ? 'bg-primary text-primary-foreground' 
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  All
                </button>
              </div>
              <select className="text-sm border border-border rounded-lg px-3 py-1.5 bg-card">
                <option>All Types</option>
              </select>
              <div className="flex-1">
                <input 
                  type="text" 
                  placeholder="Search tasks" 
                  className="w-full text-sm border border-border rounded-lg px-3 py-1.5 bg-card"
                />
              </div>
            </div>

            {/* Action Items */}
            <div className="space-y-3">
              {actionItems.map((item) => (
                <Link 
                  key={item.id} 
                  to="/compliance"
                  className="action-item cursor-pointer hover:bg-accent/50 transition-colors"
                >
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{item.title}</p>
                    <div className="flex items-center gap-2 mt-1 text-sm">
                      <span className={item.dueDate.includes('Today') ? 'text-primary' : 'text-muted-foreground'}>
                        <Clock className="h-3 w-3 inline mr-1" />
                        {item.dueDate}
                      </span>
                      <span className="text-muted-foreground">•</span>
                      <span className="text-muted-foreground flex items-center">
                        <Users className="h-3 w-3 mr-1" />
                        {item.owner}
                      </span>
                      <span className="text-muted-foreground">•</span>
                      <PriorityBadge priority={item.priority} />
                      <span className="text-muted-foreground">
                        {item.status === 'not-started' ? 'Not started' : 'In progress'}
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                </Link>
              ))}
            </div>
          </div>

          {/* Review Queue */}
          <div className="card-section">
            <div className="flex items-center gap-2 mb-2">
              <h2 className="text-lg font-semibold text-foreground">Review Queue</h2>
              <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-medium flex items-center justify-center">
                3
              </span>
            </div>
            <p className="text-sm text-muted-foreground mb-4">Pending reviews & sign-offs</p>

            <div className="space-y-0">
              {reviewQueue.map((item) => {
                const routeMap: Record<string, string> = {
                  Policy: '/policies',
                  Audit: '/audits',
                  Training: '/compliance',
                };
                return (
                  <Link 
                    key={item.id} 
                    to={routeMap[item.type] || '/compliance'}
                    className="flex items-center justify-between py-4 border-b border-border last:border-b-0 cursor-pointer hover:bg-accent/50 transition-colors -mx-4 px-4"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                        <FileText className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{item.title}</p>
                        <div className="flex items-center gap-2 mt-1 text-sm">
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getTypeStyle(item.type)}`}>
                            {item.type}
                          </span>
                          <span className="text-muted-foreground flex items-center">
                            <Users className="h-3 w-3 mr-1" />
                            {item.owner}
                          </span>
                          <span className="text-muted-foreground flex items-center">
                            <Clock className="h-3 w-3 mr-1" />
                            {item.date}
                          </span>
                          <StatusBadge status={item.status} />
                        </div>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </Link>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Sidebar - Quick Stats & KPIs */}
        <div className="w-96 flex-shrink-0 space-y-6">
          {/* Quick Stats */}
          <div className="card-section">
            <h3 className="text-sm font-semibold text-foreground mb-4">Quick Stats</h3>
            <div className="divide-y divide-border">
              <QuickStatItem 
                icon={<FileText className="h-4 w-4" />} 
                label="Total" 
                value={dashboardMetrics.audits.total + dashboardMetrics.enforcements.total} 
                trend="+3"
              />
              <QuickStatItem 
                icon={<CheckCircle className="h-4 w-4" />} 
                label="Completed" 
                value={dashboardMetrics.audits.completed + dashboardMetrics.enforcements.completed} 
                trend="+5"
                variant="success"
              />
              <QuickStatItem 
                icon={<Clock className="h-4 w-4" />} 
                label="Pending" 
                value={dashboardMetrics.audits.pending + dashboardMetrics.enforcements.pending} 
                trend="-2"
                variant="warning"
              />
              <QuickStatItem 
                icon={<AlertTriangle className="h-4 w-4" />} 
                label="Overdue" 
                value={dashboardMetrics.audits.overdue + dashboardMetrics.enforcements.overdue} 
                trend="+1"
                variant="destructive"
              />
            </div>
          </div>

          {/* KPI Summary with CRUD */}
          <div className="card-section">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-foreground">Quality KPIs</h3>
              <Button size="sm" variant="ghost" onClick={handleAddKPI} className="h-7 px-2">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-3">
              {kpis.map((kpi) => {
                const status = getKPIStatus(kpi);
                const isLowerBetter = kpi.name.toLowerCase().includes('violation');
                const progress = isLowerBetter 
                  ? Math.max(0, 100 - (kpi.current * 10)) 
                  : Math.min(100, (kpi.current / kpi.target) * 100);
                
                return (
                  <div 
                    key={kpi.id} 
                    className="p-3 bg-muted/30 rounded-lg group cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => handleViewKPI(kpi)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-foreground truncate pr-2">{kpi.name}</span>
                      <div className="flex items-center gap-1">
                        <TrendIcon trend={kpi.trend} />
                        <div className="hidden group-hover:flex items-center gap-0.5">
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-6 w-6 p-0"
                            onClick={(e) => { e.stopPropagation(); handleViewKPI(kpi); }}
                          >
                            <Eye className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-6 w-6 p-0"
                            onClick={(e) => { e.stopPropagation(); handleEditKPI(kpi); }}
                          >
                            <Pencil className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-6 w-6 p-0 text-destructive hover:text-destructive"
                            onClick={(e) => { e.stopPropagation(); handleDeleteKPI(kpi); }}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-baseline gap-1 mb-2">
                      <span className="text-xl font-bold text-foreground">{kpi.current}</span>
                      <span className="text-sm text-muted-foreground">{kpi.unit}</span>
                      <span className="text-xs text-muted-foreground ml-auto">Target: {kpi.target}{kpi.unit}</span>
                    </div>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden mb-2">
                      <div
                        className={cn('h-full rounded-full transition-all', getStatusColor(status))}
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                    {kpi.calculation && (
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Calculator className="h-3 w-3" />
                        <span className="truncate">{kpi.calculation.formula}</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
      {/* Micro Apps Section */}
      <div className="mt-6">
        <h2 className="text-lg font-semibold text-foreground mb-4">Quick Access</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {microApps.map((app) => {
            const IconComponent = getIconComponent(app.icon);
            return (
              <Link
                key={app.id}
                to={app.route}
                className="bg-card rounded-xl border border-border p-4 hover:shadow-md hover:border-primary/20 transition-all group"
              >
                <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center mb-3', app.color)}>
                  <IconComponent className="h-5 w-5 text-white" />
                </div>
                <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">{app.name}</h3>
                <p className="text-xs text-muted-foreground mt-1">{app.description}</p>
              </Link>
            );
          })}
        </div>
      </div>

      {/* KPI Dialogs */}
      <KPIDialog
        open={kpiDialogOpen}
        onOpenChange={setKpiDialogOpen}
        kpi={selectedKPI}
        onSave={handleSaveKPI}
      />
      <ViewKPIDialog
        open={viewDialogOpen}
        onOpenChange={setViewDialogOpen}
        kpi={selectedKPI}
        onEdit={() => {
          setViewDialogOpen(false);
          setKpiDialogOpen(true);
        }}
      />
      <DeleteKPIDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        kpi={selectedKPI}
        onConfirm={handleConfirmDelete}
      />
      <ActionItemDialog
        open={actionItemDialogOpen}
        onOpenChange={setActionItemDialogOpen}
        onSelect={handleSelectMicroApp}
      />
    </MainLayout>
  );
}