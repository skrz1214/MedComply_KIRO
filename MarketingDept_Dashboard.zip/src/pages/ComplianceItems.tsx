import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { DataTable } from '@/components/dashboard/DataTable';
import { StatusBadge } from '@/components/dashboard/StatusBadge';
import { MetricCard } from '@/components/dashboard/MetricCard';
import { CheckCircle, Monitor, Clock, Smartphone, Printer } from 'lucide-react';
import { complianceItems, dashboardMetrics } from '@/data/mockData';
import { ComplianceItem } from '@/types/compliance';
import { useToast } from '@/hooks/use-toast';

export default function ComplianceItems() {
  const { toast } = useToast();
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);

  const categories = [...new Set(complianceItems.map((c) => c.category))];

  const filteredItems = complianceItems.filter((c) => {
    const matchesStatus = !statusFilter || c.status === statusFilter;
    const matchesCategory = !categoryFilter || c.category === categoryFilter;
    return matchesStatus && matchesCategory;
  });

  const columns = [
    { key: 'id' as keyof ComplianceItem, label: 'Compliance ID' },
    { key: 'description' as keyof ComplianceItem, label: 'Description' },
    { key: 'category' as keyof ComplianceItem, label: 'Category' },
    {
      key: 'status' as keyof ComplianceItem,
      label: 'Status',
      render: (item: ComplianceItem) => <StatusBadge status={item.status} />,
    },
    { key: 'owner' as keyof ComplianceItem, label: 'Owner' },
    { key: 'actions' as const, label: 'Actions' },
  ];

  const handleAction = (action: string, item: ComplianceItem) => {
    toast({
      title: `${action} - ComplianceConnect`,
      description: `Routing to ComplianceConnect for ${item.id}`,
    });
  };

  const handleRowClick = (item: ComplianceItem) => {
    toast({
      title: 'Opening in ComplianceConnect',
      description: `Routing to ComplianceConnect microapp for ${item.id}: ${item.description}`,
    });
  };

  return (
    <MainLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground">Compliance Tracking</h1>
        <p className="text-muted-foreground mt-1">
          Track and manage compliance items across all categories
        </p>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
        <MetricCard
          label="Total Items"
          value={complianceItems.length}
          icon={<CheckCircle className="h-5 w-5" />}
          onClick={() => { setStatusFilter(null); setCategoryFilter(null); }}
          isActive={statusFilter === null && categoryFilter === null}
        />
        <MetricCard
          label="Pending Review"
          value={complianceItems.filter((c) => c.status === 'pending').length}
          icon={<Clock className="h-5 w-5" />}
          variant="warning"
          onClick={() => { setStatusFilter('pending'); setCategoryFilter(null); }}
          isActive={statusFilter === 'pending'}
        />
        <MetricCard
          label="Digital Content"
          value={complianceItems.filter((c) => c.category === 'Digital Content').length}
          icon={<Monitor className="h-5 w-5" />}
          onClick={() => { setCategoryFilter('Digital Content'); setStatusFilter(null); }}
          isActive={categoryFilter === 'Digital Content'}
        />
        <MetricCard
          label="Digital Channels"
          value={complianceItems.filter((c) => c.category === 'Digital Channels').length}
          icon={<Smartphone className="h-5 w-5" />}
          onClick={() => { setCategoryFilter('Digital Channels'); setStatusFilter(null); }}
          isActive={categoryFilter === 'Digital Channels'}
        />
        <MetricCard
          label="Print Marketing"
          value={complianceItems.filter((c) => c.category === 'Print Marketing').length}
          icon={<Printer className="h-5 w-5" />}
          onClick={() => { setCategoryFilter('Print Marketing'); setStatusFilter(null); }}
          isActive={categoryFilter === 'Print Marketing'}
        />
      </div>

      {/* Category Filters */}
      <div className="flex flex-wrap gap-2 mb-6">
        <button
          onClick={() => setCategoryFilter(null)}
          className={`px-4 py-2 rounded-lg border text-sm transition-colors ${
            categoryFilter === null
              ? 'bg-accent text-accent-foreground border-accent'
              : 'bg-card text-foreground border-border hover:border-accent/50'
          }`}
        >
          All Categories
        </button>
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setCategoryFilter(category)}
            className={`px-4 py-2 rounded-lg border text-sm transition-colors ${
              categoryFilter === category
                ? 'bg-accent text-accent-foreground border-accent'
                : 'bg-card text-foreground border-border hover:border-accent/50'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Table */}
      <DataTable
        data={filteredItems}
        columns={columns}
        title="Compliance Registry"
        onAdd={() => handleAction('Add', { id: 'new' } as ComplianceItem)}
        onView={(item) => handleAction('View', item)}
        onEdit={(item) => handleAction('Edit', item)}
        onDelete={(item) => handleAction('Delete', item)}
        onRowClick={handleRowClick}
      />
    </MainLayout>
  );
}
