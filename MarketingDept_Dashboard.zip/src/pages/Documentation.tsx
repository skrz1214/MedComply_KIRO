import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, FileText, Printer } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

const prdContent = `
# ComplianceHub - Product Requirements Document
**Version 1.0 | December 2024**

## 1. Executive Summary
ComplianceHub is a comprehensive compliance management platform designed for the Marketing Division to track, manage, and ensure regulatory compliance across all marketing activities, materials, and campaigns.

## 2. Product Vision
To provide a centralized, intuitive platform that enables marketing teams to maintain compliance standards while streamlining workflows and reducing risk.

## 3. Target Users
- **Admin/Compliance Head**: Full system access, policy management, user administration
- **Department Heads**: Team management, approval workflows, reporting
- **Staff Members**: View-only access, task completion, feedback submission

## 4. Core Features

### 4.1 Dashboard
- Real-time metrics and KPIs
- Action Center with task management
- **Add Action Item**: Opens a micro app selector allowing users to quickly navigate to specialized compliance tools
- Quick actions and notifications
- Micro-app access for specialized tools

### 4.2 Org Chart
- Team structure visualization
- Role management and assignments

### 4.3 Risk Management
- Risk registry with severity levels
- Mitigation tracking and status updates

### 4.4 Audit Management
- Audit scheduling and tracking
- Findings documentation and remediation

### 4.5 Enforcement Management
- Regulatory actions tracking
- Deadline management and assignments

### 4.6 Compliance Tracking
- Item management by category
- Status monitoring and reporting

### 4.7 Feedback Management
- Issue reporting system
- Resolution tracking

## 5. User Roles and Permissions

| Role | Create | Read | Update | Delete | Manage Users |
|------|--------|------|--------|--------|--------------|
| Admin | ✓ | ✓ | ✓ | ✓ | ✓ |
| Department Head | ✓ | ✓ | ✓ | ✗ | ✗ |
| Staff | ✗ | ✓ | ✗ | ✗ | ✗ |

## 6. Success Metrics
- 95% compliance rate across all marketing materials
- 50% reduction in compliance-related incidents
- 30% improvement in audit response times
- 90% user adoption rate within 3 months

## 7. Technical Requirements
- React-based SPA with TypeScript
- Responsive design for desktop and tablet
- Role-based access control
- Real-time data synchronization
- Export capabilities for reports
`;

const tddContent = `
# ComplianceHub - Technical Design Document
**Version 1.0 | December 2024**

## 1. System Architecture

### Frontend Stack
- **Framework**: React 18.3 with TypeScript
- **Build System**: Vite
- **Styling**: Tailwind CSS with custom design tokens
- **State Management**: React Context API, TanStack Query
- **Routing**: React Router v6
- **UI Components**: Radix UI primitives with shadcn/ui

## 2. Component Architecture

### 2.1 Layout Components
- **MainLayout**: Primary application wrapper with sidebar and header
- **Sidebar**: Navigation with collapsible sections and documentation links
- **Header**: Breadcrumb, search, role switcher, notifications

### 2.2 Feature Components
- **Dashboard**: MetricCard, DataTable, MicroAppGrid, KPI management
- **ActionItemDialog**: Micro app selector for quick navigation to compliance tools
- **Management Pages**: CRUD dialogs, status badges, filtering

## 3. Role-Based Access Control

### Implementation
- **Provider**: React Context with RoleProvider
- **Hook**: useRole() for accessing current role and permissions

### Roles
| Role | ID | Permissions |
|------|-----|-------------|
| Admin | admin | Full access |
| Department Head | department_head | Create, Edit (no delete) |
| Staff | staff | View only |

### Permission Flags
- canEdit, canDelete, canCreate, canViewAll, canManageUsers

## 4. Data Models

\`\`\`typescript
interface TeamMember {
  id: string;
  name: string;
  role: string;
  department: string;
  email: string;
}

interface RiskItem {
  id: string;
  description: string;
  level: 'low' | 'medium' | 'high' | 'critical';
  status: string;
  owner: string;
  mitigationStrategy: string;
}

interface AuditItem {
  id: string;
  title: string;
  status: string;
  deadline: string;
  owner: string;
  priority: 'low' | 'medium' | 'high';
}

interface KPI {
  id: string;
  name: string;
  target: number;
  current: number;
  trend: 'up' | 'down' | 'stable';
  status: 'on-track' | 'at-risk' | 'off-track';
}
\`\`\`

## 5. Design System

### Color Tokens
- HSL-based semantic colors defined in index.css
- Dark/Light theme support via CSS variables

### Typography
- Font Family: IBM Plex Sans
- Scale: Tailwind default typography scale

### Components
- Customized shadcn/ui with project-specific variants

## 6. File Structure
\`\`\`
/src
  /components     - Reusable UI components
  /pages          - Route-level page components
  /contexts       - React Context providers
  /hooks          - Custom React hooks
  /data           - Mock data and fixtures
  /types          - TypeScript type definitions
\`\`\`

## 7. Performance Considerations
- Code splitting with React.lazy for route components
- Memoization of expensive computations
- Optimistic updates for better UX
- Efficient re-renders with proper key usage
`;

const qaContent = `
# ComplianceHub - QA Test Scenarios
**Version 1.0 | December 2024**

## 1. Authentication and Role Management

| ID | Test Case | Steps | Expected Result |
|----|-----------|-------|-----------------|
| TC-001 | Verify role switcher displays all roles | Open header dropdown | Shows Admin, Department Head, Staff options |
| TC-002 | Verify Admin role permissions | Switch to Admin > Attempt CRUD | All operations available |
| TC-003 | Verify Department Head permissions | Switch to Dept Head > Attempt delete | Delete button disabled/hidden |
| TC-004 | Verify Staff role is view-only | Switch to Staff > Check UI | No edit/delete buttons visible |
| TC-005 | Verify user profile updates | Switch roles > Check sidebar | Name and title update correctly |

## 2. Dashboard Functionality

| ID | Test Case | Steps | Expected Result |
|----|-----------|-------|-----------------|
| TC-010 | Verify metric cards display | Load Dashboard | All 6 metric cards show data |
| TC-011 | Verify KPI section | Load Dashboard | KPI list displays correctly |
| TC-012 | Verify Add KPI dialog | Click + button > Fill form | Dialog opens, validates, saves |
| TC-013 | Verify Edit KPI | Click edit on KPI > Modify | Values update correctly |
| TC-014 | Verify Delete KPI | Click delete > Confirm | Item removed with confirmation |
| TC-015 | Verify Quick Access navigation | Click micro-app card | Navigates to correct page |
| TC-016 | Verify Add Action Item | Click Add Action Item button | Micro app selector dialog opens |
| TC-017 | Verify micro app selection | Click micro app in dialog | Navigates to selected app route |

## 3. Risk Management

| ID | Test Case | Steps | Expected Result |
|----|-----------|-------|-----------------|
| TC-020 | Verify risk list display | Navigate to Risks | All items display in table |
| TC-021 | Verify risk creation | Add Risk > Fill form | New risk appears in list |
| TC-022 | Verify severity levels | View risk items | Correct color badges shown |
| TC-023 | Verify status updates | Edit risk status | Status persists after save |
| TC-024 | Verify risk deletion | Delete risk > Confirm | Item removed from list |
| TC-025 | Verify search/filter | Enter search term | List filters correctly |

## 4. Audit Management

| ID | Test Case | Steps | Expected Result |
|----|-----------|-------|-----------------|
| TC-030 | Verify audit list pagination | Load page with many items | Pagination controls work |
| TC-031 | Verify audit creation | Add Audit > Fill form | New audit in list |
| TC-032 | Verify deadline display | View audit items | Dates formatted correctly |
| TC-033 | Verify priority badges | View audit items | High/Med/Low badges correct |
| TC-034 | Verify owner assignment | Edit audit owner | Owner updates correctly |

## 5. Compliance Tracking

| ID | Test Case | Steps | Expected Result |
|----|-----------|-------|-----------------|
| TC-040 | Verify category display | Load Compliance page | Categories shown correctly |
| TC-041 | Verify status badges | View items | Colors match status |
| TC-042 | Verify CRUD operations | Create/Edit/Delete | All operations work |
| TC-043 | Verify category filter | Select category | List filters correctly |

## 6. Navigation and Layout

| ID | Test Case | Steps | Expected Result |
|----|-----------|-------|-----------------|
| TC-050 | Verify sidebar links | Click each nav item | All routes work |
| TC-051 | Verify section collapse | Click section header | Expands/collapses |
| TC-052 | Verify breadcrumb | Navigate deep | Breadcrumb updates |
| TC-053 | Verify responsive layout | Resize to tablet | Layout adapts |
| TC-054 | Verify doc downloads | Click doc links | Documents accessible |

## 7. Cross-Browser Testing

| ID | Browser | Test | Expected |
|----|---------|------|----------|
| TC-060 | Chrome | Full functionality | Pass |
| TC-061 | Firefox | Full functionality | Pass |
| TC-062 | Safari | Full functionality | Pass |
| TC-063 | Edge | Full functionality | Pass |

## 8. Performance Testing

| ID | Test Case | Criteria | Expected |
|----|-----------|----------|----------|
| TC-070 | Page load time | < 3 seconds | Pass |
| TC-071 | Table scrolling | Smooth 60fps | Pass |
| TC-072 | Dialog animations | No jank | Pass |
`;

const uatContent = `
# ComplianceHub - UAT Test Scenarios
**Version 1.0 | December 2024**

## 1. User Story: As a Compliance Head

### UAT-001: Dashboard Overview
**Scenario**: I can view the complete dashboard with all compliance metrics
| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Login as Admin | Dashboard loads |
| 2 | View Quick Stats | All 4 stat cards visible |
| 3 | View Quality KPIs | KPI list with current values |
| 4 | Check Action Center | Tasks and deadlines visible |
| 5 | Click Add Action Item | Micro app selector opens |
| 6 | Select a micro app | Navigates to selected app |

### UAT-002: KPI Management
**Scenario**: I can manage KPIs for compliance tracking
| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Click + Add KPI | Dialog opens |
| 2 | Enter KPI details | Form validates input |
| 3 | Click Save | KPI appears in list |
| 4 | Click Edit | Can modify values |
| 5 | Click Delete | Confirmation, then removed |

### UAT-003: Full System Access
**Scenario**: I can access all management modules
| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Navigate to each module | All pages load |
| 2 | Perform CRUD operations | All work correctly |
| 3 | View documentation | All docs accessible |

---

## 2. User Story: As a Department Head

### UAT-010: Department View
**Scenario**: I can view my department's compliance status
| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Switch to Department Head | Role updates in UI |
| 2 | View Dashboard | Relevant metrics shown |
| 3 | Navigate modules | Data displays correctly |

### UAT-011: Limited Edit Access
**Scenario**: I can create and edit but not delete
| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Create new item | Item created successfully |
| 2 | Edit existing item | Changes saved |
| 3 | Attempt delete | Delete not available |

---

## 3. User Story: As a Staff Member

### UAT-020: View-Only Access
**Scenario**: I can view all compliance information
| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Switch to Staff role | Role updates |
| 2 | Navigate all pages | Data visible |
| 3 | Look for edit buttons | None available |

### UAT-021: Read-Only Confirmation
**Scenario**: I cannot modify any records
| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | View any list | No Add button |
| 2 | Click any item | View only, no edit |
| 3 | Check all modules | Consistent behavior |

---

## 4. User Story: Document Access

### UAT-030: Documentation Availability
**Scenario**: I can access all project documentation
| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Click Documentation nav | Page loads |
| 2 | View PRD tab | Content displays |
| 3 | View TDD tab | Content displays |
| 4 | View QA tab | Content displays |
| 5 | View UAT tab | Content displays |
| 6 | Click Print/Download | Print dialog opens |

---

## 5. Acceptance Criteria Summary

### Functional Requirements
- [ ] All user roles function as specified
- [ ] Navigation is intuitive and consistent
- [ ] Data displays accurately across modules
- [ ] CRUD operations work for authorized users
- [ ] Documents are accessible and printable

### Non-Functional Requirements
- [ ] Application loads within 3 seconds
- [ ] Responsive on desktop and tablet
- [ ] Consistent styling throughout
- [ ] No console errors during normal use

### Sign-Off
| Role | Name | Date | Signature |
|------|------|------|-----------|
| Product Owner | | | |
| QA Lead | | | |
| Dev Lead | | | |
| Business Stakeholder | | | |
`;

const systemsPromptContent = `
# ComplianceHub - Systems Prompt
**Version 1.0 | December 2024**

## 1. System Overview

You are ComplianceHub, an intelligent compliance management assistant for the Marketing Division. Your primary function is to help users navigate, manage, and maintain regulatory compliance across all marketing activities.

## 2. Core Identity

### 2.1 Name and Role
- **Name**: ComplianceHub Assistant
- **Role**: Compliance Management AI
- **Domain**: Marketing Regulatory Compliance

### 2.2 Personality Traits
- Professional and precise
- Helpful and proactive
- Risk-aware and cautious
- Clear and concise in communication

## 3. User Roles and Permissions

### 3.1 Admin/Compliance Head
**Access Level**: Full System Access
- Create, read, update, delete all records
- Manage user roles and permissions
- Access all reports and analytics
- Configure system settings
- Approve policy changes

### 3.2 Department Head
**Access Level**: Department Scope
- Create and edit records within department
- View all department compliance data
- Cannot delete records
- Cannot manage users
- Limited to department reports

### 3.3 Staff Member
**Access Level**: View Only
- Read-only access to compliance data
- Submit feedback and issues
- View assigned tasks
- Cannot modify any records

## 4. Module Capabilities

### 4.1 Dashboard
**Purpose**: Central command center for compliance overview
- Display real-time metrics and KPIs
- Show action items and deadlines
- Provide quick access to micro-apps
- Alert on critical compliance issues

### 4.2 Risk Management
**Purpose**: Identify, assess, and mitigate compliance risks
- Register and categorize risks
- Assign severity levels (Low, Medium, High, Critical)
- Track mitigation strategies
- Monitor risk status and trends

### 4.3 Audit Management
**Purpose**: Plan, execute, and document compliance audits
- Schedule internal and external audits
- Document findings and observations
- Track remediation actions
- Manage audit priorities

### 4.4 Enforcement Tracking
**Purpose**: Monitor regulatory actions and deadlines
- Track enforcement actions
- Manage response deadlines
- Assign responsible parties
- Document resolution steps

### 4.5 Compliance Items
**Purpose**: Manage compliance requirements by category
- Categorize compliance items
- Track status and progress
- Document evidence
- Monitor due dates

### 4.6 Org Chart
**Purpose**: Visualize team structure and responsibilities
- Display organizational hierarchy
- Show role assignments
- Track compliance responsibilities
- Facilitate communication

### 4.7 Feedback Management
**Purpose**: Collect and resolve compliance-related issues
- Submit and track feedback
- Categorize by type and priority
- Monitor resolution progress
- Document resolutions

## 5. Response Guidelines

### 5.1 General Principles
- Always verify user role before providing information
- Never expose data outside user's permission scope
- Provide accurate, up-to-date compliance information
- Escalate critical issues immediately
- Document all significant interactions

### 5.2 Compliance Queries
When responding to compliance queries:
1. Identify the specific compliance area
2. Check relevant regulations and policies
3. Provide clear, actionable guidance
4. Reference official documentation when available
5. Flag any potential risks or concerns

### 5.3 Risk Assessment
When assessing risks:
1. Evaluate severity based on impact and likelihood
2. Consider regulatory implications
3. Identify affected stakeholders
4. Recommend appropriate mitigation measures
5. Set appropriate monitoring frequency

### 5.4 Audit Support
When supporting audits:
1. Provide accurate historical data
2. Document evidence trails
3. Highlight areas of concern
4. Track remediation progress
5. Generate compliance reports

## 6. Data Handling

### 6.1 Data Classification
- **Public**: General compliance guidelines
- **Internal**: Department-specific procedures
- **Confidential**: Audit findings, risk assessments
- **Restricted**: Enforcement actions, legal matters

### 6.2 Data Retention
- Compliance records: 7 years minimum
- Audit documentation: 10 years
- Risk assessments: Current + 3 years
- Feedback records: 2 years

### 6.3 Privacy Considerations
- Protect personally identifiable information
- Anonymize data in reports when possible
- Follow data protection regulations
- Limit access based on need-to-know

## 7. Integration Points

### 7.1 Micro-Apps
- Quick access compliance tools
- Specialized functions per module
- Contextual navigation
- Role-based availability

### 7.2 Reporting
- Generate compliance reports on demand
- Support multiple export formats
- Include data visualizations
- Enable scheduled reports

### 7.3 Notifications
- Alert on approaching deadlines
- Notify of status changes
- Escalate critical issues
- Remind of pending actions

## 8. Error Handling

### 8.1 User Errors
- Provide clear error messages
- Suggest corrective actions
- Maintain data integrity
- Log for audit purposes

### 8.2 System Errors
- Fail gracefully without data loss
- Notify appropriate personnel
- Provide fallback options
- Document for troubleshooting

## 9. Continuous Improvement

### 9.1 Feedback Loop
- Collect user feedback regularly
- Analyze usage patterns
- Identify improvement opportunities
- Implement enhancements iteratively

### 9.2 Compliance Updates
- Monitor regulatory changes
- Update policies promptly
- Communicate changes effectively
- Train users on new requirements

## 10. Version Control

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | December 2024 | Compliance Team | Initial release |

---

**Document Owner**: Compliance Head
**Review Cycle**: Quarterly
**Next Review**: March 2025
`;

export default function Documentation() {
  const [activeTab, setActiveTab] = useState('prd');

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const docs = [
    { id: 'prd', label: 'PRD', content: prdContent, filename: 'ComplianceHub_PRD.md' },
    { id: 'tdd', label: 'TDD', content: tddContent, filename: 'ComplianceHub_TDD.md' },
    { id: 'qa', label: 'QA Tests', content: qaContent, filename: 'ComplianceHub_QA.md' },
    { id: 'uat', label: 'UAT Tests', content: uatContent, filename: 'ComplianceHub_UAT.md' },
    { id: 'systems', label: 'Systems Prompt', content: systemsPromptContent, filename: 'ComplianceHub_SystemsPrompt.md' },
  ];

  const currentDoc = docs.find(d => d.id === activeTab) || docs[0];

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Project Documentation</h1>
            <p className="text-muted-foreground">PRD, TDD, QA and UAT documents</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handlePrint}>
              <Printer className="h-4 w-4 mr-2" />
              Print
            </Button>
            <Button onClick={() => handleDownload(currentDoc.content, currentDoc.filename)}>
              <Download className="h-4 w-4 mr-2" />
              Download {currentDoc.label}
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5">
            {docs.map(doc => (
              <TabsTrigger key={doc.id} value={doc.id} className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                {doc.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {docs.map(doc => (
            <TabsContent key={doc.id} value={doc.id}>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    {doc.label} Document
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[600px] pr-4">
                    <div className="prose prose-sm dark:prose-invert max-w-none">
                      <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed">
                        {doc.content}
                      </pre>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </MainLayout>
  );
}
