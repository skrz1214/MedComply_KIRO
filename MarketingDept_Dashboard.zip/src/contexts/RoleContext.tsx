import { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'admin' | 'department_head' | 'staff';

interface RoleConfig {
  label: string;
  title: string;
  initials: string;
  permissions: {
    canEdit: boolean;
    canDelete: boolean;
    canCreate: boolean;
    canViewAll: boolean;
    canManageUsers: boolean;
  };
}

export const roleConfigs: Record<UserRole, RoleConfig> = {
  admin: {
    label: 'Admin / Compliance Head',
    title: 'Chief Compliance Officer',
    initials: 'SC',
    permissions: {
      canEdit: true,
      canDelete: true,
      canCreate: true,
      canViewAll: true,
      canManageUsers: true,
    },
  },
  department_head: {
    label: 'Department Head',
    title: 'Marketing Director',
    initials: 'JD',
    permissions: {
      canEdit: true,
      canDelete: false,
      canCreate: true,
      canViewAll: false,
      canManageUsers: false,
    },
  },
  staff: {
    label: 'Staff (View Only)',
    title: 'Marketing Specialist',
    initials: 'TM',
    permissions: {
      canEdit: false,
      canDelete: false,
      canCreate: false,
      canViewAll: false,
      canManageUsers: false,
    },
  },
};

interface RoleContextType {
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  roleConfig: RoleConfig;
  hasPermission: (permission: keyof RoleConfig['permissions']) => boolean;
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export function RoleProvider({ children }: { children: ReactNode }) {
  const [currentRole, setCurrentRole] = useState<UserRole>('admin');

  const roleConfig = roleConfigs[currentRole];

  const hasPermission = (permission: keyof RoleConfig['permissions']) => {
    return roleConfig.permissions[permission];
  };

  return (
    <RoleContext.Provider value={{ currentRole, setCurrentRole, roleConfig, hasPermission }}>
      {children}
    </RoleContext.Provider>
  );
}

export function useRole(): RoleContextType {
  const context = useContext(RoleContext);
  if (context === undefined) {
    throw new Error('useRole must be used within a RoleProvider');
  }
  return context;
}
