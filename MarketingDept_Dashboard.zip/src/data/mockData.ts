import { TeamMember, Policy, AuditItem, Enforcement, RiskItem, ComplianceItem, PrintMarketing, MicroApp } from '@/types/compliance';

export const teamMembers: TeamMember[] = [
  { id: '1', name: 'Sarah Chen', role: 'Chief Compliance Officer', department: 'Marketing Compliance', email: 'sarah.chen@company.com', avatar: '' },
  { id: '2', name: 'Michael Torres', role: 'Senior Compliance Manager', department: 'Marketing Compliance', email: 'michael.torres@company.com', reportsTo: '1' },
  { id: '3', name: 'Emily Watson', role: 'HIPAA Compliance Lead', department: 'Marketing Compliance', email: 'emily.watson@company.com', reportsTo: '2' },
  { id: '4', name: 'David Kim', role: 'Digital Content Analyst', department: 'Marketing Compliance', email: 'david.kim@company.com', reportsTo: '2' },
  { id: '5', name: 'Jessica Brown', role: 'Policy Administrator', department: 'Marketing Compliance', email: 'jessica.brown@company.com', reportsTo: '2' },
  { id: '6', name: 'Robert Garcia', role: 'Audit Coordinator', department: 'Marketing Compliance', email: 'robert.garcia@company.com', reportsTo: '2' },
  { id: '7', name: 'Amanda Lee', role: 'Risk Analyst', department: 'Marketing Compliance', email: 'amanda.lee@company.com', reportsTo: '3' },
  { id: '8', name: 'James Wilson', role: 'Print Compliance Specialist', department: 'Marketing Compliance', email: 'james.wilson@company.com', reportsTo: '4' },
];

export const policies: Policy[] = [
  { id: 'POL-001', name: 'HIPAA Marketing Guidelines', category: 'Privacy', lastUpdated: '2024-12-01', status: 'active', nextUpdate: '2025-06-01', owner: 'Sarah Chen' },
  { id: 'POL-002', name: 'Digital Advertising Standards', category: 'Digital', lastUpdated: '2024-11-15', status: 'active', nextUpdate: '2025-05-15', owner: 'Michael Torres' },
  { id: 'POL-003', name: 'Social Media Compliance', category: 'Digital', lastUpdated: '2024-10-20', status: 'pending', nextUpdate: '2025-01-20', owner: 'David Kim' },
  { id: 'POL-004', name: 'Print Distribution Protocol', category: 'Print', lastUpdated: '2024-09-10', status: 'active', nextUpdate: '2025-03-10', owner: 'James Wilson' },
  { id: 'POL-005', name: 'Patient Testimonial Guidelines', category: 'Privacy', lastUpdated: '2024-08-25', status: 'overdue', nextUpdate: '2024-12-25', owner: 'Emily Watson' },
  { id: 'POL-006', name: 'ADAA Compliance Framework', category: 'Legal', lastUpdated: '2024-12-10', status: 'active', nextUpdate: '2025-06-10', owner: 'Sarah Chen' },
];

export const auditItems: AuditItem[] = [
  { id: 'AUD-001', title: 'Q4 Digital Campaign Review', status: 'pending', deadline: '2024-12-30', owner: 'Robert Garcia', priority: 'high' },
  { id: 'AUD-002', title: 'Annual HIPAA Assessment', status: 'completed', deadline: '2024-12-15', owner: 'Emily Watson', priority: 'high' },
  { id: 'AUD-003', title: 'Social Media Audit', status: 'pending', deadline: '2025-01-15', owner: 'David Kim', priority: 'medium' },
  { id: 'AUD-004', title: 'Print Materials Compliance Check', status: 'overdue', deadline: '2024-12-10', owner: 'James Wilson', priority: 'high' },
  { id: 'AUD-005', title: 'Email Marketing Review', status: 'completed', deadline: '2024-11-30', owner: 'Michael Torres', priority: 'medium' },
  { id: 'AUD-006', title: 'Third-Party Vendor Assessment', status: 'pending', deadline: '2025-02-01', owner: 'Sarah Chen', priority: 'low' },
];

export const enforcements: Enforcement[] = [
  { id: 'ENF-001', title: 'Unauthorized Claim Removal', status: 'completed', dueDate: '2024-12-05', owner: 'Michael Torres', priority: 'high' },
  { id: 'ENF-002', title: 'Privacy Policy Update Rollout', status: 'pending', dueDate: '2024-12-28', owner: 'Emily Watson', priority: 'high' },
  { id: 'ENF-003', title: 'Social Media Post Correction', status: 'completed', dueDate: '2024-12-01', owner: 'David Kim', priority: 'medium' },
  { id: 'ENF-004', title: 'Print Recall - Outdated Info', status: 'overdue', dueDate: '2024-12-15', owner: 'James Wilson', priority: 'high' },
  { id: 'ENF-005', title: 'Landing Page Disclaimer Addition', status: 'pending', dueDate: '2025-01-10', owner: 'David Kim', priority: 'medium' },
];

export const riskItems: RiskItem[] = [
  { id: 'RSK-001', description: 'PHI exposure in testimonial videos', level: 'high', status: 'pending', owner: 'Emily Watson', mitigationStrategy: 'Implement review workflow' },
  { id: 'RSK-002', description: 'Non-compliant third-party ad network', level: 'high', status: 'active', owner: 'David Kim', mitigationStrategy: 'Vendor assessment required' },
  { id: 'RSK-003', description: 'Outdated consent forms in campaigns', level: 'medium', status: 'completed', owner: 'Jessica Brown', mitigationStrategy: 'Forms updated Q4' },
  { id: 'RSK-004', description: 'Social media auto-response PHI risk', level: 'medium', status: 'pending', owner: 'David Kim', mitigationStrategy: 'Disable auto-responses' },
  { id: 'RSK-005', description: 'Print distribution tracking gap', level: 'low', status: 'active', owner: 'James Wilson', mitigationStrategy: 'Implement tracking system' },
];

export const complianceItems: ComplianceItem[] = [
  { id: 'CMP-001', description: 'HIPAA Training Completion - Marketing Team', status: 'completed', owner: 'Sarah Chen', category: 'Training' },
  { id: 'CMP-002', description: 'Q4 Compliance Report Submission', status: 'pending', owner: 'Michael Torres', category: 'Reporting' },
  { id: 'CMP-003', description: 'Digital Channel Privacy Review', status: 'active', owner: 'David Kim', category: 'Privacy' },
  { id: 'CMP-004', description: 'Annual Policy Acknowledgment', status: 'overdue', owner: 'Jessica Brown', category: 'Governance' },
  { id: 'CMP-005', description: 'Vendor Compliance Certification', status: 'pending', owner: 'Robert Garcia', category: 'Vendor Management' },
  // Digital Content items
  { id: 'DC-001', description: 'Holiday Health Campaign (Multi-channel)', status: 'active', owner: 'David Kim', category: 'Digital Content' },
  { id: 'DC-002', description: 'Patient Success Story Video (YouTube)', status: 'pending', owner: 'Emily Watson', category: 'Digital Content' },
  { id: 'DC-003', description: 'Facebook Lead Gen Ads', status: 'completed', owner: 'David Kim', category: 'Digital Content' },
  { id: 'DC-004', description: 'Twitter Health Tips Series', status: 'active', owner: 'David Kim', category: 'Digital Content' },
  { id: 'DC-005', description: 'Email Newsletter Q4', status: 'overdue', owner: 'Michael Torres', category: 'Digital Content' },
  // Digital Channels items
  { id: 'DCH-001', description: 'Facebook - Social Media Channel', status: 'active', owner: 'David Kim', category: 'Digital Channels' },
  { id: 'DCH-002', description: 'Twitter/X - Social Media Channel', status: 'active', owner: 'David Kim', category: 'Digital Channels' },
  { id: 'DCH-003', description: 'Instagram - Social Media Channel', status: 'pending', owner: 'David Kim', category: 'Digital Channels' },
  { id: 'DCH-004', description: 'Email Marketing Platform', status: 'completed', owner: 'Michael Torres', category: 'Digital Channels' },
  { id: 'DCH-005', description: 'SEO & SEM Compliance', status: 'active', owner: 'David Kim', category: 'Digital Channels' },
  // Print Marketing items
  { id: 'PM-001', description: 'Patient Welcome Brochure', status: 'active', owner: 'Sarah Chen', category: 'Print Marketing' },
  { id: 'PM-002', description: 'Service Directory 2025', status: 'pending', owner: 'James Wilson', category: 'Print Marketing' },
  { id: 'PM-003', description: 'Health Fair Flyers', status: 'completed', owner: 'Michael Torres', category: 'Print Marketing' },
  { id: 'PM-004', description: 'Insurance Plan Comparison Guide', status: 'overdue', owner: 'James Wilson', category: 'Print Marketing' },
];

export const printMarketing: PrintMarketing[] = [
  { id: 'PM-001', name: 'Patient Welcome Brochure', type: 'Brochure', status: 'active', distributionDate: '2024-12-01', approvedBy: 'Sarah Chen', archived: false },
  { id: 'PM-002', name: 'Service Directory 2025', type: 'Directory', status: 'pending', distributionDate: '2025-01-15', archived: false },
  { id: 'PM-003', name: 'Health Fair Flyers', type: 'Flyer', status: 'completed', distributionDate: '2024-11-15', approvedBy: 'Michael Torres', archived: true },
  { id: 'PM-004', name: 'Insurance Plan Comparison', type: 'Guide', status: 'overdue', distributionDate: '2024-12-10', archived: false },
];

export const microApps: MicroApp[] = [
  { id: 'cc', name: 'ComplianceConnect', description: 'Compliance management hub', icon: 'shield-check', route: '/apps/compliance-connect', color: 'bg-info' },
  { id: 'fh', name: 'FeedbackHub', description: 'Stakeholder feedback system', icon: 'message-square', route: '/apps/feedback-hub', color: 'bg-success' },
  { id: 'rg', name: 'RiskGuard', description: 'Risk assessment platform', icon: 'alert-triangle', route: '/apps/risk-guard', color: 'bg-warning' },
  { id: 'ap', name: 'AuditPro', description: 'Audit management system', icon: 'clipboard-check', route: '/apps/audit-pro', color: 'bg-accent' },
  { id: 'ep', name: 'EnforcePoint', description: 'Enforcement tracking', icon: 'gavel', route: '/apps/enforce-point', color: 'bg-destructive' },
];

export const dashboardMetrics = {
  audits: { total: 24, pending: 8, completed: 14, overdue: 2 },
  enforcements: { total: 18, pending: 5, completed: 11, overdue: 2 },
  risks: { total: 15, high: 4, medium: 6, low: 5 },
  compliance: { total: 32, pending: 10, completed: 18, overdue: 4 },
  policies: { total: 45, active: 38, pending: 5, overdue: 2 },
  digitalContent: { total: 156, approved: 142, pending: 10, flagged: 4 },
  printMarketing: { total: 28, approved: 22, pending: 4, archived: 2 },
};
