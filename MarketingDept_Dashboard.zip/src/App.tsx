import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { RoleProvider } from "@/contexts/RoleContext";
import Dashboard from "./pages/Dashboard";
import OrgChart from "./pages/OrgChart";
import Audits from "./pages/Audits";
import Enforcements from "./pages/Enforcements";
import Risks from "./pages/Risks";
import ComplianceItems from "./pages/ComplianceItems";
import FeedbackItems from "./pages/FeedbackItems";
import MicroAppPage from "./pages/MicroAppPage";
import Documentation from "./pages/Documentation";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <RoleProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/org-chart" element={<OrgChart />} />
            <Route path="/audits" element={<Audits />} />
            <Route path="/enforcements" element={<Enforcements />} />
            <Route path="/risks" element={<Risks />} />
            <Route path="/compliance" element={<ComplianceItems />} />
            <Route path="/feedback" element={<FeedbackItems />} />
            <Route path="/documentation" element={<Documentation />} />
            <Route path="/apps/:appId" element={<MicroAppPage />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </RoleProvider>
  </QueryClientProvider>
);

export default App;
