import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { RiskItem } from '@/types/compliance';
import { StatusBadge, RiskLevelBadge } from '@/components/dashboard/StatusBadge';
import { AlertTriangle, User, Shield, FileText } from 'lucide-react';

interface ViewRiskDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  risk: RiskItem | null;
  onEdit: () => void;
}

export function ViewRiskDialog({ open, onOpenChange, risk, onEdit }: ViewRiskDialogProps) {
  if (!risk) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-warning" />
            Risk Details
          </DialogTitle>
        </DialogHeader>
        <div className="py-4 space-y-6">
          {/* Header Info */}
          <div>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{risk.id}</p>
                <h2 className="text-lg font-semibold text-foreground mt-1">{risk.description}</h2>
              </div>
              <RiskLevelBadge level={risk.level} />
            </div>
          </div>

          {/* Details Grid */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
              <Shield className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Status</p>
                <div className="mt-1">
                  <StatusBadge status={risk.status} />
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
              <User className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Owner</p>
                <p className="text-sm font-medium text-foreground">{risk.owner}</p>
              </div>
            </div>
          </div>

          {/* Mitigation Strategy */}
          {risk.mitigationStrategy && (
            <div className="p-4 bg-muted/30 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <FileText className="h-4 w-4 text-muted-foreground" />
                <h3 className="text-sm font-semibold text-foreground">Mitigation Strategy</h3>
              </div>
              <p className="text-sm text-muted-foreground">{risk.mitigationStrategy}</p>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-2 pt-4 border-t border-border">
            <Button variant="outline" className="flex-1" onClick={() => onOpenChange(false)}>
              Close
            </Button>
            <Button className="flex-1" onClick={onEdit}>
              Edit Risk
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
