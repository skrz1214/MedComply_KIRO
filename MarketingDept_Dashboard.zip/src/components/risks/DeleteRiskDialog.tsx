import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { RiskItem } from '@/types/compliance';

interface DeleteRiskDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  risk: RiskItem | null;
  onConfirm: () => void;
}

export function DeleteRiskDialog({
  open,
  onOpenChange,
  risk,
  onConfirm,
}: DeleteRiskDialogProps) {
  if (!risk) return null;

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete Risk</AlertDialogTitle>
          <AlertDialogDescription>
            Are you sure you want to delete risk <strong>{risk.id}</strong>?
            <span className="block mt-2 text-muted-foreground">
              "{risk.description}"
            </span>
            <span className="block mt-2">
              This action cannot be undone.
            </span>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={onConfirm}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
