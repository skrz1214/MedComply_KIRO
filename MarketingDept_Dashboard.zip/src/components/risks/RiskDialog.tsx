import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { RiskItem } from '@/types/compliance';

const riskSchema = z.object({
  description: z.string().trim().min(1, 'Description is required').max(500, 'Description must be less than 500 characters'),
  level: z.enum(['high', 'medium', 'low']),
  status: z.enum(['active', 'pending', 'completed']),
  owner: z.string().trim().min(1, 'Owner is required').max(100, 'Owner must be less than 100 characters'),
  mitigationStrategy: z.string().max(1000, 'Mitigation strategy must be less than 1000 characters').optional(),
});

type RiskFormData = z.infer<typeof riskSchema>;

interface RiskDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  risk?: RiskItem | null;
  onSave: (data: RiskFormData & { id?: string }) => void;
}

export function RiskDialog({ open, onOpenChange, risk, onSave }: RiskDialogProps) {
  const isEditing = !!risk;

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<RiskFormData>({
    resolver: zodResolver(riskSchema),
    defaultValues: {
      description: '',
      level: 'medium',
      status: 'pending',
      owner: '',
      mitigationStrategy: '',
    },
  });

  const level = watch('level');
  const status = watch('status');

  useEffect(() => {
    if (risk) {
      reset({
        description: risk.description,
        level: risk.level,
        status: risk.status as 'active' | 'pending' | 'completed',
        owner: risk.owner,
        mitigationStrategy: risk.mitigationStrategy || '',
      });
    } else {
      reset({
        description: '',
        level: 'medium',
        status: 'pending',
        owner: '',
        mitigationStrategy: '',
      });
    }
  }, [risk, reset]);

  const onSubmit = (data: RiskFormData) => {
    onSave({
      ...data,
      id: risk?.id,
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{isEditing ? 'Edit Risk' : 'Add New Risk'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="description">Risk Description *</Label>
            <Textarea
              id="description"
              placeholder="Describe the risk..."
              rows={3}
              {...register('description')}
              className={errors.description ? 'border-destructive' : ''}
            />
            {errors.description && (
              <p className="text-sm text-destructive">{errors.description.message}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="level">Risk Level *</Label>
              <Select
                value={level}
                onValueChange={(value: 'high' | 'medium' | 'low') => setValue('level', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select
                value={status}
                onValueChange={(value: 'active' | 'pending' | 'completed') => setValue('status', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="owner">Owner *</Label>
            <Input
              id="owner"
              placeholder="Risk owner name"
              {...register('owner')}
              className={errors.owner ? 'border-destructive' : ''}
            />
            {errors.owner && (
              <p className="text-sm text-destructive">{errors.owner.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="mitigationStrategy">Mitigation Strategy</Label>
            <Textarea
              id="mitigationStrategy"
              placeholder="Describe the mitigation strategy..."
              rows={2}
              {...register('mitigationStrategy')}
            />
          </div>

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isEditing ? 'Update Risk' : 'Create Risk'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
