import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calculator } from 'lucide-react';

export interface KPICalculation {
  numerator: number;
  denominator: number;
  numeratorLabel: string;
  denominatorLabel: string;
  formula: string;
  guidance: string;
}

export interface KPI {
  id: string;
  name: string;
  current: number;
  target: number;
  unit: string;
  trend: 'up' | 'down' | 'neutral';
  periodicity: string;
  category: string;
  calculation?: KPICalculation;
}

const kpiSchema = z.object({
  name: z.string().min(1, 'Name is required').max(100),
  target: z.number().min(0, 'Target must be positive'),
  unit: z.string().min(1, 'Unit is required'),
  trend: z.enum(['up', 'down', 'neutral']),
  periodicity: z.string().min(1, 'Periodicity is required'),
  category: z.string().min(1, 'Category is required'),
  numerator: z.number().min(0, 'Numerator must be positive'),
  denominator: z.number().min(1, 'Denominator must be at least 1'),
  numeratorLabel: z.string().min(1, 'Numerator label is required').max(200),
  denominatorLabel: z.string().min(1, 'Denominator label is required').max(200),
  formula: z.string().min(1, 'Formula is required').max(200),
  guidance: z.string().max(500).optional(),
});

type KPIFormData = z.infer<typeof kpiSchema>;

interface KPIDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  kpi: KPI | null;
  onSave: (data: Omit<KPI, 'id'> & { id?: string }) => void;
}

export function KPIDialog({ open, onOpenChange, kpi, onSave }: KPIDialogProps) {
  const {
    register,
    handleSubmit,
    reset,
    setValue,
    watch,
    formState: { errors },
  } = useForm<KPIFormData>({
    resolver: zodResolver(kpiSchema),
    defaultValues: {
      name: '',
      target: 100,
      unit: '%',
      trend: 'neutral',
      periodicity: 'Monthly',
      category: 'Marketing Compliance',
      numerator: 0,
      denominator: 100,
      numeratorLabel: '',
      denominatorLabel: '',
      formula: '(Numerator ÷ Denominator) × 100',
      guidance: '',
    },
  });

  const numerator = watch('numerator');
  const denominator = watch('denominator');
  const unit = watch('unit');

  // Calculate current value automatically
  const calculatedValue = denominator > 0 
    ? unit === '%' 
      ? Math.round((numerator / denominator) * 100) 
      : Math.round((numerator / denominator) * 10) / 10
    : 0;

  useEffect(() => {
    if (kpi) {
      reset({
        name: kpi.name,
        target: kpi.target,
        unit: kpi.unit,
        trend: kpi.trend,
        periodicity: kpi.periodicity,
        category: kpi.category,
        numerator: kpi.calculation?.numerator ?? 0,
        denominator: kpi.calculation?.denominator ?? 100,
        numeratorLabel: kpi.calculation?.numeratorLabel ?? '',
        denominatorLabel: kpi.calculation?.denominatorLabel ?? '',
        formula: kpi.calculation?.formula ?? '(Numerator ÷ Denominator) × 100',
        guidance: kpi.calculation?.guidance ?? '',
      });
    } else {
      reset({
        name: '',
        target: 100,
        unit: '%',
        trend: 'neutral',
        periodicity: 'Monthly',
        category: 'Marketing Compliance',
        numerator: 0,
        denominator: 100,
        numeratorLabel: '',
        denominatorLabel: '',
        formula: '(Numerator ÷ Denominator) × 100',
        guidance: '',
      });
    }
  }, [kpi, reset]);

  const onSubmit = (data: KPIFormData) => {
    const current = data.denominator > 0 
      ? data.unit === '%' 
        ? Math.round((data.numerator / data.denominator) * 100) 
        : Math.round((data.numerator / data.denominator) * 10) / 10
      : 0;

    onSave({
      id: kpi?.id,
      name: data.name,
      current,
      target: data.target,
      unit: data.unit,
      trend: data.trend,
      periodicity: data.periodicity,
      category: data.category,
      calculation: {
        numerator: data.numerator,
        denominator: data.denominator,
        numeratorLabel: data.numeratorLabel,
        denominatorLabel: data.denominatorLabel,
        formula: data.formula,
        guidance: data.guidance || '',
      },
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{kpi ? 'Edit KPI' : 'Add KPI'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {/* Basic Info */}
          <div className="space-y-2">
            <Label htmlFor="name">KPI Name</Label>
            <Input id="name" {...register('name')} placeholder="e.g., Content Compliance Rate" />
            {errors.name && <p className="text-sm text-destructive">{errors.name.message}</p>}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="target">Target Value</Label>
              <Input
                id="target"
                type="number"
                {...register('target', { valueAsNumber: true })}
              />
              {errors.target && <p className="text-sm text-destructive">{errors.target.message}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="unit">Unit</Label>
              <Select value={watch('unit')} onValueChange={(value) => setValue('unit', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select unit" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="%">Percentage (%)</SelectItem>
                  <SelectItem value="count">Count</SelectItem>
                  <SelectItem value="days">Days</SelectItem>
                  <SelectItem value="hours">Hours</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="trend">Trend</Label>
              <Select value={watch('trend')} onValueChange={(value: 'up' | 'down' | 'neutral') => setValue('trend', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select trend" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="up">Trending Up</SelectItem>
                  <SelectItem value="down">Trending Down</SelectItem>
                  <SelectItem value="neutral">Neutral</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="periodicity">Periodicity</Label>
              <Select value={watch('periodicity')} onValueChange={(value) => setValue('periodicity', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select periodicity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Daily">Daily</SelectItem>
                  <SelectItem value="Weekly">Weekly</SelectItem>
                  <SelectItem value="Monthly">Monthly</SelectItem>
                  <SelectItem value="Quarterly">Quarterly</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Calculation Section */}
          <div className="border-t border-border pt-4 mt-4">
            <div className="flex items-center gap-2 mb-4">
              <Calculator className="h-4 w-4 text-primary" />
              <h3 className="font-medium text-foreground">Calculation</h3>
            </div>

            <div className="space-y-2 mb-4">
              <Label htmlFor="formula">Formula</Label>
              <Input id="formula" {...register('formula')} placeholder="e.g., (Compliant Items ÷ Total Items) × 100" />
              {errors.formula && <p className="text-sm text-destructive">{errors.formula.message}</p>}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="numerator">Numerator Value</Label>
                <Input
                  id="numerator"
                  type="number"
                  {...register('numerator', { valueAsNumber: true })}
                />
                {errors.numerator && <p className="text-sm text-destructive">{errors.numerator.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="denominator">Denominator Value</Label>
                <Input
                  id="denominator"
                  type="number"
                  {...register('denominator', { valueAsNumber: true })}
                />
                {errors.denominator && <p className="text-sm text-destructive">{errors.denominator.message}</p>}
              </div>
            </div>

            <div className="space-y-2 mt-4">
              <Label htmlFor="numeratorLabel">Numerator Definition</Label>
              <Input id="numeratorLabel" {...register('numeratorLabel')} placeholder="What does the numerator represent?" />
              {errors.numeratorLabel && <p className="text-sm text-destructive">{errors.numeratorLabel.message}</p>}
            </div>

            <div className="space-y-2 mt-4">
              <Label htmlFor="denominatorLabel">Denominator Definition</Label>
              <Input id="denominatorLabel" {...register('denominatorLabel')} placeholder="What does the denominator represent?" />
              {errors.denominatorLabel && <p className="text-sm text-destructive">{errors.denominatorLabel.message}</p>}
            </div>

            <div className="space-y-2 mt-4">
              <Label htmlFor="guidance">Guidance / How to Calculate</Label>
              <Textarea id="guidance" {...register('guidance')} placeholder="Explain how to measure and calculate this KPI..." rows={3} />
            </div>

            {/* Calculated Result Preview */}
            <div className="mt-4 p-3 bg-primary/5 rounded-lg border border-primary/10">
              <p className="text-sm text-muted-foreground">Calculated Value:</p>
              <p className="text-2xl font-bold text-foreground">{calculatedValue}{unit}</p>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">{kpi ? 'Update' : 'Create'}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}