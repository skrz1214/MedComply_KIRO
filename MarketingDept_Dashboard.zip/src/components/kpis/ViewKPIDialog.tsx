import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { KPI } from './KPIDialog';
import { Calculator, TrendingUp, TrendingDown, Minus, Pencil, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ViewKPIDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  kpi: KPI | null;
  onEdit: () => void;
}

export function ViewKPIDialog({ open, onOpenChange, kpi, onEdit }: ViewKPIDialogProps) {
  if (!kpi) return null;

  const getKPIStatus = (): 'on-track' | 'at-risk' | 'off-track' => {
    const isLowerBetter = kpi.name.toLowerCase().includes('violation');
    if (isLowerBetter) {
      if (kpi.current <= kpi.target) return 'on-track';
      if (kpi.current <= kpi.target + 2) return 'at-risk';
      return 'off-track';
    }
    const ratio = kpi.current / kpi.target;
    if (ratio >= 1) return 'on-track';
    if (ratio >= 0.95) return kpi.trend === 'up' ? 'on-track' : 'at-risk';
    if (ratio >= 0.85) return kpi.trend === 'up' ? 'at-risk' : 'off-track';
    return 'off-track';
  };

  const status = getKPIStatus();

  const getStatusIcon = () => {
    switch (status) {
      case 'on-track': return <CheckCircle className="h-5 w-5 text-success" />;
      case 'at-risk': return <Clock className="h-5 w-5 text-warning" />;
      case 'off-track': return <AlertTriangle className="h-5 w-5 text-destructive" />;
    }
  };

  const getStatusBadge = () => {
    const variants = {
      'on-track': 'bg-success/10 text-success border-success/20',
      'at-risk': 'bg-warning/10 text-warning border-warning/20',
      'off-track': 'bg-destructive/10 text-destructive border-destructive/20',
    };
    const labels = { 'on-track': 'On Track', 'at-risk': 'At Risk', 'off-track': 'Off Track' };
    return (
      <Badge variant="outline" className={cn('font-medium', variants[status])}>
        {labels[status]}
      </Badge>
    );
  };

  const TrendIcon = () => {
    if (kpi.trend === 'up') return <TrendingUp className="h-5 w-5 text-success" />;
    if (kpi.trend === 'down') return <TrendingDown className="h-5 w-5 text-destructive" />;
    return <Minus className="h-5 w-5 text-muted-foreground" />;
  };

  const isLowerBetter = kpi.name.toLowerCase().includes('violation');
  const progress = isLowerBetter 
    ? Math.max(0, 100 - (kpi.current * 10)) 
    : Math.min(100, (kpi.current / kpi.target) * 100);

  const getProgressColor = () => {
    switch (status) {
      case 'on-track': return 'bg-success';
      case 'at-risk': return 'bg-warning';
      case 'off-track': return 'bg-destructive';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[550px]">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2">
              {getStatusIcon()}
              <span>{kpi.name}</span>
            </DialogTitle>
            <Button variant="outline" size="sm" onClick={onEdit}>
              <Pencil className="h-4 w-4 mr-2" />
              Edit
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Status and Value */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="text-4xl font-bold text-foreground">{kpi.current}{kpi.unit}</div>
              <TrendIcon />
            </div>
            {getStatusBadge()}
          </div>

          {/* Progress Bar */}
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Progress to Target</span>
              <span className="font-medium">Target: {kpi.target}{kpi.unit}</span>
            </div>
            <div className="h-3 bg-muted rounded-full overflow-hidden">
              <div
                className={cn('h-full rounded-full transition-all', getProgressColor())}
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          {/* Metadata */}
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Periodicity</p>
              <p className="font-medium text-foreground">{kpi.periodicity}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Category</p>
              <p className="font-medium text-foreground">{kpi.category}</p>
            </div>
          </div>

          {/* Calculation Details */}
          {kpi.calculation && (
            <div className="border-t border-border pt-4">
              <div className="flex items-center gap-2 mb-4">
                <Calculator className="h-4 w-4 text-primary" />
                <h3 className="font-semibold text-foreground">How to Calculate</h3>
              </div>

              <div className="bg-muted/50 rounded-lg p-4 mb-4">
                <p className="font-mono text-sm text-foreground">{kpi.calculation.formula}</p>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-card border border-border rounded-lg p-3">
                  <p className="text-xs text-muted-foreground mb-1">Numerator</p>
                  <p className="text-2xl font-bold text-foreground">{kpi.calculation.numerator}</p>
                  <p className="text-xs text-muted-foreground mt-1">{kpi.calculation.numeratorLabel}</p>
                </div>
                <div className="bg-card border border-border rounded-lg p-3">
                  <p className="text-xs text-muted-foreground mb-1">Denominator</p>
                  <p className="text-2xl font-bold text-foreground">{kpi.calculation.denominator}</p>
                  <p className="text-xs text-muted-foreground mt-1">{kpi.calculation.denominatorLabel}</p>
                </div>
              </div>

              {kpi.calculation.guidance && (
                <div className="bg-primary/5 border border-primary/10 rounded-lg p-3">
                  <p className="text-xs font-medium text-primary mb-1">Guidance</p>
                  <p className="text-sm text-muted-foreground">{kpi.calculation.guidance}</p>
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}