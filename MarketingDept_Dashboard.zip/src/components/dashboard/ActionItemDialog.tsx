import { Shield, MessageSquare, AlertTriangle, ClipboardCheck, Gavel, FileCheck } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { microApps } from '@/data/mockData';
import { cn } from '@/lib/utils';

const iconMap: Record<string, React.ElementType> = {
  'shield-check': Shield,
  'message-square': MessageSquare,
  'alert-triangle': AlertTriangle,
  'clipboard-check': ClipboardCheck,
  'gavel': Gavel,
  'file-text': FileCheck,
};

interface ActionItemDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelect: (microAppId: string) => void;
}

export function ActionItemDialog({ open, onOpenChange, onSelect }: ActionItemDialogProps) {
  const handleSelect = (appId: string) => {
    onSelect(appId);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[450px]">
        <DialogHeader>
          <DialogTitle>Select Micro App</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3 pt-2">
          {microApps.map((app) => {
            const IconComponent = iconMap[app.icon] || Shield;
            return (
              <button
                key={app.id}
                type="button"
                onClick={() => handleSelect(app.id)}
                className={cn(
                  'flex items-center gap-3 p-4 rounded-lg border border-border transition-all text-left',
                  'hover:border-primary hover:bg-primary/5 hover:shadow-sm'
                )}
              >
                <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center shrink-0', app.color)}>
                  <IconComponent className="h-5 w-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm text-foreground truncate">{app.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{app.description}</p>
                </div>
              </button>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}
