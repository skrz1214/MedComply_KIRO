import { cn } from '@/lib/utils';
import { Status, Priority, RiskLevel } from '@/types/compliance';

interface StatusBadgeProps {
  status: Status;
  className?: string;
}

const statusConfig: Record<Status, { label: string; className: string }> = {
  completed: { label: 'Completed', className: 'status-completed' },
  pending: { label: 'Pending', className: 'status-pending' },
  overdue: { label: 'Overdue', className: 'status-overdue' },
  active: { label: 'Active', className: 'status-active' },
  draft: { label: 'Draft', className: 'bg-muted text-muted-foreground' },
  'in-progress': { label: 'In Progress', className: 'status-active' },
  'pending-review': { label: 'Pending Review', className: 'status-pending' },
  'under-review': { label: 'In Review', className: 'status-active' },
  approved: { label: 'Approved', className: 'status-completed' },
  flagged: { label: 'Flagged', className: 'status-overdue' },
  archived: { label: 'Archived', className: 'bg-muted text-muted-foreground' },
  'not-started': { label: 'Not Started', className: 'bg-muted text-muted-foreground' },
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status];
  return (
    <span className={cn('status-badge', config.className, className)}>
      {config.label}
    </span>
  );
}

interface PriorityBadgeProps {
  priority: Priority;
  className?: string;
}

const priorityConfig: Record<Priority, { label: string; className: string }> = {
  high: { label: 'High', className: 'priority-high' },
  medium: { label: 'Med', className: 'priority-medium' },
  low: { label: 'Low', className: 'priority-low' },
};

export function PriorityBadge({ priority, className }: PriorityBadgeProps) {
  const config = priorityConfig[priority];
  return (
    <span className={cn('status-badge', config.className, className)}>
      {config.label}
    </span>
  );
}

interface RiskLevelBadgeProps {
  level: RiskLevel;
  className?: string;
}

const riskConfig: Record<RiskLevel, { label: string; className: string }> = {
  high: { label: 'High Risk', className: 'priority-high' },
  medium: { label: 'Medium Risk', className: 'priority-medium' },
  low: { label: 'Low Risk', className: 'priority-low' },
};

export function RiskLevelBadge({ level, className }: RiskLevelBadgeProps) {
  const config = riskConfig[level];
  return (
    <span className={cn('status-badge', config.className, className)}>
      {config.label}
    </span>
  );
}
