import { Link } from 'react-router-dom';
import { Shield, MessageSquare, AlertTriangle, ClipboardCheck, Gavel, FileCheck } from 'lucide-react';
import { cn } from '@/lib/utils';
import { microApps } from '@/data/mockData';

const iconMap: Record<string, React.ElementType> = {
  'shield-check': Shield,
  'message-square': MessageSquare,
  'alert-triangle': AlertTriangle,
  'clipboard-check': ClipboardCheck,
  'gavel': Gavel,
  'file-text': FileCheck,
};

export function MicroAppGrid() {
  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <h3 className="font-semibold text-foreground mb-4">Micro Apps</h3>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {microApps.map((app) => {
          const IconComponent = iconMap[app.icon] || Shield;
          return (
            <Link key={app.id} to={app.route} className="micro-app-tile group">
              <div className={cn('micro-app-icon', app.color)}>
                <IconComponent className="h-5 w-5 text-white" />
              </div>
              <span className="text-sm font-medium text-foreground group-hover:text-accent transition-colors">
                {app.name}
              </span>
              <span className="text-xs text-muted-foreground text-center mt-1 line-clamp-2">
                {app.description}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
