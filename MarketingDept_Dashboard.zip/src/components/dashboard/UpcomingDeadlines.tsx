import { Link } from 'react-router-dom';
import { ArrowRight, Clock } from 'lucide-react';
import { StatusBadge, PriorityBadge } from './StatusBadge';
import { auditItems } from '@/data/mockData';

export function UpcomingDeadlines() {
  const upcomingItems = auditItems
    .filter((item) => item.status !== 'completed')
    .sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime())
    .slice(0, 5);

  return (
    <div className="bg-card rounded-lg border border-border">
      <div className="flex items-center justify-between p-4 border-b border-border">
        <h3 className="font-semibold text-foreground">Upcoming Deadlines</h3>
        <Link
          to="/audits"
          className="text-sm text-accent hover:text-accent/80 flex items-center gap-1 transition-colors"
        >
          View All
          <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
      <div className="divide-y divide-border">
        {upcomingItems.map((item) => (
          <div key={item.id} className="p-4 hover:bg-muted/30 transition-colors">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground truncate">{item.title}</p>
                <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                  <Clock className="h-3.5 w-3.5" />
                  <span>{new Date(item.deadline).toLocaleDateString()}</span>
                  <span>•</span>
                  <span>{item.owner}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <PriorityBadge priority={item.priority} />
                <StatusBadge status={item.status} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
