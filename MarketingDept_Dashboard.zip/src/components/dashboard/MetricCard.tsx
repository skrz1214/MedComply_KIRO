import { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { FileText, CheckCircle, Clock, AlertTriangle } from 'lucide-react';

interface MetricCardProps {
  label: string;
  value: number | string;
  icon?: ReactNode;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  variant?: 'default' | 'success' | 'warning' | 'destructive' | 'info';
  onClick?: () => void;
  isActive?: boolean;
}

const variantStyles = {
  default: 'border-border hover:border-primary/30',
  success: 'border-l-4 border-l-success border-border',
  warning: 'border-l-4 border-l-warning border-border',
  destructive: 'border-l-4 border-l-destructive border-border',
  info: 'border-l-4 border-l-info border-border',
};

const iconVariantStyles = {
  default: 'text-muted-foreground',
  success: 'text-success',
  warning: 'text-warning',
  destructive: 'text-destructive',
  info: 'text-info',
};

const trendColors = {
  up: 'text-success',
  down: 'text-destructive',
  neutral: 'text-muted-foreground',
};

export function MetricCard({
  label,
  value,
  icon,
  trend,
  trendValue,
  variant = 'default',
  onClick,
  isActive,
}: MetricCardProps) {
  return (
    <div
      onClick={onClick}
      className={cn(
        'bg-card rounded-xl border p-4 transition-all duration-200 hover:shadow-md',
        variantStyles[variant],
        onClick && 'cursor-pointer',
        isActive && 'ring-2 ring-primary ring-offset-2 ring-offset-background shadow-md'
      )}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {icon && (
            <div className={cn('flex-shrink-0', iconVariantStyles[variant])}>
              {icon}
            </div>
          )}
          <span className="text-sm font-medium text-muted-foreground">{label}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-2xl font-bold text-foreground">{value}</span>
          {trend && trendValue && (
            <span className={cn('text-sm font-medium', trendColors[trend])}>
              {trendValue}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

// Quick Stats Card for sidebar layout
interface QuickStatItemProps {
  icon: ReactNode;
  label: string;
  value: number | string;
  trend?: string;
  variant?: 'default' | 'success' | 'warning' | 'destructive';
}

const quickStatVariants = {
  default: 'text-foreground',
  success: 'text-success',
  warning: 'text-warning',
  destructive: 'text-destructive',
};

export function QuickStatItem({ icon, label, value, trend, variant = 'default' }: QuickStatItemProps) {
  return (
    <div className="quick-stat-item">
      <div className="flex items-center gap-3">
        <div className={cn('flex-shrink-0', quickStatVariants[variant])}>
          {icon}
        </div>
        <span className="text-sm text-muted-foreground">{label}</span>
      </div>
      <div className="flex items-center gap-2">
        <span className={cn('text-xl font-bold', quickStatVariants[variant])}>{value}</span>
        {trend && (
          <span className={cn('text-xs font-medium', quickStatVariants[variant])}>
            {trend}
          </span>
        )}
      </div>
    </div>
  );
}

export function QuickStatsCard() {
  return (
    <div className="card-section">
      <h3 className="text-sm font-semibold text-foreground mb-4">Quick Stats</h3>
      <div className="space-y-0">
        <QuickStatItem 
          icon={<FileText className="h-4 w-4" />} 
          label="Total" 
          value={24} 
          trend="+3"
        />
        <QuickStatItem 
          icon={<CheckCircle className="h-4 w-4" />} 
          label="Completed" 
          value={12} 
          trend="+5"
          variant="success"
        />
        <QuickStatItem 
          icon={<Clock className="h-4 w-4" />} 
          label="Pending" 
          value={10} 
          trend="-2"
          variant="warning"
        />
        <QuickStatItem 
          icon={<AlertTriangle className="h-4 w-4" />} 
          label="Overdue" 
          value={2} 
          trend="+1"
          variant="destructive"
        />
      </div>
    </div>
  );
}
