import { UserRole, roleConfigs, useRole } from '@/contexts/RoleContext';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { UserCog } from 'lucide-react';

export function RoleSwitcher() {
  const { currentRole, setCurrentRole } = useRole();

  return (
    <div className="flex items-center gap-2">
      <UserCog className="h-4 w-4 text-muted-foreground" />
      <Select value={currentRole} onValueChange={(value: UserRole) => setCurrentRole(value)}>
        <SelectTrigger className="w-48 h-9 text-sm bg-card border-border">
          <SelectValue placeholder="Select role" />
        </SelectTrigger>
        <SelectContent>
          {(Object.keys(roleConfigs) as UserRole[]).map((role) => (
            <SelectItem key={role} value={role}>
              {roleConfigs[role].label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
