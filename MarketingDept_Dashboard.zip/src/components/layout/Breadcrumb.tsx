import { ChevronRight, Home } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const routeLabels: Record<string, string> = {
  '': 'Marketing Compliance',
  'org-chart': 'Org Chart',
  'policies': 'Policies & Procedures',
  'audits': 'Audit Items',
  'enforcements': 'Enforcements',
  'risks': 'Risks & Thresholds',
  'compliance': 'Compliance Items',
  'marketing-policy': 'Marketing Policy',
  'marketing-compliance': 'Marketing Compliance',
  'quality-kpis': 'Quality KPIs',
  'hipaa-adaa': 'HIPAA & ADAA',
  'digital-content': 'Digital Content',
  'digital-channels': 'Digital Channels',
  'print-marketing': 'Print Marketing',
  'apps': 'Micro Apps',
};

export function Breadcrumb() {
  const location = useLocation();
  const pathSegments = location.pathname.split('/').filter(Boolean);

  const breadcrumbs = pathSegments.map((segment, index) => {
    const path = '/' + pathSegments.slice(0, index + 1).join('/');
    const label = routeLabels[segment] || segment.charAt(0).toUpperCase() + segment.slice(1).replace(/-/g, ' ');
    return { path, label };
  });

  return (
    <nav className="flex items-center space-x-1 text-sm" aria-label="Breadcrumb">
      <Link
        to="/"
        className="flex items-center text-muted-foreground hover:text-foreground transition-colors"
      >
        <Home className="h-4 w-4" />
      </Link>
      {breadcrumbs.map((crumb, index) => (
        <div key={crumb.path} className="flex items-center">
          <ChevronRight className="h-4 w-4 text-muted-foreground mx-1" />
          {index === breadcrumbs.length - 1 ? (
            <span className="font-medium text-foreground">{crumb.label}</span>
          ) : (
            <Link
              to={crumb.path}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              {crumb.label}
            </Link>
          )}
        </div>
      ))}
    </nav>
  );
}
