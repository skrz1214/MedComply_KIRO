import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  ClipboardCheck,
  Shield,
  AlertTriangle,
  CheckCircle,
  ChevronDown,
  ChevronRight,
  MessageSquare,
  Gavel,
  FileText,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useRole } from '@/contexts/RoleContext';

interface NavItem {
  label: string;
  icon: React.ElementType;
  path: string;
  children?: NavItem[];
}

const managementHubItems: NavItem[] = [
  { label: 'Dashboard', icon: LayoutDashboard, path: '/' },
  { label: 'Org Chart', icon: Users, path: '/org-chart' },
  { label: 'Risk Management', icon: AlertTriangle, path: '/risks' },
  { label: 'Audit Management', icon: ClipboardCheck, path: '/audits' },
  { label: 'Enforcement Management', icon: Gavel, path: '/enforcements' },
  { label: 'Compliance Tracking', icon: CheckCircle, path: '/compliance' },
  { label: 'Feedback Management', icon: MessageSquare, path: '/feedback' },
];

export function Sidebar() {
  const location = useLocation();
  const { roleConfig } = useRole();
  const [expandedSections, setExpandedSections] = useState<string[]>(['management']);

  const toggleSection = (section: string) => {
    setExpandedSections((prev) =>
      prev.includes(section) ? prev.filter((s) => s !== section) : [...prev, section]
    );
  };

  const isActive = (path: string) => location.pathname === path;

  const NavLink = ({ item }: { item: NavItem }) => (
    <Link
      to={item.path}
      className={cn(
        'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200',
        isActive(item.path)
          ? 'bg-sidebar-accent text-primary font-medium'
          : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
      )}
    >
      <item.icon className={cn('h-4 w-4 flex-shrink-0', isActive(item.path) ? 'text-primary' : 'text-sidebar-muted')} />
      <span>{item.label}</span>
    </Link>
  );

  const SectionHeader = ({ title, section }: { title: string; section: string }) => (
    <button
      onClick={() => toggleSection(section)}
      className="flex items-center justify-between w-full px-3 py-2 text-sidebar-muted hover:text-sidebar-foreground transition-colors"
    >
      <span className="text-xs font-semibold uppercase tracking-wider">{title}</span>
      {expandedSections.includes(section) ? (
        <ChevronDown className="h-4 w-4" />
      ) : (
        <ChevronRight className="h-4 w-4" />
      )}
    </button>
  );

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-sidebar flex flex-col border-r border-sidebar-border z-50">
      {/* Header */}
      <div className="flex items-center gap-3 p-4 border-b border-sidebar-border">
        <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
          <Shield className="h-5 w-5 text-primary-foreground" />
        </div>
        <div>
          <span className="font-semibold text-sidebar-foreground">ComplianceHub</span>
          <p className="text-xs text-sidebar-muted">Marketing Division</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 scrollbar-thin">
        {/* Management Hub */}
        <div className="mb-4">
          <SectionHeader title="Management Hub" section="management" />
          {expandedSections.includes('management') && (
            <div className="space-y-1 mt-1">
              {managementHubItems.map((item) => (
                <NavLink key={item.path} item={item} />
              ))}
            </div>
          )}
        </div>

        {/* Documentation */}
        <div className="mb-4">
          <Link
            to="/documentation"
            className={cn(
              'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200',
              isActive('/documentation')
                ? 'bg-sidebar-accent text-primary font-medium'
                : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
            )}
          >
            <FileText className={cn('h-4 w-4 flex-shrink-0', isActive('/documentation') ? 'text-primary' : 'text-sidebar-muted')} />
            <span>Documentation</span>
          </Link>
        </div>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
            <span className="text-sm font-medium text-primary">{roleConfig.initials}</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-sidebar-foreground truncate">
              {roleConfig.initials === 'SC' ? 'Sarah Chen' : roleConfig.initials === 'JD' ? 'John Davis' : 'Tom Miller'}
            </p>
            <p className="text-xs text-sidebar-muted truncate">{roleConfig.title}</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
