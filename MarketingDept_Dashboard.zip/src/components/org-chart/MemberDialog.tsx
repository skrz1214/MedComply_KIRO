import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { TeamMember } from '@/types/compliance';

const memberSchema = z.object({
  name: z.string().trim().min(1, 'Name is required').max(100, 'Name must be less than 100 characters'),
  role: z.string().trim().min(1, 'Role is required').max(100, 'Role must be less than 100 characters'),
  department: z.string().trim().min(1, 'Department is required').max(100, 'Department must be less than 100 characters'),
  email: z.string().trim().email('Invalid email address').max(255, 'Email must be less than 255 characters'),
  reportsTo: z.string().optional(),
});

type MemberFormData = z.infer<typeof memberSchema>;

interface MemberDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  member?: TeamMember | null;
  members: TeamMember[];
  onSave: (data: MemberFormData & { id?: string }) => void;
}

export function MemberDialog({ open, onOpenChange, member, members, onSave }: MemberDialogProps) {
  const isEditing = !!member;

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<MemberFormData>({
    resolver: zodResolver(memberSchema),
    defaultValues: {
      name: '',
      role: '',
      department: 'Marketing Compliance',
      email: '',
      reportsTo: '',
    },
  });

  const reportsToValue = watch('reportsTo');

  useEffect(() => {
    if (member) {
      reset({
        name: member.name,
        role: member.role,
        department: member.department,
        email: member.email,
        reportsTo: member.reportsTo || '',
      });
    } else {
      reset({
        name: '',
        role: '',
        department: 'Marketing Compliance',
        email: '',
        reportsTo: '',
      });
    }
  }, [member, reset]);

  const onSubmit = (data: MemberFormData) => {
    onSave({
      ...data,
      id: member?.id,
      reportsTo: data.reportsTo || undefined,
    });
    onOpenChange(false);
  };

  // Filter out current member from reports to list (can't report to yourself)
  const availableManagers = members.filter((m) => m.id !== member?.id);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{isEditing ? 'Edit Team Member' : 'Add Team Member'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name *</Label>
            <Input
              id="name"
              placeholder="Enter full name"
              {...register('name')}
              className={errors.name ? 'border-destructive' : ''}
            />
            {errors.name && (
              <p className="text-sm text-destructive">{errors.name.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email *</Label>
            <Input
              id="email"
              type="email"
              placeholder="Enter email address"
              {...register('email')}
              className={errors.email ? 'border-destructive' : ''}
            />
            {errors.email && (
              <p className="text-sm text-destructive">{errors.email.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="role">Role *</Label>
            <Input
              id="role"
              placeholder="Enter job title"
              {...register('role')}
              className={errors.role ? 'border-destructive' : ''}
            />
            {errors.role && (
              <p className="text-sm text-destructive">{errors.role.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="department">Department *</Label>
            <Input
              id="department"
              placeholder="Enter department"
              {...register('department')}
              className={errors.department ? 'border-destructive' : ''}
            />
            {errors.department && (
              <p className="text-sm text-destructive">{errors.department.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="reportsTo">Reports To</Label>
            <Select
              value={reportsToValue || ''}
              onValueChange={(value) => setValue('reportsTo', value === 'none' ? '' : value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select manager (optional)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No Manager (Top Level)</SelectItem>
                {availableManagers.map((m) => (
                  <SelectItem key={m.id} value={m.id}>
                    {m.name} - {m.role}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isEditing ? 'Update Member' : 'Add Member'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
