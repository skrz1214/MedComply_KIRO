import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { TeamMember } from '@/types/compliance';
import { Mail, Building } from 'lucide-react';

interface ViewProfileDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  member: TeamMember | null;
  members: TeamMember[];
  onSendMessage: (member: TeamMember) => void;
}

export function ViewProfileDialog({ open, onOpenChange, member, members, onSendMessage }: ViewProfileDialogProps) {
  if (!member) return null;

  const manager = member.reportsTo ? members.find((m) => m.id === member.reportsTo) : null;
  const directReports = members.filter((m) => m.reportsTo === member.id);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Team Member Profile</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          {/* Profile Header */}
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="text-xl font-semibold text-primary">
                {member.name.split(' ').map((n) => n[0]).join('')}
              </span>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-foreground">{member.name}</h3>
              <p className="text-muted-foreground">{member.role}</p>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-3 mb-6">
            <div className="flex items-center gap-3 text-sm">
              <Mail className="h-4 w-4 text-muted-foreground" />
              <span className="text-foreground">{member.email}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Building className="h-4 w-4 text-muted-foreground" />
              <span className="text-foreground">{member.department}</span>
            </div>
          </div>

          {/* Reporting Structure */}
          <div className="space-y-4">
            {manager && (
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-2">Reports To</h4>
                <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-xs font-semibold text-primary">
                      {manager.name.split(' ').map((n) => n[0]).join('')}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">{manager.name}</p>
                    <p className="text-xs text-muted-foreground">{manager.role}</p>
                  </div>
                </div>
              </div>
            )}

            {directReports.length > 0 && (
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-2">
                  Direct Reports ({directReports.length})
                </h4>
                <div className="space-y-2">
                  {directReports.map((report) => (
                    <div key={report.id} className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-xs font-semibold text-primary">
                          {report.name.split(' ').map((n) => n[0]).join('')}
                        </span>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">{report.name}</p>
                        <p className="text-xs text-muted-foreground">{report.role}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="mt-6 pt-4 border-t border-border">
            <Button 
              className="w-full"
              onClick={() => {
                onSendMessage(member);
                onOpenChange(false);
              }}
            >
              Send Message
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
